package data_cache

import (
	"content_svr/pub/logger"
	"context"
	"github.com/samber/lo"
	"sort"
	"strconv"
	"time"
)

func (p *DataCacheMng) GetUserMemberType(ctx context.Context, userId int64) int32 {
	redisKey := getRdsKeyMemberType(userId)
	retDict, err := p.RedisCli.HGetAll(ctx, redisKey).Result()
	if err != nil {
		logger.Errorf(ctx, "GetUserMemberType failed. key=%v, err=%v", redisKey, err.Error())
	}
	if len(retDict) == 0 {
		return 0
	}

	curTimeStr := strconv.FormatInt(time.Now().UnixNano()/1e6, 10)
	if retDict["1"] > curTimeStr {
		return 1
	}
	if retDict["3"] > curTimeStr {
		return 3
	}
	if retDict["2"] > curTimeStr {
		return 2
	}
	return 0
}

//func (p *DataCacheMng) DeleteUserMemberType(ctx context.Context, userId int64) {
//	redisKey := getRdsKeyMemberType(userId)
//	_, err := p.RedisCli.Del(ctx, redisKey).Result()
//	if err != nil {
//		logger.Errorf(ctx, "delete member type from redis, userID: %v, membertype: %v", userId, redisKey)
//	}
//}

func (p *DataCacheMng) GetUserMember(ctx context.Context, userId int64) (int32, int64) {
	redisKey := getRdsKeyMemberType(userId)
	retDict, err := p.RedisCli.HGetAll(ctx, redisKey).Result()
	if err != nil {
		logger.Errorf(ctx, "GetUserMemberType failed. key=%v, err=%v", redisKey, err.Error())
	}

	keys := lo.Keys(retDict)
	sort.Strings(keys)

	curTimeStr := time.Now().UnixMilli()
	for _, k := range keys {
		v := retDict[k]
		expire, _ := strconv.Atoi(v)
		if int64(expire) <= curTimeStr {
			continue
		}
		switch k {
		case "1":
			return 1, int64(expire)
		case "2":
			return 3, int64(expire)
		case "3":
			return 3, int64(expire)
		}
	}

	// TODO 降级DB

	return 0, 0
}
