package cache

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/dao/operate"
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
	"context"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type BackgroundImage struct {
	model.BackgroundImageModel
	redisManage *query_rds.Manage
}

func NewCacheBackgroundImage(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *BackgroundImage {
	return &BackgroundImage{
		BackgroundImageModel: mongo.BackgroundImage,
		redisManage:          redisManage,
	}
}

func (p *BackgroundImage) Create(ctx context.Context, data *model.BackgroundImage) error {
	number, overlap, err := p.BackgroundImageModel.CheckOverlap(ctx, data)
	if err != nil {
		return err
	}
	if overlap {
		return xerr.DbTimeOverlapError.SetMsg(fmt.Sprintf("已与序号为%d的默认背景设置生效时间重叠，请修改后保存", number))
	}

	opt := &options.FindOneOptions{}
	opt.Sort = bson.D{
		{Key: "number", Value: -1},
	}
	firstBackground, err := p.BackgroundImageModel.FindOne(ctx, nil, opt)
	var newNumber int64
	switch err {
	case xerr.DbNotFound:
		break
	case nil:
		newNumber = firstBackground.Number
	default:
		return err
	}
	data.Number = newNumber + 1
	result, err := p.BackgroundImageModel.Insert(ctx, data)
	if err != nil {
		return err
	}
	id := result.InsertedID.(primitive.ObjectID)
	data.ID = id

	if err := p.redisManage.BackgroundImage.SetRds(ctx, data); err != nil {
		return err
	}

	return nil
}

func (p *BackgroundImage) Update(ctx context.Context, data *model.BackgroundImage, checkFlag bool) error {
	if checkFlag {
		number, overlap, err := p.BackgroundImageModel.CheckOverlap(ctx, data)
		if err != nil {
			return err
		}
		if overlap {
			return xerr.DbTimeOverlapError.SetMsg(fmt.Sprintf("已与序号为%d的默认背景设置生效时间重叠，请修改后保存", number))
		}
	}

	update, err := p.BackgroundImageModel.UpdateOne(ctx, data)
	if err != nil {
		return err
	}

	if update.ModifiedCount == 0 {
		return xerr.DbDoNothing
	}

	data, err = p.BackgroundImageModel.FindById(ctx, data.ID)
	if err := p.redisManage.BackgroundImage.UpdateRds(ctx, data); err != nil {
		return err
	}

	return nil
}

func (p *BackgroundImage) FindById(ctx context.Context, id string) (*model.BackgroundImage, error) {
	return p.BackgroundImageModel.FindById(ctx, id)
}

func (p *BackgroundImage) FindPage(ctx context.Context, turner operate.PageTurner) ([]model.BackgroundImage, int64, error) {
	filter, opt := turner.ParseMongo()

	list, err := p.BackgroundImageModel.FindAll(ctx, filter, opt)
	if err != nil {
		return nil, 0, err
	}

	total, err := p.BackgroundImageModel.Count(ctx, filter)
	if err != nil {
		return nil, 0, err
	}

	return list, total, nil

}

func (p *BackgroundImage) Delete(ctx context.Context, id string) error {
	result, err := p.BackgroundImageModel.Delete(ctx, id)
	if err != nil {
		return err
	}
	if result == 0 {
		return xerr.DbDoNothing
	}

	if _, err := p.redisManage.BackgroundImage.DelRds(ctx, id); err != nil {
		logx.Error(err)
	}

	return nil
}
