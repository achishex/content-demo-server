#!/bin/bash

cd ./app/maozhua_admin_svr/cmd/
sh gen.sh