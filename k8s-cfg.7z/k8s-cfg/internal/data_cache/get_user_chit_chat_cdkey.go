package data_cache

import (
	"content_svr/pub/logger"
	"context"
)

func (p *DataCacheMng) GetChitChatCDKeyExpireTime(ctx context.Context) int64 {
	redisKey := getRdsKeyTimesConfig("times_chitchat_cd_key_expire")

	expireDay, err := p.RedisCli.Get(ctx, redisKey).Int64()
	if err != nil {
		logger.Error(ctx, "GetChitChatCDKeyExpireTime", err)
		return 30
	}

	return expireDay
}
