package aggregation

import (
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/utils"
	"context"
	"time"
)

type Member struct {
	WriteDB, ReadDB *dao.ManagerDB
}

func (s *Member) Today(ctx context.Context) ([]model.UserMemberStatistical, error) {
	now := time.Now()
	nowZero := utils.ZeroTime(now)
	where := map[string]interface{}{
		"create_time_start": nowZero.Format("2006-01-02 15:04:05"),
		"type":              1001,
		"order_status":      3,
	}

	return s.UserMember(ctx, where)
}

func (s *Member) UserMember(ctx context.Context, where map[string]interface{}) ([]model.UserMemberStatistical, error) {
	var memberTable = map[int64]model.UserMemberStatistical{}

	orders, err := s.ReadDB.OrderInfo.FindMap(ctx, 0, 0, where)
	if err != nil {
		return nil, err
	}

	for _, order := range orders {
		createTime, err := time.Parse("2006-01-02 15:04:05", order.CreateTime)
		if err != nil {
			return nil, err
		}
		zero := utils.ZeroTime(createTime).UnixMilli()
		var data model.UserMemberStatistical
		if value, exist := memberTable[zero]; exist {
			data = value
		}

		data.Day = zero
		price := uint(order.Price)
		switch order.AppType {
		case "applet-qq":
			data.QQSum += price
		case "applet-wx":
			data.WeiXinSum += price
		case "mobile-android":
			data.AndroidSum += price
		case "mobile-ios":
			data.IosSum += price
		default:
			data.UnknownSum += price
			continue
		}

		data.PriceSum += price
		memberTable[zero] = data
	}

	result := make([]model.UserMemberStatistical, 0)
	for _, statistical := range memberTable {
		result = append(result, statistical)
	}

	return result, nil

}
