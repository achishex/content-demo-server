package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretPayNotifyMgModel interface {
	Get(ctx context.Context, filter any) (*pbmgdb.SecretPayNotifyMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.SecretPayNotifyMgDbModel, options ...*options.InsertOneOptions) error
}

type SecretPayNotify struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretPayNotifyMgModelImpl(db *mongo.Database) ISecretPayNotifyMgModel {
	return &SecretPayNotify{
		MgDB:  db,
		Table: "secretPayNotify",
	}
}

func (g *SecretPayNotify) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *SecretPayNotify) Get(ctx context.Context, filter any) (*pbmgdb.SecretPayNotifyMgDbModel, error) {
	var v *pbmgdb.SecretPayNotifyMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretPayNotify Get failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *SecretPayNotify) Create(ctx context.Context, data *pbmgdb.SecretPayNotifyMgDbModel, options ...*options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data, options...)

	if err != nil {
		logger.Errorf(ctx, "SecretPayNotify:create error : %v", err)
		return err
	}

	return nil
}
