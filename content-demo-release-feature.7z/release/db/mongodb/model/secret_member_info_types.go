package model

type SecretMemberInfo struct {
	ID        int64 `json:"id,omitempty" bson:"_id,omitempty"`
	UserId    int64 `json:"userId,omitempty" bson:"userId,omitempty"`
	Type      int32 `json:"type,omitempty" bson:"type,omitempty"`
	Expire    int64 `json:"expire,omitempty" bson:"expire,omitempty"`       //过期时间
	Timestamp int64 `json:"timestamp,omitempty" bson:"timestamp,omitempty"` //过期时间
	Enable    bool  `json:"enable,omitempty" bson:"enable,omitempty"`
	RepairNo  int32 `json:"repairNo,omitempty" bson:"workId,omitempty"`
}
