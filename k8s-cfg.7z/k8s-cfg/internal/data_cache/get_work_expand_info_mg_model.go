package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	"time"
)

// mgdb.SecretWorksExpandRel 获取work的expand记录。  mysqldb.SecretExpandType获取expand的详细信息。
func (p *DataCacheMng) GetWorkExpandInfoMgDBLd(ctx context.Context, workId int64) [][]*pbapi.WorksExpandTypeSimpleResponse {
	//从内存取
	cacheKey := fmt.Sprintf(cache_const.WorkExpandInfoLcache.KeyFmt, workId)
	expire := cache_const.WorkExpandInfoLcache.Expire
	cResp, exist := p.LocalCache.Get(cacheKey)
	if exist {
		resp, ok := cResp.([][]*pbapi.WorksExpandTypeSimpleResponse)
		if ok && resp != nil {
			return resp
		}
	}

	resp := make([][]*pbapi.WorksExpandTypeSimpleResponse, 0)
	//从mg db取
	mgItems, err := p.WorkExpandRelMgDbModel.ListByWorkId(ctx, workId)
	if err != nil {
		logger.Errorf(ctx, "get WorkExpandInfo failed. workId=%v, err=%v", workId, err.Error())
		return nil
	}

	expandIds := make([]int64, 0)
	for _, mgItem := range mgItems {
		expandIds = append(expandIds, mgItem.GetExpandId())
	}
	//获取所有 expandid记录。
	if len(expandIds) > 0 {
		cond := map[string]interface{}{"id": expandIds}
		expandArrs, err := p.SecretExpandTypeModel.ListItemsPathsByCondition(ctx, cond, 1, cm_const.MaxDbSize)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("get WorkExpandInfo list failed. expandids=%v", expandIds), err)
			return nil
		}

		for _, expandList := range expandArrs {
			if len(expandList) == 0 {
				continue
			}

			oneRow := make([]*pbapi.WorksExpandTypeSimpleResponse, 0)
			for _, expand := range expandList {
				oneRow = append(oneRow, &pbapi.WorksExpandTypeSimpleResponse{
					Id:    expand.GetId(),
					Title: expand.GetTitle(),
					Icon:  expand.GetIcon(),
				})
			}
			resp = append(resp, oneRow)
		}
	}

	// save 到localcache
	bSuc := p.LocalCache.Set(cacheKey, resp, go_cache.WithEx(time.Duration(expire)*time.Second))
	logger.Infof(ctx, "save WorkExpandInfo to local cache. workId=%v, value=%v,bSuc=%v", workId, resp, bSuc)
	return resp
}
