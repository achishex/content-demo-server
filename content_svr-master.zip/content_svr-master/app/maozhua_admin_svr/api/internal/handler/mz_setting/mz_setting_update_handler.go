package mz_setting

import (
	"content_svr/app/maozhua_admin_svr/common/result"
	"content_svr/app/maozhua_admin_svr/common/xhttp"
	"github.com/go-playground/validator/v10"
	"net/http"

	"content_svr/app/maozhua_admin_svr/api/internal/logic/mz_setting"
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
)

type verifyMzSettingUpdateReqRequest struct {
	types.MzSettingUpdateReq
}

func (p *verifyMzSettingUpdateReqRequest) Validate() error {
	valid := validator.New()
	if err := valid.Struct(p); err != nil {
		return err
	}
	return nil
}

func MzSettingUpdateHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req verifyMzSettingUpdateReqRequest
		if err := xhttp.Parse(r, &req); err != nil {
			result.ParamErrorResult(r, w, err)
			return
		}

		l := mz_setting.NewMzSettingUpdateLogic(r.Context(), svcCtx)
		resp, err := l.MzSettingUpdate(&req.MzSettingUpdateReq)
		result.HttpResult(r, w, resp, err)
	}
}
