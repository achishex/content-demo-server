package security_mng

import (
	"content_svr/internal/data_cache"
	"content_svr/internal/inner_mng"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/thirdparty/baidu_lbs_yun_proxy"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/protobuf/pbsecurity"
	"context"
)

type SecurityMng struct {
	DataCache     data_cache.IDataCacheMng
	BaiduLbsProxy baidu_lbs_yun_proxy.IBaiduLbsYunProxy
	ShumeiProxy   shumei_proxy.IShumeiProxy
	InnerProxy    inner_mng.IInnerProxy
	KafkaProxy    kafka_proxy.IKafkaProxy
}

type ISecurityMng interface {
	CheckUpdateUserInfo(ctx context.Context, req *pbsecurity.CheckUpdateUserInfoReq) (*pbsecurity.CheckUpdateUserInfoSimple, error)
	CheckTelPhone(ctx context.Context, phoneNum string) (int32, error)
	CheckTxt(ctx context.Context, userId int64, eventId, content string, checkType int32) (int32, error)
	CheckImage(ctx context.Context, userId int64, eventId, url string) (int32, error)
}

func NewSecurityMng(
	dataCache data_cache.IDataCacheMng,
	BaiduLbsProxy baidu_lbs_yun_proxy.IBaiduLbsYunProxy,
	shumeiProxy shumei_proxy.IShumeiProxy,
	innerProxy inner_mng.IInnerProxy,
	kafkaProxy kafka_proxy.IKafkaProxy) ISecurityMng {
	return &SecurityMng{
		DataCache:     dataCache,
		BaiduLbsProxy: BaiduLbsProxy,
		ShumeiProxy:   shumeiProxy,
		InnerProxy:    innerProxy,
		KafkaProxy:    kafkaProxy,
	}
}
