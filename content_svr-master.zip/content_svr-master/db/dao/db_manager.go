package dao

import (
	"content_svr/db/dao/cache"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type ManagerDB struct {
	// cache mysql
	*cache.UserInfo
	*cache.PersonalBottleWorks
	*cache.OperatorTab
	*cache.WorkObjectAttr
	*cache.OrderInfo
	*cache.WxRewardLog

	// cache mongo
	*cache.MzRobot
	*cache.WorksCommentDetail
	*cache.BackgroundImage
	*cache.SecretUserExtInfo
	*cache.SecretMemberInfo
	*cache.SecretMemberDetail
	*cache.UserMemberStatistical
	*cache.SmsRecord
	*cache.SecretAudit
	*cache.SecretActiveUser
	*cache.SuperiorAwardDaily
	*cache.SuperiorContentAwardDetail
	*cache.UserRewardMoneyActivity
	*cache.SecretReport
	*cache.SecretReportUser
	*cache.SecretBlackHouse
	*cache.PersonalTalkMessageRecord
	*cache.SecretMedalInfo
	*cache.SecretUserMedalInfo
	*cache.PersonalPoliceInfo
	*cache.SecretUserActivityDaily
	*cache.SecretUserChannelDaily
	*cache.SecretUserRetainedStatistics
	*cache.PersonalPoliceDailyData
	*cache.CsjAdvertisementData
	*cache.SecretGame
	*cache.SecretGameOrder
	*cache.GameStatistical
	*cache.SecretGameStatisticDaily
	*cache.SecretMeme
	*cache.AppAdvertisement
	*cache.SecretUserIdentificationCard
	*cache.PersonalUserNotificationMgModel
	*cache.Partner
	*cache.PartnerDailySignIn
	*cache.PartnerInvite
	*cache.IntraCity
	*cache.ProvinceCity
	*cache.ZooGameUserInfo
	*cache.ZooGamePayInfo
	*cache.ZooGamePayDaily

	// mysql
	*query.Query

	// mongo
	*query_mng.QueryMng
}

func NewDbManager(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *ManagerDB {
	m := &ManagerDB{
		Query:    mysql,
		QueryMng: mongo,

		UserInfo:            cache.NewCacheUserInfo(mysql, mongo, redisManage),
		PersonalBottleWorks: cache.NewCachePersonalBottleWorks(mysql, mongo, redisManage),
		OperatorTab:         cache.NewCacheOperatorTab(mysql, mongo, redisManage),
		WorkObjectAttr:      cache.NewCacheWorkObjectAttr(mysql, mongo, redisManage),
		OrderInfo:           cache.NewCacheOrderInfo(mysql, mongo, redisManage),
		WxRewardLog:         cache.NewCacheWxRewardLog(mysql, mongo, redisManage),

		MzRobot:                         cache.NewCacheMzRobot(mysql, mongo, redisManage),
		WorksCommentDetail:              cache.NewCacheWorksCommentDetail(mysql, mongo, redisManage),
		BackgroundImage:                 cache.NewCacheBackgroundImage(mysql, mongo, redisManage),
		SecretUserExtInfo:               cache.NewCacheSecretUserExtInfo(mysql, mongo, redisManage),
		SecretMemberInfo:                cache.NewCacheSecretMemberInfo(mysql, mongo, redisManage),
		SecretMemberDetail:              cache.NewCacheSecretMemberDetail(mysql, mongo, redisManage),
		UserMemberStatistical:           cache.NewCacheUserMemberStatistical(mysql, mongo, redisManage),
		SmsRecord:                       cache.NewCacheSmsRecord(mysql, mongo, redisManage),
		SecretAudit:                     cache.NewCacheSecretAudit(mysql, mongo, redisManage),
		SecretActiveUser:                cache.NewCacheSecretActiveUser(mysql, mongo, redisManage),
		SuperiorAwardDaily:              cache.NewCacheSuperiorAwardDaily(mysql, mongo, redisManage),
		SuperiorContentAwardDetail:      cache.NewCacheSuperiorContentAwardDetail(mysql, mongo, redisManage),
		UserRewardMoneyActivity:         cache.NewCacheUserRewardMoneyActivity(mysql, mongo, redisManage),
		SecretReport:                    cache.NewCacheSecretReport(mysql, mongo, redisManage),
		SecretReportUser:                cache.NewCacheSecretReportUser(mysql, mongo, redisManage),
		SecretBlackHouse:                cache.NewCacheSecretBlackHouse(mysql, mongo, redisManage),
		PersonalTalkMessageRecord:       cache.NewCachePersonalTalkMessageRecord(mysql, mongo, redisManage),
		SecretMedalInfo:                 cache.NewCacheSecretMedalInfo(mysql, mongo, redisManage),
		SecretUserMedalInfo:             cache.NewCacheSecretUserMedalInfo(mysql, mongo, redisManage),
		PersonalPoliceInfo:              cache.NewCachePersonalPoliceInfo(mysql, mongo, redisManage),
		SecretUserActivityDaily:         cache.NewCacheSecretUserActivityDaily(mysql, mongo, redisManage),
		SecretUserChannelDaily:          cache.NewCacheSecretUserChannelDaily(mysql, mongo, redisManage),
		SecretUserRetainedStatistics:    cache.NewCacheSecretUserRetainedStatistics(mysql, mongo, redisManage),
		PersonalPoliceDailyData:         cache.NewCachePersonalPoliceDailyData(mysql, mongo, redisManage),
		CsjAdvertisementData:            cache.NewCacheCsjAdvertisementData(mysql, mongo, redisManage),
		SecretGame:                      cache.NewCacheSecretGame(mysql, mongo, redisManage),
		SecretGameOrder:                 cache.NewCacheSecretGameOrder(mysql, mongo, redisManage),
		GameStatistical:                 cache.NewCacheGameStatistical(mysql, mongo, redisManage),
		SecretGameStatisticDaily:        cache.NewCacheSecretGameStatisticDaily(mysql, mongo, redisManage),
		SecretMeme:                      cache.NewCacheSecretMeme(mysql, mongo, redisManage),
		AppAdvertisement:                cache.NewCacheAppAdvertisement(mysql, mongo, redisManage),
		SecretUserIdentificationCard:    cache.NewCacheSecretUserIdentificationCard(mysql, mongo, redisManage),
		PersonalUserNotificationMgModel: cache.NewCachePersonalUserNotificationMgModel(mysql, mongo, redisManage),
		Partner:                         cache.NewCachePartner(mysql, mongo, redisManage),
		PartnerDailySignIn:              cache.NewCachePartnerDailySignIn(mysql, mongo, redisManage),
		PartnerInvite:                   cache.NewCachePartnerInvite(mysql, mongo, redisManage),
		IntraCity:                       cache.NewCacheIntraCity(mysql, mongo, redisManage),
		ProvinceCity:                    cache.NewCacheProvinceCity(mysql, mongo, redisManage),
		ZooGameUserInfo:                 cache.NewCacheZooGameUserInfo(mysql, mongo, redisManage),
		ZooGamePayInfo:                  cache.NewCacheZooGamePayInfo(mysql, mongo, redisManage),
		ZooGamePayDaily:                 cache.NewCacheZooGamePayDaily(mysql, mongo, redisManage),
	}

	return m
}
