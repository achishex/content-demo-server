import os
import time
import torch
from typing import List
from datetime import datetime
from typing import Optional
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from optimum.onnxruntime import ORTModelForSequenceClassification
from app.core.logs import logger


tokenizer =  None 
model = None 
device = None 

def usePyTorchModel(modelName):
    return AutoModelForSequenceClassification.from_pretrained(modelName)

def useORTModel(modelName):
    return ORTModelForSequenceClassification.from_pretrained(modelName)

def useGpu(modelIn):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return modelIn.to(device), device
def modelCreate(modelName, mType: int):
    if mType == 1:
        return usePyTorchModel(modelName)
    elif mType == 2:
        return useORTModel(modelName)
    else:
        return useORTModel(modelName)
def loadModel():
    # MODEL_NAME = "BAAI/bge-reranker-base"
    # MODEL_NAME = "BAAI/bge-reranker-v2-m3" ## 强多语言支持，包含中文、英文、日文等
    modelName = "mixedbread-ai/mxbai-rerank-xsmall-v1" ##支持多语言，适合轻量部署
    global tokenizer, model, device

    tokenizer = AutoTokenizer.from_pretrained(modelName)
    model = modelCreate(modelName, 2)
    model, device = useGpu(model)
    print(f"device: {device}")
    logger.info(f"device: {device}")

if __name__ == "__main__":
    loadModel()