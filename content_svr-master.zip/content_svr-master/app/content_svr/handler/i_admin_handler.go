package handler

import (
	"content_svr/config"
	"content_svr/internal/ad_mng"
	"content_svr/internal/bttl_mng"
	"content_svr/internal/busi_comm/schema"
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/internal/game_mng"
	"content_svr/internal/im_mng"
	"content_svr/internal/money_task"
	"content_svr/internal/palace"
	"content_svr/internal/partner_mng"
	"content_svr/internal/pay_mng"
	"content_svr/internal/security_mng"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/internal/user_center_mng"
	"content_svr/internal/user_level_mng"
	"content_svr/internal/vip_mng"
	"content_svr/internal/wxreward"
	"content_svr/internal/zoo_game_mng"
	"content_svr/pub/decorate"
	"content_svr/pub/middleware"
	"content_svr/pub/validator"
	"github.com/gin-gonic/gin"
	"net/http"
)

type AdminHandler struct {
	ContentMng       content_mng.IContentMng
	UserLevMng       user_level_mng.IUserLevelMng
	SecurityMng      security_mng.ISecurityMng
	UserCenterMng    user_center_mng.IUserCenterMng
	GameMng          game_mng.IGameMng
	PayMng           pay_mng.IPayMng
	ImMng            im_mng.IIMMng
	Shumei           shumei_proxy.IShumeiProxy
	vipMng           *vip_mng.VipMng
	adMng            *ad_mng.ADMng
	PartnerMng       partner_mng.IPartnerMng
	bttlMng          *bttl_mng.BttlMng
	zooGameMng       *zoo_game_mng.ZooGameMng
	palace           *palace.Handler
	wxr              *wxreward.Handler
	wxrSvc           *wxreward.Service
	ulv2             *user_level_mng.UserLvlV2Handler
	ulv2comp         *user_level_mng.UserLvlV2Comp
	moneyTaskHandler *money_task.Handler
	moneySvc         *money_task.Service
	// todo fix
	dc data_cache.IDataCacheMng
}

func NewAdminHandler(
	iKeyWordMng content_mng.IContentMng,
	userLevMng user_level_mng.IUserLevelMng,
	mng security_mng.ISecurityMng,
	ucMng user_center_mng.IUserCenterMng,
	gameMng game_mng.IGameMng,
	payMng pay_mng.IPayMng,
	imMng im_mng.IIMMng,
	shumeiProxy shumei_proxy.IShumeiProxy,
	vipMng *vip_mng.VipMng,
	adMng *ad_mng.ADMng,
	partnerMng partner_mng.IPartnerMng,
	bttlMng *bttl_mng.BttlMng,
	zooGameMng *zoo_game_mng.ZooGameMng,
	palace *palace.Handler,
	wxr *wxreward.Handler,
	wxrSvc *wxreward.Service,
	ulv2 *user_level_mng.UserLvlV2Handler,
	ulv2comp *user_level_mng.UserLvlV2Comp,
	moneyTaskHandler *money_task.Handler,
	dc data_cache.IDataCacheMng,
	moneySvc *money_task.Service,
) *AdminHandler {

	return &AdminHandler{
		ContentMng:       iKeyWordMng,
		UserLevMng:       userLevMng,
		SecurityMng:      mng,
		UserCenterMng:    ucMng,
		GameMng:          gameMng,
		PayMng:           payMng,
		ImMng:            imMng,
		Shumei:           shumeiProxy,
		vipMng:           vipMng,
		adMng:            adMng,
		PartnerMng:       partnerMng,
		bttlMng:          bttlMng,
		zooGameMng:       zooGameMng,
		palace:           palace,
		wxr:              wxr,
		wxrSvc:           wxrSvc,
		ulv2:             ulv2,
		ulv2comp:         ulv2comp,
		dc:               dc,
		moneyTaskHandler: moneyTaskHandler,
		moneySvc:         moneySvc,
	}
}

func SetUrls(router *gin.Engine, adminHandler *AdminHandler, wares ...gin.HandlerFunc) {
	// wx verify
	router.Any("/MP_verify_VSdEjdIoFw2YN8tF.txt", func(c *gin.Context) {
		c.String(http.StatusOK, "VSdEjdIoFw2YN8tF")
	})

	//// 老接口
	baseAPI := router.Group("platform/")

	secretAPI := baseAPI.Group("secret/")
	{
		// 拉作品(首页分发接口)
		secretAPI.GET("bottleWorks/share",
			//validator.GenValidateHandler(schema.PersonalTalkCheckReqSchema),
			decorate.SerializeDecoratorCli(adminHandler.WorkidsGetshare))

		// 发布动态
		secretAPI.POST("chitchat/works",
			validator.GenValidateHandler(schema.PushChitchatReqSchema),
			decorate.SerializeDecoratorCli(adminHandler.PushChitchat))

		//获取未读消息数
		secretAPI.GET("talkMessage/unReadCount/v2",
			decorate.SerializeDecoratorCli(adminHandler.GetUnReadMsgCounts))

		// 拉未读消息列表
		secretAPI.GET("talkMessage/newMessage/v2",
			//validator.GenValidateHandler(schema.PersonalTalkCheckReqSchema),
			decorate.SerializeDecoratorCli(adminHandler.GetReplyMsg))

		// 拉取消息盒子-消息列表
		secretAPI.GET("talkGateWay/talkListByPage",
			decorate.SerializeDecoratorCli(adminHandler.GetWorkTalkList))

		// 来消息盒子中官方消息(未读消息数量及最后一条消息)
		secretAPI.GET("/notification/unread/quantity",
			decorate.SerializeDecoratorCli(adminHandler.GetOfficialNewMsg))

		// 发送消息(发私信)
		secretAPI.POST("talkMessage/v2/send",
			validator.GenValidateHandler(schema.SendMsgReqSchema),
			decorate.SerializeDecoratorCli(adminHandler.SendMsg))

		// 聊天状态
		secretAPI.POST("talkMessage/v2/status",
			decorate.SerializeDecoratorCli(adminHandler.TalkStatus))

		// 拉私聊消息详情
		secretAPI.GET("talkMessage/v2/listByUserByPage",
			decorate.SerializeDecoratorCli(adminHandler.GetTalkMessageDetail))

		// 与他人聊天时，获取私聊相关的配置内容
		secretAPI.GET("talkMessage/v2/config",
			decorate.SerializeDecoratorCli(adminHandler.GetTalkConfig))

		// 修改私聊配置信息(扩列)
		baseAPI.POST("api/talkMessage/set/config",
			decorate.SerializeDecoratorCli(adminHandler.SetTalkConfig))

		// todo by quding
		// 拉取私聊列表
		// 获取动态 header 接口

		// 个人主页接口 主态、客态
		secretAPI.POST("userCenter/follow", decorate.SerializeDecoratorCli(adminHandler.Follow))
		//拉黑
		secretAPI.PUT("user/addBlackList", decorate.SerializeDecoratorCli(adminHandler.AddBlackList))

		// 改造，消息已读接口

	}

	// 下发客户端配置参数 byquding
	baseAPI.GET("api/comm/get_app_config",
		decorate.SerializeDecoratorCli(adminHandler.GetAppConfig))

	baseAPI.GET("api/discovery/list",
		decorate.SerializeDecoratorCli(adminHandler.GetDiscoveryList))
	//h5新版发现页
	baseAPI.GET("api/v2/discovery/list",
		decorate.SerializeDecoratorCli(adminHandler.GetDiscoveryListV2))

	// 设置用户的星座生日
	baseAPI.POST("api/work/set_star_sign_birth",
		validator.GenValidateHandler(schema.SetStarSignBirthSchema),
		decorate.SerializeDecoratorCli(adminHandler.SetStarSignBirth))

	// 获取用户的星座运势
	baseAPI.GET("api/work/get_star_sign_birth",
		decorate.SerializeDecoratorCli(adminHandler.GetStarSignBirth))

	// 获取用户的星座运势
	baseAPI.GET("api/work/get_star_sign_info",
		decorate.SerializeDecoratorCli(adminHandler.GetStarSignInfo))

	// 最新动态信息
	baseAPI.GET("api/work/latest-work-info", decorate.Wrap(adminHandler.GetLatestWorkInfo))

	// 获取表情广场
	baseAPI.GET("api/meme/square", decorate.SerializeDecoratorCli(adminHandler.GetMemeSquare))
	// 举报表情
	baseAPI.POST("api/meme/report", decorate.SerializeDecoratorCli(adminHandler.MemeReport))

	// 名人堂
	baseAPI.GET("api/palace/records", decorate.Wrap(adminHandler.palace.ListRecords))

	wxrAPI := baseAPI.Group("api/wxreward")
	{
		wxrAPI.POST("/bind_reward", decorate.Wrap(adminHandler.wxr.BindReward))
		wxrAPI.POST("/lvl5_reward", decorate.Wrap(adminHandler.wxr.Lvl5Reward))
		wxrAPI.GET("/red_paper", decorate.Wrap(adminHandler.wxr.ListRedPaper))
		wxrAPI.POST("/withdraw_red_paper", decorate.Wrap(adminHandler.wxr.WithdrawRedPaper))
	}

	chitchatAPI := baseAPI.Group("api/chitchat")
	{
		chitchatAPI.GET("/pub_status", decorate.Wrap(adminHandler.GetPubWorkStatus))
	}

	// work 动态
	workAPI := baseAPI.Group("api/work/")
	{
		workAPI.POST("reset_exposure",
			decorate.SerializeDecoratorCli(adminHandler.ResetExposure))

	}

	// user
	userAPI := baseAPI.Group("api/user/")
	{
		// api/user/quick_login
		userAPI.POST("quick_login", decorate.SerializeDecoratorCli(adminHandler.QuickLogin))
		// api/user/realtime/create_room
		userAPI.GET("realtime/create_room",
			decorate.SerializeDecoratorCli(adminHandler.RmTimeoutWorks))

		// api/user/get_level  获取用户等级信息
		userAPI.GET("get_level",
			decorate.SerializeDecoratorCli(adminHandler.GetUserLevel))

		// api/user/level_info  获取等级信息
		userAPI.POST("level_info",
			decorate.SerializeDecoratorCli(adminHandler.GetLevelInfo))

		userAPI.GET("info", decorate.Wrap(adminHandler.GetUserInfo))
		userAPI.POST("edit", decorate.Wrap(adminHandler.EditUserInfo))

		// api/user/daily_sign		签到
		userAPI.GET("daily_sign",
			decorate.SerializeDecoratorCli(adminHandler.UserDailySign))

		// api/user/chitchat/confirm  核销激活码
		userAPI.GET("chitchat/confirm",
			decorate.SerializeDecoratorCli(adminHandler.UserChitChatConfirm))

		// api/user/chitchat/get	获取激活码卡片信息
		userAPI.GET("chitchat/get",
			decorate.SerializeDecoratorCli(adminHandler.GetchitchatInfo))

		// api/user/publish/status 检查发帖权限
		userAPI.GET("publish/status",
			decorate.SerializeDecoratorCli(adminHandler.GetPublishStatus))

		// 官方信息 @
		userAPI.POST("remind/official",
			decorate.SerializeDecoratorCli(adminHandler.GetRemindOfficialList))
		// 关注者信息 @  该接口废弃
		userAPI.POST("remind/mutual",
			decorate.SerializeDecoratorCli(adminHandler.GetRemindMutualList))
		//设置用户星标好友
		userAPI.POST("remind/star_target/set", decorate.SerializeDecoratorCli(adminHandler.SetRemindStarTarget))
		//获取星标好友列表
		userAPI.GET("remind/star_target/list", decorate.SerializeDecoratorCli(adminHandler.GetRemindStarTargetList))

		// 身份证实名
		userAPI.POST("real_name_authentication",
			decorate.SerializeDecoratorCli(adminHandler.RealNameAuthentication))
		// 检测是否实名
		userAPI.GET("check_real_name",
			decorate.SerializeDecoratorCli(adminHandler.CheckRealName))

		userAPI.GET("follow/recommend_users", decorate.Wrap(adminHandler.palace.ListRecommendUser))
		//批量关注
		userAPI.POST("follow/batch_follow", decorate.Wrap(adminHandler.BatchFollow))
		//关注列表
		userAPI.GET("follow/list", decorate.SerializeDecoratorCli(adminHandler.FollowList))
		//关注状态
		userAPI.GET("follow/stat", decorate.SerializeDecoratorCli(adminHandler.FollowStat))
		userAPI.POST("follow/v2/stat", decorate.SerializeDecoratorCli(adminHandler.FollowStatV2))
		//小红点
		userAPI.GET("follow/badge", decorate.SerializeDecoratorCli(adminHandler.FollowBadge))
		//设置用户备注
		userAPI.POST("remark_name", decorate.SerializeDecoratorCli(adminHandler.RemarkName))

		//绑定微信用户
		userAPI.POST("wechat/bind", decorate.SerializeDecoratorCli(adminHandler.BindWX))
		//提现基本信息
		userAPI.GET("withdraw/before", decorate.SerializeDecoratorCli(adminHandler.WithdrawBefore))
		//提现
		userAPI.POST("withDraw", decorate.SerializeDecoratorCli(adminHandler.Withdraw))

		//用户昵称查询
		userAPI.GET("search", decorate.SerializeDecoratorCli(adminHandler.UserSearch))

		//签到
		userAPI.POST("/daily/sign", decorate.SerializeDecoratorCli(adminHandler.DailySign))
		//获取签到加速码
		userAPI.GET("/speed_code/get", decorate.SerializeDecoratorCli(adminHandler.GetSpeedCode))
		//使用加速码
		userAPI.POST("/speed_code/usage", decorate.SerializeDecoratorCli(adminHandler.UsageSpeedCode))
		//校验加速码
		userAPI.GET("/speed_code/check", decorate.SerializeDecoratorCli(adminHandler.CheckSpeedCode))
		//加速码被使用列表
		userAPI.GET("/speed_code/used_list", decorate.SerializeDecoratorCli(adminHandler.UsedListSpeedCode))
		//等级信息
		userAPI.GET("/level/info", decorate.SerializeDecoratorCli(adminHandler.LevelInfo))
		//等级权益
		userAPI.GET("/level/rights", decorate.SerializeDecoratorCli(adminHandler.LevelRights))

		//用户动态过滤设置
		userAPI.POST("/work/setting", decorate.SerializeDecoratorCli(adminHandler.WorkSetting))

		//secret sports
		//获取当前用户的运动状态
		userAPI.POST("work/sport_status_query",
			decorate.SerializeDecoratorCli(adminHandler.QuerySportStatus))
		//计算步数应该分到的鱼干数
		userAPI.POST("sport_fish_for_step_nums_eval",
			decorate.SerializeDecoratorCli(adminHandler.EvalFishOnStepNums))
		//提交运动步数,包括更新提交
		userAPI.POST("sport_steps_push",
			decorate.SerializeDecoratorCli(adminHandler.PushSportSteps))
		//获取用户运动排行榜
		userAPI.POST("sport_ranker_pull",
			decorate.SerializeDecoratorCli(adminHandler.PullSportRanker))

		//work, comment status check
		userAPI.POST("res/status/check",
			decorate.SerializeDecoratorCli(adminHandler.CheckResStatus))
		//他人主页上发送私聊检查
		userAPI.POST("private_message/check",
			decorate.SerializeDecoratorCli(adminHandler.HomePagePrivateMessageCheckProc))
		//他人主页上发送私聊
		userAPI.POST("private_message/push",
			decorate.SerializeDecoratorCli(adminHandler.HomePagePrivateMessagePushProc))
		// 安全过滤-修改用户信息
		userAPI.POST("check_update_user_info",
			decorate.SerializeDecoratorCli(adminHandler.CheckUpdateUserInfo))

		//优质内容app卡片入口:
		userAPI.POST("work/kola_plan",
			decorate.SerializeDecoratorCli(adminHandler.KoLaPlanEntry))

		//app跳转页面后，页面请求优质内容
		userAPI.POST("work/kola_plan/detail",
			decorate.SerializeDecoratorCli(adminHandler.KoLaPlanDetail))

		//页面请求奖励详情
		userAPI.POST("work/kola_plan/award_detail",
			decorate.SerializeDecoratorCli(adminHandler.KoLaPlanAwardDetail))

		//可乐名人堂
		userAPI.POST("work/kola_plan/hall_of_fame",
			decorate.SerializeDecoratorCli(adminHandler.KoLaPlanHallOfFame))

		// 零钱计划
		userAPI.GET("money_plan", decorate.SerializeDecoratorCli(adminHandler.MoneyPlan))
		// 上报奖励信息
		userAPI.POST("reward", decorate.SerializeDecoratorCli(adminHandler.UploadReward))
	}

	userAPIV2 := userAPI.Group("v2")
	{
		userAPIV2.GET("/lvlup_status", decorate.Wrap(adminHandler.ulv2.GetUserLvlUpStatus))
		userAPIV2.POST("/user_lvlup", decorate.Wrap(adminHandler.ulv2.UserLvlUp))
		userAPIV2.POST("/checkin", decorate.Wrap(adminHandler.ulv2.UserCheckIn))
		userAPIV2.GET("/scode_checkin_status", decorate.Wrap(adminHandler.ulv2.GetUserSuperCodeCheckinStatus))
		userAPIV2.POST("/consume_scode", decorate.Wrap(adminHandler.ulv2.ConsumeSCode))
	}

	moneyTaskAPI := baseAPI.Group("api/money_task")
	{
		moneyTaskAPI.GET("/user_task_info", decorate.Wrap(adminHandler.moneyTaskHandler.GetUserTaskInfo))
		moneyTaskAPI.POST("/upload_view_work_cnt", decorate.Wrap(adminHandler.moneyTaskHandler.UploadViewWorkCnt))
	}

	// api/inner/audit/notify  审核通知过来的，严重违规需要降低用户等级。
	baseAPI.POST("api/inner/audit/notify",
		decorate.SerializeDecoratorCli(adminHandler.AuditNotify))
	baseAPI.POST("api/inner/check_phone",
		decorate.SerializeDecoratorCli(adminHandler.checkPhone))

	// 内容检查
	baseAPI.POST("api/check_content/txt", decorate.SerializeDecoratorCli(adminHandler.CheckTxtContent))
	baseAPI.POST("api/check_content/img", decorate.SerializeDecoratorCli(adminHandler.CheckImgContent))

	if config.ServerConfig.Env == "test" || true {
		// 内部调测接口或脚本
		//
		baseAPI.GET("debug/bottleWorks/rm_timeout_works",
			decorate.SerializeDecoratorCli(adminHandler.RmTimeoutWorks))

		// debug
		baseAPI.GET("debug/common_debug",
			decorate.SerializeDecoratorCli(adminHandler.Debug))

		baseAPI.GET("api/debug/clean_xingzuo_user_cache",
			decorate.SerializeDecoratorCli(adminHandler.CleanXingzuoUserCache))

		// 加入分发
		baseAPI.GET("api/debug/add_to_fenfa",
			decorate.SerializeDecoratorCli(adminHandler.DebugAddToDeliver))

		// 清理用户的每日打卡信息
		baseAPI.GET("api/debug/clear_user_daily_sign_cache",
			decorate.SerializeDecoratorCli(adminHandler.CleanSignCache))

		//
		baseAPI.POST("api/debug", decorate.SerializeDecoratorCli(adminHandler.DebugHandler))

		// 帖子评论设置开关 废弃，不再对外暴露 byquding
		//baseAPI.POST("api/user/work/comment_enable",
		//	decorate.SerializeDecoratorCli(adminHandler.SetWorkCommentStatus))
	}

	work := baseAPI.Group("api/user/work")
	{
		work.POST("work_like",
			decorate.SerializeDecoratorCli(adminHandler.LikeWork))
		//对帖子发起评论
		work.POST("comment_push",
			decorate.SerializeDecoratorCli(adminHandler.PushWorkComments))
		//删除评论记录
		work.POST("comment_delete",
			decorate.SerializeDecoratorCli(adminHandler.DeleteWorkComments))
		//拉取评论详情
		work.POST("comment_pull",
			decorate.SerializeDecoratorCli(adminHandler.PullWorkComments))
		work.POST("comment_pull/v2",
			decorate.SerializeDecoratorCli(adminHandler.PullWorkCommentsV2))
		//获取未读评论的帖子
		work.POST("unread_comment_work_pull",
			decorate.SerializeDecoratorCli(adminHandler.PullUnreadCommentWorks))
		//
		work.POST("comment_like",
			decorate.SerializeDecoratorCli(adminHandler.LikeWorkComments))
	}

	baseAPI.POST("api/upload/log",
		decorate.SerializeDecoratorCli(adminHandler.UploadLog))

	//广告相关
	adAPI := baseAPI.Group("api/ad", middleware.NoAuthMiddleware())
	{
		// 主动上报
		adAPI.POST("/behavior_upload/v2",
			decorate.SerializeDecoratorCli(adminHandler.AdBehaviorUploadV2))

		// 回调sdk
		adAPI.POST("/vivo/feedback", adminHandler.AdVivoFeedback)
		adAPI.POST("/vivo2/feedback", adminHandler.AdVivo2Feedback)
		adAPI.GET("/huawei/feedback", adminHandler.AdHuaweiFeedback)
		adAPI.GET("/oppo/feedback", adminHandler.AdOppoFeedback)
		adAPI.GET("/xiaomi/feedback", adminHandler.AdXiaomiFeedback)
		adAPI.GET("/baidu/feedback", adminHandler.AdBaiduFeedback)
		adAPI.GET("/gdt/feedback", adminHandler.AdGdtFeedback)
		adAPI.GET("/toutiao/feedback", adminHandler.AdToutiaoFeedback)
		adAPI.GET("/xingtu/feedback", adminHandler.AdXingtuFeedback)
		adAPI.GET("/kuaishou/feedback", adminHandler.AdKuaiShouFeedback)
		adAPI.GET("/wangyi/feedback", adminHandler.WangyiFeedback)
	}

	//游戏平台相关
	gameAPI := baseAPI.Group("api/game")
	{
		//认证授权
		gameAPI.POST("/auth", decorate.SerializeDecoratorCli(adminHandler.GameAuth))
		//预下单
		gameAPI.POST("/prepay", decorate.SerializeDecoratorCli(adminHandler.GamePreOrder))
		//订单详情
		gameAPI.POST("/order/get", decorate.SerializeDecoratorCli(adminHandler.GameGetOrderInfo))
		//微信订单详情
		gameAPI.GET("/order/wx/get", decorate.SerializeDecoratorCli(adminHandler.QueryOrderByOutTradeNo))
		//绑定游戏，生成appKey，appSecret
		gameAPI.POST("/bind", decorate.SerializeDecoratorCli(adminHandler.GameBind))
		//游戏列表
		gameAPI.GET("/list", decorate.SerializeDecoratorCli(adminHandler.GameList))
	}
	//微信支付回调
	baseAPI.POST("api/wechat/pay/notify", decorate.SerializeDecoratorCli(adminHandler.WechatPayNotify))
	//游戏第三方回调自测
	baseAPI.POST("api/game/notify_test", decorate.SerializeDecoratorCli(adminHandler.GameNotifyTest))

	//OPEN IM
	imAPI := baseAPI.Group("api/im")
	{
		// 同步业务通知
		imAPI.POST("/sync_biz_ntf", decorate.Wrap(adminHandler.SyncBizNtf))
		//用户token获取/注册
		imAPI.POST("/token", decorate.SerializeDecoratorCli(adminHandler.UserToken))
		//建群
		imAPI.POST("/group/create", decorate.SerializeDecoratorCli(adminHandler.GroupCreate))
		//邀请进群
		imAPI.POST("/group/invite", decorate.SerializeDecoratorCli(adminHandler.GroupInvite))
		//申请进群
		imAPI.POST("/group/join", decorate.SerializeDecoratorCli(adminHandler.GroupJoin))
		//进群申请处理
		imAPI.POST("/group/apply", decorate.SerializeDecoratorCli(adminHandler.GroupApplicationResponse))
		//踢出群
		imAPI.POST("/group/kick", decorate.SerializeDecoratorCli(adminHandler.GroupKick))
		//更新群信息
		imAPI.POST("/group/set", decorate.SerializeDecoratorCli(adminHandler.GroupSet))
		//群举报
		imAPI.POST("/group/report", decorate.SerializeDecoratorCli(adminHandler.GroupReport))
		//群解散
		imAPI.POST("/group/dismiss", decorate.SerializeDecoratorCli(adminHandler.GroupDismiss))
		//用户退出群
		imAPI.POST("/group/quit", decorate.SerializeDecoratorCli(adminHandler.GroupQuit))
		//群转让
		imAPI.POST("/group/transfer", decorate.SerializeDecoratorCli(adminHandler.GroupTransfer))
		//设置群员信息
		imAPI.POST("/group/set_member", decorate.SerializeDecoratorCli(adminHandler.GroupSetMemberInfo))
		//群状态
		imAPI.POST("/group/mix_info", decorate.SerializeDecoratorCli(adminHandler.GroupMixInfo))
		//批量群是否加入
		imAPI.POST("/group/batch_group_info", decorate.SerializeDecoratorCli(adminHandler.GroupBatchInfo))
		//群成员用户状态相关信息
		imAPI.POST("/group/member_ext_info", decorate.SerializeDecoratorCli(adminHandler.GroupMemberExtInfo))
		//Callback
		imAPI.POST("/callback", adminHandler.Callback)

		//同城群聊列表
		imAPI.GET("/group/intra_city/list", decorate.SerializeDecoratorCli(adminHandler.GroupIntraCityList))
		//同城群聊信息
		imAPI.GET("/group/intra_city/info", decorate.SerializeDecoratorCli(adminHandler.GroupIntraCityInfo))
		//同城群聊定位
		imAPI.GET("/group/intra_city/lbs", decorate.SerializeDecoratorCli(adminHandler.GroupIntraCityLbs))
		//同城群聊设置
		imAPI.POST("/group/intra_city/setting", decorate.SerializeDecoratorCli(adminHandler.GroupIntraCitySetting))
	}

	vipApi := baseAPI.Group("api/vip")
	{
		vipApi.GET("/rights_conf", decorate.SerializeDecoratorCli(adminHandler.GetVipRightsConf))
	}

	bttlApi := baseAPI.Group("api/bttl-lite")
	{
		bttlApi.GET("/discover", decorate.SerializeDecoratorCli(adminHandler.DiscoverBttl))
		bttlApi.GET("/bttls", decorate.SerializeDecoratorCli(adminHandler.ListBttl))
		bttlApi.POST("/bttls", decorate.SerializeDecoratorCli(adminHandler.CreateBttl))
		bttlApi.POST("/bttls/:bttlID/pick", decorate.SerializeDecoratorCli(adminHandler.PickBttl))
		bttlApi.POST("/bttls/:bttlID/throwback", decorate.SerializeDecoratorCli(adminHandler.ThrowbackBttl))
		bttlApi.POST("/bttls/:bttlID/reply", decorate.SerializeDecoratorCli(adminHandler.ReplyBttl))
		bttlApi.GET("/status", decorate.SerializeDecoratorCli(adminHandler.BttlStatus))
		bttlApi.POST("/pick_ad_upload", decorate.SerializeDecoratorCli(adminHandler.PickBttlADUpload))

	}

	// 系统内部调用接口
	// todo 不对外 & 加签名校验
	baseAPI.POST("api/internal/im/sync_user_info", decorate.SerializeDecoratorCli(adminHandler.SyncIMUserInfo))

	// 广告
	adApi := baseAPI.Group("api/ad")
	{
		adApi.POST("/talk/csjupload", decorate.SerializeDecoratorCli(adminHandler.CSJTalkADUpload))
		adApi.GET("/app_ad", decorate.SerializeDecoratorCli(adminHandler.GetAppAD))
	}

	//合伙人
	partnerApi := baseAPI.Group("api/partner")
	{
		partnerApi.GET("/info", decorate.SerializeDecoratorCli(adminHandler.GetPartnerInfo))
		partnerApi.POST("/use_invite_code", decorate.SerializeDecoratorCli(adminHandler.UseInviteCode))
	}

	// 提供给 adjust 平台的回调获取用户shu
	adjustAPI := baseAPI.Group("api/adjust", middleware.NoAuthMiddleware())
	{
		adjustAPI.GET("/registerCallback", decorate.SerializeDecoratorCli(adminHandler.AdjustRegisterCallback))
		//adjustAPI.GET("/loginCallback", decorate.SerializeDecoratorCli(adminHandler.AdjustLoginCallback))
		adjustAPI.GET("/payCallback", decorate.SerializeDecoratorCli(adminHandler.AdjustPayCallback))
	}
}
