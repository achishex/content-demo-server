package data_cache

import (
	"content_svr/pub/utils"
	"context"
	rdsV8 "github.com/go-redis/redis/v8"
	"time"
)

// 检查是不是在内容分发池。  userid ~ workid:times, workid:times    times记录workid被消费了几次。
func (p *DataCacheMng) CheckUserReadHistoryPoolR(ctx context.Context, workid string, curUserIdUk string) (bool, int64, error) {
	redisKey, _ := getKeyUserReadHistoryPool(curUserIdUk)          // workid~calcScore
	tsMs, err := p.RedisCli.ZScore(ctx, redisKey, workid).Result() //返回在range的idx位置
	if err != nil {
		return false, int64(tsMs), err
	} else {
		return true, int64(tsMs), err
	}
}

// 检查是不是在内容分发池。
func (p *DataCacheMng) SetUserReadHistoryPoolR(ctx context.Context, workid string, curUserIdUk string) error {
	redisKey, expireTime := getKeyUserReadHistoryPool(curUserIdUk) // workid~calcScore
	_, err := p.RedisCli.ZAdd(ctx, redisKey, &rdsV8.Z{Score: float64(utils.GetCurTsMs()), Member: workid}).Result()
	p.RedisCli.Expire(ctx, redisKey, time.Duration(expireTime)*time.Second)
	return err
}
