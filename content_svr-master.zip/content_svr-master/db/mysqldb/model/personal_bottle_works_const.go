package model

const (
	_             = iota
	WorkTypeImage // 图片
	WorkTypeVideo // 视频
	WorkTypeText  // 文字
)

// 作品展示范围 1全部可见 2全部不可见
const (
	ShowScopeAll  = 1
	ShowScopeSelf = 2
)
