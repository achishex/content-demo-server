package content_mng

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/pub/logger"
	"context"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"strconv"
)

type ITalkMessageDetail interface {
	CheckReqUser(ctx context.Context) error
	DoBasicLogic(ctx context.Context) error
	QueryTalkMessageTotal(ctx context.Context) error
	QueryTalkMessageDetailList(ctx context.Context) error
	//get
	GetTalkMessageDetail(ctx context.Context) []*pbapi.PersonalTalkMessageRecordMgDbModel
}

func NewTalkMessageDetailProc(impl *ContentMng, header *pbapi.HttpHeaderInfo, req *pbapi.TalkMessageSecurityReq, loginUserInfo *data_cache.UserInfoLocal) *TalkMessageDetailProc {
	ret := &TalkMessageDetailProc{
		impl:        impl,
		header:      header,
		req:         req,
		curUserInfo: loginUserInfo,
		toUseInfo:   nil,
		openId:      "",
		userLock:    0,
		workId:      req.GetWorkId(),
	}
	ret.bbMachineIds = GetBBMachineIds()
	return ret
}

type TalkMessageDetailProc struct {
	impl         *ContentMng
	header       *pbapi.HttpHeaderInfo
	req          *pbapi.TalkMessageSecurityReq
	curUserInfo  *data_cache.UserInfoLocal
	bbMachineIds map[int64]bool
	// 中间状态:
	toUseInfo *data_cache.UserInfoLocal
	openId    string
	userLock  int32
	workId    int64
	sessionId int64
	//
	page          int32
	rows          int32
	total         int64
	recordMsgList []*pbapi.PersonalTalkMessageRecordMgDbModel
	totalList     []*pbapi.PersonalTalkMessageTotalMgDbModel
}

func (p *TalkMessageDetailProc) QueryTalkMessageDetailList(ctx context.Context) error {
	var condOr []bson.M
	condOr = append(condOr, bson.M{
		"toUserId":   p.curUserInfo.UserInfoDbModel.GetUserId(),
		"fromUserId": p.toUseInfo.UserInfoDbModel.GetUserId(),
		"status":     1,
	}, bson.M{
		"fromUserId": p.curUserInfo.UserInfoDbModel.GetUserId(),
		"toUserId":   p.toUseInfo.UserInfoDbModel.GetUserId(),
		"status":     1,
	})

	var condAnd []bson.M
	condAnd = append(condAnd, bson.M{
		"workId": p.workId,
	})
	appTypeStr := p.header.GetApptype()
	versionCodeInt, _ := strconv.Atoi(p.header.GetVersioncode())

	if appTypeStr == cm_const.AppTypeAppletQq || appTypeStr == cm_const.AppTypeAppletWx {
		if versionCodeInt < 103019 {
			condAnd = append(condAnd, bson.M{
				"messageType": bson.M{
					"$nin": []int64{6, 8},
				},
			})
		} else if versionCodeInt < 103053 {
			condAnd = append(condAnd, bson.M{
				"messageType": bson.M{
					"$ne": 8,
				},
			})
		}
	} else {
		if versionCodeInt < 1100101 {
			condAnd = append(condAnd, bson.M{
				"messageType": bson.M{
					"$nin": []int64{9, 10, 11},
				},
			})
		} else if versionCodeInt < 2000001 {
			condAnd = append(condAnd, bson.M{
				"messageType": bson.M{
					"$nin": []int64{10, 11},
				},
			})
		}
		//else if versionCodeInt < 2040001 {
		//	condAnd = append(condAnd, bson.M{
		//		"messageType": bson.M{
		//			"$nin": []int64{12},
		//		},
		//	})
		//}
	}

	runFilter := bson.M{
		"$or":  condOr,
		"$and": condAnd,
	}

	sortField := map[string]int32{
		"createTime": const_busi.SortTypeDesc,
	}
	skips := (p.req.GetPage() - 1) * p.req.GetRows()
	limits := p.req.GetRows()

	tmpMsgRecordRet, total, err := p.impl.DataCache.GetImpl().PersonalTalkMessageRecordMgDbModel.ListByCondWithSort(ctx, runFilter, sortField, skips, limits)
	if err != nil {
		logger.Errorf(ctx, "query no record msg from tab fail, err: %v", err)
		return err
	}
	if len(tmpMsgRecordRet) <= 0 {
		logger.Infof(ctx, "not find item for userId: %v", p.curUserInfo.UserInfoDbModel.GetUserId())
		return nil
	}
	p.recordMsgList = tmpMsgRecordRet
	p.total = total
	return nil
}
func (p *TalkMessageDetailProc) QueryTalkMessageTotal(ctx context.Context) error {
	workIdCondAnd := bson.M{}

	workIdCondAnd["workId"] = p.workId
	//
	orBsonMs := []bson.M{}
	toWindowsCondOr := bson.M{
		"toUserId":   p.curUserInfo.UserInfoDbModel.GetUserId(),
		"fromUserId": p.toUseInfo.UserInfoDbModel.GetUserId(),
	}
	fromWindowsCondOr := bson.M{
		"fromUserId": p.curUserInfo.UserInfoDbModel.GetUserId(),
		"toUserId":   p.toUseInfo.UserInfoDbModel.GetUserId(),
	}
	orBsonMs = append(orBsonMs, toWindowsCondOr, fromWindowsCondOr)

	runFilter := bson.M{
		"$or":  orBsonMs,
		"$and": []bson.M{workIdCondAnd},
	}

	tmpMsgTotalQueryRet, err := p.impl.DataCache.GetImpl().PersonalTalkMessageTotalMgDbModel.FindItemsWithComplexConds(ctx, runFilter, nil, 0, 0)
	if err != nil {
		logger.Errorf(ctx, "query message total fail, err: %v", err)
		return err
	}
	if len(tmpMsgTotalQueryRet) <= 0 {
		logger.Infof(ctx, "not find item for userId: %v", p.curUserInfo.UserInfoDbModel.GetUserId())
		return nil
	}
	oneTalkTotalMsg := tmpMsgTotalQueryRet[0]
	if oneTalkTotalMsg == nil {
		return nil
	}
	sessionId := int64(oneTalkTotalMsg.GetId())
	defer func(id *int64) {
		p.sessionId = *id
		p.totalList = tmpMsgTotalQueryRet
	}(&sessionId)

	if oneTalkTotalMsg.GetFromUserId() != p.curUserInfo.UserInfoDbModel.GetUserId() {
		return nil
	}
	queryCondAnd := bson.M{
		"toUserId":   p.curUserInfo.UserInfoDbModel.GetUserId(),
		"fromUserId": oneTalkTotalMsg.GetToUserId(),
		"status":     1,
		"workId":     p.workId,
	}
	toTotalMsg, err := p.impl.DataCache.GetImpl().PersonalTalkMessageTotalMgDbModel.FindItemsWithComplexConds(ctx, queryCondAnd, nil, 0, 1)
	if err == nil && len(toTotalMsg) > 0 && toTotalMsg[0] != nil {
		sessionId = toTotalMsg[0].GetId()
	}
	return nil
}
func (p *TalkMessageDetailProc) CheckReqUser(ctx context.Context) error {
	toUserInfo, err := p.impl.GetUserInfo(ctx, p.req.GetUserId())
	if err != nil || toUserInfo == nil || toUserInfo.UserInfoDbModel.GetStatus() == const_busi.UserUnRegister {
		logger.Errorf(ctx, "to req user: %d no exit", p.req.GetUserId())
		return errorcode.ACCOUNT_CLOSED
	}
	p.toUseInfo = toUserInfo

	if p.toUseInfo.UserInfoDbModel.GetWorksLock() == 1 {
		redisKey := "soul_soup:" + "userModuleBlock" + ":" + strconv.FormatInt(p.req.GetUserId(), 10) + ":1" + ":2"
		if ret, err := p.impl.DataCache.GetImpl().RedisCli.PTTL(ctx, redisKey).Result(); err == nil && ret > -2 {
			toUserInfo.UserInfoDbModel.WorksLock = proto.Int32(2)
		}
	} else {
		p.userLock = 1
	}
	if p.toUseInfo.UserInfoDbModel.GetCommentLock() == 1 {
		redisKey := "soul_soup:" + "userModuleBlock" + ":" + strconv.FormatInt(p.req.GetUserId(), 10) + ":1" + ":3"
		if ret, err := p.impl.DataCache.GetImpl().RedisCli.PTTL(ctx, redisKey).Result(); err == nil && ret > -2 {
			toUserInfo.UserInfoDbModel.CommentLock = proto.Int32(2)
		}
	} else {
		p.userLock = 1
	}
	return nil
}

func (p *TalkMessageDetailProc) DoBasicLogic(ctx context.Context) error {
	//get openId:
	toUserId := p.toUseInfo.UserInfoDbModel.GetUserId()
	appFlag := cm_const.AppNameFlagDict[p.header.GetAppname()]
	appTypeReq := cm_const.AppTypeDict[p.header.GetApptype()]
	if appTypeReq == 0 {
		appTypeReq = cm_const.AppTypeDict[cm_const.AppTypeAppletQq]
	}
	//
	openType := int32(cm_const.ThirdSystem)
	switch appTypeReq {
	case 4:
		openType = cm_const.ThirdSystem
	case 3:
		openType = cm_const.ThirdWX
	case 7:
		openType = cm_const.ThirdQuickApp
	default:
		openType = cm_const.ThirdSystem
	}
	//get from cache, key: cache:userInfo:hash: + userId
	cond := map[string]interface{}{
		"user_id":   toUserId,
		"app_flag":  appFlag,
		"open_type": openType,
		"status":    1,
	}
	ret, err := p.impl.DataCache.GetImpl().OpenUserModel.ListItemsByCondition(ctx, cond, 1, 1)
	if err != nil || len(ret) <= 0 || ret[0] == nil {
		if err != nil {
			logger.Errorf(ctx, "not get openid for user, cnd: %#v", cond)
		}
	} else {
		p.openId = ret[0].GetOpenid()
	}
	mutual := p.impl.DataCache.GetImpl().GetUserFollowMgDBLd(ctx, p.curUserInfo.UserInfoDbModel.GetUserId(), p.toUseInfo.UserInfoDbModel.GetUserId())
	if p.req.WorkId <= 0 || mutual == 1 {
		p.workId = -1
	}

	if p.req.GetPage() <= 0 {
		p.req.Page = 1
	}
	if p.req.GetRows() <= 0 {
		p.req.Rows = 20
	}
	return nil
}
func (p *TalkMessageDetailProc) GetTalkMessageDetail(ctx context.Context) []*pbapi.PersonalTalkMessageRecordMgDbModel {
	return p.recordMsgList
}

// //
type ITalkMsgDetailPackage interface {
	HistoryAppVersionFill(ctx context.Context, item *pbapi.TalkMessageSecurityDetail) error
	CommonAppVersionFill(ctx context.Context, item *pbapi.TalkMessageSecurityDetail, record *pbapi.PersonalTalkMessageRecordMgDbModel) error
	PackageSessionInfo(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.TalkMessageSecurityResponse, error)
	UpdateReadStatusDone(ctx context.Context, response *pbapi.TalkMessageSecurityResponse) error
	CalcPageSize(ctx context.Context, talkMsgRet *pbapi.TalkMessageSecurityResponse, req *pbapi.TalkMessageSecurityReq) error
}

func NewTalkMsgDetailRsp(messageProcessHandle *TalkMessageDetailProc) ITalkMsgDetailPackage {
	return &TalkMessageDetailPackage{
		detailProcHandle: messageProcessHandle,
	}
}

type TalkMessageDetailPackage struct {
	detailProcHandle *TalkMessageDetailProc
}

func (p *TalkMessageDetailPackage) UpdateReadStatusDone(ctx context.Context, response *pbapi.TalkMessageSecurityResponse) error {
	if response == nil || len(response.List) <= 0 {
		return nil
	}
	for k, _ := range p.detailProcHandle.totalList {
		totalMsgOne := p.detailProcHandle.totalList[k]
		if totalMsgOne == nil {
			continue
		}
		//

		if totalMsgOne.GetToUserId() == p.detailProcHandle.curUserInfo.UserInfoDbModel.GetUserId() &&
			totalMsgOne.GetLastMessageId() != -1 {
			//
			updateVal := map[string]interface{}{}
			updateVal["unReadCount"] = 0
			err := p.detailProcHandle.impl.DataCache.GetImpl().PersonalTalkMessageTotalMgDbModel.UpdateDictById(ctx, totalMsgOne.GetId(), updateVal, nil)
			if err != nil {
				logger.Errorf(ctx, "update tab: personalTalkMessageTotal unReadCount to 0 fail, err: %v", err)
			}
			//
			recordUpdateCond := bson.M{
				"fromUserId": p.detailProcHandle.req.GetUserId(),
				"toUserId":   p.detailProcHandle.curUserInfo.UserInfoDbModel.GetUserId(),
				"modeType":   totalMsgOne.GetModeType(),
				"read":       0,
				"status":     1,
			}
			if totalMsgOne.WorkId != nil {
				recordUpdateCond["workId"] = totalMsgOne.GetWorkId()
			} else {
				//TODO:
			}
			recordUpdateValue := map[string]interface{}{
				"read": 1,
			}
			err = p.detailProcHandle.impl.DataCache.GetImpl().PersonalTalkMessageRecordMgDbModel.UpdateDictByCond(ctx, recordUpdateCond, recordUpdateValue)
			if err != nil {
				logger.Errorf(ctx, "update personalTalkMessageRecord read from 0 to 1 fail, err: %v", err)
			}
		}
	}
	return nil
}
func (p *TalkMessageDetailPackage) HistoryAppVersionFill(ctx context.Context, item *pbapi.TalkMessageSecurityDetail) error {
	item.MessageType = 1
	item.Content = "ta在动态/评论中@了你，当前版本无法查看"
	return nil
}

func (p *TalkMessageDetailPackage) CommonAppVersionFill(ctx context.Context, item *pbapi.TalkMessageSecurityDetail, record *pbapi.PersonalTalkMessageRecordMgDbModel) error {
	if record.GetMessageWorkId() <= 0 {
		return nil
	}
	switch item.GetMessageType() {
	case const_busi.MutualNoticeMsgType: // 互爪的动态消息
		workInfo, err := QueryWorkInfoOnTalkMessage(ctx, record.GetMessageWorkId(), p.detailProcHandle.impl)
		if err == nil {
			item.Work = workInfo
		}
	case const_busi.MutualWorkMsgType, const_busi.MutualCommentMsgType: //动态@, //评论@
		eqConds := map[string]interface{}{
			"_id": record.GetMessageWorkId(),
		}
		remindDetails, err := p.detailProcHandle.impl.DataCache.GetImpl().UserRemindDetail.GetRemindDetailByConds(ctx, eqConds, nil, nil, nil, 1)
		if err == nil && len(remindDetails) > 0 {
			item.Remind = remindDetails[0]
		}
		if record.GetMessageType() == const_busi.MutualWorkMsgType && item.Remind != nil { //动态@,
			workInfo, err := QueryWorkInfoOnTalkMessage(ctx, item.Remind.GetWorkId(), p.detailProcHandle.impl)
			if err == nil {
				item.Work = workInfo
			}
		}
	case int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply):
		userInfo, commentInfoDetail, content, _ := PackageReplyCommentMsg(ctx, p.detailProcHandle.impl, record.GetMessageWorkId()) // 回复的评论详情。
		item.ReplyCommentUser = userInfo
		item.ReplyCommentId = record.GetMessageWorkId()

		if commentInfoDetail != nil {
			item.WorkId = commentInfoDetail.GetWorkId()
			item.CommentId = commentInfoDetail.GetId() //
			item.Content = content
		}
		//和websocket 协议保持一致的字段
		item.Reply = &pbapi.CommentReply{
			UserInfo: &pbapi.UserInfo{
				UserId:   userInfo.GetUserId(),
				NickName: userInfo.GetNickName(),
			},
			Comment: &pbapi.Comment{
				Id: item.ReplyCommentId,
			},
			Work: &pbapi.Work{
				Id: item.WorkId,
			},
		}
	}
	return nil
}
func (p *TalkMessageDetailPackage) processWorkOnPlatform(ctx context.Context, item *pbapi.TalkMessageSecurityDetail) error {
	p.detailProcHandle.impl.DataCache.GetWorkInfoLocal(ctx, item.GetWorkId(), false)
	workInfo, err := p.detailProcHandle.impl.DataCache.GetWorkInfoLocal(ctx, item.GetWorkId(), false)
	if err != nil {
		logger.Errorf(ctx, "get work info fail for workid: %v", item.GetWorkId())
		return nil
	}
	if workInfo == nil {
		item.Deleted = 1
	}

	item.WorkType = workInfo.WorkInfoDbModel.GetType()
	if workInfo.WorkInfoDbModel.GetType() == 1 || workInfo.WorkInfoDbModel.GetType() == 2 {
		objsMp, err := p.detailProcHandle.impl.DataCache.GetImpl().WorkObjectAttrModel.DictByWorkIds(ctx, []int64{item.GetWorkId()})
		if err == nil && len(objsMp) > 0 {
			if objs, ok := objsMp[item.GetWorkId()]; ok {
				if len(objs) > 0 {
					item.WorkHigh = objs[0].GetHigh()
					item.ObjectId = objs[0].GetObjectId()
					item.Thumbnail = objs[0].GetThumbnail()
				}
			}
		}
	}
	if workInfo.WorkInfoDbModel.GetStatus() == 0 {
		item.Deleted = 1
	}
	return nil
}

func checkNeedProcessMsgType(msgType int32) bool {
	if msgType != const_busi.MutualNoticeMsgType && msgType != const_busi.MutualWorkMsgType &&
		msgType != const_busi.MutualCommentMsgType && msgType != int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply) {
		return false
	}
	return true
}

func isHistoryAppVersion(versionCode string, appType string, msgType int32) bool {
	versionCodeInt, err := strconv.Atoi(versionCode)
	if err != nil {
		versionCodeInt = 0
	}
	//if msgType == int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply) && (appType == cm_const.AppTypeAppletQq || appType == cm_const.AppTypeAppletWx || versionCodeInt < 2040001) {
	//	return true
	//}
	if appType == cm_const.AppTypeAppletQq || appType == cm_const.AppTypeAppletWx || versionCodeInt < 2000001 {
		return true
	}
	return false
}
func (p *TalkMessageDetailPackage) PackageSessionInfo(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.TalkMessageSecurityResponse, error) {
	if len(p.detailProcHandle.recordMsgList) <= 0 {
		return nil, nil
	}
	var retResponse *pbapi.TalkMessageSecurityResponse
	var response []*pbapi.TalkMessageSecurityDetail
	for k, _ := range p.detailProcHandle.recordMsgList {
		record := p.detailProcHandle.recordMsgList[k]
		if record == nil {
			continue
		}
		messageType := int32(1)

		if record.MessageType != nil {
			messageType = record.GetMessageType()
		}
		if messageType == 4 && record.GetFromUserId() == p.detailProcHandle.curUserInfo.UserInfoDbModel.GetUserId() {
			continue
		}
		if messageType == 8 && record.GetToUserId() == p.detailProcHandle.curUserInfo.UserInfoDbModel.GetUserId() {
			continue
		}
		whetherSend := int32(0)
		//if record.GetFromUserId() == p.detailProcHandle.toUseInfo.UserInfoDbModel.GetUserId() {
		if record.GetFromUserId() == p.detailProcHandle.curUserInfo.UserInfoDbModel.GetUserId() {
			whetherSend = 1
		}
		workFlag := int32(0)
		if p.detailProcHandle.workId != -1 && p.detailProcHandle.workId != 100 {
			workFlag = record.GetWorkFlag()
		}
		item := &pbapi.TalkMessageSecurityDetail{
			OpenId:        p.detailProcHandle.openId,
			UserLock:      p.detailProcHandle.userLock,
			CommentLock:   p.detailProcHandle.toUseInfo.UserInfoDbModel.GetCommentLock(),
			WorksLock:     p.detailProcHandle.toUseInfo.UserInfoDbModel.GetWorksLock(),
			Content:       record.GetContent(),
			FromUserId:    record.GetFromUserId(),
			Id:            record.GetId(),
			SendTime:      record.GetCreateTime(),
			ToUserId:      record.GetToUserId(),
			WhetherSend:   whetherSend,
			High:          record.GetHigh(),
			ObjectId:      record.GetObjectId(),
			MessageType:   record.GetMessageType(),
			Width:         record.GetWidth(),
			Duration:      record.GetDuration(),
			WorkFlag:      workFlag,
			SessionId:     p.detailProcHandle.sessionId,
			RecallMsgId:   record.GetRecallMsgId(),
			MemeId:        record.GetMemeId(),
			Read:          record.GetRead(),
			Province:      record.GetProvince(),
			City:          record.GetCity(),
			Latitude:      record.GetLatitude(),
			Longitude:     record.GetLongitude(),
			WorkId:        p.detailProcHandle.workId,
			Title:         record.GetTitle(),
			IconUrl:       record.GetIconUrl(),
			BackgroundUrl: record.GetBackgroundUrl(),
		}
		if record.RecallMsgId != nil {
			item.RecallFlag = 1
		}

		if item.GetWorkFlag() == 1 && item.GetWorkId() > 100000 {
			if err := p.processWorkOnPlatform(ctx, item); err != nil {
				logger.Errorf(ctx, "get work info fail, err: %v", err)
				continue
			}
		}
		//
		if checkNeedProcessMsgType(messageType) {
			if isHistoryAppVersion(p.detailProcHandle.header.GetVersioncode(), p.detailProcHandle.header.GetApptype(), messageType) {
				p.HistoryAppVersionFill(ctx, item)
			} else {
				p.CommonAppVersionFill(ctx, item, record)
			}
		}
		response = append(response, item)
	}
	if retResponse == nil {
		retResponse = new(pbapi.TalkMessageSecurityResponse)
	}
	retResponse.List = response
	return retResponse, nil
}

func (p *TalkMessageDetailPackage) CalcPageSize(ctx context.Context, talkMsgRet *pbapi.TalkMessageSecurityResponse, req *pbapi.TalkMessageSecurityReq) error {
	talkMsgRet.CurrentPage = req.GetPage()
	talkMsgRet.Total = p.detailProcHandle.total

	remainder := talkMsgRet.Total % int64(req.GetRows())
	pages := talkMsgRet.Total / int64(req.GetRows())
	if remainder != 0 && talkMsgRet.Total > 0 {
		pages++
	}
	talkMsgRet.Pages = int32(pages)
	return nil
}

// ///
func (p *ContentMng) UpdateUnReadMessageNums(ctx context.Context, req *pbapi.TalkMessageSecurityReq, curUserId int64) error {
	//personal_card_message_queue
	uniqueId := genUniqueId(req.GetUserId(), curUserId, req.GetWorkId(), 0)
	err := p.DataCache.GetImpl().PersonalCardMessageQueueDbModel.DeleteItemByGroupId(ctx, uniqueId, curUserId)
	if err != nil {
		logger.Errorf(ctx, "del item form personal_card_message_queue fail, err: %v", err)
		return err
	}
	logger.Infof(ctx, "del item from personal_card_message_queue, uniqueId: %v, userId: %v", uniqueId, curUserId)
	return nil
}
func (p *ContentMng) GetTalkMessageDetailByUser(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.TalkMessageSecurityReq) (*pbapi.TalkMessageSecurityResponse, error) {
	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil || loginUserInfo == nil || loginUserInfo.UserInfoDbModel.GetUserId() <= 0 {
		logger.Errorf(ctx, "not login in detail talk message")
		return nil, errorcode.MIDAS_LOGIN_ERROR
	}

	talkMsgDetailHandler := NewTalkMessageDetailProc(p, header, req, loginUserInfo)
	//
	if err := talkMsgDetailHandler.CheckReqUser(ctx); err != nil {
		return nil, err
	}
	if err := talkMsgDetailHandler.DoBasicLogic(ctx); err != nil {
		return nil, err
	}
	if err := talkMsgDetailHandler.QueryTalkMessageTotal(ctx); err != nil {
		return nil, err
	}
	if err := talkMsgDetailHandler.QueryTalkMessageDetailList(ctx); err != nil {
		return nil, err
	}
	handlerProc := NewTalkMsgDetailRsp(talkMsgDetailHandler)
	ret, err := handlerProc.PackageSessionInfo(ctx, header)
	if err != nil || ret == nil {
		logger.Errorf(ctx, "package message record.")
		return &pbapi.TalkMessageSecurityResponse{}, nil
	}
	handlerProc.UpdateReadStatusDone(ctx, ret)
	handlerProc.CalcPageSize(ctx, ret, req)
	p.UpdateUnReadMessageNums(ctx, req, loginUserInfo.UserInfoDbModel.GetUserId())
	return ret, nil
}
