package robot

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mongodb/model"
	"context"
	"fmt"
	"github.com/jinzhu/copier"
	"go.mongodb.org/mongo-driver/mongo"
	"gorm.io/gorm"
	"sync"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewCreateLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateLogic {
	return &CreateLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

var createLock sync.RWMutex

func (l *CreateLogic) Create(req *types.RobotCreateReq) (resp *types.RobotCreateResp, err error) {
	createLock.Lock()
	defer createLock.Unlock()
	robot := &model.MzRobot{}
	err = copier.Copy(robot, req)
	if err != nil {
		return nil, err
	}

	infoByUserId, err := l.svcCtx.ManagerDB.UserInfo.FindByUserId(l.ctx, robot.UserId)
	if err == gorm.ErrRecordNotFound {
		return nil, xerr.UserInfoNoFound
	}
	if err != nil {
		return nil, err
	}
	newInfoNickName, err := l.svcCtx.ManagerDB.SecretUserExtInfo.FindOne(l.ctx, map[string]interface{}{"nickName": robot.Name})
	if err != nil && err != xerr.DbNotFound {
		return nil, err
	}
	if newInfoNickName != nil && infoByUserId != nil && newInfoNickName.NickName != infoByUserId.NickName {
		return nil, xerr.UserInfoNickNameError
	}

	number, ok, err := l.svcCtx.ManagerDB.MzRobotMng.CheckArea(l.ctx, robot.TimePartStart, robot.TimePartEnd, robot.CommentIndex)
	if err != nil {
		return nil, err
	}
	if ok {
		return nil, xerr.DbTimeOverlapError.SetMsg(fmt.Sprintf("已与序号为%d的机器人生效时间重叠，请修改后保存", number))
	}

	now := time.Now().UnixMilli()
	if now >= robot.TimePartEnd {
		robot.Status = false
	}
	robot.UpdateAt = time.Now().UnixMilli()
	err = l.svcCtx.ManagerDB.MzRobotMng.Create(l.ctx, robot)
	switch {
	case mongo.IsDuplicateKeyError(err):
		return nil, xerr.DbNoDuplicateUpsert.SetMsg("comment_index 不允许重复")
	case err != nil:
		return nil, err
	}

	if err := l.svcCtx.ManagerDB.UpdateAllRobotByUserId(l.ctx, robot); err != nil {
		return nil, err
	}

	err = l.svcCtx.ManagerDB.UserInfo.UpdateHeaderAndNickName(l.ctx, robot.UserId, robot.Header, robot.Name)
	if err != nil {
		return nil, err
	}

	monitorServe.registerWorker(newWorker(robot))

	return
}
