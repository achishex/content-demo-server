package report

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/app/maozhua_admin_svr/common/xconst"
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/app/maozhua_admin_svr/common/xhttp"
	"content_svr/db/mongodb/model"
	"content_svr/pub/utils"
	"context"
	"encoding/json"
	"go.mongodb.org/mongo-driver/bson"
	"net/url"
	"time"

	"github.com/zeromicro/go-zero/core/logx"
)

type AuditReportLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewAuditReportLogic(ctx context.Context, svcCtx *svc.ServiceContext) *AuditReportLogic {
	return &AuditReportLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

/*
1 不处罚
2 关小黑屋1天，不降级
3 关小黑屋3天，不降级
4 关小黑屋3天，降1级
5 关小黑屋3天，降为0级
6 关小黑屋10年，降为0级
7 永久封禁
*/
const (
	_ int64 = iota

	threeDayBlackHouseAndUnLevel     = 2 //      【中等处罚：关小黑屋3天并降1级】
	blockUser                        = 3 // 		永久封禁用户
	noPunish                         = 4 // 		不处罚
	threeDayBlackHouseAndUnLevelZero = 5 //      【严重处罚：关小黑屋3天，并降为0级】

	oneDayBlackHouse   = 11 //      【轻度处罚：关小黑屋1天】
	threeDayBlackHouse = 12 //      【轻度处罚：关小黑屋3天】
)

func (l *AuditReportLogic) AuditReport(req *types.AuditReportReq) (resp *types.AuditReportResp, err error) {
	report, err := l.svcCtx.ManagerDB.SecretReport.FindById(l.ctx, req.ReportId)
	if err != nil {
		return nil, err
	}

	if report.VerifyStatus != 0 {
		return nil, xerr.ReportPunishDuplicateError
	}

	now := time.Now()
	var endTime int64
	switch req.Status {
	case noPunish:
		// 不处罚
	case oneDayBlackHouse:
		endTime = now.Add(xconst.Day).UnixMilli()
	case threeDayBlackHouse:
		endTime = now.Add(xconst.Day * 3).UnixMilli()
	case threeDayBlackHouseAndUnLevel:
		endTime = now.Add(xconst.Day * 3).UnixMilli()
	case threeDayBlackHouseAndUnLevelZero:
		endTime = now.Add(xconst.Day * 3).UnixMilli()
	case blockUser:
		{ // 封禁用户
			filter := map[string]interface{}{
				"user_id": report.UserId,
			}
			data := map[string]interface{}{
				"enabled": 3,
			}
			_db := l.svcCtx.ManagerDB.UserInfo
			_, err = _db.Update(l.ctx, filter, data)
			if err != nil {
				return nil, err
			}

			err = _db.ClearUserInfoRedisCache(l.ctx, report.UserId)
			err = _db.ClearUserTokenRedisCache(l.ctx, report.UserId)

			if err != nil {
				return nil, err
			}
		}
	}

	{

		// 更新处罚记录状态
		filter := map[string]interface{}{
			"_id": report.ID,
		}
		update := map[string]interface{}{
			"verifyStatus": req.Status,
			"verifyTime":   now.UnixMilli(),
			"verifyUser":   req.CtxName,
		}
		_, err = l.svcCtx.ManagerDB.SecretReport.UpdateMap(l.ctx, filter, update)
		if err != nil {
			return nil, err
		}

		if req.Status != noPunish {
			filter = map[string]interface{}{
				"_id": report.UserId,
			}
			update = map[string]interface{}{
				"$inc": bson.D{
					{"newPenalties", 1},
				},
			}
			err = l.svcCtx.ManagerDB.SecretUserExtInfo.Update(l.ctx, filter, update)
			if err != nil {
				return nil, err
			}

			// 所有举报成功的都加1
			filter = map[string]interface{}{
				"reportId": report.ID,
				"source":   1,
			}
			reportUsers, err := l.svcCtx.ManagerOnlyReadDB.SecretReportUser.FindAll(l.ctx, filter)
			if err != nil {
				return nil, err
			}
			for _, user := range reportUsers {
				day, _ := utils.TimeByDay(now)
				filter = map[string]interface{}{
					"daily":  day,
					"userId": user.ReportUserId,
				}
				policeDaily, err := l.svcCtx.ManagerDB.PersonalPoliceDailyData.FindOne(l.ctx, filter)
				switch {
				case err == xerr.DbNotFound:
					policeDaily = &model.PersonalPoliceDailyData{
						Daily:        day,
						UserId:       user.ReportUserId,
						SuccessCount: 1,
					}
					_, err = l.svcCtx.ManagerDB.PersonalPoliceDailyData.Insert(l.ctx, policeDaily)
					if err != nil {
						return nil, err
					}
				case err == nil:
					update = map[string]interface{}{
						"$inc": bson.D{
							{"successCount", 1},
						},
					}
					_, err = l.svcCtx.ManagerDB.PersonalPoliceDailyData.Update(l.ctx, filter, update)
					if err != nil {
						return nil, err
					}
				default:
					return nil, err
				}
			}

		}
	}

	{ // 更新小黑屋数据
		if endTime > 0 {
			data := &model.SecretBlackHouse{
				UserId: report.UserId,
				Start:  now.UnixMilli(),
				End:    endTime,
				Status: req.Status,
			}
			_, err = l.svcCtx.ManagerDB.SecretBlackHouse.Insert(l.ctx, data)
			if err != nil {
				return nil, err
			}
		}

		if req.Status == noPunish && report.Arrested == 1 {
			l.svcCtx.RedisClient.UserInfo.RemoveUserFromBlackHouse(l.ctx, report.UserId)
		}
	}

	{ // 通知降级等处罚
		body, err := json.Marshal(map[string]interface{}{
			"report_id": req.ReportId,
		})
		if err != nil {
			return nil, err
		}
		u, _ := url.JoinPath(l.svcCtx.Config.ContentServe, "/platform/api/inner/audit/notify")
		response, err := xhttp.Post(u, body)
		if err != nil {
			return nil, err
		}

		if response.StatusCode != 200 {
			return nil, xerr.ReportPunishError
		}
	}

	return
}
