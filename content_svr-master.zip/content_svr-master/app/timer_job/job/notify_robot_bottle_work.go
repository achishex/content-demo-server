package job

import (
	"content_svr/config"
	"content_svr/db/dao"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"time"
)

/*
定时推送动态相关数据
*/
type notifyBottleWorkControl struct {
	write, read *dao.ManagerDB
}

func newNotifyBottleWorkControl(write, read *dao.ManagerDB) *notifyBottleWorkControl {
	return &notifyBottleWorkControl{
		write: write,
		read:  read,
	}
}

func InitBottleWorkRobot(write, read *dao.ManagerDB) {
	ctx := requestid.WithRequestID(context.Background())
	target := time.Now()
	ctrl := newNotifyBottleWorkControl(write, read)
	if err := ctrl.doTask(ctx, target); err != nil {
		logger.Error(context.Background(), "InitBottleWorkRobot:", err)
	}
}

func (r notifyBottleWorkControl) doTask(ctx context.Context, targetTime time.Time) error {
	messageColumn := make([]plain, 0)

	filter := map[string]interface{}{
		"create_time_begin": utils.ZeroTime(targetTime).Format("2006-01-02 15:04:05"),
		"create_time_end":   utils.ZeroTime(utils.CalcTime(targetTime, 1)).Format("2006-01-02 15:04:05"),
	}

	count, err := r.read.PersonalBottleWorks.Count(ctx, filter)
	if err != nil {
		return err
	}

	messageColumn = append(messageColumn, plain{
		Tag:  "text",
		Text: fmt.Sprintf("当天发布的动态总数: %v\n", count),
	})

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = "动态"
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, messageColumn)

	if config.ServerConfig.Env == "test" {
		RobotServerControl.SendMessage(m)
	} else {
		RobotFacaimaoControl.SendMessage(m)
	}

	return nil
}
