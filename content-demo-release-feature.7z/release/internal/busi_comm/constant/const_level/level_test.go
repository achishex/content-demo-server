package const_level

import (
	"fmt"
	"testing"
)

func TestGetLevelCfg(t *testing.T) {
	var i int32
	for ; i < 6; i++ {
		fmt.Println(i, "级")
		u := GetLevelCfg(i)
		for _, v := range u.LevelUpDescArr {
			fmt.Println(v)
		}
		fmt.Printf("\n\n\n")
	}
}

func BenchmarkSetLevelCommentLimit(b *testing.B) {
	b.Log(b.N)
	var q int32

	for i := 0; i < b.N; i++ {
		go func() {
			for q = 0; q < 6; q++ {
				GetLevelCfg(q)
			}
		}()
	}

	for i := 0; i < b.N; i++ {
		for q = 0; q < 6; q++ {
			SetLevelCommentLimit(q, i, i)
		}

	}

}
