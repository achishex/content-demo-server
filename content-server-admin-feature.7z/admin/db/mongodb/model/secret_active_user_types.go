package model

type SecretActiveUser struct {
	ID            int64  `json:"id,omitempty" bson:"_id"`
	UserId        int64  `json:"user_id,omitempty" bson:"user_id"`                 //用户id
	Nickname      string `json:"nickname,omitempty" bson:"nickname"`               //昵称
	CreateTime    int64  `json:"create_time,omitempty" bson:"create_time"`         //创建时间/第一次登录时间
	LastLoginTime int64  `json:"last_login_time,omitempty" bson:"last_login_time"` //最后登录时间
	NicknameWords string `json:"nickname_words,omitempty" bson:"nickname_words"`   //昵称分词
}
