package cache

import (
	"content_svr/db/dao/operate"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/model"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
	"context"
	"gorm.io/gen"
)

type PersonalBottleWorks struct {
	query.PersonalBottleWork
	redisManage *query_rds.Manage
}

func NewCachePersonalBottleWorks(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *PersonalBottleWorks {
	return &PersonalBottleWorks{
		PersonalBottleWork: query.NewPersonalBottleWork(mysql.PersonalBottleWork),
		redisManage:        redisManage,
	}
}

func (p *PersonalBottleWorks) UpdateByWorkId(ctx context.Context, workId int64, update map[string]interface{}) (info gen.ResultInfo, err error) {
	info, err = p.PersonalBottleWork.UpdateMap(ctx, map[string]interface{}{"id": workId}, update)
	switch {
	case err != nil:
		return info, err
	case info.RowsAffected != 0:
		err = p.redisManage.WorkInfo.UpdateMany(ctx, workId, update)
	}

	return info, err
}

func (p *PersonalBottleWorks) UpdateShowScope(ctx context.Context, workId int64, showScope int32) (info gen.ResultInfo, err error) {

	info, err = p.PersonalBottleWork.Where(p.ID.Eq(workId)).Update(p.ShowScope, showScope)
	switch {
	case err != nil:
		return info, err
	case info.RowsAffected != 0:
		err = p.redisManage.WorkInfo.UpdateColumnOne(ctx, workId, p.PersonalBottleWork.GetColumnName(p.ShowScope), showScope)
		if err != nil {
			return info, err
		}
	}
	return info, err
}

func (p *PersonalBottleWorks) IncNewCommentCount(ctx context.Context, workId, count int64) error {
	_, err := p.PersonalBottleWork.WithContext(ctx).Where(
		p.PersonalBottleWork.ID.Eq(workId)).Update(p.PersonalBottleWork.NewCommentCount, p.PersonalBottleWork.NewCommentCount.Add(1))
	if err != nil {
		return err
	}

	err = p.redisManage.WorkInfo.UpdateColumnOne(ctx, workId, p.PersonalBottleWork.GetColumnName(p.NewCommentCount), count)
	if err != nil {
		return err
	}
	return nil
}

func (p *PersonalBottleWorks) UpdateWorkVerifyStatus(ctx context.Context, workId int64, verifyStatus int32) error {
	_, err := p.PersonalBottleWork.WithContext(ctx).Where(
		p.PersonalBottleWork.ID.Eq(workId)).Update(p.PersonalBottleWork.VerifyStatus, verifyStatus)
	if err != nil {
		return err
	}

	err = p.redisManage.WorkInfo.UpdateColumnOne(ctx, workId, p.PersonalBottleWork.GetColumnName(p.VerifyStatus), 1)
	if err != nil {
		return err
	}

	return nil
}

func (p *PersonalBottleWorks) FindByWorkId(ctx context.Context, workId int64) (result *model.PersonalBottleWork, err error) {
	_db := p.PersonalBottleWork
	return _db.WithContext(ctx).Where(_db.ID.Eq(workId)).First()
}

func (p *PersonalBottleWorks) FindByWorkIds(ctx context.Context, workIds []int64) (results []*model.PersonalBottleWork, err error) {
	_db := p.PersonalBottleWork
	return _db.WithContext(ctx).Where(_db.ID.In(workIds...)).Find()
}

func (p *PersonalBottleWorks) FindPage(ctx context.Context, turner operate.PageTurner) (results []*model.PersonalBottleWork, total int64, err error) {
	where, offset, limit := turner.ParseMysql()
	_do := p.PersonalBottleWork.ParseWhere(ctx, where)

	count, err := _do.Count()
	if err != nil {
		return nil, 0, err
	}

	orderCond := turner.ParseMysqlOrderBy(p.PersonalBottleWork.TableName())

	result, err := _do.Limit(limit).Offset(offset).Order(orderCond).Find()
	if err != nil {
		return nil, 0, err
	}

	return result, count, nil
}

func (p *PersonalBottleWorks) Count(ctx context.Context, where map[string]interface{}) (int64, error) {
	_do := p.PersonalBottleWork.ParseWhere(ctx, where)
	return _do.Count()

}
