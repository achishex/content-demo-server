package utils

import (
	"testing"
	"time"
)

func TestCalcTime(t *testing.T) {
	now := time.Now()

	afterTime := CalcTime(now, -2)

	t.Log(afterTime.After(now))  //  相当于 大于
	t.Log(afterTime.Before(now)) //  相当于 小于

}

func TestToday(t *testing.T) {
	today := Today(23, 30, 0)
	t.Log(today)
	t.Log(today.AddDate(0, 0, -1))
	t.Log(today.AddDate(0, 0, 1))
}

func TestRandDur(t *testing.T) {
	t.Log(RandDur(time.Minute * 10))
	t.Log(RandDur(time.Minute * 10))
	t.Log(RandDur(time.Minute * 10))
}
