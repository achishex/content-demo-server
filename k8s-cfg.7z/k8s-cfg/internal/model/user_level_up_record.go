package model

import (
	"content_svr/protobuf/pbdb"
	"content_svr/pub/errors"
	"context"
	"encoding/json"
	"gorm.io/gorm"
	"gorm.io/plugin/dbresolver"
)

type IUserLevelUpRecordDbModel interface {
	ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.UserLevelUpRecordDbModel, error)
	GetItemById(ctx context.Context, userId int64) (*pbdb.UserLevelUpRecordDbModel, error)
	UpdateItem(ctx context.Context, model *pbdb.UserLevelUpRecordDbModel) (*pbdb.UserLevelUpRecordDbModel, error)
	CreateItem(ctx context.Context, model *pbdb.UserLevelUpRecordDbModel) (*pbdb.UserLevelUpRecordDbModel, error)
	CountItemsByCondition(ctx context.Context, condition map[string]interface{}) (total int64, _ error)
	UpdateByCondition(ctx context.Context, condition, changes map[string]interface{}) error
}

type UserLevelUpRecordDbModelImpl struct {
	DB *gorm.DB
}

func NewUserLevelUpRecordDbModelImpl(db *gorm.DB) IUserLevelUpRecordDbModel {
	return &UserLevelUpRecordDbModelImpl{DB: db}
}

func (impl *UserLevelUpRecordDbModelImpl) table() string {
	return "user_level_up_record"
}

func (impl *UserLevelUpRecordDbModelImpl) GetItemById(ctx context.Context, userId int64) (*pbdb.UserLevelUpRecordDbModel, error) {
	model := pbdb.UserLevelUpRecordDbModel{}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Clauses(dbresolver.Write).
		Where("user_id = ?", userId).First(&model)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &model, errors.Wrap(result.Error)
}

func (impl *UserLevelUpRecordDbModelImpl) UpdateItem(ctx context.Context, model *pbdb.UserLevelUpRecordDbModel) (*pbdb.UserLevelUpRecordDbModel, error) {
	modelDict := make(map[string]interface{})
	modelByte, err := json.Marshal(model)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(modelByte, &modelDict)
	if err != nil {
		return nil, err
	}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Where("user_id = ?", model.GetUserId()).Updates(modelDict)
	return model, errors.Wrap(result.Error)
}

func (impl *UserLevelUpRecordDbModelImpl) CreateItem(ctx context.Context, model *pbdb.UserLevelUpRecordDbModel) (*pbdb.UserLevelUpRecordDbModel, error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Create(model)
	return model, errors.Wrap(result.Error)
}

// offset 开始查的默认值为0
func (impl *UserLevelUpRecordDbModelImpl) ListItemOffset(ctx context.Context, condition map[string]interface{}, page int, size int) ([]*pbdb.UserLevelUpRecordDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.UserLevelUpRecordDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(size).Offset(offset).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}

	return items, errors.Wrap(result.Error)
}

func (impl *UserLevelUpRecordDbModelImpl) ListItemsByCondition(ctx context.Context,
	condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.UserLevelUpRecordDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.UserLevelUpRecordDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(int(size)).Offset(int(offset)).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *UserLevelUpRecordDbModelImpl) CountItemsByCondition(ctx context.Context,
	condition map[string]interface{}) (total int64, _ error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Model(&pbdb.UserLevelUpRecordDbModel{}).Where(condition).Count(&total)
	return total, errors.Wrap(result.Error)
}

func (impl *UserLevelUpRecordDbModelImpl) UpdateByCondition(ctx context.Context,
	condition, changes map[string]interface{}) error {
	if len(condition) == 0 || len(changes) == 0 {
		return nil
	}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Where(condition).Updates(changes)
	return errors.Wrap(result.Error)
}
