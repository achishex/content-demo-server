package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretSignInMgModel interface {
	FindOne(ctx context.Context, filter any) (*pbmgdb.SecretDailySignInMgDbModel, error)
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretDailySignInMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.SecretDailySignInMgDbModel, options ...*options.InsertOneOptions) error
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
}

type SecretDailySignIn struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretDailySignInMgModelImpl(db *mongo.Database) ISecretSignInMgModel {
	return &SecretDailySignIn{
		MgDB:  db,
		Table: "secretDailySignIn",
	}
}

func (g *SecretDailySignIn) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *SecretDailySignIn) FindOne(ctx context.Context, filter any) (*pbmgdb.SecretDailySignInMgDbModel, error) {
	var v *pbmgdb.SecretDailySignInMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretDailySignIn FindOne failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *SecretDailySignIn) Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretDailySignInMgDbModel, error) {
	find, err := g.coll().Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	retItems := make([]*pbmgdb.SecretDailySignInMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.SecretDailySignInMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretDailySignIn failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (g *SecretDailySignIn) Create(ctx context.Context, data *pbmgdb.SecretDailySignInMgDbModel, options ...*options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data, options...)

	if err != nil {
		logger.Errorf(ctx, "SecretDailySignIn:Create error : %v", err)
		return err
	}

	return nil
}

func (g *SecretDailySignIn) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "SecretDailySignIn:updateOne error: %v", err)
		return err
	}

	return nil
}
