package work_manage

import "content_svr/db/dao"

type WorkManage struct {
	WorkCommentAttr
}

func NewWorkManage(read, write *dao.ManagerDB) *WorkManage {
	return &WorkManage{
		WorkCommentAttr: WorkCommentAttr{
			write: write,
			read:  read,
		},
	}
}
