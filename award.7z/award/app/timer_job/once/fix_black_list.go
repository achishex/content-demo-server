package once

import (
	"content_svr/config"
	"content_svr/protobuf/pbapi"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"log"
	"time"
)

func fixBlackList(mngDB *mongo.Client) {
	db := mngDB.Database(config.ServerConfig.MongodbConfig.DBName)
	userBlackListCollection := db.Collection("userBlackList")

	filter := bson.D{
		{Key: "appFlag", Value: 5},
	}

	opt := &options.FindOptions{}

	var page int64 = 1
	var size int64 = 100

	count, err := userBlackListCollection.CountDocuments(context.Background(), filter)
	if err != nil {
		panic(err)
	}

	log.Println("count: ", count)

	for {
		log.Printf("page: %d, size: %d \n", page, size)
		skip := (page - 1) * size
		opt.Limit = &size
		opt.Skip = &skip
		ctx := context.Background()
		cur, err := userBlackListCollection.Find(ctx, filter, opt)
		if err != nil {
			panic(err)
		}

		if count < skip {
			break
		}

		for cur.Next(ctx) {
			var item pbapi.UserBlackListMgDbModel
			err := cur.Decode(&item)
			if err != nil {
				panic(err)
			}

			if item.GetUserId() == 0 {
				continue
			}

			if item.GetUserId() == item.GetTargetUserId() {
				log.Println("delete: ", item.GetId())
				//dFilter := bson.D{
				//	{"_id", item.GetId()},
				//}
				//_, err = userBlackListCollection.DeleteOne(ctx, dFilter)
				//if err != nil {
				//	log.Println("delete error: ", err)
				//}
			}
		}

		time.Sleep(time.Millisecond * 500)
		page++
	}

}
