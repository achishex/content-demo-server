package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	"github.com/go-redis/redis/v8"
	"time"
)

func (p *DataCacheMng) GetTimesConfigLR(ctx context.Context, busiKey string) int64 {
	cacheKey := fmt.Sprintf(cache_const.TimeConfigLcache.KeyFmt, busiKey) // TimesConfig:times_push_work_intercept_threshold_num
	expire := cache_const.TimeConfigLcache.Expire

	//从内存取// todo 跳过读内存
	//cResp, exist := p.LocalCache.Get(cacheKey)
	//if exist {
	//	resp, ok := cResp.(int64)
	//	if ok {
	//		return resp
	//	}
	//}

	redisKey := getRdsKeyTimesConfig(busiKey)
	timesStr, err := p.RedisCli.Get(ctx, redisKey).Result() //返回在range的idx位置
	if err != nil && err != redis.Nil {
		logger.Error(ctx, fmt.Sprintf("GetTimesConfig failed, redisKey=%v", redisKey), err)
		return 0
	}
	timeInt64, err := utils.Str2Int64(timesStr)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("GetTimesConfig trans to int64 failed, redisKey=%v", redisKey), err)
		return 0
	}

	// 写缓存 todo 删除？
	bSuc := p.LocalCache.Set(cacheKey, timeInt64, go_cache.WithEx(time.Duration(expire)*time.Second))
	logger.Infof(ctx, "save GetTimesConfig to local cache. cacheKey=%v, timeInt64=%v， bSuc=%v",
		cacheKey, timeInt64, bSuc)
	return timeInt64
}

//func (p *DataCacheMng) LoadTimesConfigComment(ctx context.Context, key string) {
//	redisKey := getRdsKeyTimesConfig(key)
//	m, err := p.RedisCli.HGetAll(ctx, redisKey).Result()
//	if err != nil {
//		logger.Error(ctx, "redis key: "+redisKey, err)
//		return
//	}
//
//	for k, v := range m {
//		value, err := strconv.Atoi(v)
//		if err != nil {
//			logger.Error(ctx, fmt.Sprintf("redis key: %s, %s", v, redisKey), err)
//			continue
//		}
//		switch k {
//		case "0-max":
//			var_busi.Level0MaxCommentNums = value
//		case "1-max":
//			var_busi.Level1MaxCommentNums = value
//		case "2-max":
//			var_busi.Level2MaxCommentNums = value
//		case "3-max":
//			var_busi.Level3MaxCommentNums = value
//		case "4-max":
//			var_busi.Level4MaxCommentNums = value
//		case "5-max":
//			var_busi.Level5MaxCommentNums = value
//
//		case "0-single-max":
//			var_busi.Level0SingleMaxCommentNums = value
//		case "1-single-max":
//			var_busi.Level1SingleMaxCommentNums = value
//		case "2-single-max":
//			var_busi.Level2SingleMaxCommentNums = value
//		case "3-single-max":
//			var_busi.Level3SingleMaxCommentNums = value
//		case "4-single-max":
//			var_busi.Level4SingleMaxCommentNums = value
//		case "5-single-max":
//			var_busi.Level5SingleMaxCommentNums = value
//		}
//	}
//
//	const_level.SetLevelCommentLimit(0, var_busi.Level0SingleMaxCommentNums, var_busi.Level0MaxCommentNums)
//	const_level.SetLevelCommentLimit(1, var_busi.Level1SingleMaxCommentNums, var_busi.Level1MaxCommentNums)
//	const_level.SetLevelCommentLimit(2, var_busi.Level2SingleMaxCommentNums, var_busi.Level2MaxCommentNums)
//	const_level.SetLevelCommentLimit(3, var_busi.Level3SingleMaxCommentNums, var_busi.Level3MaxCommentNums)
//	const_level.SetLevelCommentLimit(4, var_busi.Level4SingleMaxCommentNums, var_busi.Level4MaxCommentNums)
//	const_level.SetLevelCommentLimit(5, var_busi.Level5SingleMaxCommentNums, var_busi.Level5MaxCommentNums)
//
//}
