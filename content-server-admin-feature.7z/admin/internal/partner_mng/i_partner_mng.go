package partner_mng

import (
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/internal/inner_mng"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/user_center_mng"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbuserapi"
	"context"
)

type IPartnerMng interface {
	GetPartnerInfo(ctx context.Context) (*pbuserapi.PartnerInfoResp, error)
	UseInviteCode(ctx context.Context, req *pbuserapi.UseInviteCodeReq) (*pbuserapi.UseInviteCodeResp, error)
	GetPartnerDetail(ctx context.Context, userId int64) (*pbuserapi.PartnerInfoResp, *pbmgdb.PartnerMgDbModel, error)
	GetPartnerLabel(ctx context.Context, userId int64) ([]*pbapi.LabelItem, error)
}

type PartnerMng struct {
	DataCache     data_cache.IDataCacheMng
	InnerProxy    inner_mng.IInnerProxy
	KafkaProxy    kafka_proxy.IKafkaProxy
	UserCenterMng user_center_mng.IUserCenterMng
	ContentMng    content_mng.IContentMng
}

func NewPartnerMng(
	dataCache data_cache.IDataCacheMng,
	innerProxy inner_mng.IInnerProxy,
	kafkaProxy kafka_proxy.IKafkaProxy,
	userCenterMng user_center_mng.IUserCenterMng,
	contentMng content_mng.IContentMng,
) IPartnerMng {
	return &PartnerMng{
		DataCache:     dataCache,
		InnerProxy:    innerProxy,
		KafkaProxy:    kafkaProxy,
		UserCenterMng: userCenterMng,
		ContentMng:    contentMng,
	}
}
