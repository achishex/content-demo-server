package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/pub/logger"
	"context"
	"fmt"
)

// 模块权限是否风景。 todo test
func (p *DataCacheMng) CheckByTypeAndModule(ctx context.Context, fbType, module int32, userId int64) bool {
	if userId == 0 {
		return false
	}

	redisKey := fmt.Sprintf(cache_const.UserModuleBlockRcache.KeyFmt, fbType, module, userId) //
	time, err := p.RedisCli.TTL(ctx, redisKey).Result()
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("CheckByTypeAndModule redis qurey failed. key=%v", redisKey), err)
		return false
	}
	return time > -2
}
