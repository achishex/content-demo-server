package model

const SecretReportCollectionName = "secretReport"

type SecretReport struct {
	ID           int64  `bson:"_id" json:"id"`
	Type         int32  `json:"type,omitempty" bson:"type"`                 //抓捕类型 1.动态 2.单聊 3.带图动态二审 4.背景图二审 10.评论
	Timestamp    int64  `json:"timestamp,omitempty" bson:"timestamp"`       // 创建时间
	Arrested     int32  `json:"arrested,omitempty" bson:"arrested"`         // 1 被抓捕过 ，2 没有被抓捕过
	VerifyTime   int64  `json:"verifyTime,omitempty" bson:"verifyTime"`     // 审核时间
	VerifyStatus int64  `json:"verifyStatus,omitempty" bson:"verifyStatus"` // 审核状态
	VerifyUser   string `json:"verifyUser,omitempty" bson:"verifyUser"`     // 审核人
	WorkId       int64  `json:"workId,omitempty" bson:"workId"`             //动态id
	CommentId    int64  `json:"commentId,omitempty" bson:"commentId"`       //评论id
	UserId       int64  `json:"userId,omitempty" bson:"userId"`             //用户id
	ReportUserId int64  `json:"reportUserId,omitempty" bson:"reportUserId"` // 操作举报的用户id
}
