package subcmd

import (
	"content_svr/internal/data_cache"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/model"
	"content_svr/internal/wxreward"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/samber/lo"
	"github.com/spf13/cobra"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"gorm.io/gorm"
)

func NewDailyNotifyCmd(kfk kafka_proxy.IKafkaProxy, pdb model.ParseTimeDB, srv *wxreward.Service,
	mdb *mongo.Database, dc data_cache.IDataCacheMng) *cobra.Command {
	var uid int64
	var db *gorm.DB = pdb
	fmt.Sprint(db)

	ctx := context.Background()
	cmd := &cobra.Command{
		Use:   "daily_notify",
		Short: "daily_notify",
		Long:  "",
		RunE: func(_ *cobra.Command, args []string) error {
			var uids []int64
			if uid > 0 {
				uids = []int64{uid}
			} else {
				opts := options.Find().SetSort(bson.D{{Key: "_id", Value: -1}}).SetLimit(2000)

				exts, err := dc.GetImpl().UserInfoExtMgModel.Query(ctx, bson.M{"ulevel": 5}, opts)
				if err != nil {
					return err
				}

				logger.Infof(ctx, "query level user count %v", len(exts))
				totalLvl5UserIDs := lo.Map(exts, func(t *pbapi.SecretUserExtInfoMgDbModel, index int) int64 {
					return t.GetId()
				})

				if err := db.Table("user_info").Where("status = 1 and user_id in ?", totalLvl5UserIDs).Limit(2000).Pluck("user_id", &uids).Error; err != nil {
					logger.Errorf(ctx, "get user id err: %v", err)
					return err
				}
			}

			logger.Infof(ctx, "noitfy user count %v", len(uids))
			var lvl5reward, lvl5n []int64
			for _, u := range uids {
				if reward, _ := srv.CheckLvlUpReward(ctx, &wxreward.LvlUpRewardReq{
					UserID: u,
					Lvl:    5,
				}); reward.Rewarded {
					lvl5reward = append(lvl5reward, u)
				} else {
					lvl5n = append(lvl5n, u)
				}
			}

			logger.Infof(ctx, "daily_notify reward: %v, not_reward: %v", lvl5reward, lvl5n)
			rewardContent := `[有人@我]大红包!快快快!! 点击查看>`
			notRewarContent := `[有人@我]都几点了，还不理我吗?`

			if err := kfk.TsnPushDailyNotify(ctx, rewardContent, lvl5reward); err != nil {
				logger.Errorf(ctx, "daily_notify push err: %v", err)
			}
			if err := kfk.TsnPushDailyNotify(ctx, notRewarContent, lvl5n); err != nil {
				logger.Errorf(ctx, "daily_notify push err: %v", err)
			}
			return nil
		},
	}
	cmd.Flags().Int64Var(&uid, "uid", 0, "user_id")
	return cmd
}
