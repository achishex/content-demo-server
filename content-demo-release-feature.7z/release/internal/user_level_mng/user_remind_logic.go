package user_level_mng

import (
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbuserapi"
	"github.com/gin-gonic/gin"
	"github.com/pkg/errors"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const (
	mutualClose = iota
	mutualOpen
)

var officialID = []int64{
	//129533901081600, // 名字：猫爪官方 by quding
	//4424423168587776, // 名字：猫爪临时工小美 // by quding
	//4340433133352960, // 猫爪研发
}

// mongo SecretUserFollow 表，mutual=1的就是互爪

// GetRemindOfficialListLogic 获取官方@信息
func (p *UserLevelMng) GetRemindOfficialListLogic(ctx *gin.Context) (data []*pbapi.UserinfoDbModel, err error) {

	// 从mysql user_info表查出所有官方账号
	users, err := p.DataCache.GetImpl().UserInfoModel.GetByUserIds(ctx, officialID)
	if err != nil {
		return nil, err
	}

	if users == nil || len(users) == 0 {
		return nil, errors.New("无法查询到官方用户")
	}

	return users, err
}

// GetRemindFollowerListLogic 获取可以@用户信息
func (p *UserLevelMng) GetRemindMutualListLogic(
	ctx *gin.Context, userId int64, req *pbuserapi.GetRemindFollowerListReq) (
	data []*pbapi.UserinfoDbModel, total int64, err error) {

	filter := bson.D{
		{"userId", userId},
		{"mutual", mutualOpen},
	}

	skipCount := int64((req.GetPage() - 1) * req.GetSize())
	if skipCount < 0 {
		skipCount = 0
	}
	size := int64(req.GetSize())
	if size == 0 {
		size = 10
	}
	findOptions := options.Find()
	findOptions.SetSkip(skipCount)
	findOptions.SetLimit(size)

	// 查互关表，拿userId
	followIds, total, err := p.DataCache.GetImpl().SecretUserFollowMgModel.GetSecretUserFollowByUserId(ctx, filter, findOptions)
	// 从mysql user_info表拿用户信息
	users, err := p.DataCache.GetImpl().UserInfoModel.GetByUserIds(ctx, followIds)
	if err != nil {
		return nil, 0, err
	}

	return users, total, err
}
