package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type MzRobot struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	Number        int64  `bson:"number,omitempty" json:"number,omitempty"`                   // 序号
	UserId        int64  `bson:"user_id,omitempty" json:"user_id,omitempty"`                 // user_id
	Header        string `bson:"header,omitempty" json:"header,omitempty"`                   // 头像
	Name          string `bson:"name,omitempty" json:"name,omitempty"`                       // 机器人名称
	Category      uint8  `bson:"category,omitempty" json:"category,omitempty"`               // 机器人类型
	Comment       string `bson:"comment,omitempty" json:"comment,omitempty"`                 // 评论内容
	Status        bool   `bson:"status" json:"status"`                                       // 是否启动， 必须
	Description   string `bson:"description,omitempty" json:"description,omitempty"`         // 简介：非必填，对应正常账户的动态
	CommentIndex  int32  `bson:"comment_index,omitempty" json:"comment_index,omitempty"`     // 插入位置（第几条评论）
	Color         string `bson:"color,omitempty" json:"color,omitempty"`                     // 评论内容的颜色（颜色支持RGB六位提供，如000000）
	TimePartStart int64  `bson:"time_part_start,omitempty" json:"time_part_start,omitempty"` // 生效时间
	TimePartEnd   int64  `bson:"time_part_end,omitempty" json:"time_part_end,omitempty"`     // 结束时间
	UpdateAt      int64  `bson:"update_at,omitempty" json:"update_at,omitempty"`             // 修改时间
}
