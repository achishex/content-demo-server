package content_mng

import "context"

func (p *ContentMng) GetBackgroundWithTalk(ctx context.Context) (string, error) {
	bgImage, err := p.DataCache.GetBackgroundWithTalk(ctx)
	if err != nil {
		return "", err
	}

	return bgImage, err
}

func (p *ContentMng) GetBackgroundWithWork(ctx context.Context) (string, error) {
	bgImage, err := p.DataCache.GetBackgroundWithWork(ctx)
	if err != nil {
		return "", err
	}

	return bgImage, err
}
