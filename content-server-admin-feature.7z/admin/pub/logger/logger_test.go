package logger

import (
	"context"
	"fmt"
	"testing"
	"unicode/utf8"
)

func TestInfo(t *testing.T) {
	DebugLogger("test")
	fmt.Println("tttttt")
	//logrus.Info("zzz")
	Info(context.Background(), "ccc")
	Error(context.Background(), "aaa", nil)
	Warnf(context.Background(), "bbb%v", "x")
}

func TestStrLen(t *testing.T) {
	s := "建设过程以保护传承弘扬长江文化为核心，按照“堤内园林景观带，堤外生态绿化带”标准，改造提升琵琶亭、浔阳楼、锁江楼及周边景点，打造水清干"
	rs := []rune(s)
	t.Log(utf8.RuneCountInString(s))
	t.Log(len(s))
	t.Log(len(rs))
}
