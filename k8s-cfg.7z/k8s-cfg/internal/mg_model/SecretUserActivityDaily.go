package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretUserActivityDailyMgModel interface {
	Create(ctx context.Context, data *pbmgdb.SecretUserActivityDaily, opts ...*options.InsertOneOptions) error
	FindOne(ctx context.Context, filter bson.D, opts ...*options.FindOneOptions) (*pbmgdb.SecretUserActivityDaily, error)
	FindAll(ctx context.Context, filter bson.D, opts ...*options.FindOptions) ([]*pbmgdb.SecretUserActivityDaily, error)
	Count(ctx context.Context, filter bson.D, opts ...*options.CountOptions) (int64, error)
	Update(ctx context.Context, filter, update any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error)
}

type SecretUserActivityDailyMgModelImpl struct {
	MgDB       *mongo.Database
	Collection *mongo.Collection
}

func NewSecretUserActivityDailyMgModelImpl(db *mongo.Database) ISecretUserActivityDailyMgModel {
	record := &SecretUserActivityDailyMgModelImpl{MgDB: db}
	record.Collection = record.MgDB.Collection(record.tableName())
	return record
}

func (impl *SecretUserActivityDailyMgModelImpl) tableName() string {
	return "secretUserActivityDaily"
}

func (impl *SecretUserActivityDailyMgModelImpl) Create(ctx context.Context, data *pbmgdb.SecretUserActivityDaily, opts ...*options.InsertOneOptions) error {
	//data.ID = snow_flake.GetSnowflakeID()
	_, err := impl.Collection.InsertOne(ctx, data, opts...)
	if err != nil {
		return err
	}

	//id, ok := result.InsertedID.(primitive.ObjectID)
	//if !ok {
	//	return nil
	//}
	//data.ID = id
	return nil
}

func (impl *SecretUserActivityDailyMgModelImpl) Delete() {}

func (impl *SecretUserActivityDailyMgModelImpl) Count(ctx context.Context, filter bson.D, opts ...*options.CountOptions) (int64, error) {
	return impl.Collection.CountDocuments(ctx, filter, opts...)
}
func (impl *SecretUserActivityDailyMgModelImpl) FindOne(ctx context.Context, filter bson.D, opts ...*options.FindOneOptions) (*pbmgdb.SecretUserActivityDaily, error) {
	result := &pbmgdb.SecretUserActivityDaily{}
	err := impl.Collection.FindOne(ctx, filter, opts...).Decode(result)
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (impl *SecretUserActivityDailyMgModelImpl) FindAll(ctx context.Context, filter bson.D, opts ...*options.FindOptions) ([]*pbmgdb.SecretUserActivityDaily, error) {
	cur, err := impl.Collection.Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	result := make([]*pbmgdb.SecretUserActivityDaily, 0)
	for cur.Next(ctx) {
		item := &pbmgdb.SecretUserActivityDaily{}
		if err := cur.Decode(item); err != nil {
			return nil, err
		}
		result = append(result, item)
	}

	return result, err
}

func (impl *SecretUserActivityDailyMgModelImpl) Update(ctx context.Context, filter, update any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error) {
	return impl.Collection.UpdateOne(ctx, filter, update, opts...)
}

func (impl *SecretUserActivityDailyMgModelImpl) UpdateMany(ctx context.Context, filter, update any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error) {
	return impl.Collection.UpdateMany(ctx, filter, update, opts...)
}
