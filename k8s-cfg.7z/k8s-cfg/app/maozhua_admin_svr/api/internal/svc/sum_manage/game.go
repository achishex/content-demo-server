package sum_manage

import (
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/utils"
	"context"
	"time"
)

type GameOrder struct {
	ManagerDB, ManagerOnlyReadDB *dao.ManagerDB
}

func (s *GameOrder) GameOrder(ctx context.Context, filter map[string]interface{}) ([]model.GameStatistical, error) {
	var gameTable = map[string]model.GameStatistical{}

	items, err := s.ManagerOnlyReadDB.SecretGameOrder.FindAll(ctx, filter)
	if err != nil {
		return nil, err
	}

	if len(items) == 0 {
		return nil, nil
	}

	// 聚合数据
	now := time.Now()
	nowZero := utils.ZeroTime(now).UnixMilli()
	var sumAllGame uint
	for _, item := range items {
		price := uint(item.Amount)
		if game, ok := gameTable[item.GameId]; ok {
			game.AmountSum += price
			gameTable[item.GameId] = game
		} else {
			var gameName string
			gameInfo, err := s.ManagerOnlyReadDB.SecretGame.FindOne(ctx, map[string]interface{}{
				"game_id": item.GameId,
			})
			if err == nil {
				gameName = gameInfo.GameName
			}
			if err != nil {
				return nil, err
			}
			gameTable[item.GameId] = model.GameStatistical{
				GameId:     item.GameId,
				GameName:   gameName,
				AmountSum:  price,
				Day:        nowZero,
				CreateTime: nowZero,
				UpdateTime: nowZero,
			}
		}

		sumAllGame += uint(item.Amount)
	}

	statisticalList := make([]model.GameStatistical, 0)
	for _, statistical := range gameTable {
		statisticalList = append(statisticalList, statistical)
	}

	return statisticalList, nil
}
