package mg_model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type ISecretMedalInfoMgModel interface {
	Insert(ctx context.Context, item *pbapi.SecretMedalInfoMgDbModel) error
	DictByIds(ctx context.Context, ids []int64) (map[int64]*pbapi.SecretMedalInfoMgDbModel, error)
}

type SecretMedalInfoMgDbImpl struct {
	MgDB *mongo.Database
}

func NewSecretMedalInfoMgModelImpl(db *mongo.Database) ISecretMedalInfoMgModel {
	return &SecretMedalInfoMgDbImpl{MgDB: db}
}

func (impl *SecretMedalInfoMgDbImpl) table() string {
	return "secretMedalInfo"
}

// DictByIds 查不到返回nil
func (impl *SecretMedalInfoMgDbImpl) DictByIds(ctx context.Context, ids []int64) (map[int64]*pbapi.SecretMedalInfoMgDbModel, error) {
	retDict := make(map[int64]*pbapi.SecretMedalInfoMgDbModel)
	if len(ids) == 0 {
		return retDict, nil
	}

	retItems := make([]*pbapi.SecretMedalInfoMgDbModel, 0)
	collection := impl.MgDB.Collection("secretMedalInfo")
	find, err := collection.Find(ctx, bson.M{"_id": bson.D{{"$in", ids}}}) // todo
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretMedalInfoMgDbModel Find failed.ids=%v",
			ids), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.SecretMedalInfoMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretMedalInfoMgDbModel failed.ids=%v",
				ids), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}

	for _, retItem := range retItems {
		retDict[retItem.GetId()] = retItem
	}
	return retDict, err
}

func (impl *SecretMedalInfoMgDbImpl) Insert(ctx context.Context, item *pbapi.SecretMedalInfoMgDbModel) error {
	collection := impl.MgDB.Collection(impl.table())
	_, err := collection.InsertOne(ctx, item)
	//print(result, err)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretMedalInfoMgDbImpl.Insert  failed. item=%v",
			item), err)
	}
	return err
}
