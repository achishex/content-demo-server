package mg_model

import "go.mongodb.org/mongo-driver/mongo"

type IUserAwardSummaryMgModel interface {
}

func NewUserAwardSummaryMgModelImpl(db *mongo.Database) IUserAwardSummaryMgModel {
	return &UserAwardSummaryMgModelImpl{
		MgDB:  db,
		Table: "user_award_capital_summary",
	}
}

type UserAwardSummaryMgModelImpl struct {
	MgDB  *mongo.Database
	Table string
}
