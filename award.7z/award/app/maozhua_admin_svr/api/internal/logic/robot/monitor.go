package robot

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"context"
	"encoding/json"
	"github.com/go-redis/redis/v8"
	"github.com/zeromicro/go-zero/core/logx"
)

type robotStatus uint8

const (
	_ robotStatus = iota
	open
	running
	stop
	remove
)

const (
	_ uint8 = iota
	commentCategory
)

var monitorServe *monitor

func InitRobotMonitor(svc *svc.ServiceContext) {
	monitorServe = newMonitor(svc)
	go monitorServe.run()

	robots, err := svc.ManagerDB.MzRobotMng.FindAll(context.Background(), nil)
	if err != nil {
		panic(err)
	}
	for i := 0; i < len(robots); i++ {
		w := newWorker(&robots[i])
		monitorServe.registerWorker(w)
	}

}

// AddRobotMonitorMessage 提供外部写入任务方法
func AddRobotMonitorMessage(d map[string]int64) {
	monitorServe.addMessage(d)
}

type monitor struct {
	manageDB *dao.ManagerDB

	// 所有注册的机器人
	workers map[string]*worker
	// 注册
	register chan *worker
	// 注销 robot 表 _id
	unregister chan string
	// 从redis来的数据
	subMessage chan map[string]int64

	ctx context.Context
}

func newMonitor(svc *svc.ServiceContext) *monitor {
	return &monitor{
		manageDB:   svc.ManagerDB,
		register:   make(chan *worker),
		unregister: make(chan string),
		workers:    make(map[string]*worker),
		subMessage: make(chan map[string]int64),
		ctx:        context.Background(),
	}
}

func (m *monitor) run() {
	sub := m.subscript()
	defer func(sub *redis.PubSub) {
		_ = sub.Close()
	}(sub)

	for {
		select {
		case w := <-m.register:
			// 注册机器人
			if err := m.manageDB.MzRobotMng.UpdateStatus(m.ctx, w.robot.ID.Hex(), w.robot.Status); err != nil {
				if err != xerr.DbDoNothing {
					logx.Error(err)
				}
			}
			m.workers[w.robot.ID.Hex()] = w
			//logx.Infof("机器人: %s 注册", w.robot.ID.Hex())
			go w.run()
		case id := <-m.unregister:
			// 注销机器人
			if w, ok := m.workers[id]; ok {
				if err := m.manageDB.MzRobotMng.UpdateStatus(m.ctx, id, false); err != nil {
					if err != xerr.DbDoNothing {
						logx.Error(err)
					}
				}
				w.notifyExit()
				delete(m.workers, id)
				//logx.Infof("机器人: %s 被删除", id)
			}
		case message := <-sub.Channel():
			// 通过redis获取任务
			data := map[string]int64{}
			err := json.Unmarshal([]byte(message.Payload), &data)
			if err != nil {
				logx.Error(err)
				continue
			}
			go m.addMessage(data)
		case data := <-m.subMessage:
			// 分发任务
			for robotId, workId := range data {
				w, exist := m.workers[robotId]
				if !exist {
					continue
				}
				if w.status != running {
					// 其他状态丢弃
					continue
				}
				w.addTask(workId)
			}

		}
		//fmt.Println("wwwwwww")
	}
}

func (m *monitor) subscript() *redis.PubSub {
	sub := m.manageDB.MzRobotMng.Subscript()
	return sub
}

func (m *monitor) addMessage(d map[string]int64) {
	select {
	case m.subMessage <- d:
	case <-m.ctx.Done():
	}
}

func (m *monitor) registerWorker(w *worker) {
	id := w.robot.ID.Hex()
	_, exist := m.workers[id]
	if exist {
		m.unregisterWork(id)
	}

	select {
	case m.register <- w:
	case <-m.ctx.Done():
	}
}

func (m *monitor) unregisterWork(id string) {
	select {
	case m.unregister <- id:
	case <-m.ctx.Done():
	}
}

func (m *monitor) resetWorker(robot *model.MzRobot) {
	m.registerWorker(newWorker(robot))
}
