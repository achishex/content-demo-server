package shumei_proxy

import (
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	"io"
)

// PASS：正常，建议直接放行
// REVIEW：可疑，建议人工审核
// REJECT：违规，建议直接拦截
// Return RiskLevel
// 接口文档：https://help.ishumei.com/docs/tj/text/newest/developDoc
func (p *ShumeiProxy) CheckImg(ctx context.Context, imgUrl string, userId int64, EventID string) (string, *TextResp, error) {
	url := p.HostImage

	req := map[string]interface{}{
		"accessKey": p.AccessKey,
		"appId":     "default",
		"type":      "POLITY_EROTIC_VIOLENT_ADVERT_QRCODE_IMGTEXTRISK",
		"eventId":   EventID,
		"data": map[string]interface{}{
			"tokenId": fmt.Sprintf("%v", userId),
			"img":     imgUrl,
		},
	}
	reqByte, err := json.Marshal(req)
	// req
	sResp, err := p.postRequest(ctx, url, reqByte)
	if err != nil {
		return "", nil, err
	}
	sRespBytes, err := io.ReadAll(sResp.Body)
	if err != nil {
		return "", nil, err
	}
	logger.Infof(ctx, "shumei.CheckImg. resp=%v", string(sRespBytes))
	// 解析
	BResp := &TextResp{}
	err = json.Unmarshal(sRespBytes, BResp)
	if err != nil {
		return "", nil, err
	}
	if BResp.Code != 1100 {
		logger.Errorf(ctx, "shumei.api failed, BResp.Code=%v", BResp.Code)
		return "", nil, fmt.Errorf("shumei.api failed")
	}
	return BResp.RiskLevel, BResp, nil
}

//
//func (p *ShumeiProxy) ReverseGeocoding(ctx context.Context, lat, lng *float64) (*pbapi.Coordinate, error) {
//	if lat == nil && lng == nil {
//		return &pbapi.Coordinate{}, nil
//	}
//	uri := fmt.Sprintf("/reverse_geocoding/v3/?ak=%s&output=json&coordtype=%s&ret_coordtype=%s&location=%v,%v",
//		p.Ak, "wgs84ll", "bd09ll", *lat, *lng)
//	sn := p.Sign(ctx, uri)
//	url := fmt.Sprintf("%v%v&sn=%v", p.Host, uri, sn)
//	// req
//	sResp, err := p.getRequest(ctx, url)
//	if err != nil {
//		return nil, err
//	}
//	sRespBytes, err := io.ReadAll(sResp.Body)
//	if err != nil {
//		return nil, err
//	}
//	//logger.Infof(ctx, "===sRespBytes=%v", string(sRespBytes))
//	// 解析
//	BResp := &ReverseGeocodingResp{}
//	err = json.Unmarshal(sRespBytes, BResp)
//	if err != nil {
//		return nil, err
//	}
//
//	province := strings.Replace(BResp.Result.AddressComponent.Province, "省", "", -1)
//	province = strings.Replace(province, "市", "", -1)
//	city := strings.Replace(BResp.Result.AddressComponent.City, "市", "", -1)
//
//	// 封装到我们的结构
//	resp := &pbapi.Coordinate{
//		Longitude: lng,
//		Latitude:  lat,
//		Province:  proto.String(province),
//		City:      proto.String(city),
//		CityCode:  proto.Int32(int32(BResp.Result.CityCode)),
//		//Address:   BResp.Result,		// TODO
//	}
//	return resp, nil
//}
