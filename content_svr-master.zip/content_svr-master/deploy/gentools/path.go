package main

// 模版文件：生成go的路径文件
var (
	mongoManageTemplatePath = []string{
		"additional/mongo_manage_head.tpl",
		"additional/mongo_manage_body.tpl",
	}
	mongoManageGoPath       = "./query_mng/query.go"
	mongoConfigTemplatePath = "additional/config.tpl"
	mongoConfigGoPath       = "./model/config.go"

	mysqlModelTemplatePath = "additional/mysql.tpl"
	mysqlModelPath         = "./query/*.go"

	daoManageTemplatePath = "additional/dao.tpl"
	daoManageGoPath       = "./db/dao/db_manager.go"

	daoCacheTemplatePath = "additional/cache.tpl"
	daoCacheGoPath       = "./db/dao/cache/*.go"

	redisManageTemplatePath = "additional/redis_manage.tpl"
	redisManageGoPath       = "query.go"

	redisModelTemplatePath = "additional/redis.tpl"
	redisModelGoPath       = "./model/*.go"
)
