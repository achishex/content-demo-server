package once

import (
	"content_svr/pub/logger"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

func (c *command) fixMemberInfo() {
	//filter := bson.D{
	//	{Key: "enable", Value: true},
	//	{Key: "expire", Value: bson.D{
	//		{"$gte", time.Now().UnixMilli()},
	//	}},
	//	{Key: "userId", Value: 4323936494238720},
	//}

	filter := map[string]interface{}{
		"enable": true,
		"expire": bson.D{
			{"$gte", time.Now().UnixMilli()},
		},
		//"userId": 4323936494238720,
	}

	memberInfoList, _ := c.read.SecretMemberInfo.FindAll(context.Background(), filter)
	for _, item := range memberInfoList {
		logger.Infof(context.Background(), "quding1 %v", item)

		c.read.SecretMemberInfo.UpdateRedis(context.Background(), &item)
	}
}
