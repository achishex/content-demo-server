package content_mng

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/version"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"content_svr/setting"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"strconv"
	"time"
)

const (
	SendSessDefaultTTL = time.Hour * 24 * 2 //2-day
)

// SendSessComp 发送Session，控制用户发送消息数量
// 1. 对方未首次回复时，最多发x条消息
// 2. 对方首次回复后，每次最多发y条消息
// 说明：
//
//	未首次回复时，redis记录发送机会
//	首次回复后，redis记录发送次数
type SendSessComp struct {
	rcli *redis.Client
}

func NewSendSessComp(rcli *redis.Client) *SendSessComp {
	return &SendSessComp{
		rcli: rcli,
	}
}

func (c *SendSessComp) IsVIP(memberType int32) bool {
	return memberType > const_busi.NormalUser
}

func (c *SendSessComp) EnableTalkAD(ver string) bool {
	return setting.Maozhua.EnableTalkAD.Get() > 0 && ver >= version.TalkADVersion
}

// 按uid和nonce除重
func (c *SendSessComp) DistinctADUpload(ctx context.Context, sender, receiver int64, nonce string) (bool, error) {
	nonceKey := fmt.Sprintf("platform:sendsess:ad:upload:nonce:%v:%v", sender, nonce)
	uidKey := fmt.Sprintf("platform:sendsess:ad:upload:uid:%v", sender)
	res1, err := c.rcli.SetNX(ctx, uidKey, "1", time.Second*3).Result()
	if err != nil {
		return false, err
	}
	if !res1 {
		return false, nil
	}
	return c.rcli.SetNX(ctx, nonceKey, "1", time.Second*3).Result()
}

func (c *SendSessComp) GetNoReplySess(ctx context.Context, sender, receiver int64, curr int32, senderMemberType int32) (*pbapi.SendSess, error) {
	maxSend := setting.Maozhua.TalkADNoReplyMaxCount.Get()

	if curr >= maxSend {
		return &pbapi.SendSess{
			Max:    maxSend,
			Curr:   curr,
			Remain: 0,
		}, nil
	}

	if c.IsVIP(senderMemberType) { //vip免看广告
		remain := maxSend - curr
		if remain < 0 {
			remain = 0
		}

		return &pbapi.SendSess{
			Max:    maxSend,
			Curr:   curr,
			Remain: remain,
		}, nil
	}

	key := c.getNoReplyRemainKey(sender, receiver)
	remain, err := c.getRedisI64(ctx, key)
	if err != nil {
		return nil, err
	}
	return &pbapi.SendSess{
		Max:    maxSend,
		Curr:   curr,
		Remain: int32(remain),
	}, nil
}

func (c *SendSessComp) IncrNoReplySendRemain(ctx context.Context, sender, receiver int64) error {
	key := c.getNoReplyRemainKey(sender, receiver)
	_, err := c.rcli.Incr(ctx, key).Result()
	if err != nil {
		return err
	}

	_ = c.rcli.Expire(ctx, key, SendSessDefaultTTL).Err() // default ttl 2-day
	return nil
}

func (c *SendSessComp) DecrNoReplySendRemain(ctx context.Context, sender, receiver int64) error {
	key := c.getNoReplyRemainKey(sender, receiver)
	v, err := c.rcli.Decr(ctx, key).Result()
	if err != nil {
		return err
	}

	if v < 0 {
		return c.rcli.Del(ctx, key).Err()
	}

	return nil
}

func (c *SendSessComp) getNoReplyRemainKey(sender, receiver int64) string {
	return fmt.Sprintf("platform:sendsess:noreply:remain:%vto%v", sender, receiver)
}

func (c *SendSessComp) getSendSessKey(sender, receiver int64) string {
	return fmt.Sprintf("platform:sendsess:sess:count:%vto%v", sender, receiver)
}

func (c *SendSessComp) getRedisI64(ctx context.Context, key string) (int64, error) {
	str, err := c.rcli.Get(ctx, key).Result()
	if err != nil {
		if errors.Is(err, redis.Nil) {
			return 0, nil
		}
		return 0, err
	}

	v, err := strconv.ParseInt(str, 10, 64)
	return v, err
}

func (c *SendSessComp) ClearSendSessCount(ctx context.Context, sender, receiver int64) error {
	key := c.getSendSessKey(sender, receiver)
	_, err := c.rcli.Del(ctx, key).Result()
	return err
}

func (c *SendSessComp) IncrSendSessCount(ctx context.Context, sender, receiver int64) error {
	key := c.getSendSessKey(sender, receiver)
	_, err := c.rcli.Incr(ctx, key).Result()
	if err != nil {
		return err
	}

	_ = c.rcli.Expire(ctx, key, SendSessDefaultTTL).Err() // default ttl 2-day
	return nil
}

func (c *SendSessComp) GetSendSess(ctx context.Context, sender, receiver int64, senderMemberType int32) (*pbapi.SendSess, error) {
	maxI32 := int32(1<<31 - 1)
	if c.IsVIP(senderMemberType) {
		return &pbapi.SendSess{
			Max:    maxI32,
			Curr:   0,
			Remain: maxI32,
		}, nil
	}

	maxSend := int32(setting.Maozhua.TalkADSessSendCount.Get())

	key := c.getSendSessKey(sender, receiver)
	curr, err := c.getRedisI64(ctx, key)
	if err != nil {
		return nil, err
	}

	remain := maxSend - int32(curr)
	if remain < 0 {
		remain = 0
	}
	return &pbapi.SendSess{
		Max:    maxSend,
		Curr:   int32(curr),
		Remain: remain,
	}, nil

}
