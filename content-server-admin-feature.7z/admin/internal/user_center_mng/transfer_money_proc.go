package user_center_mng

import (
	"content_svr/config"
	"content_svr/db/mongodb/model"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/content_mng"
	"content_svr/internal/thirdparty/wechat_proxy"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"strconv"
	"time"
)

const (
	WithdrawOpTypeWithholding = 1 //扣款类型
	WithdrawOpTypeBackout     = 2 //退款类型
)
const (
	// 1: accept, 2: processing, 3: finished, 4: fail, 5: succ
	WithdrawStatusTypeAccept     = 1 // 支付方返回的状态在本地系统的定义： 接受支付
	WithdrawStatusTypeProcessing = 2 //支付方返回的状态在本地系统的定义：  支付处理中
	WithdrawStatusTypeFinished   = 3 //支付方返回的状态在本地系统的定义：  支付已完成
	WithdrawStatusTypeFail       = 4 //支付方返回的状态在本地系统的定义：  支付失败（因为关闭支付）
	WithdrawStatusOK             = 5 //支付成功，支付平台上的账单上显示成功
)

const (
	WaitTimeSecondAccept     = 10
	WaitTimeSecondProcessing = 10
	WaitTimeSecondFinished   = 5
)

type TransMoneyBusiness struct {
	Mng          *UserCenterMng
	recvNikeName string
	//
	transReqMsg *wechat_proxy.WeChatPayReq
	transResp   *wechat_proxy.WeChatPayResponse
	//
	memberId int64
}

func NewTransMoneyHandler(u *UserCenterMng, nickName string, memberId int64) *TransMoneyBusiness {
	return &TransMoneyBusiness{
		Mng:          u,
		recvNikeName: nickName,
		//
		transReqMsg: nil,
		transResp:   nil,
		//
		memberId: memberId,
	}
}
func (p *TransMoneyBusiness) CheckUserLocalStatus(ctx context.Context, userId int64, toWithdrawNums float32) (int32, error) {
	//查询流水表的最新状态。
	//查询可提现数是否大于 本次请求的提现数。
	remainAward, err := p.Mng.ContentMng.GetCanWithdrawAwardByUserId(ctx, userId)
	if err != nil || remainAward < 0.0001 {
		logger.Errorf(ctx, "has not enough award to withdraw for user: %v, can withdraw v: %v, err: %v", userId, remainAward, err)
		return WithdrawRetInit, errorcode.KoLaTransferMoneyFail
	}
	if toWithdrawNums-float32(remainAward) > 0 {
		logger.Errorf(ctx, "has not enough award to withdraw for user: %v, can withdraw v: %v, req Withdraw: %v", userId, remainAward, toWithdrawNums)
		return WithdrawRetInit, errorcode.KoLaTransferMoneyFail
	}

	withdrawItem, err := p.Mng.DataCache.GetImpl().KoLaWithdrawDetailMgModel.GetLatestItemByUserId(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get latest withdraw detail fail, err: %v, userId: %v", err, userId)
		return 0, err
	}
	if withdrawItem == nil {
		return WithdrawRetInit, nil
	}
	//检查正在提现中的状态。
	if withdrawItem.GetStatus() == WithdrawStatusTypeAccept ||
		withdrawItem.GetStatus() == WithdrawStatusTypeProcessing ||
		withdrawItem.GetStatus() == WithdrawStatusTypeFinished {
		logger.Infof(ctx, "user: %v is on %v [processing or accept or finished]", userId, withdrawItem.GetStatus())
		return WithdrawRetToasting, nil
	}

	return WithdrawRetInit, nil
}

func (p *TransMoneyBusiness) SendPayReq(ctx context.Context, req *pbuserapi.WithdrawReq, ret *pbuserapi.WithdrawResp, openId string) error {
	uniqBatchNo := snow_flake.GetSnowflakeID()
	moneyTransVal := int64(req.Amount * 100)

	if moneyTransVal < 10 {
		return fmt.Errorf("微信提现最低0.1元")
	}

	p.transReqMsg = &wechat_proxy.WeChatPayReq{
		AppId:       config.ServerConfig.WechatConfig.AppId,
		OutBatchNo:  strconv.FormatInt(uniqBatchNo, 10),
		BatchName:   "猫爪可乐计划-提现",
		BatchRemark: "上猫爪，有零花",
		TotalAmount: moneyTransVal, //以分为单位
		TotalNum:    1,             //默认是以一笔
	}

	uniqDetailNo := snow_flake.GetSnowflakeID()

	p.transReqMsg.TransferDetailList = append(p.transReqMsg.TransferDetailList, wechat_proxy.TransferItem{
		OutDetailNo:    strconv.FormatInt(uniqDetailNo, 10),
		TransferAmount: moneyTransVal,
		TransferRemark: "上猫爪，有零花",
		ReceiverOpenId: openId,
	})

	var err error

	p.transResp, err = p.Mng.WxProxy.TransferMoney(ctx, p.transReqMsg)
	if err != nil {
		logger.Errorf(ctx, "transfer money fail, err: %v, req: %s, tranReq: %#v", err, req, p.transReqMsg)
		ret.WithdrawStatus = WithdrawRetToastFailDesc
		return errorcode.KoLaTransferMoneyError
	}

	if p.transResp == nil {
		logger.Errorf(ctx, "trans response is nil, req: %s, tranReq: %#v", req, p.transReqMsg)
		ret.WithdrawStatus = WithdrawRetToastFailDesc
		return errorcode.KoLaTransferMoneyError
	}

	if p.transResp.CreateTime != nil {
		logger.Infof(ctx, "pay platform return create time: %s", p.transResp.CreateTime.String())
		ret.WithdrawTime = p.transResp.CreateTime.UnixMilli() / 1e3 // 返回给客户端的时间戳. unit second
	}
	return nil
}
func (p *TransMoneyBusiness) ProcessWithdrawOnLocal(ctx context.Context, authUserId int64) (int32, error) {
	status, err := WithdrawRetToasting, error(nil)

	switch p.transResp.BatchStatus {
	case wechat_proxy.TransStatusAccept:
		status, err = p.WithdrawingOnAccept(ctx, authUserId)

	case wechat_proxy.TransStatusProcessing:
		status, err = p.WithdrawingOnProcessing(ctx, authUserId)

	case wechat_proxy.TransStatusFinished:
		status, err = p.Withdrew(ctx, authUserId)

	case wechat_proxy.TransStatusClosed:
		status, err = p.WithdrawFail(ctx)
	}
	return status, err
}

// 处理转账结果
func (p *TransMoneyBusiness) ProcessQueryPayRetOnFail(ctx context.Context, status int32, withdrawDetail *pbmgdb.KoLaWithDrawDetail) error {
	id := snow_flake.GetSnowflakeID()
	superiorContentId := snow_flake.GetSnowflakeID()
	//
	withdrawDetailItem := &pbmgdb.KoLaWithDrawDetail{
		Id:                     id,
		UserId:                 proto.Int64(withdrawDetail.GetUserId()),
		NickName:               proto.String(withdrawDetail.GetNickName()),
		Account:                proto.Int64(withdrawDetail.GetAccount()),
		OutDetailNo:            proto.String(withdrawDetail.GetOutDetailNo()), //目前每批次只转一笔
		OutBatchNo:             proto.String(withdrawDetail.GetOutBatchNo()),
		BatchId:                proto.String(withdrawDetail.GetBatchId()),
		CreateTime:             proto.Int64(withdrawDetail.GetCreateTime()),
		Status:                 proto.Int32(WithdrawStatusTypeFail),
		Type:                   proto.Int32(WithdrawOpTypeBackout),
		SuperiorContentAwardId: proto.Int64(superiorContentId),
	}

	if err := p.Mng.DataCache.GetImpl().KoLaWithdrawDetailMgModel.InsertOne(ctx, withdrawDetailItem); err != nil {
		logger.Errorf(ctx, "insert withdraw detail on query_fail status, fail, err: %v, item: %v", err, withdrawDetailItem.String())
		return err
	}
	logger.Infof(ctx, "write tab: kola_withdraw_detail on fail, new item: %s", withdrawDetailItem.String())

	err := content_mng.NewSuperiorContentHandlerForWithdrawSucc(&content_mng.ContentMng{DataCache: p.Mng.DataCache}, superiorContentId).WriteNewItem(ctx, 0, withdrawDetail.GetUserId(), "",
		content_mng.TranFloatWith2Bit(float64(withdrawDetail.GetAccount())/100), model.WechatPayWithdrawFail)
	if err != nil {
		logger.Errorf(ctx, "write item fail, err: %v", err)
		return err
	}

	//latestAwardItem, err := p.Mng.ContentMng.GetAwardDetailLatestOnUser(ctx, withdrawDetail.GetUserId())
	//if err != nil || latestAwardItem == nil {
	//	logger.Errorf(ctx, "get latest award for userId: %v, fail, err: %v", withdrawDetail.GetUserId(), err)
	//	return err
	//}
	//
	//canWithdrawAward, err := p.Mng.ContentMng.GetCanWithdrawAward(ctx, latestAwardItem)
	//if err != nil {
	//	logger.Errorf(ctx, "get can withdraw award for userId: %v, fail, err: %v", withdrawDetail.GetUserId(), err)
	//	return err
	//}
	//
	//toInsertItem := &pbmgdb.SuperiorContentAwardDetail{
	//	Id:               superiorContentId,
	//	UserId:           proto.Int64(withdrawDetail.GetUserId()),
	//	SettlementType:   proto.Int32(const_busi.WechatPayWithdrawFail),
	//	Award:            proto.Float64(content_mng.TranFloatWith2Bit(float64(withdrawDetail.GetAccount()) / 100)),
	//	CreatTime:        proto.Int64(time.Now().UnixMilli()),
	//	TotalAward:       latestAwardItem.TotalAward,                                                                                                     //  1.
	//	CanWithdrawAward: proto.Float64(canWithdrawAward + content_mng.TranFloatWith2Bit(float64(withdrawDetail.GetAccount())/100)),                      // 2.
	//	HasWithdrewAward: proto.Float64(latestAwardItem.GetHasWithdrewAward() - content_mng.TranFloatWith2Bit(float64(withdrawDetail.GetAccount())/100)), // 3.
	//}
	//if err := p.Mng.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.InsertOneItem(ctx, toInsertItem); err != nil {
	//	logger.Errorf(ctx, "insert new item to tab: superior_content_award_detail on trans_fail, fail: %v, insert item: %s", err, toInsertItem.String())
	//	return err
	//}
	logger.Infof(ctx, "write tab: superior_content_award_detail, new item: %v", withdrawDetailItem)

	content_mng.NewDelayQueue(p.Mng.DataCache.GetImpl().RedisCli).ExcludeMsgItem(ctx, p.memberId, content_mng.GetWithdrawQueueKey())
	return nil
}
func (p *TransMoneyBusiness) ProcessQueryPayRetOnSucc(ctx context.Context, status int32, withdrawDetail *pbmgdb.KoLaWithDrawDetail) error {

	id := snow_flake.GetSnowflakeID()
	superiorContentId := snow_flake.GetSnowflakeID()

	withdrawDetailItem := &pbmgdb.KoLaWithDrawDetail{
		Id:                     id,
		UserId:                 proto.Int64(withdrawDetail.GetUserId()),
		NickName:               proto.String(withdrawDetail.GetNickName()),
		Account:                proto.Int64(withdrawDetail.GetAccount()),
		OutDetailNo:            proto.String(withdrawDetail.GetOutDetailNo()), //目前每批次只转一笔
		OutBatchNo:             proto.String(withdrawDetail.GetOutBatchNo()),
		BatchId:                proto.String(withdrawDetail.GetBatchId()),
		CreateTime:             proto.Int64(withdrawDetail.GetCreateTime()),
		Status:                 proto.Int32(WithdrawStatusOK),
		Type:                   proto.Int32(WithdrawOpTypeWithholding),
		SuperiorContentAwardId: proto.Int64(superiorContentId),
	}

	if err := p.Mng.DataCache.GetImpl().KoLaWithdrawDetailMgModel.InsertOne(ctx, withdrawDetailItem); err != nil {
		logger.Errorf(ctx, "insert withdraw detail on query_succ status, fail, err: %v, item: %v", err, withdrawDetailItem.String())
		return err
	}
	logger.Infof(ctx, "write tab: kola_withdraw_detail on succ, new item: %s", withdrawDetailItem.String())

	err := content_mng.NewSuperiorContentHandlerForWithdrawSucc(&content_mng.ContentMng{DataCache: p.Mng.DataCache}, superiorContentId).WriteNewItem(ctx, 0, withdrawDetail.GetUserId(), "",
		content_mng.TranFloatWith2Bit(float64(withdrawDetail.GetAccount())/100), model.WechatPayWithdrawSuccess)
	if err != nil {
		logger.Errorf(ctx, "write item fail, err: %v", err)
		return err
	}

	//钱包消息
	go func() {
		defer func() {
			if err := recover(); err != nil {
				logger.Errorf(ctx, "recover err : %v", err)
			}
		}()

		canWithdrawAward, _ := p.Mng.ContentMng.GetCanWithdrawAwardByUserId(ctx, withdrawDetail.GetUserId())
		msgData := &pbapi.Wallet{
			Type:       proto.Int32(const_busi.WalletMsgTypeWithdraw),
			Amount:     proto.String(strconv.FormatFloat(float64(withdrawDetail.GetAccount())/100, 'f', 2, 64)),
			Balance:    proto.String(strconv.FormatFloat(canWithdrawAward, 'f', 2, 64)),
			Desc:       proto.String("提现金额"),
			CreateTime: proto.Int64(time.Now().UnixMilli()),
		}

		if err := p.Mng.ContentMng.SendWalletMsg(ctx, withdrawDetail.GetUserId(), int32(pbconst.MessageTypeEnum_msg_type_wallet_award_notice), "您有一笔奖励金入账，快去看看吧！", msgData); err != nil {
			logger.Errorf(ctx, "sendWalletMsg error: %v", err)
		}
	}()

	//latestAwardItem, err := p.Mng.ContentMng.GetAwardDetailLatestOnUser(ctx, withdrawDetail.GetUserId())
	//if err != nil || latestAwardItem == nil {
	//	logger.Errorf(ctx, "get latest award for userId: %v, fail, err: %v", withdrawDetail.GetUserId(), err)
	//	return err
	//}
	//
	//canWithdrawAward, err := p.Mng.ContentMng.GetCanWithdrawAward(ctx, latestAwardItem)
	//if err != nil {
	//	logger.Errorf(ctx, "get can withdraw award for userId: %v, fail, err: %v", withdrawDetail.GetUserId(), err)
	//	return err
	//}
	//
	//toInsertItem := &pbmgdb.SuperiorContentAwardDetail{
	//	Id:               superiorContentId,
	//	UserId:           proto.Int64(withdrawDetail.GetUserId()),
	//	SettlementType:   proto.Int32(const_busi.WechatPayWithdrawSucc),
	//	Award:            proto.Float64(content_mng.TranFloatWith2Bit(float64(withdrawDetail.GetAccount()) / 100)),
	//	CreatTime:        proto.Int64(time.Now().UnixMilli()),
	//	TotalAward:       latestAwardItem.TotalAward, // 1.
	//	CanWithdrawAward: proto.Float64(canWithdrawAward), // 2.
	//	HasWithdrewAward: proto.Float64(latestAwardItem.GetHasWithdrewAward()), // 3.
	//}
	//if err := p.Mng.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.InsertOneItem(ctx, toInsertItem); err != nil {
	//	logger.Errorf(ctx, "insert new item to tab: superior_content_award_detail on succ_trans, fail: %v, insert item: %s", err, toInsertItem.String())
	//	return err
	//}
	//logger.Infof(ctx, "write tab: superior_content_award_detail, new item: %v", toInsertItem.String())

	content_mng.NewDelayQueue(p.Mng.DataCache.GetImpl().RedisCli).ExcludeMsgItem(ctx, p.memberId, content_mng.GetWithdrawQueueKey())
	return nil
}
func (p *TransMoneyBusiness) ProcessQueryPayResult(ctx context.Context, status int32, withdrawDetail *pbmgdb.KoLaWithDrawDetail) error {
	if withdrawDetail == nil {
		return nil
	}
	if status == WithdrawStatusTypeFail {
		return p.ProcessQueryPayRetOnFail(ctx, status, withdrawDetail)

	} else if status == WithdrawStatusOK {
		return p.ProcessQueryPayRetOnSucc(ctx, status, withdrawDetail)
	} else {

	}
	return nil
}

// 查询转账结果
func (p *TransMoneyBusiness) QueryTransferBatchResult(ctx context.Context, res *pbmgdb.KoLaWithDrawDetail) (map[int64]int32, error) {
	if p == nil || res == nil {
		return nil, errors.New("param is nil")
	}
	queryReq := &wechat_proxy.BatchQueryByMchIdReq{
		OutBatchNo:      res.GetOutBatchNo(),
		NeedQueryDetail: true,
		DetailStatus:    "ALL",
	}

	//
	//curCtx := context.WithValue(ctx, "testUserId", res.GetUserId())
	//
	queryRet, err := p.Mng.WxProxy.QueryBatchInfo(ctx, queryReq)
	if err != nil {
		logger.Errorf(ctx, "query pay status fail, err: %v", err)
		return nil, err
	}

	if queryRet == nil {
		logger.Errorf(ctx, "query pay status ret is nil")
		return nil, nil
	}

	waitReQueryTimeSecond := int32(WaitTimeSecondAccept)

	retMap := make(map[int64]int32)
	if queryRet.BatchStatus == wechat_proxy.TransStatusAccept {
		retMap[res.GetId()] = WithdrawStatusTypeAccept //
		waitReQueryTimeSecond = WaitTimeSecondAccept

	} else if queryRet.BatchStatus == wechat_proxy.TransStatusProcessing {
		retMap[res.GetId()] = WithdrawStatusTypeProcessing //
		waitReQueryTimeSecond = WaitTimeSecondProcessing

	} else if queryRet.BatchStatus == wechat_proxy.TransStatusFinished {
		retMap[res.GetId()] = WithdrawStatusTypeFinished //
		waitReQueryTimeSecond = WaitTimeSecondFinished

		//目前 一批只发 一笔支付
		if len(queryRet.TransferDetails) > 0 {
			if queryRet.TransferDetails[0].DetailStatus == wechat_proxy.DetailStatusInit {
				retMap[res.GetId()] = WithdrawStatusTypeProcessing
				waitReQueryTimeSecond = WaitTimeSecondProcessing

			} else if queryRet.TransferDetails[0].DetailStatus == wechat_proxy.DetailStatusWAITPAY {
				retMap[res.GetId()] = WithdrawStatusTypeProcessing
				waitReQueryTimeSecond = WaitTimeSecondProcessing

			} else if queryRet.TransferDetails[0].DetailStatus == wechat_proxy.DetailStatusProcessing {
				retMap[res.GetId()] = WithdrawStatusTypeProcessing
				waitReQueryTimeSecond = WaitTimeSecondProcessing

			} else if queryRet.TransferDetails[0].DetailStatus == wechat_proxy.DetailStatusSucc {
				retMap[res.GetId()] = WithdrawStatusOK

			} else if queryRet.TransferDetails[0].DetailStatus == wechat_proxy.DetailStatusFAIL {
				retMap[res.GetId()] = WithdrawStatusTypeFail
			}
		}
	} else if wechat_proxy.TransStatusClosed == queryRet.BatchStatus {
		logger.Errorf(ctx, "支付关闭，需要查找原因！")
		retMap[res.GetId()] = WithdrawStatusTypeFail

	} else if wechat_proxy.TransStatusWAITPAY == queryRet.BatchStatus {

		retMap[res.GetId()] = WithdrawStatusTypeProcessing
		waitReQueryTimeSecond = WaitTimeSecondAccept

		logger.Errorf(ctx, "need to 待付款确认。需要付款出资商户在商家助手小程序或服务商助手小程序进行付款确认")
	}

	if retMap[res.GetId()] == WithdrawStatusTypeProcessing ||
		retMap[res.GetId()] == WithdrawStatusTypeAccept ||
		retMap[res.GetId()] == WithdrawStatusTypeFinished {

		content_mng.NewWithdrawDelayQueue(p.Mng.DataCache.GetImpl().RedisCli).SendWithdrawItem(ctx, res.GetId(), waitReQueryTimeSecond)
	}
	return retMap, nil
}

// /
// /
// /

// 索引是：
func (p *TransMoneyBusiness) IsSameStatusOn(ctx context.Context, userId int64, status int32) (int32, error) {
	//索引： user_id, out_batch_no, out_detail_no, status
	filter := bson.D{
		{"user_id", userId},
		{"out_batch_no", p.transReqMsg.OutBatchNo},
		{"out_detail_no", p.transReqMsg.TransferDetailList[0].OutDetailNo},
		{"status", status},
	}
	item, err := p.Mng.DataCache.GetImpl().KoLaWithdrawDetailMgModel.FindOneItem(ctx, filter)
	if err != nil {
		logger.Infof(ctx, "find same status: %v fail, err: %v, userId: %v", status, err, userId)
		return WithdrawRetInit, err
	}
	if item != nil && (status == WithdrawStatusTypeAccept ||
		status == WithdrawStatusTypeProcessing ||
		status == WithdrawStatusTypeFinished) {
		return WithdrawRetToasting, nil
	} else if item != nil && status == WithdrawStatusOK {
		return WithdrawRetToastSucc, nil
	}
	return WithdrawRetInit, nil
}
func (p *TransMoneyBusiness) WriteLoggingOnStatus(ctx context.Context, userId int64, batchQueryStatus int32, delayTmSecond int32) (int32, error) {
	ret := WithdrawRetToasting
	id := snow_flake.GetSnowflakeID()
	superiorContentId := snow_flake.GetSnowflakeID()

	withdrawDetailItem := &pbmgdb.KoLaWithDrawDetail{
		Id:                     id,
		UserId:                 proto.Int64(userId),
		NickName:               proto.String(p.recvNikeName),
		Account:                proto.Int64(p.transReqMsg.TotalAmount),
		OutDetailNo:            proto.String(p.transReqMsg.TransferDetailList[0].OutDetailNo), //目前每批次只转一笔
		OutBatchNo:             proto.String(p.transReqMsg.OutBatchNo),
		BatchId:                proto.String(p.transResp.BatchId),
		CreateTime:             proto.Int64(p.transResp.CreateTime.UnixMilli()),
		Status:                 proto.Int32(batchQueryStatus),
		Type:                   proto.Int32(WithdrawOpTypeWithholding),
		SuperiorContentAwardId: proto.Int64(superiorContentId),
	}

	if err := p.Mng.DataCache.GetImpl().KoLaWithdrawDetailMgModel.InsertOne(ctx, withdrawDetailItem); err != nil {
		logger.Errorf(ctx, "insert withdraw detail on accept fail, err: %v, item: %v", err, withdrawDetailItem.String())
		ret = WithdrawRetToastFail
		return ret, err
	}

	defer func() {
		if ret == WithdrawRetToastFail {
			p.Mng.DataCache.GetImpl().KoLaWithdrawDetailMgModel.DeleteOneById(ctx, id)
		}
	}()

	err := content_mng.NewSuperiorContentHandlerForWithdrawing(&content_mng.ContentMng{DataCache: p.Mng.DataCache}, superiorContentId).WriteNewItem(ctx, 0, userId, "",
		content_mng.TranFloatWith2Bit(float64(p.transReqMsg.TotalAmount)/100), model.WechatPayWithdrawing)
	if err != nil {
		logger.Errorf(ctx, "write fail, userId: %v, err: %v", userId, err)
		ret = WithdrawRetToastFail
	}

	if batchQueryStatus == WaitTimeSecondFinished {
		//钱包消息
		go func() {
			defer func() {
				if err := recover(); err != nil {
					logger.Errorf(ctx, "recover err : %v", err)
				}
			}()

			canWithdrawAward, _ := p.Mng.ContentMng.GetCanWithdrawAwardByUserId(ctx, withdrawDetailItem.GetUserId())
			msgData := &pbapi.Wallet{
				Type:       proto.Int32(const_busi.WalletMsgTypeWithdraw),
				Amount:     proto.String(strconv.FormatFloat(float64(withdrawDetailItem.GetAccount())/100, 'f', 2, 64)),
				Balance:    proto.String(strconv.FormatFloat(canWithdrawAward, 'f', 2, 64)),
				Desc:       proto.String("提现金额"),
				CreateTime: proto.Int64(time.Now().UnixMilli()),
			}

			if err := p.Mng.ContentMng.SendWalletMsg(ctx, withdrawDetailItem.GetUserId(), int32(pbconst.MessageTypeEnum_msg_type_wallet_award_notice), "您有一笔奖励金入账，快去看看吧！", msgData); err != nil {
				logger.Errorf(ctx, "sendWalletMsg error: %v", err)
			}
		}()
	}

	//获取最新一条，

	//latestAwardItem, err := p.Mng.ContentMng.GetAwardDetailLatestOnUser(ctx, userId)
	//if err != nil || latestAwardItem == nil {
	//	logger.Errorf(ctx, "get latest award for userId: %v, fail, err: %v", userId, err)
	//	ret = WithdrawRetToastFail
	//	return ret, err
	//}
	//
	//canWithdrawAward, err := p.Mng.ContentMng.GetCanWithdrawAward(ctx, latestAwardItem)
	//if err != nil {
	//	logger.Errorf(ctx, "get can withdraw award for userId: %v, fail, err: %v", userId, err)
	//	ret = WithdrawRetToastFail
	//	return ret, err
	//}
	//if canWithdrawAward < 0.0001 {
	//	logger.Errorf(ctx, "has not enough award to  withdraw, canWithdrawAward: %v, userId: %v", canWithdrawAward, userId)
	//	ret = WithdrawRetToastFail
	//	return ret, nil
	//}
	//
	//toInsertItem := &pbmgdb.SuperiorContentAwardDetail{
	//	Id:               superiorContentId,
	//	UserId:           proto.Int64(userId),
	//	SettlementType:   proto.Int32(const_busi.WechatPayWithdrawing),
	//	Award:            proto.Float64(content_mng.TranFloatWith2Bit(float64(p.transReqMsg.TotalAmount) / 100)),
	//	CreatTime:        proto.Int64(time.Now().UnixMilli()),
	//	TotalAward:       latestAwardItem.TotalAward,
	//	CanWithdrawAward: proto.Float64(content_mng.TranFloatWith2Bit(canWithdrawAward - content_mng.TranFloatWith2Bit(float64(p.transReqMsg.TotalAmount)/100))),
	//	HasWithdrewAward: proto.Float64(latestAwardItem.GetHasWithdrewAward() + content_mng.TranFloatWith2Bit(float64(p.transReqMsg.TotalAmount)/100)),
	//}
	//if err := p.Mng.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.InsertOneItem(ctx, toInsertItem); err != nil {
	//	logger.Errorf(ctx, "insert new item to tab: superior_content_award_detail, fail: %v, insert item: %s", err, toInsertItem.String())
	//	ret = WithdrawRetToastFail
	//	return ret, err
	//}
	//
	//logger.Infof(ctx, "write tab: superior_content_award_detail, add new Item: %v", toInsertItem.String())
	//将这个待处理任务放到延迟

	if delayTmSecond <= 0 {
		delayTmSecond = 10 // 10 second
	}

	content_mng.NewWithdrawDelayQueue(p.Mng.DataCache.GetImpl().RedisCli).SendWithdrawItem(ctx, withdrawDetailItem.GetId(), delayTmSecond)
	return ret, nil
}

func (p *TransMoneyBusiness) IsOnSameAcceptStatus(ctx context.Context, userId int64) (int32, error) {
	//索引： user_id, out_batch_no, out_detail_no, status
	return p.IsSameStatusOn(ctx, userId, WithdrawStatusTypeAccept)
}
func (p *TransMoneyBusiness) WithdrawingOnAccept(ctx context.Context, userId int64) (int32, error) {
	//可提现金额   = 统计用户所有优质内容奖励金额 - 内容违规扣除金额 - 已经提现的金额
	//累计赢得金额 = 统计用户所有优质内容奖励金额 - 内容违规扣除金额
	//将本次转账记录到提现详情详情中。包括: userId, nickName, openid, account, out_detail_no, out_batch_no, batch_id, create_time, status, type
	//用户账户表： 累计赢得总额数，可提现金额，已提现现金额， 操作时间，
	//在superior_content_award_detail中，type 类型值新增一个值 4，提现到微信。 新增可提现数，

	if status, err := p.IsOnSameAcceptStatus(ctx, userId); err != nil {
		return WithdrawRetInit, err
	} else if status == WithdrawRetToasting {
		logger.Infof(ctx, "has exist some accept status,user id: %v", userId)
		return status, nil
	}

	ret, err := WithdrawRetToasting, error(nil)
	ret, err = p.WriteLoggingOnStatus(ctx, userId, WithdrawStatusTypeAccept, WaitTimeSecondAccept)
	return ret, err
}

func (p *TransMoneyBusiness) IsOnSameProcessing(ctx context.Context, userId int64) (int32, error) {
	return p.IsSameStatusOn(ctx, userId, WithdrawStatusTypeProcessing)
}
func (p *TransMoneyBusiness) WithdrawingOnProcessing(ctx context.Context, userId int64) (int32, error) {
	//可提现金额   = 统计用户所有优质内容奖励金额 - 内容违规扣除金额 - 已经提现的金额
	//累计赢得金额 = 统计用户所有优质内容奖励金额 - 内容违规扣除金额
	//将本次转账记录到提现详情详情中。包括: userId, nickName, openid, account, out_detail_no, out_batch_no, batch_id, create_time, status, type
	//用户账户表： 累计赢得总额数，可提现金额，已提现现金额， 操作时间，
	//在superior_content_award_detail中，type 类型值新增一个值 4，提现到微信。 新增可提现数，

	if status, err := p.IsOnSameProcessing(ctx, userId); err != nil {
		return 0, err
	} else if status == WithdrawRetToasting {
		logger.Infof(ctx, "has exist some processing status,user id: %v", userId)
		return status, nil
	}
	ret, err := WithdrawRetToasting, error(nil)
	ret, err = p.WriteLoggingOnStatus(ctx, userId, WithdrawStatusTypeProcessing, WaitTimeSecondProcessing)
	return ret, err
}

func (p *TransMoneyBusiness) IsOnSameFinished(ctx context.Context, userId int64) (int32, error) {
	return p.IsSameStatusOn(ctx, userId, WithdrawStatusTypeFinished)
}
func (p *TransMoneyBusiness) Withdrew(ctx context.Context, userId int64) (int32, error) {
	if status, err := p.IsOnSameFinished(ctx, userId); err != nil {
		return 0, err
	} else if status == WithdrawRetToasting {
		logger.Infof(ctx, "has exist some finish status,user id: %v", userId)
		return status, nil
	}
	ret, err := WithdrawRetToasting, error(nil)
	ret, err = p.WriteLoggingOnStatus(ctx, userId, WithdrawStatusTypeFinished, WaitTimeSecondFinished)
	return ret, err
}

func (p *TransMoneyBusiness) WithdrawFail(ctx context.Context) (int32, error) {
	var ret int32 = WithdrawRetToastSucc
	if p.transResp.BatchStatus == wechat_proxy.TransStatusClosed {
		logger.Errorf(ctx, "trans money fail, req: %#v, resp: %s", p.transReqMsg, p.transResp)
		ret := WithdrawRetToastFail
		return ret, errors.New(fmt.Sprintf("%v", p.transResp.String()))
	}
	return ret, nil
}
