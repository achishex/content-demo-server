package dau

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"

	"github.com/zeromicro/go-zero/core/logx"
)

type GameListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGameListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GameListLogic {
	return &GameListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

type resultItem struct {
	Day      int64  `bson:"day"`
	GameName string `bson:"game_name"`
	GameId   string `bson:"game_id"`
	Count    int64  `bson:"count"`
}

func (l *GameListLogic) GameList(req *types.DauGameListReq) (resp *types.DauGameListResp, err error) {
	var (
		pipeline []bson.M
		list     []*resultItem
	)

	if req.TimeStart > 0 || req.TimeEnd > 0 {
		var match []bson.M
		if req.TimeStart > 0 {
			match = append(match, bson.M{"$gt": req.TimeStart})
		}
		if req.TimeEnd > 0 {
			match = append(match, bson.M{"$lt": req.TimeEnd})
		}
		pipeline = append(pipeline, bson.M{
			"$match": match,
		})
	}

	if req.Type == "" {
		req.Type = "UV"
	}

	switch req.Type {
	case "UV":
		pipeline = []bson.M{
			{
				"$group": bson.M{
					"_id":   bson.M{"game_name": "$game_name", "game_id": "$game_id", "day": "$day"},
					"count": bson.M{"$sum": 1},
				},
			},
			{
				"$project": bson.M{
					"_id":       false,
					"game_name": "$_id.game_name",
					"game_id":   "$_id.game_id",
					"day":       "$_id.day",
					"count":     true,
				},
			},
		}
	case "PV":
		pipeline = []bson.M{
			{
				"$group": bson.M{
					"_id":   bson.M{"game_name": "$game_name", "game_id": "$game_id", "day": "$day"},
					"count": bson.M{"$sum": "$user_pv"},
				},
			},
			{
				"$project": bson.M{
					"_id":       false,
					"game_name": "$_id.game_name",
					"game_id":   "$_id.game_id",
					"day":       "$_id.day",
					"count":     true,
				},
			},
		}
	}

	pipeline = append(pipeline, bson.M{
		"$sort": bson.M{"day": 1},
	})

	if err = l.svcCtx.ReadDB.SecretGameStatisticDaily.Aggregate(l.ctx, &list, pipeline); err != nil {
		return nil, err
	}

	var (
		result    = make(map[string][]types.DauGameItem)
		respList  = make(map[string][]types.DauGameItem)
		dayFilter = make(map[int64]struct{})
		days      []int64
		games     = make(map[string]string)
	)

	for _, v := range list {
		if _, ok := dayFilter[v.Day]; !ok {
			dayFilter[v.Day] = struct{}{}
			days = append(days, v.Day)
		}

		item := types.DauGameItem{
			Date:     v.Day,
			Count:    v.Count,
			GameName: v.GameName,
			GameId:   v.GameId,
		}
		key := fmt.Sprintf("GAME_%s", v.GameId)
		result[key] = append(result[key], item)

		if _, ok := games[key]; !ok && v.GameName != "" {
			games[key] = v.GameName
		}
	}

	for key, items := range result {
		for _, day := range days {
			isExists := false
			for _, item := range items {
				if item.Date == day {
					isExists = true
					item.GameName = games[key]
					respList[key] = append(respList[key], item)
					break
				}
			}

			if !isExists {
				respList[key] = append(respList[key], types.DauGameItem{
					Date:     day,
					GameName: games[key],
				})
			}
		}
	}

	resp = &types.DauGameListResp{
		List: respList,
	}

	return resp, nil
}
