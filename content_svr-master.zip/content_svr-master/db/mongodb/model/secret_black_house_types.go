package model

const SecretBlackHouseCollectionName = "personalBlackHouseDetail"

type SecretBlackHouse struct {
	ID     int64 `bson:"_id" json:"id"`
	UserId int64 `bson:"userId" json:"userId"`
	Start  int64 `bson:"start" json:"start"`
	End    int64 `bson:"end" json:"end"`
	Status int64 `bson:"status" json:"status"`
}
