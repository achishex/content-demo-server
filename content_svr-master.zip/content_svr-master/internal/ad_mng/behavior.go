package ad_mng

import (
	"bytes"
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"crypto/md5"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/go-resty/resty/v2"
	jsoniter "github.com/json-iterator/go"
	"github.com/zeromicro/go-zero/core/jsonx"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
)

type BehaviorUpCtrl struct {
	DataCache data_cache.IDataCacheMng
}

func NewBehaviorUpCtrl(dataCache data_cache.IDataCacheMng) *BehaviorUpCtrl {
	return &BehaviorUpCtrl{DataCache: dataCache}
}

func (b BehaviorUpCtrl) SetCallbackData(ctx context.Context, channel, data string, machineIds ...string) {
	for _, machineId := range machineIds {
		if machineId == "" {
			continue
		}
		_ = b.DataCache.GetImpl().SetRedisAdCallback(ctx, channel, machineId, data)
	}
}

func (b BehaviorUpCtrl) GetCallbackData(ctx context.Context, channel string, machineIds ...string) string {
	for _, machineId := range machineIds {
		if machineId == "" {
			continue
		}
		data := b.DataCache.GetImpl().GetRedisAdCallback(ctx, channel, machineId)
		if len(data) != 0 {
			return data
		}
	}

	return ""
}

func (b BehaviorUpCtrl) Xiaomi2(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (bool, error) {
	data := b.DataCache.GetRedisAdCallback(ctx, cm_const.AppChannelXiaomi, req.Oaid)
	if data == "" {
		data = b.DataCache.GetRedisAdCallback(ctx, cm_const.AppChannelXiaomi, req.Imei)
	}
	if data == "" {
		logger.Errorf(ctx, "找不到 xiaomi imei oaid")
		return false, nil
	}

	params := &pbapi.AdXiaomiFeedbackReq{}
	if err := json.Unmarshal([]byte(data), &params); err != nil {
		return false, err
	}

	switch req.GetType() {
	case const_busi.BehaviorTypeActivate:
		params.ConvType = "APP_ACTIVE"
	case const_busi.BehaviorTypeRegister:
		params.ConvType = "APP_REGISTER"
	case const_busi.BehaviorTypePay:

	}

	logger.Infof(ctx, "xiaomi behavior imei: %s oaid: %s request:%v", req.Imei, req.Oaid, params)
	if err := adXiaomiCallback(ctx, params); err != nil {
		return false, err
	}

	return false, nil
}

func (b BehaviorUpCtrl) Xiaomi(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	// http://trail.e.mi.com/api/callback?callback=FqK3xF8WvgkYJGU4NDJkNjQwLWI2MzMtNDMxYS1hNTA0LTcyND
	// VhNWEyMDE2YlgQMTJhN2Y5ZGVjNTdhZGRhNBgFQ0xJQ0sA&oaid=12a7f9dec57adda4&conv_time=1635335972760&convType=APP_ACTIVE
	now := time.Now()
	urlString := "http://trail.e.mi.com/global/log"

	// 生成签名
	type pair struct {
		key   string
		value string
	}
	buildInfo := func(device []pair, signKey string, encryptKey string) string {
		//queryString 设备信息
		query := ""
		for i, p := range device {
			and := ""
			if i != 0 {
				and = "&"
			}
			query += fmt.Sprintf("%s%s=%s", and, p.key, p.value)
		}
		query1 := url.QueryEscape(query)
		//md5后的sign值
		sign := fmt.Sprintf("%x", md5.Sum([]byte(signKey+"&"+query1)))
		//baseData
		baseData := query + "&sign=" + sign

		l2 := len(encryptKey)
		var res []byte
		for i := range baseData {
			u := baseData[i] ^ encryptKey[i%l2]&0xFF
			res = append(res, u)
		}
		return url.QueryEscape(base64.StdEncoding.EncodeToString(res))
	}

	// 需要的参数值
	appId := "914866"
	customerId := "491842"
	info := ""     // 签名
	convType := "" // APP_ACTIVE 自定义激活  APP_REGISTER 自定义注册

	device := make([]pair, 0)
	if req.Imei != "" {
		device = append(device, pair{"imei", utils.MD5(req.Imei)})
	}
	if req.Oaid != "" && req.Imei == "" {
		device = append(device, pair{"oaid", req.Oaid})
	}
	device = append(device, pair{"conv_time", strconv.FormatInt(now.UnixMilli(), 10)})
	switch req.Type {
	case 1:
		convType = "APP_ACTIVE" // 自定义激活
		info = buildInfo(device, "XZEHduHOsLyBPhuA", "tLCJdIZqucpWOmFH")
	case 2:
		convType = "APP_REGISTER" // 自定义注册
		info = buildInfo(device, "dqhAqGfNOsZMoSld", "MIhXhHbOvasPGMlM")
	case 3:
		convType = "APP_PAY" // 自定义付费
		info = buildInfo(device, "RkMTolKgtNQzDUPa", "NMAYpjowYLmpkDKN")
	}

	// 构建请求链接
	u, err := url.Parse(urlString)
	if err != nil {
		logger.Error(ctx, "url.Parse", err)
		return err
	}
	query := u.Query()
	query.Set("appId", appId)
	query.Set("customer_id", customerId)
	query.Set("info", info)
	query.Set("conv_type", convType)
	u.RawQuery = query.Encode()

	client := resty.New()
	r, err := client.R().Get(u.String())
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return err
	}
	logger.Infof(ctx, "imei: %s oaid: %s xiaomi behavior request:%v", req.Imei, req.Oaid, u.String())
	logger.Infof(ctx, "xiaomi behavior response:%v", r.String())
	return nil
}

func (b BehaviorUpCtrl) WangYi(ctx context.Context, h *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	logger.Infof(ctx, "rec wangyi upload, header %v req %+v", h, req)
	data := b.DataCache.GetRedisAdCallback(ctx, cm_const.AppChannelWangYi, req.Oaid)
	if data == "" && req.Imei != "" {
		imeiMD5 := strings.ToUpper(utils.MD5(req.Imei))
		data = b.DataCache.GetRedisAdCallback(ctx, cm_const.AppChannelWangYi, imeiMD5)
	}
	if data == "" {
		logger.Errorf(ctx, "empty wangyi imei oaid")
		return nil
	}
	logger.Infof(ctx, "get wangyi cb data %s", data)
	fb := &pbapi.WangyiFeedbackReq{}
	err := json.Unmarshal([]byte(data), fb)
	if err != nil {
		logger.Errorf(ctx, "malform json, err %v", err)
		return nil
	}
	if fb.Conv == "" {
		logger.Errorf(ctx, "empty wangyi conv, req %+v, fb %+v", req, fb)
		return nil
	}

	uri := "https://conv.youdao.com/api/track"

	convAction := "android_download"
	// 1 自定义激活  2 自定义注册 3 自定义付费 4 自定义次留
	switch req.Type {
	case 1:
		convAction = "android_activate"
	case 2:
		convAction = "android_register"
	case 3:
		convAction = ""
	case 4:
		convAction = "android_day1retention"
	}
	if convAction == "" {
		logger.Errorf(ctx, "unknown type %v", req.Type)
		return nil
	}

	vv := url.Values{}
	vv.Set("conv_ext", fb.Conv)
	vv.Set("conv_action", convAction)

	hreq, _ := http.NewRequest(http.MethodGet, fmt.Sprintf("%s?%s", uri, vv.Encode()), nil)
	hresp, err := utils.DefaultHTTPClient.Do(hreq)
	if err != nil {
		logger.Errorf(ctx, "do http req fail, err %v", err)
		return err
	}
	defer hresp.Body.Close()
	bs, _ := io.ReadAll(hresp.Body)
	if hresp.StatusCode != http.StatusOK {
		logger.Errorf(ctx, "resp fail, code %v, body %s", hresp.StatusCode, bs)
		return nil
	}
	if jsoniter.Get(bs, "code").ToString() != "success" {
		logger.Errorf(ctx, "wangyi upload fail, body %s", bs)
		return nil
	}

	logger.Infof(ctx, "wangyi upload succ, body %s", bs)
	return nil
}

func (b BehaviorUpCtrl) Huawei(ctx context.Context, h *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	logger.Infof(ctx, "rec huawei upload, header %v req %+v", h, req)
	data := b.DataCache.GetRedisAdCallback(ctx, cm_const.AppChannelHuaWei, req.Oaid)
	if data == "" && req.Imei != "" {
		imeiMD5 := strings.ToUpper(utils.MD5(req.Imei))
		data = b.DataCache.GetRedisAdCallback(ctx, cm_const.AppChannelHuaWei, imeiMD5)
	}
	if data == "" {
		logger.Errorf(ctx, "empty huawei imei oaid")
		return nil
	}
	logger.Infof(ctx, "get huawei cb data %s", data)

	actionType := ""
	// 接口定义 1 自定义激活  2 自定义注册 3 自定义付费 4 自定义次留
	// https://developer.huawei.com/consumer/cn/doc/promotion/bp-functions-ocpd-interface-return-0000001238484400
	switch req.Type {
	case 1:
		actionType = "1"
	case 2:
		actionType = "7"
	case 4:
		actionType = "3"
	}

	if actionType == "" {
		logger.Errorf(ctx, "unknown type %v", req.Type)
		return nil
	}

	nxkey := fmt.Sprintf("huawei_accessToken:%v", req.Oaid)
	callBack, err := b.DataCache.GetImpl().RedisCli.Get(ctx, nxkey).Result()
	if len(callBack) == 0 {
		logger.Errorf(ctx, "unknown accessToken %v", req.Type)
		return nil
	}

	huaweiReq := &pbapi.HuaweiReportReq{
		AppId:        "101195435",
		DeviceIdType: "OAID",
		DeviceId:     req.Oaid,
		ActionTime:   time.Now().UnixMilli(),
		ActionType:   actionType,
		CallBack:     callBack,
	}
	body, _ := json.Marshal(huaweiReq)

	url := "https://connect-api.cloud.huawei.com/api/datasource/v1/track/activate"
	hreq, err := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(body))

	// header
	hreq.Header.Add("client_id", "1471858680101091968")

	accesstoken, err := b.getHuaweiToken()
	if err != nil {
		logger.Errorf(ctx, "get accesstoken, err %v", err)
		return err
	}

	var bearer = "Bearer " + accesstoken
	hreq.Header.Add("Authorization", bearer)

	hresp, err := utils.DefaultHTTPClient.Do(hreq)
	if err != nil {
		logger.Errorf(ctx, "do http req fail, err %v", err)
		return err
	}
	defer hresp.Body.Close()
	bs, _ := io.ReadAll(hresp.Body)
	if hresp.StatusCode != http.StatusOK {
		logger.Errorf(ctx, "resp fail, code %v, body %s", hresp.StatusCode, bs)
		return nil
	}

	logger.Infof(ctx, "huawei upload succ, body %s", bs)
	return nil
}

func (b BehaviorUpCtrl) getHuaweiToken() (string, error) {
	url := "https://connect-api.cloud.huawei.com/api/oauth2/v1/token"

	huaweiReq := &pbapi.HuaweiAccessTokenReq{
		GrantType:    "client_credentials",
		ClientId:     "1471858680101091968",
		ClientSecret: "51BC9D6EF6AD168D34010D5DCF58D54095F80C14AF72A58909CE46C25A8D7CEA",
	}

	body, _ := json.Marshal(huaweiReq)

	req, err := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(body))
	if err != nil {
		return "", err
	}
	req.Header.Add("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}

	sRespBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	// 解析
	Resp := &pbapi.HuaweiAccessTokenResp{}
	err = json.Unmarshal(sRespBytes, Resp)
	if err != nil {
		return "", err
	}

	return Resp.AccessToken, nil
}

func (b BehaviorUpCtrl) Oppo(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	now := time.Now()

	salt := "e0u6fnlag06lc3pl"
	aesKeyBase64 := "XGAXicVG5GMBsx5bueOe4w=="
	urlString := "https://api.ads.heytapmobi.com/api/uploadActiveData"

	// 加密imei和oaid
	aesKey, _ := base64.StdEncoding.DecodeString(aesKeyBase64)
	var imei, ouid string
	var err error
	if len(req.GetImei()) != 0 {
		imei, err = utils.AESEncrypt([]byte(req.GetImei()), aesKey)
		if err != nil {
			logger.Error(ctx, "utils.AESEncrypt", err)
			return err
		}
	}
	if len(req.GetOaid()) != 0 && len(req.GetImei()) == 0 {
		ouid, err = utils.AESEncrypt([]byte(req.GetOaid()), aesKey)
		if err != nil {
			logger.Error(ctx, "utils.AESEncrypt", err)
			return err
		}
	}

	if req.Type == 3 {
		req.Type = 7 // oppo 应用付费类型为 7
	}

	body := map[string]interface{}{
		"imei":        imei,             //  imei 经过 AES 加密后的值
		"ouId":        ouid,             // 开发者 ID 经过 AES 加密后的值
		"timestamp":   now.UnixMilli(),  // 事 件 发 生 的 时 间戳 ( 毫 秒 ) ， 如1522221766623
		"pkg":         "com.xiyou.miao", // 包名，如 com.xxx或者填，快应用 id，如 100137
		"dataType":    req.Type,         // 转化数据类型： 1、激活， 2、注册 3、游戏付费
		"channel":     1,                // 渠道：1、OPPO，2、一加，0、其他
		"type":        0,                // 0：无加密（默认为 0）1：imei md5 加密2：oaid md5 加密
		"ascribeType": 0,                // 归因类型：1：广告主归因，0：OPPO归因（默认或者不填即为 0），2：助攻归因
		//"adId":        314156384,        // 请求 id
	}

	// 生成签名
	timestamp := strconv.FormatInt(now.UnixMilli(), 10)
	content, err := jsonx.MarshalToString(body)
	if err != nil {
		logger.Error(ctx, "jsonx.MarshalToString", err)
		return err
	}
	content = content + timestamp + salt
	sign := utils.MD5(content)

	client := resty.New()
	r, err := client.R().
		SetHeader("Content-Type", "application/json").
		SetHeader("signature", sign). // 签名
		SetHeader("timestamp", timestamp).
		SetBody(body).
		Post(urlString)
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return err
	}

	logger.Infof(ctx, "imei: %s oaid: %s oppo behavior request: %v", req.Imei, req.Oaid, r.Request)
	logger.Infof(ctx, "oppo behavior response: %v", r.String())
	return nil
}

func (b BehaviorUpCtrl) Vivo(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	if len(req.GetOaid()) == 0 && len(req.GetImei()) == 0 && req.GetType() > 0 {
		logger.Errorf(ctx, "quding-vivo, 参数不全，没有 oaid 或 imei 或 type")
		return errors.New("参数不全")
	}

	type item struct {
		CvTime     int64  `json:"cvTime"`
		CvType     string `json:"cvType"`
		UserId     string `json:"userId"`
		UserIdType string `json:"userIdType"`
		CvCustom   string `json:"cvCustom"`
	}

	cvType := "ACTIVATION"
	if req.GetType() == const_busi.BehaviorTypeRegister {
		cvType = "REGISTER" //注册
	} else if req.GetType() == const_busi.BehaviorTypePay {
		cvType = "PAY" // 自定义付费
	} else if req.GetType() == const_busi.BehaviorTypeNextDayRetention {
		cvType = "RETENTION_1"
	}

	userId := ""
	UserIdType := ""
	if len(req.GetOaid()) > 0 {
		userId = req.GetOaid()
		UserIdType = "OAID"
	} else if len(req.GetImei()) > 0 {
		userId = req.GetImei()
		UserIdType = "IMEI"
	}

	dataList := []item{
		{
			CvTime:     time.Now().UnixMilli(),
			CvType:     cvType,
			UserId:     userId,
			UserIdType: UserIdType,
			CvCustom:   "",
		},
	}

	logger.Infof(ctx, "channel %v,vivo_dataList url %#v", header.GetChannel(), dataList)

	adConfig := config.ServerConfig.AdConfig
	body := map[string]any{
		"srcType":  "APP",
		"srcId":    adConfig.Vivo.SrcId,
		"pkgName":  "com.xiyou.miao",
		"dataList": dataList,
	}

	logger.Infof(ctx, "vivo_body url %#v", body)

	h := md5.New()
	h.Write([]byte(strconv.FormatInt(time.Now().UnixMicro(), 10)))
	nonce := hex.EncodeToString(h.Sum(nil))

	urlString := fmt.Sprintf("%s?access_token=%s&timestamp=%d&nonce=%s&advertiser_id=%s",
		adConfig.Vivo.Url,
		adConfig.Vivo.AccessToken,
		time.Now().UnixMilli(),
		nonce,
		adConfig.Vivo.AdvertiserId)

	client := resty.New()
	r, err := client.R().
		SetHeader("Content-Type", "application/json").
		SetBody(body).
		Post(urlString)
	if err != nil {
		logger.Errorf(ctx, "quding-vivo, http error:", err)
		return err
	}

	logger.Infof(ctx, "imei: %s oaid: %s vivo behavior request: %v", req.Imei, req.Oaid, urlString)
	logger.Infof(ctx, "vivo_http response", r.String())
	return nil
}

func (b BehaviorUpCtrl) Baidu(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (bool, error) {
	var joinType string
	data := b.GetCallbackData(ctx, cm_const.AppChannelBaidu, req.Oaid)
	joinType = "oaid"
	if data == "" {
		if data = b.GetCallbackData(ctx, cm_const.AppChannelBaidu, req.Imei); data == "" {
			logger.Errorf(ctx, "找不到 baidu imei oaid")
			return false, nil
		}
		joinType = "imei"
	}

	params := &pbapi.AdBaiduFeedbackReq{}
	if err := json.Unmarshal([]byte(data), &params); err != nil {
		return false, err
	}
	params.JoinType = joinType
	switch req.GetType() {
	case const_busi.BehaviorTypeActivate:
		params.AType = "activate"
	case const_busi.BehaviorTypeRegister:
		params.AType = "register"
	case const_busi.BehaviorTypePay:
	case const_busi.BehaviorTypeNextDayRetention:
		params.AType = "retain_1day"
	}

	logger.Infof(ctx, "imei: %s oaid: %s xiaomi behavior params:%v", req.Imei, req.Oaid, params)
	ok, err := adBaiduCallback(ctx, params)
	if err != nil {
		return false, err
	}

	return ok, nil
}

func (b BehaviorUpCtrl) Toutiao(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (bool, error) {
	data := b.GetCallbackData(ctx, cm_const.AppChannelToutiao, req.Oaid, req.Imei)

	params := &pbapi.AdToutiaoFeedbackReq{}
	if err := json.Unmarshal([]byte(data), &params); err != nil {
		return false, err
	}

	switch req.GetType() {
	case const_busi.BehaviorTypeActivate:
		params.EventType = "active"
	case const_busi.BehaviorTypeRegister:
		params.EventType = "active_register"
	case const_busi.BehaviorTypePay:
	case const_busi.BehaviorTypeNextDayRetention:
		params.EventType = "next_day_open"
	}

	logger.Infof(ctx, "toutiao behavior imei: %s oaid: %s request:%v", req.Imei, req.Oaid, params)
	ok, err := adToutiaoCallback(ctx, params)
	if err != nil {
		return false, err
	}
	return ok, nil
}

func (b BehaviorUpCtrl) Xingtu(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (bool, error) {
	//data := b.GetCallbackData(ctx, cm_const.AppChannelXingtu, req.Oaid, req.Imei)
	//
	//params := &pbapi.AdXingtuFeedbackReq{}
	//if err := json.Unmarshal([]byte(data), &params); err != nil {
	//	return false, err
	//}
	//switch req.GetType() {
	//case const_busi.BehaviorTypeActivate:
	//	params.EventType = 0
	//case const_busi.BehaviorTypeRegister:
	//	params.EventType = 1
	//case const_busi.BehaviorTypePay:
	//}
	//
	//logger.Infof(ctx, "xingtu behavior imei: %s oaid: %s request:%v", req.Imei, req.Oaid, params)
	//ok, err := adXingtuCallback(ctx, params)
	//if err != nil {
	//	return false, err
	//}
	//
	//return ok, nil

	// 星图使用和头条同一种方式上报
	data := b.GetCallbackData(ctx, cm_const.AppChannelXingtu, req.Oaid, req.Imei)
	params := &pbapi.AdToutiaoFeedbackReq{}
	if err := json.Unmarshal([]byte(data), &params); err != nil {
		return false, err
	}

	switch req.GetType() {
	case const_busi.BehaviorTypeActivate:
		params.EventType = "active"
	case const_busi.BehaviorTypeRegister:
		params.EventType = "active_register"
	case const_busi.BehaviorTypePay:
	case const_busi.BehaviorTypeNextDayRetention:
		params.EventType = "next_day_open"
	}

	logger.Infof(ctx, "toutiao behavior imei: %s oaid: %s request:%v", req.Imei, req.Oaid, params)
	ok, err := adToutiaoCallback(ctx, params)
	if err != nil {
		return false, err
	}
	return ok, nil
}

func (b BehaviorUpCtrl) KuaiShou(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (bool, error) {
	oaid := utils.MD5(req.Oaid)
	data := b.GetCallbackData(ctx, cm_const.AppChannelKuaiShou, oaid, req.Imei)
	params := &pbapi.AdKuaiShouFeedbackReq{}
	if err := json.Unmarshal([]byte(data), &params); err != nil {
		return false, err
	}

	switch req.GetType() {
	case const_busi.BehaviorTypeActivate:
		params.EventType = 1
	case const_busi.BehaviorTypeRegister:
		params.EventType = 2
	case const_busi.BehaviorTypePay:
	case const_busi.BehaviorTypeNextDayRetention:
		params.EventType = 7
	}

	logger.Infof(ctx, "kuaishou behavior imei: %s oaid: %s request:%v", req.Imei, oaid, params)
	ok, err := adKuaiShouCallback(ctx, params)
	if err != nil {
		return false, err
	}

	return ok, nil
}
