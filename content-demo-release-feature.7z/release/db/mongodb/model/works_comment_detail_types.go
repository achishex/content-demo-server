package model

type WorksCommentDetail struct {
	ID            int64                  `json:"id,omitempty" bson:"_id,omitempty"`
	WorkId        int64                  `json:"work_id,omitempty" bson:"work_id,omitempty"`           //作品的id
	UserId        int64                  `json:"user_id,omitempty" bson:"user_id,omitempty"`           //评论发布人的id
	Comment       string                 `json:"comment,omitempty" bson:"comment,omitempty"`           //评论内容
	Longitude     float64                `json:"longitude,omitempty" bson:"longitude,omitempty"`       // 经度
	Latitude      float64                `json:"latitude,omitempty" bson:"latitude,omitempty"`         // 纬度
	Ip            string                 `json:"ip,omitempty" bson:"ip,omitempty"`                     // 评论时ip
	Province      string                 `json:"province,omitempty" bson:"province,omitempty"`         //评论时省份
	City          string                 `json:"city,omitempty" bson:"city,omitempty"`                 //城市
	Status        int32                  `json:"status,omitempty" bson:"status,omitempty"`             //评论的状态, 0:无效；1:有效；2:删除
	CreateTime    string                 ` json:"create_time,omitempty" bson:"create_time,omitempty"`  //创建时间
	UpdateTime    string                 `json:"update_time,omitempty" bson:"update_time,omitempty"`   //  update_time
	LikedCount    int64                  `json:"liked_count,omitempty" bson:"liked_count,omitempty"`   // 点赞数量
	CommentType   int32                  `json:"comment_type,omitempty" bson:"comment_type,omitempty"` // 该条评论的类型
	CommentObject *WorkCommentObjectAttr `json:"comment_object,omitempty" bson:"comment_object,omitempty"`
}

type WorkCommentObjectAttr struct {
	Width     int32  `json:"width" form:"width"`
	High      int32  `json:"high" form:"high"`
	ObjectId  string `json:"object_id" form:"object_id"` // 对应阿里云资源的url
	ThumbNail string `json:"-" form:"thumb_nail"`        // 视频的截图地址
	ImgMd5    string `json:"-" form:"img_md5"`           // 图片的MD5值
	MemeId    int64  `json:"meme_id" form:"meme_id"`     // 表情id
}
