package data_cache

import (
	zeroModel "content_svr/db/mongodb/model"
	"content_svr/internal/mg_model"
	"content_svr/internal/model"
	"content_svr/internal/model/im"
	"content_svr/internal/thirdparty/baidu_lbs_yun_proxy"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/utils"
	"context"
	go_cache "github.com/fanjindong/go-cache"
	rdsV8 "github.com/go-redis/redis/v8"
)

type DataCacheMng struct {
	//mg_db
	UserAwardSummaryMgModel           mg_model.IUserAwardSummaryMgModel
	KoLaWithdrawDetailMgModel         mg_model.IKoLaWithdrawDetailMgModel
	SuperiorContentAwardDetailMgModel mg_model.ISuperiorContentAwardDetailMgModel
	NotificationReadCursorMgDbModel   mg_model.INotificationReadCursorMgDbModel
	CommentLikeDetailMgModel          mg_model.ICommentLikeDetailMgModel
	UserRemindDetail                  mg_model.IUserRemindDetailMgDbModel
	SecretMemberInfoMgModel           mg_model.ISecretMemberInfoMgModel
	SecretReport                      mg_model.ISecretReportMgModel
	SportActivityMgModel              mg_model.ISportActivityMgModel
	PersonalUserAccountMgDbModel      mg_model.IPersonalUserAccountMgDbModel
	WorkCommentDetailMgModel          mg_model.IWorkCommentDetailMgModel
	UserCommentUnReadWorkMgModel      mg_model.IUserCommentUnreadWorkMgModel
	PersonalUserNotificationMgModel   mg_model.IPersonalUserNotificationMgModel
	//PersonalBlackHouseInfoMgModel       mg_model.IPersonalBlackHouseInfoMgModel
	SecretChitChatCDKeyMgDbModel       mg_model.ISecretChitChatCDKeyMgDbModel
	SignDailyFortuneMg                 mg_model.ISignDailyFortuneMgModel
	SecretChitchatWork                 mg_model.ISecretChitchatWorkMgDbModel
	IpAddressMgModel                   mg_model.IIpAddressMgModel
	MemeMgDbModel                      mg_model.ISecretMemeMgModel
	PersonalTalkMessageRecordMgDbModel mg_model.IPersonalTalkMessageRecordMgDbModel
	SecretWorksLikeRecordMgDbModel     mg_model.ISecretWorksLikeRecordMgDbModel
	SecretUserFollowMgModel            mg_model.ISecretUserFollowMgDbModel
	SecretUserFollowBadgeMgDbModel     mg_model.ISecretUserFollowBadgeMgDbModel
	SecretUserFollowBadgeListMgDbModel mg_model.ISecretUserFollowBadgeListMgDbModel
	SecretUserWechatBindListMgDbModel  mg_model.ISecretUserWechatBindListMgDbModel
	PersonalTalkMessageTotalMgDbModel  mg_model.IPersonalTalkMessageTotalMgDbModel
	UserBlackListMgModel               mg_model.IUserBlackListMgModel
	UserMedalMgModel                   mg_model.ISecretUserMedalInfoMgModel
	MedalMgModel                       mg_model.ISecretMedalInfoMgModel
	WorkExpandRelMgDbModel             mg_model.IWorksExpandRelMgModel
	PersonalPoliceInfoMgDbModel        mg_model.IPersonalPoliceInfoMgDbModel
	UserInfoExtMgModel                 mg_model.ISecretShareUserInfoExtMgModel
	AuditAwardRecordMgDbModel          mg_model.IAuditAwardRecordMgModel
	SecretReportUserMgModel            mg_model.ISecretReportUserMgModel

	AuditMaliciousRecordMgDbModel       mg_model.IAuditMaliciousRecordMgModel
	SecretUserIdentificationCardMgModel mg_model.ISecretUserIdentificationCardMgModel
	PersonBottleWorksExtMgModel         mg_model.IPersonBottleWorksExtMgModel
	SecretGameMgModel                   mg_model.ISecretGameMgModel
	SecretGameOrderMgModel              mg_model.ISecretGameOrderMgModel
	SecretPayOrderInfoMgModel           mg_model.ISecretPayOrderInfoMgModel
	SecretPayNotifyMgModel              mg_model.ISecretPayNotifyMgModel
	SecretActiveUserMgModel             mg_model.ISecretActiveUserMgModel
	SecretEmoteAuditRecordMgModel       mg_model.ISecretEmoteAuditRecordMgModel
	SecretAuditMgDbModel                mg_model.ISecretAuditMgModel
	SecretDailySignInMgModel            mg_model.ISecretSignInMgModel
	SecretSpeedCodeMgModel              mg_model.ISecretSpeedCodeMgModel
	SecretUserActivityDailyMgModel      mg_model.ISecretUserActivityDailyMgModel
	ImGroupMgModel                      mg_model.IImGroupMgModel
	AtDetailMgModel                     mg_model.IAtDetailMgModel

	// mysql db
	SecretExpandTypeModel           model.ISecretExpandTypeDbModel
	OperatorModel                   model.IOperatorTabDbModel
	ReportRewardDbModel             model.IReportRewardDbModel
	UserLevelUpRecordDbModel        model.IUserLevelUpRecordDbModel
	MaozhuaXingZuoModel             model.IMaoZhuaXingZuoBirthDbModel
	PersonalCardMessageQueueDbModel model.IPersonalCardMessageQueueDbModel
	UserCircleWorksSwitchDbModel    model.IUserCircleWorksSwitchDbModelModel
	OpenUserModel                   model.IOpenUserDbModelModel
	WorkObjectAttrModel             model.IWorkObjectAttrDbModel
	UserInfoModel                   model.IUserinfoDbModelModel
	PersonBottleWorksModel          model.IPersonalBottleWorksDbModel
	WorkCommentStatusDbModel        model.IWorkCommentStatusDbModel
	AdVivoFeedbackDbModel           model.IAdVivoFeedbackDbModelDbModel

	ImGroupsDbModel      im.IImGroupsDbModelModel
	ImGroupMemberDbModel im.IImGroupMemberDbModelModel

	//
	BaiduLbsProxy baidu_lbs_yun_proxy.IBaiduLbsYunProxy

	//
	LocalCache go_cache.ICache
	RedisCli   *rdsV8.Client
}

var mDataCacheMng *DataCacheMng = nil

type IDataCacheMng interface {
	// 获取对象
	GetImpl() *DataCacheMng

	// 查不到返回nil
	GetUserInfoTalkMode(ctx context.Context, userId int64) int32
	GetUserInfoLocal(ctx context.Context, header *pbapi.HttpHeaderInfo, userId int64, bSkipCache bool) (*UserInfoLocal, error)
	DeleteUserInfoFromCache(ctx context.Context, userIds []int64) error
	// work相关操作
	IncWorkInfoToNewCommentCount(ctx context.Context, workId int64, count int64) error
	GetWorkInfoToNewCommentCount(ctx context.Context, workIds ...int64) ([]*WorkInfoDataCache, error)
	IncWorkInfoToNewCommentPeopleCount(ctx context.Context, workId int64, authorUserId int64, userId int64, count int64) error
	IncCommentCountPeopleCountGtN(ctx context.Context, workId int64, authorUserId, userId int64, count int64) error
	SetUserVisitorCountRD(ctx context.Context, WorkId []int64) error
	SetUserCommentCountRD(ctx context.Context, workIds []int64) error
	SetAuthorReplyCountD(ctx context.Context, workIds []int64) error
	SetWorkStatus(ctx context.Context, workIds []int64, status int32) error
	SetWorkShowScope(ctx context.Context, workIds []int64, showScope int32) error

	//
	DeleteCommentUsersOnWork(ctx context.Context, workId int64) error
	IncrValidCommentPersonCount(ctx context.Context, workId, userId int64, addOrDel int32) (int32, error)
	GetValidCommentPersonCount(ctx context.Context, workId int64) (int64, error)

	//
	GetWorkInfoLocal(ctx context.Context, workId int64, bSkipCache bool) (*WorkInfoLocal, error)
	DelWorkInfoCache(ctx context.Context, workId int64)

	/// 动态分发池操作
	AddToTsWorkPoolRedis(ctx context.Context, workId int64) error
	AsyncRemoveFromTsWorkPoolRedis(ctx context.Context, workids []string) bool
	RangeTsWorkPoolRedis(ctx context.Context, begin, end int64) (map[string]int64, int64, error)
	CleanTsWorkPoolRedis(ctx context.Context, min, max string) error

	// 优质分发池操作
	AddToHighTsWorkPoolRedis(ctx context.Context, workId int64) error
	AsyncRemoveFromHighTsWorkPoolRedis(ctx context.Context, workids []string) bool
	RangeHighTsWorkPoolRedis(ctx context.Context, begin, end int64) (map[string]int64, int64, error)
	CleanHighTsWorkPoolRedis(ctx context.Context, min, max string) error
	//CheckExistTsWorkPoolRedis(ctx context.Context, workid string) (bool, error)

	// 《高》优质分发池操作
	AddToHighPlusTsWorkPoolRedis(ctx context.Context, workId int64) error
	AsyncRemoveFromHighPlusTsWorkPoolRedis(ctx context.Context, workids []string) bool
	RangeHighPlusTsWorkPoolRedis(ctx context.Context, begin, end int64) (map[string]int64, int64, error)
	CleanHighPlusTsWorkPoolRedis(ctx context.Context, min, max string) error

	// 检查是否在用户已读池子  查询不到返回 err=redis: nil  curUserId: 登录了就是userid，不登录就是uk一个字符串
	CheckUserReadHistoryPoolR(ctx context.Context, workid string, curUserIdUk string) (bool, int64, error) //
	SetUserReadHistoryPoolR(ctx context.Context, workid string, curUserIdUk string) error

	// 获取用户权限集
	//GetUserPermission(ctx context.Context, userId int64) int32

	GetUserIdByToken(ctx context.Context, token string) (int64, error)

	// UserLatestWorkScore
	GetUserLatestWorkScore(ctx context.Context, userId int64) float32
	SetUserLatestWorkScore(ctx context.Context, userId int64, score float32) error

	// db
	//GetUserCircleWorksSwitchDbModel(ctx context.Context, userId int64,
	//	bSkipCache bool) (*pbapi.UserCircleWorksSwitchDbModel, error)
	ListUserReplyMsgDB(ctx context.Context, userId int64, cursorId int64, limit int32) []*pbapi.PersonalCardMessageQueueDbModel
	InsertPersonalCardMessageQueueDbModel(ctx context.Context, model *pbapi.PersonalCardMessageQueueDbModel) (*pbapi.PersonalCardMessageQueueDbModel, error)

	// ----mgdb-------//
	CheckUserBlackListMgDBLD(ctx context.Context, userId, targetUserId int64) bool
	// PersonTalkMsgTotal
	UpdatePersonTalkMsgTotalMgDBLd(ctx context.Context, id int64, changes map[string]interface{}, incDict map[string]int) error
	InsertPersonTalkMsgTotalMgDBLd(ctx context.Context, item *pbapi.PersonalTalkMessageTotalMgDbModel) error
	GetPersonTalkMsgTotalMgDB(ctx context.Context, uniqueId int32, toUserId int64) *pbapi.PersonalTalkMessageTotalMgDbModel
	GetPersonTalkMsgTotalWithIdMgDBLd(ctx context.Context, fromUserId, toUserId, workId int64) *pbapi.PersonalTalkMessageTotalMgDbModel
	//
	GetUserFollowMgDBLd(ctx context.Context, userId, targetUserId int64) int32
	GetUserWorkLikeMgDB(ctx context.Context, userId int64, workIds []int64) map[int64]*pbapi.SecretWorksLikeRecordMgDbModel //直接查db
	GetPersonTalkMsgRecordMgDB(ctx context.Context, msgId int64) *pbapi.PersonalTalkMessageRecordMgDbModel
	ListPersonTalkMsgRecordByConditionMgDB(ctx context.Context, cond map[string]interface{}) []*pbapi.PersonalTalkMessageRecordMgDbModel
	InsertPersonTalkMsgRecord(ctx context.Context, item *pbapi.PersonalTalkMessageRecordMgDbModel) error
	UpdatePersonTalkMsgRecordDictById(ctx context.Context, id int64, update map[string]interface{}) error
	UpdatePersonTalkMsgRecordDictByCond(ctx context.Context, cond, update map[string]interface{}) error
	GetSecretMemeMgDBLd(ctx context.Context, memeId int64) *pbmgdb.SecretMemeMgDbModel

	// redis
	ConvertFormate(coor *pbapi.CoordinateRedis) *pbapi.Coordinate
	GetUserCoordinateV2(ctx context.Context, userId int64, header *pbapi.HttpHeaderInfo) *pbapi.CoordinateRedis
	GetUserCoordinateRedis(ctx context.Context, userId int64) *pbapi.CoordinateRedis
	GetTimesConfigLR(ctx context.Context, busiKey string) int64
	//LoadTimesConfigComment(ctx context.Context, key string)
	GetUserCurReplyList(ctx context.Context, userId int64) []int64
	SetUserCurReplyList(ctx context.Context, curUserId, destUserId int64) error
	GetPushChitchatTimes(ctx context.Context, userId int64) int
	SetPushChitchatTimes(ctx context.Context, userId int64) (int, error)
	GetUserSystemWorkReadFlagRds(ctx context.Context, userId, workId int64) bool
	SetUserSystemWorkReadFlagRds(ctx context.Context, userId, workId int64) error
	GetUserSystemWorkPublishFlagRds(ctx context.Context, userId, workId int64) bool
	SetUserSystemWorkPublishFlagRds(ctx context.Context, userId, workId int64) error
	GetUserDayWorkCount(ctx context.Context, userId int64) (int64, error)
	SetUserDayWorkCount(ctx context.Context, userId int64, count int64) error
	GetSignDailyFortuneMgDBLD(ctx context.Context, signId, date int32) *pbapi.StarSignData
	GetRobotCommentRules(ctx context.Context) ([]zeroModel.MzRobot, error)
	PushMessageToRobot(message map[string]int64) error
	// 广告
	SetRedisAdFeedback(ctx context.Context, channel, machineId string, value int) error
	GetRedisAdFeedback(ctx context.Context, channel, machineId string) int
	// 备注
	GetUserRemarkOne(ctx context.Context, userId, toUserId int64) (remarkName string, err error)
	SetUserRemarkOne(ctx context.Context, userId, toUserId int64, name string) error
	DelUserRemarkOne(ctx context.Context, userId, toUserId int64) error
	// 获取背景图
	GetBackgroundWithTalk(ctx context.Context) (string, error)
	GetBackgroundWithWork(ctx context.Context) (string, error)
	// 获取激活码的过期时间
	GetChitChatCDKeyExpireTime(ctx context.Context) int64
	// 获取redis中举报奖励配置信息
	GetAuditAwardSetting(ctx context.Context) error
	IsRobotComment(ctx context.Context, userId int64) bool
	// 获取redis中首条动态奖励配置
	LoadSuperiorContentAwardSetting(ctx context.Context) error

	//// type   封禁类型，2:发帖 3:评论,   module 模块，1:单聊 2:story 3:群聊
	CheckByTypeAndModule(ctx context.Context, fbType, module int32, userId int64) bool

	//comment nums redis
	//key:commenter_user_id value:100, 过期时间是24小时
	GetCommentNumsForCommenter(ctx context.Context, user_id int64) (int64, error)
	IncrUserSingleMaxCommentCount(ctx context.Context, user_id int64, incr_val int64) error
	//key:work_id_user_id, value:5 不过期时间
	GetWorkCommenterCommentNums(ctx context.Context, user_id int64, work_id int64) (int64, error)
	IncrUserMaxCommentCount(ctx context.Context, user_id int64, work_id int64, incr_val int64) (int64, error)
	GetUserBasicInfo(ctx context.Context, userId int64, bSkipCache bool) (*pbapi.UserinfoDbModel, error)

	//运动排行榜
	//user_id 使用户id, step_nums是运动步数， expire_time是过期时间，单位秒
	SetActivityRankerByStep(ctx context.Context, simple_key int64, user_id int64, step_nums int64, expire_time int64) error
	//获取用户的排行榜位置，依次返回排行榜位置，步数，或者错误
	GetRankerIdForUser(ctx context.Context, simple_key, user_id int64) (int64, int64, error)
	GetRankerUserTop20(ctx context.Context, simple_key int64) (*utils.SortMap, error)
	// 获取某期的人数，运动总步数，错误
	AggregateRankerUserByRedis(ctx context.Context, simpleKey int64) (int64, int64, error)
}

func NewDataCacheMng(
	UserAwardSummaryMgModel mg_model.IUserAwardSummaryMgModel,
	KoLaWithdrawDetailMgModel mg_model.IKoLaWithdrawDetailMgModel,
	SuperiorContentAwardDetailMgModel mg_model.ISuperiorContentAwardDetailMgModel,
	NotificationReadCursorMgDbModel mg_model.INotificationReadCursorMgDbModel,
	CommentLikeDetailMgModel mg_model.ICommentLikeDetailMgModel,
	UserRemindDetail mg_model.IUserRemindDetailMgDbModel,
	secretMemberInfoMgModel mg_model.ISecretMemberInfoMgModel,
	SecretReport mg_model.ISecretReportMgModel,
	SecretReportUserMgModel mg_model.ISecretReportUserMgModel,
	SportActivityMgModel mg_model.ISportActivityMgModel,
	PersonalUserAccountMgDbModel mg_model.IPersonalUserAccountMgDbModel,
	WorkCommentDetailMgModel mg_model.IWorkCommentDetailMgModel,
	UserCommentUnreadWorkMgModel mg_model.IUserCommentUnreadWorkMgModel,
	PersonalUserNotificationMgModel mg_model.IPersonalUserNotificationMgModel,
	//personalBlackHouseInfoMgModel mg_model.IPersonalBlackHouseInfoMgModel,
	secretChitChatCDKeyMgDbModel mg_model.ISecretChitChatCDKeyMgDbModel,
	SignDailyFortuneMg mg_model.ISignDailyFortuneMgModel,
	SecretChitchatWork mg_model.ISecretChitchatWorkMgDbModel,
	IpAddressMgModel mg_model.IIpAddressMgModel,
	memeMgDbModel mg_model.ISecretMemeMgModel,
	PersonalTalkMessageRecordMgDbModel mg_model.IPersonalTalkMessageRecordMgDbModel,
	SecretWorksLikeRecordMgDbModel mg_model.ISecretWorksLikeRecordMgDbModel,
	SecretUserFollowMgModel mg_model.ISecretUserFollowMgDbModel,
	SecretUserFollowBadgeMgDbModel mg_model.ISecretUserFollowBadgeMgDbModel,
	SecretUserFollowBadgeListMgDbModel mg_model.ISecretUserFollowBadgeListMgDbModel,
	SecretUserWechatBindListMgDbModel mg_model.ISecretUserWechatBindListMgDbModel,
	PersonalTalkMessageTotalMgDbModel mg_model.IPersonalTalkMessageTotalMgDbModel,
	UserBlackListMgModel mg_model.IUserBlackListMgModel,
	UserMedalMgModel mg_model.ISecretUserMedalInfoMgModel,
	MedalMgModel mg_model.ISecretMedalInfoMgModel,
	WorkExpandRelMgDbModel mg_model.IWorksExpandRelMgModel,
	PersonalPoliceInfoMgDbModel mg_model.IPersonalPoliceInfoMgDbModel,
	UserInfoExtMgModel mg_model.ISecretShareUserInfoExtMgModel,
	AuditAwardRecordMgDbModel mg_model.IAuditAwardRecordMgModel,
	AuditMaliciousRecordMgModel mg_model.IAuditMaliciousRecordMgModel,
	SecretUserIdentificationCardMgModel mg_model.ISecretUserIdentificationCardMgModel,
	PersonBottleWorksExtMgModel mg_model.IPersonBottleWorksExtMgModel,
	SecretGameMgModel mg_model.ISecretGameMgModel,
	SecretGameOrderMgModel mg_model.ISecretGameOrderMgModel,
	SecretGamePayOrderInfoMgModel mg_model.ISecretPayOrderInfoMgModel,
	SecretGamePayNotifyMgModel mg_model.ISecretPayNotifyMgModel,
	SecretActiveUserMgModel mg_model.ISecretActiveUserMgModel,
	SecretEmoteAuditRecordMgModel mg_model.ISecretEmoteAuditRecordMgModel,
	SecretAuditMgModel mg_model.ISecretAuditMgModel,
	SecretDailySignInMgModel mg_model.ISecretSignInMgModel,
	SecretSpeedCodeMgModel mg_model.ISecretSpeedCodeMgModel,
	SecretUserActivityDailyMgModel mg_model.ISecretUserActivityDailyMgModel,
	ImGroupMgModel mg_model.IImGroupMgModel,

	SecretExpandTypeModel model.ISecretExpandTypeDbModel, // db
	WorkCommentStatusDbModel model.IWorkCommentStatusDbModel,
	ReportRewardDbModel model.IReportRewardDbModel,
	OperatorModel model.IOperatorTabDbModel,
	UserLevelUpRecordDbModel model.IUserLevelUpRecordDbModel,
	MaozhuaXingZuoModel model.IMaoZhuaXingZuoBirthDbModel,
	PersonalCardMessageQueueDbModel model.IPersonalCardMessageQueueDbModel,
	UserCircleWorksSwitchDbModel model.IUserCircleWorksSwitchDbModelModel,
	AdVivoFeedbackDbModel model.IAdVivoFeedbackDbModelDbModel,

	OpenUserDbImpl model.IOpenUserDbModelModel,
	workObjectAttrImpl model.IWorkObjectAttrDbModel,
	userDB model.IUserinfoDbModelModel,
	psworkDb model.IPersonalBottleWorksDbModel,

	imGroupsDb im.IImGroupsDbModelModel,
	AtDetailMgModel mg_model.IAtDetailMgModel,
	imGroupMemberDb im.IImGroupMemberDbModelModel,

	BaiduLbsProxy baidu_lbs_yun_proxy.IBaiduLbsYunProxy,
	redis *rdsV8.Client,
	localCache go_cache.ICache) IDataCacheMng {
	iMng := &DataCacheMng{
		// mgDb
		UserAwardSummaryMgModel:           UserAwardSummaryMgModel,
		KoLaWithdrawDetailMgModel:         KoLaWithdrawDetailMgModel,
		SuperiorContentAwardDetailMgModel: SuperiorContentAwardDetailMgModel,
		NotificationReadCursorMgDbModel:   NotificationReadCursorMgDbModel,
		CommentLikeDetailMgModel:          CommentLikeDetailMgModel,
		UserRemindDetail:                  UserRemindDetail,
		SecretMemberInfoMgModel:           secretMemberInfoMgModel,
		SecretReport:                      SecretReport,
		SecretReportUserMgModel:             SecretReportUserMgModel,
		WorkCommentDetailMgModel:          WorkCommentDetailMgModel,
		UserCommentUnReadWorkMgModel:      UserCommentUnreadWorkMgModel,
		PersonalUserNotificationMgModel:   PersonalUserNotificationMgModel,
		//PersonalBlackHouseInfoMgModel:       personalBlackHouseInfoMgModel,
		SecretChitChatCDKeyMgDbModel:        secretChitChatCDKeyMgDbModel,
		SignDailyFortuneMg:                  SignDailyFortuneMg,
		SecretChitchatWork:                  SecretChitchatWork,
		IpAddressMgModel:                    IpAddressMgModel,
		MemeMgDbModel:                       memeMgDbModel,
		PersonalTalkMessageRecordMgDbModel:  PersonalTalkMessageRecordMgDbModel,
		SecretWorksLikeRecordMgDbModel:      SecretWorksLikeRecordMgDbModel,
		SecretUserFollowMgModel:             SecretUserFollowMgModel,
		SecretUserFollowBadgeMgDbModel:      SecretUserFollowBadgeMgDbModel,
		SecretUserFollowBadgeListMgDbModel:  SecretUserFollowBadgeListMgDbModel,
		SecretUserWechatBindListMgDbModel:   SecretUserWechatBindListMgDbModel,
		PersonalTalkMessageTotalMgDbModel:   PersonalTalkMessageTotalMgDbModel,
		UserBlackListMgModel:                UserBlackListMgModel,
		UserMedalMgModel:                    UserMedalMgModel,
		MedalMgModel:                        MedalMgModel,
		WorkExpandRelMgDbModel:              WorkExpandRelMgDbModel,
		PersonalPoliceInfoMgDbModel:         PersonalPoliceInfoMgDbModel,
		UserInfoExtMgModel:                  UserInfoExtMgModel,
		SportActivityMgModel:                SportActivityMgModel,
		PersonalUserAccountMgDbModel:        PersonalUserAccountMgDbModel,
		AuditAwardRecordMgDbModel:           AuditAwardRecordMgDbModel,
		AuditMaliciousRecordMgDbModel:       AuditMaliciousRecordMgModel,
		SecretUserIdentificationCardMgModel: SecretUserIdentificationCardMgModel,
		PersonBottleWorksExtMgModel:         PersonBottleWorksExtMgModel,
		SecretGameMgModel:                   SecretGameMgModel,
		SecretGameOrderMgModel:              SecretGameOrderMgModel,
		SecretPayOrderInfoMgModel:           SecretGamePayOrderInfoMgModel,
		SecretPayNotifyMgModel:              SecretGamePayNotifyMgModel,
		SecretActiveUserMgModel:             SecretActiveUserMgModel,
		SecretEmoteAuditRecordMgModel:       SecretEmoteAuditRecordMgModel,
		SecretAuditMgDbModel:                SecretAuditMgModel,
		SecretDailySignInMgModel:            SecretDailySignInMgModel,
		SecretSpeedCodeMgModel:              SecretSpeedCodeMgModel,
		SecretUserActivityDailyMgModel:      SecretUserActivityDailyMgModel,
		ImGroupMgModel:                      ImGroupMgModel,
		AtDetailMgModel:                     AtDetailMgModel,
		ImGroupMemberDbModel:                imGroupMemberDb,

		// DB
		SecretExpandTypeModel:           SecretExpandTypeModel,
		WorkCommentStatusDbModel:        WorkCommentStatusDbModel,
		OperatorModel:                   OperatorModel,
		ReportRewardDbModel:             ReportRewardDbModel,
		UserLevelUpRecordDbModel:        UserLevelUpRecordDbModel,
		MaozhuaXingZuoModel:             MaozhuaXingZuoModel,
		PersonalCardMessageQueueDbModel: PersonalCardMessageQueueDbModel,
		UserCircleWorksSwitchDbModel:    UserCircleWorksSwitchDbModel,
		OpenUserModel:                   OpenUserDbImpl,
		WorkObjectAttrModel:             workObjectAttrImpl,
		UserInfoModel:                   userDB,
		PersonBottleWorksModel:          psworkDb,
		ImGroupsDbModel:                 imGroupsDb,
		AdVivoFeedbackDbModel:           AdVivoFeedbackDbModel,

		BaiduLbsProxy: BaiduLbsProxy,
		RedisCli:      redis,
		LocalCache:    localCache,
	}
	mDataCacheMng = iMng
	return iMng
}

func (p *DataCacheMng) GetImpl() *DataCacheMng {
	return mDataCacheMng
}
