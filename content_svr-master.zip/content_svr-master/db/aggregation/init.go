package aggregation

import "content_svr/db/dao"

type SumManage struct {
	UserActivityDaily
	Game
	Member
}

func NewSumManage(read, write *dao.ManagerDB) *SumManage {
	return &SumManage{
		UserActivityDaily: UserActivityDaily{
			WriteDB: write,
			ReadDB:  read,
		},
		Game: Game{
			WriteDB: write,
			ReadDB:  read,
		},
		Member: Member{
			WriteDB: write,
			ReadDB:  read,
		},
	}
}
