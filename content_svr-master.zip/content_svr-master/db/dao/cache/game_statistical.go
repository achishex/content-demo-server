package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type GameStatistical struct {
	model.GameStatisticalModel
	redisManage *query_rds.Manage
}

func NewCacheGameStatistical(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *GameStatistical {
	return &GameStatistical{
		GameStatisticalModel: mongo.GameStatistical,
		redisManage:          redisManage,
	}
}
