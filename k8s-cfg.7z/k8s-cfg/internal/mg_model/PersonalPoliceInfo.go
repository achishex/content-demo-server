package mg_model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type IPersonalPoliceInfoMgDbModel interface {
	GetByUserId(ctx context.Context,
		userId int64) (*pbapi.PersonalPoliceInfoMgDbModel, error)
}

type PersonalPoliceInfoMgDbImpl struct {
	MgDB *mongo.Database
}

func NewPersonalPoliceInfoMgModelImpl(db *mongo.Database) IPersonalPoliceInfoMgDbModel {
	return &PersonalPoliceInfoMgDbImpl{MgDB: db}
}

// 查不到返回nil
func (impl *PersonalPoliceInfoMgDbImpl) GetByUserId(ctx context.Context,
	userId int64) (*pbapi.PersonalPoliceInfoMgDbModel, error) {
	retItems := make([]*pbapi.PersonalPoliceInfoMgDbModel, 0)
	collection := impl.MgDB.Collection("personalPoliceInfo")
	find, err := collection.Find(ctx, bson.M{"_id": userId})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PersonalPoliceInfoMgDbModel Find failed.userid=%v",
			userId), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.PersonalPoliceInfoMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to PersonalPoliceInfoMgDbModel failed.userid=%v",
				userId), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	if len(retItems) > 1 {
		logger.Error(ctx, fmt.Sprintf("get PersonalPoliceInfoMgDbModel failed.userid=%v",
			userId), err)
	}
	return retItems[0], err
}
