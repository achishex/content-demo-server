package main

import (
	"io"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"text/template"
)

var (
	contentSvrTable = map[string]string{
		//"content_svr/app_comm.tpl": "./app/app_comm/app_comm.go",
		"content_svr/app_comm.tpl": "./deploy/app_comm/app_comm.go",
	}
)

type ContentSvrTemplateKey struct {
	MysqlType []string
	MongoType []string
}

func generateContentSvrFile(mongoTableNames, mysqlTableNames string) {
	if mongoTableNames == "" || mysqlTableNames == "" {
		log.Println("mongoTableNames error ->", mongoTableNames)
		log.Println("mysqlTableNames error ->", mysqlTableNames)
		return
	}

	sqlTables := strings.Split(mysqlTableNames, ",")
	mngTables := strings.Split(mongoTableNames, ",")
	data := ContentSvrTemplateKey{
		MysqlType: sqlTables,
		MongoType: mngTables,
	}

	for tPath, wPath := range contentSvrTable {
		tPath = filepath.Join(templateDir, tPath)
		if _, err := os.Stat(tPath); err != nil {
			log.Println(err)
			continue
		}

		if err := parseFile(tPath, wPath, data); err != nil {
			panic(err)
		}

		_ = exec.Command("gofmt", "-l", "-w", wPath).Run()
	}

}

func createTemplateObject(templatePath string) (*template.Template, error) {
	rf, err := os.Open(templatePath)
	if err != nil {
		return nil, err
	}
	b, err := io.ReadAll(rf)
	if err != nil {
		return nil, err
	}
	defer rf.Close()

	tmpl, err := template.New("gen").Parse(string(b))
	if err != nil {
		panic(err)
	}

	return tmpl, nil
}
