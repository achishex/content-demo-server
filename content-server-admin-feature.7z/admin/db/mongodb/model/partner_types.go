package model

const collectionNamePartner = "partner"

type Partner struct {
	ID          string `json:"id,omitempty" bson:"_id,omitempty"`
	UserId      int64  `json:"user_id,omitempty" bson:"user_id,omitempty json:"`           //用户id
	IsPartner   bool   `json:"is_partner,omitempty" bson:"is_partner,omitempty json:"`     //是否合伙人
	TotalIncome uint64 `json:"total_income,omitempty" bson:"total_income,omitempty json:"` //累计收益
	IsInvited   bool   `json:"is_invited,omitempty" bson:"is_invited,omitempty json:"`     //是否已被邀请
	RewardPopup bool   `json:"reward_popup,omitempty" bson:"reward_popup,omitempty json:"` //瓜分弹窗
	InvitePopup bool   `json:"invite_popup,omitempty" bson:"invite_popup,omitempty json:"` //邀请弹窗
	CreateTime  int64  `json:"create_time,omitempty" bson:"create_time,omitempty json:"`   //创建时间
	UpdateTime  int64  `json:"update_time,omitempty" bson:"update_time,omitempty json:"`   // 更新时间
}
