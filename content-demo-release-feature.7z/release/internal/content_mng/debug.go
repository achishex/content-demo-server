package content_mng

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
)

func (p *ContentMng) Debug(ctx context.Context) error {

	return nil
}

func (p *ContentMng) DebugAddToDeliver(ctx context.Context, req *pbapi.DebugUserIdReq) error {
	//加入到分发池子
	err := p.DataCache.AddToTsWorkPoolRedis(ctx, req.GetUserId())
	if err != nil {
		logger.Errorf(ctx, "add work to tsPool failed.", err)
		return err
	}
	logger.Infof(ctx, "add id=%v to fenfa suc", req.GetUserId())
	return nil
}
