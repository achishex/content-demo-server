package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretUserWechatBindListMgDbModel interface {
	Get(ctx context.Context, cond any) (*pbmgdb.SecretUserWechatBindListMgDbModel, error)
	AddOne(ctx context.Context, data *pbmgdb.SecretUserWechatBindListMgDbModel, opts ...*options.InsertOneOptions) error
	Exists(ctx context.Context, filter any) bool
	Delete(ctx context.Context, filter any) bool
}

type SecretUserWechatBindListMgDbImpl struct {
	MgDB *mongo.Database
}

func NewSecretUserWechatBindListMgModelImpl(db *mongo.Database) ISecretUserWechatBindListMgDbModel {
	return &SecretUserWechatBindListMgDbImpl{MgDB: db}
}

func (impl *SecretUserWechatBindListMgDbImpl) table() string {
	return "secretUserWechatBindList"
}

func (impl *SecretUserWechatBindListMgDbImpl) coll() *mongo.Collection {
	return impl.MgDB.Collection(impl.table())
}

func (impl *SecretUserWechatBindListMgDbImpl) Get(ctx context.Context, filter any) (*pbmgdb.SecretUserWechatBindListMgDbModel, error) {
	v := &pbmgdb.SecretUserWechatBindListMgDbModel{}
	err := impl.coll().FindOne(ctx, filter).Decode(v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserWechatBindListMgDbImpl get mongo failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (impl *SecretUserWechatBindListMgDbImpl) AddOne(ctx context.Context, doc *pbmgdb.SecretUserWechatBindListMgDbModel, opts ...*options.InsertOneOptions) error {
	_, err := impl.coll().InsertOne(ctx, doc)
	if err != nil {
		logger.Errorf(ctx, "SecretUserWechatBindListMgDbImpl:Add mongo error : %v", err)
		return err
	}

	return nil
}

func (impl *SecretUserWechatBindListMgDbImpl) Exists(ctx context.Context, filter any) bool {
	c, err := impl.coll().CountDocuments(ctx, filter)
	if err != nil {
		logger.Errorf(ctx, "SecretUserWechatBindListMgDbImpl: count mongo error : %v", err)
		return false
	}
	if c > 0 {
		return true
	}
	return false
}

func (impl *SecretUserWechatBindListMgDbImpl) Delete(ctx context.Context, filter any) bool {
	_, err := impl.coll().DeleteOne(ctx, filter)
	if err != nil {
		logger.Errorf(ctx, "SecretUserWechatBindListMgDbImpl: Delete mongo error : %v", err)
		return false
	}
	return true
}
