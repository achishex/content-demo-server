package content_mng

import (
	"context"
	"github.com/go-redis/redis/v8"
	"github.com/stretchr/testify/assert"
	"testing"
	"time"
)

func TestIncrAndDecrRemain(t *testing.T) {
	cli := redis.NewClient(&redis.Options{
		Addr: "127.0.0.1:6379",
	})
	ctx := context.Background()
	err := cli.Ping(ctx).Err()
	assert.Nil(t, err)

	sender, receiver := int64(100), int64(200)
	comp := NewSendSessComp(cli)
	err = comp.IncrNoReplySendRemain(ctx, sender, receiver)
	assert.Nil(t, err)
	err = comp.DecrNoReplySendRemain(ctx, sender, receiver)
	assert.Nil(t, err)
}

func TestIncrAndClearCount(t *testing.T) {
	cli := redis.NewClient(&redis.Options{
		Addr: "127.0.0.1:6379",
	})
	ctx := context.Background()
	err := cli.Ping(ctx).Err()
	assert.Nil(t, err)

	sender, receiver := int64(100), int64(200)
	comp := NewSendSessComp(cli)

	err = comp.IncrSendSessCount(ctx, sender, receiver)
	assert.Nil(t, nil)
	err = comp.IncrSendSessCount(ctx, sender, receiver)
	assert.Nil(t, err)

	err = comp.ClearSendSessCount(ctx, sender, receiver)
	assert.Nil(t, err)
}

func TestSetNX(t *testing.T) {
	cli := redis.NewClient(&redis.Options{
		Addr: "127.0.0.1:6379",
	})
	ctx := context.Background()
	err := cli.Ping(ctx).Err()
	assert.Nil(t, err)

	result, err := cli.SetNX(ctx, "no_exist", "1", time.Second).Result()
	if err != nil {
		t.Error(err)
	}
	t.Log(result)

	time.Sleep(time.Second * 2)

	result2, err := cli.SetNX(ctx, "no_exist", "1", time.Second).Result()
	if err != nil {
		t.Error(err)
	}
	t.Log(result2)
}
