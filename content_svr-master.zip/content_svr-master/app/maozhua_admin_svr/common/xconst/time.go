package xconst

import "time"

const (
	Day  = time.Hour * 24
	Week = time.Hour * 24 * 7
	Year = time.Hour * 24 * 365
)
