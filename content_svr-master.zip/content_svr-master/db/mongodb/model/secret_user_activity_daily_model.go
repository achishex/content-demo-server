package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var _ SecretUserActivityDailyModel = (*customSecretUserActivityDailyModel)(nil)

type (
	// SecretUserActivityDailyModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretUserActivityDailyModel.
	SecretUserActivityDailyModel interface {
		secretUserActivityDailyModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretUserActivityDaily, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretUserActivityDaily, error)
		DeleteMany(ctx context.Context, filter map[string]interface{}, opts ...*options.DeleteOptions) (int64, error)
	}

	customSecretUserActivityDailyModel struct {
		*defaultSecretUserActivityDailyModel
	}
)

// NewSecretUserActivityDailyModel returns a model for the mongo.
func NewSecretUserActivityDailyModel(cfg MonConfig) SecretUserActivityDailyModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SecretUserActivityDailyCollectionName)
	return &customSecretUserActivityDailyModel{
		defaultSecretUserActivityDailyModel: newDefaultSecretUserActivityDailyModel(conn),
	}
}

func (m *customSecretUserActivityDailyModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	} else {
		flagType = "default"
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customSecretUserActivityDailyModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretUserActivityDailyModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretUserActivityDaily, error) {
	result := make([]SecretUserActivityDaily, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretUserActivityDailyModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretUserActivityDaily, error) {
	var data SecretUserActivityDaily
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretUserActivityDailyModel) DeleteMany(ctx context.Context, filter map[string]interface{}, opts ...*options.DeleteOptions) (int64, error) {
	if len(filter) == 0 {
		return 0, nil
	}
	return m.conn.DeleteMany(ctx, filter, opts...)
}
