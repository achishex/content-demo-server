package model

import "go.mongodb.org/mongo-driver/bson/primitive"

const collectionNamePartnerInvite = "partner_invite"

type PartnerInvite struct {
	ID           primitive.ObjectID `json:"id,omitempty" bson:"_id,omitempty"`
	UserId       int64              `json:"user_id,omitempty" bson:"user_id,omitempty json:"`               //用户id
	InviteUserId int64              `json:"invite_user_id,omitempty" bson:"invite_user_id,omitempty json:"` //邀请人
	InviteCode   string             `json:"invite_code,omitempty" bson:"invite_code,omitempty json:"`       //使用的邀请码
	CreateTime   int64              `json:"create_time,omitempty" bson:"create_time,omitempty json:"`       //创建时间
	UpdateTime   int64              `json:"update_time,omitempty" bson:"update_time,omitempty json:"`       // 更新时间
}
