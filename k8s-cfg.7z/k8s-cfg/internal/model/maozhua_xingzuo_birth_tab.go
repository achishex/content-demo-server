package model

import (
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbdb"
	"content_svr/pub/errors"
	"context"
	"encoding/json"
	"github.com/gogo/protobuf/proto"
	"gorm.io/gorm"
	"gorm.io/plugin/dbresolver"
)

type IMaoZhuaXingZuoBirthDbModel interface {
	ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.MaoZhuaXingZuoBirthDbModel, error)
	CreateOrUpdate(ctx context.Context, model *pbdb.MaoZhuaXingZuoBirthDbModel) (*pbdb.MaoZhuaXingZuoBirthDbModel, error)
	GetItemById(ctx context.Context, userId int64) (*pbdb.MaoZhuaXingZuoBirthDbModel, error)
	//ListItemByAccountIdsAndType(ctx context.Context, ids int64) ([]*pbapi.MaoZhuaXingZuoBirthDbModel, error)
	UpdateItem(ctx context.Context, model *pbdb.MaoZhuaXingZuoBirthDbModel) (*pbdb.MaoZhuaXingZuoBirthDbModel, error)
	CreateItem(ctx context.Context, model *pbdb.MaoZhuaXingZuoBirthDbModel) (*pbdb.MaoZhuaXingZuoBirthDbModel, error)
	CountItemsByCondition(ctx context.Context, condition map[string]interface{}) (total int64, _ error)
}

type MaoZhuaXingZuoBirthDbModelImpl struct {
	DB *gorm.DB
}

func NewMaoZhuaXingZuoBirthDbModelImpl(db *gorm.DB) IMaoZhuaXingZuoBirthDbModel {
	return &MaoZhuaXingZuoBirthDbModelImpl{DB: db}
}

func (impl *MaoZhuaXingZuoBirthDbModelImpl) table() string {
	return "maozhua_xingzuo_birth_tab"
}

func (impl *MaoZhuaXingZuoBirthDbModelImpl) GetItemById(ctx context.Context, userId int64) (*pbdb.MaoZhuaXingZuoBirthDbModel, error) {
	model := pbdb.MaoZhuaXingZuoBirthDbModel{}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Clauses(dbresolver.Write).
		Where("user_id = ?", userId).First(&model)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &model, errors.Wrap(result.Error)
}

func (impl *MaoZhuaXingZuoBirthDbModelImpl) CreateOrUpdate(ctx context.Context, model *pbdb.MaoZhuaXingZuoBirthDbModel) (*pbdb.MaoZhuaXingZuoBirthDbModel, error) {
	item, err := impl.GetItemById(ctx, model.GetUserId())
	if err != nil {
		return nil, err
	}
	if item == nil {
		// CREATE
		item, err = impl.CreateItem(ctx, model)
	} else {
		// UPDATE
		item.Status = proto.Int32(int32(pbconst.BaseTabStatus_valid))
		item.Month = model.Month
		item.Day = model.Day
		item, err = impl.UpdateItem(ctx, item)
	}
	return item, err
}

func (impl *MaoZhuaXingZuoBirthDbModelImpl) UpdateItem(ctx context.Context, model *pbdb.MaoZhuaXingZuoBirthDbModel) (*pbdb.MaoZhuaXingZuoBirthDbModel, error) {
	modelDict := make(map[string]interface{})
	modelByte, err := json.Marshal(model)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(modelByte, &modelDict)
	if err != nil {
		return nil, err
	}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Where("user_id = ?", model.GetUserId()).Updates(modelDict)
	return model, errors.Wrap(result.Error)
}

func (impl *MaoZhuaXingZuoBirthDbModelImpl) CreateItem(ctx context.Context, model *pbdb.MaoZhuaXingZuoBirthDbModel) (*pbdb.MaoZhuaXingZuoBirthDbModel, error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Create(model)
	return model, errors.Wrap(result.Error)
}

// offset 开始查的默认值为0
func (impl *MaoZhuaXingZuoBirthDbModelImpl) ListItemOffset(ctx context.Context, condition map[string]interface{}, page int, size int) ([]*pbdb.MaoZhuaXingZuoBirthDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.MaoZhuaXingZuoBirthDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(size).Offset(offset).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}

	return items, errors.Wrap(result.Error)
}

func (impl *MaoZhuaXingZuoBirthDbModelImpl) ListItemsByCondition(ctx context.Context,
	condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.MaoZhuaXingZuoBirthDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.MaoZhuaXingZuoBirthDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(int(size)).Offset(int(offset)).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *MaoZhuaXingZuoBirthDbModelImpl) CountItemsByCondition(ctx context.Context,
	condition map[string]interface{}) (total int64, _ error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Model(&pbdb.MaoZhuaXingZuoBirthDbModel{}).Where(condition).Count(&total)
	return total, errors.Wrap(result.Error)
}
