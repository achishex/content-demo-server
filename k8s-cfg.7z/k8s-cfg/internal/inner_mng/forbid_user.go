package inner_mng

import (
	"content_svr/config"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	"strconv"
)

// 永久封禁用户。   https://admin-test.52mengdong.com/admin/user/lock/{sign}
func (p *InnerProxyImpl) ForbidUserForever(ctx context.Context, userId int64) error {
	// 设置到redis，然后请求。
	sign, _ := p.setRdsSign(ctx)
	url := config.ServerConfig.InnerHost + "/admin/user/lock/" + strconv.Itoa(int(sign))
	body := map[string]interface{}{
		"userIds":   []int64{userId},
		"type":      3,
		"lockTypes": []int32{1},
		"duration":  0,
		"reason":    "daily_check_undergroud",
		"source":    100,
	}

	bodyBytes, _ := json.Marshal(body)
	resp, err := p.sendPutRequest(ctx, url, bodyBytes)
	if err != nil {
		logger.Errorf(ctx, "/admin/user/lock/ return err. userId=%v, resp=%v, err=%v", userId, resp, err)
		return err
	}

	if resp.StatusCode != 200 {
		logger.Errorf(ctx, "/admin/user/lock/ httpcode!=200. userId=%v, resp=%v, err=%v", userId, resp, err)
		return fmt.Errorf("http retcode != 200, retcode=%v", resp.Status)
	}

	innerResp := &pbapi.InnerCommResp{}
	json.NewDecoder(resp.Body).Decode(innerResp)
	logger.Infof(ctx, "/admin/user/lock/ over, userId=%v, url=%v, innerResp=%+v", userId, url, innerResp)
	return nil
}
