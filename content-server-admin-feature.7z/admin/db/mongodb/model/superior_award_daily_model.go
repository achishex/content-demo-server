package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const SuperiorAwardDailyCollectionName = "superior_award_daily"

var _ SuperiorAwardDailyModel = (*customSuperiorAwardDailyModel)(nil)

type (
	// SuperiorAwardDailyModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSuperiorAwardDailyModel.
	SuperiorAwardDailyModel interface {
		superiorAwardDailyModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SuperiorAwardDaily, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SuperiorAwardDaily, error)
	}

	customSuperiorAwardDailyModel struct {
		*defaultSuperiorAwardDailyModel
	}
)

// NewSuperiorAwardDailyModel returns a model for the mongo.
func NewSuperiorAwardDailyModel(cfg MonConfig, opts ...mon.Option) SuperiorAwardDailyModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SuperiorAwardDailyCollectionName, opts...)
	return &customSuperiorAwardDailyModel{
		defaultSuperiorAwardDailyModel: newDefaultSuperiorAwardDailyModel(conn),
	}
}

func (m *customSuperiorAwardDailyModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	} else {
		flagType = "default"
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customSuperiorAwardDailyModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSuperiorAwardDailyModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SuperiorAwardDaily, error) {
	result := make([]SuperiorAwardDaily, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSuperiorAwardDailyModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SuperiorAwardDaily, error) {
	var data SuperiorAwardDaily
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
