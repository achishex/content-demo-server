package dau

import (
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type PartnerInvitedUserListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewPartnerInvitedUserListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *PartnerInvitedUserListLogic {
	return &PartnerInvitedUserListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *PartnerInvitedUserListLogic) PartnerInvitedUserList(req *types.PartnerInvitedUserListReq) (resp *types.PartnerInvitedUserListResp, err error) {
	var list []types.PartnerInvitedUserItem

	startTime := time.UnixMilli(req.TimeStart)
	endTime := time.UnixMilli(req.TimeEnd)
	nextTime := time.Date(startTime.Year(), startTime.Month(), startTime.Day(), 0, 0, 0, 0, startTime.Location()).AddDate(0, 0, 1)

	for {
		if nextTime.UnixMilli() >= endTime.UnixMilli() { // 最后一条
			nextTime = endTime

			item, err := l.queryItem(startTime.UnixMilli(), nextTime.UnixMilli())
			if err == nil {
				list = append(list, item)
			}
			break
		}

		item, err := l.queryItem(startTime.UnixMilli(), nextTime.UnixMilli())
		if err == nil {
			list = append(list, item)
		}

		// 开始循环
		startTime = nextTime
		nextTime = nextTime.AddDate(0, 0, 1)
	}

	return &types.PartnerInvitedUserListResp{List: list}, nil
}

func (l *PartnerInvitedUserListLogic) queryItem(start, end int64) (item types.PartnerInvitedUserItem, err error) {
	filter := map[string]interface{}{}
	filter = BuildFilter(filter, "create_time", bson.D{
		{"$gte", start},
		{"$lte", end},
	})

	count, err := l.svcCtx.ReadDB.PartnerInvite.Count(l.ctx, filter)
	if err != nil {
		return types.PartnerInvitedUserItem{}, err
	}

	time := time.UnixMilli(start)
	return types.PartnerInvitedUserItem{
		Date:  fmt.Sprintf("%04d-%02d-%02d", int(time.Year()), int(time.Month()), time.Day()),
		Count: count,
	}, nil
}
