package kafka_proxy

import (
	"content_svr/config"
	"strings"
)

var (
	// topics
	topicDataChange               = "workshop_data_change"
	topicinterfaceLogger          = "interface_logger"
	topicPersonalWebsocketMessage = "personal_websocket_message"
	topicSignQQMessage            = "sign_qq_message"
	topicDataStatistics           = "data_statistics"
	topicPersonalBottleWorksEs    = "personal_bottle_works_es"
	topicSecretAsyncAudit         = "secret_async_audit"
	topicComplainStatistics       = "complain_statistics"
	topicServe2backstage          = "workshop_serve_to_backstage"
	topicSecretPushMessage        = "secret_push_message"
	topicSecretLogGather          = "secret_log_gather"

	// TsnPushSingleMessageDto.type
	tsnType_single_message = "single_message"

	// TsnPushSingleMessageDto.MessageType
	tsnMsgType_notify = "notify"
)

type constParamDef struct {
	redPacket       string
	normalRedPacket string
	singleTalk      string
	groupTalk       string
	systemMessage   string
}

var ConstParamDef = &constParamDef{
	redPacket:       "redPacket",
	normalRedPacket: "normalRedPacket",
	singleTalk:      "singleTalk",
	groupTalk:       "groupTalk",
	systemMessage:   "systemMessage",
}

func getTopic(topic string) string {
	if strings.ToLower(config.ServerConfig.Env) == "prod" {
		return topic
	} else {
		return "test_" + topic
	}
}

func getTsnEnv() string {
	if config.ServerConfig.Env == "prod" {
		return "product"
	} else {
		return "dev"
	}
}
