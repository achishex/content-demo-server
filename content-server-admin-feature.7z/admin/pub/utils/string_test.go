package utils

import "testing"

func TestUnderscoreToCamelCase(t *testing.T) {
	t.Log(UnderscoreToCamelCase("show_scope"))
	t.Log(UnderscoreToCamelCase("showScope"))
}
