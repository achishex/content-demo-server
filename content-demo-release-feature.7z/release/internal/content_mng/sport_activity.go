package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/mg_model"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"math"
	"time"
)

func (p *ContentMng) QuerySportStatus(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.SecretSportStatusResponse, error) {
	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil || loginUserInfo == nil {
		return nil, errorcode.USER_ENABLED_ERROR
	}

	//nowTm := time.Date(2023, 8, 16,
	//	config.ServerConfig.SportTime.ActivityOpenHour, config.ServerConfig.SportTime.ActivityOpenMinter,
	//	0, 0, time.Now().Location())
	nowTm := time.Now()
	activityPhone := getActivityPhone(nowTm)
	//上一期开始时间，用于activity_status为1时，也就是等待开奖
	activityLastPhone := getActivityLastNTime(nowTm, 1)
	activityEnd := getActivityEndTime(nowTm)

	// 获取今天和前三天数据
	eqConds := map[string]interface{}{
		"user_id": loginUserInfo.UserInfoDbModel.GetUserId(),
	}
	//>=
	largeConds := map[string]interface{}{
		"cur_activity_date": getActivityLastThreeTime(activityPhone).UnixMilli(),
	}
	// <=
	lessConds := map[string]interface{}{
		"cur_activity_date": activityEnd.UnixMilli(),
	}
	//
	orderCond := map[string]interface{}{
		"cur_activity_date": -1,
	}
	resp := &pbapi.SecretSportStatusResponse{}
	queryData, err := p.DataCache.GetImpl().SportActivityMgModel.QueryItemBasic(ctx, eqConds, largeConds, lessConds, orderCond, 0)
	if err != nil {
		//fmt.Println(err)
		logger.Infof(ctx, "not data for user: %d", loginUserInfo.UserInfoDbModel.GetUserId())
		return nil, err
	}

	if queryData != nil && len(queryData) == 0 {
		return resp, nil
	}

	day3, today := p.getDay3AndToday(queryData, nowTm, activityPhone, activityLastPhone)
	fishTotal, stepTotal, userTotal, err := p.QueryTotalFishAndStepNums(ctx, today.GetCurActivityDate())
	if err != nil {
		logger.Error(ctx, "QueryTotalFishAndStepNums", err)
	}
	// 今日数据,未开奖时候为上一期数据
	resp.TodayRecord = p.getTodaySportActivity(ctx, today, fishTotal, stepTotal, userTotal)

	// 历史数据
	if day3 != nil {
		resp.Day3HistoryRecord = p.getDay3SportActivity(ctx, day3)
	}

	_, allRank, err := p.getNowRanker(ctx, loginUserInfo.UserInfoDbModel.GetUserId(), activityPhone)
	if err != nil {
		logger.Error(ctx, "getNowRanker", err)
	}
	resp.RankerUser = allRank

	//获取用户的所有鱼干记录：
	userAllDetail := p.getUserAllDetail(ctx, loginUserInfo.UserInfoDbModel.GetUserId())
	// 用户拥有的总鱼干数
	userFishTotalNums := p.getUserHaveFishCount(ctx, loginUserInfo.UserInfoDbModel.GetUserId())

	resp.FishDetail = userAllDetail
	resp.TotalFishNums = proto.Int64(userFishTotalNums)
	return resp, nil
}

// CurrentActivityRanker 查询活动排行榜
func (p *ContentMng) CurrentActivityRanker(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.SecretSportAwardRankerDetail, error) {
	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil || loginUserInfo == nil {
		return nil, errorcode.USER_ENABLED_ERROR
	}

	nowTm := time.Now()
	var targetPhone time.Time
	if checkActivityTime(nowTm) {
		targetPhone = getActivityPhone(nowTm)
	} else {
		targetPhone = getActivityLastNTime(nowTm, 1)
	}

	userRanker, allRanker, err := p.getNowRanker(ctx, loginUserInfo.UserInfoDbModel.GetUserId(), targetPhone)

	if userRanker == nil {
		// 若该用户，未提交过
		userRanker = &pbapi.SecretSportRanker{
			NickName: loginUserInfo.UserInfoDbModel.GetNickName(),
			Header:   loginUserInfo.UserInfoDbModel.GetPhoto(),
			Ranker:   -1,
		}
	}

	result := &pbapi.SecretSportAwardRankerDetail{
		AllRanker:     allRanker,
		UserRanker:    userRanker,
		ActivityTitle: proto.String(fmt.Sprintf("%02d%02d", targetPhone.Month(), targetPhone.Day())),
	}

	return result, nil
}

// QueryTotalFishAndStepNums 计算该期活动的总鱼干数，总步数，总人数
func (p *ContentMng) QueryTotalFishAndStepNums(ctx context.Context, millActivityTime int64) (int64, int64, int64, error) {
	if millActivityTime <= 0 {
		logger.Errorf(ctx, "input param is empty")
		return 1000, 0, 0, errorcode.USER_ENABLED_ERROR
	}

	userTotal, stepTotal, err := p.DataCache.AggregateRankerUserByRedis(ctx, millActivityTime)
	if err != nil {
		logger.Error(ctx, "QueryTotalFishAndStepNums: ", err)
		return 1000, 0, 0, errorcode.USER_ENABLED_ERROR
	}

	totalFishNums := calcFishTotal(userTotal)
	return totalFishNums, stepTotal, userTotal, nil
}

// UpdateFishNumsForAllUser 更新所有用户拥有的鱼干数
func (p *ContentMng) UpdateFishNumsForAllUser(ctx context.Context, millActivityTime int64, totalFishNums, totalStepNums, totalUserNums int64) error {
	//
	yesterdayTime := time.UnixMilli(millActivityTime)
	titleMonthDay := fmt.Sprintf("%02d%02d", yesterdayTime.Month(), yesterdayTime.Day())
	awardOpenTime := millActivityTime + (time.Hour * 24).Milliseconds()
	lastUserId := int64(0)
	eqConds := map[string]interface{}{
		"cur_activity_date": millActivityTime,
		"activity_status":   const_busi.SportActivityOn,
	}
	sortField := map[string]interface{}{
		"user_id": 1,
	}
	limits := int32(100)
	var activityDetail []*pbmgdb.UserSportActivityDetail
	var err error

	for {
		largeConds := map[string]interface{}{
			"user_id": lastUserId,
		}

		activityDetail, err = p.DataCache.GetImpl().SportActivityMgModel.QueryItemBasic(ctx,
			eqConds, largeConds, nil, sortField, limits)
		if err != nil {
			logger.Errorf(ctx, "query sport activity detail for cur_activity_date: %v fail, err: %v", millActivityTime, err)
			return err
		}
		if len(activityDetail) <= 0 {
			break
		}

		for _, v := range activityDetail {
			if v == nil {
				continue
			}
			stepNums := v.GetSportStepNums()
			oneUserFishNums := calcPredictFish(ctx, stepNums, totalStepNums, totalUserNums)
			lastUserId = v.GetUserId()

			eqConds := map[string]interface{}{
				"cur_activity_date": millActivityTime,
				"user_id":           lastUserId,
			}
			updateFields, err := utils.StructToJsonMap(&pbmgdb.UserSportActivityDetail{
				ActivityStatus:     proto.Int32(const_busi.SportActivityOpenAward),
				AwardFishNums:      proto.Int64(oneUserFishNums),
				FishItemName:       proto.String(titleMonthDay),
				AwardOpenTime:      proto.Int64(awardOpenTime),
				TotalStepNumsUsers: proto.Int64(totalStepNums),
				TotalFishNumsUsers: proto.Int64(totalFishNums),
				TotalUserNumsAll:   proto.Int64(totalUserNums),
			})
			if err != nil {
				logger.Error(ctx, "StructToJsonMap", err)
				continue
			}

			fishEqConds := map[string]interface{}{
				"userId": lastUserId,
			}

			updatePersonalUserAccount := map[string]interface{}{
				"fish": oneUserFishNums,
			}

			insertPersonalUserAccount, err := utils.StructToJsonMap(&pbmgdb.PersonalUserAccountMgDbModel{
				Id:        lastUserId,
				UserId:    proto.Int64(lastUserId),
				Timestamp: proto.Int64(time.Now().UnixMilli()),
				Fish:      proto.Int64(oneUserFishNums),
			})

			err = p.DataCache.GetImpl().SportActivityMgModel.TransactionFishToSportTableAndPersonalTable(ctx, []mg_model.SessionParams{
				{Filter: eqConds, Data: updateFields},
				{Filter: fishEqConds, Data: nil},
				{Filter: fishEqConds, Data: updatePersonalUserAccount},
				{Filter: nil, Data: insertPersonalUserAccount},
			})
			if err != nil {
				logger.Error(ctx, "", err)
			}

		}
	}
	return nil
}

// PredictFishNums 预估鱼干数
func (p *ContentMng) PredictFishNums(ctx context.Context, header *pbapi.HttpHeaderInfo, step int64) (int64, error) {
	userInfo, err := p.getUserInfo(ctx, header)
	if err != nil || userInfo == nil {
		return 0, errorcode.USER_ENABLED_ERROR
	}

	now := time.Now()
	activityPhone := getActivityPhone(now)
	activityEndTime := getActivityEndTime(now)

	filter := bson.D{
		{"create_time", bson.D{
			{"$gte", activityPhone.UnixMilli()},
			{"$lt", activityEndTime.UnixMilli()},
		},
		},
		{
			"user_id", bson.D{
				{"$ne", userInfo.UserInfoDbModel.GetUserId()},
			},
		},
	}

	pipeline := []bson.M{
		{"$match": filter},
		{"$group": bson.M{
			"_id":        nil,
			"step_total": bson.M{"$sum": "$sport_step_nums"},
			"user_total": bson.M{"$sum": 1},
		},
		},
	}

	aggregate, err := p.DataCache.GetImpl().SportActivityMgModel.GetAggregateUserActivitySport(ctx, pipeline)
	switch {
	case err == errorcode.Sport_step_zero:
		break
	case err != nil:
		logger.Error(ctx, "GetAggregateUserActivitySport: ", err)
		return 0, errorcode.Sport_status_query_fail
	}

	return calcPredictFish(ctx, step, step+aggregate.StepTotal, aggregate.UserTotal+1), nil

}

// UpsertSportStep 更新用户本期步数
func (p *ContentMng) UpsertSportStep(ctx context.Context, header *pbapi.HttpHeaderInfo, step int64) (*pbapi.SecretSportAwardPushStepResp, error) {
	now := time.Now()
	cfg := config.ServerConfig.SportTime
	activityPhone := getActivityPhone(now)
	activityEndTime := getActivityEndTime(now)
	if now.After(activityEndTime) {
		return nil, errorcode.Sport_activity_not_begin
	}

	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil || loginUserInfo == nil {
		return nil, errorcode.USER_ENABLED_ERROR
	}
	userId := loginUserInfo.UserInfoDbModel.GetUserId()

	filter := bson.D{
		{"user_id", userId},
		{"cur_activity_date", activityPhone.UnixMilli()}}

	spd, err := utils.StructToJsonMap(&pbmgdb.UserSportActivityDetail{
		CreateTime:         proto.Int64(now.UnixMilli()),
		SportStepNums:      proto.Int64(step),
		ActivityStatus:     proto.Int32(const_busi.SportActivityOn),
		AwardFishNums:      proto.Int64(0),
		UserId:             proto.Int64(userId),
		FishItemName:       proto.String(fmt.Sprintf("%02d%02d", activityPhone.Month(), activityPhone.Day())),
		AwardOpenTime:      proto.Int64(0),
		CurActivityDate:    proto.Int64(activityPhone.UnixMilli()),
		TotalStepNumsUsers: proto.Int64(0),
		TotalFishNumsUsers: proto.Int64(0),
		TotalUserNumsAll:   proto.Int64(0),
	})

	_, err = p.DataCache.GetImpl().SportActivityMgModel.QuerySportStepByUserID(ctx, userId, activityPhone.UnixMilli())
	if err != nil {
		_, err := p.DataCache.GetImpl().SportActivityMgModel.InsertSportStep(ctx, spd)
		if err != nil {
			logger.Error(ctx, "UpsertSportStep error: ", err)
			return nil, errorcode.Sport_push_fail
		}
	} else {
		update := bson.D{
			{"$set", bson.D{
				{"sport_step_nums", step},
			}},
		}
		_, err = p.DataCache.GetImpl().SportActivityMgModel.UpdateSportStep(ctx, filter, update)
		if err != nil {
			logger.Error(ctx, "UpsertSportStep error: ", err)
			return nil, errorcode.Sport_push_fail
		}
	}

	// save redis
	tomorrowLastTime := time.Date(now.Year(), now.Month(), now.Day()+4, cfg.ActivityOpenHour, cfg.ActivityOpenMinter, 0, 0, now.Location())
	intervalTime := tomorrowLastTime.Sub(now).Seconds()
	phone := getActivityPhone(now)
	if err := p.DataCache.SetActivityRankerByStep(ctx, phone.UnixMilli(), userId, step, int64(intervalTime)); err != nil {
		return nil, errorcode.Sport_push_fail
	}

	pipeline := bson.M{
		"$group": bson.M{
			"_id":        nil,
			"user_total": bson.M{"$sum": 1},
		},
	}

	filter = bson.D{
		{"cur_activity_date", activityPhone.UnixMilli()}}
	pipelines := []bson.M{
		{"$match": filter},
		pipeline,
	}
	aggregateSport, err := p.DataCache.GetImpl().SportActivityMgModel.GetAggregateUserActivitySport(ctx, pipelines)
	if err != nil {
		return nil, err
	}

	fishTotal := calcFishTotal(aggregateSport.UserTotal)
	result := &pbapi.SecretSportAwardPushStepResp{
		TotalFishNumsUsers: &fishTotal,
		TodayStepNums:      &step,
	}

	return result, nil
}

// 获取该用户拥有的所有鱼干数
func (p *ContentMng) getUserHaveFishCount(ctx context.Context, useId int64) int64 {
	eqConds := map[string]interface{}{
		"userId": useId,
	}
	fishData, err := p.DataCache.GetImpl().PersonalUserAccountMgDbModel.GetItems(ctx, eqConds)
	var userFishTotalNums int64
	if err == nil && len(fishData) > 0 {
		for _, v := range fishData {
			userFishTotalNums = v.GetFish()
			break
		}
	}

	return userFishTotalNums
}

// 获取该用户参加过的所有活动记录
func (p *ContentMng) getUserAllDetail(ctx context.Context, useId int64) []*pbapi.SecretSportAwardFishItem {
	eqConds := map[string]interface{}{
		"user_id":         useId,
		"activity_status": const_busi.SportActivityOpenAward,
	}
	sortField := map[string]interface{}{
		"create_time": -1,
	}
	fishItems, err := p.DataCache.GetImpl().SportActivityMgModel.QueryItemBasic(ctx, eqConds, nil, nil, sortField, 0)
	var fishDetail []*pbapi.SecretSportAwardFishItem
	if err == nil && len(fishItems) > 0 {
		for _, v := range fishItems {
			if v == nil {
				continue
			}
			titleName := fmt.Sprintf("猫爪运动-%v期-开奖", v.GetFishItemName())
			item := &pbapi.SecretSportAwardFishItem{
				WayFishGotten:  &titleName,
				TimeFishGotten: v.AwardOpenTime,
				FishNums:       v.AwardFishNums,
			}

			fishDetail = append(fishDetail, item)
		}

	}
	return fishDetail

}

// 获取该列表中最后一条历史数据和今日数据
func (p *ContentMng) getDay3AndToday(details []*pbmgdb.UserSportActivityDetail, nowTm, activityPhone, activityLastPhone time.Time) (
	day3 *pbmgdb.UserSportActivityDetail, today *pbmgdb.UserSportActivityDetail) {
	for _, detail := range details {
		if checkActivityTime(nowTm) {
			switch {
			case detail.GetCurActivityDate() == activityPhone.UnixMilli():
				today = detail
				continue
			}

		} else {
			// 等待开奖
			switch {
			case detail.GetCurActivityDate() == activityPhone.UnixMilli():
				continue
			case detail.GetCurActivityDate() == activityLastPhone.UnixMilli():
				today = detail
				today.ActivityStatus = proto.Int32(const_busi.SportActivityClose)
				continue
			}
		}

		day3 = detail
		break
	}

	if today == nil {
		today = &pbmgdb.UserSportActivityDetail{CurActivityDate: proto.Int64(activityPhone.UnixMilli())}
	}

	return
}

// 获取排行数据
func (p *ContentMng) getNowRanker(ctx context.Context, loginUserId int64, activityPhone time.Time) (
	*pbapi.SecretSportRanker, []*pbapi.SecretSportRanker, error) {

	//activityPhone = time.UnixMilli(1690840800000)
	// 获取redis前二十，以免突然有个账号注销，导致最后得到的上榜人数不够十个
	userStepMap, err := p.DataCache.GetRankerUserTop20(ctx, activityPhone.UnixMilli())
	if err != nil {
		logger.Error(ctx, "GetRankerUserTop20: ", err)
		return nil, nil, err
	}
	// redis
	loginUserRank, loginUserStep, err := p.DataCache.GetRankerIdForUser(ctx, activityPhone.UnixMilli(), loginUserId)
	if err != nil {
		loginUserDetailSport, err := p.DataCache.GetImpl().SportActivityMgModel.QuerySportStepByUserID(ctx, activityPhone.UnixMilli(), loginUserId)
		if err != nil {
			logger.Error(ctx, "GetRankerIdForUser.QuerySportStepByUserID", err)
		}
		if loginUserDetailSport != nil {
			loginUserStep = loginUserDetailSport.GetSportStepNums()
		}

	}
	userStepMap.Set(loginUserId, loginUserStep)

	userIds := userStepMap.GetInt64RangeKeys()
	// mysql 查询该数组上用户个人信息
	userInfos, err := p.DataCache.GetImpl().UserInfoModel.GetByUserIds(ctx, userIds)
	if err != nil {
		logger.Error(ctx, "UserInfoModel.GetByUserIds: ", err)
		return nil, nil, err
	}
	// redis
	_, stepTotal, userTotal, err := p.QueryTotalFishAndStepNums(ctx, activityPhone.UnixMilli())
	if err != nil {
		logger.Error(ctx, "QueryTotalFishAndStepNums: ", err)
		return nil, nil, err
	}

	// packet
	userInfoMap := map[int64]*pbapi.UserinfoDbModel{}
	var userRanker *pbapi.SecretSportRanker
	var otherUserRanker = make([]*pbapi.SecretSportRanker, 0)
	var rank int64
	var lastOne int64
	for _, info := range userInfos {
		userInfoMap[info.GetUserId()] = info
	}
	for _, userId := range userIds {
		uInfo := userInfoMap[userId]
		if uInfo == nil {
			continue
		}

		step := userStepMap.GetInt64(userId)
		if step != lastOne {
			// 上一个和下一个步数相同时, rank 不变
			rank = int64(len(otherUserRanker)) + 1
		}
		lastOne = step

		nickName := uInfo.GetNickName()
		if uInfo.NickName == nil {
			nickName = uInfo.GetOpenNickName()
		}
		photo := uInfo.GetPhoto()
		if uInfo.Photo == nil {
			photo = uInfo.GetOpenPhoto()
		}

		pFish := calcPredictFish(ctx, step, stepTotal, userTotal)
		ranker := &pbapi.SecretSportRanker{
			NickName: nickName,
			Header:   photo,
			Ranker:   rank,
			Steps:    step,
			Score:    pFish,
		}

		if loginUserId == userId && userRanker == nil {
			ranker.Ranker = loginUserRank
			ranker.Steps = loginUserStep
			userRanker = ranker
		}
		if rank > 10 || rank <= 0 {
			// 10 名开外 或 未上榜
			continue
		}

		otherUserRanker = append(otherUserRanker, ranker)
	}

	return userRanker, otherUserRanker, nil
}

// 获取redis中用户某次活动打败猫友数据
func (p *ContentMng) getSportActivityUserRankSite(ctx context.Context, activityPhone int64, userId int64) int32 {
	_, _, userTotal, err := p.QueryTotalFishAndStepNums(ctx, activityPhone)
	if err != nil {
		return const_busi.NoSportActivityRank
	}
	//p.DataCache.SetActivityRankerByStep(ctx, activityPhone, 44459882504192, 0, 86400)
	//p.DataCache.SetActivityRankerByStep(ctx, activityPhone, 4421654724417536, 816, 86400)
	userRank, _, err := p.DataCache.GetRankerIdForUser(ctx, activityPhone, userId)
	if err != nil {
		userRank = 0
		eqConds := map[string]interface{}{
			"user_id":           userId,
			"cur_activity_date": activityPhone,
		}
		sortField := map[string]interface{}{
			"cur_activity_date": -1,
		}
		ads, err := p.DataCache.GetImpl().SportActivityMgModel.QueryItemBasic(ctx, eqConds, nil, nil, sortField, 0)
		if err != nil {
			return 0
		}
		for i, ad := range ads {
			if ad.GetUserId() == userId {
				userRank = int64(i + 1)
				//intervalTime := time.Hour * 24 * 3
				//p.DataCache.SetActivityRankerByStep(ctx, activityPhone, userId, ad.GetSportStepNums(), int64(intervalTime))
			}
		}

	}

	if userTotal == 1 || userRank == 1 {
		// 第一名
		return 100
	}
	rate := int32(math.Round(100 * (float64(userTotal-userRank) / float64(userTotal))))
	return rate
}

// 计算构建返回今日数据
func (p *ContentMng) getTodaySportActivity(ctx context.Context, today *pbmgdb.UserSportActivityDetail, fishTotal, stepTotal, userTotal int64) *pbapi.SecretSportAwardToday {
	date := time.UnixMilli(today.GetCurActivityDate())
	endTime := getActivityEndTime(date)

	fishNumsUser := calcPredictFish(ctx, today.GetSportStepNums(), stepTotal, userTotal)
	userStep := int32(today.GetSportStepNums())
	status := today.GetActivityStatus()

	phone := fmt.Sprintf("%02d%02d", date.Month(), date.Day())
	openAward := endTime.UnixMilli()
	remainingTime := caleRemainingTime(date)

	return &pbapi.SecretSportAwardToday{
		TotalFishAllUsersToday: proto.Int64(fishTotal),
		ScoreToday:             proto.Int32(int32(fishNumsUser)),
		PushStepValidTime:      proto.Int64(remainingTime),
		CurrentUserStep:        proto.Int32(userStep),
		ActivityTitle:          proto.String(phone),
		OpenAwardTime:          proto.Int64(openAward),
		ActivityStatus:         proto.Int32(status),
	}
}

func (p *ContentMng) getDay3SportActivity(ctx context.Context, detail *pbmgdb.UserSportActivityDetail) *pbapi.SecretSportAwardedNoCheck {

	userFishNums := int32(detail.GetTotalFishNumsUsers())
	targetActivityFishNums := int32(detail.GetAwardFishNums())
	targetActivityTotalUser := int32(detail.GetTotalUserNumsAll())
	targetActivityUserStep := int32(detail.GetSportStepNums())
	rate := p.getSportActivityUserRankSite(ctx, detail.GetCurActivityDate(), detail.GetUserId())
	return &pbapi.SecretSportAwardedNoCheck{
		FishTotalNums:   proto.Int32(userFishNums),
		FishNums:        proto.Int32(targetActivityFishNums),
		UserNums:        proto.Int32(targetActivityTotalUser),
		UserCurrentStep: proto.Int32(targetActivityUserStep),
		UserRankingSite: proto.Int32(rate),
		ActivityTitle:   detail.FishItemName,
	}

}

func getActivityLastNTime(date time.Time, n int) time.Time {
	cfg := config.ServerConfig.SportTime
	return time.Date(date.Year(), date.Month(), date.Day()-n,
		cfg.ActivityOpenHour, cfg.ActivityOpenMinter,
		0, 0, date.Location())
}

// 获取该时间的活动号，开始时间
func getActivityPhone(date time.Time) time.Time {
	cfg := config.ServerConfig.SportTime

	return time.Date(date.Year(), date.Month(), date.Day(),
		cfg.ActivityOpenHour, cfg.ActivityOpenMinter,
		0, 0, date.Location())
}

// 获取该时间的活动结束时间
func getActivityEndTime(date time.Time) time.Time {
	cfg := config.ServerConfig.SportTime

	return time.Date(date.Year(), date.Month(), date.Day(),
		cfg.ActivityEndHour, cfg.ActivityEndMinter,
		0, 0, date.Location())
}

// 获取该时间三天前时间
func getActivityLastThreeTime(date time.Time) time.Time {
	cfg := config.ServerConfig.SportTime
	return time.Date(date.Year(), date.Month(), date.Day()-3,
		cfg.ActivityEndHour, cfg.ActivityEndMinter,
		0, 0, date.Location())
}

// 检查是否在活动期间
func checkActivityTime(date time.Time) bool {
	activityOpenTime := getActivityPhone(date)
	activityEndTime := getActivityEndTime(date)
	return date.After(activityOpenTime) && date.Before(activityEndTime)
}

// 活动剩余时间
func caleRemainingTime(date time.Time) int64 {
	endTime := getActivityEndTime(date)
	remainingTime := endTime.Sub(date).Milliseconds()
	if date.After(endTime) {
		remainingTime = time.Minute.Milliseconds()
	}
	return remainingTime
}

// 本期总鱼干数
func calcFishTotal(totalUser int64) int64 {
	return 1000 + totalUser*100
}

// 计算预估鱼干数
// 总鱼干数 = 1000 + 总人数 *100
// 预估鱼干数 = （当前步数 / 总步数）* 总鱼干数
func calcPredictFish(ctx context.Context, nowStep, stepNumsTotal, userTotal int64) int64 {
	if nowStep > const_busi.MaxValidSteIpNumsForUser {
		nowStep = const_busi.MaxValidSteIpNumsForUser
	}

	if nowStep < 0 {
		nowStep = 0
	}

	if stepNumsTotal < nowStep {
		logger.Errorf(ctx, "总步数小于当前步数, stepNumsTotal: %d, nowStep: %d \n", stepNumsTotal, nowStep)
		stepNumsTotal = nowStep
	}

	fish := int64(math.Round((float64(nowStep) / float64(stepNumsTotal)) * float64(calcFishTotal(userTotal))))
	if fish < 0 {
		return 0
	}
	return fish
}
