package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var _ PersonalPoliceDailyDataModel = (*customPersonalPoliceDailyDataModel)(nil)

type (
	// PersonalPoliceDailyDataModel is an interface to be customized, add more methods here,
	// and implement the added methods in customPersonalPoliceDailyDataModel.
	PersonalPoliceDailyDataModel interface {
		personalPoliceDailyDataModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]PersonalPoliceDailyData, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*PersonalPoliceDailyData, error)
	}

	customPersonalPoliceDailyDataModel struct {
		*defaultPersonalPoliceDailyDataModel
	}
)

// NewPersonalPoliceDailyDataModel returns a model for the mongo.
func NewPersonalPoliceDailyDataModel(cfg MonConfig, opts ...mon.Option) PersonalPoliceDailyDataModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), collectionNamePersonalPoliceDailyData, opts...)
	return &customPersonalPoliceDailyDataModel{
		defaultPersonalPoliceDailyDataModel: newDefaultPersonalPoliceDailyDataModel(conn),
	}
}

func (m *customPersonalPoliceDailyDataModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	} else {
		flagType = "default"
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customPersonalPoliceDailyDataModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customPersonalPoliceDailyDataModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]PersonalPoliceDailyData, error) {
	result := make([]PersonalPoliceDailyData, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customPersonalPoliceDailyDataModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*PersonalPoliceDailyData, error) {
	var data PersonalPoliceDailyData
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
