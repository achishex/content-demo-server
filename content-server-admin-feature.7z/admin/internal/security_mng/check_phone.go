package security_mng

import "context"

// 状态码 0 为通过，1为不通过
func (p *SecurityMng) CheckTelPhone(ctx context.Context, phoneNum string) (int32, error) {
	result, _, err := p.ShumeiProxy.CheckTelPhone(ctx, phoneNum)
	if err != nil {
		return 0, err
	}

	return result, nil
}
