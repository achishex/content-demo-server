package di

import (
	"content_svr/config"
	model2 "content_svr/db/mongodb/model"
	"content_svr/db/redisdb/query_rds"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/mg_model"
	"content_svr/internal/model"
	"content_svr/internal/model/im"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/dtm-labs/rockscache"
	rdsV8 "github.com/go-redis/redis/v8"
	rdsV9 "github.com/redis/go-redis/v9"
	"go.mongodb.org/mongo-driver/mongo"
	"go.uber.org/dig"
	"gorm.io/gorm"
	"time"
)

func NewKafkaProxyByConf() kafka_proxy.IKafkaProxy {
	return kafka_proxy.NewKafkaProxyImpl(config.ServerConfig.KafkaConfig)
}

func NewMongoDBByConf() (*mongo.Client, *mongo.Database, error) {
	mgcli, err := mg_model.NewMongoDBInstance(config.ServerConfig.MongodbConfig)
	if err != nil {
		return nil, nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()
	err = mgcli.Ping(timeoutCtx, nil)
	if err != nil {
		logger.Error(context.Background(), "ping mongo fail, err: %v", err)
		return nil, nil, err
	}
	return mgcli, mgcli.Database(config.ServerConfig.MongodbConfig.DBName), nil
}

func NewParseTimeDB() (model.ParseTimeDB, error) {
	db, err := model.NewDBInstance(config.ServerConfig.MysqlConfig, true)
	if err != nil {
		return nil, fmt.Errorf("new platform db instansce failed, err: %v", err)
	}
	return db, nil
}
func NewPlatformAndIMDB() (*gorm.DB, im.IMDB, error) {
	db, err := model.NewDBInstance(config.ServerConfig.MysqlConfig, false)
	if err != nil {
		return nil, nil, fmt.Errorf("new platform db instansce failed, err: %v", err)
	}
	//初始化IM DB
	dbIm, err := model.NewDBInstance(config.ServerConfig.MysqlImConfig, false)
	if err != nil {
		return nil, nil, fmt.Errorf("new im db instansce failed, err: %v", err)
	}
	return db, im.IMDB(dbIm), nil
}

type RdbDIOut struct {
	dig.Out

	// V8Rdb use V9 instead
	V8Rdb             *rdsV8.Client
	V9Rdb             rdsV9.UniversalClient
	RocketCacheClient *rockscache.Client
}

func NewRdsClientByConf() RdbDIOut {
	v8 := newRdsClient(config.ServerConfig.RedisConfig.Addr, config.ServerConfig.RedisConfig.Pwd)

	v9 := rdsV9.NewUniversalClient(&rdsV9.UniversalOptions{
		Addrs:        []string{config.ServerConfig.RedisConfig.Addr},
		Password:     config.ServerConfig.RedisConfig.Pwd,
		DB:           0,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 30 * time.Second,
		PoolSize:     500,
	})
	ctx := context.Background()
	err := v9.Ping(ctx).Err()
	if err != nil {
		panic(err)
	}

	rcc := rockscache.NewClient(v9, rockscache.NewDefaultOptions())
	out := RdbDIOut{
		V8Rdb:             v8,
		V9Rdb:             v9,
		RocketCacheClient: rcc,
	}
	return out
}

func newRdsClient(addr, pwd string) *rdsV8.Client {
	client := rdsV8.NewClient(&rdsV8.Options{
		Addr:         addr,
		Password:     pwd,
		DB:           0,
		ReadTimeout:  2 * time.Minute,
		WriteTimeout: 1 * time.Minute,
		PoolTimeout:  2 * time.Minute,
		IdleTimeout:  10 * time.Minute,
		PoolSize:     1000,
	})
	_, err := client.Ping(context.Background()).Result()
	if err != nil {
		panic(fmt.Sprintf("redis init failed. err:%v", err.Error()))
	}
	return client
}

type MongoConfig struct {
	URI, DBName string
}

func (m *MongoConfig) GetURL() string {
	return m.URI
}

func (m *MongoConfig) GetDBName() string {
	return m.DBName
}

func NewMongoConf() model2.MonConfig {
	return config.ServerConfig.MongodbConfig
}

func NewQueryMng(rdb *rdsV8.Client) *query_rds.Manage {
	env := config.ServerConfig.Env
	return query_rds.NewClient(rdb, env)
}
