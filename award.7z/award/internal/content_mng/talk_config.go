package content_mng

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/user"
	"context"
)

func (p *ContentMng) SetTalkConfig(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.TalkMessageSecurityConfigReq) error {
	loginUser, err := p.getUserInfo(ctx, header)
	if err != nil {
		return err
	}

	isAdult, _ := user.JudgeAdult(loginUser.UserInfoDbModel.GetBirth())
	if !isAdult && req.GetTalkMode() == const_busi.TalkModeOpen {
		return errorcode.TalkModeError
	}

	if loginUser.PsecretUserExtInfo.GetUlevel() < 4 {
		return errorcode.TalkModeLevelError
	}

	data := map[string]interface{}{
		"talkMode": req.GetTalkMode(),
	}
	err = p.DataCache.GetImpl().UserInfoExtMgModel.UpdateDictById(ctx, loginUser.UserInfoDbModel.GetUserId(), data, nil)
	if err != nil {
		return err
	}
	err = p.DataCache.GetImpl().SetUserInfoTalkMode(ctx, loginUser.UserInfoDbModel.GetUserId(), req.GetTalkMode())
	if err != nil {
		return err
	}
	return nil
}
