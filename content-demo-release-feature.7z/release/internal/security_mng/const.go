package security_mng

// 1 appId传：default
// 2 eventId传：
// 昵称：nickname
// 评论：comment
// 个人简介/签名：profile
// 私聊：message
// 帖子：article
//
// 3 type建议传：TEXTRISK
// 4 接口文档：https://help.ishumei.com/docs/tj/text/newest/developDoc
type articleEventId struct {
	Nickname string //昵称
	Comment  string // 评论
	Profile  string // 个人简介/签名
	Message  string // 私聊
	Article  string // 帖子
}

var MArticleEventId = &articleEventId{
	Nickname: "nickname",
	Comment:  "comment",
	Profile:  "profile",
	Message:  "message",
	Article:  "article",
}

// 图片传参：
// 1 appId传：default
// 2 eventId：
// 私聊：message
// 帖子：article
// 头像：headimgurl
// 相册：album
// 评论：comment
// 3 type建议传：POLITY_EROTIC_VIOLENT_ADVERT_QRCODE_IMGTEXTRISK
// 4 接口文档：https://help.ishumei.com/docs/tj/image/newest/developDoc/
type imgEventId struct {
	Message   string // 私聊
	Article   string // 帖子
	HeadImage string //头像
	Album     string //  相册
	Comment   string // 评论
}

var MImgEventId = &imgEventId{
	Message:   "message",
	Article:   "article",
	HeadImage: "headImage",
	Album:     "album",
	Comment:   "comment",
}

// 视频文件传参
//1 appId传：
//默认应用：default
//2 eventId：message
//3 imgType传：POLITY_EROTIC_VIOLENT_ADVERT_QRCODE_IMGTEXTRISK
//   audioType传：POLITICAL_PORN_AD_MOAN_ABUSE
//4 接口文档：https://help.ishumei.com/docs/tj/video/newest/developDoc
//------------------------------------------------------------
//音频文件传参
//1、appId传：default
//2、eventId传：message
//3、type建议传：POLITY_EROTIC_ADVERT_DIRTY_MOAN
//4、接口文档：https://help.ishumei.com/docs/tj/audio/newest/developDoc@张明学
