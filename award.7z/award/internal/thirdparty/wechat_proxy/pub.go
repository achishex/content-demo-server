package wechat_proxy

const (
	//通过code获取access_token
	UrlGetAccessToken = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=%s&secret=%s&code=%s&grant_type=authorization_code"

	//获取微信用户信息
	UrlGetUserInfo = "https://api.weixin.qq.com/sns/userinfo?access_token=%s&openid=%s"
)
