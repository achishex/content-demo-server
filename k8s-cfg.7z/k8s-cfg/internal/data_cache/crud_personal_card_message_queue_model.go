package data_cache

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
)

func (p *DataCacheMng) ListUserReplyMsgDB(ctx context.Context, userId int64, cursorId int64, limit int32) []*pbapi.PersonalCardMessageQueueDbModel {
	//results := make([]*pbapi.PersonalCardMessageQueueDbModel, 0)
	cond := map[string]interface{}{"user_id": userId}
	msgItems, err := p.PersonalCardMessageQueueDbModel.ListAsc(ctx, cond, cursorId, limit)
	if err != nil {
		logger.Error(ctx, "PersonalCardMessageQueueDbModel.listAsc failed", err)
	}
	return msgItems
}

func (p *DataCacheMng) InsertPersonalCardMessageQueueDbModel(ctx context.Context, model *pbapi.PersonalCardMessageQueueDbModel) (*pbapi.PersonalCardMessageQueueDbModel, error) {
	return p.PersonalCardMessageQueueDbModel.CreateItem(ctx, model)
}
