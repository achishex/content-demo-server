package job

import (
	"content_svr/db/dao"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

func InitCleanUserActivity(write, read *dao.ManagerDB) {
	go func() {
		ctrl := newCleanUserActivityControl(write, read)
		//ctrl.once()
		//return

		ctrl.Do(func() {
			ctx := requestid.WithRequestID(context.Background())
			if err := ctrl.DoTask(ctx); err != nil {
				logger.Errorf(ctx, "InitCleanUserActivity: %v\n", err)
				// 五分钟后重试
				ctrl.ticker.Reset(time.Minute * 5)
				return
			}

			ctrl.ticker.Reset(ctrl.calcIntervalTime())
		})

	}()
}

type cleanUserActivityControl struct {
	TickerExecute
	write, read *dao.ManagerDB
}

func newCleanUserActivityControl(write, read *dao.ManagerDB) cleanUserActivityControl {
	// 凌晨五点执行
	ctrl := cleanUserActivityControl{}
	ctrl.hour = 5
	ctrl.write = write
	ctrl.read = read
	return ctrl
}

func (l cleanUserActivityControl) once() {
	ctx := requestid.WithRequestID(context.Background())
	if err := l.DoTask(ctx); err != nil {
		logger.Error(ctx, "InitAwardCalcSum:", err)
	}
}

func (l cleanUserActivityControl) DoTask(ctx context.Context) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	now := time.Now()
	filter := map[string]interface{}{
		"day": bson.D{
			{"$lte", l.calcTimeByDay(now, -40)},
		},
	}
	count, err := l.write.SecretUserActivityDaily.DeleteMany(ctx, filter)
	if err != nil {
		return err
	}
	logger.Infof(ctx, "InitCleanUserActivity delete calcMemberSum: %d", count)

	return nil
}
