package main

import (
	"fmt"
	"os/exec"
	"path/filepath"
	"strings"
)

func ChangeToDoubleHump(str string) string {
	words := strings.Split(str, "_") // 将字符串按照 "_" 分割成多个单词
	for i, word := range words {
		words[i] = strings.Title(word) // 每个单词的首字母大写
	}

	result := strings.Join(words, "") // 连接所有单词
	return result
}

func ChangeToUnderline(str string) string {
	result := ""
	for i, c := range str {
		if i == 0 {
			result += strings.ToLower(string(c))
			continue
		}

		if c >= 'A' && c <= 'Z' {
			result += "_" + strings.ToLower(string(c))
		} else {
			result += string(c)
		}
	}
	return result
}

func FmtFile(wPath string) {
	_ = exec.Command("gofmt", "-l", "-w", wPath).Run()
}

func fmtString(s string) string {
	return fmt.Sprintf(`"%s"`, s)
}

func getPath(p string) string {
	abs, _ := filepath.Abs(p)
	return abs
}

func duplicateTableName(tableNames string) []string {
	nameList := make([]string, 0)
	nameMap := map[string]struct{}{}

	temp := strings.Split(tableNames, ",")
	for _, value := range temp {
		if _, exist := nameMap[value]; exist {
			continue
		} else {
			nameMap[value] = struct{}{}
			nameList = append(nameList, value)
		}
	}

	return nameList
}
