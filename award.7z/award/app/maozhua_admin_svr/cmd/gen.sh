#!/bin/bash

goctl api go -api base.api -dir ../api  --style=go_zero --home=../../../deploy/template

#goctl api plugin -plugin goctl-swagger="swagger -filename mz_admin_setting.json" -api mz_admin_setting.api -dir ./swagger


#for file in *.api; do
#  fileName="${file%.*}"
#  if [ "$fileName" = "base" ]; then
#    continue
#  fi
#
#  if [ "$fileName" = "head" ]; then
#      continue
#  fi
#
#  if [ "$fileName" = "query" ]; then
#      continue
#  fi
#
#  goctl api plugin -plugin goctl-swagger="swagger -filename $fileName.json" -api $fileName.api -dir ./swagger
#done

#swagger serve -F=swagger ./swagger/mz_admin_setting.json


#docker run --rm -p 8083:8080 -e SWAGGER_JSON=/doc/mz_admin_setting.json -v $PWD:/doc swaggerapi/swagger-ui
