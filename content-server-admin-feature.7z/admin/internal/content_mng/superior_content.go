package content_mng

import (
	"content_svr/config"
	"content_svr/db/mongodb/model"
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"content_svr/setting"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"math"
	"strconv"
	"strings"
	"time"
)

const (
	InitStatus     = 0
	WaitSettlement = 1
)
const SuperiorContentDescOnWorkFmt string = "该动态已被系统评为优质，已得现金%.2f元！"

type SuperiorWorkWithExpireTm struct {
	work       *data_cache.WorkInfoLocal
	expireTime float64
}

type SuperiorContentOnWork struct {
	impl            *ContentMng
	workInfo        *pbapi.PersonalBottleWorksDbModel
	commentUserId   int64
	commentUserNums int32
	status          int32
	//
	detailId int64
	//
	immediatelyLogic SettlementImmediately
}
type SettlementImmediately struct {
	awardLevel         int32
	preAwardLevel      int32
	preCommentUserNums int32
	preAwardValue      float64
}

type WorkStatus struct {
	IsSuperiorContent bool
	Award             float64 //按评论数计算奖励
	Url               string
	LatestAwarded     float64 //最新奖励记录
}

func NewSuperiorContentInstance(impl *ContentMng, work *pbapi.PersonalBottleWorksDbModel, commentUserId int64) *SuperiorContentOnWork {
	return &SuperiorContentOnWork{
		impl:            impl,
		workInfo:        work,
		commentUserId:   commentUserId,
		commentUserNums: 0,
		status:          InitStatus,

		immediatelyLogic: SettlementImmediately{
			awardLevel:         -1,
			preAwardLevel:      -1,
			preCommentUserNums: 0,
			preAwardValue:      0.0,
		},
	}
}
func NewSuperiorContentHandlerForWithdrawing(impl *ContentMng, detailId int64) *SuperiorContentOnWork {
	return &SuperiorContentOnWork{
		impl:     impl,
		detailId: detailId,
	}
}
func NewSuperiorContentHandlerForWithdrawSucc(impl *ContentMng, detailId int64) *SuperiorContentOnWork {
	return &SuperiorContentOnWork{
		impl:     impl,
		detailId: detailId,
	}
}
func NewHallOfFameInstance(impl *ContentMng) *SuperiorContentOnWork {
	return &SuperiorContentOnWork{
		impl: impl,
	}
}
func getSuperiorWorkOnUserKey(workUserId int64) string {
	return fmt.Sprintf(cache_const.SuperiorContentWorkOnUserConf.KeyFmt, workUserId)
}
func getSuperiorAwardOnWork(workId int64) string {
	return fmt.Sprintf(cache_const.SuperiorContentAwardOnWorkConf.KeyFmt, workId)
}
func GetWorkValidMinutes() int32 {
	if config.ServerConfig.SuperiorContentConfig != nil {
		return config.ServerConfig.SuperiorContentConfig.WorkCalcValidMinute
	}
	return 3 * 60
}
func GetWorkValidTimeFromCreated(ctx context.Context, createTime string) (int64, error) {
	workCreateTimeMilli, err := TimeStrToSecond(createTime)
	if err != nil {
		logger.Errorf(ctx, "trans work create time: %v fail, err: %v", createTime, err)
		return 0, err
	}

	settlementTimeMill := workCreateTimeMilli + int64(GetWorkValidMinutes()*60*1000)
	return settlementTimeMill, nil
}

// usage: content_mng.NewSuperiorContentInstance(ContentMng, nil, nil).CheckReachAwardCondOnWork(ctx, workId)
func (p *SuperiorContentOnWork) CheckReachAwardCondOnWork(ctx context.Context, workId int64) (int32, error) { // 0: 未达到， 1： 达到，
	validUserNums, _ := p.GetValidCommentUserNums(ctx, workId)
	p.commentUserNums = int32(validUserNums)
	award, _, _ := p.CheckStatus(ctx)
	if award > 0.00001 {
		return 1, nil
	}
	return 0, nil
}
func (p *SuperiorContentOnWork) CalcPreAward(ctx context.Context, validCommentUserNums int32) (float64, error) {
	p.commentUserNums = validCommentUserNums
	award, _, err := p.CheckStatus(ctx)
	return award, err
}
func (p *SuperiorContentOnWork) DelHasSettlementItem(ctx context.Context, workId int64, userId int64) error {
	//delete item
	if err := NewDelayQueue(p.impl.DataCache.GetImpl().RedisCli).ExcludeMsgItem(ctx, workId, GetSuperiorContentQueueKey()); err != nil {
		logger.Errorf(ctx, "del workId: %v from delay queue fail, err: %v", workId, err)
		return err
	}
	if err := p.ExcludeItemWorkForUser(ctx, userId, workId); err != nil {
		logger.Errorf(ctx, "del workId: %v on userId: %v fail, err: %v", workId, userId, err)
		return err
	}
	return nil
}
func GetTotalAwardSafeLockKey() string {
	return ""
}
func (p *SuperiorContentOnWork) GetTotalAwardOnUser(ctx context.Context, userId int64) (*pbmgdb.SuperiorContentAwardDetail, error) {
	ret, err := p.impl.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.GetLatestItemByUserId(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get last superior fail, err: %v", err)
		return nil, err
	}
	return ret, nil
}

func (p *SuperiorContentOnWork) PenalizeWorkAwardWithComment(ctx context.Context, workId int64, commentId int64, commentUserId int64) error {
	if workId <= 0 && commentId > 0 {
		commentDetail, err := p.impl.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentById(ctx, commentId)
		if err == nil || commentDetail != nil {
			workId = commentDetail.GetWorkId()
		}
	}
	eqConds := map[string]interface{}{
		"work_id": workId,
		"status":  1,
		"user_id": commentUserId,
	}
	//
	commentDetail, err := p.impl.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentDetails(ctx, eqConds, nil, nil, nil, 0)
	if err == nil && len(commentDetail) == 0 {
		logger.Infof(ctx, "do superior content check, workId: %v, userId: %v", workId, commentUserId)
		//删除 有效评论人数.
		p.impl.DataCache.IncrValidCommentPersonCount(ctx, workId, commentUserId, -1)
	}
	return nil
}

// 处罚一个动态时，对该动态得到的奖励进行缩减。
func GetWorkInfoOnPenalizedWork(ctx context.Context, mng *ContentMng, workId int64) (*data_cache.WorkInfoLocal, error) {
	filter := bson.D{
		{"work_id", workId},
		{"pass", true},
	}
	catchItem, err := mng.DataCache.GetImpl().AuditAwardRecordMgDbModel.FindOne(ctx, filter)
	if err != nil && err != mongo.ErrNoDocuments {
		logger.Errorf(ctx, "get audit award record fail, workId: %v, err: %v", workId, err)
		return nil, err
	}
	if catchItem != nil {
		logger.Infof(ctx, "has been  Penalize for workId: %v", workId)
		return nil, nil
	}
	workInfo, err := mng.DataCache.GetImpl().GetWorkInfoLocal(ctx, workId, false)
	if err != nil {
		logger.Errorf(ctx, "get work info detail fail, workId: %v", workId)
		return nil, err
	}
	if workInfo == nil {
		logger.Infof(ctx, "get work info is nil, workId: %v", workId)
	}
	return workInfo, nil

}
func (p *SuperiorContentOnWork) PenalizeWorkAward(ctx context.Context, workId int64) error {
	var exist bool = false
	defer func() {
		logger.Infof(ctx, "PenalizeWorkAward workId: %v, exist: %v", workId, exist)
	}()

	//filter := bson.D{
	//	{"work_id", workId},
	//	{"pass", true},
	//}
	//catchItem, err := p.impl.DataCache.GetImpl().AuditAwardRecordMgDbModel.FindOne(ctx, filter)
	//if err != nil && err != mongo.ErrNoDocuments {
	//	logger.Errorf(ctx, "get audit award record fail, workId: %v, err: %v", workId, err)
	//	return err
	//}
	//if catchItem != nil {
	//	logger.Infof(ctx, "has been  Penalize for workId: %v", workId)
	//	return nil
	//}
	//workInfo, err := p.impl.DataCache.GetImpl().GetWorkInfoLocal(ctx, workId, false)
	//if err != nil || workInfo == nil {
	//	logger.Errorf(ctx, "get work info detail fail, workId: %v", workId)
	//	return err
	//}
	workInfo, err := GetWorkInfoOnPenalizedWork(ctx, p.impl, workId)
	if err != nil {
		return err
	}
	if workInfo == nil {
		return nil
	}

	exist, err = NewDelayQueue(p.impl.DataCache.GetImpl().RedisCli).ProbeItemExist(ctx, workId)
	if err != nil {
		logger.Errorf(ctx, "check exist item err: %v", err)
		return err
	}
	if exist {
		p.impl.DataCache.DeleteCommentUsersOnWork(ctx, workId)
		err := p.DelHasSettlementItem(ctx, workId, workInfo.WorkInfoDbModel.GetUserId())
		logger.Infof(ctx, "del has settlement award for workId: %v, userId: %v, ret err: %v", workId, workInfo.WorkInfoDbModel.GetUserId(), err)
		return nil
	}
	//
	workAward, err := p.GetWorkStatusAndAward(ctx, workId)
	if err != nil {
		logger.Errorf(ctx, "get work award fail, err: %v, workId: %v", err, workId)
		return err
	}
	if workAward == nil || workAward.IsSuperiorContent == false {
		logger.Infof(ctx, "workId: %v is not superior content", workId)
		return nil
	}

	err = NewSuperiorContentInstance(p.impl, nil, 0).WriteNewItem(ctx, workId, workInfo.WorkInfoDbModel.GetUserId(),
		workInfo.WorkInfoDbModel.GetTitle(), workAward.Award, model.DeductionIllegal)

	//违规扣除钱包消息
	//钱包消息
	go func() {
		defer func() {
			if err := recover(); err != nil {
				logger.Errorf(ctx, "recover err : %v", err)
			}
		}()

		canWithdrawAward, _ := p.impl.GetCanWithdrawAwardByUserId(ctx, workInfo.WorkInfoDbModel.GetUserId())
		msgData := &pbapi.Wallet{
			Type:       proto.Int32(const_busi.WalletMsgTypeExpense),
			Amount:     proto.String(strconv.FormatFloat(workAward.Award, 'f', 2, 64)),
			Balance:    proto.String(strconv.FormatFloat(canWithdrawAward, 'f', 2, 64)),
			Desc:       proto.String(fmt.Sprintf("“%v...”违规扣除", string([]rune(workInfo.WorkInfoDbModel.GetTitle())[0:4]))),
			CreateTime: proto.Int64(time.Now().UnixMilli()),
		}

		if err := p.impl.SendWalletMsg(ctx, workInfo.WorkInfoDbModel.GetUserId(),
			int32(pbconst.MessageTypeEnum_msg_type_wallet_award_notice),
			fmt.Sprintf("您的动态“%v...”，涉嫌违规，已扣除%v元", string([]rune(workInfo.WorkInfoDbModel.GetTitle())[0:4]), msgData.GetAmount()),
			msgData); err != nil {
			logger.Errorf(ctx, "sendWalletMsg error: %v", err)
			return
		}
	}()

	//userAwardLatest, err := p.GetTotalAwardOnUser(ctx, workInfo.WorkInfoDbModel.GetUserId())
	//if err != nil {
	//	logger.Errorf(ctx, "get user latest award record fail, err: %v, userId: %v", err, workInfo.WorkInfoDbModel.GetUserId())
	//	return err
	//}
	//if userAwardLatest == nil {
	//	return nil
	//}
	//
	//awardInfo := &pbmgdb.SuperiorContentAwardDetail{
	//	Id:             snow_flake.GetSnowflakeID(),
	//	WorkId:         proto.Int64(workId),
	//	UserId:         proto.Int64(workInfo.WorkInfoDbModel.GetUserId()),
	//	SettlementType: proto.Int32(const_busi.DeductionIllegal),
	//	Award:          proto.Float64(workAward.Award),
	//	CreatTime:      proto.Int64(time.Now().UnixMilli()),
	//	TotalAward:     proto.Float64(userAwardLatest.GetTotalAward() - workAward.Award),
	//}
	//if err := p.ModifyItemAwardRecord(ctx, awardInfo); err != nil {
	//	logger.Errorf(ctx, "del work award and note it err: %v, workId: %v", err, workId)
	//	return err
	//}
	p.impl.DataCache.DeleteCommentUsersOnWork(ctx, workId)
	logger.Infof(ctx, "del work award info, workID：%v", workId)
	return nil
}

// 记录流水:新增记录
func (p *SuperiorContentOnWork) AddNewItemAwardRecord(ctx context.Context, item *pbmgdb.SuperiorContentAwardDetail) error {
	if item == nil {
		return nil
	}
	err := p.WriteDownNewItem(ctx, item)
	if err != nil {
		logger.Errorf(ctx, "insert new award record to table fail, err: %v", err)
		return err
	}

	//err = p.SetWorkAwardToCache(ctx, item.GetWorkId(), item.GetAward(), false)
	//if err != nil {
	//	logger.Errorf(ctx, "add new award to redis for work fail, err: %v", err)
	//	return err
	//}
	return nil
}

// 记录流水：修改奖励记录, item.TotalAward 需要实现算好，比如扣除的量.
func (p *SuperiorContentOnWork) ModifyItemAwardRecord(ctx context.Context, item *pbmgdb.SuperiorContentAwardDetail) error {
	if item == nil {
		return nil
	}
	//if err := p.SetWorkAwardToCache(ctx, item.GetWorkId(), item.GetAward(), true); err != nil {
	//	logger.Errorf(ctx, "modify award to redis for work fail, err: %v", err)
	//	return err
	//}

	if err := p.WriteDownNewItem(ctx, item); err != nil {
		logger.Errorf(ctx, "insert new award record to table fail, err: %v", err)
		return err
	}
	return nil
}

func (p *SuperiorContentOnWork) WriteDownNewItem(ctx context.Context, item *pbmgdb.SuperiorContentAwardDetail) error {
	err := p.impl.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.InsertOneItem(ctx, item)
	if err != nil {
		logger.Errorf(ctx, "insert data to db fail, value: %#v", *item)
		return err
	}
	return nil
}
func (p *SuperiorContentOnWork) CheckStatus(ctx context.Context) (float64, int32, error) {
	if config.ServerConfig.SuperiorContentConfig == nil {
		logger.Errorf(ctx, "not config superior Content config")
		return 0.0, 0, errorcode.GenBusiErr(errorcode.WorkNotExist, "superior Content config not exit")
	}
	rules := config.ServerConfig.SuperiorContentConfig.RewardRules
	if len(rules) <= 0 {
		logger.Errorf(ctx, "not config rules for Superior content")
		return 0.0, 0, errorcode.GenBusiErr(errorcode.WorkNotExist, "superior Content config not exit")
	}

	awardValue := float64(0)
	tmpAccount := int32(-1)
	peopleNum := int32(0)

	for i, _ := range rules {
		if p.commentUserNums >= rules[i].Gte && p.commentUserNums < rules[i].Lt {
			p.status = WaitSettlement
			if i == 0 {
				awardValue = setting.Maozhua.Level1WorkAward.Get()
			} else if i == 1 {
				awardValue = setting.Maozhua.Level2WorkAward.Get()
			}
			p.immediatelyLogic.awardLevel = tmpAccount + 1
			peopleNum = rules[i].Gte
			break
		}
		tmpAccount++
	}

	tmpAccount = int32(-1)
	for i, _ := range rules {
		if p.immediatelyLogic.preCommentUserNums >= rules[i].Gte && p.immediatelyLogic.preCommentUserNums < rules[i].Lt {
			p.immediatelyLogic.preAwardLevel = tmpAccount + 1
			if i == 0 {
				p.immediatelyLogic.preAwardValue = setting.Maozhua.Level1WorkAward.Get()
			} else if i == 1 {
				p.immediatelyLogic.preAwardValue = setting.Maozhua.Level2WorkAward.Get()
			}
			break
		}
		tmpAccount++
	}

	return awardValue, peopleNum, nil
}
func TranFloatWith2Bit(data float64) float64 {
	return math.Round(data*100) / 100
}

func float64Addition(left, right float64) float64 {
	l := uint64(math.Round(left * 100))
	r := uint64(math.Round(right * 100))

	amount := l + r
	return float64(amount) / 100
}

// GetWorkStatusAndAward 根据作品评论数计算奖励
func (p *SuperiorContentOnWork) GetWorkStatusAndAward(ctx context.Context, workId int64) (*WorkStatus, error) {
	statusRet := &WorkStatus{}
	commentUserNums, err := p.impl.DataCache.GetValidCommentPersonCount(ctx, workId)
	if err != nil {
		logger.Errorf(ctx, "get valid comment user num fails, err: %v, workId: %v", err, workId)
		return statusRet, nil
	}
	//
	p.commentUserNums = int32(commentUserNums)
	award, _, err := p.CheckStatus(ctx)
	if err != nil {
		logger.Errorf(ctx, "check status fail, err: %v", err)
		return statusRet, nil
	}
	if award > 0.001 {
		statusRet.IsSuperiorContent = true
		statusRet.Award = TranFloatWith2Bit(award)
		statusRet.Url = GetWebHomeJumpUrl()

		// 查最新奖励记录
		statusRet.LatestAwarded = statusRet.Award // 默认值为配置奖励，查询失败降级用

		work, err2 := p.impl.DataCache.GetWorkInfoLocal(ctx, workId, false)
		if err2 != nil {
			logger.Errorf(ctx, "get work info fail, workId: %v, err: %v", workId, err2)
			return statusRet, nil
		}
		filter := bson.D{{"work_id", workId}, {"user_id", work.WorkInfoDbModel.UserId}, {"type", model.AwardSettlement}}
		sortOpt := bson.D{{"_id", const_busi.MongodbSortDes}}
		items, err2 := p.impl.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.ListByCond(ctx, filter, sortOpt)
		if err2 != nil {
			logger.Errorf(ctx, "list award fail, userId: %v workId: %v, err: %v", work.WorkInfoDbModel.UserId, workId, err2)
			return statusRet, nil
		}
		if len(items) > 0 && items[0].GetAward() > 0 {
			statusRet.LatestAwarded = TranFloatWith2Bit(items[0].GetAward())
		}

	}
	//key := getSuperiorAwardOnWork(workId)
	//award, err := p.impl.DataCache.GetImpl().RedisCli.Get(ctx, key).Float64()
	//if err != nil {
	//	logger.Errorf(ctx, "get work award fail, err: %v, workId: %v", err, workId)
	//	return statusRet, nil
	//}
	//if award > 0.001 {
	//	statusRet.IsSuperiorContent = true
	//	statusRet.Award = award
	//	statusRet.Url = "" //TODO:
	//}
	return statusRet, nil
}
func (p *SuperiorContentOnWork) SetWorkAwardToCache(ctx context.Context, workId int64, award float64, modify bool) error {
	if award < 0.0001 {
		logger.Errorf(ctx, "award is less than 0")
		return nil
	}
	key := getSuperiorAwardOnWork(workId)
	if modify == false {
		//默认保存起来,不做过期时间。
		err := p.impl.DataCache.GetImpl().RedisCli.Set(ctx, key, award, time.Duration(cache_const.SuperiorContentAwardOnWorkConf.Expire)*time.Second).Err()
		if err != nil {
			logger.Errorf(ctx, "set work an award fail, err: %v, workId: %v, award: %v, redis Field: %v", err, workId, award, key)
			return err
		}
		return nil
	}
	if _, err := p.impl.DataCache.GetImpl().RedisCli.Del(ctx, key).Result(); err != nil {
		logger.Errorf(ctx, "del work award item fail, key: %v, err: %v", key, err)
		return err
	}
	logger.Infof(ctx, "del work award item succ, key: %v", key)
	return nil
}

// //
func (p *SuperiorContentOnWork) FilterCommentSelf(ctx context.Context, workUserId, commentUserId int64) bool {
	if workUserId == commentUserId {
		return true
	}
	return false
}
func (p *SuperiorContentOnWork) FilterHistoryWorks(ctx context.Context, workCreateTime string) bool {
	workCreateTimeMilli, err := TimeStrToSecond(workCreateTime)
	if err != nil {
		logger.Errorf(ctx, "trans create time to int fail, %v", p.workInfo.GetCreateTime())
		return true
	}
	//
	diffSeconds := int32(time.Since(time.UnixMilli(workCreateTimeMilli)).Seconds())
	if diffSeconds < 0 || diffSeconds > GetWorkValidMinutes()*60 { // 设置 24 小时
		logger.Infof(ctx, "time: %v, work:%v created from now more than: %v", workCreateTimeMilli, p.workInfo.GetId(), diffSeconds)
		return true
	}
	return false
}
func (p *SuperiorContentOnWork) FilterIsMutual(ctx context.Context, workUserId, commentUserId int64) bool {
	mutual := p.impl.DataCache.GetImpl().GetUserFollowMgDBLd(ctx, commentUserId, workUserId)
	if mutual == int32(pbconst.MutualEnum_mutual_yes) {
		logger.Infof(ctx, "workUserId: %v commentUserId: %v is mutual", workUserId, commentUserId)
		return false
	}
	return false
}
func (p *SuperiorContentOnWork) FilterMachineComment(ctx context.Context, commentUserId int64) bool {
	if ret := p.impl.DataCache.IsRobotComment(ctx, commentUserId); ret {
		return true
	}

	userInfo, err := p.impl.DataCache.GetUserInfoLocal(ctx, nil, commentUserId, false)
	if err != nil || userInfo == nil {
		return false
	}
	if userInfo.UserInfoDbModel.GetUserType() == 4 || userInfo.UserInfoDbModel.GetUserType() == 3 {
		return true
	}

	return false
}
func (p *SuperiorContentOnWork) FilterUnRegisterUser(ctx context.Context, commentUserId int64) bool {
	userInfo, err := p.impl.DataCache.GetUserInfoLocal(ctx, nil, commentUserId, false)
	if err != nil || userInfo == nil {
		return true
	}
	if userInfo.UserInfoDbModel.GetStatus() != 1 {
		logger.Infof(ctx, "commentUserId is unregistered: %v", commentUserId)
		return true
	}
	return false
}

// //
func getHistoryValidTimeMill() int64 {
	if config.ServerConfig.SuperiorContentConfig == nil ||
		config.ServerConfig.SuperiorContentConfig.ListHistoryAwardMinute <= 0 {
		return 30 * 24 * 3600 * 1000
	}
	return int64(config.ServerConfig.SuperiorContentConfig.ListHistoryAwardMinute) * 60 * 1000
}
func (p *SuperiorContentOnWork) GetSuperiorContentItemOnWork(ctx context.Context, workId int64) ([]*pbmgdb.SuperiorContentAwardDetail, error) {
	filter := bson.D{
		{"work_id", workId},
		{"type", model.AwardSettlement},
	}
	opts := bson.D{}
	opts = append(opts, bson.E{Key: "_id", Value: const_busi.SortTypeDesc})
	mgDetailList, err := p.impl.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.ListByCond(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "get superior award detail fail, err: %v", err)
		return nil, err
	}

	return mgDetailList, nil
}
func (p *SuperiorContentOnWork) GetSuperiorContentAwardListOnUser(ctx context.Context, userId int64, req *pbapi.KoLaPlanDetailReq) ([]*pbapi.KoLaPlanItem, error) {
	nowTime := time.Now()
	begin := nowTime.UnixMilli() - getHistoryValidTimeMill()

	filter := bson.D{
		{"user_id", userId},
		{"create_time", bson.D{{"$gte", begin}, {"$lt", nowTime.UnixMilli()}}},
	}

	opts := &options.FindOptions{
		Sort:  bson.M{"_id": const_busi.SortTypeDesc},
		Skip:  proto.Int64(int64((req.Page - 1) * req.Size)),
		Limit: proto.Int64(int64(req.Size)),
	}

	mgDetailList, err := p.impl.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.FindAll(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "get superior award detail fail, err: %v", err)
		return nil, err
	}

	var workInfo *data_cache.WorkInfoLocal = nil
	nickName := ""
	var needNickName bool = false
	var ret []*pbapi.KoLaPlanItem
	var hasWithdrawSuccOrFailOrDoing int32 = 0

	for k, _ := range mgDetailList {
		if mgDetailList[k] == nil {
			continue
		}

		description := "结算奖励"
		switch mgDetailList[k].GetSettlementType() {
		case model.AwardSettlement:
			description = "结算奖励"
			workInfo, _ = p.impl.DataCache.GetImpl().GetWorkInfoLD(ctx, mgDetailList[k].GetWorkId(), false)
		case model.DeductionIllegal:
			description = "违规扣除"
			workInfo, _ = p.impl.DataCache.GetImpl().GetWorkInfoLD(ctx, mgDetailList[k].GetWorkId(), false)
		case model.WechatPayWithdrawing:
			description = "提现到微信"
			needNickName = true
		case model.WechatPayWithdrawSuccess:
			description = "提现到微信"
			needNickName = true
			hasWithdrawSuccOrFailOrDoing += 1
		case model.WechatPayWithdrawFail:
			description = "提现到微信"
			needNickName = true
			hasWithdrawSuccOrFailOrDoing += 1
		case model.FirstWorkSettlement:
			description = "首条动态奖励"
		case model.SignLevelUpAward:
			description = "签到奖励"
		case model.AwardViewWork:
			description = "零花钱指南-刷动态领红包"
		case model.AwardGameTime:
			description = "零花钱指南-玩游戏领红包"
		case model.AwardSportAd, model.AwardStarSignAd, model.AwardSignAd:
			description = "看视频领红包"
		case model.PartnerInviteReward:
			description = "合伙人计划-邀新好礼"
		case model.PartnerCarveUp:
			description = "合伙人计划-瓜分奖池"
		case model.AwardCommentFirst:
			description = "发布评论"
		case model.AwardGroupByCreate:
			description = "首次建群奖励"
		case model.AwardGroupUserByActive:
			description = "群活跃奖励"
		}

		if needNickName == true {
			if openUserInfo, err := p.impl.DataCache.GetImpl().OpenUserModel.GetByUserId(ctx, userId); err == nil && openUserInfo != nil {
				nickName = openUserInfo.GetNickName()
			}
		}

		typeSettlement := mgDetailList[k].GetSettlementType()
		if typeSettlement == model.WechatPayWithdrawing && hasWithdrawSuccOrFailOrDoing > 0 {
			continue
		}

		item := &pbapi.KoLaPlanItem{
			SettlementType:        mgDetailList[k].GetSettlementType(),
			SettlementDescription: description,
			WxNickName:            nickName,
			AwardNums:             TranFloatWith2Bit(mgDetailList[k].GetAward()),
			TimeSettlement:        mgDetailList[k].GetCreatTime() / 1e3, //转化成秒给h5使用过
			TotalAward:            TranFloatWith2Bit(mgDetailList[k].GetTotalAward()),
			CanWithdrawAward:      TranFloatWith2Bit(mgDetailList[k].GetCanWithdrawAward()),
		}

		if mgDetailList[k].GetSettlementType() == model.AwardSettlement || mgDetailList[k].GetSettlementType() == model.DeductionIllegal {
			if workInfo != nil {
				item.WorkInfo = &pbapi.WorkInfo{
					Content: workInfo.WorkInfoDbModel.GetTitle(),
				}
			}
		}
		ret = append(ret, item)

		if typeSettlement == model.WechatPayWithdrawing {
			hasWithdrawSuccOrFailOrDoing += 1
		}

	}
	return ret, nil
}

func (p *SuperiorContentOnWork) RecordValidCommentUserNums(ctx context.Context) (bool, error) {
	if p.workInfo == nil || len(p.workInfo.GetCreateTime()) <= 0 {
		return false, nil
	}
	if filter := p.FilterCommentSelf(ctx, p.workInfo.GetUserId(), p.commentUserId); filter {
		return false, nil
	}
	if filter := p.FilterHistoryWorks(ctx, p.workInfo.GetCreateTime()); filter {
		return false, nil
	}
	if filter := p.FilterIsMutual(ctx, p.workInfo.GetUserId(), p.commentUserId); filter {
		return false, nil
	}
	if filter := p.FilterMachineComment(ctx, p.commentUserId); filter {
		return false, nil
	}
	if filter := p.FilterUnRegisterUser(ctx, p.commentUserId); filter {
		return false, nil
	}
	//
	var err error
	if userNums, err := p.impl.DataCache.GetValidCommentPersonCount(ctx, p.workInfo.GetId()); err == nil {
		p.immediatelyLogic.preCommentUserNums = int32(userNums)
	}
	p.commentUserNums, err = p.impl.DataCache.IncrValidCommentPersonCount(ctx, p.workInfo.GetId(), p.commentUserId, 1)
	if err != nil {
		logger.Errorf(ctx, "op: add, incr fail: %v", err)
		return false, err
	}
	return true, err
}
func (p *SuperiorContentOnWork) RecordWorkForUser(ctx context.Context) error {
	tmValid, err := GetWorkValidTimeFromCreated(ctx, p.workInfo.GetCreateTime()) //存入的是动态创建后的三小时时间戳
	if err != nil {
		return err
	}
	key := getSuperiorWorkOnUserKey(p.workInfo.GetUserId())
	_, err = p.impl.DataCache.GetImpl().RedisCli.ZAdd(ctx, key, &redis.Z{Score: float64(tmValid), Member: p.workInfo.GetId()}).Result()
	if err != nil {
		logger.Errorf(ctx, "add item to work on user cache, key: %v, workId: %v, score: %v", key, p.workInfo.GetId(), tmValid)
		return err
	}
	logger.Infof(ctx, "add item to work on user cache, key: %v, workId: %v, score: %v", key, p.workInfo.GetId(), tmValid)
	return nil
}
func (p *SuperiorContentOnWork) GetValidCommentUserNums(ctx context.Context, workId int64) (int64, error) {
	return p.impl.DataCache.GetValidCommentPersonCount(ctx, workId)
}
func (p *SuperiorContentOnWork) GetWorksForUser(ctx context.Context, userId int64) ([]*SuperiorWorkWithExpireTm, error) {
	//**:userId  score: create_time(millisecond)  member: (workId)
	key := getSuperiorWorkOnUserKey(userId)
	arrData, err := p.impl.DataCache.GetImpl().RedisCli.ZRevRangeWithScores(ctx, key, 0, -1).Result()
	if err != nil {
		logger.Errorf(ctx, "get works for user fail, userId: %v, key: %v, err: %v", userId, key, err)
		return nil, err
	}
	var workInfos []*SuperiorWorkWithExpireTm
	for k, _ := range arrData {
		workId, _ := strconv.ParseInt(arrData[k].Member.(string), 10, 64)
		if workId <= 0 {
			continue
		}
		workInfo, err := p.impl.DataCache.GetImpl().GetWorkInfoLocal(ctx, workId, false)
		if err != nil {
			logger.Errorf(ctx, "get work info fail, err: %v, workId: %v", err, workId)
			continue
		}
		if workInfo == nil {
			continue
		}
		if workInfo.WorkInfoDbModel.GetStatus() != 1 {
			logger.Infof(ctx, "work status is ok: %v", workInfo.WorkInfoDbModel.GetStatus())
			continue
		}
		// check work valid comment user nums:
		commentUserNumsCheck, err := p.GetValidCommentUserNums(ctx, workId)
		if err == nil {
			checkHandler := NewSuperiorContentInstance(p.impl, nil, 0)
			checkHandler.commentUserNums = int32(commentUserNumsCheck)
			checkHandler.CheckStatus(ctx)
			if checkHandler.status != WaitSettlement {
				logger.Infof(ctx, "del work: %v from to settlement queue", workId)
				p.ExcludeItemWorkForUser(ctx, userId, workId)
				NewDelayQueue(p.impl.DataCache.GetImpl().RedisCli).ExcludeMsgItem(ctx, workId, GetSuperiorContentQueueKey())
				continue
			}
		}

		item := &SuperiorWorkWithExpireTm{
			work:       workInfo,
			expireTime: arrData[k].Score,
		}
		workInfos = append(workInfos, item)
	}
	return workInfos, nil
}
func (p *SuperiorContentOnWork) ExcludeItemWorkForUser(ctx context.Context, userId int64, workId int64) error {
	_, err := p.impl.DataCache.GetImpl().RedisCli.ZRem(ctx, getSuperiorWorkOnUserKey(userId), workId).Result()
	if err != nil {
		logger.Errorf(ctx, "del work: %d from user: %v fail, err: %v", userId, workId, err)
		return err
	}
	return nil
}
func (p *SuperiorContentOnWork) AppendWorkToSettlementQueue(ctx context.Context) error {
	if p.status != WaitSettlement {
		return nil
	}
	//
	delayQueueHandle := NewDelayQueue(p.impl.DataCache.GetImpl().RedisCli)
	err := delayQueueHandle.SendMsg(ctx, p.workInfo)
	if err != nil {
		logger.Errorf(ctx, "send msg to delay queue fail, err: %v", err)
		return err
	}
	//
	if err = p.RecordWorkForUser(ctx); err != nil {
		logger.Errorf(ctx, "record superior for user fail, err: %v", err)
		delayQueueHandle.ExcludeMsgItem(ctx, p.workInfo.GetId(), GetSuperiorContentQueueKey())
		return err
	}
	logger.Infof(ctx, "send superior content settlement to waited queue")
	return nil
}
func (p *SuperiorContentOnWork) FindPenalizeItem(ctx context.Context, workId int64, userId int64) (bool, error) {
	filter := bson.D{
		{
			"work_id", workId,
		},
		{
			"user_id", userId,
		},
		{
			"type", model.DeductionIllegal,
		},
	}

	items, err := p.impl.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.ListByCond(ctx, filter, nil)
	if err != nil {
		logger.Errorf(ctx, "find superior items fail, err: %v, filter: %v", err, filter)
		return false, err
	}

	if len(items) > 0 {
		logger.Infof(ctx, "find has Penalize existed item, userId: %v, workId: %v", userId, workId)
		return true, nil
	}
	return false, nil
}
func (p *SuperiorContentOnWork) SettlementImmediately(ctx context.Context, workUserId int64, award float64, peopleNum int32) error {
	if p.status != WaitSettlement {
		return nil
	}
	if p.immediatelyLogic.preCommentUserNums == p.commentUserNums || p.immediatelyLogic.preAwardLevel == p.immediatelyLogic.awardLevel {
		return nil
	}

	var (
		err   error
		exist bool = false
	)

	if exist, err = p.FindPenalizeItem(ctx, p.workInfo.GetId(), workUserId); err != nil {
		logger.Errorf(ctx, "find penalized work fail, workId: %v, err: %v", workUserId, err)
		return err
	}
	if exist {
		logger.Infof(ctx, "as work: %v is been penalized, so omit this award", p.workInfo.GetId())
		return nil
	}

	filter := bson.D{
		{
			"work_id", p.workInfo.GetId(),
		},
		{
			"user_id", workUserId,
		},
		{
			"type", model.AwardSettlement,
		},
	}

	sortOpt := bson.D{
		{"_id", const_busi.MongodbSortDes},
	}

	addHallOFFameHande := NewAddKoLaHallOfFameInstance(&ContentMng{DataCache: p.impl.DataCache})

	p.GetDistributeLock(ctx, workUserId)
	defer func() {
		p.UnlockDistributeLock(ctx, workUserId)

		addHallOFFameHande.ExpireHallOfFameSession(ctx)
	}()

	items, err := p.impl.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.ListByCond(ctx, filter, sortOpt)
	if err != nil {
		logger.Errorf(ctx, "find superior items fail, err: %v, filter: %v", err, filter)
		return err
	}

	if len(items) <= 0 {
		preSuperiorItem, err := p.GetTotalAwardOnUser(ctx, workUserId)
		if err != nil {
			logger.Errorf(ctx, "get latest total award on user: %v fail, err: %v", workUserId, err)
			return err
		}

		item := &pbmgdb.SuperiorContentAwardDetail{
			Id:               snow_flake.GetSnowflakeID(),
			UserId:           proto.Int64(workUserId),
			CreatTime:        proto.Int64(time.Now().UnixMilli()),
			WorkId:           proto.Int64(p.workInfo.GetId()),
			SettlementType:   proto.Int32(model.AwardSettlement),
			Award:            proto.Float64(award),
			TotalAward:       proto.Float64(award),
			CanWithdrawAward: proto.Float64(award),
			WorkContent:      proto.String(p.workInfo.GetTitle()),
		}

		if preSuperiorItem != nil {
			item.TotalAward = proto.Float64(TranFloatWith2Bit(award + preSuperiorItem.GetTotalAward()))
			item.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(award + preSuperiorItem.GetCanWithdrawAward()))

			defaultHasWithdraw := float64(0.0)
			if preSuperiorItem.GetHasWithdrewAward() <= 0.0001 {
				defaultHasWithdraw = preSuperiorItem.GetTotalAward() - preSuperiorItem.GetCanWithdrawAward()
			} else {
				defaultHasWithdraw = preSuperiorItem.GetHasWithdrewAward()
			}
			item.HasWithdrewAward = proto.Float64(TranFloatWith2Bit(defaultHasWithdraw))
		}
		if err := p.WriteDownNewItem(ctx, item); err != nil {
			logger.Errorf(ctx, "write new item fail, err: %v, item: %v", err, item.String())
			return err
		}

		logger.Infof(ctx, "insert first item to tab: %v, item: %v", "superior_content_award_detail", item.String())

		addHallOFFameHande.AddItemToHallOfFame(ctx, workUserId, award)

		//发送消息
		p.SendRedPacketMsg(ctx, workUserId, award, peopleNum)

		//上报零花钱有效评论人数任务
		if err := p.impl.ManagerDB.UserRewardMoneyActivity.FinishTask(ctx, workUserId, model.AwardSettlement); err != nil {
			logger.Errorf(ctx, "ContentMng:SuperiorContentFilter:FinshTask error: %v", err)
			return err
		}
		return nil
	}

	preSuperiorItem, err := p.GetTotalAwardOnUser(ctx, workUserId)
	if err != nil {
		logger.Errorf(ctx, "get latest total award on user: %v fail, err: %v", workUserId, err)
		return err
	}

	incrAward := award - p.immediatelyLogic.preAwardValue

	item := &pbmgdb.SuperiorContentAwardDetail{
		Id:               snow_flake.GetSnowflakeID(),
		UserId:           proto.Int64(workUserId),
		CreatTime:        proto.Int64(time.Now().UnixMilli()),
		WorkId:           proto.Int64(p.workInfo.GetId()),
		SettlementType:   proto.Int32(model.AwardSettlement),
		Award:            proto.Float64(incrAward),
		TotalAward:       proto.Float64(incrAward),
		CanWithdrawAward: proto.Float64(incrAward),
		WorkContent:      proto.String(p.workInfo.GetTitle()),
	}

	if preSuperiorItem != nil {
		item.TotalAward = proto.Float64(TranFloatWith2Bit(incrAward + preSuperiorItem.GetTotalAward()))
		item.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(incrAward + preSuperiorItem.GetCanWithdrawAward()))

		defaultHasWithdraw := float64(0.0)
		if preSuperiorItem.GetHasWithdrewAward() <= 0.0001 {
			defaultHasWithdraw = preSuperiorItem.GetTotalAward() - preSuperiorItem.GetCanWithdrawAward()
		} else {
			defaultHasWithdraw = preSuperiorItem.GetHasWithdrewAward()
		}
		item.HasWithdrewAward = proto.Float64(TranFloatWith2Bit(defaultHasWithdraw))
	}
	if err := p.WriteDownNewItem(ctx, item); err != nil {
		logger.Errorf(ctx, "write new item fail, err: %v, item: %v", err, item.String())
		return err
	}
	logger.Infof(ctx, "insert new item to tab: %v, item: %v", "superior_content_award_detail", item.String())

	addHallOFFameHande.AddItemToHallOfFame(ctx, workUserId, incrAward)
	//发送消息
	p.SendRedPacketMsg(ctx, workUserId, incrAward, peopleNum)

	if err := p.impl.ManagerDB.UserRewardMoneyActivity.FinishTask(ctx, workUserId, model.AwardSettlement); err != nil {
		logger.Errorf(ctx, "ContentMng:SuperiorContentFilter:FinshTask error: %v", err)
		return err
	}
	return nil
}

// 红包消息
func (p *SuperiorContentOnWork) SendRedPacketMsg(ctx context.Context, userId int64, award float64, peopleNum int32) {
	canWithdrawAward, _ := p.impl.GetCanWithdrawAwardByUserId(ctx, userId)
	msgData := &pbapi.Wallet{
		Type:       proto.Int32(const_busi.WalletMsgTypeAward),
		Amount:     proto.String(strconv.FormatFloat(award, 'f', 2, 64)),
		Balance:    proto.String(strconv.FormatFloat(canWithdrawAward, 'f', 2, 64)),
		Desc:       proto.String(fmt.Sprintf("动态评论人数已超%d人", peopleNum)),
		CreateTime: proto.Int64(time.Now().UnixMilli()),
	}

	if err := p.impl.SendWalletMsg(ctx, userId, int32(pbconst.MessageTypeEnum_msg_type_wallet_award_notice), "您有一笔奖励金入账，快去看看吧！", msgData); err != nil {
		logger.Errorf(ctx, "send read packet msg err: %v", err)
	}
}

func (p *SuperiorContentOnWork) FindHallOfFameItem(ctx context.Context, userId int64, term string) (*pbmgdb.SuperiorContentAwardDetail, error) {
	filter := bson.D{
		{"user_id", userId},
		{"kola_halloffame", term},
		{"type", model.HallOfFameAwardSettlement},
	}

	retItem, err := p.impl.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.ListByCond(ctx, filter, nil)
	if err != nil {
		logger.Errorf(ctx, "find userId: %v, term: %v, err: %v", userId, term)
		return nil, err
	}

	if retItem == nil || len(retItem) <= 0 {
		logger.Infof(ctx, "not find item, term: %v, userId: %v", term, userId)
		return nil, nil
	}

	return retItem[0], nil
}
func (p *SuperiorContentOnWork) WriteHallOfFameItem(ctx context.Context, userId int64, award float64, term string) error {
	// 查找work的UserId 最新的一条记录
	p.GetDistributeLock(ctx, userId)
	defer func() {
		p.UnlockDistributeLock(ctx, userId)
	}()

	superiorDetail, err := p.GetTotalAwardOnUser(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get latest total award on user: %v fail, err: %v", userId, err)
		return err
	}

	newAwardItem := &pbmgdb.SuperiorContentAwardDetail{
		Id:             snow_flake.GetSnowflakeID(),
		UserId:         proto.Int64(userId),
		Award:          proto.Float64(award),
		CreatTime:      proto.Int64(time.Now().UnixMilli()),
		HallOfFameTerm: proto.String(term),
	}

	totalAward := newAwardItem.GetAward()
	if superiorDetail.GetTotalAward() > 0.0001 {
		totalAward += superiorDetail.GetTotalAward()
	}

	newAwardItem.SettlementType = proto.Int32(model.HallOfFameAwardSettlement) //const_busi.AWardSettlement
	newAwardItem.TotalAward = proto.Float64(TranFloatWith2Bit(totalAward))     //累计赢得金额：统计用户所有优质内容奖励金额 - 内容违规扣除金额
	newAwardItem.HasWithdrewAward = proto.Float64(TranFloatWith2Bit(superiorDetail.GetHasWithdrewAward()))
	newAwardItem.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(totalAward - superiorDetail.GetHasWithdrewAward())) //可提现金额 = 统计用户所有优质内容奖励金额 - 内容违规扣除金额 - 会员抵扣金额 - 已经提现的金额

	p.UnlockDistributeLock(ctx, userId)

	err = p.AddNewItemAwardRecord(ctx, newAwardItem)
	if err != nil {
		logger.Errorf(ctx, "insert new item: %v, to db fail, err: %v", newAwardItem.String(), err)
		return err
	}

	logger.Infof(ctx, "write tab: superior_content_award_detail in WriteHallOfFameItem, new item: %v", newAwardItem.String())
	return nil
}

//AWardSettlement
//DeductionIllegal
//FirstWorkSettlement
//WechatPayWithdrawing  = 4
//WechatPayWithdrawSucc = 5
//WechatPayWithdrawFail = 6

func (p *SuperiorContentOnWork) AwardSettlementProc(ctx context.Context, lastItem, itemNew *pbmgdb.SuperiorContentAwardDetail) error {
	if itemNew == nil || lastItem == nil {
		return nil
	}
	//
	totalAward := itemNew.GetAward()
	if lastItem.GetTotalAward() > 0.0001 {
		totalAward += lastItem.GetTotalAward()
	}

	//
	itemNew.SettlementType = proto.Int32(model.AwardSettlement) //const_busi.AWardSettlement
	itemNew.TotalAward = proto.Float64(totalAward)              //累计赢得金额：统计用户所有优质内容奖励金额 - 内容违规扣除金额
	itemNew.HasWithdrewAward = proto.Float64(lastItem.GetHasWithdrewAward())
	itemNew.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(totalAward - lastItem.GetHasWithdrewAward())) //可提现金额 = 统计用户所有优质内容奖励金额 - 内容违规扣除金额 - 会员抵扣金额 - 已经提现的金额
	return nil
}

func (p *SuperiorContentOnWork) DeductionIllegalProc(ctx context.Context, lastItem, newItem *pbmgdb.SuperiorContentAwardDetail) error {
	if newItem == nil || lastItem == nil {
		return errors.New("input item is nil")
	}

	totalAward := lastItem.GetTotalAward() - newItem.GetAward() //累计赢得金额：统计用户所有优质内容奖励金额 - 内容违规扣除金额
	newItem.TotalAward = proto.Float64(totalAward)
	newItem.SettlementType = proto.Int32(model.DeductionIllegal)
	newItem.HasWithdrewAward = proto.Float64(lastItem.GetHasWithdrewAward())
	newItem.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(totalAward - lastItem.GetHasWithdrewAward())) //可提现金额 = 统计用户所有优质内容奖励金额 - 内容违规扣除金额 - 会员抵扣金额 - 已经提现的金额
	return nil
}
func (p *SuperiorContentOnWork) FirstWorkSettlementProc(ctx context.Context, lastItem, newItem *pbmgdb.SuperiorContentAwardDetail) error {
	if newItem == nil {
		return nil
	}
	//
	totalAward := newItem.GetAward()
	if lastItem.GetTotalAward() > 0.0001 {
		totalAward += lastItem.GetTotalAward()
	}
	//
	newItem.SettlementType = proto.Int32(model.FirstWorkSettlement)   //const_busi.AWardSettlement
	newItem.TotalAward = proto.Float64(TranFloatWith2Bit(totalAward)) //累计赢得金额：统计用户所有优质内容奖励金额 - 内容违规扣除金额
	newItem.HasWithdrewAward = proto.Float64(lastItem.GetHasWithdrewAward())
	newItem.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(totalAward - lastItem.GetHasWithdrewAward())) //可提现金额 = 统计用户所有优质内容奖励金额 - 内容违规扣除金额 - 会员抵扣金额 - 已经提现的金额
	return nil
}
func (p *SuperiorContentOnWork) WechatPayWithdrawingProc(ctx context.Context, lastItem, itemNew *pbmgdb.SuperiorContentAwardDetail) error {
	if itemNew == nil || lastItem == nil {
		return errors.New("input param is nil")
	}

	canWithdrawAward, err := p.impl.GetCanWithdrawAward(ctx, lastItem)
	if err != nil {
		logger.Errorf(ctx, "get can withdraw award for userId: %v, fail, err: %v", lastItem.GetUserId(), err)
		//ret = WithdrawRetToastFail
		return err
	}
	if canWithdrawAward < 0.0001 {
		logger.Errorf(ctx, "has not enough award to  withdraw, canWithdrawAward: %v, userId: %v", canWithdrawAward, lastItem.GetUserId())
		//ret = WithdrawRetToastFail
		return errors.New("less more than 0  for can withdraw")
	}

	if p.detailId > 0 {
		itemNew.Id = p.detailId
	}
	itemNew.TotalAward = lastItem.TotalAward
	itemNew.SettlementType = proto.Int32(model.WechatPayWithdrawing)
	itemNew.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(lastItem.GetCanWithdrawAward() - itemNew.GetAward()))
	itemNew.HasWithdrewAward = proto.Float64(TranFloatWith2Bit(lastItem.GetHasWithdrewAward() + itemNew.GetAward()))

	return nil
}
func (p *SuperiorContentOnWork) WechatPayWithdrawSucc(ctx context.Context, lastItem, itemNew *pbmgdb.SuperiorContentAwardDetail) error {
	if itemNew == nil || lastItem == nil {
		return errors.New("input param is nil")
	}

	canWithdrawAward, err := p.impl.GetCanWithdrawAward(ctx, lastItem)
	if err != nil {
		logger.Errorf(ctx, "get can withdraw award for userId: %v, fail, err: %v", itemNew.GetUserId(), err)
		//ret = WithdrawRetToastFail
		return err
	}

	if p.detailId > 0 {
		itemNew.Id = p.detailId //最新的
	}

	itemNew.TotalAward = lastItem.TotalAward //上次的
	itemNew.SettlementType = proto.Int32(model.WechatPayWithdrawSuccess)
	itemNew.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(canWithdrawAward))               //上次的
	itemNew.HasWithdrewAward = proto.Float64(TranFloatWith2Bit(lastItem.GetHasWithdrewAward())) //上次的

	return nil
}
func (p *SuperiorContentOnWork) WechatPayWithdrawFail(ctx context.Context, lastItem, itemNew *pbmgdb.SuperiorContentAwardDetail) error {
	if itemNew == nil || lastItem == nil {
		return errors.New("input param is nil")
	}

	canWithdrawAward, err := p.impl.GetCanWithdrawAward(ctx, lastItem)
	if err != nil {
		logger.Errorf(ctx, "get can withdraw award for userId: %v, fail, err: %v", lastItem.GetUserId(), err)
		//ret = WithdrawRetToastFail
		return err
	}

	if p.detailId > 0 {
		itemNew.Id = p.detailId //1.id 使用新创建
	}

	itemNew.TotalAward = lastItem.TotalAward // 2.和上次保持不变
	itemNew.SettlementType = proto.Int32(model.WechatPayWithdrawFail)
	itemNew.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(canWithdrawAward + itemNew.GetAward()))               // 3. 上次的 + this time
	itemNew.HasWithdrewAward = proto.Float64(TranFloatWith2Bit(lastItem.GetHasWithdrewAward() - itemNew.GetAward())) //4. 上次的 - this time

	return nil
}

func (p *SuperiorContentOnWork) SignLevelUp(ctx context.Context, lastItem, newItem *pbmgdb.SuperiorContentAwardDetail) error {
	if newItem == nil {
		return nil
	}

	totalAward := newItem.GetAward()
	if lastItem.GetTotalAward() > 0.0001 {
		totalAward += lastItem.GetTotalAward()
	}

	newItem.SettlementType = proto.Int32(model.SignLevelUpAward)
	newItem.TotalAward = proto.Float64(TranFloatWith2Bit(totalAward))
	newItem.HasWithdrewAward = proto.Float64(lastItem.GetHasWithdrewAward())
	newItem.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(totalAward - lastItem.GetHasWithdrewAward()))
	return nil
}

func (p *SuperiorContentOnWork) AwardMoneyPlan(ctx context.Context, lastItem, newItem *pbmgdb.SuperiorContentAwardDetail, itemType int32) error {
	if newItem == nil {
		return nil
	}

	totalAward := newItem.GetAward()
	if lastItem.GetTotalAward() > 0.0001 {
		totalAward = float64Addition(totalAward, lastItem.GetTotalAward())
	}

	newItem.SettlementType = proto.Int32(itemType)
	newItem.TotalAward = proto.Float64(totalAward)
	newItem.HasWithdrewAward = proto.Float64(lastItem.GetHasWithdrewAward())
	newItem.CanWithdrawAward = proto.Float64(float64Addition(totalAward, -lastItem.GetHasWithdrewAward()))
	return nil
}

func (p *SuperiorContentOnWork) PartnerInviteReward(ctx context.Context, lastItem, newItem *pbmgdb.SuperiorContentAwardDetail) error {
	if newItem == nil {
		return nil
	}

	totalAward := newItem.GetAward()
	if lastItem.GetTotalAward() > 0.0001 {
		totalAward += lastItem.GetTotalAward()
	}

	newItem.SettlementType = proto.Int32(model.PartnerInviteReward)
	newItem.TotalAward = proto.Float64(TranFloatWith2Bit(totalAward))
	newItem.HasWithdrewAward = proto.Float64(lastItem.GetHasWithdrewAward())
	newItem.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(totalAward - lastItem.GetHasWithdrewAward()))
	return nil
}

func (p *SuperiorContentOnWork) PartnerCarveUp(ctx context.Context, lastItem, newItem *pbmgdb.SuperiorContentAwardDetail) error {
	if newItem == nil {
		return nil
	}

	totalAward := newItem.GetAward()
	if lastItem.GetTotalAward() > 0.0001 {
		totalAward += lastItem.GetTotalAward()
	}

	newItem.SettlementType = proto.Int32(model.PartnerCarveUp)
	newItem.TotalAward = proto.Float64(TranFloatWith2Bit(totalAward))
	newItem.HasWithdrewAward = proto.Float64(lastItem.GetHasWithdrewAward())
	newItem.CanWithdrawAward = proto.Float64(TranFloatWith2Bit(totalAward - lastItem.GetHasWithdrewAward()))
	return nil
}

func getSuperiorContentLockKey(userId int64) string {
	if userId <= 0 {
		return ""
	}
	return fmt.Sprintf(cache_const.SuperiorContentDistributeLockKey.KeyFmt, userId)
}
func getSuperiorContentLockExpire() int64 {
	return cache_const.SuperiorContentDistributeLockKey.Expire
}
func (p *SuperiorContentOnWork) GetDistributeLock(ctx context.Context, userId int64) (bool, error) {
	key := getSuperiorContentLockKey(userId)
	if len(key) <= 0 {
		return false, errors.New("distribute superior content lock is nil")
	}
	//
	ret, err := p.impl.DataCache.GetImpl().RedisCli.SetNX(ctx, key, "1", time.Duration(getSuperiorContentLockExpire())*time.Second).Result()
	if err != nil {
		logger.Errorf(ctx, "get redis key fail, key: %v, err: %v", key, err)
		return false, err
	}
	if ret == true {
		logger.Infof(ctx, "get redis lock succ, key: %v", key)
		return true, nil
	}
	logger.Infof(ctx, "get reids lock fail, key: %v", key)
	return false, nil

}
func (p *SuperiorContentOnWork) UnlockDistributeLock(ctx context.Context, userId int64) error {
	key := getSuperiorContentLockKey(userId)
	if len(key) <= 0 {
		return errors.New("distribute superior content lock is nil")
	}
	p.impl.DataCache.GetImpl().RedisCli.Del(ctx, key)

	logger.Infof(ctx, "unlock key: %v", key)
	return nil
}
func (p *SuperiorContentOnWork) WriteNewItem(ctx context.Context, workId, userId int64, workContent string, award float64, itemType int32) error {
	// 查找work的UserId 最新的一条记录
	p.GetDistributeLock(ctx, userId)
	var advanceExst bool = false
	defer func() {
		if advanceExst == false {
			p.UnlockDistributeLock(ctx, userId)
		}
	}()

	superiorDetail, err := p.GetTotalAwardOnUser(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get latest total award on user: %v fail, err: %v", userId, err)
		return err
	}

	newAwardItem := &pbmgdb.SuperiorContentAwardDetail{
		Id:        snow_flake.GetSnowflakeID(),
		UserId:    proto.Int64(userId),
		Award:     proto.Float64(award),
		CreatTime: proto.Int64(time.Now().UnixMilli()),
	}

	if workId > 0 {
		newAwardItem.WorkId = proto.Int64(workId)
	}
	if len(workContent) > 0 {
		newAwardItem.WorkContent = proto.String(workContent)
	}
	//
	switch itemType {
	case model.AwardSettlement:
		if err = p.AwardSettlementProc(ctx, superiorDetail, newAwardItem); err != nil {
			return err
		}

	case model.DeductionIllegal:
		if err = p.DeductionIllegalProc(ctx, superiorDetail, newAwardItem); err != nil {
			return err
		}

	case model.FirstWorkSettlement:
		if err = p.FirstWorkSettlementProc(ctx, superiorDetail, newAwardItem); err != nil {
			return err
		}

	case model.WechatPayWithdrawing:
		if err = p.WechatPayWithdrawingProc(ctx, superiorDetail, newAwardItem); err != nil {
			return err
		}

	case model.WechatPayWithdrawSuccess:
		if err = p.WechatPayWithdrawSucc(ctx, superiorDetail, newAwardItem); err != nil {
			return err
		}

	case model.WechatPayWithdrawFail:
		if err = p.WechatPayWithdrawFail(ctx, superiorDetail, newAwardItem); err != nil {
			return err
		}
	case model.SignLevelUpAward:
		if err = p.SignLevelUp(ctx, superiorDetail, newAwardItem); err != nil {
			return err
		}
	case model.PartnerInviteReward:
		if err = p.PartnerInviteReward(ctx, superiorDetail, newAwardItem); err != nil {
			return err
		}
	case model.PartnerCarveUp:
		if err = p.PartnerCarveUp(ctx, superiorDetail, newAwardItem); err != nil {
			return err
		}
	case model.AwardViewWork, model.AwardGameTime, model.AwardSportAd, model.AwardStarSignAd, model.AwardSignAd,
		model.AwardGroupByCreate, model.AwardGroupUserByActive, //群
		model.AwardCommentFirst:
		if err = p.AwardMoneyPlan(ctx, superiorDetail, newAwardItem, itemType); err != nil {
			return err
		}
	}

	advanceExst = true
	p.UnlockDistributeLock(ctx, userId)

	if itemType == model.DeductionIllegal {
		// 包括记录本次新增记录，本次动态得分在缓存中的值。
		err = p.ModifyItemAwardRecord(ctx, newAwardItem)
	} else {
		err = p.AddNewItemAwardRecord(ctx, newAwardItem)
	}

	if err != nil {
		logger.Errorf(ctx, "insert new item: %v, to db fail, err: %v", newAwardItem.String(), err)
		return err
	}
	logger.Infof(ctx, "write tab: superior_content_award_detail in WriteNewItem, new item: %v", newAwardItem.String())
	return nil
}

// /////////////////////
func (p *ContentMng) PackageKoLaPlanItem(ctx context.Context, works []*SuperiorWorkWithExpireTm) ([]*pbapi.KoLaPlanItem, error) {
	var retPlanItems []*pbapi.KoLaPlanItem
	for k, _ := range works {
		if works[k] == nil {
			continue
		}
		//
		createTimeMill, err := TimeStrToSecond(works[k].work.WorkInfoDbModel.GetCreateTime())
		if err != nil {
			logger.Errorf(ctx, "tran work create time from : %v to int64 fail, err: %v",
				works[k].work.WorkInfoDbModel.GetCreateTime(), err)
		}
		objectId := ""
		if len(works[k].work.WorkObjAttr) > 0 {
			objectId = works[k].work.WorkObjAttr[0].GetObjectId()
		} else {
			bgImage, err := p.GetBackgroundWithWork(ctx)
			if err != nil {
				logger.Error(ctx, "GetBackgroundWithWork", err)
			}
			objectId = bgImage
		}
		workId := works[k].work.WorkInfoDbModel.GetId()
		//
		if !strings.HasPrefix(objectId, "http") && len(config.ServerConfig.ImageHost) > 0 {
			objectId = config.ServerConfig.ImageHost + "/" + objectId
		}
		item := &pbapi.KoLaPlanItem{}
		item.WorkInfo = &pbapi.WorkInfo{
			Id:         workId,
			Content:    works[k].work.WorkInfoDbModel.GetTitle(),
			CreateTime: createTimeMill,
			ObjectId:   objectId,
		}

		settlementRemainTime, err := GetWorkValidTimeFromCreated(ctx, works[k].work.WorkInfoDbModel.GetCreateTime())
		if err != nil {
			logger.Errorf(ctx, "get settlement remain time fail, err: %v, create time: %v", err, works[k].work.WorkInfoDbModel.GetCreateTime())
		}
		diffTimeMilli := settlementRemainTime - time.Now().UnixMilli()
		if diffTimeMilli < 0 {
			logger.Errorf(ctx, "has no remain time, need to settlement, tm: %v", settlementRemainTime)
			item.RemainTimeSettlement = fmt.Sprintf("0s")
			//默认使用
		} else if diffTimeMilli == 0 {
			item.RemainTimeSettlement = fmt.Sprintf("0s")
		} else {
			dur := time.Duration(diffTimeMilli) * time.Millisecond
			seconds := int32(dur.Seconds())
			h := seconds / 3600
			m := (seconds % 3600) / 60
			s := (seconds % 3600) % 60

			if h > 0 {
				item.RemainTimeSettlement = fmt.Sprintf("%vh%vmin%vs", h, m, s)
			} else if m > 0 {
				item.RemainTimeSettlement = fmt.Sprintf("%vmin%vs", m, s)
			} else if s > 0 {
				item.RemainTimeSettlement = fmt.Sprintf("%vs", s)
			} else {
			}
		}
		//
		commentUserNums, err := NewSuperiorContentInstance(p, nil, 0).GetValidCommentUserNums(ctx, workId)
		if err != nil {
			logger.Errorf(ctx, "get valid comment user nums fail: %v, workId: %v", err, workId)
		}
		item.CommentUserNums = int32(commentUserNums)

		preAward, err := NewSuperiorContentInstance(p, nil, 0).CalcPreAward(ctx, item.CommentUserNums)
		if err != nil {
			logger.Errorf(ctx, "calc pre award fail workId: %v, commentUserNums: %v, err: %v", workId, item.CommentUserNums, err)
		}
		item.PreAward = preAward
		retPlanItems = append(retPlanItems, item)
	}

	return retPlanItems, nil
}
func (p *ContentMng) GetKoLaToSettlementDetailByUser(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.KoLaPlanDetailResp, error) {
	retDetail := &pbapi.KoLaPlanDetailResp{
		TotalAwards:       0.0,
		Item:              nil,
		CanWithdrawAwards: 0.0,
		Level1WorkAward:   setting.Maozhua.Level1WorkAward.Get(),
		Level2WorkAward:   utils.FloatRound(setting.Maozhua.Level2WorkAward.Get()-setting.Maozhua.Level1WorkAward.Get(), 1),
	}
	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "get user info fail, err: %v", err)
		return retDetail, err
	}

	totalAward, canAward, err := p.GetTotalAndCanWithdrewAward(ctx, nil, loginUserInfo.UserInfoDbModel.GetUserId())
	if err != nil {
		logger.Errorf(ctx, "get total award for user fail, err: %v, userId: %v", err, loginUserInfo.UserInfoDbModel.GetUserId())
		return nil, errorcode.SuperiorContentDetailError
	}
	if totalAward > 0.0001 {
		retDetail.TotalAwards = TranFloatWith2Bit(totalAward)
	}
	if canAward > 0.0001 {
		retDetail.CanWithdrawAwards = TranFloatWith2Bit(canAward)
	}

	toAwardWorks, err := NewSuperiorContentInstance(p, nil, 0).GetWorksForUser(ctx, loginUserInfo.UserInfoDbModel.GetUserId())
	if err != nil {
		return nil, errorcode.SuperiorContentDetailError
	}
	if len(toAwardWorks) <= 0 {
		return retDetail, nil
	}

	planItems, err := p.PackageKoLaPlanItem(ctx, toAwardWorks)
	if err != nil {
		logger.Errorf(ctx, "package plan items fail, err: %v", err)
		return nil, errorcode.SuperiorContentDetailError
	}
	retDetail.Item = planItems
	return retDetail, nil
}
func GetWebHomeJumpUrl() string {
	return fmt.Sprintf("%s/bonuss", config.ServerConfig.ServerHost)
}
func (p *ContentMng) GetTotalAWardByUser(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.KoLaPlanEntryResponse, error) {
	retEntry := &pbapi.KoLaPlanEntryResponse{
		JumpUrl: GetWebHomeJumpUrl(),
	}

	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "get user info fail, err: %v", err)
		return retEntry, err
	}

	totalAward, err := p.GetTotalAwardOnUser(ctx, loginUserInfo.UserInfoDbModel.GetUserId())
	if err != nil {
		logger.Errorf(ctx, "get total award for user: %v from tab fail, err: %v", loginUserInfo.UserInfoDbModel.GetUserId(), err)
		return retEntry, err
	}

	if totalAward > 0.0001 {
		retEntry.TotalAwards = TranFloatWith2Bit(totalAward)
	}
	return retEntry, nil
}
func (p *ContentMng) GetKoLaAwardDetailByUser(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.KoLaPlanDetailReq) (*pbapi.KoLaPlanDetailResp, error) {
	retDetail := &pbapi.KoLaPlanDetailResp{
		TotalAwards: 0.0,
		Item:        nil,
	}
	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "get user info fail, err: %v", err)
		return retDetail, err
	}
	totalAward, CanWithdrawAwards, err := p.GetTotalAndCanWithdrewAward(ctx, nil, loginUserInfo.UserInfoDbModel.GetUserId())
	if err != nil {
		logger.Errorf(ctx, "get total award for user fail, err: %v, userId: %v", err, loginUserInfo.UserInfoDbModel.GetUserId())
		return nil, errorcode.SuperiorContentDetailError
	}
	if totalAward > 0.0001 {
		retDetail.TotalAwards = TranFloatWith2Bit(totalAward)
	}

	if CanWithdrawAwards > 0.0001 {
		retDetail.CanWithdrawAwards = TranFloatWith2Bit(CanWithdrawAwards)
	}

	awardList, err := NewSuperiorContentInstance(p, nil, 0).GetSuperiorContentAwardListOnUser(ctx, loginUserInfo.UserInfoDbModel.GetUserId(), req)
	if err != nil {
		return nil, errorcode.SuperiorContentDetailError
	}
	if len(awardList) <= 0 {
		return retDetail, nil
	}
	retDetail.Item = awardList
	return retDetail, nil
}
func (p *ContentMng) GetTotalAwardOnUser(ctx context.Context, userId int64) (float64, error) {
	//可以在这加一个分布式锁
	awardItem, err := p.GetAwardDetailLatestOnUser(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get total award for user fail, err: %v, userId: %v", err, userId)
		return 0.0, errorcode.SuperiorContentDetailError
	}
	if awardItem == nil {
		return 0.0, nil
	}
	return awardItem.GetTotalAward(), nil
}

func (p *ContentMng) GetTotalAndCanWithdrewAward(ctx context.Context, header *pbapi.HttpHeaderInfo, userId int64) (float64, float64, error) {
	awardItem, err := p.GetAwardDetailLatestOnUser(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get total award for user fail, err: %v, userId: %v", err, userId)
		return 0.0, 0.0, errorcode.SuperiorContentDetailError
	}
	if awardItem == nil {
		return 0.0, 0.0, nil
	}
	return awardItem.GetTotalAward(), awardItem.GetCanWithdrawAward(), nil
}
func (p *ContentMng) GetAwardDetailLatestOnUser(ctx context.Context, userId int64) (*pbmgdb.SuperiorContentAwardDetail, error) {
	awardItem, err := NewSuperiorContentInstance(p, nil, 0).GetTotalAwardOnUser(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get total award for user fail, err: %v, userId: %v", err, userId)
		return nil, errorcode.SuperiorContentDetailError
	}
	return awardItem, nil
}
func (p *ContentMng) GetCanWithdrawAward(ctx context.Context, item *pbmgdb.SuperiorContentAwardDetail) (float64, error) {
	if item == nil {
		return 0.0, errors.New("param is nil")
	}
	if item.GetCanWithdrawAward() > 0.0001 {
		return item.GetCanWithdrawAward(), nil
	}
	if item.GetCanWithdrawAward() <= 0.0001 {
		return 0.0, nil
	}
	return 0.0, nil
	//
	//if item.GetHasWithdrewAward() <= 0.0001 {
	//	return TranFloatWith2Bit(item.GetCanWithdrawAward()), nil
	//}
	//return TranFloatWith2Bit(item.GetTotalAward() - item.GetHasWithdrewAward()), nil
}
func (p *ContentMng) GetCanWithdrawAwardByUserId(ctx context.Context, userId int64) (float64, error) {
	item, err := p.GetAwardDetailLatestOnUser(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get latest award item for user fail, userId: %v", userId)
		return 0.0, err
	}
	return p.GetCanWithdrawAward(ctx, item)
}

func (p *ContentMng) GetKoLaHallOfFameList(ctx context.Context, header *pbapi.HttpHeaderInfo) ([]*pbapi.UserItemOnHalfOfFame, error) {
	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "get user info fail, err: %v", err)
		return nil, err
	}

	item, err := NewGetKoLaHallOfFameInstance(loginUserInfo, p).GetHallOfFameList(ctx)
	if err != nil {
		logger.Errorf(ctx, "get kola hall of fame fail, err: %v")
		return nil, err
	}
	return item, nil
}
