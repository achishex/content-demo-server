package phone

import (
	"content_svr/app/maozhua_admin_svr/common/result"
	"github.com/go-playground/validator/v10"
	"net/http"

	"content_svr/app/maozhua_admin_svr/api/internal/logic/phone"
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"github.com/zeromicro/go-zero/rest/httpx"
)

type verifyPhoneCodeReqRequest struct {
	types.PhoneCodeReq
}

func (p *verifyPhoneCodeReqRequest) Validate() error {
	valid := validator.New()
	if err := valid.Struct(p); err != nil {
		return err
	}
	return nil
}

func QueryPhoneCodeHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req verifyPhoneCodeReqRequest
		if err := httpx.Parse(r, &req); err != nil {
			result.ParamErrorResult(r, w, err)
			return
		}

		l := phone.NewQueryPhoneCodeLogic(r.Context(), svcCtx)
		resp, err := l.QueryPhoneCode(&req.PhoneCodeReq)
		result.HttpResult(r, w, resp, err)
	}
}
