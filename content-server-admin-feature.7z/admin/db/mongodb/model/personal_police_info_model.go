package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const PersonalPoliceInfoCollectionName = "personal_police_info"

var _ PersonalPoliceInfoModel = (*customPersonalPoliceInfoModel)(nil)

type (
	// PersonalPoliceInfoModel is an interface to be customized, add more methods here,
	// and implement the added methods in customPersonalPoliceInfoModel.
	PersonalPoliceInfoModel interface {
		personalPoliceInfoModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]PersonalPoliceInfo, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*PersonalPoliceInfo, error)
	}

	customPersonalPoliceInfoModel struct {
		*defaultPersonalPoliceInfoModel
	}
)

// NewPersonalPoliceInfoModel returns a model for the mongo.
func NewPersonalPoliceInfoModel(cfg MonConfig) PersonalPoliceInfoModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), PersonalPoliceInfoCollectionName)
	return &customPersonalPoliceInfoModel{
		defaultPersonalPoliceInfoModel: newDefaultPersonalPoliceInfoModel(conn),
	}
}

func (m *customPersonalPoliceInfoModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}

	return query
}

func (m *customPersonalPoliceInfoModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customPersonalPoliceInfoModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]PersonalPoliceInfo, error) {
	result := make([]PersonalPoliceInfo, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customPersonalPoliceInfoModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*PersonalPoliceInfo, error) {
	var data PersonalPoliceInfo
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
