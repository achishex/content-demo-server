package model

const PersonalPoliceInfoCollectionName = "personalPoliceInfo"

type PersonalPoliceInfo struct {
	ID               int64 `json:"id,omitempty" bson:"_id,omitempty"`
	JoinAt           int64 `json:"joinAt,omitempty" bson:"joinAt,omitempty"`
	Timestamp        int64 `json:"timestamp,omitempty" bson:"timestamp,omitempty"`
	LastActiveAt     int64 `json:"lastActiveAt,omitempty" bson:"lastActiveAt,omitempty"`         // 最后活跃时间
	ArrestWorkCount  int64 `json:"arrestWorkCount,omitempty" bson:"arrestWorkCount,omitempty"`   // 抓捕数量-作品
	MistakeCount     int64 `json:"mistakeCount,omitempty" bson:"mistakeCount,omitempty"`         // 误抓-作品
	SuccessCount     int64 `json:"successCount,omitempty" bson:"successCount,omitempty"`         // 成功抓捕-作品
	ArrestTalkCount  int64 `json:"arrestTalkCount,omitempty" bson:"arrestTalkCount,omitempty"`   // 抓捕数量-聊天
	MistakeTalkCount int64 `json:"mistakeTalkCount,omitempty" bson:"mistakeTalkCount,omitempty"` // 误抓-聊天
	SuccessTalkCount int64 `json:"successTalkCount,omitempty" bson:"successTalkCount,omitempty"` // 成功抓捕-聊天
	Status           int32 `json:"status,omitempty" bson:"status,omitempty"`                     // 状态 1正常 0删除
	ShowConvoy       bool  `json:"showConvoy,omitempty" bson:"showConvoy,omitempty"`             // 是否展示护卫队标识true展示，false不展示
}
