package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const WorksCommentDetailCollectionName = "works_comment_detail"

var _ WorksCommentDetailModel = (*customWorksCommentDetailModel)(nil)

type (
	// WorksCommentDetailModel is an interface to be customized, add more methods here,
	// and implement the added methods in customWorksCommentDetailModel.
	WorksCommentDetailModel interface {
		worksCommentDetailModel
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*WorksCommentDetail, error)
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]WorksCommentDetail, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
	}

	customWorksCommentDetailModel struct {
		*defaultWorksCommentDetailModel
	}
)

// NewWorksCommentDetailModel returns a model for the mongo.
func NewWorksCommentDetailModel(cfg MonConfig) WorksCommentDetailModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), WorksCommentDetailCollectionName)
	return &customWorksCommentDetailModel{
		defaultWorksCommentDetailModel: newDefaultWorksCommentDetailModel(conn),
	}
}

func (m *customWorksCommentDetailModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customWorksCommentDetailModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]WorksCommentDetail, error) {
	result := make([]WorksCommentDetail, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customWorksCommentDetailModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customWorksCommentDetailModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*WorksCommentDetail, error) {
	var data WorksCommentDetail
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
