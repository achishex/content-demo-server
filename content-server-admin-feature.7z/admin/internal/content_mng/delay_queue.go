package content_mng

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"context"
	"fmt"
	rdsV8 "github.com/go-redis/redis/v8"
	"github.com/zeromicro/go-zero/core/stores/redis"
	"strconv"
	"time"
)

type QueueNotifyChannel struct {
	redisClient *rdsV8.Client
	channel     string
}

func NewQueryNotifyChannelNode(redis *rdsV8.Client, chName string) *QueueNotifyChannel {
	return &QueueNotifyChannel{
		redisClient: redis,
		channel:     chName,
	}
}
func (p *QueueNotifyChannel) SendNotifyOnChanel(ctx context.Context) error {
	if p.redisClient == nil || len(p.channel) <= 0 {
		return errors.New("redis client not init")
	}
	_, err := p.redisClient.Publish(ctx, p.channel, 1).Result()
	if err != nil {
		logger.Errorf(ctx, "send notify on channel: %v fail", p.channel)
		return err
	}
	return nil
}
func (p *QueueNotifyChannel) Wait(ctx context.Context) (<-chan *rdsV8.Message, error) {
	pubSubHandler := p.redisClient.Subscribe(ctx, p.channel)
	_, err := pubSubHandler.Receive(ctx)
	if err != nil {
		logger.Errorf(ctx, "Subscribe ch: %v fail", p.channel)
		return nil, err
	}
	ch := pubSubHandler.Channel()
	return ch, nil
}

// ////
type IDelayQueue interface {
	SendMsg(ctx context.Context, work *pbapi.PersonalBottleWorksDbModel) error
	ReceiveMsg(ctx context.Context) error
	ExcludeMsgItem(ctx context.Context, workId int64, key string) error
	QueryItemsByTimeCond(ctx context.Context, scoreBeginTime, scoreEndTime int64, key string) ([]int64, error)
	QueryAllItems(ctx context.Context, key string) ([]int64, error)
	//获取最近的一个记录.
	QueryItemLatest(ctx context.Context, key string) (int64, int64, error) // workId, createTime
	ProbeItemExist(ctx context.Context, workId int64) (bool, error)

	WaitNotify(ctx context.Context) chan bool

	//
	SendWithdrawItem(ctx context.Context, withdrawId int64, delayTimeSecond int32) error
}

func NewDelayQueue(redisClient *rdsV8.Client) IDelayQueue {
	return &RedisImplDelayQueue{
		redisClient:   redisClient,
		notifyHandler: NewQueryNotifyChannelNode(redisClient, getSuperiorContentQueueNotifyChName()),
	}
}

type RedisImplDelayQueue struct {
	redisClient   *rdsV8.Client
	notifyHandler *QueueNotifyChannel
}

func GetSuperiorContentQueueKey() string {
	return fmt.Sprintf(cache_const.SuperiorContentQueueConf.KeyFmt, "global")
}
func getSuperiorContentQueueNotifyChName() string {
	return fmt.Sprintf(cache_const.SuperiorContentQueueNotifyChName.KeyFmt, "superior_content")
}

func (p *RedisImplDelayQueue) WaitNotify(ctx context.Context) chan bool {
	inCh, err := p.notifyHandler.Wait(ctx)
	if err != nil {
		return nil
	}
	retCh := make(chan bool)
	go func() {
		defer func() {
			if e := recover(); e != nil {
				fmt.Printf("wait norify happen error.\n")
			}
		}()
		for {
			select {
			case <-inCh:
				retCh <- true
				logger.Infof(ctx, "recv notify and send to busi.")
			}
		}
	}()
	return retCh
}
func (p *RedisImplDelayQueue) ProbeItemExist(ctx context.Context, workId int64) (bool, error) {
	key := GetSuperiorContentQueueKey()
	_, err := p.redisClient.ZRank(ctx, key, fmt.Sprintf("%v", workId)).Result()
	if err != nil && err != redis.Nil {
		logger.Infof(ctx, "check member exist fail, member: %v, key: %v", workId, key)
		return false, err
	}
	if err == redis.Nil {
		return false, nil
	}
	return true, nil
}
func (p *RedisImplDelayQueue) ExcludeMsgItem(ctx context.Context, id int64, key string) error { // GetSuperiorContentQueueKey()
	_, err := p.redisClient.ZRem(ctx, key, id).Result()
	if err != nil {
		logger.Errorf(ctx, "del id: %d from: %v in queue, fail: %v", id, GetSuperiorContentQueueKey(), err)
		return err
	}
	return nil
}

func (p *RedisImplDelayQueue) SendMsg(ctx context.Context, work *pbapi.PersonalBottleWorksDbModel) error {
	if p.redisClient == nil || work == nil {
		return errorcode.GenBusiErr(errorcode.WorkNotExist, "参数或者动态消息不存在")
	}
	settlementTimeMill, err := GetWorkValidTimeFromCreated(ctx, work.GetCreateTime()) //存入的是动态创建后的三小时时间戳。
	if err != nil {
		return err
	}

	_, err = p.redisClient.ZAdd(ctx, GetSuperiorContentQueueKey(), &redis.Z{Score: float64(settlementTimeMill), Member: work.GetId()}).Result()
	if err != nil {
		logger.Errorf(ctx, "add item to queue fail, key: %v, workId: %v, score: %v", GetSuperiorContentQueueKey(), work.GetId(), settlementTimeMill)
		return err
	}
	logger.Infof(ctx, "add item to queue, key: %v, workId: %v, score: %v", GetSuperiorContentQueueKey(), work.GetId(), settlementTimeMill)

	if e := p.notifyHandler.SendNotifyOnChanel(ctx); e != nil {
		logger.Errorf(ctx, "send notify by redis fail, err: %v", err)
	}
	return nil
}

func (p *RedisImplDelayQueue) QueryItemLatest(ctx context.Context, key string) (int64, int64, error) {
	if p.redisClient == nil {
		return 0, 0, nil
	}
	works, err := p.redisClient.ZRangeWithScores(ctx, key, 0, 0).Result()
	if err != nil {
		return 0, 0, nil
	}
	if len(works) <= 0 {
		return 0, 0, nil
	}
	member, err := strconv.ParseInt(works[0].Member.(string), 10, 64)

	return member, int64(works[0].Score), nil
}
func (p *RedisImplDelayQueue) QueryAllItems(ctx context.Context, key string) ([]int64, error) {
	if p.redisClient == nil {
		return nil, nil
	}

	min, max := "-inf", "+inf"
	works, err := p.redisClient.ZRangeByScoreWithScores(ctx, key, &rdsV8.ZRangeBy{
		Min: min,
		Max: max,
	}).Result()

	if err != nil {
		logger.Errorf(ctx, "get delay queue fail, err: %v", err)
		return nil, err
	}
	var workIds []int64
	for k, _ := range works {
		id, err := strconv.ParseInt(works[k].Member.(string), 10, 64)
		if err == nil {
			workIds = append(workIds, id)
		}
	}
	return workIds, nil
}

func (p *RedisImplDelayQueue) QueryItemsByTimeCond(ctx context.Context, scoreBeginTime, scoreEndTime int64, key string) ([]int64, error) {
	if p.redisClient == nil {
		return nil, nil
	}

	if scoreBeginTime > scoreEndTime {
		logger.Errorf(ctx, "begin time: %v more then end time: %v", scoreBeginTime, scoreEndTime)
		return nil, errors.New("input param is invalid")
	}
	//
	min, max := "", ""
	if scoreBeginTime > 0 {
		min = strconv.FormatInt(scoreBeginTime, 10)
	} else {
		min = "-inf"
	}
	//
	max = strconv.FormatInt(scoreEndTime, 10)
	works, err := p.redisClient.ZRangeByScoreWithScores(ctx, key, &rdsV8.ZRangeBy{
		Min: min,
		Max: max,
	}).Result()

	if err != nil {
		logger.Errorf(ctx, "get delay queue fail, err: %v", err)
		return nil, err
	}
	var workIds []int64
	for k, _ := range works {
		id, err := strconv.ParseInt(works[k].Member.(string), 10, 64)
		if err == nil {
			workIds = append(workIds, id)
		}
	}
	return workIds, nil

}
func (p *RedisImplDelayQueue) ReceiveMsg(ctx context.Context) error {

	return nil
}

// ////
func NewWithdrawDelayQueue(redisClient *rdsV8.Client) IDelayQueue {
	return &RedisImplDelayQueue{
		redisClient:   redisClient,
		notifyHandler: NewQueryNotifyChannelNode(redisClient, getWithdrawQueueNotifyChName()),
	}
}
func getWithdrawQueueNotifyChName() string {
	return fmt.Sprintf(cache_const.SuperiorContentQueueNotifyChName.KeyFmt, "withdraw_kola")
}
func GetWithdrawQueueKey() string {
	return cache_const.WithdrawPayDetailQueueConf.KeyFmt
}
func (p *RedisImplDelayQueue) SendWithdrawItem(ctx context.Context, withdrawDetailId int64, delayTimeSecond int32) error {
	if p.redisClient == nil || withdrawDetailId <= 0 || delayTimeSecond < 0 {
		return errorcode.GenBusiErr(errorcode.WorkNotExist, "参数或者动态消息不存在")
	}
	//field 为： kola_withdraw_detail 表中的_id
	scoreTimeSecond := int64(delayTimeSecond*1e3) + time.Now().UnixMilli()
	_, err := p.redisClient.ZAdd(ctx, GetWithdrawQueueKey(), &redis.Z{Score: float64(scoreTimeSecond), Member: withdrawDetailId}).Result()
	if err != nil {
		logger.Errorf(ctx, "add item to queue on withdraw fail,err: %v, key: %v, workId: %v, score: %v", err, GetWithdrawQueueKey(), withdrawDetailId, scoreTimeSecond)
		return err
	}
	logger.Infof(ctx, "add item to queue on withdraw, key: %v, workId: %v, score: %v", GetWithdrawQueueKey(), withdrawDetailId, scoreTimeSecond)

	if e := p.notifyHandler.SendNotifyOnChanel(ctx); e != nil {
		logger.Errorf(ctx, "send notify by redis fail, err: %v", err)
	}
	return nil
}
