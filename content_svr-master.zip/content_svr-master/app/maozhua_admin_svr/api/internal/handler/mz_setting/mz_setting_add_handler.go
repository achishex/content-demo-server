package mz_setting

import (
	"content_svr/app/maozhua_admin_svr/common/result"
	"content_svr/app/maozhua_admin_svr/common/xhttp"
	"github.com/go-playground/validator/v10"
	"net/http"

	"content_svr/app/maozhua_admin_svr/api/internal/logic/mz_setting"
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
)

type verifyMzSettingAddReqRequest struct {
	types.MzSettingAddReq
}

func (p *verifyMzSettingAddReqRequest) Validate() error {
	valid := validator.New()
	if err := valid.Struct(p); err != nil {
		return err
	}
	return nil
}

func MzSettingAddHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req verifyMzSettingAddReqRequest
		if err := xhttp.Parse(r, &req); err != nil {
			result.ParamErrorResult(r, w, err)
			return
		}

		l := mz_setting.NewMzSettingAddLogic(r.Context(), svcCtx)
		resp, err := l.MzSettingAdd(&req.MzSettingAddReq)
		result.HttpResult(r, w, resp, err)
	}
}
