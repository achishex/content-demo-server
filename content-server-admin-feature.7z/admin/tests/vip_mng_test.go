package tests

import (
	"content_svr/app/di"
	"content_svr/internal/vip_mng"
	"context"
	"github.com/stretchr/testify/assert"
	"testing"
)

var c = di.NewContainer()

func TestVipRefund(t *testing.T) {
	ctx := context.Background()
	e := c.Invoke(func(v *vip_mng.VipMng) {
		right, err := v.GetRefundRight(ctx, 100)
		assert.Nil(t, err)
		assert.Greater(t, right, int64(0))

		orders, err := v.FindRefundOrder(ctx, 1)
		assert.Nil(t, err)
		assert.NotEmpty(t, orders)
	})
	assert.Nil(t, e)
}
