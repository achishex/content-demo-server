package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	"time"
)

// 这个得实时查
func (p *DataCacheMng) GetPersonTalkMsgTotalMgDB(ctx context.Context, uniqueId int32, toUserId int64) *pbapi.PersonalTalkMessageTotalMgDbModel {
	//cacheKey := fmt.Sprintf(cache_const.PersonTalkMsgTotalLcache.KeyFmt, uniqueId, toUserId)
	//expire := cache_const.PersonTalkMsgTotalLcache.Expire
	//
	////从内存取
	//cResp, exist := p.LocalCache.Get(cacheKey)
	//if exist {
	//	resp, ok := cResp.(*pbapi.PersonalTalkMessageTotalMgDbModel)
	//	if ok {
	//		return resp
	//	}
	//}

	//从mg db取.
	mgItem, err := p.PersonalTalkMessageTotalMgDbModel.GetById(ctx, uniqueId, toUserId)
	if err != nil {
		logger.Errorf(ctx, "get GetPersonTalkMsgTotalMgDB failed. uniqueId=%v, err=%v", uniqueId, err.Error())
		return nil
	}

	//// todo 已回复的才记录到缓存。
	//if mgItem != nil && mgItem.GetInteractTimes() > 0 {
	//	bSuc := p.LocalCache.Set(cacheKey, mgItem, go_cache.WithEx(time.Duration(expire)*time.Second))
	//	logger.Infof(ctx, "save GetPersonTalkMsgTotalMgDB to local cache. cacheKey=%v, val.InteractTimes=%v， bSuc=%v", cacheKey, mgItem.GetInteractTimes(), bSuc)
	//}

	return mgItem
}

func (p *DataCacheMng) GetPersonTalkMsgTotalWithIdMgDBLd(ctx context.Context, fromUserId, toUserId, workId int64) *pbapi.PersonalTalkMessageTotalMgDbModel {
	cacheKey := fmt.Sprintf(cache_const.PersonTalkMsgTotalWithIdsLcache.KeyFmt, fromUserId, toUserId, workId)
	expire := cache_const.PersonTalkMsgTotalLcache.Expire

	//从内存取
	cResp, exist := p.LocalCache.Get(cacheKey)
	if exist {
		resp, ok := cResp.(*pbapi.PersonalTalkMessageTotalMgDbModel)
		if ok {
			return resp
		}
	}

	//从mg db取. 所有medals信息
	mgItem, err := p.PersonalTalkMessageTotalMgDbModel.GetByFromAndToId(ctx, fromUserId, toUserId, workId)
	if err != nil {
		logger.Errorf(ctx, "get GetPersonTalkMsgTotalWithIdMgDBLd failed. fromUserId=%v, toUserid=%v, err=%v",
			fromUserId, toUserId, err.Error())
		return nil
	}

	if mgItem != nil {
		bSuc := p.LocalCache.Set(cacheKey, mgItem, go_cache.WithEx(time.Duration(expire)*time.Second))
		logger.Infof(ctx, "save GetPersonTalkMsgTotalWithIdMgDBLd to local cache. cacheKey=%v, val.InteractTimes=%v， bSuc=%v",
			cacheKey, mgItem.GetInteractTimes(), bSuc)
	}
	return mgItem
}

func (p *DataCacheMng) InsertPersonTalkMsgTotalMgDBLd(ctx context.Context, item *pbapi.PersonalTalkMessageTotalMgDbModel) error {
	logger.Infof(ctx, "InsertPersonTalkMsgTotalMgDBLd. item.id=%v, fromUserId=%v, toUserId=%v，UniqueId=%v,workId=%v modeType=%v",
		item.GetId(), item.GetFromUserId(), item.GetToUserId(), item.GetUniqueId(), item.GetWorkId(), item.GetModeType())
	return p.PersonalTalkMessageTotalMgDbModel.Insert(ctx, item)
}

func (p *DataCacheMng) UpdatePersonTalkMsgTotalMgDBLd(
	ctx context.Context, id int64,
	changes map[string]interface{},
	incDict map[string]int) error {
	return p.PersonalTalkMessageTotalMgDbModel.UpdateDictById(ctx, id, changes, incDict)
}
