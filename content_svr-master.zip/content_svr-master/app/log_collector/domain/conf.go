package domain

type Conf struct {
	MongoURI                 string   `yaml:"mongo_uri"`
	MongoDatabase            string   `yaml:"mongo_database"`
	KafkaBrokers             []string `yaml:"kafka_brokers"`
	RateLimit                int      `yaml:"rate_limit"`
	RateLimitN               int      `yaml:"rate_limit_n"`
	BatchInsertSize          int      `yaml:"batch_insert_size"` //批量插入数量
	BatchInsertIntervalInSec int      `yaml:"batch_insert_interval_in_sec"`
}
