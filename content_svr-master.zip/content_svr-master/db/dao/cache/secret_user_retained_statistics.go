package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type SecretUserRetainedStatistics struct {
	model.SecretUserRetainedStatisticsModel
	redisManage *query_rds.Manage
}

func NewCacheSecretUserRetainedStatistics(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *SecretUserRetainedStatistics {
	return &SecretUserRetainedStatistics{
		SecretUserRetainedStatisticsModel: mongo.SecretUserRetainedStatistics,
		redisManage:                       redisManage,
	}
}
