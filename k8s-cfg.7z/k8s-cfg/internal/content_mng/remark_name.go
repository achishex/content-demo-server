package content_mng

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbuserapi"
	"context"
)

func (p *ContentMng) SetUserRemarkName(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbuserapi.UserRemarkNameReq) error {
	loginUser, err := p.getUserInfo(ctx, header)
	if err != nil {
		return errorcode.MIDAS_LOGIN_ERROR
	}

	if loginUser.UserInfoDbModel.GetUserId() == req.GetToUserId() {
		return errorcode.RemarkNameSelfError
	}

	follow, err := p.DataCache.GetImpl().SecretUserFollowMgModel.GetByUserId(ctx, loginUser.UserInfoDbModel.GetUserId(), req.GetToUserId())
	if err != nil {
		return err
	}
	if follow.GetMutual() != const_busi.Mutual {
		return errorcode.RemarkNameError
	}

	filter := map[string]interface{}{
		"userId":       loginUser.UserInfoDbModel.GetUserId(),
		"targetUserId": req.GetToUserId(),
	}
	update := map[string]interface{}{
		"remarkName": req.Name,
	}
	if _, err := p.DataCache.GetImpl().SecretUserFollowMgModel.UpsertMapOne(ctx, filter, update); err != nil {
		return err
	}

	if err := p.DataCache.SetUserRemarkOne(ctx, loginUser.UserInfoDbModel.GetUserId(), req.GetToUserId(), req.GetName()); err != nil {
		return err
	}

	return nil
}

func (p *ContentMng) GetUserRemarkNameOne(ctx context.Context, userId, toUserId int64) (string, error) {
	return p.DataCache.GetUserRemarkOne(ctx, userId, toUserId)
}
