package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var _ SecretReportUserModel = (*customSecretReportUserModel)(nil)

type (
	// SecretReportUserModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretReportUserModel.
	SecretReportUserModel interface {
		secretReportUserModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretReportUser, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretReportUser, error)
	}

	customSecretReportUserModel struct {
		*defaultSecretReportUserModel
	}
)

// NewSecretReportUserModel returns a model for the mongo.
func NewSecretReportUserModel(cfg MonConfig) SecretReportUserModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SecretReportUserCollectionName)
	return &customSecretReportUserModel{
		defaultSecretReportUserModel: newDefaultSecretReportUserModel(conn),
	}
}

func (m *customSecretReportUserModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customSecretReportUserModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretReportUserModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretReportUser, error) {
	result := make([]SecretReportUser, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretReportUserModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretReportUser, error) {
	var data SecretReportUser
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
