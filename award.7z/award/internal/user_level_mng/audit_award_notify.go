package user_level_mng

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"math"
	"time"
)

const (
	// 存在举报奖励资格
	awardSuccess = `你于%s举报了%s“%s”，该帖子经客服核实确认违规，我们已对该用户进行惩处。

为感谢你对猫爪的付出，成功举报满%d次即可解锁一枚加速码（%d/%d）。

注意：恶意举报他人将暂时取消奖励资格哦～`
	// 已解锁一枚激活码奖励
	awardSuccessHaveCode = `感谢你这段时间对猫爪社区的贡献，我们为你准备了一枚最最新鲜的加速码，请笑纳～

%s`

	// 暂无举报奖励资格
	awardSuccessQualify = `你于%s举报了%s“%s”，该帖子经客服核实确认违规，我们已对该用户进行惩处，感谢你对猫爪的付出～`

	// 举报失败
	awardFail = `你于%s举报了%s“%s”，该帖子经客服核实未存在违规行为，后续我们将持续关注该用户，努力营造更好的社区氛围。`
	// 系统判断为恶意举报
	awardMaliciousReport = `请勿恶意举报他人哦，下次举报奖励资格将在%d天后（%s）恢复。`
)

func (p *UserLevelMng) awardNotify(ctx context.Context, message *notifyMessage) {
	if err := p.DataCache.GetAuditAwardSetting(ctx); err != nil {
		logger.Error(ctx, "GetAuditAwardSetting", err)
	}

	filter := bson.D{
		{"user_id", message.reportUserId},
		{"work_id", message.workId},
		{"comment_id", message.commentId},
	}
	aRecord, err := p.DataCache.GetImpl().AuditAwardRecordMgDbModel.FindOne(ctx, filter)
	switch err {
	case mongo.ErrNoDocuments:
		break
	case nil:
		logger.Infof(ctx, "已存在该条举报奖励表的记录: %v", aRecord)
		return
	default:
		logger.Error(ctx, "AuditAwardRecordMgDbModel.FindOne", err)
		return
	}

	if err := p.buildAwardRecord(ctx, message); err != nil {
		logger.Error(ctx, "buildAwardRecord", err)
	}
}

func (p *UserLevelMng) buildAwardRecord(ctx context.Context, message *notifyMessage) error {
	html := ""
	awardStatus, passCount, err := p.checkAwardRecord(ctx, message.reportUserId, message.isPunish)
	if err != nil {
		return err
	}

	maliciousStatus := NoRecord // 不在记录恶意举报
	//maliciousStatus, _, err := p.checkMaliciousUser(ctx, message.reportUserId)
	//if err != nil {
	//	return err
	//}

	passMaxCount := int64(cm_const.AuditPassMaxCount * cm_const.AuditAwardLength)
	nowTime := time.Now()
	record := &pbmgdb.AuditAwardRecordMng{
		SettleAccounts: false,
		Pass:           false,
		CreateTime:     nowTime.UnixMilli(),
		UpdateTime:     nowTime.UnixMilli(),
		UserId:         message.reportUserId,
		WorkId:         message.workId,
		CommentId:      message.commentId,
	}

	switch p.judgeAwardNotifyType(message.isPunish, awardStatus, maliciousStatus) {
	case cm_const.AuditSuccess:
		record.SettleAccounts = false
		record.Pass = true
		html = fmt.Sprintf(awardSuccess, message.reportTime, message.messageType, message.content, passMaxCount, passCount, passMaxCount)
		p.sendNotify(ctx, message.reportUserId, html)
	case cm_const.AuditSuccessAwardCode:
		record.SettleAccounts = true
		record.Pass = true
		// get加速码, 结算
		code := p.getAwardSpeedCode(ctx)
		if err != nil {
			logger.Error(ctx, "getAwardChitChatCDKey", err)
			break
		}
		if err := p.settleAccountAwardRecord(ctx, message.reportUserId); err != nil {
			logger.Error(ctx, "settleAccountAwardRecord", err)
			break
		}

		// 先发一次成功通知
		html = fmt.Sprintf(awardSuccess, message.reportTime, message.messageType, message.content, passMaxCount, passCount, passMaxCount)
		p.sendNotify(ctx, message.reportUserId, html)

		// 激活码奖励通知
		html = fmt.Sprintf(awardSuccessHaveCode, code)
		p.sendNotify(ctx, message.reportUserId, html)

	case cm_const.AuditSuccessMaliciousLock:
		record.SettleAccounts = true
		record.Pass = true
		//html = fmt.Sprintf(awardSuccessQualify, message.reportTime, message.messageType, message.content)
		//p.sendNotify(ctx, message.reportUserId, html)

	case cm_const.AuditFail:
		record.SettleAccounts = false
		record.Pass = false
		//html = fmt.Sprintf(awardFail, message.reportTime, message.messageType, message.content)
		//p.sendNotify(ctx, message.reportUserId, html)

	case cm_const.AuditFailMalicious:
		record.SettleAccounts = true
		record.Pass = false
		//html = fmt.Sprintf(awardFail, message.reportTime, message.messageType, message.content)
		//p.sendNotify(ctx, message.reportUserId, html)

	case cm_const.AuditMalicious:
		//  结算
		record.SettleAccounts = true
		record.Pass = false
		if err := p.settleAccountAwardRecord(ctx, message.reportUserId); err != nil {
			logger.Error(ctx, "settleAccountAwardRecord", err)
			break
		}

		////  登记恶意记录
		//endTime := nowTime.Add(time.Hour * 24 * time.Duration(cm_const.AuditMaliciousLockTime))
		//maliciousMaxCount := int64(cm_const.AuditMaliciousMaxCount * cm_const.AuditAwardLength)
		//mrr := &pbmgdb.AuditMaliciousRecordMng{
		//	CreateTime: nowTime.UnixMilli(),
		//	EndTime:    endTime.UnixMilli(),
		//	UserId:     message.reportUserId,
		//	Count:      maliciousMaxCount,
		//}
		//err := p.DataCache.GetImpl().AuditMaliciousRecordMgDbModel.Create(ctx, mrr)
		//if err != nil {
		//	return err
		//}
		//lockEndDate := endTime.Format("2006-01-02 15:04:05")
		//// 先下发举报失败的通知
		//html = fmt.Sprintf(awardFail, message.reportTime, message.messageType, message.content)
		//p.sendNotify(ctx, message.reportUserId, html)
		//// 再下发恶意举报的通知
		//html = fmt.Sprintf(awardMaliciousReport, cm_const.AuditMaliciousLockTime, lockEndDate)
		//p.sendNotify(ctx, message.reportUserId, html)
	default:
		logger.Error(ctx, fmt.Sprintf("不存在该举报奖励类型 %v / %v / %v", message.isPunish, awardStatus, maliciousStatus), nil)
		return nil
	}

	if err := p.DataCache.GetImpl().AuditAwardRecordMgDbModel.Create(ctx, record); err != nil {
		logger.Error(ctx, "AuditAwardRecordMgDbModel.Create", err)
		return err
	}

	return nil
}

func (p *UserLevelMng) judgeAwardNotifyType(isPunish bool, as awardRecordType, ms maliciousType) uint8 {
	switch {
	// 处罚
	case isPunish && ms != LockTime && as == noCode:
		return cm_const.AuditSuccess
	case isPunish && ms != LockTime && as == awardCode:
		return cm_const.AuditSuccessAwardCode
	case isPunish && ms == LockTime:
		return cm_const.AuditSuccessMaliciousLock
	// 未处罚
	case !isPunish && as == doMalicious:
		// 恶意
		//return cm_const.AuditMalicious
		return cm_const.AuditFail
	case !isPunish && ms != LockTime:
		return cm_const.AuditFail
	case !isPunish && ms == LockTime:
		//return cm_const.AuditFailMalicious
		return cm_const.AuditFail
	default:
		return cm_const.AuditUnknown
	}
}

func (p *UserLevelMng) getAwardChitChatCDKey(ctx context.Context) (string, int64) {
	expireDay := p.DataCache.GetChitChatCDKeyExpireTime(ctx)
	expireTime := time.Now().Add(time.Hour * 24 * time.Duration(expireDay))

	code, err := p.DataCache.GetImpl().SecretChitChatCDKeyMgDbModel.CreateCdKey(ctx, 1, expireTime.UnixMilli())
	if err != nil {
		logger.Error(ctx, "SecretChitChatCDKeyMgDbModel.CreateCdKey", err)
	}

	return code, expireTime.UnixMilli()
}

func (p *UserLevelMng) getAwardSpeedCode(ctx context.Context) string {
	code, err := p.DataCache.GetImpl().SecretSpeedCodeMgModel.Create(ctx, 1)
	if err != nil {
		logger.Error(ctx, "getAwardSpeedCode.Create SpeedCode error", err)
	}

	return code
}

func (p *UserLevelMng) settleAccountAwardRecord(ctx context.Context, userId int64) error {
	filter := map[string]interface{}{
		"user_id": userId,
	}
	update := map[string]interface{}{
		"settle_accounts": true,
	}
	_, err := p.DataCache.GetImpl().AuditAwardRecordMgDbModel.UpdateMap(ctx, filter, update)
	if err != nil {
		return err
	}
	return nil
}

type awardRecordType uint8

const (
	unknownAwardRecord awardRecordType = iota
	noCode                             // 成功，但不足奖励激活码
	awardCode                          // 成功，奖励激活码
	doMalicious                        // 此时封禁
)

func (p *UserLevelMng) checkAwardRecord(ctx context.Context, userId int64, isPunish bool) (awardRecordType, int64, error) {
	var passCount, wrongCount float64
	if isPunish {
		passCount++
	} else {
		wrongCount++
	}

	filter := bson.D{
		{"user_id", userId},
		{"settle_accounts", false},
	}
	records, err := p.DataCache.GetImpl().AuditAwardRecordMgDbModel.FindAll(ctx, filter)
	switch err {
	case mongo.ErrNoDocuments:
		// 无任何举报记录
		return noCode, int64(passCount), nil
	case nil:
		if len(records) == 0 {
			return noCode, int64(passCount), nil
		}

		for _, record := range records {
			if record.Pass {
				passCount++
			} else {
				wrongCount++
			}
		}

		passMaxCount := math.Round(cm_const.AuditPassMaxCount * cm_const.AuditAwardLength)
		maliciousMaxCount := math.Round(cm_const.AuditMaliciousMaxCount * cm_const.AuditAwardLength)

		switch {
		case passCount >= passMaxCount:
			// 成功，奖励激活码
			return awardCode, int64(passCount), nil
		case wrongCount >= maliciousMaxCount:
			// 此时封禁
			return doMalicious, 0, nil
		default:
			// 成功，但不足奖励激活码
			return noCode, int64(passCount), nil
		}

	default:
		return unknownAwardRecord, 0, err
	}

}

type maliciousType uint8

const (
	unknownMalicious maliciousType = iota
	NoRecord                       // 无恶意记录
	LockTime                       // 处于封禁时间
	UnLockTime                     // 已过封禁时间
)

func (p *UserLevelMng) checkMaliciousUser(ctx context.Context, userId int64) (maliciousType, int64, error) {
	filter := bson.D{
		{"user_id", userId},
	}
	opt := &options.FindOneOptions{}
	opt.Sort = bson.D{
		{"create_time", -1},
	}
	mRecord, err := p.DataCache.GetImpl().AuditMaliciousRecordMgDbModel.FindOne(ctx, filter, opt)
	switch err {
	case mongo.ErrNoDocuments:
		// 无恶意记录
		return NoRecord, 0, nil
	case nil:
		nowTime := time.Now().UnixMilli()
		if nowTime > mRecord.EndTime {
			// 有恶意记录，但已过封禁时间
			return UnLockTime, 0, nil
		}
		return LockTime, mRecord.EndTime, nil
	default:
		return unknownMalicious, 0, err
	}

}
