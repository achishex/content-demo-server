package job

import (
	"content_svr/db/aggregation"
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

func InitMemberSum(write, read *dao.ManagerDB) {

	ctx := requestid.WithRequestID(context.Background())
	target := time.Now().AddDate(0, 0, -1)
	ctrl := newUserMemberSumControl(write, read)
	if err := ctrl.DoTask(ctx, target); err != nil {
		logger.Error(context.Background(), "InitMemberSum:", err)
	}

}

type userMemberSumControl struct {
	write, read *dao.ManagerDB
	sumDb       *aggregation.SumManage
}

func newUserMemberSumControl(write, read *dao.ManagerDB) userMemberSumControl {
	ctrl := userMemberSumControl{}
	ctrl.write = write
	ctrl.read = read
	ctrl.sumDb = aggregation.NewSumManage(read, write)
	return ctrl
}

func (l userMemberSumControl) DoTask(ctx context.Context, targetTime time.Time) error {
	data, err := l.calcMemberSum(ctx, targetTime)
	if err != nil {
		return err
	}

	if err := l.saveUserMemberStatistical(ctx, data, targetTime); err != nil {
		return err
	}

	day, _ := utils.TimeByDay(targetTime)
	logger.Infof(ctx, "%d 会员充值统计完成\n", day)
	return nil
}

func (l userMemberSumControl) calcMemberSum(ctx context.Context, targetTime time.Time) (*model.UserMemberStatistical, error) {

	gtTime := utils.ZeroTime(targetTime)
	ltTime := utils.ZeroTime(utils.CalcTime(targetTime, 1))

	where := map[string]interface{}{
		"create_time_start": gtTime.Format("2006-01-02 15:04:05"),
		"create_time_end":   ltTime.Format("2006-01-02 15:04:05"),
		"type":              1001,
		"order_status":      3,
	}

	var statistical model.UserMemberStatistical
	result, err := l.sumDb.Member.UserMember(ctx, where)
	if err != nil {
		return nil, err
	}

	if len(result) == 0 {
		return &statistical, nil
	}
	statistical = result[0]

	return &statistical, err
}

func (l userMemberSumControl) saveUserMemberStatistical(ctx context.Context, data *model.UserMemberStatistical, targetTime time.Time) error {
	updateFilter := bson.D{
		{"day", data.Day},
	}

	update := bson.D{
		{"$set", data},
		{"$setOnInsert", bson.D{
			{"create_time", targetTime.UnixMilli()},
		}},
	}

	opt := options.Update().SetUpsert(true)
	if _, err := l.write.UserMemberStatistical.Update(ctx, updateFilter, update, opt); err != nil {
		return err
	}

	return nil
}
