package mg_model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type IWorksExpandRelMgModel interface {
	ListByWorkId(ctx context.Context,
		workId int64) ([]*pbapi.WorksExpandRelMgDbModel, error)
	//UpdateItem(ctx context.Context, model *pbapi.WorksExpandRelMgDbModel) (*pbapi.WorksExpandRelMgDbModel, error)
	//CreateItem(ctx context.Context, model *pbapi.WorksExpandRelMgDbModel) (*pbapi.WorksExpandRelMgDbModel, error)
	//ListItemOffset(ctx context.Context, condition map[string]interface{}, offsetId int, size int) ([]*pbapi.WorksExpandRelMgDbModel, error)
	//ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbapi.WorksExpandRelMgDbModel, error)
	//CountItemsByCondition(ctx context.Context, condition map[string]interface{}) (total int64, _ error)
}

type WorksExpandRelMgDbImpl struct {
	MgDB *mongo.Database
}

func NewWorksExpandRelMgModelImpl(db *mongo.Database) IWorksExpandRelMgModel {
	return &SecretShareUserInfoExtMgDbImpl{MgDB: db}
}

// 查不到返回nil
func (impl *SecretShareUserInfoExtMgDbImpl) ListByWorkId(ctx context.Context,
	workId int64) ([]*pbapi.WorksExpandRelMgDbModel, error) {
	retItems := make([]*pbapi.WorksExpandRelMgDbModel, 0)
	collection := impl.MgDB.Collection("secretWorksExpandRel")
	find, err := collection.Find(ctx, bson.M{"workId": workId})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("WorksExpandRelMgDbModel Find failed.workId=%v",
			workId), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.WorksExpandRelMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to WorksExpandRelMgDbModel failed.workId=%v",
				workId), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	return retItems, err
}
