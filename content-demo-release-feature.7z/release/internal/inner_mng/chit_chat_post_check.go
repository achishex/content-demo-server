package inner_mng

import (
	"content_svr/config"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
)

// 通过-true。 0-pass通过  1-swallow吞掉且不给用户提示 2-warn警告给用户提示。
func (p *InnerProxyImpl) ChitChatPostCheck(ctx context.Context, content string, fromUserId int64) (*pbapi.PersonalTalkCheckResp, error) {
	url := config.ServerConfig.CheckSvrHost + "/api/content/chit_chat_post_check"
	req := map[string]interface{}{
		"content":      content,
		"from_user_id": fromUserId,
	}
	bodyBytes, _ := json.Marshal(req)
	resp, err := p.postRequest(ctx, url, bodyBytes)
	if err != nil {
		logger.Errorf(ctx, "chit_chat_post_check return err. req=%v, err=%v", req, err)
		return nil, err
	}

	if resp.StatusCode != 200 {
		logger.Errorf(ctx, "chit_chat_post_check httpcode!=200. req=%v,resp.StatusCode != 200", req)
		return nil, fmt.Errorf("http retcode != 200, retcode=%v", resp.Status)
	}

	innerResp := &pbapi.PersonalTalkCheckResp{}
	json.NewDecoder(resp.Body).Decode(innerResp)
	//bPass = innerResp.GetIResultCode() != pbapi.IResultCodeEnum_swallow
	//logger.Infof(ctx, "chit_chat_post_check over, userId=%v, url=%v, innerResp=%+v", userId, url, innerResp)
	//return int32(innerResp.GetIResultCode()), nil
	return innerResp, nil
}
