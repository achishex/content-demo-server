package job

import (
	"content_svr/db/dao"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"context"
	"fmt"
	"time"
)

type notifyMoneyControl struct {
	TickerExecute

	write, read *dao.ManagerDB
}

func InitMoneyRobot(write, read *dao.ManagerDB) {
	moneyControl := notifyMoneyControl{}

	//moneyControl.today = true
	moneyControl.hour = 10
	moneyControl.write = write
	moneyControl.read = read

	go func() {
		//ctx := requestid.WithRequestID(context.Background())
		//moneyControl.DoTask(ctx, time.Now().AddDate(0, 0, -1))
		//return
		moneyControl.Do(func() {
			ctx := requestid.WithRequestID(context.Background())
			if err := moneyControl.DoTask(ctx, time.Now().AddDate(0, 0, -1)); err != nil {
				logger.Errorf(ctx, "moneyControl.DoTask: %v", err)
				// 五分钟后重试
				moneyControl.ticker.Reset(time.Minute * 5)
				return
			}

			moneyControl.ticker.Reset(moneyControl.calcIntervalTime())
		})

	}()
}

func (r notifyMoneyControl) DoTask(ctx context.Context, targetTime time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	filter := map[string]interface{}{
		"day": r.baseZeroTime(targetTime).UnixMilli(),
	}

	data, err := r.read.SuperiorAwardDaily.FindOne(ctx, filter)
	if err != nil {
		return err
	}

	var memberSum float64
	if member, err := r.read.UserMemberStatistical.FindOne(ctx, filter); err == nil {
		memberSum = float64(member.PriceSum)
	} else {
		logger.Error(ctx, "UserMemberStatistical.FindOne", err)
	}

	var revenueSum float64
	filter = map[string]interface{}{
		"date": targetTime.Format("2006-01-02"),
	}
	if csjList, err := r.read.CsjAdvertisementData.FindAll(ctx, filter); err == nil {
		for _, csj := range csjList {
			revenueSum += csj.Revenue
		}
	} else {
		logger.Error(ctx, "CsjAdvertisementData.FindOne", err)
	}

	AwardSettlementSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天结算奖励总和: %.2f\n", float64(data.AwardSettlementSum)/100),
	}
	DeductionIllegalSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天违规扣除总和: %.2f\n", float64(data.DeductionIllegalSum)/100),
	}
	FirstWorkSettlementSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天首条动态奖励总和: %.2f\n", float64(data.FirstWorkSettlementSum)/100),
	}
	WechatPayWithdrawSuccessSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天微信提现成功总和: %.2f\n", float64(data.WechatPayWithdrawSuccessSum)/100),
	}
	WechatPayWithdrawFailSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天微信提现失败总和: %.2f\n", float64(data.WechatPayWithdrawFailSum)/100),
	}
	HallOfFameAwardSettlementSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天排行榜奖励总和: %.2f\n", float64(data.HallOfFameAwardSettlementSum)/100),
	}
	MemberSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天充值总和: %.2f\n", memberSum/100),
	}
	CsjSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("穿山甲广告预估收益总和: %.2f\n", revenueSum),
	}
	GameSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天游戏充值总和: %.2f\n", float64(data.GameSum)/100),
	}

	items := []item{
		AwardSettlementSumMessage,
		DeductionIllegalSumMessage,
		FirstWorkSettlementSumMessage,
		WechatPayWithdrawSuccessSumMessage,
		WechatPayWithdrawFailSumMessage,
		HallOfFameAwardSettlementSumMessage,
		MemberSumMessage,
		CsjSumMessage,
		GameSumMessage,
	}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = fmt.Sprintf("%d 各类结算统计", r.baseTimeByDay(targetTime))
	m.Content.Post.ZhCn.Content = make([][]item, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	RobotBossControl.SendMessage(m)

	// 统计完成后当天早上8点再发通知
	//now := time.Now()
	//target := time.Date(now.Year(), now.Month(), now.Day(), 8, 0, 0, 0, now.Location())
	//r.SendMessageAfterTime(m, target.Sub(now))

	return nil
}
