package user_center_mng

import (
	"content_svr/protobuf/pbuserapi"
	"context"
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestTXSign(t *testing.T) {
	c := NewTencentLoginComp(map[string]string{
		"1400920109": "beb43b7c5f022444416b23225c2a28b1",
	})
	ctx := context.Background()
	ares, err := c.AuthCall(ctx, &pbuserapi.QuickLoginReq{
		LoginToken: "05F767A4E7874AA38392C2D4857735E0",
		Carrier:    "telecom",
		Sdkappid:   "1400920109",
	})
	assert.Nil(t, err)
	t.Log(ares)
}
