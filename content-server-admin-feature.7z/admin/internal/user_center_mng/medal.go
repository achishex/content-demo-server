package user_center_mng

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"context"
	"errors"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/mongo"
	"time"
)

// 永久勋章
func (u *UserCenterMng) MediaPermanent(ctx context.Context, userId, medalId int64) error {
	var (
		medalDoc = u.DataCache.GetImpl().UserMedalMgModel

		media *pbapi.SecretUserMedalInfoMgDbModel
		err   error
	)

	if media, err = medalDoc.GetOneByMediaAndUserId(ctx, userId, medalId); err != nil && !errors.Is(err, mongo.ErrNoDocuments) {
		return err
	}

	if media == nil {
		if err := medalDoc.Insert(ctx, &pbapi.SecretUserMedalInfoMgDbModel{
			Id:        proto.Int64(snow_flake.GetSnowflakeID()),
			UserId:    &userId,
			MedalId:   &medalId,
			Expire:    proto.Int64(time.Now().AddDate(100, 0, 0).UnixMilli()),
			Timestamp: proto.Int64(time.Now().UnixMilli()),
		}); err != nil {
			return err
		}
	} else {
		update := map[string]any{
			"expire": time.Now().AddDate(100, 0, 0).UnixMilli(),
		}
		if err := medalDoc.UpdateDictById(ctx, media.GetId(), update, nil); err != nil {
			return err
		}
	}

	u.DataCache.GetImpl().LocalCache.Del(fmt.Sprintf(cache_const.MedalInfoLcache.KeyFmt, userId))
	return nil
}

// 取消勋章
func (u *UserCenterMng) MediaCancel(ctx context.Context, userId, medalId int64) error {
	var (
		medalDoc = u.DataCache.GetImpl().UserMedalMgModel
		now      = time.Now().UnixMilli()

		medal *pbapi.SecretUserMedalInfoMgDbModel
		err   error
	)

	if medal, err = medalDoc.GetOneByMediaAndUserId(ctx, userId, medalId); err != nil && !errors.Is(err, mongo.ErrNoDocuments) {
		return err
	}

	if medal != nil && medal.GetExpire() > now {
		update := map[string]any{
			"expire": now,
		}
		if err := medalDoc.UpdateDictById(ctx, medal.GetId(), update, nil); err != nil {
			return err
		}
	}

	u.DataCache.GetImpl().LocalCache.Del(fmt.Sprintf(cache_const.MedalInfoLcache.KeyFmt, userId))

	return nil
}

// 添加勋章
func (u *UserCenterMng) MediaAdd(ctx context.Context, userId, medalId int64, expire int64) error {
	umItem := &pbapi.SecretUserMedalInfoMgDbModel{
		Id:        proto.Int64(snow_flake.GetSnowflakeID()),
		UserId:    proto.Int64(userId),
		MedalId:   proto.Int64(medalId),
		Expire:    proto.Int64(expire),
		Timestamp: proto.Int64(utils.GetCurTsMs()),
	}
	if err := u.DataCache.GetImpl().UserMedalMgModel.CreateOrUpdateRecord(ctx, umItem); err != nil {
		logger.Error(ctx, "核销验证码新芽勋章失败", err)
		return err
	}

	u.DataCache.GetImpl().LocalCache.Del(fmt.Sprintf(cache_const.MedalInfoLcache.KeyFmt, userId))

	return nil
}
