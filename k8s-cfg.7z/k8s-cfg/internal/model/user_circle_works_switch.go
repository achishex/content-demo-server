package model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"context"
	"gorm.io/gorm"
	"gorm.io/plugin/dbresolver"
)

type IUserCircleWorksSwitchDbModelModel interface {
	GetByUserId(ctx context.Context, userId int64) (*pbapi.UserCircleWorksSwitchDbModel, error)
}

type UserCircleWorksSwitchDbModelImpl struct {
	DB *gorm.DB
}

func NewUserCircleWorksSwitchDbModelImpl(db *gorm.DB) IUserCircleWorksSwitchDbModelModel {
	return &UserCircleWorksSwitchDbModelImpl{DB: db}
}

func (impl *UserCircleWorksSwitchDbModelImpl) GetByUserId(ctx context.Context, userId int64) (*pbapi.UserCircleWorksSwitchDbModel, error) {
	model := pbapi.UserCircleWorksSwitchDbModel{}
	result := impl.DB.WithContext(ctx).Clauses(dbresolver.Write).Table("user_circle_works_switch").
		Where(&pbapi.UserCircleWorksSwitchDbModel{UserId: userId}).First(&model)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &model, errors.Wrap(result.Error)
}

//	func (impl *UserCircleWorksSwitchDbModelImpl) UpdateItem(ctx context.Context, model *pbapi.UserCircleWorksSwitchDbModel) (*pbapi.UserCircleWorksSwitchDbModel, error) {
//		modelDict := make(map[string]interface{})
//		modelByte, err := json.Marshal(model)
//		if err != nil {
//			return nil, err
//		}
//		err = json.Unmarshal(modelByte, &modelDict)
//		if err != nil {
//			return nil, err
//		}
//		result := impl.DB.WithContext(ctx).Model(&pbapi.UserCircleWorksSwitchDbModel{Id: model.Id}).Updates(modelDict)
//		return model, errors.Wrap(result.Error)
//	}
//
//	func (impl *UserCircleWorksSwitchDbModelImpl) CreateItem(ctx context.Context, model *pbapi.UserCircleWorksSwitchDbModel) (*pbapi.UserCircleWorksSwitchDbModel, error) {
//		result := impl.DB.WithContext(ctx).Debug().Create(model)
//		return model, errors.Wrap(result.Error)
//	}
//
// // offset 开始查的默认值为0
//
//	func (impl *UserCircleWorksSwitchDbModelImpl) ListItemOffset(ctx context.Context, condition map[string]interface{}, offsetId int, size int) ([]*pbapi.UserCircleWorksSwitchDbModel, error) {
//		var items []*pbapi.UserCircleWorksSwitchDbModel
//		result := impl.DB.WithContext(ctx).Limit(size).Offset(offsetId).
//			Where(condition).Order("id desc").Find(&items)
//		if errors.Is(result.Error, gorm.ErrRecordNotFound) {
//			return items, nil
//		}
//
//		return items, errors.Wrap(result.Error)
//	}
//func (impl *UserCircleWorksSwitchDbModelImpl) ListItemsByCondition(ctx context.Context,
//	condition map[string]interface{}, page uint64, size uint64) ([]*pbapi.UserCircleWorksSwitchDbModel, error) {
//	offset := (page - 1) * size
//	var items []*pbapi.UserCircleWorksSwitchDbModel
//	result := impl.DB.WithContext(ctx).Table("open_user").
//		Limit(int(size)).Offset(int(offset)).
//		Where(condition).Order("id desc").Find(&items)
//	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
//		return items, nil
//	}
//	return items, errors.Wrap(result.Error)
//}

//func (impl *UserCircleWorksSwitchDbModelImpl) CountItemsByCondition(ctx context.Context,
//	condition map[string]interface{}) (total int64, _ error) {
//	result := impl.DB.WithContext(ctx).Model(&pbapi.UserCircleWorksSwitchDbModel{}).Where(condition).Count(&total)
//	return total, errors.Wrap(result.Error)
//}
