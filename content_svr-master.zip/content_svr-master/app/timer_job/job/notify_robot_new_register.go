package job

import (
	"content_svr/config"
	"content_svr/db/dao"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"sort"
	"time"
)

/*
定时推送不同渠道的新注册用户
*/
type notifyRegisterControl struct {
	write, read *dao.ManagerDB
}

func newNotifyRegisterControl(write, read *dao.ManagerDB) *notifyRegisterControl {
	return &notifyRegisterControl{
		write: write,
		read:  read,
	}
}

func InitRegisterRobotDetail(write, read *dao.ManagerDB) {
	ctx := requestid.WithRequestID(context.Background())
	target := time.Now()
	ctrl := newNotifyRegisterControl(write, read)

	if err := ctrl.DoTaskNewUser(ctx, target); err != nil {
		logger.Error(context.Background(), "InitRegisterRobotDetail:", err)
	}

	if err := ctrl.DoTaskUserVersion(ctx, target); err != nil {
		logger.Error(context.Background(), "InitRegisterRobotDetail:", err)
	}
}

// 新用户不同渠道占比
func (r notifyRegisterControl) DoTaskNewUser(ctx context.Context, targetTime time.Time) error {
	messageColumn := make([]plain, 0)
	nowZero := utils.ZeroTime(targetTime)

	userList, err := r.read.SecretUserActivityDaily.FindAll(ctx, bson.M{
		"create_time": bson.D{
			{"$gte", nowZero.UnixMilli()},
		},
		"is_new": 1,
	})
	if err != nil {
		logger.Errorf(ctx, "InitRegisterRobotDetail,DoTaskBy30Min,err: %v", err)
		return err
	}

	{ // 实时DAU
		count, err := r.read.SecretUserActivityDaily.Count(ctx, bson.M{
			"create_time": bson.D{
				{"$gte", nowZero.UnixMilli()},
			},
		})
		if err != nil {
			logger.Errorf(ctx, "InitRegisterRobotDetail,DoTaskBy30Min,count,err: %v", err)
			return err
		}

		messageColumn = append(messageColumn, plain{
			Tag:  "text",
			Text: fmt.Sprintf("实时DAU: %v\n", count),
		})
	}

	messageColumn = append(messageColumn, plain{
		Tag:  "text",
		Text: fmt.Sprintf("实时新注册用户: %v\n", len(userList)),
	})

	dataMap := make(map[string]uint)
	for _, item := range userList {
		if _, ok := dataMap[item.Channel]; ok {
			dataMap[item.Channel] = dataMap[item.Channel] + 1
		} else {
			dataMap[item.Channel] = 1
		}
	}

	// 排序
	keys := make([]string, 0)
	for key := range dataMap {
		if len(key) > 0 {
			keys = append(keys, key)
		}
	}
	sort.Sort(sort.StringSlice(keys))

	for _, key := range keys {
		messageColumn = append(messageColumn, plain{
			Tag:  "text",
			Text: fmt.Sprintf("%v : %v\n", key, dataMap[key]),
		})
	}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = fmt.Sprintf("%s 新注册用户", targetTime.Format("2006-01-02 15:04:05"))
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, messageColumn)

	if config.ServerConfig.Env == "test" {
		RobotServerControl.SendMessage(m)
	} else {
		RobotFacaimaoControl.SendMessage(m)
	}

	return nil
}

// 用户版本占比
func (r notifyRegisterControl) DoTaskUserVersion(ctx context.Context, targetTime time.Time) error {
	messageColumn := make([]plain, 0)
	nowZero := utils.ZeroTime(targetTime)

	userList, err := r.read.SecretUserActivityDaily.FindAll(ctx, bson.M{
		"create_time": bson.D{
			{"$gte", nowZero.UnixMilli()},
		},
		"app_type": "mobile-android",
	})

	if err != nil {
		logger.Errorf(ctx, "InitRegisterRobotDetail,DoTaskUserVersion,err: %v", err)
		return err
	}

	dataMap := make(map[string]uint)
	for _, item := range userList {
		if len(item.Version) == 0 {
			item.Version = "other" // 兜底
		}

		if _, ok := dataMap[item.Version]; ok {
			dataMap[item.Version] = dataMap[item.Version] + 1
		} else {
			dataMap[item.Version] = 1
		}
	}

	// 排序
	keys := make([]string, 0)
	for key := range dataMap {
		if len(key) > 0 {
			keys = append(keys, key)
		}
	}
	sort.Sort(sort.Reverse(sort.StringSlice(keys))) //降序排序

	for _, key := range keys {
		messageColumn = append(messageColumn, plain{
			Tag:  "text",
			Text: fmt.Sprintf("%v : %v\n", key, dataMap[key]),
		})
	}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = fmt.Sprintf("Android版本分布(实时)")
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, messageColumn)

	if config.ServerConfig.Env == "test" {
		RobotServerControl.SendMessage(m)
	} else {
		RobotBossControl.SendMessage(m)
	}

	return nil
}
