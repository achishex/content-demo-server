package main

import "testing"

func TestChangeToDoubleHump(t *testing.T) {
	t.Log(ChangeToDoubleHump("xi_set_order"))
	t.Log(ChangeToDoubleHump("secretMemberDetail"))
}

func TestChangeToUnderline(t *testing.T) {
	t.Log(ChangeToUnderline("PersonalBottleWorks"))
	t.Log(ChangeToUnderline("UserInfo"))
}
