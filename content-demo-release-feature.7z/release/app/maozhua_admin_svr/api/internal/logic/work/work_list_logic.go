package work

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/app/maozhua_admin_svr/common/util"
	"content_svr/app/maozhua_admin_svr/common/util_user"
	"content_svr/db/mysqldb/model"
	"context"
	"github.com/zeromicro/go-zero/core/logx"
)

type WorkListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

// 0-默认(id倒序)  1-评论量倒序 2-浏览量倒序
const (
	idSort = iota
	commentCountSort
	visitorCountSort
)

func NewWorkListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *WorkListLogic {
	return &WorkListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *WorkListLogic) WorkList(req *types.WorkListRes) (resp *types.WorkListResp, err error) {
	query := &types.DbQueryList{
		Page:  req.Page,
		Size:  req.Size,
		Order: types.Desc,
		Where: map[string]interface{}{
			"create_time_begin": req.CreateTimeBegin,
			"create_time_end":   req.CreateTimeEnd,
			"work_ids":          util.StringToInt64Slice(req.WorkIds),
			"user_ids":          util.StringToInt64Slice(req.UserIds),
		},
	}
	switch req.Sort {
	case idSort:
		query.OrderKey = "id"
	case commentCountSort:
		query.OrderKey = "new_comment_count"
	case visitorCountSort:
		query.OrderKey = "visitor_count"
	}

	workInfoList, total, err := l.svcCtx.ManagerDB.PersonalBottleWork.FindPage(l.ctx, query)
	if err != nil {
		return nil, err
	}
	userIds := make([]int64, 0)
	workIds := make([]int64, 0)
	for _, work := range workInfoList {
		userIds = append(userIds, work.UserID)
		workIds = append(workIds, work.ID)
	}
	userIds = util.DuplicateByInt64(userIds)
	workIds = util.DuplicateByInt64(workIds)

	userInfos, err := l.svcCtx.ManagerDB.UserInfo.FindByUserIds(l.ctx, userIds)
	if err != nil {
		return nil, err
	}
	userInfoMap := map[int64]*model.UserInfo{}
	for _, info := range userInfos {
		if info == nil {
			continue
		}
		userInfoMap[info.UserID] = info
	}

	_dbWorkObjectAttr := l.svcCtx.ManagerDB.WorkObjectAttr
	workAttr, err := _dbWorkObjectAttr.WithContext(l.ctx).Where(_dbWorkObjectAttr.WorkID.In(workIds...)).Find()
	if err != nil {
		return nil, err
	}
	attrMap := map[int64]*model.WorkObjectAttr{}
	for _, attr := range workAttr {
		if attr == nil {
			continue
		}
		attrMap[attr.WorkID] = attr
	}

	wl := make([]types.WorkItem, 0)
	for _, work := range workInfoList {
		userInfo := userInfoMap[work.UserID]
		if userInfo == nil {
			continue
		}

		attrInfo := attrMap[work.ID]
		var workImageUrl string
		if attrInfo != nil {
			workImageUrl = util_user.FixImageUrl(l.svcCtx.Config.ImageHost, attrInfo.ObjectID)
		}

		item := types.WorkItem{
			ID:                  work.ID,
			UserId:              work.UserID,
			Gender:              userInfo.Gender,
			AppType:             work.AppType,
			Type:                work.Type,
			Title:               work.Title,
			WorkObjAttrUrl:      workImageUrl,
			VerifyStatus:        work.VerifyStatus,
			VerifyTime:          work.VerifyTime,
			PersonalLetterCount: work.CommentCount,
			CommentCount:        work.NewCommentCount,
			VisitorCount:        work.VisitorCount,
			Status:              work.Status,
			CreateTime:          work.CreateTime,
			VerifyUser:          work.VerifyUser,
			Arrested:            work.Arrested,
			Ip:                  work.IP,
			ReplayCount:         work.ReplayCount,
			ReportTimes:         work.ReportTimes,
			NewCommentCount:     work.NewCommentCount,
			ShowScope:           work.ShowScope,
		}

		wl = append(wl, item)
	}

	resp = &types.WorkListResp{
		WorkList: wl,
		Total:    total,
	}

	return resp, nil
}
