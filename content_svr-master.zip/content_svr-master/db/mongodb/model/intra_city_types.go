package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

const collectionNameIntraCity = "intraCity"

type IntraCity struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	GroupId         string `json:"group_id" bson:"group_id"`                   //群id
	UserId          int64  `json:"user_id" bson:"user_id"`                     //用户id
	Province        string `json:"province" json:"province"`                   //省
	ProvinceCode    string `json:"province_code" bson:"province_code"`         //省码
	City            string `json:"city" bson:"city"`                           //城市
	CityCode        string `json:"city_code" bson:"city_code"`                 //城市码
	IsOpenFirepower bool   `json:"is_open_firepower" bson:"is_open_firepower"` //是否激活火力值
	Firepower       uint32 `json:"firepower" bson:"firepower"`                 //火力值
	IsOpen          bool   `json:"is_open" bson:"is_open"`                     //是否公开群

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` //创建时间
	UpdateTime int64 `json:"update_time,omitempty" bson:"update_time,omitempty"` //更新时间
}
