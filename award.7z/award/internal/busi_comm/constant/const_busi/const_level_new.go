package const_busi

import (
	"content_svr/setting"
	"fmt"
	"github.com/jinzhu/copier"
	"strings"
)

// 所有用户级别
const (
	UserLevel0 int32 = iota
	UserLevel1
	UserLevel2
	UserLevel3
	UserLevel4
	UserLevel5
	UserLevelSpeedCode
)

// UserMaxLevel 用户级别最大值, 新增级别时候修改其为最大值
const UserMaxLevel = UserLevelSpeedCode

type ULevelInfo struct {
	Level                  int32
	Title                  string
	NoVipVisitCountLimit   int32    // 普通用户-每个帖子的曝光上限度
	VipVisitCountLimit     int32    // vip-每个帖子的曝光上限度
	DailyTalkLimit         int32    // 每天可以回复的用户私聊数限制
	CommentSingleLimit     int64    // 单条动态评论数
	CommentMaxLimit        int64    // 总评论数
	FullSignTimes          int32    //当前级别需要签到数量
	FullPenaltiesSignTimes int32    //违规用户当前级别需要签到数量
	DailyTalkNewObjNums    int32    //单日私聊新猫友的上限数
	LevelUpDesc            string   // 升级后的文案。显示在等级卡片上，展示下一级权益。  废弃
	LevelUpDescArr         []string // 升级后弹窗文案.

	BackgroundColor string // 背景色
	Color           string // 字体色
	TaskMessage     string
}

var (
	userLeveTitleDict = map[int32]*ULevelInfo{
		0: {
			Level:                  0,
			Title:                  "小猫崽",
			NoVipVisitCountLimit:   0,
			VipVisitCountLimit:     0,
			DailyTalkLimit:         2,
			CommentSingleLimit:     0,
			CommentMaxLimit:        0,
			FullSignTimes:          0,
			FullPenaltiesSignTimes: 0,
			DailyTalkNewObjNums:    2,
			LevelUpDesc:            "",
			LevelUpDescArr:         make([]string, 0),
			BackgroundColor:        "linear-gradient(308deg, #E1EBFD 0%, #C4D7EC 100% )",
			Color:                  "#495A6B",
		},
		1: {
			Level:                  1,
			Title:                  "小奶猫",
			NoVipVisitCountLimit:   20,
			VipVisitCountLimit:     20,
			DailyTalkLimit:         10,
			CommentSingleLimit:     4,
			CommentMaxLimit:        100,
			FullSignTimes:          3,
			FullPenaltiesSignTimes: 10,
			DailyTalkNewObjNums:    10,
			LevelUpDesc:            "",
			LevelUpDescArr:         make([]string, 0),
			BackgroundColor:        "linear-gradient(316deg, #DFF5FF 0%, #ADE5FE 100%)",
			Color:                  "#406272",
		},
		2: {
			Level:                  2,
			Title:                  "初级猫",
			NoVipVisitCountLimit:   299,
			VipVisitCountLimit:     399,
			DailyTalkLimit:         20,
			CommentSingleLimit:     8,
			CommentMaxLimit:        400,
			FullSignTimes:          3,
			FullPenaltiesSignTimes: 4,
			DailyTalkNewObjNums:    20,
			LevelUpDesc:            "",
			LevelUpDescArr:         make([]string, 0),
			BackgroundColor:        "linear-gradient(134deg, #FFD057 0%,  #FEE9AC 100%)",
			Color:                  "#5A4510",
		},
		3: {
			Level:                  3,
			Title:                  "中级猫",
			NoVipVisitCountLimit:   399,
			VipVisitCountLimit:     599,
			DailyTalkLimit:         30,
			CommentSingleLimit:     12,
			CommentMaxLimit:        600,
			FullSignTimes:          2,
			FullPenaltiesSignTimes: 4,
			DailyTalkNewObjNums:    30,
			LevelUpDesc:            "",
			LevelUpDescArr:         make([]string, 0),
			BackgroundColor:        "linear-gradient(135deg,  #FFC29E 0%, #FEE0C5 100%)",
			Color:                  "#4E3627",
		},
		4: {
			Level:                  4,
			Title:                  "高级猫",
			NoVipVisitCountLimit:   599,
			VipVisitCountLimit:     999,
			DailyTalkLimit:         40,
			CommentSingleLimit:     16,
			CommentMaxLimit:        1000,
			FullSignTimes:          2,
			FullPenaltiesSignTimes: 4,
			DailyTalkNewObjNums:    40,
			LevelUpDesc:            "",
			LevelUpDescArr:         make([]string, 0),
			BackgroundColor:        "linear-gradient(134deg, #1C203B  0%, #414996 100%)",
			Color:                  "#CDD2FF",
		},
		5: {
			Level:                  5,
			Title:                  "大师猫",
			NoVipVisitCountLimit:   599,
			VipVisitCountLimit:     999,
			DailyTalkLimit:         40,
			CommentSingleLimit:     16,
			CommentMaxLimit:        1000,
			FullSignTimes:          0,
			FullPenaltiesSignTimes: 4,
			DailyTalkNewObjNums:    40,
			LevelUpDesc:            "",
			LevelUpDescArr:         make([]string, 0),
			BackgroundColor:        "linear-gradient(315deg, #1F1B1C 0%, #65645F 100%)",
			Color:                  "#F1EBC1",
		},
		6: {
			Level:                  5,
			Title:                  "加速码",
			NoVipVisitCountLimit:   599,
			VipVisitCountLimit:     999,
			DailyTalkLimit:         40,
			CommentSingleLimit:     16,
			CommentMaxLimit:        1000,
			FullSignTimes:          4,
			FullPenaltiesSignTimes: 4,
			DailyTalkNewObjNums:    40,
			LevelUpDesc:            "",
			LevelUpDescArr:         make([]string, 0),
			BackgroundColor:        "linear-gradient(315deg, #1F1B1C 0%, #65645F 100%)",
			Color:                  "#F1EBC1",
		},
	}
)

var (
	messageTalk = "每日仅可私聊%d新猫友"

	messageReply   = "可分享动态，最高曝光%d"
	messageComment = "同一动态下可发%d条评论，每日上限%d条"

	messageHead = "可上传头像及分享动态"

	messageTalkEmoji = "私聊可发送自定义表情"
	messageCode      = "开启加速码生成系统"

	messageTaskSign     = "完成%d次签到"
	messageTaskSheniu   = "点亮“社牛勋章"
	messageTaskRealName = "完成实名认证"

	messageLevel5 = []string{
		"在Lv.4的权益上，解锁更多玩法～！",
		"最多可创建%d个群聊",
		"可签到获得加速码",
		"支持设置资料主页背景",
		"动态评论可发送表情",
		"分享动态可选择相册图片/表情",
		"猫友聊天可发送相册图片",
		"群聊中可发语音/相册图片/表情",
	}
)

func GetUserLevelUp(penalties bool) map[int32]*ULevelInfo {
	levels := map[int32]*ULevelInfo{}
	_ = copier.Copy(&levels, userLeveTitleDict)
	for _, info := range levels {
		info.BuildTaskMessage(penalties)
		info.BuildConfByAdminConf()
		info.BuildLevelUpDescArr()
	}

	return levels
}

func GetLevelCfg(level int32) *ULevelInfo {
	item := userLeveTitleDict[level]
	if item == nil {
		return nil
	}
	newItem := *item
	newItem.BuildConfByAdminConf()
	newItem.BuildLevelUpDescArr()

	if len(newItem.LevelUpDescArr) > 0 {
		newItem.LevelUpDesc = fmt.Sprintf("%v将拥有权益:%v。", newItem.Title, strings.Join(newItem.LevelUpDescArr, ","))
	}

	return &newItem
}

func (u *ULevelInfo) BuildLevelUpDescArr() {
	switch u.Level {
	case UserLevel0:
		u.addLevelUpMessage(fmt.Sprintf(messageTalk, u.DailyTalkLimit))
	case UserLevel1:
		u.addLevelUpMessage(fmt.Sprintf(messageReply, u.NoVipVisitCountLimit))
		u.addLevelUpMessage(fmt.Sprintf(messageTalk, u.DailyTalkLimit))
		u.addLevelUpMessage(fmt.Sprintf(messageComment, u.CommentSingleLimit, u.CommentMaxLimit))
	case UserLevel2:
		u.addLevelUpMessage(messageHead)
		//u.addLevelUpMessage(fmt.Sprintf(messageVipReply, u.NoVipVisitCountLimit))
		u.addLevelUpMessage(fmt.Sprintf(messageTalk, u.DailyTalkLimit))
		u.addLevelUpMessage(fmt.Sprintf(messageComment, u.CommentSingleLimit, u.CommentMaxLimit))
	case UserLevel3, UserLevel4:
		u.addLevelUpMessage(messageHead)
		u.addLevelUpMessage(messageTalkEmoji)
		//u.addLevelUpMessage(messageCode)
		//u.addLevelUpMessage(fmt.Sprintf(messageVipReply, u.NoVipVisitCountLimit))
		u.addLevelUpMessage(fmt.Sprintf(messageTalk, u.DailyTalkLimit))
		u.addLevelUpMessage(fmt.Sprintf(messageComment, u.CommentSingleLimit, u.CommentMaxLimit))
	case UserLevel5, UserLevelSpeedCode:
		messageLevel5[1] = fmt.Sprintf("最多可创建%d个群聊", setting.Maozhua.ImGroup.MaxGroupLimit.Get())
		u.LevelUpDescArr = messageLevel5
	}
}

// 根据管理后台配置刷新配置
func (u *ULevelInfo) BuildConfByAdminConf() {
	switch u.Level {
	case UserLevel0:
		u.VipVisitCountLimit = setting.Maozhua.VipLevel0Exposure.Get()
		u.NoVipVisitCountLimit = setting.Maozhua.Level0Exposure.Get()
		u.CommentSingleLimit = setting.Maozhua.Level0SingleCommentMax.Get()
		u.CommentMaxLimit = setting.Maozhua.Level0CommentMax.Get()
		u.DailyTalkNewObjNums = setting.Maozhua.Level0TalkNewPeopleMaxCount.Get()
	case UserLevel1:
		u.VipVisitCountLimit = setting.Maozhua.VipLevel1Exposure.Get()
		u.NoVipVisitCountLimit = setting.Maozhua.Level1Exposure.Get()
		u.CommentSingleLimit = setting.Maozhua.Level1SingleCommentMax.Get()
		u.CommentMaxLimit = setting.Maozhua.Level1CommentMax.Get()
		u.DailyTalkNewObjNums = setting.Maozhua.Level1TalkNewPeopleMaxCount.Get()
	case UserLevel2:
		u.VipVisitCountLimit = setting.Maozhua.VipLevel2Exposure.Get()
		u.NoVipVisitCountLimit = setting.Maozhua.Level2Exposure.Get()
		u.CommentSingleLimit = setting.Maozhua.Level2SingleCommentMax.Get()
		u.CommentMaxLimit = setting.Maozhua.Level2CommentMax.Get()
		u.DailyTalkNewObjNums = setting.Maozhua.Level2TalkNewPeopleMaxCount.Get()
	case UserLevel3:
		u.VipVisitCountLimit = setting.Maozhua.VipLevel3Exposure.Get()
		u.NoVipVisitCountLimit = setting.Maozhua.Level3Exposure.Get()
		u.CommentSingleLimit = setting.Maozhua.Level3SingleCommentMax.Get()
		u.CommentMaxLimit = setting.Maozhua.Level3CommentMax.Get()
		u.DailyTalkNewObjNums = setting.Maozhua.Level3TalkNewPeopleMaxCount.Get()
	case UserLevel4:
		u.VipVisitCountLimit = setting.Maozhua.VipLevel4Exposure.Get()
		u.NoVipVisitCountLimit = setting.Maozhua.Level4Exposure.Get()
		u.CommentSingleLimit = setting.Maozhua.Level4SingleCommentMax.Get()
		u.CommentMaxLimit = setting.Maozhua.Level4CommentMax.Get()
		u.DailyTalkNewObjNums = setting.Maozhua.Level4TalkNewPeopleMaxCount.Get()
	case UserLevel5:
		u.VipVisitCountLimit = setting.Maozhua.VipLevel5Exposure.Get()
		u.NoVipVisitCountLimit = setting.Maozhua.Level5Exposure.Get()
		u.CommentSingleLimit = setting.Maozhua.Level5SingleCommentMax.Get()
		u.CommentMaxLimit = setting.Maozhua.Level5CommentMax.Get()
		u.DailyTalkNewObjNums = setting.Maozhua.Level5TalkNewPeopleMaxCount.Get()
	}
}

func (u *ULevelInfo) addLevelUpMessage(newMessage string) {
	length := len(u.LevelUpDescArr)
	if length == 0 {
		u.LevelUpDescArr = []string{
			newMessage,
		}
		return
	}

	u.LevelUpDescArr = append(u.LevelUpDescArr, newMessage)
}

func (u *ULevelInfo) BuildTaskMessage(penalties bool) {
	if penalties {
		// 违规用户任务, 并重设其full上限值
		u.FullSignTimes = u.FullPenaltiesSignTimes

		switch u.Level {
		case UserLevel0:
		case UserLevel1:
			u.addTaskMessage(fmt.Sprintf(messageTaskSign, setting.Maozhua.DailySign.Level1FullPenaltiesSignTimes.Get()))
		case UserLevel2:
			u.addTaskMessage(fmt.Sprintf(messageTaskSign, setting.Maozhua.DailySign.Level2FullPenaltiesSignTimes.Get()))
		case UserLevel3:
			u.addTaskMessage(fmt.Sprintf(messageTaskSign, setting.Maozhua.DailySign.Level3FullPenaltiesSignTimes.Get()))
		case UserLevel4:
			u.addTaskMessage(fmt.Sprintf(messageTaskSign, setting.Maozhua.DailySign.Level4FullPenaltiesSignTimes.Get()))
		case UserLevel5, UserLevelSpeedCode:
			u.addTaskMessage(fmt.Sprintf(messageTaskSign, setting.Maozhua.DailySign.Level5FullPenaltiesSignTimes.Get()))
			u.addTaskMessage(messageTaskSheniu)
			u.addTaskMessage(messageTaskRealName)
		}
	} else {
		// 常规用户任务
		switch u.Level {
		case UserLevel0:
		case UserLevel1:
		case UserLevel2:
			u.addTaskMessage(fmt.Sprintf(messageTaskSign, setting.Maozhua.DailySign.Level2FullSignTimes.Get()))
		case UserLevel3:
			u.addTaskMessage(fmt.Sprintf(messageTaskSign, setting.Maozhua.DailySign.Level3FullSignTimes.Get()))
		case UserLevel4:
			u.addTaskMessage(fmt.Sprintf(messageTaskSign, setting.Maozhua.DailySign.Level4FullSignTimes.Get()))
		case UserLevel5, UserLevelSpeedCode:
			u.addTaskMessage(messageTaskSheniu)
			u.addTaskMessage(messageTaskRealName)
		}
	}

}

func (u *ULevelInfo) addTaskMessage(msg string) {
	if msg == "" {
		return
	}

	if u.TaskMessage == "" {
		u.TaskMessage = msg
		return
	}

	u.TaskMessage += " + " + msg
}

// 加速码状态
const (
	SpeedCodeStatusNo   int32 = iota //不可领取
	SpeedCodeStatusYes               //可领取
	SpeedCodeStatusDraw              //已领取
)

// 一个加速码兑换签到次数
const (
	SpeedCodeExchangeSignTimesForNormal    int32 = 4 //正常用户
	SpeedCodeExchangeSignTimesForPenalties int32 = 1 //违规用户
)
