package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/busi_comm/user_info_const"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/user"
	"context"
	"fmt"
	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common"
	"github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/common/profile"
	faceid "github.com/tencentcloud/tencentcloud-sdk-go/tencentcloud/faceid/v20180301"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"time"
)

func (p *ContentMng) RealNameAuthentication(ctx context.Context, header *pbapi.HttpHeaderInfo, cardId, cardName string) (identity int32, err error) {
	loginUser, err := p.getUserInfo(ctx, header)
	if err != nil {
		return const_busi.IdentityUnknown, err
	}

	if !p.checkExistIdentificationCard(ctx, cardId) {
		logger.Info(ctx, fmt.Sprintf("%s: cardId: %s, cardName: %s", errorcode.UserLevelNotEnough.UserMsg, cardId, cardName))
		return const_busi.IdentityUnknown, errorcode.ExistCardError
	}

	if config.ServerConfig.Env == "prod" {
		// 腾讯验证
		ok, err := p.checkIdentificationCardByTencent(ctx, cardId, cardName)
		if err != nil {
			logger.Error(ctx, "腾讯身份证验证服务超时", err)
			return const_busi.IdentityUnknown, errorcode.TencentSdkError
		}
		if !ok {
			// 验证没通过
			logger.Info(ctx, fmt.Sprintf("%s: cardId: %s, cardName: %s", errorcode.CardError.UserMsg, cardId, cardName))
			return const_busi.IdentityUnknown, errorcode.CardError
		}
	}

	if identity, err = p.UpdateUserInfoRecord(ctx, loginUser, cardId, cardName); err != nil {
		logger.Error(ctx, "UpdateUserInfoRecord", err)
		return const_busi.IdentityUnknown, errorcode.TencentSdkError
	}

	return identity, nil
}

func (p *ContentMng) checkExistIdentificationCard(ctx context.Context, cardId string) bool {
	filter := bson.D{
		{"status", const_busi.UserCardStatus},
		{"card_id", cardId},
		//{"card_name", cardName},
	}
	record, err := p.DataCache.GetImpl().SecretUserIdentificationCardMgModel.FindOne(ctx, filter)
	switch {
	case err == mongo.ErrNoDocuments:
		return true
	case err == nil:
		// 注销用户时候，在java端，因此这里暂作处理
		info, err := p.DataCache.GetImpl().UserInfoModel.GetByUserId(ctx, record.UserId)
		if err != nil {
			logger.Error(ctx, "用户不存在", err)
			return false
		}
		if info.GetStatus() == 0 {
			filter := map[string]interface{}{
				"user_id": record.UserId,
			}
			data := map[string]interface{}{
				"status": const_busi.UserCardSignOutStatus,
			}
			_, err := p.DataCache.GetImpl().SecretUserIdentificationCardMgModel.UpdateMap(ctx, filter, data)
			if err != nil {
				logger.Error(ctx, "更新用户注销状态失败, 可能是因为不存在该条记录", err)
				return true
			}
			return true
		}

		return false
	default:
		logger.Error(ctx, "SecretUserIdentificationCard.FindOne", err)
		return false
	}

}

func (p *ContentMng) checkIdentificationCardByTencent(ctx context.Context, cardId, cardName string) (bool, error) {
	// 实例化一个认证对象，入参需要传入腾讯云账户 SecretId 和 SecretKey，此处还需注意密钥对的保密
	// 代码泄露可能会导致 SecretId 和 SecretKey 泄露，并威胁账号下所有资源的安全性。以下代码示例仅供参考，建议采用更安全的方式来使用密钥，请参见：https://cloud.tencent.com/document/product/1278/85305
	// 密钥可前往官网控制台 https://console.cloud.tencent.com/cam/capi 进行获取
	credential := common.NewCredential(
		config.ServerConfig.RealNameAuthentication.SecretId,
		config.ServerConfig.RealNameAuthentication.SecretKey,
	)
	// 实例化一个client选项，可选的，没有特殊需求可以跳过
	cpf := profile.NewClientProfile()
	cpf.HttpProfile.Endpoint = "faceid.tencentcloudapi.com"
	// 实例化要请求产品的client对象,clientProfile是可选的
	client, _ := faceid.NewClient(credential, "", cpf)

	// 实例化一个请求对象,每个接口都会对应一个request对象
	request := faceid.NewIdCardVerificationRequest()

	request.IdCard = common.StringPtr(cardId)
	request.Name = common.StringPtr(cardName)

	// 返回的resp是一个IdCardVerificationResponse的实例，与请求对象对应
	response, err := client.IdCardVerification(request)
	//if _, ok := err.(*errors.TencentCloudSDKError); ok {
	//	return err
	//}
	if err != nil {
		return false, err
	}
	// 输出json格式的字符串回包
	logger.Infof(ctx, "tencent IdCardVerification", response.ToJsonString())
	if response == nil || response.Response == nil || *response.Response.Result != "0" {
		return false, nil
	}
	return true, nil
}

func (p *ContentMng) UpdateUserInfoRecord(ctx context.Context, loginUser *data_cache.UserInfoLocal, cardId, cardName string) (identity int32, err error) {
	sexNumStr := cardId[16] // 第17位
	var gender int32
	if sexNumStr%2 == 1 {
		gender = user_info_const.GenderBoy
	} else {
		gender = user_info_const.GenderGirl
	}

	dateNumStr := cardId[6:14] // 第7到13位
	t, err := time.Parse("20060102", dateNumStr)
	if err != nil {
		return const_busi.IdentityUnknown, err
	}
	birth := t.Format("2006-01-02")
	isAdult, _ := user.JudgeAdult(birth)
	if isAdult {
		identity = const_busi.IdentityAdult
	} else {
		identity = const_busi.IdentityUnderage
		// 若以成年人身份打开了扩列模式，那么实名为未成年时候关闭
		if loginUser.PsecretUserExtInfo.GetTalkMode() == const_busi.TalkModeOpen {
			update := map[string]interface{}{
				"talkMode": const_busi.TalkModeClose,
			}
			err = p.DataCache.GetImpl().SetUserInfoTalkMode(ctx, loginUser.UserInfoDbModel.GetUserId(), const_busi.TalkModeClose)
			if err != nil {
				logger.Error(ctx, "change redis talkMode error", err)
			}
			err = p.DataCache.GetImpl().UserInfoExtMgModel.UpdateDictById(ctx, loginUser.UserInfoDbModel.GetUserId(), update, nil)
			if err != nil {
				logger.Error(ctx, "change talkMode error", err)
			}
		}
	}

	err = p.DataCache.GetImpl().UserInfoModel.UpdateById(
		ctx, loginUser.UserInfoDbModel.GetUserId(), &pbapi.UserinfoDbModel{
			Gender: &gender,
			Birth:  &birth,
		})
	if err != nil {
		return const_busi.IdentityUnknown, err
	}
	filter := bson.D{
		{"user_id", loginUser.UserInfoDbModel.GetUserId()},
	}
	IdCardRecord, err := p.DataCache.GetImpl().SecretUserIdentificationCardMgModel.FindOne(ctx, filter)
	switch {
	case err == mongo.ErrNoDocuments:
		IdCardRecord = &pbmgdb.SecretUserIdentificationCard{
			UserId:   loginUser.UserInfoDbModel.GetUserId(),
			CardId:   cardId,
			CardName: cardName,
			Status:   const_busi.UserCardStatus,
		}
		if err := p.DataCache.GetImpl().SecretUserIdentificationCardMgModel.Create(ctx, IdCardRecord); err != nil {
			return const_busi.IdentityUnknown, err
		}
		return identity, nil
	case err == nil:
		IdCardRecord.CardId = cardId
		IdCardRecord.CardName = cardName
		IdCardRecord.Status = const_busi.UserCardStatus
		if _, err := p.DataCache.GetImpl().SecretUserIdentificationCardMgModel.UpdateByUserId(ctx, IdCardRecord); err != nil {
			return const_busi.IdentityUnknown, err
		}
		return identity, nil
	default:
		return identity, err
	}

}

func (p *ContentMng) CheckIdentificationCard(ctx context.Context, loginUserId int64) (identity int32, exist bool, err error) {
	loginUser, err := p.GetUserInfo(ctx, loginUserId)
	if err != nil {
		return const_busi.IdentityUnknown, false, errorcode.MIDAS_LOGIN_ERROR
	}

	_, err = p.DataCache.GetImpl().SecretUserIdentificationCardMgModel.FindOne(ctx, bson.D{
		{Key: "user_id", Value: loginUser.UserInfoDbModel.GetUserId()},
		{Key: "status", Value: const_busi.UserCardStatus},
	})
	switch err {
	case nil:
		exist = true
	default:
		exist = false
	}

	birth := loginUser.UserInfoDbModel.GetBirth()
	if len(birth) == 0 {
		// 生日没填，默认为成年人
		return const_busi.IdentityAdult, exist, nil
	}
	adult, err := user.JudgeAdult(birth)
	if err != nil {
		logger.Error(ctx, "judgeAdult error", err)
	}
	if adult {
		return const_busi.IdentityAdult, exist, nil
	} else {
		return const_busi.IdentityUnderage, exist, nil
	}

}
