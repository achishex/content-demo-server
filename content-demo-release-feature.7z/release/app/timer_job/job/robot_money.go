package job

import (
	"content_svr/db/dao"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"context"
	"fmt"
	"time"
)

type robotMoneyControl struct {
	TickerExecute
	robotControl

	write, read *dao.ManagerDB
}

func InitMoneyRobot(write, read *dao.ManagerDB) {
	robotMoneyControl := robotMoneyControl{}
	//robotMoneyControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/c02670dc-de16-4af0-a234-d90af25c6f13" // server群，测试用
	robotMoneyControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/afd15198-34ea-4788-a306-2e94630458de" // 正式群，不要乱推数据
	robotMoneyControl.msgChan = make(chan Message, 10)
	robotMoneyControl.hour = 8
	robotMoneyControl.write = write
	robotMoneyControl.read = read

	go robotMoneyControl.monitor()
	go func() {
		//ctx := requestid.WithRequestID(context.Background())
		//robotMoneyControl.DoTask(ctx, time.Now().AddDate(0, 0, -1))
		robotMoneyControl.Do(func() {
			ctx := requestid.WithRequestID(context.Background())
			if err := robotMoneyControl.DoTask(ctx, time.Now().AddDate(0, 0, -1)); err != nil {
				logger.Errorf(ctx, "robotMoneyControl.DoTask: %v", err)
				// 五分钟后重试
				robotMoneyControl.ticker.Reset(time.Minute * 5)
				return
			}

			robotMoneyControl.ticker.Reset(robotMoneyControl.calcIntervalTime())
		})

	}()
}

func (r robotMoneyControl) DoTask(ctx context.Context, targetTime time.Time) error {
	filter := map[string]interface{}{
		"day": r.baseZeroTime(targetTime).UnixMilli(),
	}

	data, err := r.read.SuperiorAwardDaily.FindOne(ctx, filter)
	if err != nil {
		return err
	}

	member, err := r.read.UserMemberStatistical.FindOne(ctx, filter)
	if err != nil {
		return err
	}

	AwardSettlementSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天结算奖励总和: %.2f\n", float64(data.AwardSettlementSum)/100),
	}
	DeductionIllegalSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天违规扣除总和: %.2f\n", float64(data.DeductionIllegalSum)/100),
	}
	FirstWorkSettlementSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天首条动态奖励总和: %.2f\n", float64(data.FirstWorkSettlementSum)/100),
	}
	WechatPayWithdrawSuccessSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天微信提现成功总和: %.2f\n", float64(data.WechatPayWithdrawSuccessSum)/100),
	}
	WechatPayWithdrawFailSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天微信提现失败总和: %.2f\n", float64(data.WechatPayWithdrawFailSum)/100),
	}
	HallOfFameAwardSettlementSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天排行榜奖励总和: %.2f\n", float64(data.HallOfFameAwardSettlementSum)/100),
	}
	MemberSumMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("当天充值总和: %.2f\n", float64(member.PriceSum)/100),
	}
	items := []item{
		AwardSettlementSumMessage,
		DeductionIllegalSumMessage,
		FirstWorkSettlementSumMessage,
		WechatPayWithdrawSuccessSumMessage,
		WechatPayWithdrawFailSumMessage,
		HallOfFameAwardSettlementSumMessage,
		MemberSumMessage,
	}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = fmt.Sprintf("%d 各类结算统计", r.baseTimeByDay(targetTime))
	m.Content.Post.ZhCn.Content = make([][]item, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	r.SendMessage(m)

	// 统计完成后当天早上8点再发通知
	//now := time.Now()
	//target := time.Date(now.Year(), now.Month(), now.Day(), 8, 0, 0, 0, now.Location())
	//r.SendMessageAfterTime(m, target.Sub(now))

	return nil
}
