package originManage

//type ContentSvr struct {
//	KafkaProxy kafka_proxy.IKafkaProxy
//	BdLbsProxy baidu_lbs_yun_proxy.IBaiduLbsYunProxy
//	InnerProxy inner_mng.IInnerProxy
//
//	DataCache  data_cache.IDataCacheMng
//	UserLevMng user_level_mng.IUserLevelMng
//}
//
//func NewContentSvr(mysqlClient *gorm.DB, mongoClient *mongo.Client, redisClient *redis.Client) *ContentSvr {
//	// 初始化
//	kafkaProxy := kafka_proxy.NewKafkaProxyImpl(config.ServerConfig.KafkaConfig)
//	bdLbsProxy := baidu_lbs_yun_proxy.NewBaiduLbsYunProxyImpl()
//	localCache := go_cache.NewMemCache()
//	innerProxy := inner_mng.NewInnerProxyImpl(redisClient)
//
//	// 初始化 绑定的方法
//	dataCache := app_comm.BuildDataCache(mysqlClient, nil, mongoClient, redisClient, bdLbsProxy, localCache)
//	userLevMng := user_level_mng.NewUserLevelMng(dataCache)
//
//	return &ContentSvr{
//		KafkaProxy: kafkaProxy,
//		BdLbsProxy: bdLbsProxy,
//		InnerProxy: innerProxy,
//
//		DataCache:  dataCache,
//		UserLevMng: userLevMng,
//	}
//}
