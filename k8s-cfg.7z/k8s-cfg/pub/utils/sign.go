package utils

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"net/url"
	"sort"
	"strings"
)

// 接口签名
func GenApiSign(params map[string]any, appSecret string) (string, string) {
	var keys, kv []string

	for key := range params {
		if key == "sign" {
			continue
		}
		keys = append(keys, key)
	}

	sort.Strings(keys)

	for _, key := range keys {
		if params[key] == "" {
			continue
		}
		k := url.QueryEscape(key)
		v := url.QueryEscape(fmt.Sprintf("%v", params[key]))
		kv = append(kv, fmt.Sprintf("%s=%v", k, v))
	}

	encodeStr := strings.Join(kv, "&")
	hmacHash := hmac.New(sha256.New, []byte(appSecret))
	hmacHash.Write([]byte(encodeStr))
	return hex.EncodeToString(hmacHash.Sum(nil)), encodeStr
}
