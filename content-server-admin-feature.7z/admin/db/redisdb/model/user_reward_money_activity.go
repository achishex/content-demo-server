package model

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/redisdb/model/internal"
	"context"
	"encoding/json"
	"fmt"
	redisV8 "github.com/go-redis/redis/v8"
	"time"
)

type UserRewardMoneyActivityRedis struct {
	UserRewardMoneyActivityRedisData
	UserRewardMoneyActivityRedisNx
}

func NewUserRewardMoneyActivityRedis(rds *redisV8.Client, env string) *UserRewardMoneyActivityRedis {
	return &UserRewardMoneyActivityRedis{
		UserRewardMoneyActivityRedisData{
			internal.RdsInfo{
				Env:    env,
				Expire: time.Hour * 24,
				Client: rds,
				RdsKey: "platform:%v:award:money_plan:%v:%v:%v",
			},
		},
		UserRewardMoneyActivityRedisNx{
			RdsInfo: internal.RdsInfo{
				Env:    env,
				Expire: 0,
				RdsKey: "platform:%v:award:money_plan:nx:%v:%v",
				//Expire: time.Hour * 24,
				Client: rds,
			},
			NxTimeout: 10, // 秒
		},
	}
}

func (u *UserRewardMoneyActivityRedis) Get(ctx context.Context, day, userId, modelType any) (*model.UserRewardMoneyActivity, error) {
	result, err := u.UserRewardMoneyActivityRedisData.Get(ctx, day, userId, modelType)
	if err != nil {
		return nil, err
	}

	data := model.UserRewardMoneyActivity{}
	if err := json.Unmarshal(result, &data); err != nil {
		return nil, err
	}
	//fmt.Println(result)

	return &data, nil
}

func (u *UserRewardMoneyActivityRedis) Set(ctx context.Context, day, userId, modelType, value any) error {
	b, _ := json.Marshal(value)
	if err := u.UserRewardMoneyActivityRedisData.Set(ctx, day, userId, modelType, string(b)); err != nil {
		return err
	}

	return nil
}

type UserRewardMoneyActivityRedisData struct {
	internal.RdsInfo
}

func (u *UserRewardMoneyActivityRedisData) getKey(day, userId, modelType any) string {
	return fmt.Sprintf(u.RdsKey, u.Env, day, userId, modelType)
}

func (u *UserRewardMoneyActivityRedisData) Get(ctx context.Context, day, userId, modelType any) ([]byte, error) {
	fmt.Println(u.getKey(day, userId, modelType))
	return u.Client.Get(ctx, u.getKey(day, userId, modelType)).Bytes()
}

func (u *UserRewardMoneyActivityRedisData) Set(ctx context.Context, day, userId, modelType, value any) error {
	return u.Client.Set(ctx, u.getKey(day, userId, modelType), value, u.Expire).Err()
}

type UserRewardMoneyActivityRedisNx struct {
	internal.RdsInfo
	NxTimeout int
}

func (u *UserRewardMoneyActivityRedisNx) getKey(day, userId any) string {
	return fmt.Sprintf(u.RdsKey, u.Env, day, userId)
}

func (u *UserRewardMoneyActivityRedisNx) GetLock(ctx context.Context, day, userId int64) (*internal.RedisLock, error) {
	lock := internal.NewRedisLock(u.Client, u.getKey(day, userId))
	lock.SetExpire(u.NxTimeout)

	for {
		// 尝试获取锁
		acquire, err := lock.AcquireCtx(ctx)
		switch {
		case err != nil:
			return nil, err
		case acquire:
			return lock, err
		case !acquire:
			time.Sleep(time.Second)
		}
	}

}

func (u *UserRewardMoneyActivityRedisNx) UnLock(ctx context.Context, local *internal.RedisLock) (bool, error) {
	return local.ReleaseCtx(ctx)
}
