package mg_model

import (
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type IPersonalUserAccountMgDbModel interface {
	UpdateItem(ctx context.Context, eqConds map[string]interface{}, update interface{}) error
	GetItems(ctx context.Context, eqConds map[string]interface{}) ([]*pbmgdb.PersonalUserAccountMgDbModel, error)
	InsertItem(ctx context.Context, data *pbmgdb.PersonalUserAccountMgDbModel) error
	FindItems(ctx context.Context, eqConds map[string]interface{}) (error, bool)
}
type PersonalUserAccountMgDbModelImpl struct {
	MgDB *mongo.Database
}

func NewPersonalUserAccountMgModelImpl(db *mongo.Database) IPersonalUserAccountMgDbModel {
	return &PersonalUserAccountMgDbModelImpl{
		MgDB: db,
	}
}

func (p *PersonalUserAccountMgDbModelImpl) collection() string {
	return "personalUserAccount"
}

func (p *PersonalUserAccountMgDbModelImpl) InsertItem(ctx context.Context, data *pbmgdb.PersonalUserAccountMgDbModel) error {
	if data == nil {
		return nil
	}
	ret, err := p.MgDB.Collection(p.collection()).InsertOne(ctx, data)
	if err != nil {
		logger.Errorf(ctx, "insert data fail, %v,err: %v", *data, err)
		return err
	}
	logger.Infof(ctx, "insert ret: %v", ret.InsertedID)
	return nil
}
func (p *PersonalUserAccountMgDbModelImpl) FindItems(ctx context.Context, eqConds map[string]interface{}) (error, bool) {
	//
	coll := p.MgDB.Collection(p.collection())
	filter := bson.D{}

	for k, v := range eqConds {
		filter = append(filter, bson.E{Key: k, Value: v})
	}

	cursor, err := coll.Find(ctx, filter)
	if err != nil {
		return err, false
	}
	var result []*pbmgdb.PersonalUserAccountMgDbModel
	for cursor.Next(ctx) {
		item := &pbmgdb.PersonalUserAccountMgDbModel{}
		// 解码绑定数据
		err = cursor.Decode(item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to user_sport_activity_detail failed.err=%v", err), err)
			return err, false
		}
		result = append(result, item)
	}
	if len(result) > 0 {
		return nil, true
	}
	return nil, false

}
func (p *PersonalUserAccountMgDbModelImpl) UpdateItem(ctx context.Context, eqConds map[string]interface{},
	update interface{}) error {
	coll := p.MgDB.Collection(p.collection())
	filter := bson.M{}
	for k, v := range eqConds {
		filter[k] = v
	}

	_, err := coll.UpdateOne(ctx, filter, update)
	if err != nil {
		logger.Errorf(ctx, "update tab: %v fail, err: %v", p.collection(), err)
		return err
	}
	logger.Infof(ctx, "begin to update fish nums: %v", update)
	return nil
}
func (p *PersonalUserAccountMgDbModelImpl) GetItems(ctx context.Context, eqConds map[string]interface{}) ([]*pbmgdb.PersonalUserAccountMgDbModel, error) {
	//
	coll := p.MgDB.Collection(p.collection())
	filter := bson.D{}

	for k, v := range eqConds {
		filter = append(filter, bson.E{Key: k, Value: v})
	}

	cursor, err := coll.Find(ctx, filter)
	var result []*pbmgdb.PersonalUserAccountMgDbModel
	for cursor.Next(ctx) {
		item := &pbmgdb.PersonalUserAccountMgDbModel{}
		// 解码绑定数据
		err = cursor.Decode(item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to %v failed.err=%v", p.collection(), err), err)
			return nil, err
		}
		result = append(result, item)
	}
	return result, nil
}

/////////////////////////////////////////////

type ISportActivityMgModel interface {
	QueryItemBasic(ctx context.Context, eqConds, largeConds, lessConds, sortField map[string]interface{}, limits int32) ([]*pbmgdb.UserSportActivityDetail, error)
	GetAggregateUserActivitySport(ctx context.Context, pipeline []bson.M) (result *AggregateSport, err error)
	UpdateSportStep(ctx context.Context, filter, update bson.D) (interface{}, error)
	InsertSportStep(ctx context.Context, item interface{}) (interface{}, error)
	QuerySportStepByUserID(ctx context.Context, userId, activityPhone int64) (*pbmgdb.UserSportActivityDetail, error)
	QuerySportStepByUserIDs(ctx context.Context, userIds []int64, activityPhone int64) ([]*pbmgdb.UserSportActivityDetail, error)
	TransactionFishToSportTableAndPersonalTable(ctx context.Context, params []SessionParams) error

	// UpsertSportStep 暂未使用
	//UpsertSportStep(ctx context.Context, filter, update interface{}) (interface{}, error)
	//QueryStepAndUserNums(ctx context.Context, pipeline bson.M, condEq map[string]interface{}) (int64, int64, error)
	//UpdateItems(ctx context.Context, eqConds map[string]interface{}, update interface{}) error
}
type SportActivityMgModelImpl struct {
	MgDB *mongo.Database
}

func NewSportActivityMgModelImpl(db *mongo.Database) ISportActivityMgModel {
	return &SportActivityMgModelImpl{MgDB: db}
}

func (s *SportActivityMgModelImpl) collection() string {
	return "user_sport_activity_detail"
}

type SessionParams struct {
	Filter map[string]interface{}
	Data   map[string]interface{}
}

func (s *SportActivityMgModelImpl) TransactionFishToSportTableAndPersonalTable(ctx context.Context, params []SessionParams) error {
	// 获取要操作的集合
	sportActivityCollection := s.MgDB.Collection(s.collection())
	PersonalUserCollection := s.MgDB.Collection("personalUserAccount")

	update := bson.D{
		{"$set", params[0].Data},
	}
	_, err := sportActivityCollection.UpdateOne(ctx, loadFilter(params[0].Filter), update)
	if err != nil {
		return err
	}

	update = bson.D{
		{"$inc", params[2].Data},
	}

	pu := &pbmgdb.PersonalUserAccountMgDbModel{}
	if err := PersonalUserCollection.FindOne(ctx, loadFilter(params[1].Filter)).Decode(pu); err == nil {
		logger.Info(ctx, fmt.Sprintf("PersonalUserCollection.FindOne: %v", pu))
		_, err := PersonalUserCollection.UpdateOne(ctx, loadFilter(params[2].Filter), update)
		if err != nil {
			return err
		}
	} else {
		logger.Info(ctx, fmt.Sprintf("PersonalUserCollection.FindOne: fish 0"))
		_, err := PersonalUserCollection.InsertOne(ctx, params[3].Data)
		if err != nil {
			return err
		}
	}

	return nil

}

func loadFilter(f map[string]interface{}) bson.M {
	filter := bson.M{}
	for k, v := range f {
		filter[k] = v
	}
	return filter
}

//func (p *SportActivityMgModelImpl) UpdateItems(ctx context.Context, eqConds map[string]interface{}, update interface{}) error {
//
//	coll := p.MgDB.Collection(p.collection())
//	filter := bson.M{}
//	for k, v := range eqConds {
//		filter[k] = v
//	}
//
//	_, err := coll.UpdateOne(ctx, filter, update)
//	if err != nil {
//		logger.Errorf(ctx, "update tab: %v fail, err: %v", p.collection(), err)
//		return err
//	}
//	return nil
//}

func (s *SportActivityMgModelImpl) QueryItemBasic(ctx context.Context, equalCones, largeCones, lessCones,
	sortField map[string]interface{}, limits int32) ([]*pbmgdb.UserSportActivityDetail, error) {
	//
	coll := s.MgDB.Collection(s.collection())
	filter := bson.D{}

	for k, v := range equalCones {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	for k, v := range largeCones {
		filter = append(filter, bson.E{k, bson.D{{"$gte", v}}})
	}
	for k, v := range lessCones {
		filter = append(filter, bson.E{k, bson.D{{"$lte", v}}})
	}

	opts := options.Find()
	orderSet := bson.D{}
	for k, v := range sortField {
		orderSet = append(orderSet, bson.E{Key: k, Value: v})
	}
	if len(orderSet) > 0 {
		opts.SetSort(orderSet)
	}
	if limits > 0 {
		opts.SetLimit(int64(limits))
	}

	cursor, err := coll.Find(ctx, filter, opts)
	var result []*pbmgdb.UserSportActivityDetail
	for cursor.Next(ctx) {
		item := &pbmgdb.UserSportActivityDetail{}
		// 解码绑定数据
		err = cursor.Decode(item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to user_sport_activity_detail failed.err=%v", err), err)
			return nil, err
		}
		result = append(result, item)
	}
	return result, nil
}

type AggregateSport struct {
	StepTotal int64 `bson:"step_total"`
	UserTotal int64 `bson:"user_total"`
}

// QuerySportStepByUserID 根据id和活动号确定唯一值
func (s *SportActivityMgModelImpl) QuerySportStepByUserID(ctx context.Context, userId, activityPhone int64) (*pbmgdb.UserSportActivityDetail, error) {
	filter := bson.D{
		{"user_id", userId},
		{"cur_activity_date", activityPhone},
	}
	result := &pbmgdb.UserSportActivityDetail{}
	err := s.MgDB.Collection(s.collection()).FindOne(ctx, filter).Decode(result)
	if err != nil {
		return nil, err
	}

	return result, nil
}

// QuerySportStepByUserIDs 根据某期查询这些用户
func (s *SportActivityMgModelImpl) QuerySportStepByUserIDs(ctx context.Context, userIds []int64, activityPhone int64) ([]*pbmgdb.UserSportActivityDetail, error) {
	filter := bson.D{
		{"cur_activity_date", activityPhone},
		{"user_id", bson.D{
			{"$in", userIds},
		}},
	}
	findOptions := options.Find()
	findOptions.SetSort(bson.D{
		bson.E{"sport_step_nums", -1}, //倒序
	})

	//var result interface{}
	result := make([]*pbmgdb.UserSportActivityDetail, 0)
	cursor, err := s.MgDB.Collection(s.collection()).Find(ctx, filter, findOptions)
	if err != nil {
		return nil, err
	}

	for cursor.Next(ctx) {
		item := &pbmgdb.UserSportActivityDetail{}
		// 解码绑定数据
		err = cursor.Decode(item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to user_sport_activity_detail failed.err=%v", err), err)
			return nil, err
		}
		result = append(result, item)
	}

	return result, nil
}

// UpsertSportStep 存在则更新，不存在则插入
//func (s SportActivityMgModelImpl) UpsertSportStep(ctx context.Context, filter, update interface{}) (interface{}, error) {
//	opts := options.UpdateOne().SetUpsert(true)
//	updateResult, err := s.MgDB.Collection(s.collection()).UpdateOne(ctx, filter, update, opts)
//	if err != nil {
//		// 处理更新错误
//		return nil, err
//	}
//
//	return updateResult.UpsertedID, err
//}

// UpdateSportStep 更新
func (s *SportActivityMgModelImpl) UpdateSportStep(ctx context.Context, filter, update bson.D) (interface{}, error) {
	updateResult, err := s.MgDB.Collection(s.collection()).UpdateOne(ctx, filter, update)
	if err != nil {
		// 处理更新错误
		return nil, err
	}

	return updateResult.UpsertedID, err
}

// InsertSportStep 插入
func (s *SportActivityMgModelImpl) InsertSportStep(ctx context.Context, item interface{}) (interface{}, error) {
	InsertOneResult, err := s.MgDB.Collection(s.collection()).InsertOne(ctx, item)
	if err != nil {
		// 处理更新错误
		return nil, err
	}

	return InsertOneResult.InsertedID, err
}

// GetAggregateUserActivitySport 统计某期用户数据
func (s *SportActivityMgModelImpl) GetAggregateUserActivitySport(ctx context.Context, pipeline []bson.M) (result *AggregateSport, err error) {
	result = &AggregateSport{}
	cursor, err := s.MgDB.Collection(s.collection()).Aggregate(ctx, pipeline)
	if err != nil {
		return nil, err
	}
	defer cursor.Close(ctx)

	if !cursor.Next(ctx) {
		return result, errorcode.Sport_step_zero
	}

	err = cursor.Decode(&result)
	if err != nil {
		logger.Errorf(ctx, "total sport step error: %v", err)
		return nil, err
	}

	return result, nil
}

//func (p *SportActivityMgModelImpl) QueryStepAndUserNums(ctx context.Context, pipeline bson.M, cond_eq map[string]interface{}) (int64, int64, error) {
//	filter := bson.D{}
//	for k, v := range cond_eq {
//		filter = append(filter, bson.E{Field: k, Value: v})
//	}
//	pipelines := []bson.M{
//		{"$match": filter},
//		pipeline,
//	}
//
//	cursor, err := p.MgDB.Collection(p.collection()).Aggregate(ctx, pipelines)
//	if err != nil {
//		return -1, -1, err
//	}
//	defer cursor.Close(ctx)
//
//	if !cursor.Next(ctx) {
//		return -1, -1, errors.New("not get ret")
//	}
//
//	result := &AggregateSport{}
//	err = cursor.Decode(&result)
//	if err != nil {
//		logger.Errorf(ctx, "total sport step error: %v", err)
//		return -1, -1, err
//	}
//
//	return result.StepTotal, result.UserTotal, nil
//}
