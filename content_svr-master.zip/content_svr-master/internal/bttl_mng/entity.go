package bttl_mng

import (
	"time"
)

type BttlEntity struct {
	ID         int64 `gorm:"primaryKey"`
	BttlID     int64 `gorm:"index:uniq_bttl_id,unique"` //业务ID
	UserID     int64
	Gender     int
	Content    string
	City       string
	Replier    int64
	CreateTime *time.Time `gorm:"index:idx_create_time"`
	ReplyTime  *time.Time
}

func (BttlEntity) TableName() string {
	return "bttl_entity"
}
