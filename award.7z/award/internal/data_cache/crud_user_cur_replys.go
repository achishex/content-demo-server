package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"time"
)

// 获取用户今天回复过多少人。
func (p *DataCacheMng) GetUserCurReplyList(ctx context.Context, userId int64) []int64 {
	result := make([]int64, 0)
	if userId == 0 {
		return result
	}

	redisKey := fmt.Sprintf(cache_const.UserCurReplyListRcache.KeyFmt, utils.GetCurDate(), userId) //
	retStrList, err := p.RedisCli.SMembers(ctx, redisKey).Result()
	if err == redis.Nil {
		logger.Error(ctx, fmt.Sprintf("GetUserLatestWorkScore redis qurey failed. key=%v", redisKey), err)
		return result
	}
	if len(retStrList) == 0 {
		//logger.Error(ctx, fmt.Sprintf("GetUserLatestWorkScore redis qurey failed. key=%v", redisKey), err)
		return result
	}

	//
	for _, retStr := range retStrList {
		if retStr == "" {
			continue
		}
		tmpInt64, err := utils.Str2Int64(retStr)
		if err != nil {
			continue
		}
		result = append(result, tmpInt64)
	}
	result = utils.Int64Set(result)
	return result

}

// 设置到今日已回复的列表
func (p *DataCacheMng) SetUserCurReplyList(ctx context.Context, curUserId, destUserId int64) error {
	redisKey := fmt.Sprintf(cache_const.UserCurReplyListRcache.KeyFmt, utils.GetCurDate(), curUserId) //
	expire := cache_const.UserCurReplyListRcache.Expire
	_, err := p.RedisCli.SAdd(ctx, redisKey, destUserId).Result()
	if err != nil && err != redis.Nil {
		logger.Error(ctx, fmt.Sprintf("SetUserCurReplyList set failed. key=%v", redisKey), err)
		return err
	}

	bSuc, err := p.RedisCli.Expire(ctx, redisKey, time.Duration(expire)*time.Second).Result()
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SetUserCurReplyList ret redis expire failed. key=%v, bSuc=%v", redisKey, bSuc), err)
		return err
	}
	return nil
}
