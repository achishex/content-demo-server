package xerr

const (
	SvcCodeParams    uint32 = 4000
	SvcCodeForbidden uint32 = 4003

	SvcCodeError uint32 = 1001 // 默认错误
)

const (
	SvcMsgParamError = "参数错误"
	SvcMsgForbidden  = "登录失效"

	SvcMsgDefaultError = "服务器开小差啦,稍后再来试一试"
)

var (
	ParamError = &CodeError{errCode: SvcCodeParams, errMsg: SvcMsgParamError}
)

var (
	DbNotFound          = &CodeError{errCode: 10000, errMsg: "无数据"}
	DbDoNothing         = &CodeError{errCode: 10001, errMsg: "未修改"}
	DbNoDuplicateUpsert = &CodeError{errCode: 10002, errMsg: "该数据已存在"}
	DbUpdateMastWhere   = &CodeError{errCode: 10003, errMsg: "必须传递where条件"}

	DbTimeOverlapError = &CodeError{errCode: 10201, errMsg: "生效时间重叠"}
)

var (
	UserInfoNoFound       = &CodeError{errCode: 20101, errMsg: "找不到用户信息"}
	UserInfoNickNameError = &CodeError{errCode: 20102, errMsg: "昵称重复"}

	WorkInfoNoFound = &CodeError{errCode: 20111, errMsg: "找不到作品信息"}

	OperatorAccountError         = &CodeError{errCode: 20301, errMsg: "账号状态异常"}
	OperatorAccountPermitError   = &CodeError{errCode: 20302, errMsg: "权限不足"}
	OperatorAccountPasswordError = &CodeError{errCode: 20303, errMsg: "账号密码错误"}
	OperatorAccountNoExistError  = &CodeError{errCode: 20304, errMsg: "用户不存在"}

	SettingUpdateError      = &CodeError{errCode: 20401, errMsg: "更新配置类型设置错误"}
	SettingUpdateValueError = &CodeError{errCode: 20402, errMsg: "不允许设置该值，_emptyType值为特殊值"}

	KeywordAddError   = &CodeError{errCode: 20501, errMsg: "添加关键字失败"}
	KeywordDelError   = &CodeError{errCode: 20501, errMsg: "删除关键字失败"}
	KeywordQueryError = &CodeError{errCode: 20501, errMsg: "查询关键字失败"}

	ReportPunishError          = &CodeError{errCode: 20601, errMsg: "举报惩罚失败"}
	ReportPunishDuplicateError = &CodeError{errCode: 20601, errMsg: "不允许重复惩罚同一条记录"}

	FeedbackTypeNotSupport = &CodeError{errCode: 20700, errMsg: "反馈类型不支持"}
	FeedbackTypeError      = &CodeError{errCode: 20701, errMsg: "反馈失败"}
)
