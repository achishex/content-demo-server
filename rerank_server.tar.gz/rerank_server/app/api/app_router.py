
from fastapi import APIRouter
from app.api import reranker


router = APIRouter()
router.include_router(reranker.router)

