package data_cache

import (
	"context"
	"fmt"
	rdsV8 "github.com/go-redis/redis/v8"
	"testing"
	"time"
)

func TestDataCacheMng_IncWorkInfoToNewCommentPeopleCount(t *testing.T) {
	type fields struct {
		RedisCli *rdsV8.Client
	}
	type args struct {
		ctx         context.Context
		workId      int64
		autohrLevel int64
		userId      int64
		count       int64
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
	}{
		{
			"name1",
			fields{
				RedisCli: InitRdsClient("119.29.185.233:6379", "1qaz2wsx"),
			},
			args{
				ctx:    context.Background(),
				workId: 4538230929392640,
				userId: 4399195780946945,
				count:  1,
			},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &DataCacheMng{
				RedisCli: tt.fields.RedisCli,
			}
			if err := p.IncWorkInfoToNewCommentPeopleCount(tt.args.ctx, tt.args.workId, tt.args.autohrLevel, tt.args.userId, tt.args.count); (err != nil) != tt.wantErr {
				t.Errorf("IncWorkInfoToNewCommentPeopleCount() error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

func InitRdsClient(addr, pwd string) *rdsV8.Client {
	client := rdsV8.NewClient(&rdsV8.Options{
		Addr:         addr,
		Password:     pwd,
		DB:           0,
		ReadTimeout:  2 * time.Minute,
		WriteTimeout: 1 * time.Minute,
		PoolTimeout:  2 * time.Minute,
		IdleTimeout:  10 * time.Minute,
		PoolSize:     1000,
	})
	_, err := client.Ping(context.Background()).Result()
	if err != nil {
		panic(fmt.Sprintf("redis init failed. err:%v", err.Error()))
	}
	return client
}
