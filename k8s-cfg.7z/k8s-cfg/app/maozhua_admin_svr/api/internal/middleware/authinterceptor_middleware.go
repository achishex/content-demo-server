package middleware

import (
	"content_svr/app/maozhua_admin_svr/common/result"
	"content_svr/db/mysqldb/model"
	rdsModel "content_svr/db/redisdb/model"
	"content_svr/pub/errors"
	"encoding/json"
	"github.com/zeromicro/go-zero/core/service"
	"net/http"
)

const appReqHeaderToken = "Token"

type AuthInterceptorMiddleware struct {
	Token *rdsModel.TokenAdmin
}

func NewAuthInterceptorMiddleware(token *rdsModel.TokenAdmin) *AuthInterceptorMiddleware {
	return &AuthInterceptorMiddleware{Token: token}
}

func (m *AuthInterceptorMiddleware) Handle(mode string) func(next http.HandlerFunc) http.HandlerFunc {
	return func(next http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			token := r.Header.Get(appReqHeaderToken)
			if mode == service.DevMode && token == "" {
				r.Header.Set("ctx_email", r.Header.Get("ctx_email"))
				r.Header.Set("ctx_name", r.Header.Get("ctx_name"))
				r.Header.Set("ctx_phone", r.Header.Get("ctx_phone"))
				next(w, r)
				return
			}

			if token == "" {
				result.ForbiddenErrorResult(r, w, errors.New("token is empty"))
				return
			}
			info, err := m.Token.Auth(token)
			if err != nil {
				result.ForbiddenErrorResult(r, w, err)
				return
			}

			userInfo := model.OperatorTab{}
			if err := json.Unmarshal([]byte(info), &userInfo); err != nil {
				result.ForbiddenErrorResult(r, w, err)
				return
			}

			r.Header.Set("ctx_email", userInfo.Email)
			r.Header.Set("ctx_name", userInfo.Name)
			r.Header.Set("ctx_phone", userInfo.Phone)

			next(w, r)
		}
	}
}
