package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	"github.com/golang/protobuf/proto"
	"time"
)

type WorkInfoLocal struct {
	WorkInfoDbModel *pbapi.PersonalBottleWorksDbModel
	WorkObjAttr     []*pbapi.WorkObjectAttrDbModel
	WorksExpandInfo [][]*pbapi.WorksExpandTypeSimpleResponse
	//TODO: add comments info..
}

// FIXME: 缓存优化
// 每次都请求 LDB + redisCache
func (p *DataCacheMng) GetWorkInfoLocal(ctx context.Context, workId int64, bSkipCache bool) (*WorkInfoLocal, error) {
	//从db获取之后，还需要从redis获取 曝光量等数据
	item, err := p.GetWorkInfoLD(ctx, workId, bSkipCache)
	if err != nil {
		return nil, err
	}
	if item == nil {
		return nil, nil
	}

	// item存在，则需要请求redis，获取最新的 曝光量，回复量等 计数数据
	redisWorkInfo := p.GetWorkInfoRedis(ctx, workId)
	if redisWorkInfo != nil {
		item.WorkInfoDbModel.VisitorCount = proto.Int32(redisWorkInfo.GetVisitorCount())
		item.WorkInfoDbModel.CommentCount = proto.Int32(redisWorkInfo.GetTalkUserCount())
		item.WorkInfoDbModel.LikeCount = proto.Int32(redisWorkInfo.GetLikeCount())

		//兼容历史数据，如果status key存在，则使用redis值。如果不存在使用本地内在中原model的值
		if ok, err := p.RedisCli.HExists(ctx, getRdsKeyWorkInfo(workId), "status").Result(); err == nil && ok {
			item.WorkInfoDbModel.Status = proto.Int32(redisWorkInfo.Status)
		}

		//redis中此key小于等于0说明未设置过，使用model值
		if redisWorkInfo.GetShowScope() > 0 {
			item.WorkInfoDbModel.ShowScope = proto.Int32(redisWorkInfo.ShowScope)
		}
	}
	return item, nil
}

// DB cache. 曝光量等数据是老数据。
func (p *DataCacheMng) DelWorkInfoCache(ctx context.Context, workId int64) {
	cacheKey := getLocalCacheKeyWorkInfo(workId)
	_, exist := p.LocalCache.GetDel(cacheKey)
	if exist == false {
		return
	}
}
func (p *DataCacheMng) GetWorkInfoLD(ctx context.Context, workId int64, bSkipCache bool) (*WorkInfoLocal, error) {
	// 从内存取
	cacheKey := getLocalCacheKeyWorkInfo(workId)
	cResp, exist := p.LocalCache.Get(cacheKey)
	if exist {
		resp, ok := cResp.(*WorkInfoLocal)
		if ok && resp != nil {
			return resp, nil
		}
	}

	//获取失败
	//logger.Infof(ctx, "get work info from db, workinfo localcache=%v", cResp)
	resp := &WorkInfoLocal{
		WorkObjAttr: make([]*pbapi.WorkObjectAttrDbModel, 0),
	}

	// db item
	dbitem, err := p.PersonBottleWorksModel.GetByWorkId(ctx, workId)
	if err != nil {
		return nil, err
	}
	if dbitem == nil {
		return nil, nil
	}
	resp.WorkInfoDbModel = dbitem

	// work obj attr
	if dbitem.GetType() != const_busi.WorkTypeText &&
		dbitem.GetId() > 100000 {
		cond := map[string]interface{}{"work_id": workId}
		itemAttrs, err1 := p.WorkObjectAttrModel.ListItemsByCondition(ctx, cond, 1, cm_const.MaxDbSize)
		if err1 != nil {
			return nil, err1
		}
		resp.WorkObjAttr = itemAttrs
	}

	// work expand
	resp.WorksExpandInfo = p.GetWorkExpandInfoMgDBLd(ctx, workId)

	// set local cache
	bSuc := p.LocalCache.Set(cacheKey, resp, go_cache.WithEx(5*60*time.Second))
	if !bSuc {
		logger.Errorf(ctx, "get work info from db, set to cache failed")
	}
	return resp, nil
}

// DB cache.  workidStr tsms
func (p *DataCacheMng) GetOfficialWorkIdsRd(ctx context.Context) (map[string]int64, error) {
	// 从内存取
	oUid := cm_const.OfficialMZUserId
	cacheKey := fmt.Sprintf(cache_const.OfficialWorkLcache.KeyFmt, oUid)
	expire := cache_const.OfficialWorkLcache.Expire
	cResp, exist := p.LocalCache.Get(cacheKey)
	if exist {
		resp, ok := cResp.(map[string]int64)
		if ok && resp != nil {
			return resp, nil
		}
	}

	// 30分钟到10小时的动态
	time30MBefor := utils.GenDbTime(time.Now().Add(time.Duration(-30*60) * time.Second))
	time10HBefor := utils.GenDbTime(time.Now().Add(time.Duration(-10*60*60) * time.Second))
	// db item
	dbitems, err := p.PersonBottleWorksModel.ListItemsByCond(ctx, map[string]interface{}{"user_id": cm_const.OfficialMZUserId},
		time10HBefor, time30MBefor, 1, cm_const.MaxDbSize)
	if err != nil {
		return nil, err
	}
	if dbitems == nil {
		return nil, nil
	}
	resp := make(map[string]int64)
	for _, item := range dbitems {
		resp[fmt.Sprintf("%v", item.GetId())] = utils.GenTimestampMs(item.GetCreateTime())
	}

	// set local cache
	bSuc := p.LocalCache.Set(cacheKey, resp, go_cache.WithEx(time.Duration(expire)*time.Second))
	if !bSuc {
		logger.Errorf(ctx, "get official works, set to cache failed")
	}
	return resp, nil
}
