package mz_test

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"context"

	"github.com/zeromicro/go-zero/core/logx"
)

type TestFuncLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewTestFuncLogic(ctx context.Context, svcCtx *svc.ServiceContext) *TestFuncLogic {
	return &TestFuncLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *TestFuncLogic) TestFunc(req *types.TestRequest) (resp *types.TestResponse, err error) {
	// 使用旧代码实例
	//ginContext := middleware.GetGinContext(l.ctx)
	//header, err := utils.GetCtxHeadersSession(ginContext)
	//if err != nil {
	//	return nil, err
	//}
	//u, err := l.svcCtx.ContentSvr.DataCache.GetUserInfoLocal(l.ctx, header, 4461762751496192, false)
	//fmt.Println(u)
	//
	return
}
