package phone

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"context"

	"github.com/zeromicro/go-zero/core/logx"
)

type QueryPhoneCodeLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewQueryPhoneCodeLogic(ctx context.Context, svcCtx *svc.ServiceContext) *QueryPhoneCodeLogic {
	return &QueryPhoneCodeLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *QueryPhoneCodeLogic) QueryPhoneCode(req *types.PhoneCodeReq) (resp *types.PhoneCodeResp, err error) {

	filter, opt := req.ParseMongo()
	list, err := l.svcCtx.WriteDB.SmsRecord.FindAll(l.ctx, filter, opt)
	if err != nil {
		return nil, err
	}

	resp = &types.PhoneCodeResp{
		List: list,
	}

	return resp, nil
}
