package inner_mng

import (
	"content_svr/config"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/url"
)

type AclForbidResp struct {
	Content   bool   `json:"content"`
	Message   string `json:"message"`
	MessageId string `json:"message_id"`
	Status    uint32 `json:"status"`
	Timestamp int64  `json:"timestamp"`
}

// return bForbid   false-不封禁 true-封禁
func (p *InnerProxyImpl) AclForbid(ctx context.Context, appType int32, coord *pbapi.CoordinateRedis) bool {
	url := fmt.Sprintf("%v:9905/basic/aclForbid?appType=%v&ip=%v&province=%v&city=%v",
		config.ServerConfig.CheckSvrIp, appType, url.QueryEscape(coord.GetIp()),
		url.QueryEscape(coord.GetProvince()), url.QueryEscape(coord.GetCity()))

	resp, err := p.getRequest(ctx, url, nil)
	if err != nil {
		logger.Errorf(ctx, "aclForbid req return err. url=%v, err=%v", url, err)
		return false
	}

	if resp.StatusCode != 200 {
		logger.Errorf(ctx, "aclForbid httpcode!=200. req=%v,resp.StatusCode != 200", coord)
		return false
	}
	innerResp := &AclForbidResp{}
	sRespBytes, _ := io.ReadAll(resp.Body)
	logger.Infof(ctx, "AclForbid, url=%v, resp=%v", url, string(sRespBytes))
	err = json.Unmarshal(sRespBytes, innerResp)
	if err != nil {
		logger.Errorf(ctx, "aclForbid Decode failed. coord=%v", coord)
		return false
	}
	return innerResp.Content
}
