package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"crypto/md5"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"github.com/go-resty/resty/v2"
	"github.com/zeromicro/go-zero/core/jsonx"
	"net/url"
	"strconv"
	"strings"
	"time"
)

type dataList struct {
	CvTime     int64  `json:"cvTime"`
	CvType     string `json:"cvType"`
	UserId     string `json:"userId"`
	UserIdType string `json:"userIdType"`
	CvCustom   string `json:"cvCustom"`
}

const (
	platformVivo = "vivo"
)

var (
	//cvType各平台对应值
	platformCvType = map[string]map[int]string{
		"vivo": {
			1: "ACTIVATION", //激活
			2: "REGISTER",   //注册
		},
		"huawei": {
			1: "ACTIVATION", //激活
			2: "REGISTER",   //注册
		},
	}
)

// AdBehaviorUpload 平台归因上报
func (p *ContentMng) AdBehaviorUpload(ctx context.Context, req *pbapi.AdBehaviorUploadReq) (*pbapi.AdBehaviorUploadResp, error) {
	logger.Infof(ctx, "%#v", req)
	resp := &pbapi.AdBehaviorUploadResp{Status: false}

	pct, ok := platformCvType[req.Platform]
	if !ok {
		return resp, nil
	}

	cvType, ok := pct[int(req.CvType)]
	if !ok {
		return resp, nil
	}

	dataList := []dataList{
		{
			CvTime:     time.Now().UnixMicro(),
			CvType:     cvType,
			UserId:     req.UserId,
			UserIdType: req.UserIdType,
			CvCustom:   "",
		},
	}

	logger.Infof(ctx, "vivo_dataList url %#v", dataList)

	//当前只接入vivo
	if strings.ToLower(req.Platform) != platformVivo {
		return resp, nil
	}

	adConfig := config.ServerConfig.AdConfig
	body := map[string]any{
		"srcType":  req.SrcType,
		"srcId":    adConfig.Vivo.SrcId,
		"pkgName":  "com.xiyou.miao",
		"dataList": dataList,
	}

	logger.Infof(ctx, "vivo_body url %#v", body)

	h := md5.New()
	h.Write([]byte(strconv.FormatInt(time.Now().UnixMicro(), 10)))
	nonce := hex.EncodeToString(h.Sum(nil))

	urlString := fmt.Sprintf("%s?access_token=%s&timestamp=%d&nonce=%s&advertiser_id=%s",
		adConfig.Vivo.Url,
		adConfig.Vivo.AccessToken,
		time.Now().UnixMilli(),
		nonce,
		adConfig.Vivo.AdvertiserId)

	client := resty.New()
	r, err := client.R().
		SetHeader("Content-Type", "application/json").
		SetBody(body).
		Post(urlString)
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return nil, err
	}

	logger.Infof(ctx, "vivo_http url", urlString)
	logger.Infof(ctx, "vivo_http response", r.String())

	resp.Status = true

	logger.Infof(ctx, "%#v", resp)
	return resp, nil
}

func (p *ContentMng) AdBehaviorUploadV2(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (*pbapi.AdBehaviorUploadResp, error) {
	//defer logger.Infof(ctx, "get_app_config,ctx_header=%v", utils.StructToJsonString(ctx.Request.Header))
	behaviorUp := behaviorUpCtrl{}
	resp := &pbapi.AdBehaviorUploadResp{}

	switch header.GetChannel() {
	case cm_const.AppChannelVivo:
		// 调用 vivo 接口 https://www.yuque.com/waited/aa0viv/gu0ikqgdyzdzogo7?singleDoc=#UYgtv
		err := behaviorUp.vivo(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelOppo:
		// 调用 oppo 接口
		err := behaviorUp.oppo(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelXiaomi:
		// 调用 小米 接口 https://api.e.mi.com/doc.html#/1.0.0-mdtag9b26f-omd/document-f0283649125f62138db43c6f5fc25686
		err := behaviorUp.xiaomi(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelHuaWei:
		// 其他接口还没接入
	}

	resp.Status = true
	return resp, nil
}

type behaviorUpCtrl struct {
}

func (b behaviorUpCtrl) xiaomi(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	now := time.Now()
	urlString := "http://trail.e.mi.com/global/log"

	// 生成签名
	type pair struct {
		key   string
		value string
	}
	buildInfo := func(device []pair, signKey string, encryptKey string) string {
		//queryString 设备信息
		query := ""
		for i, p := range device {
			and := ""
			if i != 0 {
				and = "&"
			}
			query += fmt.Sprintf("%s%s=%s", and, p.key, p.value)
		}
		query1 := url.QueryEscape(query)
		//md5后的sign值
		sign := fmt.Sprintf("%x", md5.Sum([]byte(signKey+"&"+query1)))
		//baseData
		baseData := query + "&sign=" + sign

		l2 := len(encryptKey)
		var res []byte
		for i := range baseData {
			u := baseData[i] ^ encryptKey[i%l2]&0xFF
			res = append(res, u)
		}
		return url.QueryEscape(base64.StdEncoding.EncodeToString(res))
	}

	// 需要的参数值
	appId := "914866"
	customerId := "491842"
	info := ""     // 签名
	convType := "" // APP_ACTIVE 自定义激活  APP_REGISTER 自定义注册

	device := make([]pair, 0)
	if req.Imei != "" {
		device = append(device, pair{"imei", utils.MD5(req.Imei)})
	}
	if req.Oaid != "" && req.Imei == "" {
		device = append(device, pair{"oaid", req.Oaid})
	}
	device = append(device, pair{"conv_time", strconv.FormatInt(now.UnixMilli(), 10)})
	switch req.Type {
	case 1:
		convType = "APP_ACTIVE" // 自定义激活
		info = buildInfo(device, "XZEHduHOsLyBPhuA", "tLCJdIZqucpWOmFH")
	case 2:
		convType = "APP_REGISTER" // 自定义注册
		info = buildInfo(device, "dqhAqGfNOsZMoSld", "MIhXhHbOvasPGMlM")
	}

	// 构建请求链接
	u, err := url.Parse(urlString)
	if err != nil {
		logger.Error(ctx, "url.Parse", err)
		return err
	}
	query := u.Query()
	query.Set("appId", appId)
	query.Set("customer_id", customerId)
	query.Set("info", info)
	query.Set("conv_type", convType)
	u.RawQuery = query.Encode()

	client := resty.New()
	r, err := client.R().Get(u.String())
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return err
	}
	logger.Infof(ctx, "imei: %s oaid: %s xiaomi behavior request:%v", req.Imei, req.Oaid, u.String())
	logger.Infof(ctx, "xiaomi behavior response:%v", r.String())
	return nil
}

func (b behaviorUpCtrl) oppo(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	now := time.Now()

	salt := "e0u6fnlag06lc3pl"
	aesKeyBase64 := "XGAXicVG5GMBsx5bueOe4w=="
	urlString := "https://api.ads.heytapmobi.com/api/uploadActiveData"

	// 加密imei和oaid
	aesKey, _ := base64.StdEncoding.DecodeString(aesKeyBase64)
	var imei, ouid string
	var err error
	if len(req.GetImei()) != 0 {
		imei, err = utils.AESEncrypt([]byte(req.GetImei()), aesKey)
		if err != nil {
			logger.Error(ctx, "utils.AESEncrypt", err)
			return err
		}
	}
	if len(req.GetOaid()) != 0 && len(req.GetImei()) == 0 {
		ouid, err = utils.AESEncrypt([]byte(req.GetOaid()), aesKey)
		if err != nil {
			logger.Error(ctx, "utils.AESEncrypt", err)
			return err
		}
	}

	body := map[string]interface{}{
		"imei":        imei,             //  imei 经过 AES 加密后的值
		"ouId":        ouid,             // 开发者 ID 经过 AES 加密后的值
		"timestamp":   now.UnixMilli(),  // 事 件 发 生 的 时 间戳 ( 毫 秒 ) ， 如1522221766623
		"pkg":         "com.xiyou.miao", // 包名，如 com.xxx或者填，快应用 id，如 100137
		"dataType":    req.Type,         // 转化数据类型： 1、激活， 2、注册
		"channel":     1,                // 渠道：1、OPPO，2、一加，0、其他
		"type":        0,                // 0：无加密（默认为 0）1：imei md5 加密2：oaid md5 加密
		"ascribeType": 0,                // 归因类型：1：广告主归因，0：OPPO归因（默认或者不填即为 0），2：助攻归因
		//"adId":        314156384,        // 请求 id
	}

	// 生成签名
	timestamp := strconv.FormatInt(now.UnixMilli(), 10)
	content, err := jsonx.MarshalToString(body)
	if err != nil {
		logger.Error(ctx, "jsonx.MarshalToString", err)
		return err
	}
	content = content + timestamp + salt
	sign := utils.MD5(content)

	client := resty.New()
	r, err := client.R().
		SetHeader("Content-Type", "application/json").
		SetHeader("signature", sign). // 签名
		SetHeader("timestamp", timestamp).
		SetBody(body).
		Post(urlString)
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return err
	}

	logger.Infof(ctx, "imei: %s oaid: %s oppo behavior request: %v", req.Imei, req.Oaid, r.Request)
	logger.Infof(ctx, "oppo behavior response: %v", r.String())
	return nil
}

func (b behaviorUpCtrl) vivo(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	if len(req.GetOaid()) == 0 && len(req.GetImei()) == 0 && req.GetType() > 0 {
		logger.Errorf(ctx, "quding-vivo, 参数不全，没有 oaid 或 imei 或 type")
		return errors.New("参数不全")
	}

	cvType := "ACTIVATION"
	if req.GetType() == 2 {
		cvType = "REGISTER" //注册
	}

	userId := ""
	UserIdType := ""
	if len(req.GetOaid()) > 0 {
		userId = req.GetOaid()
		UserIdType = "OAID"
	} else if len(req.GetImei()) > 0 {
		userId = req.GetImei()
		UserIdType = "IMEI"
	}

	dataList := []dataList{
		{
			CvTime:     time.Now().UnixMicro(),
			CvType:     cvType,
			UserId:     userId,
			UserIdType: UserIdType,
			CvCustom:   "",
		},
	}

	logger.Infof(ctx, "vivo_dataList url %#v", dataList)

	adConfig := config.ServerConfig.AdConfig
	body := map[string]any{
		"srcType":  "APP",
		"srcId":    adConfig.Vivo.SrcId,
		"pkgName":  "com.xiyou.miao",
		"dataList": dataList,
	}

	logger.Infof(ctx, "vivo_body url %#v", body)

	h := md5.New()
	h.Write([]byte(strconv.FormatInt(time.Now().UnixMicro(), 10)))
	nonce := hex.EncodeToString(h.Sum(nil))

	urlString := fmt.Sprintf("%s?access_token=%s&timestamp=%d&nonce=%s&advertiser_id=%s",
		adConfig.Vivo.Url,
		adConfig.Vivo.AccessToken,
		time.Now().UnixMilli(),
		nonce,
		adConfig.Vivo.AdvertiserId)

	client := resty.New()
	r, err := client.R().
		SetHeader("Content-Type", "application/json").
		SetBody(body).
		Post(urlString)
	if err != nil {
		logger.Errorf(ctx, "quding-vivo, http error:", err)
		return err
	}

	logger.Infof(ctx, "imei: %s oaid: %s vivo behavior request: %v", req.Imei, req.Oaid, urlString)
	logger.Infof(ctx, "vivo_http response", r.String())
	return nil
}
