package robot

import (
	"content_svr/db/mongodb/model"
	"content_svr/pub/snow_flake"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"time"
)

func (w *worker) doComment(params interface{}) {
	if params == nil {
		return
	}
	workId, ok := params.(int64)
	if !ok {
		return
	}
	// 发评论
	now := time.Now()
	nowFormat := now.Format("2006-01-02 15:04:05.000")
	_, err := w.monitor.manageDB.WorksCommentDetail.Insert(w.ctx,
		&model.WorksCommentDetail{
			ID:          snow_flake.GetSnowflakeID(),
			WorkId:      workId,
			UserId:      w.robot.UserId,
			Comment:     w.robot.Comment,
			Longitude:   0,
			Latitude:    0,
			Ip:          "183.14.134.118",
			Province:    "猫爪宇宙总部",
			City:        "猫爪宇宙总部",
			Status:      1,
			CreateTime:  nowFormat,
			UpdateTime:  nowFormat,
			LikedCount:  0,
			CommentType: 1,
		})
	if err != nil {
		logx.Error(w.ctx, fmt.Sprintf("userid机器人: %d 异常", w.robot.UserId), err)
		return
	}

	if err := w.monitor.manageDB.PersonalBottleWork.IncNewCommentCount(w.ctx, workId, 1); err != nil {
		logx.Error(w.ctx, fmt.Sprintf("userid机器人: %d 异常", w.robot.UserId), err)
		return
	}

	return
}
