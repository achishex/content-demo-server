package utils

import (
	"crypto/sha256"
	"encoding/hex"
)

func Sha256String(s string) string {
	h := sha256.New()
	h.Write([]byte(s))
	bs := h.Sum(nil)
	return hex.EncodeToString(bs)
}
