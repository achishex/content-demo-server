package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type ZooGameUserInfo struct {
	model.ZooGameUserInfoModel
	redisManage *query_rds.Manage
}

func NewCacheZooGameUserInfo(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *ZooGameUserInfo {
	return &ZooGameUserInfo{
		ZooGameUserInfoModel: mongo.ZooGameUserInfo,
		redisManage:          redisManage,
	}
}
