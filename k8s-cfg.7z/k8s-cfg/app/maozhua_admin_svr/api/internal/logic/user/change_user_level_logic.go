package user

import (
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type ChangeUserLevelLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewChangeUserLevelLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ChangeUserLevelLogic {
	return &ChangeUserLevelLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ChangeUserLevelLogic) ChangeUserLevel(req *types.ChangeUserLevelReq) (resp *types.ChangeUserLevelResp, err error) {
	filter := map[string]interface{}{
		"_id": req.UserId,
	}
	update := map[string]interface{}{
		"ulevel": req.Ulevel,
	}

	err = l.svcCtx.ManagerDB.SecretUserExtInfo.UpdateMap(l.ctx, filter, update)

	return
}
