package model

const (
	AccountStatusClose = iota // 注销
	AccountStatusOpen         // 使用中
)

const (
	//_ = iota
	AccountTypeNormal = 0 // 普通权限
	AccountTypeManage = 1 // 管理员权限
)
