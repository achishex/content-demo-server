package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type SecretAudit struct {
	model.SecretAuditModel
	redisManage *query_rds.Manage
}

func NewCacheSecretAudit(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *SecretAudit {
	return &SecretAudit{
		SecretAuditModel: mongo.SecretAudit,
		redisManage:      redisManage,
	}
}
