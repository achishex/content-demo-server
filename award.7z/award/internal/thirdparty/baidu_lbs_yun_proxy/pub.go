package baidu_lbs_yun_proxy

type GetIpAddressResp struct {
	Address string `json:"address"`
	Content struct {
		Address       string `json:"address"`
		AddressDetail struct {
			Adcode       string `json:"adcode"`
			City         string `json:"city"`
			CityCode     int    `json:"city_code"`
			District     string `json:"district"`
			Province     string `json:"province"`
			Street       string `json:"street"`
			StreetNumber string `json:"street_number"`
		} `json:"address_detail"`
		Point struct {
			X string `json:"x"`
			Y string `json:"y"`
		} `json:"point"`
	} `json:"content"`
	Status int `json:"status"`
}

type ReverseGeocodingResp struct {
	Status int `json:"status"`
	Result struct {
		Location struct {
			Lng float64 `json:"lng"`
			Lat float64 `json:"lat"`
		} `json:"location"`
		FormattedAddress string `json:"formatted_address"`
		Business         string `json:"business"`
		AddressComponent struct {
			Country         string `json:"country"`
			CountryCode     int    `json:"country_code"`
			CountryCodeIso  string `json:"country_code_iso"`
			CountryCodeIso2 string `json:"country_code_iso2"`
			Province        string `json:"province"`
			City            string `json:"city"`
			CityLevel       int    `json:"city_level"`
			District        string `json:"district"`
			Town            string `json:"town"`
			TownCode        string `json:"town_code"`
			Distance        string `json:"distance"`
			Direction       string `json:"direction"`
			Adcode          string `json:"adcode"`
			Street          string `json:"street"`
			StreetNumber    string `json:"street_number"`
		} `json:"addressComponent"`
		Pois               []any  `json:"pois"`
		Roads              []any  `json:"roads"`
		PoiRegions         []any  `json:"poiRegions"`
		SematicDescription string `json:"sematic_description"`
		CityCode           int    `json:"cityCode"`
	} `json:"result"`
}

type CheckImgResp struct {
	Conclusion     string `json:"conclusion"`
	LogID          int64  `json:"log_id"`
	IsHitMd5       bool   `json:"isHitMd5"`
	ConclusionType int    `json:"conclusionType"` // 审核结果类型，可取值1、2、3、4，分别代表1：合规，2：不合规，3：疑似，4：审核失败
}
