package im_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbim"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"context"
	"github.com/OpenIMSDK/protocol/sdkws"
	"strconv"
	"time"
)

func (i *IMMng) UserToken(ctx context.Context, req *pbim.IMTokenReq) (*pbim.IMTokenResp, error) {
	var userId = strconv.FormatInt(req.UserId, 10)

	adminToken, err := i.OpenImCaller.ImAdminTokenWithDefaultAdmin(ctx)
	if err != nil {
		logger.Errorf(ctx, "im.UserToken.ImAdminTokenWithDefaultAdmin error: %v", err)
		return nil, errorcode.IMServerError
	}
	ctx = middleware.WithImToken(ctx, adminToken)
	isReg, _, err := i.OpenImCaller.AccountCheck(ctx, []string{strconv.FormatInt(req.UserId, 10)})
	if err != nil {
		logger.Errorf(ctx, "im.UserToken.AccountCheck error: %v", err)
		return nil, errorcode.IMServerError
	}

	if !isReg {
		userInfo, err := i.DataCache.GetUserBasicInfo(ctx, req.UserId, false)
		if err != nil {
			return nil, errorcode.DATA_NOT_EXISTS
		}
		u := &sdkws.UserInfo{
			UserID:     userId,
			Nickname:   userInfo.GetNickName(),
			FaceURL:    userInfo.GetPhoto(),
			CreateTime: time.Now().UnixMilli(),
		}
		if err := i.OpenImCaller.RegisterUser(ctx, []*sdkws.UserInfo{u}); err != nil {
			logger.Errorf(ctx, "im.UserToken.RegisterUser error: %v", err)
			return nil, errorcode.IMRegisterUserError
		}
	}

	token, err := i.OpenImCaller.UserToken(ctx, userId, req.PlatformId)
	if err != nil {
		logger.Errorf(ctx, "im.UserToken.UserToken error: %v", err)
		return nil, errorcode.IMGetUserTokenError
	}

	return &pbim.IMTokenResp{
		ImToken: token,
		ApiUrl:  config.ServerConfig.OpenImConfig.ClientAPIUrl,
		WsUrl:   config.ServerConfig.OpenImConfig.ClientWSUrl,
	}, nil
}

func (i *IMMng) checkOrRegister(ctx context.Context, memberUserIDs []string) error {
	adminToken := i.Helper.GetAdminIMTokenWithCache()
	ctx = middleware.WithImToken(ctx, adminToken)

	res, failedUserIds, err := i.OpenImCaller.AccountCheck(ctx, memberUserIDs)
	if err != nil {
		logger.Errorf(ctx, "IMMng.AccountCheck error: %v", err)
		return errorcode.IMServerError
	}
	if res {
		return nil
	}

	var userList []*sdkws.UserInfo
	for _, uid := range failedUserIds {
		iUid, _ := strconv.ParseInt(uid, 10, 64)
		userInfo, err := i.DataCache.GetUserBasicInfo(ctx, iUid, false)
		if err != nil {
			return errorcode.DATA_NOT_EXISTS
		}
		userList = append(userList, &sdkws.UserInfo{
			UserID:     uid,
			Nickname:   userInfo.GetNickName(),
			FaceURL:    userInfo.GetPhoto(),
			CreateTime: time.Now().UnixMilli(),
		})
	}

	if err := i.OpenImCaller.RegisterUser(ctx, userList); err != nil {
		logger.Errorf(ctx, "im.UserToken.RegisterUser error: %v", err)
		return errorcode.IMRegisterUserError
	}

	return nil
}
