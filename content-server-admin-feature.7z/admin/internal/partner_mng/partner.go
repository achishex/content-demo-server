package partner_mng

import (
	"content_svr/config"
	"content_svr/db/mongodb/model"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/content_mng"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/gogo/protobuf/proto"
	"github.com/gookit/goutil/timex"
	"github.com/kevwan/mapreduce/v2"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"strconv"
	"strings"
	"time"
)

func (p *PartnerMng) GetPartnerInfo(ctx context.Context) (*pbuserapi.PartnerInfoResp, error) {
	var userId = middleware.GetUserID(ctx.(*gin.Context))

	userInfo, err := p.DataCache.GetUserInfoLocal(ctx, nil, userId, true)
	if userInfo == nil || err != nil {
		return nil, errorcode.DATA_ERROR
	}
	if userInfo.PsecretUserExtInfo.GetUlevel() < const_busi.UserLevel5 {
		return nil, errorcode.PartnerUserLevelError
	}

	//合伙人信息
	resp, partner, err := p.GetPartnerDetail(ctx, userId)
	if err != nil {
		return nil, err
	}

	if err := mapreduce.Finish(func() error {
		//弹窗
		if resp.Popup, err = p.getPopups(ctx, userId, resp.HasSignIn, resp.InviteInfo.InvitedNum, partner); err != nil {
			return errorcode.DATA_ERROR
		}
		return nil
	}, func() error {
		//邀请列表
		resp.InvitedList, err = p.getInviteList(ctx, userId)
		return nil
	}); err != nil {
		return nil, err
	}

	return resp, nil
}

// 合伙人信息
func (p *PartnerMng) GetPartnerDetail(ctx context.Context, userId int64) (*pbuserapi.PartnerInfoResp, *pbmgdb.PartnerMgDbModel, error) {
	var (
		resp    = &pbuserapi.PartnerInfoResp{}
		partner *pbmgdb.PartnerMgDbModel
		err     error
	)

	//合伙人初始化
	if partner, err = p.DataCache.GetImpl().PartnerMgModel.FindOne(ctx, bson.M{"user_id": userId}); err != nil {
		return nil, nil, errorcode.PartnerGetError
	}
	if partner == nil {
		partner = &pbmgdb.PartnerMgDbModel{
			UserId:     userId,
			CreateTime: time.Now().UnixMilli(),
		}
		if err := p.DataCache.GetImpl().PartnerMgModel.Create(ctx, partner); err != nil {
			return nil, nil, errorcode.PartnerCreateError
		}
	}

	//今日奖池 = 前一天（总广告收益-看广告领取的红包）x65%
	var todayPond = float64(0)
	yesterday := timex.DateFormat(timex.Now().SubDay(1).T(), "Y-m-d")
	csj, err := p.DataCache.GetImpl().CsjAdvertisementDataMgModel.Find(ctx, bson.M{"date": yesterday})
	if err != nil {
		return nil, nil, err
	}
	for _, v := range csj {
		todayPond += v.GetRevenue()
	}
	if todayPond > 0 {
		//减去【看广告领取的红包】
		todayPond = (todayPond - p.sumAdReward(ctx)) * config.ServerConfig.PartnerConfig.PondRate
		//奖池最大上限 默认200元
		maxPond := float64(config.ServerConfig.PartnerConfig.PondMaxAmount)
		if maxPond > 0 && todayPond > maxPond {
			resp.TodayPond = uint64(maxPond * 100)
		} else {
			resp.TodayPond = uint64(todayPond * 100)
		}
	}

	//合伙人签到人数
	resp.ExpectPeopleNum = uint32(p.DataCache.GetImpl().PartnerDailySignInMgModel.CountByCondition(ctx, bson.M{"day": timex.DateFormat(time.Now(), "Ymd")}))
	//预计瓜分金额 = 今日奖池/预计瓜分人数
	if resp.GetTodayPond() > 0 && resp.GetExpectPeopleNum() > 0 {
		todayExpectIncome := uint64(todayPond / float64(resp.GetExpectPeopleNum()) * 100)
		resp.TodayExpectIncome = todayExpectIncome
	}

	//累计获取
	resp.TotalIncome = partner.TotalIncome
	//是否合伙人
	resp.HasPartner = partner.IsPartner
	//已邀请人数
	invitedNum := uint32(p.DataCache.GetImpl().PartnerInviteMgModel.CountByCondition(ctx, bson.M{"invite_user_id": userId}))
	//签到状态
	resp.HasSignIn = p.DataCache.GetImpl().GetUserDailySign(ctx, userId)
	//是否新用户
	resp.HasNewUser = p.isPartnerNewUser(ctx, userId)
	//开奖后瓜分金额
	resp.CarveUpAmount = p.getCarveUpAmount(ctx, userId)

	//邀请阶段展示
	var inviteStages []*pbuserapi.InviteStage
	for _, v := range config.ServerConfig.PartnerConfig.InviteStages {
		inviteStages = append(inviteStages, &pbuserapi.InviteStage{
			NeedPeopleNum:  v.NeedPeopleNum,
			Reward:         v.Reward,
			TotalPeopleNum: v.TotalPeopleNum,
		})
	}

	//邀请信息
	resp.InviteInfo = &pbuserapi.InviteInfo{
		NeedInviteNum:    config.ServerConfig.PartnerConfig.NeedInviteNum,
		InvitedNum:       invitedNum,
		InviteStages:     inviteStages,
		TotalRedPacket:   config.ServerConfig.PartnerConfig.TotalRedPacket,
		InviteCode:       partner.InviteCode,
		InvitePassphrase: fmt.Sprintf(const_busi.InvitePassphrase, partner.InviteCode),
		DrawingTime:      fmt.Sprintf("%d:00", config.ServerConfig.PartnerConfig.DrawingTime),
		HasInvited:       partner.IsInvited,
	}

	return resp, partner, nil
}

// 是否新用户
func (p *PartnerMng) isPartnerNewUser(ctx context.Context, userId int64) bool {
	userInfo, err := p.DataCache.GetUserInfoLocal(ctx, nil, userId, false)
	if err != nil {
		return false
	}

	t, err := timex.FromDate(userInfo.UserInfoDbModel.GetCreateTime(), "Y-m-d H:i:s")
	if err != nil {
		return false
	}
	if t != nil && t.UnixMilli() > timex.Now().SubDay(int(config.ServerConfig.PartnerConfig.NewUserBeforeDays)).UnixMilli() {
		return true
	}
	return false
}

// 弹窗列表
func (p *PartnerMng) getPopups(ctx context.Context, userId int64, isSignIn bool, invitedNum uint32, partner *pbmgdb.PartnerMgDbModel) ([]*pbuserapi.PopupInfo, error) {
	var (
		popups            = make([]*pbuserapi.PopupInfo, 0)
		clearAwardPopup   bool
		clearInvitePopup  bool
		clearPartnerPopup bool
	)

	if partner.IsPartner && !isSignIn && timex.Now().Hour() < int(config.ServerConfig.PartnerConfig.DrawingTime) {
		popups = append(popups, &pbuserapi.PopupInfo{
			Type: const_busi.PopupTypeNoSign,
			Desc: fmt.Sprintf("您还未签到哦，完成今日签到\n即可瓜分今日奖池金"),
		})
	}

	if partner.RewardPopup {
		award, err := p.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.GetLatestItemByUserId(ctx, userId)
		if err != nil {
			return nil, errorcode.DATA_ERROR
		}
		popups = append(popups, &pbuserapi.PopupInfo{
			Type:              const_busi.PopupTypeCarveUp,
			SplitRewardAmount: uint64(award.GetAward() * 100),
			Desc:              "奖池金已入账，可前往猫爪钱包提现",
		})
		clearAwardPopup = true
	}

	inviteStages := config.ServerConfig.PartnerConfig.InviteStages
	if partner.PartnerPopup {
		popups = append(popups, &pbuserapi.PopupInfo{
			Type:                 const_busi.PopupTypeBePartner,
			ReInviteRewardAmount: inviteStages[len(inviteStages)-1].Reward / 100,
			Desc:                 fmt.Sprintf("每日完成签到，即可在每日%d:00瓜分奖池金", config.ServerConfig.PartnerConfig.DrawingTime),
		})
		clearPartnerPopup = true
	} else if partner.InvitePopup {
		for i, v := range inviteStages {
			if invitedNum <= v.TotalPeopleNum {
				reNum := v.TotalPeopleNum - invitedNum
				reReward := v.Reward
				if i == 0 && reNum == 0 {
					reNum = inviteStages[i+1].NeedPeopleNum
					reReward = inviteStages[i+1].Reward
				}

				popup := &pbuserapi.PopupInfo{
					Type:                 const_busi.PopupTypeInvite,
					ReInviteNum:          reNum,
					ReInviteRewardAmount: reReward / 100,
				}

				if i > 0 {
					popup.Desc = fmt.Sprintf("再邀%d人，即可获得%d元现金红包", reNum, v.Reward/100)
				} else {
					popup.Desc = fmt.Sprintf("您已获得%d元红包，再邀%d人，即可获得%d元现金红包", v.Reward/100, reNum, reReward/100)
				}
				popups = append(popups, popup)
				clearInvitePopup = true
				break
			}
		}
	}

	//清除弹窗
	go p.clearPopup(ctx, clearAwardPopup, clearInvitePopup, clearPartnerPopup, partner)

	return popups, nil
}

// 清除弹窗
func (p *PartnerMng) clearPopup(ctx context.Context, clearAward, clearInvite, clearPartnerPopup bool, partner *pbmgdb.PartnerMgDbModel) {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "clear popup panic: err: %v", err)
		}
	}()

	updates := bson.M{}
	if clearPartnerPopup {
		updates["partner_popup"] = false
	}
	if clearAward {
		updates["reward_popup"] = false
	}
	if clearInvite {
		updates["invite_popup"] = false
	}

	if len(updates) > 0 {
		if err := p.DataCache.GetImpl().PartnerMgModel.UpdateOne(ctx, bson.M{"_id": partner.InviteCode}, updates); err != nil {
			logger.Errorf(ctx, "PartnerMng:clearPopup error: %v, clearAward: %v, clearInvite: %v", err, clearAward, clearInvite)
		}
	}
}

// 邀请列表
func (p *PartnerMng) getInviteList(ctx context.Context, userId int64) ([]*pbuserapi.InviteUser, error) {
	var (
		resp       = make([]*pbuserapi.InviteUser, 0)
		inviteColl = p.DataCache.GetImpl().PartnerInviteMgModel
	)

	inviteList, err := inviteColl.Find(ctx, bson.M{"invite_user_id": userId}, &options.FindOptions{
		Sort: bson.D{{"create_time", -1}},
	})
	if err != nil || len(inviteList) == 0 {
		return resp, nil
	}

	for _, user := range inviteList {
		userInfo, err := p.DataCache.GetUserInfoLocal(ctx, nil, user.UserId, true)
		if userInfo == nil || err != nil {
			continue
		}

		item := &pbuserapi.InviteUser{
			NickName: userInfo.UserInfoDbModel.GetNickName(),
			Photo:    userInfo.UserInfoDbModel.GetPhoto(),
		}

		if !strings.HasPrefix(userInfo.UserInfoDbModel.GetPhoto(), "http") && len(config.ServerConfig.ImageHost) > 0 {
			item.Photo = config.ServerConfig.ImageHost + userInfo.UserInfoDbModel.GetPhoto()
		}

		resp = append(resp, item)
	}

	return resp, nil
}

// 使用邀请码
func (p *PartnerMng) UseInviteCode(ctx context.Context, req *pbuserapi.UseInviteCodeReq) (*pbuserapi.UseInviteCodeResp, error) {
	var (
		userId       = middleware.GetUserID(ctx.(*gin.Context))
		beInviteUser *pbmgdb.PartnerMgDbModel
	)

	//非新用户
	if !p.isPartnerNewUser(ctx, userId) {
		return nil, errorcode.PartnerNotNewUser
	}

	//邀请人
	inviteUser, err := p.DataCache.GetImpl().PartnerMgModel.FindOne(ctx, bson.M{"_id": req.GetInviteCode()})
	if err != nil || inviteUser == nil {
		logger.Errorf(ctx, "UseInviteCode:inviteUser not found or err: %v", err)
		return nil, errorcode.PartnerGetInviterError
	}

	//被邀请人
	if beInviteUser, err = p.DataCache.GetImpl().PartnerMgModel.FindOne(ctx, bson.M{"user_id": userId}); err != nil {
		logger.Errorf(ctx, "UseInviteCode:Be inviteUser not found or err: %v", err)
		return nil, errorcode.PartnerGetBeInviterError
	}
	if beInviteUser == nil {
		beInviteUser = &pbmgdb.PartnerMgDbModel{
			UserId:     userId,
			CreateTime: time.Now().UnixMilli(),
		}
		if err := p.DataCache.GetImpl().PartnerMgModel.Create(ctx, beInviteUser); err != nil {
			return nil, errorcode.PartnerCreateError
		}
	}

	//不能邀请自己
	if beInviteUser.InviteCode == req.InviteCode {
		return nil, errorcode.PartnerInviteYouSelfError
	}

	//已绑定
	if beInviteUser.IsInvited {
		return nil, errorcode.PartnerHasBeenInvited
	}

	//创建邀请
	if err := p.DataCache.GetImpl().PartnerInviteMgModel.Create(ctx, &pbmgdb.PartnerInviteMgDbModel{
		UserId:       userId,
		InviteUserId: inviteUser.UserId,
		InviteCode:   req.InviteCode,
		CreateTime:   time.Now().UnixMilli(),
	}); err != nil {
		logger.Errorf(ctx, "UseInviteCode:PartnerInviteMgModel:create:error: %v", err)
		return nil, errorcode.PartnerInitError
	}
	//绑定
	if err := p.DataCache.GetImpl().PartnerMgModel.UpdateOne(ctx, bson.M{"_id": beInviteUser.InviteCode}, bson.M{"is_invited": true}); err != nil {
		logger.Errorf(ctx, "bind error: %v, beInviteUser.InviteCode", err, beInviteUser.InviteCode)
		return nil, errorcode.PartnerBindError
	}

	//已经是合伙人
	if inviteUser.IsPartner {
		return &pbuserapi.UseInviteCodeResp{}, nil
	}

	//邀请人：是否成为合伙人/奖励红包
	if err := p.inviterPartner(ctx, inviteUser); err != nil {
		return nil, err
	}

	return &pbuserapi.UseInviteCodeResp{}, nil
}

// 合伙人/ 奖励
func (p *PartnerMng) inviterPartner(ctx context.Context, inviteUser *pbmgdb.PartnerMgDbModel) error {
	var (
		inviteStages = config.ServerConfig.PartnerConfig.InviteStages
		isPartner    = false
		invitePopup  = true
		partnerPopup = false
	)

	//已邀请人数
	invitedNum := uint32(p.DataCache.GetImpl().PartnerInviteMgModel.CountByCondition(ctx, bson.M{"invite_user_id": inviteUser.UserId}))
	for _, v := range inviteStages {
		if invitedNum == v.TotalPeopleNum {
			//邀请奖励
			if err := p.inviteRedPacket(ctx, inviteUser.UserId, float64(v.Reward)/float64(100)); err != nil {
				logger.Errorf(ctx, "inviterPartner:inviteRedPacket, invertUserId: %d, amount: %v, error: %v", v.Reward, err)
				return errorcode.PartnerInviteRewardError
			}
			//成为合伙人
			if invitedNum == config.ServerConfig.PartnerConfig.NeedInviteNum {
				isPartner = true
				partnerPopup = true
				invitePopup = false
			}
			break
		}
	}

	if err := p.DataCache.GetImpl().PartnerMgModel.UpdateOne(ctx,
		bson.M{"_id": inviteUser.InviteCode},
		bson.M{
			"partner_popup": partnerPopup,
			"invite_popup":  invitePopup,
			"is_partner":    isPartner,
			"update_time":   time.Now().UnixMilli(),
		}); err != nil {
		logger.Errorf(ctx, "inviterPartner:PartnerInviteMgModel:UpdateOne error: %v", err)
		return errorcode.PartnerUpdateInviterError
	}

	//成为合伙人后，如果今天已签到，写入合伙人签到
	if isPartner {
		//超过22点不再记录合伙人签到
		if timex.Now().Hour() >= int(config.ServerConfig.PartnerConfig.DrawingTime) {
			return nil
		}

		signed := p.DataCache.GetImpl().GetUserDailySign(ctx, inviteUser.UserId)
		if false == signed {
			return nil
		}

		day := timex.DateFormat(time.Now(), "Ymd")
		if err := p.DataCache.GetImpl().PartnerDailySignInMgModel.UpdateOne(ctx,
			bson.M{
				"user_id": inviteUser.UserId,
				"day":     day,
			},
			&pbmgdb.PartnerDailySignInMgDbModel{
				UserId:     inviteUser.UserId,
				Day:        day,
				IsAward:    false,
				CreateTime: time.Now().UnixMilli(),
			},
			options.Update().SetUpsert(true),
		); err != nil {
			logger.Errorf(ctx, "UserCenterMng:PartnerSignIn error: %v", err)
			return nil
		}
	}

	return nil
}

// 邀请奖励/钱包消息
func (p *PartnerMng) inviteRedPacket(ctx context.Context, userId int64, reward float64) error {
	sc := content_mng.NewSuperiorContentInstance(&content_mng.ContentMng{
		DataCache:  p.DataCache,
		KafkaProxy: p.KafkaProxy,
	}, nil, userId)

	//奖励
	if err := sc.WriteNewItem(ctx, 0, userId, "", reward, model.PartnerInviteReward); err != nil {
		logger.Errorf(ctx, "PartnerMng:inviteRedPacket:WriteNewItem error: %v", err)
		return err
	}

	//钱包消息
	go func() {
		defer func() {
			if err := recover(); err != nil {
				logger.Errorf(ctx, "PartnerMng:inviteRedPacket:SendWalletMsg:recover err: %v", err)
			}
		}()

		canWithdrawAward, _ := p.ContentMng.GetCanWithdrawAwardByUserId(ctx, userId)
		msgData := &pbapi.Wallet{
			Type:       proto.Int32(const_busi.WalletMsgTypeAward),
			Amount:     proto.String(strconv.FormatFloat(reward, 'f', 2, 64)),
			Balance:    proto.String(strconv.FormatFloat(canWithdrawAward, 'f', 2, 64)),
			Desc:       proto.String("合伙人计划-邀新好礼"),
			CreateTime: proto.Int64(time.Now().UnixMilli()),
		}
		if err := p.ContentMng.SendWalletMsg(ctx, userId, int32(pbconst.MessageTypeEnum_msg_type_wallet_award_notice), "您有一笔奖励金入账，快去看看吧！", msgData); err != nil {
			logger.Errorf(ctx, "PartnerMng:inviteRedPacket:sendWalletMsg error: %v", err)
			return
		}
	}()

	return nil
}

// 用户合伙人标签
func (p *PartnerMng) GetPartnerLabel(ctx context.Context, userId int64) ([]*pbapi.LabelItem, error) {
	resp := make([]*pbapi.LabelItem, 0)
	partner, err := p.DataCache.GetImpl().PartnerMgModel.FindOne(ctx, bson.M{"user_id": userId, "is_partner": true})
	if err != nil || partner == nil {
		return resp, nil
	}

	resp = append(resp, &pbapi.LabelItem{
		Text:        "合伙人",
		TextColor:   "#FFFFFF",
		BgColors:    []string{"#FFB700", "#FF8100"},
		Orientation: 1,
	})

	return resp, nil
}

// 广告红包总和
func (p *PartnerMng) sumAdReward(ctx context.Context) float64 {
	timeStart := timex.DayStart(timex.Now().SubDay(1).T()).UnixMilli()
	timeEnd := timex.DayStart(time.Now()).UnixMilli()

	pipeline := []bson.M{
		{"$match": bson.M{
			"create_time": bson.M{"$gte": timeStart, "$lt": timeEnd},
			"type":        bson.M{"$in": []int{model.AwardSportAd, model.AwardStarSignAd, model.AwardSignAd}},
		}},
		{"$group": bson.M{
			"_id":   nil,
			"total": bson.M{"$sum": "$award"},
		}},
	}
	cursor, err := p.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.Aggregate(ctx, pipeline)
	if err != nil {
		logger.Errorf(ctx, "get ad reward error: %v", err)
		return 0
	}

	type item struct {
		Total float64 `bson:"total"`
	}

	var data []item
	for cursor.Next(ctx) {
		v := item{}
		err = cursor.Decode(&v)
		data = append(data, v)
	}

	total := float64(0)
	if len(data) == 0 {
		return total
	}

	for _, v := range data {
		total += v.Total
	}

	_ = cursor.Close(ctx)

	return total
}

// 获取瓜分奖励
func (p *PartnerMng) getCarveUpAmount(ctx context.Context, userId int64) uint64 {
	if timex.Now().Hour() < int(config.ServerConfig.PartnerConfig.DrawingTime) {
		return 0
	}

	v, err := p.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.FindOne(ctx,
		bson.M{
			"user_id": userId,
			"type":    model.PartnerCarveUp,
			"create_time": bson.M{
				"$gte": timex.DayStart(time.Now()).UnixMilli(),
				"$lte": timex.DayEnd(time.Now()).UnixMilli(),
			},
		}, &options.FindOneOptions{Sort: bson.M{"create_time": -1}})
	if err != nil {
		return 0
	}

	if amount := uint64(v.GetAward() * 100); amount > 0 {
		return amount
	}
	return 0
}
