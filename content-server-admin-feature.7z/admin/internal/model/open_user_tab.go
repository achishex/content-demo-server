package model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"context"
	"gorm.io/gorm"
)

type IOpenUserDbModelModel interface {
	ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbapi.OpenUserDbModel, error)
	GetByUserId(ctx context.Context, userId int64) (*pbapi.OpenUserDbModel, error)
	ExistsByOpenId(ctx context.Context, openId string) bool
	UpdateByCond(ctx context.Context, userId int64, updates *pbapi.OpenUserDbModel) error
	Insert(ctx context.Context, model *pbapi.OpenUserDbModel) error
	Delete(ctx context.Context, userId int64) bool
}

type OpenUserDbModelImpl struct {
	DB *gorm.DB
}

func NewOpenUserDbModelImpl(db *gorm.DB) IOpenUserDbModelModel {
	return &OpenUserDbModelImpl{DB: db}
}

func (impl *OpenUserDbModelImpl) ListItemsByCondition(ctx context.Context,
	condition map[string]interface{}, page uint64, size uint64) ([]*pbapi.OpenUserDbModel, error) {
	offset := (page - 1) * size
	var items []*pbapi.OpenUserDbModel
	result := impl.DB.WithContext(ctx).Table("open_user").
		Limit(int(size)).Offset(int(offset)).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *OpenUserDbModelImpl) GetByUserId(ctx context.Context, userId int64) (*pbapi.OpenUserDbModel, error) {
	var openUser *pbapi.OpenUserDbModel
	if err := impl.DB.WithContext(ctx).Table("open_user").Where("app_flag = 5 AND open_type = 1 AND user_id = ?", userId).Take(&openUser).Error; err != nil {
		return nil, err
	}

	return openUser, nil
}

func (impl *OpenUserDbModelImpl) UpdateByCond(ctx context.Context, userId int64, updates *pbapi.OpenUserDbModel) error {
	if err := impl.DB.WithContext(ctx).Table("open_user").Where("app_flag = 5 AND open_type = 1 AND user_id = ?", userId).Updates(updates).Error; err != nil {
		return err
	}
	return nil
}

func (impl *OpenUserDbModelImpl) ExistsByOpenId(ctx context.Context, openId string) bool {
	var c int64
	if err := impl.DB.WithContext(ctx).Table("open_user").Where("app_flag = 5 AND open_type = 1 AND openid = ?", openId).Count(&c).Error; err != nil {
		return false
	}

	if c > 0 {
		return true
	}

	return false
}

func (impl *OpenUserDbModelImpl) Insert(ctx context.Context, model *pbapi.OpenUserDbModel) error {
	if err := impl.DB.WithContext(ctx).Table("open_user").Create(model).Error; err != nil {
		return err
	}

	return nil
}

func (impl *OpenUserDbModelImpl) Delete(ctx context.Context, userId int64) bool {
	if err := impl.DB.WithContext(ctx).Table("open_user").Where("app_flag = 5 AND open_type = 1 AND user_id = ?", userId).Delete(&pbapi.OpenUserDbModel{}).Error; err != nil {
		return false
	}

	return true
}
