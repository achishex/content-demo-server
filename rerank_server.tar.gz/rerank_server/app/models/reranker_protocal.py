from typing import List
from pydantic import BaseModel
from typing import Optional



class QADocItem(BaseModel):
    question: str
    answer: str
class RerankRequestModel(BaseModel):
    reqId: str ### request id
    query: str  ## fieldName: "query"
    onlyAnswerDocs: Optional[List[str]]=None  ## fieldName: "onlyAnswerDocs"
    qaDocs: Optional[List[QADocItem]]=None    ## fieldName: "qaDocs"
    queryType: int  ## 0: only answer; 1: question+answer  ## fieldName: "queryType"
    
class RerankOnlyAnswerResponseModel(BaseModel):
    text: str
    score: float
class RerankQuestionAnswrResponseModel(BaseModel):
    question: str
    answer: str
    score: float

class RerankResponseModel(BaseModel):
    onlyAnswer: Optional[List[RerankOnlyAnswerResponseModel]] = None
    questionAnswer: Optional[List[RerankQuestionAnswrResponseModel]] =None
    class Config:
        # 当字段为 None 时不包含在序列化结果中
        exclude_none = True

##
class RetrieveSimilarQRequestModel(BaseModel):
    language: str
    reqId: str
    query: str
    topK: Optional[int]=3


class RetrieveQSimilarQRspItem(BaseModel):
    question: str
    answer: str
    score: float
class RetrieveSimilarQResponseModel(BaseModel):
    similarQAList: List[RetrieveQSimilarQRspItem]