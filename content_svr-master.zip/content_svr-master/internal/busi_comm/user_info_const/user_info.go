package user_info_const

const (
	_ int32 = iota
	GenderBoy
	GenderGirl
)
