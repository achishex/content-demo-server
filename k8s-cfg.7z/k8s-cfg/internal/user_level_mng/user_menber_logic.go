package user_level_mng

import (
	"content_svr/protobuf/pbmgdb"
	"github.com/gin-gonic/gin"
)

func (p *UserLevelMng) GetUserMemberInfoLogic(
	ctx *gin.Context, userId int64) (
	data []*pbmgdb.SecretMemberInfoMgDbModel, err error) {

	return p.DataCache.GetImpl().SecretMemberInfoMgModel.QueryByUserId(ctx, userId)
}
