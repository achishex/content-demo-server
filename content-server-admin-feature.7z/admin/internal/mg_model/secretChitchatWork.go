package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type ISecretChitchatWorkMgDbModel interface {
	Insert(ctx context.Context, item *pbmgdb.SecretChitchatWorkMgDbModel) error
	UpdateDictById(ctx context.Context, id int64, update map[string]interface{}, incDict map[string]int) error
}

type SecretChitchatWorkMgDbImpl struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretChitchatWorkMgModelImpl(db *mongo.Database) ISecretChitchatWorkMgDbModel {
	return &SecretChitchatWorkMgDbImpl{
		MgDB:  db,
		Table: "secretChitchatWork",
	}
}

func (impl *SecretChitchatWorkMgDbImpl) Insert(ctx context.Context, item *pbmgdb.SecretChitchatWorkMgDbModel) error {
	collection := impl.MgDB.Collection(impl.Table)
	_, err := collection.InsertOne(ctx, item)
	//print(result, err)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretChitchatWorkMgDbImpl.Insert  failed. item=%v",
			item), err)
	}
	return err
}

func (impl *SecretChitchatWorkMgDbImpl) UpdateDictById(ctx context.Context, id int64,
	updateDict map[string]interface{}, incDict map[string]int) error {
	if len(updateDict)+len(incDict) == 0 {
		return nil
	}
	collection := impl.MgDB.Collection(impl.Table)
	updates := bson.D{}
	if len(updateDict) > 0 {
		updates = append(updates, bson.E{"$set", updateDict})
	}
	if len(incDict) > 0 {
		updates = append(updates, bson.E{"$inc", incDict})
	}

	_, err := collection.UpdateByID(ctx, id, updates)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretChitchatWorkMgDbModel.UpdateDictById  failed. id=%v, updateDict=%v, incDict=%v",
			id, updateDict, incDict), err)
	}
	return err
}
