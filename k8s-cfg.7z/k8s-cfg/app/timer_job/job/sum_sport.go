package job

import (
	"content_svr/config"
	"content_svr/internal/content_mng"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"time"
)

func TimerSportFish(dataOp content_mng.IContentMng, cfg *config.SportActivityTimeConfig) {
	go func() {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf(context.Background(), "catch err: %v", e)
				return
			}
		}()

		now := time.Now()
		duration := calcWorkTime(cfg, now).Sub(now) // 下一次执行时间
		ticker := time.NewTicker(duration)
		//ticker := time.NewTicker(time.Second)
		for {

			select {
			case <-ticker.C:
				now = time.Now()
				ticker.Reset(time.Second * 5)
				activityNums := getActivityNums(cfg, now)
				if ok := updateSportStatus(dataOp, activityNums); ok {
					// 成功操作定时器后，更新下一次可定时器执行时间
					logger.Info(context.Background(), fmt.Sprintf("已开奖%d", activityNums))
					ticker.Reset(calcWorkTime(cfg, now).Sub(now))
				} else {
					logger.Error(context.Background(), fmt.Sprintf("开奖失败: 本期应该开奖 %d", activityNums), nil)
				}

			}
		}

	}()

}

func calcWorkTime(cfg *config.SportActivityTimeConfig, now time.Time) time.Time {
	var workStartTime = time.Date(now.Year(), now.Month(), now.Day(), cfg.OpenHour, cfg.OpenMinter, 0, 0, now.Location())
	if now.After(workStartTime) {
		workStartTime = time.Date(now.Year(), now.Month(), now.Day()+1, cfg.OpenHour, cfg.OpenMinter, 0, 0, now.Location())
	}
	return workStartTime
}

func getActivityNums(cfg *config.SportActivityTimeConfig, date time.Time) int64 {
	return time.Date(date.Year(), date.Month(), date.Day(),
		cfg.ActivityOpenHour, cfg.ActivityOpenMinter,
		0, 0, date.Location()).Add(-time.Hour * 24).UnixMilli()
}

func updateSportStatus(dataOp content_mng.IContentMng, activityNums int64) bool {
	totalFishNums, totalStepNums, totalUserNums, err := dataOp.QueryTotalFishAndStepNums(context.Background(), activityNums)
	logger.Infof(context.Background(),
		"begin to load total fish and user nums, now: %v, total fish nums: %v, total step num: %v",
		time.Now(), totalFishNums, totalStepNums)
	if err != nil {
		logger.Error(context.Background(), "QueryTotalFishAndStepNums error:", err)
		return false
	}
	if totalUserNums == 0 {
		// 没人任何人参加
		return true
	}

	err = dataOp.UpdateFishNumsForAllUser(context.Background(), activityNums, totalFishNums, totalStepNums, totalUserNums)
	if err != nil {
		logger.Error(context.Background(), "UpdateFishNumsForAllUser error:", err)
		return false
	}

	return true
}
