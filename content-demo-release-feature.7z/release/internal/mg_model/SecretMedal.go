package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

//secretMeme
// SecretMeme

type ISecretMemeMgModel interface {
	GetById(ctx context.Context, id int64) (*pbmgdb.SecretMemeMgDbModel, error)
	DictByIds(ctx context.Context, ids []int64) (map[int64]*pbmgdb.SecretMemeMgDbModel, error)
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretMemeMgDbModel, error)
	//UpdateItem(ctx context.Context, model *pbapi.SecretMemeMgDbModel) (*pbapi.SecretMemeMgDbModel, error)
	//CreateItem(ctx context.Context, model *pbapi.SecretMemeMgDbModel) (*pbapi.SecretMemeMgDbModel, error)
	//ListItemOffset(ctx context.Context, condition map[string]interface{}, offsetId int, size int) ([]*pbapi.SecretMemeMgDbModel, error)
	//ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbapi.SecretMemeMgDbModel, error)
	//CountItemsByCondition(ctx context.Context, condition map[string]interface{}) (total int64, _ error)
}

type SecretMemeMgDbImpl struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretMemeMgModelImpl(db *mongo.Database) ISecretMemeMgModel {
	return &SecretMemeMgDbImpl{
		MgDB:  db,
		Table: "secretMeme",
	}
}

func (impl *SecretMemeMgDbImpl) GetById(ctx context.Context, id int64) (*pbmgdb.SecretMemeMgDbModel, error) {
	retItems := make([]*pbmgdb.SecretMemeMgDbModel, 0)
	collection := impl.MgDB.Collection(impl.Table)
	find, err := collection.Find(ctx, bson.M{"_id": id})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretMemeMgDbModel Find failed. id=%v",
			id), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbmgdb.SecretMemeMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretMemeMgDbModel failed.id=%v",
				id), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	if len(retItems) > 1 {
		logger.Error(ctx, fmt.Sprintf("get SecretMemeMgDbModel failed.id=%v",
			id), err)
	}
	return retItems[0], err
}

// 查不到返回nil
func (impl *SecretMemeMgDbImpl) DictByIds(ctx context.Context, ids []int64) (map[int64]*pbmgdb.SecretMemeMgDbModel, error) {
	retDict := make(map[int64]*pbmgdb.SecretMemeMgDbModel)
	if len(ids) == 0 {
		return retDict, nil
	}

	retItems := make([]*pbmgdb.SecretMemeMgDbModel, 0)
	collection := impl.MgDB.Collection("SecretMeme")
	find, err := collection.Find(ctx, bson.M{"_id": bson.D{{"$in", ids}}}) // todo
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretMemeMgDbModel Find failed.ids=%v",
			ids), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbmgdb.SecretMemeMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretMemeMgDbModel failed.ids=%v",
				ids), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}

	for _, retItem := range retItems {
		retDict[retItem.GetId()] = retItem
	}
	return retDict, err
}

func (impl *SecretMemeMgDbImpl) Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretMemeMgDbModel, error) {
	collection := impl.MgDB.Collection(impl.Table)
	find, err := collection.Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	retItems := make([]*pbmgdb.SecretMemeMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.SecretMemeMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretMemeMgDbImpl failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}
