package money

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"context"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"sort"
	"strings"
	"time"
)

type GameMonthLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGameMonthLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GameMonthLogic {
	return &GameMonthLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *GameMonthLogic) GameMonth(req *types.GameMonthReq) (resp *types.GameMonthResp, err error) {
	monthMap := map[string]types.GameMonthGameInfo{}
	gameStatisticalList, err := l.svcCtx.ReadDB.GameStatistical.FindAll(l.ctx, nil)
	for _, statistical := range gameStatisticalList {
		day := time.UnixMilli(statistical.Day)
		date := day.Format("2006-01")
		key := fmt.Sprintf("%s_%s", date, statistical.GameId)
		if value, ok := monthMap[key]; ok {
			value.AmountSum += statistical.AmountSum
			monthMap[key] = value
		} else {
			value = types.GameMonthGameInfo{
				GameName:  statistical.GameName,
				AmountSum: statistical.AmountSum,
			}
			monthMap[key] = value
		}
	}

	keys := []string{}
	for key, _ := range monthMap {
		keys = append(keys, key)
	}

	sort.Slice(keys, func(i, j int) bool {
		return keys[i] > keys[j]
	})

	resp = &types.GameMonthResp{
		Items: make([]types.GameMonthItem, 0),
	}

	gmItem := &types.GameMonthItem{}
	for _, key := range keys {

		keyPart := strings.Split(key, "_")
		if len(keyPart) != 2 {
			return nil, nil
		}
		date := keyPart[0]
		item := monthMap[key]

		if gmItem.Date == "" {
			gmItem.Date = date
		}

		if gmItem.Date != date {
			resp.Total += gmItem.Total
			resp.Items = append(resp.Items, *gmItem)
			gmItem = &types.GameMonthItem{}
			gmItem.Date = date
			gmItem.Infos = make([]types.GameMonthGameInfo, 0)
		}

		gmItem.Total += item.AmountSum
		gmItem.Infos = append(gmItem.Infos, item)
	}
	resp.Total += gmItem.Total
	resp.Items = append(resp.Items, *gmItem)

	return resp, nil
}
