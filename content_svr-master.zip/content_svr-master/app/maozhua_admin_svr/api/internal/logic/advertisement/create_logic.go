package advertisement

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/db/mongodb/model"
	"context"
	"github.com/jinzhu/copier"
	"github.com/zeromicro/go-zero/core/logx"
)

type CreateLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewCreateLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateLogic {
	return &CreateLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *CreateLogic) Create(req *types.AppAdCreateRequest) (resp *types.AppAdCreateResponse, err error) {

	ad := model.AppAdvertisement{}
	_ = copier.Copy(&ad, req)

	//nowUnix := time.Now().UnixMilli()
	//ad.LaunchStatus = getLaunchStatus(nowUnix, ad)

	ad.Creator = req.CtxName
	_, err = l.svcCtx.WriteDB.AppAdvertisement.Insert(l.ctx, &ad)

	return
}
