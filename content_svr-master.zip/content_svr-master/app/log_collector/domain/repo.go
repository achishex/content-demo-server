package domain

import (
	"content_svr/pub/logger"
	"context"
	"github.com/a3d21/gostream/gopark"
	"github.com/samber/lo"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

func NewLogRepo(conf *Conf) (*LogRepo, error) {
	ctx := context.Background()
	mcli, err := mongo.Connect(ctx, options.Client().ApplyURI(conf.MongoURI))
	if err != nil {
		return nil, err
	}
	timeout, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	err = mcli.Ping(timeout, nil)
	if err != nil {
		return nil, err
	}

	mdb := mcli.Database(conf.MongoDatabase)

	r := &LogRepo{
		mdb: mdb,
		ch:  make(chan *LogEntity, 1),
		c:   conf,
	}
	// async
	go r.Run(ctx)

	return r, nil
}

type LogRepo struct {
	mdb *mongo.Database
	ch  chan *LogEntity
	c   *Conf
}

func (r *LogRepo) AsyncInsertLog(ctx context.Context, entity *LogEntity) error {
	r.ch <- entity
	return nil
}

func (r *LogRepo) BatchInsertLog(ctx context.Context, entities []*LogEntity) error {
	if len(entities) == 0 {
		return nil
	}

	e2 := lo.Map(entities, func(item *LogEntity, _ int) any {
		return item
	})
	now := time.Now()
	_, err := r.mdb.Collection(r.getCollectName(now)).InsertMany(ctx, e2)
	return err
}

func (r *LogRepo) Run(ctx context.Context) {
	bch := gopark.BufferChanInterval(r.ch, r.c.BatchInsertSize, time.Second*time.Duration(r.c.BatchInsertIntervalInSec))
	for entities := range bch {
		if err := r.BatchInsertLog(ctx, entities); err != nil {
			logger.Errorf(ctx, "BatchInsertLog fail, err: %v", err)
		}
		//logger.Infof(ctx, "succ insert %v log", len(entities))
	}
}

func (r *LogRepo) CreateColl(ctx context.Context, t time.Time) error {
	coll := r.getCollectName(t)
	_, err := r.mdb.Collection(coll).Indexes().CreateOne(ctx, mongo.IndexModel{
		Keys: bson.D{
			{Key: "user_id", Value: 1},
			{Key: "created", Value: 1},
		}})

	return err
}

func (r *LogRepo) getCollectName(t time.Time) string {
	return "mlog_" + t.Format("200601")
}
