package money

import (
	"content_svr/pub/utils"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"math"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type QueryMemberSumArpuLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewQueryMemberSumArpuLogic(ctx context.Context, svcCtx *svc.ServiceContext) *QueryMemberSumArpuLogic {
	return &QueryMemberSumArpuLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *QueryMemberSumArpuLogic) QueryMemberSumArpu(req *types.QueryMemberSumArpuReq) (resp *types.QueryMemberSumArpuResp, err error) {

	filter := map[string]interface{}{
		"day": bson.D{
			{"$gte", req.TimeStart},
			{"$lte", req.TimeEnd},
		},
	}

	items, err := l.svcCtx.ManagerOnlyReadDB.UserMemberStatistical.FindAll(l.ctx, filter)
	if err != nil {
		return nil, err
	}

	csjMap, err := queryCsj(l.svcCtx.ManagerOnlyReadDB, l.ctx, req.TimeStart, req.TimeEnd)
	if err != nil {
		return nil, err
	}

	filter = map[string]interface{}{
		"day": bson.D{
			{"$gte", req.TimeStart},
			{"$lte", req.TimeEnd},
		},
	}
	awardDailys, err := l.svcCtx.ManagerOnlyReadDB.SuperiorAwardDaily.FindAll(l.ctx, filter)
	if err != nil {
		return nil, err
	}
	awardDailyMap := map[int64]float64{}
	for _, daily := range awardDailys {
		awardDailyMap[daily.Day] = float64(daily.GameSum)*0.7 - float64(daily.WechatPayWithdrawSuccessSum)
	}

	result := make([]types.ArpuItem, 0)
	for _, item := range items {
		csjSum := csjMap[item.Day]
		awardDailySum := awardDailyMap[item.Day]
		day, err := utils.TimeByDay(time.UnixMilli(item.Day))
		if err != nil {
			return nil, err
		}
		filter := map[string]interface{}{
			"day": day,
		}
		channels, err := l.svcCtx.ManagerOnlyReadDB.SecretUserChannelDaily.FindAll(l.ctx, filter)
		if err != nil {
			return nil, err
		}
		activityCount := 0
		for _, channel := range channels {
			activityCount += channel.ActiveUserCount
		}

		var numerator, denominator float64

		numerator += float64(item.AndroidSum)
		numerator += float64(item.IosSum) * 0.7
		numerator += float64(csjSum)
		numerator += float64(awardDailySum)

		denominator = float64(activityCount)

		var scope float64
		if activityCount > 0 {
			scope = math.Round(numerator / denominator)
		}

		result = append(result, types.ArpuItem{
			Day:   item.Day,
			Scope: scope,
		})
	}

	resp = &types.QueryMemberSumArpuResp{List: result}

	return
}
