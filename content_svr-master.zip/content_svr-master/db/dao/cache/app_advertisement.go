package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type AppAdvertisement struct {
	model.AppAdvertisementModel
	redisManage *query_rds.Manage
}

func NewCacheAppAdvertisement(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *AppAdvertisement {
	return &AppAdvertisement{
		AppAdvertisementModel: mongo.AppAdvertisement,
		redisManage:           redisManage,
	}
}
