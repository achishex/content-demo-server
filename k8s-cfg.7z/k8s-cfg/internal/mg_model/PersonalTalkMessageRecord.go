package mg_model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type IPersonalTalkMessageRecordMgDbModel interface {
	GetById(ctx context.Context, msgId int64) (*pbapi.PersonalTalkMessageRecordMgDbModel, error)
	Insert(ctx context.Context, item *pbapi.PersonalTalkMessageRecordMgDbModel) error
	UpdateDictById(ctx context.Context, id int64, update map[string]interface{}) error
	UpdateDictByCond(ctx context.Context, cond, update map[string]interface{}) error
	ListByCondition(ctx context.Context, cond map[string]interface{}) ([]*pbapi.PersonalTalkMessageRecordMgDbModel, error)
	ListByCondWithSort(ctx context.Context, filter bson.M, sortField map[string]int32, skips, limits int32) ([]*pbapi.PersonalTalkMessageRecordMgDbModel, int64, error)
	CountByCondition(ctx context.Context, cond map[string]interface{}) (int64, error)
	CountItemsByConds(ctx context.Context, eqCond, largeCond, lessCond map[string]interface{}) (int32, error)
	AggregateUserCountByWorkIdAndToUser(ctx context.Context, workId, toUser int64) int64
}

type PersonalTalkMessageRecordMgDbImpl struct {
	MgDB  *mongo.Database
	Table string
}

func NewPersonalTalkMessageRecordMgModelImpl(db *mongo.Database) IPersonalTalkMessageRecordMgDbModel {
	return &PersonalTalkMessageRecordMgDbImpl{
		MgDB:  db,
		Table: "personalTalkMessageRecord",
	}
}

type ToUserIdAggregate struct {
	toUserNums int32 `bson:"to_user_total"`
}
type FromUserIdAggregate struct {
	fromUserNum int32 `bson:"from_user_total"`
}

func (impl *PersonalTalkMessageRecordMgDbImpl) ListByCondWithSort(ctx context.Context, filter bson.M, sortField map[string]int32, skips, limits int32) ([]*pbapi.PersonalTalkMessageRecordMgDbModel, int64, error) {
	if len(filter) <= 0 {
		return nil, 0, nil
	}
	collection := impl.MgDB.Collection(impl.Table)

	var sortExpand bson.D
	opts := options.Find()
	for k, v := range sortField {
		sortExpand = append(sortExpand, bson.E{Key: k, Value: v})
	}
	if len(sortExpand) > 0 {
		opts.SetSort(sortExpand)
	}
	if skips > 0 {
		opts.SetSkip(int64(skips))
	}
	if limits > 0 {
		opts.SetLimit(int64(limits))
	}

	count, err := collection.CountDocuments(ctx, filter)
	if err != nil {
		return nil, 0, err
	}

	cursor, err := collection.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "find fail, %v", err)
		return nil, 0, err
	}
	// 遍历查询结果
	var result []*pbapi.PersonalTalkMessageRecordMgDbModel
	for cursor.Next(ctx) {
		item := &pbapi.PersonalTalkMessageRecordMgDbModel{}
		// 解码绑定数据
		err = cursor.Decode(item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to talk message record failed.err=%v", err), err)
			return nil, 0, err
		}
		result = append(result, item)
	}
	return result, count, nil
}
func (impl *PersonalTalkMessageRecordMgDbImpl) CountItemsByConds(ctx context.Context, eqCond, largeCond, lessCond map[string]interface{}) (int32, error) {
	coll := impl.MgDB.Collection(impl.Table)
	filter := bson.D{}
	for k, v := range eqCond {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	for k, v := range largeCond {
		filter = append(filter, bson.E{k, bson.D{{"$gt", v}}})
	}
	for k, v := range lessCond {
		filter = append(filter, bson.E{k, bson.D{{"$lt", v}}})
	}
	pipeline := []bson.M{
		{"$match": filter},
		{"$project": bson.M{"toUserId": true}},
		{"$group": bson.M{"_id": "$toUserId"}},
		{"$group": bson.M{
			"_id":           nil,
			"to_user_total": bson.M{"$sum": 1},
		}},
	}
	//
	result := &ToUserIdAggregate{}
	cur, err := coll.Aggregate(ctx, pipeline)
	if err != nil {
		logger.Errorf(ctx, "not find toUserId nums in %v", impl.Table)
		return 0, err
	}

	if !cur.Next(ctx) {
		return 0, nil
	}

	err = cur.Decode(&result)
	if err != nil {
		logger.Errorf(ctx, "total to user error: %v", err)
		return 0, err
	}

	return result.toUserNums, nil
}

// 查不到返回nil
func (impl *PersonalTalkMessageRecordMgDbImpl) GetById(ctx context.Context, msgId int64) (*pbapi.PersonalTalkMessageRecordMgDbModel, error) {
	retItems := make([]*pbapi.PersonalTalkMessageRecordMgDbModel, 0)
	collection := impl.MgDB.Collection(impl.Table)
	find, err := collection.Find(ctx, bson.M{"_id": msgId})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PersonalTalkMessageRecordMgDbModel Find failed.msgId=%v",
			msgId), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.PersonalTalkMessageRecordMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to PersonalTalkMessageRecordMgDbModel failed.msgId=%v",
				msgId), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	if len(retItems) > 1 {
		logger.Error(ctx, fmt.Sprintf("get PersonalTalkMessageRecordMgDbModel failed.msgId=%v",
			msgId), err)
	}
	return retItems[0], nil
}

func (impl *PersonalTalkMessageRecordMgDbImpl) ListByCondition(ctx context.Context,
	cond map[string]interface{}) ([]*pbapi.PersonalTalkMessageRecordMgDbModel, error) {
	collection := impl.MgDB.Collection(impl.Table)
	find, err := collection.Find(ctx, cond)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PersonalTalkMessageRecordMgDbModel ListByCondition failed. cond=%v",
			cond), err)
		return nil, err
	}
	retItems := make([]*pbapi.PersonalTalkMessageRecordMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbapi.PersonalTalkMessageRecordMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to PersonalTalkMessageRecordMgDbModel failed.cond=%v",
				cond), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (impl *PersonalTalkMessageRecordMgDbImpl) Insert(ctx context.Context, item *pbapi.PersonalTalkMessageRecordMgDbModel) error {
	collection := impl.MgDB.Collection(impl.Table)
	_, err := collection.InsertOne(ctx, item)
	return err
}

func (impl *PersonalTalkMessageRecordMgDbImpl) UpdateDictById(ctx context.Context, id int64, update map[string]interface{}) error {
	collection := impl.MgDB.Collection(impl.Table)
	_, err := collection.UpdateByID(ctx, id, update)
	return err
}

func (impl *PersonalTalkMessageRecordMgDbImpl) UpdateDictByCond(ctx context.Context, cond, update map[string]interface{}) error {
	collection := impl.MgDB.Collection(impl.Table)
	if len(update) == 0 || len(cond) == 0 {
		return nil
	}

	mgUpdates := bson.D{}
	if len(update) > 0 {
		mgUpdates = append(mgUpdates, bson.E{"$set", update})
	}
	_, err := collection.UpdateMany(ctx, cond, mgUpdates)
	return err
}

func (impl *PersonalTalkMessageRecordMgDbImpl) CountByCondition(ctx context.Context, cond map[string]interface{}) (int64, error) {
	collection := impl.MgDB.Collection(impl.Table)
	total, err := collection.CountDocuments(ctx, cond)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PersonalTalkMessageRecordMgDbModel CountByCondition failed. cond=%v",
			cond), err)
		return 0, err
	}
	return total, nil
}

func (impl *PersonalTalkMessageRecordMgDbImpl) AggregateUserCountByWorkIdAndToUser(ctx context.Context, workId, toUser int64) int64 {
	collection := impl.MgDB.Collection(impl.Table)

	filter := bson.D{
		{
			"workId", bson.D{
				{"$eq", workId},
			},
		},
	}
	pipeline := []bson.M{
		{"$match": filter},
		{"$group": bson.M{
			"_id":                  bson.M{"toUserId": "$toUserId", "workId": "$workId"},
			"uniqueFromUsersCount": bson.M{"$addToSet": "$fromUserId"},
		},
		},
		{"$project": bson.M{
			"_id":   0,
			"count": bson.M{"$size": "$uniqueFromUsersCount"},
		}},
	}

	cur, err := collection.Aggregate(ctx, pipeline)
	if err != nil {
		logger.Error(ctx, "AggregateUserCountByWorkIdAndToUser.Aggregate", err)
		return 0
	}

	var count int32
	for cur.Next(ctx) {
		var m map[string]interface{}
		err := cur.Decode(&m)
		if err != nil {
			logger.Error(ctx, "AggregateUserCountByWorkIdAndToUser.Aggregate.Decode", err)
			continue
		}
		count = m["count"].(int32)
	}

	return int64(count)
}
