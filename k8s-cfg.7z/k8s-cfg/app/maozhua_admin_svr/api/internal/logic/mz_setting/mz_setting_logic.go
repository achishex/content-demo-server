package mz_setting

import (
	"content_svr/setting"
	"context"
	"sort"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type MzSettingLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewMzSettingLogic(ctx context.Context, svcCtx *svc.ServiceContext) *MzSettingLogic {
	return &MzSettingLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *MzSettingLogic) MzSetting(_ *types.MzSettingReq) (resp interface{}, err error) {
	var m map[string]setting.MaozhuaSettingRecord
	m, err = l.svcCtx.Maozhua.GetAllSetting()
	if err != nil {
		return nil, err
	}

	result := map[string][]setting.MaozhuaSettingRecord{}

	for _, record := range m {
		records, ok := result[record.Category]
		if !ok {
			records = make([]setting.MaozhuaSettingRecord, 0)
		}
		records = append(records, record)
		result[record.Category] = records
	}

	for key, records := range result {
		sort.Slice(records, func(i, j int) bool {
			return records[i].Field < records[j].Field
		})
		result[key] = records
	}

	resp = result

	return
}
