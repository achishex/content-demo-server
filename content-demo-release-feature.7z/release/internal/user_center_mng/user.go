package user_center_mng

import (
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/middleware"
	"content_svr/pub/snow_flake"
	"context"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/kevwan/mapreduce/v2"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

func (u *UserCenterMng) ActiveUser(ctx context.Context, userId int64, nickName string) error {
	var activeUserColl = u.DataCache.GetImpl().SecretActiveUserMgModel

	au, err := activeUserColl.Get(ctx, bson.M{"user_id": userId})
	if err != nil {
		return err
	}

	if au != nil {
		if err := activeUserColl.UpdateOne(ctx,
			bson.M{"_id": au.Id},
			map[string]any{
				"nickname":        nickName,
				"last_login_time": time.Now().UnixMilli(),
			},
		); err != nil {
			return err
		}
	} else {
		if err := activeUserColl.Create(ctx, &pbmgdb.SecretActiveUserMgDbModel{
			Id:            snow_flake.GetSnowflakeID(),
			UserId:        userId,
			Nickname:      nickName,
			CreateTime:    time.Now().UnixMilli(),
			LastLoginTime: time.Now().UnixMilli(),
		}); err != nil {
			return err
		}
	}

	return nil
}

func (u *UserCenterMng) SearchByNickname(ctx context.Context, req *pbuserapi.UserSearchReq) (*pbuserapi.UserSearchResp, error) {
	var (
		resp = &pbuserapi.UserSearchResp{
			List: make([]*pbuserapi.FollowItem, 0),
		}

		limit          = int64(50)
		finalLimit     = int64(10)
		page           = int64(1)
		count          = int64(0)
		curUserId      = middleware.GetUserID(ctx.(*gin.Context))
		activeUserColl = u.DataCache.GetImpl().SecretActiveUserMgModel
	)

	for {
		if count == finalLimit {
			break
		}

		skip := (page - 1) * limit
		timeRange := time.Now().AddDate(0, 0, -15).UnixMilli()
		list, err := activeUserColl.Find(ctx,
			bson.M{
				"nickname": bson.M{
					"$regex": primitive.Regex{
						Pattern: fmt.Sprintf(".*%s.*", req.Nickname),
						Options: "ig",
					},
				},
				"last_login_time": bson.M{
					"$gte": timeRange,
				},
			},
			&options.FindOptions{
				Limit: &limit,
				Skip:  &skip,
				Sort:  bson.D{{"last_login_time", -1}},
			})
		if err != nil || len(list) == 0 {
			break
		}
		fmt.Println(len(list))
		for _, user := range list {
			var (
				userInfo    *data_cache.UserInfoLocal
				stat        *pbuserapi.FollowStatusResp
				talkMode    int32
				continueErr = errors.New("continue")
			)

			if err := mapreduce.Finish(func() error {
				userInfo, err = u.DataCache.GetUserInfoLocal(ctx, nil, user.UserId, true)
				if userInfo == nil || *userInfo.UserInfoDbModel.Status == 0 || err != nil {
					return continueErr
				}
				return nil
			}, func() error {
				talkMode = u.DataCache.GetUserInfoTalkMode(ctx, user.UserId)
				return nil
			}, func() error {
				if u.DataCache.CheckUserBlackListMgDBLD(ctx, curUserId, user.UserId) {
					return continueErr
				}
				return nil
			}, func() error {
				//在对方的拉黑名单中
				if u.DataCache.CheckUserBlackListMgDBLD(ctx, user.UserId, curUserId) {
					return continueErr
				}
				return nil
			}, func() error {
				//关注状态
				stat, _ = u.getFollowStat(ctx, curUserId, user.UserId)
				return nil
			}); err == continueErr {
				continue
			}

			fi := &pbuserapi.FollowItem{
				Id:        user.Id,
				Timestamp: user.LastLoginTime,
				UserId:    userInfo.UserInfoDbModel.GetUserId(),
				User: &pbuserapi.FollowUser{
					UserId:     userInfo.UserInfoDbModel.GetUserId(),
					NickName:   userInfo.UserInfoDbModel.GetNickName(),
					Photo:      userInfo.UserInfoDbModel.GetPhoto(),
					Gender:     userInfo.UserInfoDbModel.GetGender(),
					MemberType: userInfo.MemberType,
					UserType:   userInfo.UserInfoDbModel.GetUserType(),
					Ulevel:     userInfo.PsecretUserExtInfo.GetUlevel(),
					TalkMode:   talkMode,
				},
				Stat: &pbuserapi.FollowStat{
					FollowMe: stat.FollowMe,
					MeFollow: stat.MeFollow,
				},
				WorkId: u.getLastWorkByCache(ctx, user.UserId),
				Badge:  false,
			}

			//勋章
			if len(userInfo.UserMedals) > 0 {
				for _, item := range userInfo.UserMedals {
					fi.User.Medals = append(fi.User.Medals, &pbuserapi.FollowMedals{
						Expire:    item.Expire,
						Icon:      item.Icon,
						MedalId:   item.MedalId,
						MedalName: item.MedalName,
						SmallIcon: item.SmallIcon,
						Timestamp: item.Timestamp,
					})
				}
			}

			resp.List = append(resp.List, fi)

			count++
		}
		page++
	}

	return resp, nil
}
