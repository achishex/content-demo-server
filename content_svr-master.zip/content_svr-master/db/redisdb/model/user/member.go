package user

import (
	"content_svr/db/redisdb/model/internal"
	"context"
	"fmt"
	"time"
)

type userMember struct {
	internal.RdsInfo
}

// 0非会员 1-svip 2赠送会员 3-普通会员
func (r *userMember) getRdsKey(userId int64) string {
	return fmt.Sprintf(r.RdsKey, r.Env, userId)
}

func (r *userMember) GetUserMember(ctx context.Context, userId int64) int32 {
	rdsKey := r.getRdsKey(userId)
	result, err := r.Client.HGetAll(ctx, rdsKey).Result()
	if err != nil {
		return 0
	}

	timestamp := fmt.Sprintf("%d", time.Now().UnixMilli())
	switch {
	case result["1"] > timestamp:
		return 1
	case result["2"] > timestamp:
		return 2
	case result["3"] > timestamp:
		return 3
	default:
		return 0
	}
}

func (r *userMember) SetUserMember(ctx context.Context, userId int64, member int32, timestamp int64) error {
	rdsKey := r.getRdsKey(userId)
	return r.Client.HSet(ctx, rdsKey, member, timestamp).Err()
}
