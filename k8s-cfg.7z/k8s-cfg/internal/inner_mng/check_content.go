package inner_mng

import (
	"content_svr/config"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
)

// 通过-true。
func (p *InnerProxyImpl) CheckContent(ctx context.Context, req *pbapi.PersonalTalkCheckReq) (bool, *pbapi.PersonalTalkCheckResp, error) {
	bPass := true //默认通过。
	url := config.ServerConfig.CheckSvrHost + "/api/content/personal_talk_check"
	bodyBytes, _ := json.Marshal(req)
	resp, err := p.postRequest(ctx, url, bodyBytes)
	if err != nil {
		logger.Errorf(ctx, "personal_talk_check return err. req=%v, err=%v", req, err)
		return bPass, nil, err
	}

	if resp.StatusCode != 200 {
		logger.Errorf(ctx, "personal_talk_check httpcode!=200. req=%v,resp.StatusCode != 200", req)
		return bPass, nil, fmt.Errorf("http retcode != 200, retcode=%v", resp.Status)
	}

	innerResp := &pbapi.PersonalTalkCheckResp{}
	json.NewDecoder(resp.Body).Decode(innerResp)
	bPass = innerResp.GetIResultCode() != pbapi.IResultCodeEnum_swallow
	//logger.Infof(ctx, "personal_talk_check over, userId=%v, url=%v, innerResp=%+v", userId, url, innerResp)
	return bPass, innerResp, nil
}

// CheckPublicTxtContent 一般对外公共场景的文字检测
func (p *InnerProxyImpl) CheckPublicTxtContent(ctx context.Context, req *pbapi.PublicTxtCheckReq) (bool, *pbapi.PublicTxtCheckResp, error) {
	bPass := true //默认通过。
	url := config.ServerConfig.CheckSvrHost + "/api/content/public/text_check"
	bodyBytes, _ := json.Marshal(req)
	resp, err := p.postRequest(ctx, url, bodyBytes)
	if err != nil {
		logger.Errorf(ctx, "public_txt_check return err. req=%v, err=%v", req, err)
		return bPass, nil, err
	}

	if resp.StatusCode != 200 {
		logger.Errorf(ctx, "public_txt_check httpcode!=200. req=%v,resp.StatusCode != 200", req)
		return bPass, nil, fmt.Errorf("http retcode != 200, retcode=%v", resp.Status)
	}

	innerResp := &pbapi.PublicTxtCheckResp{}
	json.NewDecoder(resp.Body).Decode(innerResp)

	bPass = innerResp.GetIResultCode() != pbapi.IResultCodeEnum_swallow
	logger.Infof(ctx, "public_txt_check, fromUserId=%v, content=%v, innerResp=%+v, bPass %v", req.GetFromUserId(), req.GetContent(), innerResp, bPass)
	return bPass, innerResp, nil
}
