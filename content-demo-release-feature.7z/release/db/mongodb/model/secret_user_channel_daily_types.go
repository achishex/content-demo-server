package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type SecretUserChannelDaily struct {
	ID primitive.ObjectID `bson:"_id" json:"id"`

	Day                   int    `json:"day" bson:"day"`                                           // 日期
	AppType               string `json:"app_type" bson:"app_type"`                                 // 平台  Android iOS
	Channel               string `json:"channel" bson:"channel"`                                   // 渠道 (maozhua, huawei, honor, xiaomi, oppo, vivo, yyb)
	Gender                int    `json:"gender" bson:"gender"`                                     // 性别 1 男 2 女
	Market                int    `json:"market" bson:"market,omitempty"`                           //  1 推广带来的用户
	ActiveUserCount       int    `json:"active_user_count" bson:"active_user_count"`               // 活跃用户数
	ActiveTargetUserCount int    `json:"active_target_user_count" bson:"active_target_user_count"` // 有操作行为的活跃目标用户数
	NewUserCount          int    `json:"new_user_count" bson:"new_user_count"`                     // 新注册用户数量
	NewTargetUserCount    int    `json:"new_target_user_count" bson:"new_target_user_count"`       // 新注册用户有操作行为的数量

	CreateTime int64 `json:"create_time" bson:"create_time"`
}
