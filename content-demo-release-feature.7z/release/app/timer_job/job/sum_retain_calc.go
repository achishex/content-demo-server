package job

import (
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

// InitCalcRetain 每天凌晨三点整，执行计算
func InitCalcRetain(write, read *dao.ManagerDB) {
	go func() {
		retainCtl := newRetainControl(write, read)
		//retainCtl.once(write, read)
		//return

		retainCtl.Do(func() {
			ctx := requestid.WithRequestID(context.Background())
			if err := retainCtl.DoTask(ctx, time.Now()); err != nil {
				logger.Errorf(ctx, "newRetainControl.DoTask: %v", err)
				// 五分钟后重试
				retainCtl.ticker.Reset(time.Minute * 5)
				return
			}

			newCtl := newRetainControl(write, read)
			newCtl.ticker = retainCtl.ticker
			newCtl.ticker.Reset(retainCtl.calcIntervalTime())
			retainCtl = newCtl
		})

	}()

}

type retainControl struct {
	TickerExecute
	read  *dao.ManagerDB
	write *dao.ManagerDB

	page, size   int64
	channelTable map[string]*model.SecretUserChannelDaily
	channelDone  bool

	target time.Time
}

func newRetainControl(write, read *dao.ManagerDB) retainControl {
	r := retainControl{
		read:  read,
		write: write,
		page:  1,
		size:  100000, // 10万条，30mb

		channelTable: map[string]*model.SecretUserChannelDaily{},
	}

	// 次日凌晨三点整，执行计算
	r.hour = 3
	//r.hour = 13
	//r.minter = 54
	//r.second = 0
	return r

}
func (r *retainControl) notifyRobotMessage(err error) {
	// 通知机器人
	errMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("【error】%v", err),
	}
	items := []item{errMessage}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = "留存定时器出错了"
	m.Content.Post.ZhCn.Content = make([][]item, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	RobotServerControl.SendMessage(m)
	return
}

func (r *retainControl) once(write, read *dao.ManagerDB) {
	for i := 30; i > 0; i-- {
		retainCtl := newRetainControl(write, read)
		ctx := requestid.WithRequestID(context.Background())
		target := time.Now().AddDate(0, 0, -i)
		if err := retainCtl.DoTask(ctx, target); err != nil {
			retainCtl.notifyRobotMessage(err)
			return
		}
	}
	return
}

func (r *retainControl) DoTask(ctx context.Context, target time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "retainControl recover: %v\n", err)
		}
	}()
	r.target = target

	if err := r.saveChannel(ctx); err != nil {
		logger.Error(ctx, "saveChannel: ", err)
		return err
	}

	if len(r.channelTable) == 0 {
		logger.Errorf(ctx, "留存计算异常无渠道记录")
		return nil
	}

	if err := r.saveRetain(ctx); err != nil {
		logger.Error(ctx, "saveRetain: ", err)
		return err
	}

	logger.Infof(ctx, "%d 留存计算完成", r.baseTimeByDay(target))

	return nil
}

func (r *retainControl) uniqueKey(daily model.SecretUserActivityDaily) string {
	return fmt.Sprintf("%d-%s-%s-%d-%d", daily.Day, daily.AppType, daily.Channel, daily.Gender, daily.Market)
}

// 计算渠道表信息
func (r *retainControl) calcChannel(activityList []model.SecretUserActivityDaily) {
	for _, daily := range activityList {
		key := r.uniqueKey(daily)
		obj, ok := r.channelTable[key]
		if !ok {
			obj = &model.SecretUserChannelDaily{}
		}

		obj.AppType = daily.AppType
		obj.Channel = daily.Channel
		obj.Day = r.lastTimeByDay(r.target, 1)
		obj.Gender = daily.Gender
		obj.Market = daily.Market
		obj.ActiveUserCount++
		if daily.IsNew == 1 {
			obj.NewUserCount++
		}
		switch {
		case daily.WorkActive != 0, daily.CommentActive != 0, daily.TalkActive != 0, daily.LikeActive != 0:
			obj.ActiveTargetUserCount++
			if daily.IsNew == 1 {
				obj.NewTargetUserCount++
			}
		}

		r.channelTable[key] = obj
	}
}

func (r *retainControl) saveChannel(ctx context.Context) error {
	if r.channelDone {
		return nil
	}

	if r.page == 1 {
		r.channelTable = map[string]*model.SecretUserChannelDaily{}
	}

	//nowDay := r.nowDay()
	lastDay := r.lastTimeByDay(r.target, 1)
	filter := map[string]interface{}{
		"day": lastDay,
	}
	// 一次十万条
	for !r.channelDone {
		skip := (r.page - 1) * r.size
		opt := &options.FindOptions{}
		opt.Limit = &r.size
		opt.Skip = &skip
		// 执行今天以前的所有数据
		activityList, err := r.read.SecretUserActivityDaily.FindAll(ctx, filter, opt)
		if err != nil {
			return err
		}
		r.page++
		r.calcChannel(activityList)

		if len(activityList) < int(r.size) {
			// 少于size说明是最后一页
			break
		}
	}

	channelList := make([]*model.SecretUserChannelDaily, 0)
	for _, daily := range r.channelTable {
		filter := map[string]interface{}{
			"day":      daily.Day,
			"app_type": daily.AppType,
			"channel":  daily.Channel,
			"gender":   daily.Gender,
		}
		if daily.Market != 0 {
			filter["market"] = daily.Market
		}

		_, err := r.read.SecretUserChannelDaily.FindOne(ctx, filter)
		if err == nil {
			logger.Info(ctx, fmt.Sprintf("SecretUserChannelDaily exist: %v", filter))
			continue
		}

		channelList = append(channelList, daily)
	}
	if len(channelList) > 0 {
		_, err := r.write.SecretUserChannelDaily.InsertMany(ctx, channelList)
		if err != nil {
			r.notifyRobotMessage(err)
			return err
		}
	}

	r.channelDone = true

	return nil
}

// 计算每一天的留存记录
func (r *retainControl) calcRetain() ([]model.SecretUserRetainedStatistics, error) {
	retainList := make([]model.SecretUserRetainedStatistics, 0)

	baseDay := r.lastTimeByDay(r.target, 1)
	filter := map[string]interface{}{
		"day": baseDay,
	}
	baseDayActiveUserList, err := r.read.SecretUserActivityDaily.FindAll(context.Background(), filter)
	if err != nil {
		return nil, err
	}
	activeUserMap := map[int]model.SecretUserActivityDaily{}
	for _, daily := range baseDayActiveUserList {
		activeUserMap[daily.UserId] = daily
	}

	for i := 0; i <= 30; i++ {
		targetDay := r.lastTimeByDay(r.target, 1+i)
		channelRetainedStatistics, err := r.calRetain(baseDay, activeUserMap, targetDay)
		if err != nil {
			return nil, err
		}
		for _, statistics := range channelRetainedStatistics {
			statistics.ID = primitive.NewObjectID()
			statistics.CreateTime = time.Now().UnixMilli()
			retainList = append(retainList, statistics)
		}
	}

	return retainList, err
}

// 计算该天全渠道留存记录
func (r *retainControl) calRetain(
	baseDay int, activeUserMap map[int]model.SecretUserActivityDaily, targetDay int) (
	map[string]model.SecretUserRetainedStatistics, error) {

	filter := map[string]interface{}{
		"day": targetDay,
	}
	targetDayActiveUserList, err := r.read.SecretUserActivityDaily.FindAll(context.Background(), filter)
	if err != nil {
		return nil, err
	}

	retMap := map[string]model.SecretUserRetainedStatistics{}

	for _, daily := range targetDayActiveUserList {
		if _, ok := activeUserMap[daily.UserId]; ok {
			key := r.uniqueKey(daily)
			var staticsModel model.SecretUserRetainedStatistics
			if tmp, ok := retMap[key]; ok {
				staticsModel = tmp
			} else {
				staticsModel = model.SecretUserRetainedStatistics{
					Channel:                 daily.Channel,
					AppType:                 daily.AppType,
					Day:                     targetDay,
					Gender:                  daily.Gender,
					Market:                  daily.Market,
					RetainType:              r.subTimeByDay(baseDay, targetDay),
					NewRetainCount:          0,
					ActiveRetainCount:       0,
					NewTargetRetainCount:    0,
					ActiveTargetRetainCount: 0,
				}
			}

			if daily.IsNew == 1 {
				staticsModel.NewRetainCount++
				if daily.LikeActive > 0 || daily.CommentActive > 0 || daily.TalkActive > 0 || daily.WorkActive > 0 {
					staticsModel.NewTargetRetainCount++
				}
			}

			staticsModel.ActiveRetainCount++
			if daily.LikeActive > 0 || daily.CommentActive > 0 || daily.TalkActive > 0 || daily.WorkActive > 0 {
				staticsModel.ActiveTargetRetainCount++
			}

			retMap[key] = staticsModel
		}
	}

	return retMap, nil
}

func (r *retainControl) saveRetain(ctx context.Context) error {
	retainList, err := r.calcRetain()
	if err != nil {
		return err
	}

	dataList := make([]any, 0)
	for _, retain := range retainList {
		filter := map[string]interface{}{
			"day":         retain.Day,
			"app_type":    retain.AppType,
			"channel":     retain.Channel,
			"gender":      retain.Gender,
			"retain_type": retain.RetainType,
		}
		if retain.Market != 0 {
			filter["market"] = retain.Market
		}

		_, err = r.read.SecretUserRetainedStatistics.FindOne(ctx, filter)
		if err == nil {
			logger.Info(ctx, fmt.Sprintf("SecretUserRetainedStatistics exist: %v", filter))
			continue
		}
		dataList = append(dataList, retain)
	}

	if len(dataList) == 0 {
		return nil
	}

	if _, err := r.write.SecretUserRetainedStatistics.InsertMany(ctx, dataList); err != nil {
		r.notifyRobotMessage(err)
		return err
	}

	return nil
}
