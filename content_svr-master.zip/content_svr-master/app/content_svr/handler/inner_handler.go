package handler

import (
	"content_svr/internal/content_mng"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/pub/logger"
	"github.com/gin-gonic/gin"
	"net/http"
)

func NewInternalHandler(
	cmng content_mng.IContentMng,
) *InternalHandler {
	return &InternalHandler{
		cmng: cmng,
	}
}

// InternalHandler 内部服务调用
// 使用gin标准写法
type InternalHandler struct {
	cmng content_mng.IContentMng
}

func (h *InternalHandler) Serve(addr string) error {
	r := gin.New()
	r.Use(gin.Recovery())
	v1 := r.Group("/v1")
	v1.POST("/notifyVip", h.notifyVip)

	return r.Run(addr)
}
func (h *InternalHandler) notifyVip(c *gin.Context) {
	req := &NotifyVipReq{}
	if err := c.BindJSON(req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"errmsg": "参数无效"})
		return
	}

	ctx := c.Request.Context()

	if err := h.cmng.SendWalletMsg(ctx, req.UserID, int32(pbconst.MessageTypeEnum_msg_type_wallet_business_notice), req.Content, req.Business); err != nil {
		logger.Errorf(ctx, "SendWalletMsg fail, err: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"errmsg": err.Error()})
	}

	c.JSON(http.StatusOK, gin.H{"msg": "success"})
}

type NotifyVipReq struct {
	UserID   int64           `json:"userID" binding:"required"`
	Content  string          `json:"content" binding:"required"`
	Business *pbapi.Business `json:"business" binding:"required"`
}
