package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

const SecretUserActivityDailyCollectionName = "secretUserActivityDaily"

type SecretUserActivityDaily struct {
	ID primitive.ObjectID `bson:"_id" json:"id"`

	Day           int    `json:"day" bson:"day"`                                           // 日期
	IsNew         int    `json:"is_new,omitempty" bson:"is_new,omitempty"`                 // 当天注册的新用户
	WorkActive    int    `json:"work_active,omitempty" bson:"work_active,omitempty"`       // 交互行为 发布动态
	CommentActive int    `json:"comment_active,omitempty" bson:"comment_active,omitempty"` // 交互行为 发布评论
	TalkActive    int    `json:"talk_active,omitempty" bson:"talk_active,omitempty"`       // 交互行为 发布私聊
	LikeActive    int    `json:"like_active,omitempty" bson:"like_active,omitempty"`       // 交互行为 发布点赞
	UserId        int64  `json:"user_id" bson:"user_id"`                                   // userId
	AppType       string `json:"app_type" bson:"app_type"`                                 // 平台  Android iOS
	Channel       string `json:"channel" bson:"channel"`                                   // 渠道 (maozhua, huawei, honor, xiaomi, oppo, vivo, yyb)
	Gender        int    `json:"gender" bson:"gender"`                                     // 性别 1 男 2 女
	Market        int    `json:"market" bson:"market,omitempty"`                           //  1 推广带来的用户
	Version       string `json:"version" bson:"version"`                                   // 版本号

	CreateTime int `json:"create_time,omitempty" bson:"create_time"`
	UpdateTime int `json:"update_time,omitempty" bson:"update_time"`
}

const (
	_       = iota
	SexBoy  // 男
	SexGirl // 女
)
