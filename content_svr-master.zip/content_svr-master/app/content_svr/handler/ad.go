package handler

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"github.com/gin-gonic/gin"
	"net/http"
)

func (p *AdminHandler) AdBehaviorUploadV2(ctx *gin.Context, req *pbapi.AdBehaviorUploadReqV2) (*pbapi.AdBehaviorUploadResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	resp, err := p.ContentMng.AdBehaviorUploadV2(ctx, header, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) AdVivoFeedback(ctx *gin.Context) {
	var params []*pbapi.AdVivoFeedbackDbModel
	if err := ctx.Bind(&params); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, pbapi.AdVivoFeedbackResp{
			Code: -1,
			Msg:  "操作失败",
		})

		return
	}

	logger.Infof(ctx, "receive req: %+v", params)

	resp, err := p.ContentMng.AdVivoFeedback(ctx, params)
	if err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, resp)
		return
	}

	ctx.JSON(http.StatusOK, resp)
	//ctx.JSON(http.StatusOK, gin.H{
	//	"code": 0,
	//	"msg":  "操作成功",
	//})

	return
}

func (p *AdminHandler) AdVivo2Feedback(ctx *gin.Context) {
	var params []*pbapi.AdVivoFeedbackDbModel
	if err := ctx.Bind(&params); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, pbapi.AdVivoFeedbackResp{
			Code: -1,
			Msg:  "操作失败",
		})

		return
	}

	logger.Infof(ctx, "receive req: %+v", params)

	resp, err := p.ContentMng.AdVivoFeedback(ctx, params)
	if err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, resp)
		return
	}

	ctx.JSON(http.StatusOK, resp)
	//ctx.JSON(http.StatusOK, gin.H{
	//	"code": 0,
	//	"msg":  "操作成功",
	//})

	return
}

func (p *AdminHandler) AdHuaweiFeedback(c *gin.Context) {
	raw := c.Request.URL.RawQuery
	logger.Infof(c, "rec huawei feedback, raw: %v", raw)

	var req pbapi.HuaweiFeedbackReq
	if err := c.Bind(&req); err != nil {
		logger.Errorf(c, "bind req fail, err: %v", err)
		c.String(http.StatusBadRequest, "bad_request")
		return
	}
	resp, err := p.ContentMng.AdHuaweiFeedback(c, &req)
	if err != nil {
		logger.Errorf(c, "huawei feedback fail, err %v", err)
	}
	c.JSON(http.StatusOK, resp)
}

func (p *AdminHandler) AdOppoFeedback(ctx *gin.Context) {
	var req pbapi.AdOppoFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, pbapi.AdOppoFeedbackResp{
			Code: -1,
			Msg:  "操作失败",
		})

		return
	}
	resp, err := p.ContentMng.AdOppoFeedback(ctx, &req)
	if err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, resp)
		return
	}

	ctx.JSON(http.StatusOK, resp)
}

func (p *AdminHandler) WangyiFeedback(c *gin.Context) {
	raw := c.Request.URL.RawQuery
	logger.Infof(c, "rec wangyi feedback, raw: %v", raw)

	var req pbapi.WangyiFeedbackReq
	if err := c.Bind(&req); err != nil {
		logger.Errorf(c, "bind req fail, err: %v", err)
		c.String(http.StatusBadRequest, "bad_request")
		return
	}
	resp, err := p.ContentMng.AdWangyiFeedback(c, &req)
	if err != nil {
		logger.Errorf(c, "wangyi feedback fail, err %v", err)
	}
	c.JSON(http.StatusOK, resp)
}

func (p *AdminHandler) AdXiaomiFeedback(ctx *gin.Context) {
	// 文档 https://api.e.mi.com/doc.html#/1.0.0-mdtag9b26f-omd/document-2bd1c4c260259b072818205a8ae20139
	// https://platform.52mengdong.com/platform/api/ad/xiaomi/feedback?response_validate=false&imei=__IMEI__&oaid=__OAID__&click_time=__TS__&app_id=__APPID__&adid=__ADID__&campaign_id=__CAMPAIGNID__&callback=__CALLBACK__&sign=__SIGN__&ua=__UA__&ip=__IP__

	var req pbapi.AdXiaomiFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, pbapi.AdXiaomiFeedbackResp{
			Code: -1,
		})
		return
	}
	resp, err := p.ContentMng.AdXiaomiFeedback(ctx, &req)
	if err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, resp)
		return
	}

	ctx.JSON(http.StatusOK, resp)
}

func (p *AdminHandler) AdBaiduFeedback(ctx *gin.Context) {
	// 文档 https://dev2.baidu.com/content?sceneType=0&pageId=101214&nodeId=662&subhead=2.3%20%E5%BA%94%E7%94%A8API%E6%8A%80%E6%9C%AF%E6%8E%A5%E5%85%A5
	// https://platform.52mengdong.com/platform/api/ad/baidu/feedback?imei_md5={{IMEI_MD5}}&os={{OS}}&ip={{IP}}&ua={{UA}}&ts={{TS}}&userid={{USER_ID}}&pid={{PLAN_ID}}&uid={{UNIT_ID}}&aid={{IDEA_ID}}&click_id={{CLICK_ID}}&callback_url={{CALLBACK_URL}}&oaid={{OAID}}

	var req pbapi.AdBaiduFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	if err := p.ContentMng.AdBaiduFeedback(ctx, &req); err != nil {
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	ctx.JSON(http.StatusOK, "")
	return

}

func (p *AdminHandler) AdGdtFeedback(ctx *gin.Context) {
	// https://developers.e.qq.com/docs/guide/user_actions/new_click_data

	var req pbapi.AdGdtFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	if err := p.ContentMng.AdGdtFeedbackReq(ctx, &req); err != nil {
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	ctx.JSON(http.StatusOK, "")
	return

}

func (p *AdminHandler) AdToutiaoFeedback(ctx *gin.Context) {
	// https://event-manager.oceanengine.com/docs/8650/h5_api_docs/
	// https://platform-test.52mengdong.com/platform/api/ad/toutiao/feedback?oaid=__OAID__&imei=__IMEI__&callback=__CALLBACK_URL__
	var req pbapi.AdToutiaoFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	if err := p.ContentMng.AdToutiaoFeedbackReq(ctx, &req); err != nil {
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	ctx.JSON(http.StatusOK, "")
	return

}

func (p *AdminHandler) AdXingtuFeedback(ctx *gin.Context) {
	// 文档：https://event-manager.oceanengine.com/docs/8650/h5_api_docs/
	var req pbapi.AdXingtuFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	if err := p.ContentMng.AdXingtuFeedbackReq(ctx, &req); err != nil {
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	ctx.JSON(http.StatusOK, "")
	return

}

func (p *AdminHandler) AdKuaiShouFeedback(ctx *gin.Context) {
	// 文档：https://docs.qingque.cn/d/home/eZQDnexll3-ebbtlX3xEDvBN3
	// 文档：https://docs.qingque.cn/d/home/eZQCUW5cBE39_ZlarHp_BWWhP?identityId=CjC4ixjMTQ#section=h.9cnktvm7ek5t
	// https://platform.52mengdong.com/platform/api/ad/kuaishou/feedback?oaid2=__OAID2__&imei=__IMEI2__&idfa=__IDFA2__&callback=__CALLBACK__&campaignid=__DID__
	var req pbapi.AdKuaiShouFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	if req.Oaid == "" { //兼容ios
		req.Oaid = req.Idfa
	}

	if err := p.ContentMng.AdKuaiShouFeedback(ctx, &req); err != nil {
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	ctx.JSON(http.StatusOK, "")
	return
}
