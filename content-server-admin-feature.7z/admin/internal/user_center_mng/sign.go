package user_center_mng

import "context"

type DailySign struct {
	UserCenterMng

	UserId             int64 //用户id
	IsSigned           bool  //是否签到
	OriginLevel        int32 //原始等级
	CurrentLevel       int32 //当前等级
	SignTimes          int32 //签到次数 普通签到：1 加速码：（违规用户：1 正常用户：4）
	IsPenalties        bool  //是否违规用户
	LevelUp            int32 //提升等级数，加速码的情况下存在连续升级
	HasAuthID          bool  //是否实名
	HasSocialButterfly bool  //是否社牛
	ExtraCondition     func()
}

func NewDailySign(ctx context.Context, mng UserCenterMng) *DailySign {
	return &DailySign{}
}

func (s *DailySign) checkLevUpAndUpdate() {

}
