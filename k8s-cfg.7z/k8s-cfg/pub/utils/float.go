package utils

import (
	"math"
	"reflect"
)

// Round 浮点类型保留小数点后n位精度
func FloatRound(f interface{}, n int) (r float64) {
	pow10N := math.Pow10(n)
	switch f.(type) {
	case float32:
		v := reflect.ValueOf(f).Interface().(float32)
		r = math.Trunc((float64(v)+0.5/pow10N)*pow10N) / pow10N
	case float64:
		v := reflect.ValueOf(f).Interface().(float64)
		r = math.Trunc((v+0.5/pow10N)*pow10N) / pow10N
	}

	return r
}
