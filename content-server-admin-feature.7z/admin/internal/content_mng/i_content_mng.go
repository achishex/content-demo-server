package content_mng

import (
	"content_svr/db/dao"
	"content_svr/internal/data_cache"
	"content_svr/internal/im_mng"
	"content_svr/internal/inner_mng"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/thirdparty/baidu_lbs_yun_proxy"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbuserapi"
	"context"
	"github.com/gin-gonic/gin"
)

type ContentMng struct {
	DataCache     data_cache.IDataCacheMng
	BaiduLbsProxy baidu_lbs_yun_proxy.IBaiduLbsYunProxy
	ShumeiProxy   shumei_proxy.IShumeiProxy
	InnerProxy    inner_mng.IInnerProxy
	KafkaProxy    kafka_proxy.IKafkaProxy
	IMHelper      *im_mng.IMHelper
	SendSessComp  *SendSessComp
	ManagerDB     *dao.ManagerDB
}

type IContentMng interface {
	// new
	NewGetShare(ctx context.Context, loginUserId int64, data []*pbapi.PersonalBottleWorksSimple) ([]*pbapi.PersonalBottleWorksSimple, error)
	NewPullUnreadCommentWorkProc(ctx context.Context, resp []*pbapi.GetReplyMsgSimple) ([]*pbapi.GetReplyMsgSimple, error)

	// user
	// RealNameAuthentication 验证身份证
	RealNameAuthentication(ctx context.Context, header *pbapi.HttpHeaderInfo, cardId, cardName string) (identity int32, err error)
	// CheckIdentificationCard 检查身份证是否已经验证以及此时身份
	CheckIdentificationCard(ctx context.Context, loginUserId int64) (identity int32, exist bool, err error)
	// SetRemarkName 备注昵称
	SetUserRemarkName(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbuserapi.UserRemarkNameReq) error
	GetUserRemarkNameOne(ctx context.Context, userId, toUserId int64) (string, error)
	// SetStarTarget 设置星标
	SetStarTarget(ctx context.Context, loginUserId int64, req *pbuserapi.UserStarTargetReq) (int, error)
	GetStarTargetList(ctx context.Context, loginUserId int64) ([]*pbapi.UserinfoDbModel, error)
	// GetUserFollowInfo 获取关注者信息
	GetUserFollowInfo(ctx context.Context, loginUserId, toUserId int64) (*pbapi.SecretUserFollowMgDbModel, error)

	GetShare(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.PersonalBottleWorksShareReq) (UserWorkScoreList, error)
	GetReplyMsg(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.GetReplyMsgReq) ([]*pbapi.GetReplyMsgSimple, error)
	SendMsg(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.SendMsgReq) (*pbapi.SendMsgSimple, error)
	TalkStatus(ctx context.Context, header *pbapi.HttpHeaderInfo, uid int64, req *pbapi.TalkStatusReq) (*pbapi.TalkStatus, error)

	PushChitchat(ctx context.Context, header *pbapi.HttpHeaderInfo,
		req *pbapi.PushChitchatReq) (int64, error)

	// 星座相关
	SetStarSignBirth(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.Birth) error
	GetStarSignBirth(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.Birth, error)
	GetStarSignInfo(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.StarSignData, error)

	//表情广场
	GetMemeSquare(ctx context.Context, req *pbapi.MemeSquareReq) (*pbapi.MemeSquareResp, error)
	MemeReport(ctx context.Context, req *pbapi.MemeReportReq) (*pbapi.MemeReportResp, error)

	// pub
	GetUserInfoTalkMode(ctx context.Context, userId int64) int32
	GetUserId(ctx context.Context, token string) (int64, error)
	GetUserMemberType(ctx context.Context, userId int64) (int32, int64)
	// debug func
	RemoveTimeoutWorks(ctx context.Context) error
	Debug(ctx context.Context) error
	CleanXingzuoUserCache(ctx context.Context, userId int64) error

	DebugAddToDeliver(ctx context.Context, req *pbapi.DebugUserIdReq) error
	DebugFirstAward(ctx context.Context, work *pbapi.DebugWork) error

	SetUserExt(ctx context.Context, userId int64, changes map[string]interface{}) error
	UntieCard(ctx context.Context, userId int64) error
	CleanSignCache(ctx context.Context, userId int64) error
	ResetSignCache(ctx context.Context, userId int64) error

	// comments
	PushWorkComment(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.WorkCommentPushReq, data *pbapi.WorkCommentPushResp) (int64, error)
	SetWorkCommentStatus(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.WorkCommentEnableReq) error
	DeleteWorkComment(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.WorkCommentDeleteReq) error
	PullWorkCommentsDetail(ctx context.Context, header *pbapi.HttpHeaderInfo,
		req *pbapi.WorkCommentPullReq) (*pbapi.WorkCommentPullResponse, error)
	PullUnreadCommentWorkProc(ctx context.Context, header *pbapi.HttpHeaderInfo, pull_size int32, work_id int64) ([]*pbapi.GetReplyMsgSimple, error)
	GetCommentStatusOnWork(ctx context.Context, works_ids []int64) (*map[int64]int32, error)
	LikeWorkComment(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.WorkCommentLikeReq) (int32, error)
	GetUserInfo(ctx context.Context, user_id int64) (*data_cache.UserInfoLocal, error)
	GetUserInfoByHeader(ctx context.Context, header *pbapi.HttpHeaderInfo) (*data_cache.UserInfoLocal, error)
	PullWorkCommentsV2(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.WorkCommentPullReq) (*pbapi.WorkCommentPullResp, error)

	// 配合安全监管，按照地区位置封禁内容. bForbid  0-不屏蔽 1-屏蔽
	AclCheck(ctx context.Context, appType int32, userId int64) bool

	PredictFishNums(ctx context.Context, header *pbapi.HttpHeaderInfo, step int64) (int64, error)
	UpsertSportStep(ctx context.Context, header *pbapi.HttpHeaderInfo, step int64) (*pbapi.SecretSportAwardPushStepResp, error)

	//sport
	QuerySportStatus(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.SecretSportStatusResponse, error)
	CurrentActivityRanker(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.SecretSportAwardRankerDetail, error)
	//返回总鱼干数和总步数, 人数
	QueryTotalFishAndStepNums(ctx context.Context, mill_activity_time int64) (int64, int64, int64, error)
	//计算每个用户的鱼干数并更新状态
	UpdateFishNumsForAllUser(ctx context.Context, millActivityTime int64, totalFishNums, totalStepNums, totalUserNums int64) error
	//处理运动勋章逻辑：
	SportMedalLogic(ctx context.Context, header *pbapi.HttpHeaderInfo) error
	//res check status
	CheckResStatusImpl(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.CheckResStatusReqMsg, userId int64) (*pbapi.CheckResStatusRespMsg, error)
	//homepage private message permission check
	CheckHomePagePrivateMessagePermission(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.HomePagePrivateMessageCheck) error
	//home page private message push message
	PushPrivateMessage(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.HomePagePrivateMessagePushReq) (*pbapi.HomePagePrivateMessagePushResp, error)
	// 获取背景图
	GetBackgroundWithTalk(ctx context.Context) (string, error)
	GetBackgroundWithWork(ctx context.Context) (string, error)
	GetBackgroundWithTalkGroup(ctx context.Context) (string, error)
	// 修改私聊配置
	SetTalkConfig(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.TalkMessageSecurityConfigReq) error

	//获取未读消息数量
	GetUnReadMsgNums(ctx context.Context, header *pbapi.HttpHeaderInfo) (int64, error)

	//平台归因上报
	AdBehaviorUpload(ctx context.Context, req *pbapi.AdBehaviorUploadReq) (*pbapi.AdBehaviorUploadResp, error)
	AdBehaviorUploadV2(ctx *gin.Context, header *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (*pbapi.AdBehaviorUploadResp, error)
	AdVivoFeedback(ctx context.Context, req []*pbapi.AdVivoFeedbackDbModel) (*pbapi.AdVivoFeedbackResp, error)
	AdOppoFeedback(ctx context.Context, req *pbapi.AdOppoFeedbackReq) (*pbapi.AdOppoFeedbackResp, error)
	AdXiaomiFeedback(ctx context.Context, req *pbapi.AdXiaomiFeedbackReq) (*pbapi.AdXiaomiFeedbackResp, error)
	AdBaiduFeedback(ctx context.Context, req *pbapi.AdBaiduFeedbackReq) error
	AdGdtFeedbackReq(ctx context.Context, req *pbapi.AdGdtFeedbackReq) error
	AdToutiaoFeedbackReq(ctx context.Context, req *pbapi.AdToutiaoFeedbackReq) error
	AdXingtuFeedbackReq(ctx context.Context, req *pbapi.AdXingtuFeedbackReq) error

	//
	OfficialNewMsgList(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.PersonalNotificationUnreadTotalResponse, error)

	GetCanWithdrawAwardByUserId(ctx context.Context, userId int64) (float64, error)
	GetCanWithdrawAward(ctx context.Context, item *pbmgdb.SuperiorContentAwardDetail) (float64, error)
	GetAwardDetailLatestOnUser(ctx context.Context, userId int64) (*pbmgdb.SuperiorContentAwardDetail, error)
	GetTotalAwardOnUser(ctx context.Context, userId int64) (float64, error)
	GetKoLaToSettlementDetailByUser(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.KoLaPlanDetailResp, error)
	GetKoLaHallOfFameList(ctx context.Context, header *pbapi.HttpHeaderInfo) ([]*pbapi.UserItemOnHalfOfFame, error)
	GetKoLaAwardDetailByUser(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.KoLaPlanDetailReq) (*pbapi.KoLaPlanDetailResp, error)
	GetTalkMessageDetailByUser(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.TalkMessageSecurityReq) (*pbapi.TalkMessageSecurityResponse, error)
	GetTotalAndCanWithdrewAward(ctx context.Context, header *pbapi.HttpHeaderInfo, userId int64) (float64, float64, error)
	ListWorkTalks(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.TalkMessageListReq) (*pbapi.SimplePageInfo, error)
	GetTotalAWardByUser(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.KoLaPlanEntryResponse, error)
	SendBBMsg(ctx context.Context, userID int64, msgType int32, content string) error
	CSJTalkADUpload(ctx context.Context, userID int64, req *pbapi.CSJTalkADUploadReq) (*pbapi.CSJTalkADUploadResp, error)
	SendWalletMsg(ctx context.Context, userID int64, msgType int32, content string, msgData any) error
	SendNotifyMsg(ctx context.Context, fromId, toId int64, msgType int32, title, content string) error

	UploadReward(ctx *gin.Context, req *pbuserapi.UploadRewardReq) (*pbuserapi.UploadRewardResp, error)
	MoneyPlan(ctx *gin.Context, req *pbuserapi.MoneyPlanReq) (*pbuserapi.MoneyPlanResp, error)
}

func NewContentMng(
	dataCache data_cache.IDataCacheMng,
	BaiduLbsProxy baidu_lbs_yun_proxy.IBaiduLbsYunProxy,
	shumeiProxy shumei_proxy.IShumeiProxy,
	innerProxy inner_mng.IInnerProxy,
	kafkaProxy kafka_proxy.IKafkaProxy,
	imHelper *im_mng.IMHelper,
	sendSessComp *SendSessComp,
	managerDB *dao.ManagerDB,
	imrc *im_mng.IMRewardComp,
) IContentMng {
	mng := &ContentMng{
		DataCache:     dataCache,
		BaiduLbsProxy: BaiduLbsProxy,
		ShumeiProxy:   shumeiProxy,
		InnerProxy:    innerProxy,
		KafkaProxy:    kafkaProxy,
		IMHelper:      imHelper,
		SendSessComp:  sendSessComp,
		ManagerDB:     managerDB,
	}
	// TODO 分包解决循环依赖
	imrc.AwardMoneyAndNotifyFn = mng.awardMoneyAndNotify
	return mng
}
