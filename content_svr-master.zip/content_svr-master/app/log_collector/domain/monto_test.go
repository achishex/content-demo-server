package domain

import (
	"context"
	"github.com/stretchr/testify/assert"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"testing"
	"time"
)

func TestMongoIdx(t *testing.T) {
	ctx := context.Background()
	db, err := newMongoDB()
	assert.Nil(t, err)
	coll := db.Collection("mlog_20240101")
	list, err := coll.Indexes().List(ctx)
	assert.Nil(t, err)
	t.Log(list)

	r := &LogRepo{
		mdb: db,
		ch:  nil,
		c:   nil,
	}
	err = r.CreateColl(ctx, time.Now())
	assert.Nil(t, err)
	err = r.BatchInsertLog(ctx, []*LogEntity{{
		UserID:  1,
		AppType: "1",
		Url:     "1",
		Method:  "1",
		Header:  "1",
		Req:     "1",
		Resp:    "1",
		Created: "1",
		Dur:     "1",
	}})
	assert.Nil(t, err)

	nextMonth := time.Now().AddDate(0, 1, 0)
	err = r.CreateColl(ctx, nextMonth)
	assert.Nil(t, err)
}

func newMongoDB() (*mongo.Database, error) {
	uri := "mongodb://root:EAtVlqFVPwUO3ldq@127.0.0.1:27017/?authSource=admin"
	ctx := context.Background()
	mcli, err := mongo.Connect(ctx, options.Client().ApplyURI(uri))
	if err != nil {
		return nil, err
	}
	timeout, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	err = mcli.Ping(timeout, nil)
	if err != nil {
		return nil, err
	}

	return mcli.Database("accesslog"), nil
}
