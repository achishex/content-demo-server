package utils

import "encoding/json"

func StructToJsonMap(target interface{}) (map[string]interface{}, error) {
	b, err := json.Marshal(target)
	if err != nil {
		return nil, err
	}

	m := make(map[string]interface{})
	err = json.Unmarshal(b, &m)
	return m, err
}

func JsonMapToStruct(to interface{}, formMap map[string]interface{}) error {
	b, err := json.Marshal(formMap)
	if err != nil {
		return err
	}

	err = json.Unmarshal(b, &to)
	return err
}
