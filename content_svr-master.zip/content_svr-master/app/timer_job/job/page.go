package job

import "go.mongodb.org/mongo-driver/mongo/options"

type PageControl struct {
	page, size int64
}

func (p *PageControl) DefaultPage() {
	p.page = 1
	p.size = 100000
}

func (p *PageControl) Reset() {
	p.page = 1
}

// PageTurning 传人的函数返回 false 时表示没有下一页
func (p *PageControl) PageTurning(f func() (bool, error)) error {
	for {
		stat, err := f()
		if err != nil {
			return err
		}

		if !stat {
			break
		}

		p.page++
	}

	p.Reset()
	return nil
}

func (p *PageControl) GetMongoPage() *options.FindOptions {
	skip := (p.page - 1) * p.size
	opt := &options.FindOptions{}
	opt.Limit = &p.size
	opt.Skip = &skip

	return opt
}
