package game_mng

import (
	"content_svr/internal/data_cache"
	"content_svr/internal/inner_mng"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/pay_mng"
	"content_svr/internal/thirdparty/wechat_proxy"
	"content_svr/protobuf/pbapi"
	"context"
)

type IGameMng interface {
	GameAuth(ctx context.Context, userId int64, appKey string) (*pbapi.GameAuthResp, error)
	GamePreOrder(ctx context.Context, req *pbapi.GamePreOrderReq) (*pbapi.GamePreOrderResp, error)
	GameGetOrderInfo(ctx context.Context, req *pbapi.GameGetOrderInfoReq) (*pbapi.GameGetOrderInfoResp, error)
	GameBind(ctx context.Context, req *pbapi.BindGameReq) (*pbapi.BindGameResp, error)
	GameList(ctx context.Context, req *pbapi.GameListReq) (*pbapi.GameListResp, error)
}

type GameMng struct {
	DataCache  data_cache.IDataCacheMng
	InnerProxy inner_mng.IInnerProxy
	KafkaProxy kafka_proxy.IKafkaProxy
	WxProxy    wechat_proxy.IWechatProxy
	PayMng     pay_mng.IPayMng
}

func NewGameMng(
	dataCache data_cache.IDataCacheMng,
	innerProxy inner_mng.IInnerProxy,
	kafkaProxy kafka_proxy.IKafkaProxy,
	wxProxy wechat_proxy.IWechatProxy,
	payMng pay_mng.IPayMng,
) IGameMng {
	return &GameMng{
		DataCache:  dataCache,
		InnerProxy: innerProxy,
		KafkaProxy: kafkaProxy,
		WxProxy:    wxProxy,
		PayMng:     payMng,
	}
}
