package model

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"errors"
)

var (
	ErrNotFound        = xerr.DbNotFound
	ErrDoNothing       = xerr.DbDoNothing
	ErrInvalidObjectId = errors.New("invalid objectId")
)
