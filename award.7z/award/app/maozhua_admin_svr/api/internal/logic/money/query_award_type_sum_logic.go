package money

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/db/dao"
	"content_svr/pub/utils"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"time"

	"github.com/zeromicro/go-zero/core/logx"
)

type QueryAwardTypeSumLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewQueryAwardTypeSumLogic(ctx context.Context, svcCtx *svc.ServiceContext) *QueryAwardTypeSumLogic {
	return &QueryAwardTypeSumLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *QueryAwardTypeSumLogic) QueryAwardTypeSum(req *types.AwardTypeSumReq) (resp *types.AwardTypeSumResp, err error) {
	filter := map[string]interface{}{
		"day": bson.D{
			{"$gte", req.TimeStart},
			{"$lte", req.TimeEnd},
		},
	}

	items, err := l.svcCtx.ManagerOnlyReadDB.SuperiorAwardDaily.FindAll(l.ctx, filter)
	if err != nil {
		return nil, err
	}

	filter = map[string]interface{}{
		"day": bson.D{
			{"$gte", req.TimeStart},
			{"$lte", req.TimeEnd},
		},
	}
	members, err := l.svcCtx.ManagerOnlyReadDB.UserMemberStatistical.FindAll(l.ctx, filter)
	if err != nil {
		return nil, err
	}
	memberMap := map[int64]uint{}
	for _, member := range members {
		memberMap[member.Day] = member.PriceSum
	}

	filter = map[string]interface{}{
		"date": bson.D{
			{"$gte", time.UnixMilli(req.TimeStart).Format("2006-01-02")},
			{"$lte", time.UnixMilli(req.TimeEnd).Format("2006-01-02")},
		},
	}
	csjMap, err := queryCsj(l.svcCtx.ManagerOnlyReadDB, l.ctx, req.TimeStart, req.TimeEnd)
	if err != nil {
		return nil, err
	}

	list := make([]types.AwardSumItem, 0)
	for _, item := range items {
		memberSum := memberMap[item.Day]
		csjSum := csjMap[item.Day]

		aItem := types.AwardSumItem{
			Day:                          item.Day,
			AwardSettlementSum:           item.AwardSettlementSum,
			DeductionIllegalSum:          item.DeductionIllegalSum,
			FirstWorkSettlementSum:       item.FirstWorkSettlementSum,
			WechatPayWithdrawSuccessSum:  item.WechatPayWithdrawSuccessSum,
			WechatPayWithdrawFailSum:     item.WechatPayWithdrawFailSum,
			HallOfFameAwardSettlementSum: item.HallOfFameAwardSettlementSum,
			GameSum:                      item.GameSum,
			MemberPaySum:                 memberSum,
			CsjSum:                       csjSum,
		}

		list = append(list, aItem)

	}

	resp = &types.AwardTypeSumResp{List: list}

	return
}

func queryCsj(read *dao.ManagerDB, ctx context.Context, timeStart, timeEnd int64) (map[int64]uint, error) {

	filter := map[string]interface{}{
		"date": bson.D{
			{"$gte", time.UnixMilli(timeStart).Format("2006-01-02")},
			{"$lte", time.UnixMilli(timeEnd).Format("2006-01-02")},
		},
	}
	csjList, err := read.CsjAdvertisementData.FindAll(ctx, filter)
	if err != nil {
		return nil, err
	}
	csjMap := map[int64]uint{}
	for _, csj := range csjList {
		dayTime, err := time.Parse("2006-01-02", csj.Date)
		if err != nil {
			logx.Error(err)
			continue
		}
		key := utils.ZeroTime(dayTime).UnixMilli()
		if count, ok := csjMap[key]; ok {
			csjMap[key] = count + uint(csj.Revenue*100)
		} else {
			csjMap[key] = uint(csj.Revenue * 100)
		}
	}

	return csjMap, err

}
