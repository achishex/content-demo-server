package query

import (
	"content_svr/db/mysqldb/model"
	"context"
	"gorm.io/gen"
	"gorm.io/gen/field"
	"time"
)

type WxRewardLog struct {
	wxRewardLog
}

func NewWxRewardLog(p wxRewardLog) WxRewardLog {
	return WxRewardLog{
		wxRewardLog: p,
	}
}

func (p *wxRewardLog) GetColumnName(field field.Expr) string {
	return field.ColumnName().String()
}

func (p *wxRewardLog) ParseWhere(ctx context.Context, where map[string]interface{}) IWxRewardLogDo {
	_do := p.WithContext(ctx)
	if len(where) == 0 {
		return _do
	}

	attrMap := map[string]interface{}{}
	for key, value := range where {
		switch key {
		case "create_time_start":
			_do = _do.Where(p.CreateTime.Gt(time.UnixMilli(value.(int64))))
		case "create_time_end":
			_do = _do.Where(p.CreateTime.Lt(time.UnixMilli(value.(int64))))
		default:
			if _, exist := p.fieldMap[key]; !exist {
				continue
			}
			attrMap[key] = value
		}
	}

	return _do.Where(field.Attrs(attrMap))
}

func (p *wxRewardLog) Find(ctx context.Context, limit, offset int, where map[string]interface{}) ([]*model.WxRewardLog, error) {
	_db := p.ParseWhere(ctx, where)
	_db = _db.WithContext(ctx)
	if limit != 0 {
		_db = _db.Limit(limit)
	}
	if offset != 0 {
		_db = _db.Offset(offset)
	}

	return _db.Find()
}

func (p *wxRewardLog) FindOne(ctx context.Context, where map[string]interface{}) (*model.WxRewardLog, error) {
	_db := p.ParseWhere(ctx, where)

	return _db.Take()
}

func (p *wxRewardLog) UpdateMap(ctx context.Context, where, update map[string]interface{}) (info gen.ResultInfo, err error) {
	_db := p.ParseWhere(ctx, where)

	return _db.Updates(update)
}
