package svc

import (
	"content_svr/app/maozhua_admin_svr/api/internal/config"
	"content_svr/app/maozhua_admin_svr/api/internal/middleware"
	"content_svr/app/maozhua_admin_svr/api/internal/svc/monitor"
	"content_svr/app/maozhua_admin_svr/api/internal/svc/shumei"
	"content_svr/app/maozhua_admin_svr/api/internal/svc/user_manage"
	"content_svr/app/maozhua_admin_svr/api/internal/svc/work_manage"
	"content_svr/app/maozhua_admin_svr/common/db"
	"content_svr/db/aggregation"
	"content_svr/db/dao"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
	"content_svr/setting"
	"github.com/zeromicro/go-zero/rest"
)

type ServiceContext struct {
	Config config.Config

	AuthInterceptor rest.Middleware

	RedisClient *query_rds.Manage
	WriteDB     *dao.ManagerDB
	ReadDB      *dao.ManagerDB

	Maozhua *setting.ServiceSetting

	RobotMonitor *monitor.Monitor
	UserManage   *user_manage.UserManage
	WorkManage   *work_manage.WorkManage
	SumManage    *aggregation.SumManage
	ShuMei       *shumei.ShuMei

	//ContentSvr *originManage.ContentSvr
}

func NewServiceContext(c config.Config) *ServiceContext {
	// 初始化数据库
	mysqlConn, err := db.ConnectMysql(c.MysqlConfig)
	if err != nil {
		panic(err)
	}
	mysqlOnlyReadConn, err := db.ConnectMysql(c.MysqlOnlyReadConfig)
	if err != nil {
		panic(err)
	}
	rds := db.InitRdsClient(c.RedisConfig.Host, c.RedisConfig.Pass)
	//mongoConn, err := mg_model.NewMongoDBInstance(cfg.ServerConfig.MongodbConfig)
	//if err != nil {
	//	panic(err)
	//}

	// 构建数据链接对象
	mysql := query.Use(mysqlConn)
	mongo := query_mng.NewQueryMng(c.MongoConfig)
	redisManage := query_rds.NewClient(rds, c.ProjectEnv)
	writeDB := dao.NewDbManager(mysql, mongo, redisManage)

	onlyReadMysql := query.Use(mysqlOnlyReadConn)
	onlyReadMongo := query_mng.NewQueryMng(c.MongoOnlyReadConfig)
	readDB := dao.NewDbManager(onlyReadMysql, onlyReadMongo, redisManage)

	// 统一配置
	if err := setting.Initialize(rds, c.ProjectEnv); err != nil {
		panic(err)
	}

	return &ServiceContext{
		Config:          c,
		AuthInterceptor: middleware.NewAuthInterceptorMiddleware(redisManage.Token.TokenAdmin).Handle(c.Mode),

		RedisClient: redisManage,
		WriteDB:     writeDB,
		ReadDB:      readDB,
		Maozhua:     setting.Maozhua,
		ShuMei:      shumei.NewShuMeiSvc(c),

		//ContentSvr: originManage.NewContentSvr(mysqlConn, mongoConn, rds),
		RobotMonitor: monitor.InitRobotMonitor(writeDB),
		UserManage:   user_manage.NewUserManage(writeDB),
		WorkManage:   work_manage.NewWorkManage(writeDB, readDB),
		SumManage:    aggregation.NewSumManage(writeDB, readDB),
	}
}
