package tests

import (
	"content_svr/db/dao"
	"context"
	"github.com/go-redis/redis/v8"
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestUpdateTaskProgress(t *testing.T) {
	e := c.Invoke(func(managerDB *dao.ManagerDB) error {
		a := managerDB.UserRewardMoneyActivity
		ctx := context.Background()
		userID := int64(4725532565906432)
		err := a.UpdateTaskProgress(ctx, userID, 20, 3, 30)
		return err
	})
	assert.Nil(t, e)
}

func TestDelGroupActiveCache(t *testing.T) {

	ctx := context.Background()
	e := c.Invoke(func(rdb *redis.Client) error {
		keys, err := rdb.Keys(ctx, "platform:test:active:im:group:*").Result()
		if err != nil {
			return err
		}

		_, err = rdb.Pipelined(ctx, func(p redis.Pipeliner) error {
			for _, key := range keys {
				p.Del(ctx, key)
			}
			return nil
		})
		if err != nil {
			return err
		}
		return nil
	})
	assert.Nil(t, e)
}
