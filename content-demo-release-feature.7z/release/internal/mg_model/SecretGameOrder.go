package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretGameOrderMgModel interface {
	Get(ctx context.Context, filter any) (*pbmgdb.SecretGameOrderMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.SecretGameOrderMgDbModel, options ...*options.InsertOneOptions) error
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
}

type SecretGameOrder struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretGameOrderMgModelImpl(db *mongo.Database) ISecretGameOrderMgModel {
	return &SecretGameOrder{
		MgDB:  db,
		Table: "secretGameOrder",
	}
}

func (g *SecretGameOrder) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *SecretGameOrder) Get(ctx context.Context, filter any) (*pbmgdb.SecretGameOrderMgDbModel, error) {
	var v *pbmgdb.SecretGameOrderMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("secretGameOrder:Get failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *SecretGameOrder) Create(ctx context.Context, data *pbmgdb.SecretGameOrderMgDbModel, options ...*options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data, options...)

	if err != nil {
		logger.Errorf(ctx, "secretGameOrder:Create : %v", err)
		return err
	}

	return nil
}

func (g *SecretGameOrder) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "secretGameOrder:updateOne error: %v", err)
		return err
	}

	return nil
}
