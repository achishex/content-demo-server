package data_cache

import (
	"content_svr/pub/logger"
	"time"

	//"content_svr/pub/utils"
	"context"
	"github.com/go-redis/redis/v8"
)

func (p *DataCacheMng) GetCommentNumsForCommenter(ctx context.Context, user_id int64) (int64, error) {
	rdKey := getRdsKeyCommentNumsOnCommenter(user_id)
	nums, err := p.RedisCli.Get(ctx, rdKey).Int64()
	if err == redis.Nil {
		return 0, nil
	}
	if err != nil {
		logger.Errorf(ctx, "get key: %v from redis fail, err: %v", rdKey, err)
		return 0, err
	}
	return nums, nil
}
func GetZeroTimeOnNextDay() time.Time {
	return time.Date(time.Now().Year(), time.Now().Month(), time.Now().Day(), 23, 59, 59, 0, time.Local)
}

// IncrUserSingleMaxCommentCount 单条动态统计当前用户评论数
func (p *DataCacheMng) IncrUserSingleMaxCommentCount(ctx context.Context, userId int64, incrVal int64) error {
	rdKey := getRdsKeyCommentNumsOnCommenter(userId)
	nums, err := p.RedisCli.IncrBy(ctx, rdKey, incrVal).Uint64()
	if err != nil {
		logger.Errorf(ctx, "incr %v fail, %v", rdKey, err)
		return err
	}
	if nums > 1 {
		return nil
	}

	expireTimeValue := GetZeroTimeOnNextDay().Sub(time.Now()).Seconds()
	logger.Infof(ctx, "expire time: %v", expireTimeValue)
	bSuc, err := p.RedisCli.Expire(ctx, rdKey, time.Duration(expireTimeValue)*time.Second).Result()
	if err != nil {
		logger.Errorf(ctx, "set redis expire failed. key=%v, bSuc=%v, err=%v", rdKey, bSuc, err)
		return err
	}
	return nil
}

func (p *DataCacheMng) DecrCommentNumsForCommenter(ctx context.Context, userId int64, decrVal int64) error {
	rdKey := getRdsKeyCommentNumsOnCommenter(userId)
	// 查看是否存在
	_, err := p.RedisCli.Get(ctx, rdKey).Int64()
	if err != nil {
		logger.Errorf(ctx, "decr get %v fail, %v", rdKey, err)
		return nil
	}

	// 减1
	nums, err := p.RedisCli.DecrBy(ctx, rdKey, decrVal).Uint64()
	if err != nil {
		logger.Errorf(ctx, "decr %v fail, %v", rdKey, err)
		return err
	}
	if nums > 1 {
		return nil
	}

	expireTimeValue := GetZeroTimeOnNextDay().Sub(time.Now()).Seconds()
	logger.Infof(ctx, "expire time: %v", expireTimeValue)
	bSuc, err := p.RedisCli.Expire(ctx, rdKey, time.Duration(expireTimeValue)*time.Second).Result()
	if err != nil {
		logger.Errorf(ctx, "set redis expire failed. key=%v, bSuc=%v, err=%v", rdKey, bSuc, err)
		return err
	}
	return nil
}

func (p *DataCacheMng) GetWorkCommenterCommentNums(ctx context.Context, user_id int64, work_id int64) (int64, error) {
	rdKey := getRdsKeyCommentNumsOnWork(user_id, work_id)
	nums, err := p.RedisCli.Get(ctx, rdKey).Int64()
	if err == redis.Nil {
		return 0, nil
	}
	if err != nil {
		logger.Errorf(ctx, "get key: %v from redis fail, err: %v", rdKey, err)
		return 0, err
	}
	return nums, nil
}

// IncrUserMaxCommentCount 当前用户评论总数
func (p *DataCacheMng) IncrUserMaxCommentCount(ctx context.Context, user_id int64, work_id int64, incr_val int64) (int64, error) {
	rdKey := getRdsKeyCommentNumsOnWork(user_id, work_id)
	c, err := p.RedisCli.IncrBy(ctx, rdKey, incr_val).Uint64()
	if err != nil {
		logger.Errorf(ctx, "incr %v fail, %v", rdKey, err)
		return 0, err
	}
	return int64(c), nil
}
