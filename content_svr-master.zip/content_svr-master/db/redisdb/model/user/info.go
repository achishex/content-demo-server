package user

import (
	mysql "content_svr/db/mysqldb/model"
	"content_svr/db/redisdb/model/internal"
	"context"
	"encoding/json"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"strings"
)

type userInfo struct {
	internal.RdsInfo
}

func (r *userInfo) getRdsKey(userId int64) string {
	return fmt.Sprintf(r.RdsKey, r.Env, userId)
}

func (r *userInfo) Del(ctx context.Context, userId int64) error {
	return r.Client.Del(ctx, r.getRdsKey(userId)).Err()
}

func (r *userInfo) GetUserInfo(ctx context.Context, userId int64) (*mysql.UserInfo, error) {
	// todo
	rdsKey := r.getRdsKey(userId)
	info := &mysql.UserInfo{}
	if err := r.Client.HGetAll(ctx, rdsKey).Scan(info); err != nil {
		return nil, err
	}
	return info, nil
}

func (r *userInfo) SetUserInfo(ctx context.Context, userId int64, data map[string]any) error {
	rdsKey := r.getRdsKey(userId)

	args := make([]any, 0)
	for key, value := range data {
		args = append(args, key)

		if strings.Contains(key, "$") {
			switch value.(type) {
			case bson.D:
				v, err := bson.Marshal(value)
				if err != nil {
					return err
				}
				args = append(args, string(v))
			case map[string]any:
				v, err := json.Marshal(value)
				if err != nil {
					return err
				}
				args = append(args, string(v))
			}
		} else {
			args = append(args, value)
		}

	}

	return r.Client.HMSet(ctx, rdsKey, args...).Err()
}
