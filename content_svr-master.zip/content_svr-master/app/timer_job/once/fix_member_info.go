package once

import (
	"content_svr/db/mysqldb/model"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"log"
	"time"
)

/*
根据 SecretMemberInfo 表中的数据，更新 redis 中会员的信息。如果 redis 中有用户信息，则不更新
*/
func (c *command) fixMemberInfo() {
	//filter := bson.D{
	//	{Key: "enable", Value: true},
	//	{Key: "expire", Value: bson.D{
	//		{"$gte", time.Now().UnixMilli()},
	//	}},
	//	{Key: "userId", Value: 4323936494238720},
	//}

	filter := map[string]interface{}{
		"enable": true,
		"expire": bson.D{
			{"$gte", time.Now().UnixMilli()},
		},
		//"userId": 4323936494238720,
	}

	memberInfoList, _ := c.read.SecretMemberInfo.FindAll(context.Background(), filter)
	for _, item := range memberInfoList {
		logger.Infof(context.Background(), "quding1 %v", item)

		c.read.SecretMemberInfo.UpdateRedis(context.Background(), &item)
	}
}

/*
将三个月会员修改为1年
*/
func (c *command) fixMemberInfo2() {
	// step1：从 orderInfo 表读取购买了3个月会员且支付成功的订单
	filter := map[string]interface{}{
		"order_status": model.PaySuccess,
		"product_name": "3个月",
	}

	ctx := requestid.WithRequestID(context.Background())
	orders, err := c.read.OrderInfo.FindMap(ctx, 0, 0, filter)
	if err != nil {
		log.Fatal(err)
	}

	for _, order := range orders {
		filter := map[string]interface{}{
			"userId": order.UserID,
		}
		opt := &options.FindOneOptions{}
		opt.Sort = bson.D{
			{"timestamp", -1}, // 取最后一条
		}
		info, err := c.read.SecretMemberInfo.FindOne(ctx, filter, opt)
		if err != nil {
			logger.Infof(ctx, "cannot find user_id: %v, order_id: %v", order.UserID, order.ID)
			continue
		}

		//oldExpire := time.UnixMilli(info.Expire)
		oldExpire, err := time.Parse("2006-01-02 15:04:05", order.CreateTime)
		if err != nil {
			logger.Infof(ctx, "createTime parse error user_id: %v, order_id: %v", order.UserID, order.ID)
			continue
		}

		newExpire := oldExpire.AddDate(1, 0, 0)
		info.Expire = newExpire.UnixMilli()

		if err := c.read.SecretMemberInfo.Update(ctx, info); err != nil {
			logger.Infof(ctx, "Update new expire time error: user_id: %v, order_id: %v", order.UserID, order.ID)
			continue
		}
		logger.Infof(ctx, "update_memberinfo %v", info)
	}
}
