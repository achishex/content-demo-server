package clock

import (
	"fmt"
	"github.com/robfig/cron/v3"
	"github.com/zeromicro/go-zero/core/threading"
)

func RunFunc(c *cron.Cron, rule string, fn func()) {
	if eid, err := c.AddFunc(rule, func() {
		threading.GoSafe(fn)
	}); err != nil {
		panic(fmt.Sprintf("EntryId:%v, err: %v", eid, err))
	}
}
