package user_center_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"content_svr/setting"
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
	"strconv"
	"time"
)

func (u *UserCenterMng) WithdrawBind(ctx context.Context, req *pbuserapi.BindWechatUserReq) (*pbuserapi.BindWechatUserResp, error) {
	var (
		resp = &pbuserapi.BindWechatUserResp{}

		userId  = middleware.GetUserID(ctx.(*gin.Context))
		bindDoc = u.DataCache.GetImpl().SecretUserWechatBindListMgDbModel
	)

	if bindDoc.Exists(ctx, bson.M{"userId": userId}) {
		return nil, errorcode.UserBindWechatExists
	}

	at, err := u.WxProxy.GetAccessTokenByCode(ctx, req.WechatCode)
	if err != nil || at.Openid == "" {
		logger.Errorf(ctx, "GetAccessTokenByCode error. code: %v, err: %v", req.WechatCode, err)
		return nil, errorcode.THIRD_API_ERROR
	}

	wxUserInfo, err := u.WxProxy.GetWechatUserInfo(ctx, at)
	if err != nil || wxUserInfo.Openid == "" {
		logger.Errorf(ctx, "GetWechatUserInfo error. at: %v, err: %v", at, err)
		return nil, errorcode.UserBindWechatError
	}

	if err := u.DataCache.GetImpl().SecretUserWechatBindListMgDbModel.AddOne(ctx, &pbmgdb.SecretUserWechatBindListMgDbModel{
		Id:         snow_flake.GetSnowflakeID(),
		UserId:     userId,
		Openid:     wxUserInfo.Openid,
		Nickname:   wxUserInfo.Nickname,
		Sex:        int32(wxUserInfo.Sex),
		Province:   wxUserInfo.Province,
		City:       wxUserInfo.City,
		Country:    wxUserInfo.Country,
		Headimgurl: wxUserInfo.HeadImgUrl,
		Privilege:  wxUserInfo.Privilege,
		Unionid:    wxUserInfo.Unionid,
	}); err != nil {
		logger.Errorf(ctx, "add bind error: %v", err)
		return nil, errorcode.UserBindWechatError
	}

	resp.Nickname = wxUserInfo.Nickname
	resp.HeadImg = wxUserInfo.HeadImgUrl

	return resp, nil
}

func (u *UserCenterMng) WithdrawUnBind(ctx context.Context) error {
	var (
		userId        = middleware.GetUserID(ctx.(*gin.Context))
		openUserModel = u.DataCache.GetImpl().OpenUserModel
		openUserDoc   = u.DataCache.GetImpl().SecretUserWechatBindListMgDbModel
	)

	openUserModel.Delete(ctx, userId)
	openUserDoc.Delete(ctx, bson.M{"userId": userId})

	return nil
}

func (u *UserCenterMng) WithdrawBefore(ctx context.Context, req *pbuserapi.WithdrawBeforeReq) (*pbuserapi.WithdrawBeforeResp, error) {

	var (
		resp = &pbuserapi.WithdrawBeforeResp{
			AvailBalance:           "0.00",
			IsBindWechat:           false,
			WechatNickname:         "",
			MinWithdrawAmount:      config.ServerConfig.WithdrawConfig.MinWithdrawAmount,
			MaxWithdrawAmountMonth: config.ServerConfig.WithdrawConfig.MaxWithdrawAmountMonth,
			IsAuthRealName:         false,
			PhoneNum:               "",
			Level1WorkAward:        setting.Maozhua.Level1WorkAward.Get(),
			Level2WorkAward:        setting.Maozhua.Level2WorkAward.Get() - setting.Maozhua.Level1WorkAward.Get(),
		}

		userId = middleware.GetUserID(ctx.(*gin.Context))
	)
	canWithdrawAward, _ := u.ContentMng.GetCanWithdrawAwardByUserId(ctx, userId)
	resp.AvailBalance = strconv.FormatFloat(canWithdrawAward, 'f', 2, 64)

	filter := bson.D{
		{"user_id", userId},
	}
	info, err := u.DataCache.GetImpl().SecretUserIdentificationCardMgModel.FindOne(ctx, filter)
	if err == nil && info.Status == const_busi.UserCardStatus {
		resp.IsAuthRealName = true
	}

	userInfo, err := u.DataCache.GetUserBasicInfo(ctx, userId, false)
	if err != nil {
		logger.Errorf(ctx, "user not found: userId, err: %v", userId, err)
		return nil, errorcode.DATA_ERROR
	}
	if userInfo.GetPhone() != "" {
		phone, err := utils.AESDecrypt(userInfo.GetPhone(), utils.AesUserKey)
		if err != nil {
			logger.Errorf(ctx, "user phone is empty: %v", err)
			return nil, errorcode.DATA_ERROR
		}
		resp.PhoneNum = string(phone)
	}

	openUser, _ := u.DataCache.GetImpl().SecretUserWechatBindListMgDbModel.Get(ctx, bson.M{"userId": userId})
	if openUser != nil {
		resp.IsBindWechat = true
		resp.WechatNickname = openUser.GetNickname()
		resp.WechatHeadImg = openUser.GetHeadimgurl()
	}

	return resp, nil
}

const (
	WithdrawRetToastingDesc  string = "提现中"
	WithdrawRetToastSuccDesc string = "已提现"
	WithdrawRetToastFailDesc string = "提现失败"
)
const (
	WithdrawRetInit      int32 = 0
	WithdrawRetToasting  int32 = 1
	WithdrawRetToastSucc int32 = 2
	WithdrawRetToastFail int32 = 3
)

type CapitalBasic struct {
	basicNums float32
	userId    int64
}

func (p *CapitalBasic) CheckMinCond(ctx context.Context) error {
	minAmount := float32(1.00)
	if len(config.ServerConfig.WithdrawConfig.MinWithdrawAmount) > 0 {
		tmpAmount, err := strconv.ParseFloat(config.ServerConfig.WithdrawConfig.MinWithdrawAmount, 32)
		if err == nil && tmpAmount > 0.0001 {
			minAmount = float32(tmpAmount)
		}
	}
	if p.basicNums < minAmount {
		logger.Errorf(ctx, "req withdraw num: %v, less than config withdraw: %v", p.basicNums, minAmount)
		return errorcode.GenBusiErr(errorcode.KoLaTransferMinWithdraw, fmt.Sprintf(errorcode.KoLaTransferMinWithdraw.UserMsg, minAmount))
	}
	return nil
}
func (p *CapitalBasic) CheckMaxCond(ctx context.Context, mng *data_cache.DataCacheMng) error {
	maxAmount := 800.0

	nowTime := time.Now()
	zerocurMonthFirstDay := time.Date(nowTime.Year(), nowTime.Month(), 1, 0, 0, 0, 0, nowTime.Location())
	filter := bson.D{
		{
			"user_id", p.userId,
		},
		{
			"type", WithdrawStatusOK,
		},
		{"$and",
			bson.A{
				bson.D{{"create_time", bson.D{{"$gt", zerocurMonthFirstDay.UnixMilli()}}}},
				bson.D{{"create_time", bson.D{{"$lte", nowTime.UnixMilli()}}}},
			},
		},
	}

	totalAward, err := mng.SuperiorContentAwardDetailMgModel.SumAccountByConds(ctx, filter)
	if err != nil {
		return errorcode.KoLaTransferNumsOverLimit
	}

	if config.ServerConfig.WithdrawConfig == nil || len(config.ServerConfig.WithdrawConfig.MaxWithdrawAmountMonth) <= 0 {
		if totalAward-maxAmount > 0.00001 {
			logger.Errorf(ctx, "has withdraw: %v more than maxAccount: %v", totalAward, maxAmount)
			return errorcode.KoLaTransferNumsOverLimit
		}
		return nil
	}

	tmpMaxAmount, err := strconv.ParseFloat(config.ServerConfig.WithdrawConfig.MaxWithdrawAmountMonth, 64)
	if err == nil && tmpMaxAmount > 0.00001 {
		maxAmount = tmpMaxAmount
	}
	if totalAward+float64(p.basicNums)-maxAmount > 0.00001 {
		logger.Errorf(ctx, "has withdraw: %v more than maxAccount: %v", totalAward, maxAmount)
		return errorcode.KoLaTransferNumsOverLimit
	}
	return nil
}
func (p *CapitalBasic) CheckFrequencyCond(ctx context.Context, mng *data_cache.DataCacheMng) error {
	nowTime := time.Now()
	zeroCurDay := time.Date(nowTime.Year(), nowTime.Month(), nowTime.Day(), 0, 0, 0, 0, nowTime.Location())
	filter := bson.D{
		{
			"user_id", p.userId,
		},
		{
			"status", WithdrawStatusOK,
		},
		{"$and",
			bson.A{
				bson.D{{"create_time", bson.D{{"$gt", zeroCurDay.UnixMilli()}}}},
				bson.D{{"create_time", bson.D{{"$lte", nowTime.UnixMilli()}}}},
			},
		},
	}
	nums, err := mng.KoLaWithdrawDetailMgModel.FindCountsByConds(ctx, filter)
	if err != nil {
		logger.Errorf(ctx, "get frequency withdraw for user: %v, fail, err: %v", p.userId, err)
		return errorcode.KoLaTransferTimesTooMany
	}
	if nums >= config.ServerConfig.WithdrawConfig.MaxTimesOneDay {
		logger.Errorf(ctx, "user: %v withdraw times: %v more than max: %v one day", p.userId, nums, config.ServerConfig.WithdrawConfig.MaxTimesOneDay)
		return errorcode.KoLaTransferTimesTooMany
	}
	return nil
}

func (u *UserCenterMng) PayNumSafeCheckForUser(ctx context.Context, capitalValue float32, userId int64) error {
	filterItem := &CapitalBasic{
		basicNums: capitalValue,
		userId:    userId,
	}
	if err := filterItem.CheckMinCond(ctx); err != nil {
		return err
	}

	if err := filterItem.CheckMaxCond(ctx, u.DataCache.GetImpl()); err != nil {
		return err
	}

	if err := filterItem.CheckFrequencyCond(ctx, u.DataCache.GetImpl()); err != nil {
		return err
	}

	return nil
}
func (u *UserCenterMng) Withdraw(ctx context.Context, req *pbuserapi.WithdrawReq) (*pbuserapi.WithdrawResp, error) {
	curUserId := middleware.GetUserID(ctx.(*gin.Context))

	ret := &pbuserapi.WithdrawResp{}
	if int32(pbuserapi.WithdrawType_VERTIFYPHONECODE) == req.GetOpType() {
		verifyRet, err := NewIPhoneVerify(req.GetPhoneNum(), req.GetMsgCode(), SmsTypeDesc[SmsTypeEnumWithdraw], u.DataCache).VerifyCode(ctx)
		if err != nil {
			logger.Errorf(ctx, "verify phone code err: %v, code: %v, curUserId: %v", err, req.GetMsgCode(), curUserId)
			return ret, errorcode.PhoneCodeVerifyError
		}
		if !verifyRet {
			logger.Errorf(ctx, "verify phone and code fail, ret: %v, curUserId: %v", verifyRet, curUserId)
			return ret, errorcode.PhoneCodeVerifyError
		}
		return ret, nil
	}

	openId := ""
	if openUserInfo, err := u.DataCache.GetImpl().SecretUserWechatBindListMgDbModel.Get(ctx, bson.M{"userId": curUserId}); err == nil && openUserInfo != nil {
		ret.NickName = openUserInfo.GetNickname()
		openId = openUserInfo.GetOpenid()
	}

	ret.Amount = req.Amount
	ret.WithdrawTime = time.Now().UnixMilli() / 1e3 //返回给h5 seconds
	ret.WithdrawStatus = WithdrawRetToastingDesc
	ret.Status = 1000

	if err := u.PayNumSafeCheckForUser(ctx, req.Amount, curUserId); err != nil {
		logger.Errorf(ctx, "req withdraw num: %v", req.Amount)
		ret.WithdrawStatus = WithdrawRetToastFailDesc

		if retErr, ok := err.(*(errors.Error)); ok {
			ret.Status = retErr.UserErrCode
		}

		return ret, nil
	}

	payProcHandle := NewTransMoneyHandler(u, ret.NickName, 0)

	curStatus, err := payProcHandle.CheckUserLocalStatus(ctx, curUserId, req.Amount)
	if err != nil {
		logger.Errorf(ctx, "get user transfer status on local fail, userId: %v, err: %v", curUserId, err)
		ret.WithdrawStatus = WithdrawRetToastFailDesc
		ret.Status = errorcode.KoLaTransferMoneyFail.UserErrCode
		return ret, nil
	}

	if curStatus == WithdrawRetToasting {
		logger.Infof(ctx, "curUser: %d is on transferring money...", curUserId)
		ret.WithdrawStatus = WithdrawRetToastingDesc
		return ret, nil
	}

	err = payProcHandle.SendPayReq(ctx, req, ret, openId)
	if err != nil {
		logger.Errorf(ctx, "withdraw req fail, err: %v", err)
		ret.WithdrawStatus = WithdrawRetToastFailDesc
		ret.Status = errorcode.KoLaTransferMoneyFail.UserErrCode
		return ret, nil
	}

	status, err := payProcHandle.ProcessWithdrawOnLocal(ctx, curUserId)
	if err != nil {
		logger.Errorf(ctx, "trans money fail, err: %v", err)

		ret.WithdrawStatus = WithdrawRetToastFailDesc
		ret.Status = errorcode.KoLaTransferMoneyError.UserErrCode
		return ret, nil
	}

	if status == WithdrawRetToasting {
		ret.WithdrawStatus = WithdrawRetToastingDesc
		ret.WithdrawStatus = errorcode.KoLaTransferMoneying.UserMsg

	} else if status == WithdrawRetToastSucc {
		ret.WithdrawStatus = WithdrawRetToastSuccDesc

	} else if status == WithdrawRetToastFail {
		ret.Status = errorcode.KoLaTransferMoneyError.UserErrCode
		ret.WithdrawStatus = WithdrawRetToastFailDesc
	}
	return ret, nil
}

///
///
///
