package sum_manage

import "content_svr/db/dao"

type SumManage struct {
	//ManagerDB, ManagerOnlyReadDB *dao.ManagerDB

	UserActivityDaily
	GameOrder
	Member
}

func NewSumManage(read, write *dao.ManagerDB) *SumManage {
	return &SumManage{
		//ManagerDB:               write,
		//ManagerOnlyReadDB:       read,
		UserActivityDaily: UserActivityDaily{
			ManagerDB:         write,
			ManagerOnlyReadDB: read,
		},
		GameOrder: GameOrder{
			ManagerDB:         write,
			ManagerOnlyReadDB: read,
		},
		Member: Member{
			ManagerDB:         write,
			ManagerOnlyReadDB: read,
		},
	}
}
