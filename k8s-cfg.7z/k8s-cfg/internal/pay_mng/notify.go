package pay_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	localUtils "content_svr/pub/utils"
	"context"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"github.com/go-resty/resty/v2"
	"github.com/wechatpay-apiv3/wechatpay-go/core"
	"github.com/wechatpay-apiv3/wechatpay-go/core/auth/verifiers"
	"github.com/wechatpay-apiv3/wechatpay-go/core/notify"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments"
	"github.com/wechatpay-apiv3/wechatpay-go/utils"
	"go.mongodb.org/mongo-driver/bson"
	"net/http"
	"strconv"
	"time"
)

func (p *PayMng) WechatPayNotify(ctx context.Context, request *http.Request) map[string]string {
	logger.Infof(ctx, "WechatPayNotify:IN: request: %+v", request)

	var (
		failResp = map[string]string{
			"code":    "FAIL",
			"message": "失败",
		}
	)

	wpath, err := localUtils.GetWorkPath()
	if err != nil {
		panic(fmt.Sprintf("WechatPayNotify:get workpath failed. err:%v", err.Error()))
	}
	cert, err := utils.LoadCertificateWithPath(wpath + "/cert/" + config.ServerConfig.WechatConfig.PlatformCertFile)
	if err != nil {
		logger.Errorf(ctx, "WechatPayNotify:load cert key file fail, err: %v", err)
		return failResp
	}
	handler, err := notify.NewRSANotifyHandler(config.ServerConfig.WechatConfig.MchAPIv3Key, verifiers.NewSHA256WithRSAVerifier(core.NewCertificateMapWithList([]*x509.Certificate{cert})))

	content := new(payments.Transaction)
	notifyReq, err := handler.ParseNotifyRequest(ctx, request, content)
	if err != nil {
		logger.Errorf(ctx, "WechatPayNotify:pay notify err: %v", err)
		return failResp
	}

	logger.Infof(ctx, "summary: %v", notifyReq.Summary)
	logger.Infof(ctx, "content: %v", content)

	var (
		payOrderColl = p.DataCache.GetImpl().SecretPayOrderInfoMgModel
		notifyColl   = p.DataCache.GetImpl().SecretPayNotifyMgModel
	)

	payOrder, err := payOrderColl.Get(ctx, bson.M{"order_no": content.OutTradeNo})
	if err != nil {
		logger.Errorf(ctx, "wechatPayNotify:payOrderColl.Get error: %v", err)
		return failResp
	}

	if payOrder.PayStatus == const_busi.PayStatusSuccess || payOrder.PayStatus == const_busi.PayStatusFail {
		return nil
	}

	vReq, _ := json.Marshal(notifyReq)
	vJson, _ := json.Marshal(content)
	_ = notifyColl.Create(ctx, &pbmgdb.SecretPayNotifyMgDbModel{
		Id:            snow_flake.GetSnowflakeID(),
		PayOrg:        "ORG_WECHAT_PAY",
		AppId:         payOrder.AppId,
		Request:       string(vReq),
		Json:          string(vJson),
		OutTradeNo:    *content.OutTradeNo,
		TransactionId: *content.TransactionId,
		CreatTime:     time.Now().UnixMilli(),
	})

	payStatus := int32(const_busi.PayStatusNoPay)
	if s, ok := const_busi.WxGamePayStatusMapping[*content.TradeState]; ok {
		payStatus = s
	}
	payOrder.PayStatus = payStatus
	err = payOrderColl.UpdateOne(ctx, bson.M{"order_no": content.OutTradeNo}, map[string]any{
		"transaction_no":   content.TransactionId,
		"pay_status":       payStatus,
		"trade_state_desc": content.TradeStateDesc,
		"pay_time":         content.SuccessTime,
		"pay_type":         content.TradeType,
		"mch_id":           content.Mchid,
		"open_id":          content.Payer.Openid,
		"update_time":      time.Now().UnixMilli(),
	})
	if err != nil {
		logger.Errorf(ctx, "wechatPayNotify:payOrderColl.UpdateOne error: %v", err)
		return failResp
	}

	//第三方通知
	go p.notifyGame(ctx, payOrder)

	logger.Infof(ctx, "WechatPayNotify:SUCCESS")

	return map[string]string{
		"code":    "SUCCESS",
		"message": "",
	}
}

func (p *PayMng) notifyGame(ctx context.Context, payOrder *pbmgdb.SecretPayOrderInfoMgDbModel) {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "panic error: %v", err)
			return
		}
	}()

	game, err := p.DataCache.GetImpl().SecretGameMgModel.GetByAppKey(ctx, payOrder.AppId)
	if err != nil {
		logger.Errorf(ctx, "notifyGame:not found game, appId: %v", payOrder.AppId)
		return
	}

	gameOrder, err := p.DataCache.GetImpl().SecretGameOrderMgModel.Get(ctx, bson.M{"_id": payOrder.OrderNo})
	if err != nil {
		logger.Errorf(ctx, "notifyGame:not found game order, OrderNo: %v", payOrder.OrderNo)
		return
	}

	if game.NotifyUrl == "" {
		logger.Errorf(ctx, "notifyGame:notifyUrl is empty")
		return
	}

	data := &pbapi.GameNotifyBody{
		TradeId:     payOrder.OrderNo,
		OutTradeId:  gameOrder.OutTradeNum,
		Uid:         gameOrder.UserId,
		GameId:      gameOrder.GameId,
		Amount:      gameOrder.Amount,
		ProductName: gameOrder.ProductName,
		Ext:         gameOrder.Extra,
		PayStatus:   payOrder.PayStatus,
		StatusMsg:   payOrder.TradeStateDesc,
		PayTime:     payOrder.PayTime,
	}

	v, _ := json.Marshal(data)
	var encodeData map[string]any
	_ = json.Unmarshal(v, &encodeData)
	//避免json后科学计数
	encodeData["amount"] = data.Amount

	encodeData["uid"] = data.Uid
	//兼容版本uid md5 string
	if v, _ := strconv.Atoi(gameOrder.GetGameId()); v > 10001 {
		encodeData["uid"] = localUtils.MD5(strconv.FormatInt(gameOrder.GetUserId(), 10))
	}
	sign, encodeStr := localUtils.GenApiSign(encodeData, game.AppSecret)

	requestBody := &pbapi.GameNotifyReq{
		Version:    "v1.0",
		NotifyType: "PAY_CALLBACK",
		SignType:   "HmacSHA256",
		Sign:       sign,
		Body:       encodeStr,
		Timestamp:  time.Now().UnixMilli(),
	}

	callback := func() (*resty.Response, error) {
		r, err := resty.New().R().
			SetHeader("Content-Type", "application/json").
			SetBody(requestBody).
			Post(game.NotifyUrl)
		if err != nil {
			logger.Errorf(ctx, "http error:", err)
			return nil, err
		}
		return r, err
	}

	r, err := callback()
	if r.StatusCode() != http.StatusOK {
		logger.Errorf(ctx, "notifyGame:notifyUrl: FAIL")
		//简单重试
		time.Sleep(60 * time.Second)
		r, err := callback()
		if err != nil {
			logger.Errorf(ctx, "notifyGame:notifyUrl:Try again in 60 seconds: error: %v", err)
		}
		if r.StatusCode() != http.StatusOK {
			logger.Errorf(ctx, "notifyGame:notifyUrl: FAIL")
		}
		return
	}

	err = p.DataCache.GetImpl().SecretGameOrderMgModel.UpdateOne(ctx, bson.M{"_id": payOrder.OrderNo}, map[string]any{"notify_status": const_busi.PayStatusSuccess})
	if err != nil {
		logger.Errorf(ctx, "notifyGame:notifyUrl: update order pay status error : %v", err)
		return
	}

	logger.Infof(ctx, "notifyGame:notifyUrl: OK. url: %v, body:%v, response:%v", game.NotifyUrl, requestBody, r.RawResponse)
}
