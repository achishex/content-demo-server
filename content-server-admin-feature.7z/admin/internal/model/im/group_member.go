package im

import (
	"content_svr/protobuf/pbdb"
	"content_svr/pub/errors"
	"context"
	"gorm.io/gorm"
)

type IImGroupMemberDbModelModel interface {
	ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.GroupMemberDbModel, error)
	HasJoined(ctx context.Context, groupIds []string, userId string) (map[string]bool, error)
}

type GroupMemberDbModelModelImpl struct {
	DB *gorm.DB
}

func NewImGroupMemberDbModelModel(db IMDB) IImGroupMemberDbModelModel {
	return &GroupMemberDbModelModelImpl{DB: db}
}

func (impl *GroupMemberDbModelModelImpl) ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.GroupMemberDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.GroupMemberDbModel
	result := impl.DB.WithContext(ctx).Table("group_members").
		Limit(int(size)).Offset(int(offset)).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *GroupMemberDbModelModelImpl) HasJoined(ctx context.Context, groupIds []string, userId string) (map[string]bool, error) {
	res := make(map[string]bool, len(groupIds))
	for _, id := range groupIds {
		res[id] = false
	}

	var groups []*pbdb.GroupMemberDbModel
	if err := impl.DB.WithContext(ctx).Table("group_members").Select("group_id,user_id").Where("group_id in ? AND user_id = ?", groupIds, userId).Find(&groups).Error; err != nil {
		return res, err
	}

	if len(groups) == 0 {
		return res, nil
	}

	for _, item := range groups {
		if _, ok := res[item.GetGroupId()]; ok {
			res[item.GetGroupId()] = true
		}
	}

	return res, nil
}
