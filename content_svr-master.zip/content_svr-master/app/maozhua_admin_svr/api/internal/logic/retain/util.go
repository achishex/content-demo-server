package retain

func safeDiv(a float64, b int) float64 {
	if b == 0 {
		return 0
	}
	return a / float64(b)
}
