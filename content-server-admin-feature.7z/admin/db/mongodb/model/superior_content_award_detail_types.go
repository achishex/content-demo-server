package model

type SuperiorContentAwardDetail struct {
	ID               int64   `bson:"_id" json:"_id"`
	WorkId           int64   `bson:"work_id" json:"work_id"`
	UserId           int64   `bson:"user_id" json:"user_id"`                                           // 用户id
	Type             int32   `bson:"type" json:"type"`                                                 // 结算操作类型，1：结算奖励， 2： 违规扣除 3: 首条动态, 4: 微信提现中， 5：微信提现成功， 6：微信提现失败退回 7:可乐名人堂榜单奖励
	Award            float64 `bson:"award,omitempty" json:"award,omitempty"`                           // 单次金额
	CreateTime       int64   `bson:"create_time" json:"create_time"`                                   // 创建时间
	TotalAward       float64 `bson:"total_award,omitempty" json:"total_award,omitempty"`               // 用户累计奖励
	CanWithdrawAward float64 `bson:"can_withdraw_award,omitempty" json:"can_withdraw_award,omitempty"` // 可提现金额
}

// Type enum
const (
	AwardSettlement           = 1 // 有效评论人数奖励
	DeductionIllegal          = 2 // 违规扣除
	FirstWorkSettlement       = 3 // 首条动态奖励
	WechatPayWithdrawing      = 4 // 提款中
	WechatPayWithdrawSuccess  = 5 // 微信提现成功
	WechatPayWithdrawFail     = 6 // 微信提现失败
	HallOfFameAwardSettlement = 7 // 排行榜奖励

	SignLevelUpAward = 10 // 签到升级红包奖励
	AwardViewWork    = 11 // 预览动态奖励
	AwardGameTime    = 12 // 玩游戏时常奖励
	AwardSportAd     = 13 // 观看运动广告奖励
	AwardStarSignAd  = 14 // 观看星座广告奖励
	AwardSignAd      = 15 // 观看签到广告奖励

	PartnerInviteReward    = 16 //合伙人邀请奖励
	PartnerCarveUp         = 17 //合伙人瓜分奖励
	AwardSendShare         = 18 // 发送分享
	AwardGroupByCreate     = 19 // 创建群聊
	AwardGroupUserByActive = 20 // 群活跃人数
	AwardCommentFirst      = 21 // 首条评论
)
