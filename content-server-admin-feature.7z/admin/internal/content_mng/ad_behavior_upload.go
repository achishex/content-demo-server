package content_mng

import (
	"content_svr/config"
	"content_svr/internal/ad_mng"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/setting"
	"context"
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/go-resty/resty/v2"
	"math/rand"
	"strconv"
	"strings"
	"time"
)

type dataList struct {
	CvTime     int64  `json:"cvTime"`
	CvType     string `json:"cvType"`
	UserId     string `json:"userId"`
	UserIdType string `json:"userIdType"`
	CvCustom   string `json:"cvCustom"`
}

const (
	platformVivo = "vivo"
)

var (
	//cvType各平台对应值
	platformCvType = map[string]map[int]string{
		"vivo": {
			1: "ACTIVATION", //激活
			2: "REGISTER",   //注册
		},
		"huawei": {
			1: "ACTIVATION", //激活
			2: "REGISTER",   //注册
		},
	}
)

// AdBehaviorUpload 平台归因上报
func (p *ContentMng) AdBehaviorUpload(ctx context.Context, req *pbapi.AdBehaviorUploadReq) (*pbapi.AdBehaviorUploadResp, error) {
	logger.Infof(ctx, "%#v", req)
	resp := &pbapi.AdBehaviorUploadResp{Status: false}

	pct, ok := platformCvType[req.Platform]
	if !ok {
		return resp, nil
	}

	cvType, ok := pct[int(req.CvType)]
	if !ok {
		return resp, nil
	}

	dataList := []dataList{
		{
			CvTime:     time.Now().UnixMicro(),
			CvType:     cvType,
			UserId:     req.UserId,
			UserIdType: req.UserIdType,
			CvCustom:   "",
		},
	}

	logger.Infof(ctx, "vivo_dataList url %#v", dataList)

	//当前只接入vivo
	if strings.ToLower(req.Platform) != platformVivo {
		return resp, nil
	}

	adConfig := config.ServerConfig.AdConfig
	body := map[string]any{
		"srcType":  req.SrcType,
		"srcId":    adConfig.Vivo.SrcId,
		"pkgName":  "com.xiyou.miao",
		"dataList": dataList,
	}

	logger.Infof(ctx, "vivo_body url %#v", body)

	h := md5.New()
	h.Write([]byte(strconv.FormatInt(time.Now().UnixMicro(), 10)))
	nonce := hex.EncodeToString(h.Sum(nil))

	urlString := fmt.Sprintf("%s?access_token=%s&timestamp=%d&nonce=%s&advertiser_id=%s",
		adConfig.Vivo.Url,
		adConfig.Vivo.AccessToken,
		time.Now().UnixMilli(),
		nonce,
		adConfig.Vivo.AdvertiserId)

	client := resty.New()
	r, err := client.R().
		SetHeader("Content-Type", "application/json").
		SetBody(body).
		Post(urlString)
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return nil, err
	}

	logger.Infof(ctx, "vivo_http url", urlString)
	logger.Infof(ctx, "vivo_http response", r.String())

	resp.Status = true

	logger.Infof(ctx, "%#v", resp)
	return resp, nil
}

func (p *ContentMng) AdBehaviorUploadV2(ctx *gin.Context, header *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (*pbapi.AdBehaviorUploadResp, error) {
	//defer logger.Infof(ctx, "get_app_config,ctx_header=%v", utils.StructToJsonString(ctx.Request.Header))
	behaviorUp := ad_mng.BehaviorUpCtrl{DataCache: p.DataCache.GetImpl()}
	resp := &pbapi.AdBehaviorUploadResp{}
	resp.Status = true

	if !p.JudgeUpload(ctx, header, req.GetType()) {
		return resp, nil
	}

	var err error
	switch header.GetChannel() {
	case cm_const.AppChannelXiaomi:
		// 调用 小米 接口 https://api.e.mi.com/doc.html#/1.0.0-mdtag9b26f-omd/document-f0283649125f62138db43c6f5fc25686
		//err := behaviorUp.xiaomi(ctx, header, req)
		err := behaviorUp.Xiaomi2(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelOppo:
		// 调用 oppo 接口
		err := behaviorUp.Oppo(ctx, header, req)
		if err != nil {
			return resp, nil
		}

	case cm_const.AppChannelVivo:
		// 调用 vivo 接口 https://www.yuque.com/waited/aa0viv/gu0ikqgdyzdzogo7?singleDoc=#UYgtv
		err := behaviorUp.Vivo(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelBaidu:
		// https://dev2.baidu.com/content?sceneType=0&pageId=101214&nodeId=662&subhead=
		resp.Status, err = behaviorUp.Baidu(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelToutiao:
		resp.Status, err = behaviorUp.Toutiao(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelXingtu:
		resp.Status, err = behaviorUp.Xingtu(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelGdt:
	case cm_const.AppChannelYYB:
	case cm_const.AppChannelHuaWei:
	case cm_const.AppChannelHonor:
	}

	return resp, nil
}

// JudgeUpload 是否上报
func (p *ContentMng) JudgeUpload(ctx *gin.Context, header *pbapi.HttpHeaderInfo, behaviorType int32) bool {
	if behaviorType != const_busi.BehaviorTypeRegister {
		return true
	}

	var gender int32 = const_busi.Girl
	userId := middleware.GetUserID(ctx)
	if userId != 0 {
		userInfo, err := p.DataCache.GetUserInfoLocal(ctx, header, userId, false)
		if err == nil {
			gender = userInfo.UserInfoDbModel.GetGender()
		}
	}

	var scope uint
	switch header.Channel {
	//case cm_const.AppChannelMaozhua:
	case cm_const.AppChannelHuaWei:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.HuaweiBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.HuaweiGirlUploadProbability.Get()
		}
	case cm_const.AppChannelHonor:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.HonorBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.HonorGirlUploadProbability.Get()
		}
	case cm_const.AppChannelXiaomi:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.XiaomiBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.XiaomiGirlUploadProbability.Get()
		}
	case cm_const.AppChannelOppo:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.OppoBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.OppoGirlUploadProbability.Get()
		}
	case cm_const.AppChannelVivo:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.VivoBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.VivoGirlUploadProbability.Get()
		}
	case cm_const.AppChannelYYB:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.YybBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.YybGirlUploadProbability.Get()
		}
	case cm_const.AppChannelBaidu:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.BaiduBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.BaiduGirlUploadProbability.Get()
		}
	case cm_const.AppChannelToutiao:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.ToutiaoBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.ToutiaoGirlUploadProbability.Get()
		}
	case cm_const.AppChannelGdt:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.GdtBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.GdtGirlUploadProbability.Get()
		}
	case cm_const.AppChannelXingtu:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.XingtuBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.XingtuGirlUploadProbability.Get()
		}
	default:
		return false
	}

	if rand.Intn(100) <= int(scope) {
		return true
	}

	return false
}
