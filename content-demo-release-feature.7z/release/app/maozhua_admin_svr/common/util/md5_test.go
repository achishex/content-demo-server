package util

import "testing"

func TestMd5(t *testing.T) {
	t.Log(Md5("123456"))
}
