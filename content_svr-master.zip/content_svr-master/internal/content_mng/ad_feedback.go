package content_mng

import (
	"content_svr/internal/ad_mng"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"time"
)

type feedBackReq interface {
	GetOaid() string
	GetImei() string
}

func (p *ContentMng) saveFeedbackData(ctx context.Context, channel string, req feedBackReq) error {
	p.adFeedback(ctx, channel, req.GetImei(), req.GetOaid())

	behavior := ad_mng.NewBehaviorUpCtrl(p.DataCache)
	behavior.SetCallbackData(ctx, channel, utils.JsonStr(req), req.GetImei(), req.GetOaid())
	return nil
}

func (p *ContentMng) adFeedback(ctx context.Context, channel string, machineIds ...string) {
	for _, id := range machineIds {
		if id == "" {
			continue
		}
		code := p.DataCache.GetRedisAdFeedback(ctx, channel, id)
		if code == const_busi.AdFeedbackNil {
			if err := p.DataCache.SetRedisAdFeedback(ctx, channel, id, const_busi.AdFeedbackFormChannel); err != nil {
				logger.Error(ctx, "SetRedisAdFeedback error:", err)
			}
		}
	}
}

func (p *ContentMng) AdVivoFeedback(ctx context.Context, req []*pbapi.AdVivoFeedbackDbModel) (*pbapi.AdVivoFeedbackResp, error) {
	for _, ad := range req {
		err := p.saveFeedbackData(ctx, cm_const.AppChannelVivo, ad)
		if err != nil {
			return nil, err
		}
	}

	return &pbapi.AdVivoFeedbackResp{Code: 0, Msg: "操作成功"}, nil
}

func (p *ContentMng) AdVivo2Feedback(ctx context.Context, req []*pbapi.AdVivoFeedbackDbModel) (*pbapi.AdVivoFeedbackResp, error) {
	for _, ad := range req {
		err := p.saveFeedbackData(ctx, cm_const.AppChannelVivo2, ad)
		if err != nil {
			return nil, err
		}
	}

	return &pbapi.AdVivoFeedbackResp{Code: 0, Msg: "操作成功"}, nil
}

func (p *ContentMng) AdOppoFeedback(ctx context.Context, req *pbapi.AdOppoFeedbackReq) (*pbapi.AdOppoFeedbackResp, error) {
	err := p.saveFeedbackData(ctx, cm_const.AppChannelOppo, req)
	return &pbapi.AdOppoFeedbackResp{Code: 0, Msg: "操作成功"}, err
}

//func (p *ContentMng) AdXiaomiFeedback(ctx context.Context, req *pbapi.AdXiaomiFeedbackReq) (*pbapi.AdXiaomiFeedbackResp, error) {
//	p.adFeedback(ctx, cm_const.AppChannelXiaomi, req.GetImei(), req.GetOaid())
//
//	resp, err := adXiaomiCallback(ctx, req)
//	if err != nil {
//		logger.Error(ctx, "adXiaomiCallback: ", err)
//		return &pbapi.AdXiaomiFeedbackResp{Code: -2, FailMsg: "", Success: false}, err
//	}
//
//	return resp, nil
//}

func (p *ContentMng) AdXiaomiFeedback(ctx context.Context, req *pbapi.AdXiaomiFeedbackReq) (*pbapi.AdXiaomiFeedbackResp, error) {
	err := p.saveFeedbackData(ctx, cm_const.AppChannelXiaomi, req)
	return &pbapi.AdXiaomiFeedbackResp{Code: 0}, err
}

func (p *ContentMng) AdWangyiFeedback(ctx context.Context, req *pbapi.WangyiFeedbackReq) (*pbapi.WangyiFeedbackResp, error) {
	err := p.saveFeedbackData(ctx, cm_const.AppChannelWangYi, req)
	return &pbapi.WangyiFeedbackResp{}, err
}

func (p *ContentMng) AdHuaweiFeedback(ctx context.Context, req *pbapi.HuaweiFeedbackReq) (*pbapi.HuaweiFeedbackResp, error) {
	err := p.saveFeedbackData(ctx, cm_const.AppChannelHuaWei, req)

	expireTime := time.Hour * 24 * 3 // 3天
	nxkey := fmt.Sprintf("huawei_accessToken:%v", req.Oaid)

	// 记录下传过来的 accessToken
	if ok, _ := p.DataCache.GetImpl().RedisCli.SetNX(ctx, nxkey, req.CallBack, expireTime).Result(); ok {
		logger.Info(ctx, "set huawei accessToken success")
	}

	return &pbapi.HuaweiFeedbackResp{}, err
}

func (p *ContentMng) AdBaiduFeedback(ctx context.Context, req *pbapi.AdBaiduFeedbackReq) error {
	return p.saveFeedbackData(ctx, cm_const.AppChannelBaidu, req)
}

func (p *ContentMng) AdGdtFeedbackReq(ctx context.Context, req *pbapi.AdGdtFeedbackReq) error {
	// todo
	return p.saveFeedbackData(ctx, cm_const.AppChannelGdt, req)
}

func (p *ContentMng) AdToutiaoFeedbackReq(ctx context.Context, req *pbapi.AdToutiaoFeedbackReq) error {
	return p.saveFeedbackData(ctx, cm_const.AppChannelToutiao, req)
}

func (p *ContentMng) AdXingtuFeedbackReq(ctx context.Context, req *pbapi.AdXingtuFeedbackReq) error {
	return p.saveFeedbackData(ctx, cm_const.AppChannelXingtu, req)
}

func (p *ContentMng) AdKuaiShouFeedback(ctx context.Context, req *pbapi.AdKuaiShouFeedbackReq) error {
	return p.saveFeedbackData(ctx, cm_const.AppChannelKuaiShou, req)
}
