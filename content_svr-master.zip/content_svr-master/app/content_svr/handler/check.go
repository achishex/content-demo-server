package handler

import (
	"content_svr/internal/busi_comm/constant/aq_const"
	"content_svr/internal/security_mng"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"content_svr/pub/middleware"
	"github.com/gin-gonic/gin"
	"strings"
)

func (p *AdminHandler) CheckTxtContent(ctx *gin.Context, req *pbapi.CheckTxtReq) (*pbapi.CheckContentResp, error) {
	// TODO 用户频控
	uid := middleware.GetUserID(ctx)
	res, err := p.SecurityMng.CheckTxt(ctx, uid, security_mng.MArticleEventId.Nickname, req.Content, 1)
	if err != nil {
		return &pbapi.CheckContentResp{RiskLevel: shumei_proxy.TextRiskLevelPASS}, nil
	}
	if res != aq_const.AqConst.Pass {
		return &pbapi.CheckContentResp{RiskLevel: shumei_proxy.TextRiskLevelREJECT}, nil
	}
	return &pbapi.CheckContentResp{RiskLevel: shumei_proxy.TextRiskLevelPASS}, nil
}

func (p *AdminHandler) CheckImgContent(ctx *gin.Context, req *pbapi.CheckImgReq) (*pbapi.CheckContentResp, error) {
	// TODO 用户频控
	uid := middleware.GetUserID(ctx)

	if req.GetUrl() == "" {
		return &pbapi.CheckContentResp{RiskLevel: shumei_proxy.TextRiskLevelPASS}, nil
	}
	if !strings.HasPrefix(req.GetUrl(), "http") {
		return nil, errors.ErrParam
	}

	res, err := p.SecurityMng.CheckImage(ctx, uid, security_mng.MImgEventId.HeadImage, req.GetUrl())
	if err != nil {
		return &pbapi.CheckContentResp{RiskLevel: shumei_proxy.TextRiskLevelPASS}, nil
	}

	if res != aq_const.AqConst.Pass {
		return &pbapi.CheckContentResp{RiskLevel: shumei_proxy.TextRiskLevelREJECT}, nil
	}

	return &pbapi.CheckContentResp{RiskLevel: shumei_proxy.TextRiskLevelPASS}, nil
}
