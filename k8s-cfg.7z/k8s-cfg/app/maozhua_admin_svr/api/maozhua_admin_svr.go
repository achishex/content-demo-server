package main

import (
	"content_svr/app/maozhua_admin_svr/api/internal/config"
	"content_svr/app/maozhua_admin_svr/api/internal/handler"
	"content_svr/app/maozhua_admin_svr/api/internal/logic/robot"
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/common/middleware"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"flag"
	"fmt"
	"github.com/zeromicro/go-zero/core/conf"
	"github.com/zeromicro/go-zero/rest"
)

var configFile = flag.String("f", "etc/maozhua_admin_svr.yaml", "the config file")

func main() {
	snow_flake.SetMachineID(7)
	flag.Parse()

	var c config.Config
	_ = conf.Load(*configFile, &c)

	server := rest.MustNewServer(c.RestConf, rest.WithNotAllowedHandler(middleware.NewCorsMiddleware().Handler()))
	defer server.Stop()
	server.Use(middleware.NewCorsMiddleware().Handle)
	//server.Use(middleware.NewLogAccessMiddleware(c.RestConf).Handle)
	server.Use(middleware.GinHandle)
	ctx := svc.NewServiceContext(c)
	handler.RegisterHandlers(server, ctx)

	go robot.InitRobotMonitor(ctx) // 机器人监听

	//bridging.RegisterHandlers(server)
	//bridging.RegisterLog(c.RestConf.Log)

	logger.DebugLogger(c.ProjectEnv)

	fmt.Printf("Starting server at %s:%d...\n", c.Host, c.Port)
	if c.Mode == "dev" {
		server.PrintRoutes()
	} else {
		logger.GoZeroLoadLogger()
	}
	server.Start()
}
