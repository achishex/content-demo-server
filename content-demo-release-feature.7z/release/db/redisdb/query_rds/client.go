package query_rds

import (
	"content_svr/db/redisdb/model"
	"content_svr/db/redisdb/model/user"
	"github.com/go-redis/redis/v8"
)

type Manage struct {
	Client *redis.Client
	Env    string

	TokenAdmin           *model.TokenAdmin
	TokenContentSvr      *model.TokenContentSvr
	UserInfo             *user.UserInfoRedis
	MzRobotRedis         *model.MzRobotRedis
	BackgroundImageRedis *model.BackgroundImageRedis
	WorkInfo             *model.WorkInfo
}

func NewClient(rds *redis.Client, env string) *Manage {
	m := &Manage{
		Client: rds,
		Env:    env,

		TokenAdmin:           model.NewTokenAdmin(rds, env),
		TokenContentSvr:      model.NewTokenContentSvr(rds, env),
		UserInfo:             user.NewUserInfoRedis(rds, env),
		MzRobotRedis:         model.NewMzRobotRedis(rds, env),
		BackgroundImageRedis: model.NewBackgroundImageRedis(rds, env),
		WorkInfo:             model.NewWorkInfoRedis(rds, env),
	}

	return m

}
