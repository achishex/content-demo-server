package shumei_proxy

// PASS：正常，建议直接放行
// REVIEW：可疑，建议人工审核
// REJECT：违规，建议直接拦截
var TextRiskLevelPASS = "PASS"
var TextRiskLevelREVIEW = "REVIEW"
var TextRiskLevelREJECT = "REJECT"

var EventIDArticle = "article"
var EventIDMessage = "message"
var EventIDComment = "comment"

type TextReq struct {
	AccessKey string `json:"accessKey"`
	AppID     string `json:"appId"`
	Type      string `json:"type"`
	EventID   string `json:"eventId"`
	Data      *Data  `json:"data"`
}

// ,omitempty
type Extra struct {
	Topic          string `json:"topic"`
	AtID           string `json:"atId"`
	Room           string `json:"room"`
	ReceiveTokenID string `json:"receiveTokenId"`
	Role           string `json:"role"`
}
type Data struct {
	Text     string `json:"text"`
	TokenID  string `json:"tokenId"`
	Lang     string `json:"lang,omitempty"`
	Nickname string `json:"nickname,omitempty"`
	IP       string `json:"ip,omitempty"`
	DeviceID string `json:"deviceId,omitempty"`
	Extra    *Extra `json:"extra,omitempty"`
}

type PhoneResp struct {
	Code             int               `json:"code"`
	Message          string            `json:"message"`
	RequestID        string            `json:"requestId"`
	PhonePrimaryInfo PhonePrimaryInfo  `json:"phonePrimaryInfo"`
	PhoneRiskLabels  []PhoneRiskLabels `json:"phoneRiskLabels"`
}

type PhonePrimaryInfo struct {
	Province string `json:"phone_province"`
	City     string `json:"phone_city"`
	Operator string `json:"phone_operator"`
}

type PhoneRiskLabels struct {
	Label1      string `json:"label1"`
	Label2      string `json:"label2"`
	Label3      string `json:"label3"`
	Description string `json:"description"`
	Timestamp   int64  `json:"timestamp"`
}

type TextResp struct {
	//AllLabels       []AllLabels   `json:"allLabels"`
	AuxInfo AuxInfo `json:"auxInfo"`
	//BusinessLabels  []interface{} `json:"businessLabels"`
	Code            int        `json:"code"`
	Message         string     `json:"message"`
	RequestID       string     `json:"requestId"`
	RiskDescription string     `json:"riskDescription"`
	RiskDetail      RiskDetail `json:"riskDetail"`
	RiskLabel1      string     `json:"riskLabel1"`
	RiskLabel2      string     `json:"riskLabel2"`
	RiskLabel3      string     `json:"riskLabel3"`
	RiskLevel       string     `json:"riskLevel"`
}

type RiskSegments struct {
	Position []int  `json:"position"`
	Segment  string `json:"segment"`
}
type RiskDetail struct {
	RiskSegments []RiskSegments `json:"riskSegments"`
}
type AllLabels struct {
	Probability     float64    `json:"probability"`
	RiskDescription string     `json:"riskDescription"`
	RiskDetail      RiskDetail `json:"riskDetail,omitempty"`
	RiskLabel1      string     `json:"riskLabel1"`
	RiskLabel2      string     `json:"riskLabel2"`
	RiskLabel3      string     `json:"riskLabel3"`
	RiskLevel       string     `json:"riskLevel"`
}
type ContactResult struct {
	ContactString string `json:"contactString"`
	ContactType   int    `json:"contactType"`
}
type AuxInfo struct {
	ContactResult []ContactResult `json:"contactResult"`
}
