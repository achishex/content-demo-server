package xlog

import (
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
)

type Logger struct {
	ctx context.Context
}

func (l Logger) mergeFields(fields []logx.LogField) string {
	s := ""
	for _, field := range fields {
		s = fmt.Sprintf("%s=%v\t", field.Key, field.Value) + s
	}

	return s
}

func (l Logger) Alert(v any) {
	logger.Error(l.ctx, "", fmt.Errorf("%v", v))
}

func (l Logger) Close() error {
	return nil
}

func (l Logger) Debug(v any, fields ...logx.LogField) {
	logger.Debug(l.ctx, fmt.Sprintf("%v\t%s", v, l.mergeFields(fields)))
}

func (l Logger) Error(v any, fields ...logx.LogField) {
	logger.Error(l.ctx, fmt.Sprintf("%v\t%s", v, l.mergeFields(fields)), nil)
}

func (l Logger) Info(v any, fields ...logx.LogField) {
	logger.Info(l.ctx, fmt.Sprintf("%v\t%s", v, l.mergeFields(fields)))
}

func (l Logger) Severe(v any) {
	logger.Error(l.ctx, "", fmt.Errorf("%v", v))
}

func (l Logger) Slow(v any, fields ...logx.LogField) {
	logger.Slow(l.ctx, fmt.Sprintf("%v\t%s", v, l.mergeFields(fields)))
}

func (l Logger) Stack(v any) {
	logger.Error(l.ctx, "", fmt.Errorf("%v", v))
}

func (l Logger) Stat(v any, fields ...logx.LogField) {
	logger.Info(l.ctx, fmt.Sprintf("%v\t%s", v, l.mergeFields(fields)))
}

func UseOldLogger() {
	l := Logger{ctx: context.Background()}
	logx.SetWriter(l)
}
