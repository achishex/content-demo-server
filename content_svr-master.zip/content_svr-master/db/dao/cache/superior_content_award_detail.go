package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type SuperiorContentAwardDetail struct {
	model.SuperiorContentAwardDetailModel
	redisManage *query_rds.Manage
}

func NewCacheSuperiorContentAwardDetail(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *SuperiorContentAwardDetail {
	return &SuperiorContentAwardDetail{
		SuperiorContentAwardDetailModel: mongo.SuperiorContentAwardDetail,
		redisManage:                     redisManage,
	}
}
