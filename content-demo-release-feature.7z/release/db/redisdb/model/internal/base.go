package internal

import (
	"github.com/go-redis/redis/v8"
	"time"
)

type RdsInfo struct {
	Env    string        // 环境
	Expire time.Duration // 超时时间
	RdsKey string        // redis key

	Client *redis.Client // 链接
}
