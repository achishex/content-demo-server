package model

// 1:待支付;3:支付成功;4:申请退款中;9:支付失败;10:已退款;
const (
	NoPay      int32 = 1
	PaySuccess int32 = 3
)
