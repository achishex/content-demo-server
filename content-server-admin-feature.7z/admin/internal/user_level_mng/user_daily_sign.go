package user_level_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"context"
)

func (p *UserLevelMng) UserDailySign(ctx context.Context,
	header *pbapi.HttpHeaderInfo) (*pbuserapi.CommLevelUpResp, error) {

	userId, err := p.getUserId(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "get user id by token failed,err=%v", err.Error())
		return nil, errorcode.LOGIN_INVALID
	}

	ss, err := p.getUserLevSession(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user level session failed,err=%v", err.Error())
		return nil, errorcode.INTERNAL_ERROR
	}

	//当前等级信息
	curLevInfo := ss.getUserLev()
	resp := &pbuserapi.CommLevelUpResp{
		BLevelUp: false,
	}
	// 已经是最高级，直接返回
	if ss.CurLevel == const_level.UserMaxLevel {
		return resp, nil
	}
	if curLevInfo.BDailySigned && config.ServerConfig.Env == "prod" {
		return nil, errorcode.GenBusiErr(errorcode.INTERNAL_ERROR, "今日已签到~")
	}
	//签到
	p.DataCache.GetImpl().SetUserDailySignFlag(ctx, userId)
	return p.checkLevUpAndUpdate(ctx, header, userId, ss, curLevInfo, 1, 0)
}
