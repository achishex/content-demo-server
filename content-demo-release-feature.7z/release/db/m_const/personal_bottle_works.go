package m_const

const (
	_             = iota
	WorkTypeImage // 图片
	WorkTypeVideo // 视频
	WorkTypeText  // 文字
)
