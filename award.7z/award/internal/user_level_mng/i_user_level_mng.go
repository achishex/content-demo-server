package user_level_mng

import (
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbuserapi"
	"context"
	"github.com/gin-gonic/gin"
)

type UserLevelMng struct {
	DataCache data_cache.IDataCacheMng
}

type IUserLevelMng interface {
	GetChitchatInfo(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbuserapi.ChitchatInfo, error)
	GetUserLevel(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbuserapi.LevelInfo, error)
	GetLevelInfo(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbuserapi.LevelAllInfoResp, error)

	UserChitChatConfirm(ctx context.Context,
		header *pbapi.HttpHeaderInfo, req *pbuserapi.ConfirmChitchatCodeReq) (*pbuserapi.CommLevelUpResp, error)
	UserDailySign(ctx context.Context,
		header *pbapi.HttpHeaderInfo) (*pbuserapi.CommLevelUpResp, error)
	AuditNotify(ctx context.Context,
		header *pbapi.HttpHeaderInfo, req *pbuserapi.AuditNotifyReq) error
	GetPublishStatus(ctx context.Context,
		header *pbapi.HttpHeaderInfo) (*pbuserapi.ChitchatStatusResp, error)

	GetUserMemberInfoLogic(
		ctx *gin.Context, userId int64) (
		data []*pbmgdb.SecretMemberInfoMgDbModel, err error)

	// 获取官方@信息
	GetRemindOfficialListLogic(ctx *gin.Context) (data []*pbapi.UserinfoDbModel, err error)

	// 获取可以@用户信息
	GetRemindMutualListLogic(
		ctx *gin.Context, userId int64, req *pbuserapi.GetRemindFollowerListReq) (
		data []*pbapi.UserinfoDbModel, total int64, err error)
}

func NewUserLevelMng(dataCache data_cache.IDataCacheMng) IUserLevelMng {
	return &UserLevelMng{
		DataCache: dataCache,
	}
}
