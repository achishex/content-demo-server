package content_mng

import (
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/pub/logger"
	"context"
)

func (p *ContentMng) CSJTalkADUpload(ctx context.Context, uid int64, req *pbapi.CSJTalkADUploadReq) (*pbapi.CSJTalkADUploadResp, error) {
	//TODO check sign
	uploaded, err := p.SendSessComp.DistinctADUpload(ctx, uid, req.GetUserId(), req.GetNonce())
	if err != nil {
		logger.Errorf(ctx, "DistinctADUpload fail, err: %v", err)
		return nil, err
	}
	if !uploaded { // 重复上报
		return &pbapi.CSJTalkADUploadResp{}, nil
	}

	uniqueId := genUniqueId(uid, req.GetUserId(), 100, int32(pbconst.PtModelTypeEnum_pt_model_type_normal))
	window := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, uid)
	if window == nil || window.GetInteractTimes() <= 0 {
		err = p.SendSessComp.IncrNoReplySendRemain(ctx, uid, req.GetUserId())
	} else {
		err = p.SendSessComp.ClearSendSessCount(ctx, uid, req.GetUserId())
	}

	if err != nil {
		logger.Errorf(ctx, "redis fail, err: %v", err)
		return nil, err
	}
	return &pbapi.CSJTalkADUploadResp{}, nil
}
