import os
import time
import torch
from typing import List
from datetime import datetime
from typing import Optional
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from optimum.onnxruntime import ORTModelForSequenceClassification
from app.services.retrieve_similar_questions import RetrieveSimilarQuestionService
from app.models.reranker_protocal import RerankRequestModel
from app.models.reranker_protocal import RerankResponseModel
from app.utils.time_op import printTime
from app.core.logs import logger
import app.services.load_model as load_model
import torch.nn.functional as F


class ReRankService():
    def __init__(self):
        pass
    
    # pass
    def Rerank(self, req: RerankRequestModel)->RerankResponseModel:
        # logger.debug(f"req id: {req.reqId}")
        beginTime = time.time()
        prompt = "Select the most relevant answer based on the user's question: "
        inputs = list()
        if req.queryType == 0:
            inputs = [f"{prompt} {req.query} [SEP] {doc}" for doc in req.onlyAnswerDocs]
        else:
            inputs = [f"{prompt} {req.query} [SEP] Q: {doc.question} A: {doc.answer}" for doc in req.qaDocs]

        logger.info(f"req id: {req.reqId}, input: {inputs}")
        # encodings = tokenizer(inputs, padding=True, truncation=True, return_tensors="pt")
        ### 推理时也将输入移动到 GPU
        encodings = load_model.tokenizer(inputs, padding=True, truncation=True, return_tensors="pt").to(load_model.device)

        with torch.no_grad():
            logits = load_model.model(**encodings).logits.squeeze(-1)
            pass
        scores = F.sigmoid(logits).tolist()
        # logger.info(f"score: {scores}")
        # scores = logits.tolist()
        
        listItem = list()
        ret = None
        if req.queryType == 0: 
            listItem = sorted(
                [{"text": d, "score": s} for d, s in zip(req.onlyAnswerDocs, scores)],
                key=lambda x: x["score"], reverse=True
            )
            ret = RerankResponseModel(onlyAnswer =listItem, questionAnswer=None )

        else:
            listItem = sorted(
                [{"question":  d.question, "answer": d.answer, "score": s} for d, s in zip(req.qaDocs, scores) ],
                key = lambda x: x["score"], reverse=True
            ) 
            ret = RerankResponseModel(onlyAnswer =None, questionAnswer=listItem )

        printTime()
        logger.debug(f"req id: {req.reqId}, response: {ret}")
        endTime = time.time()
        logger.info(f"reqid:  {req.reqId}, cost millisecond: {(endTime - beginTime) * 1000:.2f}")
        return ret
