package kafka_proxy

import (
	"content_svr/protobuf/pbkfk"
	"content_svr/pub/utils"
	"encoding/base64"
	"fmt"
	"github.com/gin-gonic/gin"
	"strconv"
	"time"
)

func GenKfkSecretLogMsg(ctx *gin.Context, req, resp string, created time.Time, dur float64) *KfkSecretLogMsg {
	var userID int64 = 0
	if val, ok := ctx.Get("ctx_user_id"); ok && val != nil {
		userID, _ = val.(int64)
	}

	return &KfkSecretLogMsg{
		UserID:  userID,
		AppType: utils.GetCtxHeadersStrVal(ctx, "Apptype"),
		Method:  ctx.Request.Method,
		Header:  getCtxHeader(ctx),
		Req:     req,
		Resp:    resp,
		Created: created,
		Dur:     dur,
	}
}

type KfkSecretLogMsg struct {
	UserID  int64
	AppType string
	Method  string
	Header  *pbkfk.CtxHeader
	Req     string
	Resp    string
	Created time.Time
	Dur     float64
}

// Enc 加密，用于记录安监日志
func (m *KfkSecretLogMsg) Enc() string {

	gzipEncBase64 := func(s string) string {
		if s == "" {
			return ""
		}

		return base64.StdEncoding.EncodeToString(utils.RC4(utils.GZip([]byte(s))))
	}

	data := map[string]string{
		"userID":  strconv.FormatInt(m.UserID, 10),
		"appType": m.AppType,
		"method":  m.Method,
		"header":  gzipEncBase64(utils.JsonStr(m.Header)),
		"req":     gzipEncBase64(m.Req),
		"resp":    gzipEncBase64(m.Resp),
		"created": m.Created.Format("2006-01-02 15:04:05"),
		"dur":     fmt.Sprintf("%.3f", m.Dur),
	}
	return utils.JsonStr(data)
}
