package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

const BackgroundImageCollectionName = "background_image"

type BackgroundImage struct {
	ID            primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`
	Number        int64              `bson:"number,omitempty" json:"number,omitempty"` // 	序号
	Image         string             `bson:"image,omitempty" json:"image"`
	TimePartStart int64              `bson:"time_part_start,omitempty" json:"time_part_start"` // 生效开始时间
	TimePartEnd   int64              `bson:"time_part_end,omitempty" json:"time_part_end"`     // 生效结束时间
	Description   string             `bson:"description,omitempty" json:"description"`         // 备注
	Status        bool               `bson:"status" json:"status"`                             // 启动状态
	Operate       []int32            `bson:"operate,omitempty" json:"operate"`                 // 涉及页面可选内容：1 动态、2 私聊
}

const (
	_                int32 = iota
	OperateWork            // 动态
	OperateTalk            // 私聊
	OperateTalkGroup       // 群聊
)

var OperateEnum = []int32{OperateWork, OperateTalk, OperateTalkGroup}
