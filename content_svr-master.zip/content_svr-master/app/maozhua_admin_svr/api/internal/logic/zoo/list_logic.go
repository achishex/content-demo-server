package zoo

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/pub/logger"
	"context"
	"github.com/zeromicro/go-zero/core/logx"
	"go.mongodb.org/mongo-driver/bson"
	"sort"
	"strconv"
)

const zoo_pay_ration = 0.7 // 收入的0.7倍作为真实收入（减去渠道费用）

type ListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ListLogic {
	return &ListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ListLogic) List(req *types.PayListReq) (resp *types.PayListResp, err error) {

	filter := bson.M{
		"day": bson.D{
			{"$gte", req.TimeStart},
			{"$lte", req.TimeEnd},
		},
		"gameId": req.GameId,
	}

	if req.Channel != "" {
		filter["channel"] = req.Channel
	}

	if req.Platform != "" {
		p, _ := strconv.Atoi(req.Platform)
		filter["platform"] = p
	}

	list, err := l.svcCtx.ReadDB.ZooGamePayDaily.FindAll(l.ctx, filter)
	if err != nil {
		return nil, err
	}

	logger.Infof(l.ctx, "list: %+v", list)

	result := make(map[uint]types.PayRespItem)
	for _, item := range list {
		value, ok := result[item.Day]

		if ok {
			value.Cost += item.Cost

			vd := value.Data
			for k, v := range item.Data {
				vd[k] += v
			}
			value.Data = vd

			result[item.Day] = value
		} else {
			result[item.Day] = types.PayRespItem{
				Day:  item.Day,
				Data: item.Data,
				Cost: item.Cost,
			}
		}
	}

	// 计算真实的收入
	for _, item := range result {
		for k, v := range item.Data {
			item.Data[k] = v * zoo_pay_ration
		}
	}

	rl := make([]types.PayRespItem, 0)
	for _, v := range result {
		rl = append(rl, v)
	}

	// 排序
	sort.Slice(rl, func(i, j int) bool {
		return rl[i].Day > rl[j].Day
	})

	return &types.PayListResp{
		List: rl,
	}, nil
}
