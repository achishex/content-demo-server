package dau

import (
	"content_svr/db/mongodb/model"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"sort"
	"strconv"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type ListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ListLogic {
	return &ListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ListLogic) List(req *types.DauListReq) (resp *types.DauListResp, err error) {
	dauRespItemList := make([]types.DauRespItem, 0)
	key := "%d" // day

	filter := map[string]interface{}{}
	if req.Channel != "" {
		filter = l.buildFilter(filter, "channel", req.Channel)
		key = key + "-" + req.Channel
	}
	if req.AppType != "" {
		filter = l.buildFilter(filter, "app_type", req.AppType)
		key = key + "-" + req.AppType
	}
	if req.Gender != 0 {
		filter = l.buildFilter(filter, "gender", req.Gender)
		key = key + "-" + strconv.Itoa(req.Gender)
	}
	if req.Market == 1 {
		filter = l.buildFilter(filter, "market", req.Market)
		key = key + "-" + strconv.Itoa(req.Market)
	}
	if req.TimeStart != 0 && req.TimeEnd != 0 {
		filter = l.buildFilter(filter, "day", bson.D{
			{"$gte", req.TimeStart},
			{"$lte", req.TimeEnd},
		})
	}

	channelList, err := l.svcCtx.ManagerOnlyReadDB.SecretUserChannelDaily.FindAll(l.ctx, filter)
	if err != nil {
		return nil, err
	}
	targetChannelMap := map[string]model.SecretUserChannelDaily{}
	for _, channelDaily := range channelList {
		uniqueKey := fmt.Sprintf(key, channelDaily.Day)
		item, ok := targetChannelMap[uniqueKey]
		if ok {
			item.ActiveUserCount += channelDaily.ActiveUserCount
			item.ActiveTargetUserCount += channelDaily.ActiveTargetUserCount
			item.NewUserCount += channelDaily.NewUserCount
			item.NewTargetUserCount += channelDaily.NewTargetUserCount
		} else {
			item = channelDaily
		}

		targetChannelMap[uniqueKey] = item
	}

	targetChannel := make([]model.SecretUserChannelDaily, 0)
	for _, daily := range targetChannelMap {
		targetChannel = append(targetChannel, daily)
	}

	sort.Slice(targetChannel, func(i, j int) bool {
		return targetChannel[i].Day < targetChannel[j].Day
	})

	for _, daily := range targetChannel {
		item := types.DauRespItem{
			Date:                  daily.Day,
			ActiveUserCount:       daily.ActiveUserCount,
			ActiveTargetUserCount: daily.ActiveTargetUserCount,
			NewUserCount:          daily.NewUserCount,
			NewTargetUserCount:    daily.NewTargetUserCount,
		}

		dauRespItemList = append(dauRespItemList, item)
	}

	resp = &types.DauListResp{
		List: dauRespItemList,
	}

	return
}

func (l *ListLogic) buildFilter(filter map[string]interface{}, key string, value interface{}) map[string]interface{} {
	switch v := value.(type) {
	case int:
		if v == 0 {
			return filter
		}
		filter[key] = value
	case string:
		if v == "" {
			return filter
		}
		filter[key] = value
	default:
		filter[key] = value
	}

	return filter
}
