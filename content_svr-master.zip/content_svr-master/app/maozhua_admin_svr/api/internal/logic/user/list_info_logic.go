package user

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/app/maozhua_admin_svr/common/xerr"
	mongoModel "content_svr/db/mongodb/model"
	mysqlModel "content_svr/db/mysqldb/model"
	"content_svr/pub/utils"
	"context"
	"github.com/zeromicro/go-zero/core/logx"
	"strconv"
)

type ListInfoLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewListInfoLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ListInfoLogic {
	return &ListInfoLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ListInfoLogic) ListInfo(req *types.ListInfoReq) (resp *types.UserListResp, err error) {
	userInfoWhere := map[string]interface{}{}
	secretActiveUserWhere := map[string]interface{}{}

	if len(req.Where) > 1 {
		return nil, xerr.ParamError.SetMsg("不允许同时填写多个参数")
	}

	for key, value := range req.Where {
		switch key {
		case "user_id":
			v, ok := value.(string)
			if !ok {
				return nil, xerr.ParamError
			}

			userId, err := strconv.Atoi(v)
			if err != nil {
				return nil, xerr.ParamError
			}
			userInfoWhere[key] = int64(userId)
			break
		case "nick_name":
			userInfoWhere[key] = value
			break
		case "phone":
			v, ok := value.(string)
			if !ok {
				return nil, xerr.ParamError
			}
			userInfoWhere[key], err = utils.EncryptPhones(v)
			if err != nil {
				return nil, err
			}
			break
		case "like_nick_name":
			secretActiveUserWhere["nickname"] = value
			break
		default:
			return nil, xerr.ParamError
		}

		break
	}

	query := &types.DbQueryList{
		Page:     req.Page,
		Size:     req.Size,
		OrderKey: req.OrderKey,
		Order:    req.Order,
	}

	var infos []*mysqlModel.UserInfo
	var total int64
	switch {
	case len(userInfoWhere) > 0:
		query.Where = userInfoWhere
		// user_info
		infos, total, err = l.svcCtx.WriteDB.UserInfo.FindPage(l.ctx, query)
		if err != nil {
			return nil, err
		}
	case len(secretActiveUserWhere) > 0:
		query.Where = secretActiveUserWhere
		filter, opt := query.ParseMongo()
		total, err = l.svcCtx.WriteDB.SecretActiveUser.Count(l.ctx, filter)
		if err != nil {
			return nil, err
		}
		if total == 0 {
			return nil, xerr.DbNotFound
		}

		activeInfos, err := l.svcCtx.WriteDB.SecretActiveUser.FindAll(l.ctx, filter, opt)
		if err != nil {
			return nil, err
		}

		var ids = make([]int64, 0)
		for _, info := range activeInfos {
			ids = append(ids, info.UserId)
		}

		// user_info
		infos, err = l.svcCtx.WriteDB.UserInfo.FindByUserIds(l.ctx, ids)
		if err != nil {
			return nil, err
		}
	default:
		return nil, xerr.ParamError
	}

	if len(infos) == 0 {
		return nil, xerr.DbNotFound
	}

	// secretUserExtInfo
	userIds := make([]int64, 0)
	for _, info := range infos {
		userIds = append(userIds, info.UserID)
	}
	extInfos, err := l.svcCtx.WriteDB.SecretUserExtInfo.FindAllByIdsNoCache(l.ctx, userIds)
	if err != nil {
		return nil, err
	}
	extInfoMap := make(map[int64]mongoModel.SecretUserExtInfo)
	for _, ext := range extInfos {
		extInfoMap[ext.ID] = ext
	}

	// secretMemberInfo
	members, err := l.svcCtx.WriteDB.SecretMemberInfo.FindAll(l.ctx, map[string]interface{}{
		"user_ids": userIds,
	})
	if err != nil {
		return nil, err
	}
	memberMap := make(map[int64]mongoModel.SecretMemberInfo)
	for _, member := range members {
		memberMap[member.UserId] = member
	}

	resp = &types.UserListResp{
		Total: total,
		List:  make([]types.UserInfo, 0),
	}
	for _, info := range infos {
		ext := extInfoMap[info.UserID]
		member := memberMap[info.UserID]
		nickName := info.NickName
		if nickName == "" {
			nickName = info.OpenNickName
		}

		photo := info.Photo
		if photo == "" {
			photo = info.OpenPhoto
		}
		photo = utils.FixImageUrl(l.svcCtx.Config.ImageHost, photo)

		phone, err := utils.DecryptPhones(info.Phone)
		if err != nil {
			logx.Error(err)
		}

		//BlackHouseOutTime
		outTimeMs, _ := l.svcCtx.RedisClient.UserInfo.GetUserInBlackHouse(l.ctx, info.UserID)

		resp.List = append(resp.List, types.UserInfo{
			UserID:             info.UserID,
			NickName:           nickName,
			Photo:              photo,
			Gender:             info.Gender,
			Description:        info.Description,
			CreateTime:         info.CreateTime,
			WorksLock:          info.WorksLock,
			Enabled:            info.Enabled,
			CommentLock:        info.CommentLock,
			City:               info.City,
			Province:           info.Province,
			Status:             info.Status,
			Phone:              phone,
			MemberType:         member.Type,
			Ulevel:             ext.Ulevel,
			ChitChatCdKey:      ext.ChitChatCdKey,
			BlackHouseOutTime:  outTimeMs,
			HomepageBackground: utils.FixImageUrl(l.svcCtx.Config.ImageHost, ext.HomepageBackground),
		})
	}

	return
}
