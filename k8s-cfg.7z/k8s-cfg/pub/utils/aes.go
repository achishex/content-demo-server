package utils

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
)

var AesUserKey = []byte("eiPJTJcUzz2KMf3DyDMSHfenrcLbmMw4")

// AESEncrypt AES/ECB/PKCS5Padding
func AESEncrypt(plaintext, key []byte) (string, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}

	bs := block.BlockSize()
	plaintext = pkcs5Padding(plaintext, bs)

	ciphertext := make([]byte, len(plaintext))
	for i := 0; i < len(plaintext); i += bs {
		block.Encrypt(ciphertext[i:], plaintext[i:])
	}

	// 返回 Base64 编码的密文字符串
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func AESDecrypt(crypt string, key []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	// 解码 Base64 密文字符串
	ciphertextBytes, err := base64.StdEncoding.DecodeString(crypt)
	if err != nil {
		return nil, err
	}

	plaintext := make([]byte, len(ciphertextBytes))
	mode := cipher.NewCBCDecrypter(block, make([]byte, block.BlockSize()))
	mode.CryptBlocks(plaintext, ciphertextBytes)

	// 去除填充字节
	plaintext = pkcs5UnPadding(plaintext)

	return plaintext, nil
}

func pkcs7Padding(origData []byte, blockSize int) []byte {
	padding := blockSize - len(origData)%blockSize
	padText := bytes.Repeat([]byte{byte(padding)}, padding)

	return append(origData, padText...)
}

func pkcs7UnPadding(origData []byte) []byte {
	length := len(origData)
	unPadding := int(origData[length-1])
	return origData[:length-unPadding]
}

func pkcs5Padding(data []byte, blockSize int) []byte {
	padding := blockSize - (len(data) % blockSize)
	padText := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(data, padText...)
}

func pkcs5UnPadding(data []byte) []byte {
	length := len(data)
	if length == 0 {
		return nil
	}
	unpadding := int(data[length-1])
	return data[:(length - unpadding)]
}
