package security_mng

import (
	"content_svr/internal/busi_comm/constant/aq_const"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"context"
	"encoding/json"
	"fmt"
	"time"
)

// CheckTxt 0-通过 1-拒绝 2-警告
// checkType 1 昵称，0 默认值

const (
	CheckTypeNickName       int32 = 1
	CheckTypeGroupName      int32 = 2
	CheckTypeGroupIntroduce int32 = 3
)

func (p *SecurityMng) CheckTxt(ctx context.Context, userId int64, eventId, content string, checkType int32) (int32, error) {
	var (
		audit = &pbmgdb.SecretAuditMgDbModel{
			Id:             snow_flake.GetSnowflakeID(),
			HookType:       cm_const.HookTypeMine,
			AuditType:      cm_const.AuditTypeText,
			Platform:       1,
			EventId:        eventId,
			UserId:         userId,
			Content:        content,
			IsRecirculate:  2,
			FeedbackStatus: 2,
			CreateTime:     time.Now().UnixMilli(),
		}
	)
	retPassed, innerResp, err := p.InnerProxy.CheckPublicTxtContent(ctx, &pbapi.PublicTxtCheckReq{
		Content:    content,
		FromUserId: userId,
		SrcType:    checkType,
	})

	if err != nil {
		logger.Errorf(ctx, "anquan check failed", err)
		return 0, err
	}

	if !retPassed {
		logger.Infof(ctx, "anquan check not pass. ret=%v", retPassed)
		audit.AuditResp = fmt.Sprintf("本平台拦截,结果：%+v", innerResp)
		_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
		return aq_const.AqConst.Reject, nil
	}

	// 数美审核
	verifyResult, resp, err := p.ShumeiProxy.CheckTxt(ctx, content, userId, eventId)
	if err != nil {
		logger.Errorf(ctx, "push_chit_chat shumeicheck failed", err)
	}

	if verifyResult != "" && verifyResult != shumei_proxy.TextRiskLevelPASS {
		logger.Infof(ctx, "push_chit_chat shumei check not pass. verifyResult=%v, content=%v", verifyResult, content)
		if resp != nil {
			auditResp, _ := json.Marshal(resp)
			audit.RequestId = resp.RequestID
			audit.HookType = cm_const.HookTypeShuMei
			audit.RiskLevel = resp.RiskLevel
			audit.AuditResp = string(auditResp)
			_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
		}

		return aq_const.AqConst.Reject, nil
	}

	return aq_const.AqConst.Pass, nil
}

func (p *SecurityMng) CheckImage(ctx context.Context, userId int64, eventId, url string) (int32, error) {
	shumeiResult, resp, err := p.ShumeiProxy.CheckImg(ctx, url, userId, eventId)
	if err != nil {
		logger.Error(ctx, "ShumeiProxy CheckImage failed", err)
		return aq_const.AqConst.Reject, err
	}

	if shumeiResult == shumei_proxy.TextRiskLevelPASS || shumeiResult == shumei_proxy.TextRiskLevelREVIEW {
		return aq_const.AqConst.Pass, nil
	} else {
		//logger.Infof(ctx, "checkImage, baiduYunResult=%v, shumeiResult=%v, url=%v", baiDuResult, shumeiResult, url)
		logger.Infof(ctx, "checkImage, shumeiResult=%v, url=%v", shumeiResult, url)

		auditResp, _ := json.Marshal(resp)
		_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, &pbmgdb.SecretAuditMgDbModel{
			Id:             snow_flake.GetSnowflakeID(),
			RequestId:      resp.RequestID,
			HookType:       cm_const.HookTypeShuMei,
			AuditType:      cm_const.AuditTypeImg,
			Platform:       1,
			EventId:        eventId,
			UserId:         userId,
			ImgUrl:         url,
			RiskLevel:      resp.RiskLevel,
			AuditResp:      string(auditResp),
			IsRecirculate:  2,
			FeedbackStatus: 2,
			CreateTime:     time.Now().UnixMilli(),
		})

		return aq_const.AqConst.Reject, nil
	}
}
