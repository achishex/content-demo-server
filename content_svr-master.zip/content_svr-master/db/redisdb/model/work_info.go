package model

import (
	"content_svr/db/redisdb/model/internal"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"github.com/zeromicro/go-zero/core/logx"
	"time"
)

type WorkInfoRedis struct {
	PersonalBottleWorkRedis *PersonalBottleWorkRedis
	SecretWorkRedis         *SecretWorkRedis
	*WorkPool
}

func NewWorkInfoRedis(rds *redis.Client, env string) *WorkInfoRedis {
	return &WorkInfoRedis{
		PersonalBottleWorkRedis: NewPersonalBottleWorkRedis(rds, env), // 作品新缓存
		SecretWorkRedis:         NewSecretWorkRedis(rds, env),         // 作品旧缓存
		WorkPool:                NewWorkPool(rds, env),                // 分发池
	}
}

func (w *WorkInfoRedis) UpdateMany(ctx context.Context, workId int64, update map[string]interface{}) error {
	pbwData := make([]interface{}, 0)
	swData := make([]interface{}, 0)
	//wpData := make([]interface{}, 0)
	for key, value := range update {
		switch key {
		case "verify_status", "status", "showScope":
			swData = append(swData, key, value)
		case "new_comment_count", "new_comment_people_count", "valid_comment_person_count":
			pbwData = append(pbwData, key, value)
		default:
		}
	}

	if len(pbwData) != 0 {
		if err := w.Client.HMSet(ctx, w.PersonalBottleWorkRedis.getRdsKey(workId), pbwData...).Err(); err != nil {
			return err
		}
	}

	if len(swData) != 0 {
		if err := w.Client.HMSet(ctx, w.SecretWorkRedis.getRdsKey(workId), swData...).Err(); err != nil {
			return err
		}
	}

	//if len(wpData) != 0 {
	//	if err := w.Client.HMSet(ctx, w.WorkPool.getRdsKeyPersonalBottleWorksShare(), wpData...).Err(); err != nil {
	//		return err
	//	}
	//}

	return nil
}

func (w *WorkInfoRedis) UpdateColumnOne(ctx context.Context, workId int64, field string, value any) error {
	switch field {
	case "verify_status", "status":
		return w.SecretWorkRedis.UpdateWork(ctx, workId, field, value)
	case "show_scope":
		field = utils.UnderscoreToCamelCase(field)
		return w.SecretWorkRedis.UpdateWork(ctx, workId, field, value)
	case "new_comment_count", "new_comment_people_count", "valid_comment_person_count":
		v := value.(int64)
		return w.PersonalBottleWorkRedis.IncWorkInfoCount(ctx, workId, field, v)
	default:
		return nil
	}
}

type PersonalBottleWorkRedis struct {
	internal.RdsInfo
}

func NewPersonalBottleWorkRedis(rds *redis.Client, env string) *PersonalBottleWorkRedis {
	return &PersonalBottleWorkRedis{
		RdsInfo: internal.RdsInfo{
			Env:    env,
			Expire: time.Hour * 24,
			Client: rds,
		},
	}
}

func (r *PersonalBottleWorkRedis) getRdsKey(workId int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:new_work_info:%v", r.Env, workId)
}

func (r *PersonalBottleWorkRedis) IncWorkInfoCount(ctx context.Context, workId int64, field string, count int64) error {
	return r.Client.HIncrBy(ctx, r.getRdsKey(workId), field, count).Err()
}

// SecretWorkRedis 老的work在redis中的缓存
/*
personal_bottle_works 表 hgetall
{
    "id": 0,
    "userId": 0,  // user_id
    "visitorCount": 0,  // 曝光量
    "talkUserCount": 0,  // 更新作品私信数
    "likeCount": 0, // 点赞数
    "status": 0, // 作品状态,0:无效；1:有效
	"verify_status": 0, // '审核状态 0待审核 1审核通过 2审核拒绝 5隐藏',
    "showScope":0, // 作品展示范围 1全部可见 2全部不可见
}
*/
type SecretWorkRedis struct {
	internal.RdsInfo
}

func NewSecretWorkRedis(rds *redis.Client, env string) *SecretWorkRedis {
	return &SecretWorkRedis{
		RdsInfo: internal.RdsInfo{
			Env:    env,
			Expire: time.Hour * 24,
			Client: rds,
		},
	}
}

func (r *SecretWorkRedis) getRdsKey(workId int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:secretBottleWorksInfo:%v", r.Env, workId)
}

//func (r *SecretWorkRedis) UpdateWorkStatus(ctx context.Context, workId int64, status int64) error {
//	return r.Client.HSet(ctx, r.getRdsKey(workId), "status", status).Err()
//}
//
//// '审核状态 0待审核 1审核通过 2审核拒绝 5隐藏',
//func (r *SecretWorkRedis) UpdateWorkVerifyStatus(ctx context.Context, workId int64, status int64) error {
//	return r.Client.HSet(ctx, r.getRdsKey(workId), "verify_status", status).Err()
//}

func (r *SecretWorkRedis) UpdateWork(ctx context.Context, workId int64, field string, value interface{}) error {
	return r.Client.HSet(ctx, r.getRdsKey(workId), field, value).Err()
}

// 分发池相关
type WorkPool struct {
	internal.RdsInfo
}

func NewWorkPool(rds *redis.Client, env string) *WorkPool {
	return &WorkPool{internal.RdsInfo{
		Env:    env,
		Expire: 0,
		RdsKey: "",
		Client: rds,
	}}
}

// 普通分发池
func (r *WorkPool) getRdsKeyPersonalBottleWorksShare() string {
	return fmt.Sprintf("platform:%v:soul_soup:personalBottleWorksShare:applet-qq", r.Env)
}

// AddToTsWorkPoolRedis 向分发池内添加数据
func (r *WorkPool) AddToTsWorkPoolRedis(ctx context.Context, workId int64) error {
	redisKey := r.getRdsKeyPersonalBottleWorksShare()
	_, err := r.Client.ZAdd(ctx, redisKey, &redis.Z{Score: float64(utils.GetCurTsMs()), Member: workId}).Result()
	if err != nil {
		logx.WithContext(ctx).Error("TsWorkPoolRedis add to ts pool failed.", err)
		return err
	}
	logx.WithContext(ctx).Infof("TsWorkPoolRedis add to ts pool suc, redisKey=%v", redisKey)
	return nil
}
