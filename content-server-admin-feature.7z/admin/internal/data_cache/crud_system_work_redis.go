package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"time"
)

// 传入 userId, 系统卡片id。 看今天是否已经给用户分发过改系统卡片。
func (p *DataCacheMng) GetUserSystemWorkReadFlagRds(ctx context.Context, userId, workId int64) bool {
	DateStr := utils.GetCurDate()
	redisKey := fmt.Sprintf(cache_const.SystemWorkReadFlagRcache.KeyFmt, DateStr, userId, workId)
	bReaded, err := p.RedisCli.Get(ctx, redisKey).Bool()
	if err != nil {
		return false
	}
	return bReaded
}

// 传入 userId, 系统卡片id。
func (p *DataCacheMng) SetUserSystemWorkReadFlagRds(ctx context.Context, userId, workId int64) error {
	DateStr := utils.GetCurDate()
	redisKey := fmt.Sprintf(cache_const.SystemWorkReadFlagRcache.KeyFmt, DateStr, userId, workId)
	expire := cache_const.SystemWorkReadFlagRcache.Expire
	_, err := p.RedisCli.Set(ctx, redisKey, true, time.Duration(expire)*time.Second).Result()
	if err != nil {
		return err
	}
	return nil
}

// 传入 userId, 系统卡片id。 看今天是否已经发布过系统贴。 星座幸运星每天只允许发一次。
func (p *DataCacheMng) GetUserSystemWorkPublishFlagRds(ctx context.Context, userId, workId int64) bool {
	DateStr := utils.GetCurDate()
	redisKey := fmt.Sprintf(cache_const.SystemWorkPublishFlagRcache.KeyFmt, DateStr, userId, workId)
	bReaded, err := p.RedisCli.Get(ctx, redisKey).Bool()
	if err != nil {
		return false
	}
	return bReaded
}

// 传入 userId, 系统卡片id。
func (p *DataCacheMng) SetUserSystemWorkPublishFlagRds(ctx context.Context, userId, workId int64) error {
	DateStr := utils.GetCurDate()
	redisKey := fmt.Sprintf(cache_const.SystemWorkPublishFlagRcache.KeyFmt, DateStr, userId, workId)
	expire := cache_const.SystemWorkPublishFlagRcache.Expire
	_, err := p.RedisCli.Set(ctx, redisKey, true, time.Duration(expire)*time.Second).Result()
	if err != nil {
		return err
	}
	logger.Infof(ctx, "SetUserSystemWorkPublishFlagRds, key=%v", redisKey)
	return nil
}

// 获取用户今天已经分发消费的作品
func (p *DataCacheMng) GetUserDayWorkCount(ctx context.Context, userId int64) (int64, error) {
	DateStr := utils.GetCurDate()
	redisKey := fmt.Sprintf(cache_const.UserReadWorkDayCountRcache.KeyFmt, DateStr, userId) // TODO
	count, err := p.RedisCli.Get(ctx, redisKey).Int64()
	if err == redis.Nil {
		logger.Error(ctx, fmt.Sprintf("GetUserLatestWorkScore redis qurey failed. key=%v", redisKey), err)
		return count, err
	}
	return count, nil
}

// 自增用户已消费的今天作品数
func (p *DataCacheMng) SetUserDayWorkCount(ctx context.Context, userId int64, count int64) error {
	DateStr := utils.GetCurDate()
	redisKey := fmt.Sprintf(cache_const.UserReadWorkDayCountRcache.KeyFmt, DateStr, userId) // TODO
	expire := cache_const.UserReadWorkDayCountRcache.Expire                                 // TODO

	_, err := p.RedisCli.IncrBy(ctx, redisKey, count).Result()
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SetUserCurReplyList set failed. key=%v", redisKey), err)
		return err
	}
	bSuc, err := p.RedisCli.Expire(ctx, redisKey, time.Duration(expire)*time.Second).Result()
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SetUserCurReplyList ret redis expire failed. key=%v, bSuc=%v", redisKey, bSuc), err)
		return err
	}
	return nil
}

func (p *DataCacheMng) DebugCleanXingZuoRedisCache(ctx context.Context, userId, workId int64) error {
	DateStr := utils.GetCurDate()
	// 已分发
	redisKey := fmt.Sprintf(cache_const.SystemWorkReadFlagRcache.KeyFmt, DateStr, userId, workId)
	err := p.RedisCli.Del(ctx, redisKey).Err()
	if err != nil && err != redis.Nil {
		logger.Errorf(ctx, "delkey failed. redisKey=%v, err=%v", redisKey, err)
		return err
	}

	// 星座卡已发布唠唠
	redisKey = fmt.Sprintf(cache_const.SystemWorkPublishFlagRcache.KeyFmt, DateStr, userId, workId)
	err = p.RedisCli.Del(ctx, redisKey).Err()
	if err != nil && err != redis.Nil {
		logger.Errorf(ctx, "delkey failed. redisKey=%v, err=%v", redisKey, err)
		return err
	}

	// 星座卡已发布。
	redisKey = fmt.Sprintf(cache_const.UserReadWorkDayCountRcache.KeyFmt, DateStr, userId)
	err = p.RedisCli.Del(ctx, redisKey).Err()
	if err != nil && err != redis.Nil {
		logger.Errorf(ctx, "delkey failed. redisKey=%v, err=%v", redisKey, err)
		return err
	}
	logger.Infof(ctx, "DebugCleanXingZuoRedisCache suc. userid=%v, workid=%v", userId, workId)
	return nil
}

// 传入 userId, 卡片id。 看是否已经给用户分发过该卡片。		//主要用于给官方号做活动
func (p *DataCacheMng) GetUserWorkReadTsRds(ctx context.Context, userId, workId int64) int64 {
	redisKey := fmt.Sprintf(cache_const.WorkReadTsRcache.KeyFmt, userId, workId)
	tsMs, err := p.RedisCli.Get(ctx, redisKey).Int64()
	if err != nil {
		return tsMs
	}
	return tsMs
}

// 传入 userId, 系统卡片id。
func (p *DataCacheMng) SetUserWorkReadTsRds(ctx context.Context, userId, workId int64) error {
	redisKey := fmt.Sprintf(cache_const.WorkReadTsRcache.KeyFmt, userId, workId)
	expire := cache_const.WorkReadTsRcache.Expire
	tsMs := (time.Now().Unix() + expire) * 1000
	_, err := p.RedisCli.Set(ctx, redisKey, tsMs, time.Duration(expire)*time.Second).Result()
	if err != nil {
		return err
	}
	return nil
}
