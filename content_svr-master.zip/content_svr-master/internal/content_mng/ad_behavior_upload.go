package content_mng

import (
	"content_svr/internal/ad_mng"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/setting"
	"fmt"
	"github.com/gin-gonic/gin"
	"math/rand"
	"time"
)

func (p *ContentMng) AdBehaviorUploadV2(ctx *gin.Context, header *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (*pbapi.AdBehaviorUploadResp, error) {
	//defer logger.Infof(ctx, "get_app_config,ctx_header=%v", utils.StructToJsonString(ctx.Request.Header))

	if req.GetType() == const_busi.BehaviorTypeActivate { // 不给第三方上报真实的的激活数据
		p.checkReportThirdPlatformRetain(ctx, header, req)

		return &pbapi.AdBehaviorUploadResp{
			Status: true,
		}, nil
	}

	if !p.JudgeUpload(ctx, header, req.GetType()) { // 使用管理后台配置的概率判断是否上报
		return &pbapi.AdBehaviorUploadResp{
			Status: true,
		}, nil
	}

	if req.GetType() == const_busi.BehaviorTypeRegister { // 给第三方上报的激活数 等于 注册数
		_, _ = p.notifyThirdPlatform(ctx, header, &pbapi.AdBehaviorUploadReqV2{
			Oaid: req.Oaid,
			Imei: req.Imei,
			Type: const_busi.BehaviorTypeActivate,
		})
	}

	resp, _ := p.notifyThirdPlatform(ctx, header, req)
	return resp, nil

}

// 判断是否给第三方平台上报次留
func (p *ContentMng) checkReportThirdPlatformRetain(ctx *gin.Context, header *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) {
	if uid := middleware.GetUserID(ctx); uid > 0 {
		now := time.Now()
		oneday := time.Hour * 24
		nxkey := fmt.Sprintf("ad_stay_nx:%v:%v", now.Format("20060102"), uid)

		if ok, _ := p.DataCache.GetImpl().RedisCli.SetNX(ctx, nxkey, 1, oneday).Result(); ok {
			if u, err := p.DataCache.GetUserBasicInfo(ctx, uid, false); err != nil {
				logger.Error(ctx, "get user fail, err %v", err)
			} else {
				if u.GetCreateTime() != "" {
					timeLayout := "2006-01-02 15:04:05"  //模版
					loc, _ := time.LoadLocation("Local") //获取当前时区
					//使用模版将需要判断的时间在对应时区转化成time.time类型
					// 次留
					if createTime, e := time.ParseInLocation(timeLayout, u.GetCreateTime(), loc); e == nil {
						c1date := createTime.Add(oneday).Format(time.DateOnly)
						ndate := now.Format(time.DateOnly)
						if c1date == ndate {
							req.Type = const_busi.BehaviorTypeNextDayRetention // 次留

							switch header.GetChannel() {
							case cm_const.AppChannelVivo, cm_const.AppChannelVivo2, cm_const.AppChannelKuaiShou:
								{
									logger.Infof(ctx, "upload 1-day stay, channel %v,uid %v, createTime: %v", header.GetChannel(), uid, createTime)
									_, _ = p.notifyThirdPlatform(ctx, header, req)
								}
							}
						}
					}
				}
			}
		}
	}
}

func (p *ContentMng) notifyThirdPlatform(ctx *gin.Context, header *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (*pbapi.AdBehaviorUploadResp, error) {
	logger.Infof(ctx, "behaviorUploadV2ToThirdChannel,channel=%v, type=%v", header.GetChannel(), req.GetType())

	behaviorUp := ad_mng.BehaviorUpCtrl{DataCache: p.DataCache.GetImpl()}

	resp := &pbapi.AdBehaviorUploadResp{}
	resp.Status = true

	var err error
	switch header.GetChannel() {
	case cm_const.AppChannelXiaomi:
		// 调用 小米 接口 https://api.e.mi.com/doc.html#/1.0.0-mdtag9b26f-omd/document-f0283649125f62138db43c6f5fc25686
		resp.Status, err = behaviorUp.Xiaomi2(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelOppo:
		// 调用 oppo 接口
		err := behaviorUp.Oppo(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelVivo, cm_const.AppChannelVivo2:
		// 调用 vivo 接口 https://www.yuque.com/waited/aa0viv/gu0ikqgdyzdzogo7?singleDoc=#UYgtv
		err := behaviorUp.Vivo(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelBaidu:
		resp.Status, err = behaviorUp.Baidu(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelToutiao:
		resp.Status, err = behaviorUp.Toutiao(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelXingtu:
		resp.Status, err = behaviorUp.Xingtu(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelKuaiShou:
		resp.Status, err = behaviorUp.KuaiShou(ctx, header, req)
		if err != nil {
			return resp, nil
		}
	case cm_const.AppChannelHuaWei:
		if err := behaviorUp.Huawei(ctx, header, req); err != nil {
			logger.Errorf(ctx, "upload huawei behavior fail, err %v", err)
		}
	case cm_const.AppChannelWangYi:
		if err := behaviorUp.WangYi(ctx, header, req); err != nil {
			logger.Errorf(ctx, "upload wangyi behavior fail, err %v", err)
		}
	case cm_const.AppChannelGdt:
	case cm_const.AppChannelYYB:
	case cm_const.AppChannelHonor:
	}

	return resp, nil
}

// JudgeUpload 是否上报
func (p *ContentMng) JudgeUpload(ctx *gin.Context, header *pbapi.HttpHeaderInfo, behaviorType int32) bool {
	if behaviorType != const_busi.BehaviorTypeRegister {
		return true
	}

	var gender int32 = const_busi.Girl
	userId := middleware.GetUserID(ctx)
	if userId != 0 {
		userInfo, err := p.DataCache.GetUserInfoLocal(ctx, userId, false)
		if err == nil {
			gender = userInfo.UserInfoDbModel.GetGender()
		}
	}

	var scope uint
	switch header.Channel {
	case cm_const.AppChannelHuaWei:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.HuaweiBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.HuaweiGirlUploadProbability.Get()
		}
	case cm_const.AppChannelHonor:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.HonorBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.HonorGirlUploadProbability.Get()
		}
	case cm_const.AppChannelXiaomi:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.XiaomiBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.XiaomiGirlUploadProbability.Get()
		}
	case cm_const.AppChannelOppo:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.OppoBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.OppoGirlUploadProbability.Get()
		}
	case cm_const.AppChannelVivo, cm_const.AppChannelVivo2:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.VivoBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.VivoGirlUploadProbability.Get()
		}
	case cm_const.AppChannelYYB:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.YybBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.YybGirlUploadProbability.Get()
		}
	case cm_const.AppChannelBaidu:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.BaiduBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.BaiduGirlUploadProbability.Get()
		}
	case cm_const.AppChannelToutiao:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.ToutiaoBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.ToutiaoGirlUploadProbability.Get()
		}
	case cm_const.AppChannelGdt:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.GdtBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.GdtGirlUploadProbability.Get()
		}
	case cm_const.AppChannelXingtu:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.XingtuBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.XingtuGirlUploadProbability.Get()
		}
	case cm_const.AppChannelKuaiShou:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.XingtuBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.XingtuGirlUploadProbability.Get()
		}
	case cm_const.AppChannelWangYi:
		if gender == const_busi.Boy {
			scope = setting.Maozhua.WangYiBoyUploadProbability.Get()
		} else {
			scope = setting.Maozhua.WangYiGirlUploadProbability.Get()
		}

	default:
		return false
	}

	if rand.Intn(100) <= int(scope) {
		return true
	}

	return false
}
