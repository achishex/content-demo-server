package di

import (
	"bytes"
	"flag"
	"github.com/goccy/go-graphviz"
	"github.com/goccy/go-graphviz/cgraph"
	"github.com/stretchr/testify/assert"
	"go.uber.org/dig"
	"io/ioutil"
	"path/filepath"
	"testing"
)

var gen = flag.Bool("gen", false, "generates dot & svg")

func TestGenProdDIGraph(t *testing.T) {
	c := NewContainer()
	genDot(t, c, "deps-prod", *gen)
}
func genDot(t *testing.T, c *dig.Container, name string, gen bool) {

	var b bytes.Buffer
	err := dig.Visualize(c, &b)
	assert.Nil(t, err)

	if gen {
		t.Log("generates dot * svg")

		dotFile := filepath.Join(".", name+".dot")
		err = ioutil.WriteFile(dotFile, b.Bytes(), 0644)
		assert.Nil(t, err)

		g := graphviz.New()
		graph, err := graphviz.ParseBytes(b.Bytes())
		assert.Nil(t, err)
		graph.SetRankDir(cgraph.LRRank)

		err = g.RenderFilename(graph, graphviz.SVG, name+".svg")
		assert.Nil(t, err)
	}
}
