package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

var _ ZooGamePayDailyModel = (*customZooGamePayDailyModel)(nil)

type (
	// ZooGamePayDailyModel is an interface to be customized, add more methods here,
	// and implement the added methods in customZooGamePayDailyModel.
	ZooGamePayDailyModel interface {
		zooGamePayDailyModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]ZooGamePayDaily, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*ZooGamePayDaily, error)
		InsertMany(ctx context.Context, data []*ZooGamePayDaily, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error)
		Upsert(ctx context.Context, filter, updateData, insertData any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error)
	}

	customZooGamePayDailyModel struct {
		*defaultZooGamePayDailyModel
	}
)

// NewZooGamePayDailyModel returns a model for the mongo.
func NewZooGamePayDailyModel(cfg MonConfig, opts ...mon.Option) ZooGamePayDailyModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), collectionNameZooGamePayDaily, opts...)
	return &customZooGamePayDailyModel{
		defaultZooGamePayDailyModel: newDefaultZooGamePayDailyModel(conn),
	}
}

func (m *customZooGamePayDailyModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	} else {
		flagType = "default"
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customZooGamePayDailyModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customZooGamePayDailyModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]ZooGamePayDaily, error) {
	result := make([]ZooGamePayDaily, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customZooGamePayDailyModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*ZooGamePayDaily, error) {
	var data ZooGamePayDaily
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customZooGamePayDailyModel) InsertMany(ctx context.Context, data []*ZooGamePayDaily, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error) {
	now := time.Now().UnixMilli()
	insertData := make([]any, 0)
	for _, datum := range data {
		datum.CreateTime = now
		datum.UpdateTime = now
		insertData = append(insertData, datum)
	}
	return m.conn.InsertMany(ctx, insertData, opts...)
}

func (m *customZooGamePayDailyModel) Upsert(ctx context.Context, filter, updateData, insertData any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error) {
	update := bson.D{
		{"$set", updateData},
		{"$setOnInsert", insertData},
	}

	opt := options.Update().SetUpsert(true)
	if len(opts) == 0 {
		return m.conn.UpdateOne(ctx, filter, update, opt)
	} else {
		opts = append([]*options.UpdateOptions{opt}, opts...)
		return m.conn.UpdateOne(ctx, filter, update, opts...)
	}
}

func (m *customZooGamePayDailyModel) Insert(ctx context.Context, data *ZooGamePayDaily) (*mongo.InsertOneResult, error) {
	//data.ID = primitive.NewObjectID()
	//data.ID = snow_flake.GetSnowflakeID()
	return m.defaultZooGamePayDailyModel.Insert(ctx, data)
}
