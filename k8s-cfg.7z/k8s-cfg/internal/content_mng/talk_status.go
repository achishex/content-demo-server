package content_mng

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/version"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/pub/logger"
	"context"
	"github.com/samber/lo"
	"time"
)

func (p *ContentMng) TalkStatus(ctx context.Context, header *pbapi.HttpHeaderInfo, uid int64, req *pbapi.TalkStatusReq) (*pbapi.TalkStatus, error) {
	resp := &pbapi.TalkStatus{}

	if req.GetFromUserId() <= 0 || uid <= 0 {
		return resp, nil
	}

	// 是否互关
	// 优先读表，降级读缓存，解决取关后数据不更新
	var err error
	resp.Mutual, err = p.DataCache.GetImpl().SecretUserFollowMgModel.GetBothFollow(ctx, uid, req.GetFromUserId())
	if err != nil {
		logger.Errorf(ctx, "GetBothFollow fail, err : %v", err)
		resp.Mutual = p.DataCache.GetUserFollowMgDBLd(ctx, uid, req.GetFromUserId())
	}
	if resp.Mutual == 1 {
		resp.Followed = 1
	} else {
		// 判断是否关注对方
		follow, err := p.GetUserFollowInfo(ctx, uid, req.GetFromUserId())
		if err != nil {
			logger.Errorf(ctx, "GetUserFollowInfo fail, err: %v", err)
			return nil, err
		}

		if follow != nil {
			resp.Followed = 1
		}
	}

	uniqueId := genUniqueId(uid, req.GetFromUserId(), req.GetWorkId(), int32(pbconst.PtModelTypeEnum_pt_model_type_normal))
	toWindow := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, uid)                   // 正向
	fromWindow := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, req.GetFromUserId()) // 反向
	if toWindow != nil {
		resp.To = fromWindow.GetInteractTimes()
		resp.StartTime = fromWindow.GetCreateTime()
		resp.EndTime = resp.StartTime + 1000*3600*24*3 //3day
		resp.SurplusTime = lo.Max([]int64{resp.EndTime - time.Now().UnixMilli(), 0})
	}
	if fromWindow != nil {
		resp.From = toWindow.GetInteractTimes()
	}

	// 金牌猫友
	if toWindow != nil && toWindow.GetPushedInteract() {
		resp.Interact = 1
	} else {
		// 从java项目抄过来
		// TODO 判断是否保留
		if req.WorkId > -1 && req.WorkId != 100 && header.GetApptype() == cm_const.AppTypeMobileIos && header.GetVersioncode() == version.CommentEmotionVersion {
			resp.Interact = 1
		}
	}

	// send_sess
	if req.GetWorkId() == 100 && p.SendSessComp.EnableTalkAD(header.GetVersioncode()) {
		u, err := p.DataCache.GetUserInfoLocal(ctx, header, uid, false)
		if err != nil {
			logger.Errorf(ctx, "GetUserInfoLocal fail, err: %v", err)
			return nil, err
		}

		var sess *pbapi.SendSess
		if resp.From <= 0 { //未首次回复
			sess, err = p.SendSessComp.GetNoReplySess(ctx, uid, req.GetFromUserId(), resp.To, u.MemberType)
			if err != nil {
				logger.Errorf(ctx, "GetNoReplySess fail, err: %v", err)
				return nil, err
			}
		} else {
			sess, err = p.SendSessComp.GetSendSess(ctx, uid, req.GetFromUserId(), u.MemberType)
			if err != nil {
				logger.Errorf(ctx, "GetSendSess fail, err: %v", err)
				return nil, err
			}
		}

		resp.SendSess = sess
	}

	return resp, nil
}
