package data_cache

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	"time"
)

func (p *DataCacheMng) GetUserOpenIdLd(ctx context.Context, header *pbapi.HttpHeaderInfo, userId int64) *pbapi.OpenUserDbModel {
	//从内存取
	cacheKey := getLocalCacheKeyOpenUserInfo(userId)
	cResp, exist := p.LocalCache.Get(cacheKey)
	if exist {
		resp, ok := cResp.(*pbapi.OpenUserDbModel)
		if ok {
			return resp
		}
	}

	appFlag := cm_const.AppNameFlagDict[header.Appname]
	cond := map[string]interface{}{
		"app_flag":  appFlag,
		"user_id":   userId,
		"open_type": cm_const.AppTypeOpenTypeDict[header.Apptype], //
	}

	items, err := p.OpenUserModel.ListItemsByCondition(ctx, cond, 1, cm_const.MaxDbSize)
	if err != nil {
		logger.Error(ctx, "OpenUserModel.ListItemsByCondition failed. ", err)
		return nil
	}
	var item *pbapi.OpenUserDbModel = nil
	if len(items) != 0 {
		item = items[0]
	}

	// save 到localcache
	bSuc := p.LocalCache.Set(cacheKey, item, go_cache.WithEx(5*60*time.Second))
	if !bSuc {
		logger.Error(ctx, fmt.Sprintf("save to local cache failed. condition=%v", cond), nil)
	}
	return item
}
