package ad_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"crypto/md5"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/go-resty/resty/v2"
	"github.com/zeromicro/go-zero/core/jsonx"
	"net/url"
	"strconv"
	"time"
)

type BehaviorUpCtrl struct {
	DataCache data_cache.IDataCacheMng
}

func NewBehaviorUpCtrl(dataCache data_cache.IDataCacheMng) *BehaviorUpCtrl {
	return &BehaviorUpCtrl{DataCache: dataCache}
}

func (b BehaviorUpCtrl) SetCallbackData(ctx context.Context, channel, data string, machineIds ...string) {
	for _, machineId := range machineIds {
		if machineId == "" {
			continue
		}
		_ = b.DataCache.GetImpl().SetRedisAdCallback(ctx, channel, machineId, data)
	}
}

func (b BehaviorUpCtrl) GetCallbackData(ctx context.Context, channel string, machineIds ...string) string {
	for _, machineId := range machineIds {
		if machineId == "" {
			continue
		}
		data := b.DataCache.GetImpl().GetRedisAdCallback(ctx, channel, machineId)
		if len(data) != 0 {
			return data
		}
	}

	return ""
}

func (b BehaviorUpCtrl) Xiaomi2(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	data := b.DataCache.GetRedisAdCallback(ctx, cm_const.AppChannelXiaomi, req.Oaid)
	if data == "" {
		data = b.DataCache.GetRedisAdCallback(ctx, cm_const.AppChannelXiaomi, req.Imei)
	}
	if data == "" {
		logger.Errorf(ctx, "找不到 xiaomi imei oaid")
		return nil
	}

	params := &pbapi.AdXiaomiFeedbackReq{}
	if err := json.Unmarshal([]byte(data), &params); err != nil {
		return err
	}

	switch req.GetType() {
	case const_busi.BehaviorTypeActivate:
		params.ConvType = "APP_ACTIVE"
	case const_busi.BehaviorTypeRegister:
		params.ConvType = "APP_REGISTER"
	case const_busi.BehaviorTypePay:

	}

	resp, err := adXiaomiCallback(ctx, params)
	if err != nil {
		return err
	}

	logger.Infof(ctx, "imei: %s oaid: %s xiaomi behavior request:%v", req.Imei, req.Oaid, params)
	logger.Infof(ctx, "xiaomi behavior response:%v", resp)
	return nil
}

func (b BehaviorUpCtrl) Xiaomi(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	// http://trail.e.mi.com/api/callback?callback=FqK3xF8WvgkYJGU4NDJkNjQwLWI2MzMtNDMxYS1hNTA0LTcyND
	// VhNWEyMDE2YlgQMTJhN2Y5ZGVjNTdhZGRhNBgFQ0xJQ0sA&oaid=12a7f9dec57adda4&conv_time=1635335972760&convType=APP_ACTIVE
	now := time.Now()
	urlString := "http://trail.e.mi.com/global/log"

	// 生成签名
	type pair struct {
		key   string
		value string
	}
	buildInfo := func(device []pair, signKey string, encryptKey string) string {
		//queryString 设备信息
		query := ""
		for i, p := range device {
			and := ""
			if i != 0 {
				and = "&"
			}
			query += fmt.Sprintf("%s%s=%s", and, p.key, p.value)
		}
		query1 := url.QueryEscape(query)
		//md5后的sign值
		sign := fmt.Sprintf("%x", md5.Sum([]byte(signKey+"&"+query1)))
		//baseData
		baseData := query + "&sign=" + sign

		l2 := len(encryptKey)
		var res []byte
		for i := range baseData {
			u := baseData[i] ^ encryptKey[i%l2]&0xFF
			res = append(res, u)
		}
		return url.QueryEscape(base64.StdEncoding.EncodeToString(res))
	}

	// 需要的参数值
	appId := "914866"
	customerId := "491842"
	info := ""     // 签名
	convType := "" // APP_ACTIVE 自定义激活  APP_REGISTER 自定义注册

	device := make([]pair, 0)
	if req.Imei != "" {
		device = append(device, pair{"imei", utils.MD5(req.Imei)})
	}
	if req.Oaid != "" && req.Imei == "" {
		device = append(device, pair{"oaid", req.Oaid})
	}
	device = append(device, pair{"conv_time", strconv.FormatInt(now.UnixMilli(), 10)})
	switch req.Type {
	case 1:
		convType = "APP_ACTIVE" // 自定义激活
		info = buildInfo(device, "XZEHduHOsLyBPhuA", "tLCJdIZqucpWOmFH")
	case 2:
		convType = "APP_REGISTER" // 自定义注册
		info = buildInfo(device, "dqhAqGfNOsZMoSld", "MIhXhHbOvasPGMlM")
	case 3:
		convType = "APP_PAY" // 自定义付费
		info = buildInfo(device, "RkMTolKgtNQzDUPa", "NMAYpjowYLmpkDKN")
	}

	// 构建请求链接
	u, err := url.Parse(urlString)
	if err != nil {
		logger.Error(ctx, "url.Parse", err)
		return err
	}
	query := u.Query()
	query.Set("appId", appId)
	query.Set("customer_id", customerId)
	query.Set("info", info)
	query.Set("conv_type", convType)
	u.RawQuery = query.Encode()

	client := resty.New()
	r, err := client.R().Get(u.String())
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return err
	}
	logger.Infof(ctx, "imei: %s oaid: %s xiaomi behavior request:%v", req.Imei, req.Oaid, u.String())
	logger.Infof(ctx, "xiaomi behavior response:%v", r.String())
	return nil
}

func (b BehaviorUpCtrl) Oppo(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	now := time.Now()

	salt := "e0u6fnlag06lc3pl"
	aesKeyBase64 := "XGAXicVG5GMBsx5bueOe4w=="
	urlString := "https://api.ads.heytapmobi.com/api/uploadActiveData"

	// 加密imei和oaid
	aesKey, _ := base64.StdEncoding.DecodeString(aesKeyBase64)
	var imei, ouid string
	var err error
	if len(req.GetImei()) != 0 {
		imei, err = utils.AESEncrypt([]byte(req.GetImei()), aesKey)
		if err != nil {
			logger.Error(ctx, "utils.AESEncrypt", err)
			return err
		}
	}
	if len(req.GetOaid()) != 0 && len(req.GetImei()) == 0 {
		ouid, err = utils.AESEncrypt([]byte(req.GetOaid()), aesKey)
		if err != nil {
			logger.Error(ctx, "utils.AESEncrypt", err)
			return err
		}
	}

	if req.Type == 3 {
		req.Type = 7 // oppo 应用付费类型为 7
	}

	body := map[string]interface{}{
		"imei":        imei,             //  imei 经过 AES 加密后的值
		"ouId":        ouid,             // 开发者 ID 经过 AES 加密后的值
		"timestamp":   now.UnixMilli(),  // 事 件 发 生 的 时 间戳 ( 毫 秒 ) ， 如1522221766623
		"pkg":         "com.xiyou.miao", // 包名，如 com.xxx或者填，快应用 id，如 100137
		"dataType":    req.Type,         // 转化数据类型： 1、激活， 2、注册 3、游戏付费
		"channel":     1,                // 渠道：1、OPPO，2、一加，0、其他
		"type":        0,                // 0：无加密（默认为 0）1：imei md5 加密2：oaid md5 加密
		"ascribeType": 0,                // 归因类型：1：广告主归因，0：OPPO归因（默认或者不填即为 0），2：助攻归因
		//"adId":        314156384,        // 请求 id
	}

	// 生成签名
	timestamp := strconv.FormatInt(now.UnixMilli(), 10)
	content, err := jsonx.MarshalToString(body)
	if err != nil {
		logger.Error(ctx, "jsonx.MarshalToString", err)
		return err
	}
	content = content + timestamp + salt
	sign := utils.MD5(content)

	client := resty.New()
	r, err := client.R().
		SetHeader("Content-Type", "application/json").
		SetHeader("signature", sign). // 签名
		SetHeader("timestamp", timestamp).
		SetBody(body).
		Post(urlString)
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return err
	}

	logger.Infof(ctx, "imei: %s oaid: %s oppo behavior request: %v", req.Imei, req.Oaid, r.Request)
	logger.Infof(ctx, "oppo behavior response: %v", r.String())
	return nil
}

func (b BehaviorUpCtrl) Vivo(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) error {
	if len(req.GetOaid()) == 0 && len(req.GetImei()) == 0 && req.GetType() > 0 {
		logger.Errorf(ctx, "quding-vivo, 参数不全，没有 oaid 或 imei 或 type")
		return errors.New("参数不全")
	}

	type item struct {
		CvTime     int64  `json:"cvTime"`
		CvType     string `json:"cvType"`
		UserId     string `json:"userId"`
		UserIdType string `json:"userIdType"`
		CvCustom   string `json:"cvCustom"`
	}

	cvType := "ACTIVATION"
	if req.GetType() == 2 {
		cvType = "REGISTER" //注册
	} else if req.GetType() == 3 {
		cvType = "PAY" // 自定义付费
	}

	userId := ""
	UserIdType := ""
	if len(req.GetOaid()) > 0 {
		userId = req.GetOaid()
		UserIdType = "OAID"
	} else if len(req.GetImei()) > 0 {
		userId = req.GetImei()
		UserIdType = "IMEI"
	}

	dataList := []item{
		{
			CvTime:     time.Now().UnixMicro(),
			CvType:     cvType,
			UserId:     userId,
			UserIdType: UserIdType,
			CvCustom:   "",
		},
	}

	logger.Infof(ctx, "vivo_dataList url %#v", dataList)

	adConfig := config.ServerConfig.AdConfig
	body := map[string]any{
		"srcType":  "APP",
		"srcId":    adConfig.Vivo.SrcId,
		"pkgName":  "com.xiyou.miao",
		"dataList": dataList,
	}

	logger.Infof(ctx, "vivo_body url %#v", body)

	h := md5.New()
	h.Write([]byte(strconv.FormatInt(time.Now().UnixMicro(), 10)))
	nonce := hex.EncodeToString(h.Sum(nil))

	urlString := fmt.Sprintf("%s?access_token=%s&timestamp=%d&nonce=%s&advertiser_id=%s",
		adConfig.Vivo.Url,
		adConfig.Vivo.AccessToken,
		time.Now().UnixMilli(),
		nonce,
		adConfig.Vivo.AdvertiserId)

	client := resty.New()
	r, err := client.R().
		SetHeader("Content-Type", "application/json").
		SetBody(body).
		Post(urlString)
	if err != nil {
		logger.Errorf(ctx, "quding-vivo, http error:", err)
		return err
	}

	logger.Infof(ctx, "imei: %s oaid: %s vivo behavior request: %v", req.Imei, req.Oaid, urlString)
	logger.Infof(ctx, "vivo_http response", r.String())
	return nil
}

func (b BehaviorUpCtrl) Baidu(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (bool, error) {
	var joinType string
	data := b.GetCallbackData(ctx, cm_const.AppChannelBaidu, req.Oaid)
	joinType = "oaid"
	if data == "" {
		if data = b.GetCallbackData(ctx, cm_const.AppChannelBaidu, req.Imei); data == "" {
			logger.Errorf(ctx, "找不到 baidu imei oaid")
			return false, nil
		}
		joinType = "imei"
	}

	params := &pbapi.AdBaiduFeedbackReq{}
	if err := json.Unmarshal([]byte(data), &params); err != nil {
		return false, err
	}
	params.JoinType = joinType
	switch req.GetType() {
	case const_busi.BehaviorTypeActivate:
		params.AType = "activate"
	case const_busi.BehaviorTypeRegister:
		params.AType = "register"
	case const_busi.BehaviorTypePay:
	case const_busi.BehaviorTypeNextDayRetention:
		params.AType = "retain_1day"
	}

	logger.Infof(ctx, "imei: %s oaid: %s xiaomi behavior params:%v", req.Imei, req.Oaid, params)
	ok, err := adBaiduCallback(ctx, params)
	if err != nil {
		return false, err
	}

	return ok, nil
}

func (b BehaviorUpCtrl) Toutiao(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (bool, error) {
	data := b.GetCallbackData(ctx, cm_const.AppChannelBaidu, req.Oaid, req.Imei)

	params := &pbapi.AdToutiaoFeedbackReq{}
	if err := json.Unmarshal([]byte(data), &params); err != nil {
		return false, err
	}

	switch req.GetType() {
	case const_busi.BehaviorTypeActivate:
		params.EventType = "active"
	case const_busi.BehaviorTypeRegister:
		params.EventType = "active_register"
	case const_busi.BehaviorTypePay:
	}

	ok, err := adToutiaoCallback(ctx, params)
	if err != nil {
		return false, err
	}
	logger.Infof(ctx, "imei: %s oaid: %s Toutiao behavior request:%v", req.Imei, req.Oaid, params)
	return ok, nil
}

func (b BehaviorUpCtrl) Xingtu(ctx context.Context, _ *pbapi.HttpHeaderInfo, req *pbapi.AdBehaviorUploadReqV2) (bool, error) {
	data := b.GetCallbackData(ctx, cm_const.AppChannelBaidu, req.Oaid, req.Imei)

	params := &pbapi.AdXingtuFeedbackReq{}
	if err := json.Unmarshal([]byte(data), &params); err != nil {
		return false, err
	}
	switch req.GetType() {
	case const_busi.BehaviorTypeActivate:
		params.EventType = 0
	case const_busi.BehaviorTypeRegister:
		params.EventType = 1
	case const_busi.BehaviorTypePay:
	}

	ok, err := adXingtuCallback(ctx, params)
	if err != nil {
		return false, err
	}

	return ok, nil
}
