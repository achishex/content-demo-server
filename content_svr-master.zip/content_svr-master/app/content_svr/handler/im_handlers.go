package handler

import (
	"bytes"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/im_mng"
	"content_svr/internal/money_task"
	"content_svr/internal/vip_mng"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbim"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/utils"
	"context"
	"github.com/OpenIMSDK/protocol/constant"
	"github.com/OpenIMSDK/protocol/group"
	"github.com/gin-gonic/gin"
	"io"
	"net/http"
	"strconv"
)

func (p *AdminHandler) UserToken(ctx *gin.Context, req *pbim.IMTokenReq) (*pbim.IMTokenResp, error) {
	if req.UserId == 0 || req.PlatformId == 0 {
		return nil, errorcode.PARAM_ERROR
	}

	resp, err := p.ImMng.UserToken(ctx, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) GroupCreate(ctx *gin.Context, req *pbim.CreateGroupReq) (*group.CreateGroupResp, error) {
	if req.GroupInfo.GroupName == "" || req.GroupInfo.FaceURL == "" {
		return nil, errorcode.PARAM_ERROR
	}

	if ok, err := utils.GroupName.MatchString(req.GroupInfo.GroupName); !ok || err != nil {
		return nil, errorcode.PARAM_ERROR
	}

	resp, err := p.ImMng.CreateGroup(ctx, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) GroupInvite(ctx *gin.Context, req *group.InviteUserToGroupReq) (*group.InviteUserToGroupResp, error) {
	if req.GroupID == "" || len(req.InvitedUserIDs) == 0 {
		return nil, errorcode.PARAM_ERROR
	}
	resp, err := p.ImMng.InviteToGroup(ctx, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) GroupJoin(ctx context.Context, req *group.JoinGroupReq) (*group.JoinGroupResp, error) {
	resp, err := p.ImMng.JoinGroup(ctx, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) GroupApplicationResponse(ctx *gin.Context, req *group.GroupApplicationResponseReq) (*group.GroupApplicationResponseResp, error) {
	resp, err := p.ImMng.GroupApplicationResponse(ctx, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) GroupKick(ctx *gin.Context, req *group.KickGroupMemberReq) (*group.KickGroupMemberResp, error) {
	resp, err := p.ImMng.KickGroup(ctx, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) GroupSet(ctx *gin.Context, req *im_mng.SetGroupInfoReq) (*group.SetGroupInfoResp, error) {
	resp, err := p.ImMng.SetGroupInfo(ctx, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) GroupReport(ctx *gin.Context, req *pbim.GroupReportReq) (*pbim.GroupReportResp, error) {
	if req.GroupId == "" {
		return nil, errorcode.PARAM_ERROR
	}

	resp, err := p.ImMng.GroupReport(ctx, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) GroupDismiss(ctx *gin.Context, req *group.DismissGroupReq) (*group.DismissGroupResp, error) {
	if req.GroupID == "" {
		return nil, errorcode.PARAM_ERROR
	}

	if resp, err := p.ImMng.DismissGroup(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (p *AdminHandler) GroupQuit(ctx *gin.Context, req *group.QuitGroupReq) (*group.QuitGroupResp, error) {
	if req.GroupID == "" {
		return nil, errorcode.PARAM_ERROR
	}

	if resp, err := p.ImMng.QuitGroup(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (p *AdminHandler) GroupTransfer(ctx *gin.Context, req *group.TransferGroupOwnerReq) (*group.TransferGroupOwnerResp, error) {
	if req.GroupID == "" {
		return nil, errorcode.PARAM_ERROR
	}

	if resp, err := p.ImMng.TransferGroup(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (p *AdminHandler) GroupSetMemberInfo(ctx *gin.Context, req *group.SetGroupMemberInfoReq) (*group.SetGroupMemberInfoResp, error) {
	if len(req.Members) == 0 {
		return nil, errorcode.PARAM_ERROR
	}

	if resp, err := p.ImMng.SetGroupMemberInfo(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (p *AdminHandler) GroupMixInfo(ctx *gin.Context, req *pbim.GroupMixInfoReq) (*pbim.GroupMixInfoResp, error) {
	if req.GroupID == "" {
		return nil, errorcode.PARAM_ERROR
	}

	if resp, err := p.ImMng.GroupMixInfo(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (p *AdminHandler) GroupBatchInfo(ctx *gin.Context, req *pbim.BatchGroupIsJoinedReq) (*pbim.BatchGroupIsJoinedResp, error) {
	if len(req.GroupIDs) <= 0 {
		return nil, errorcode.PARAM_ERROR
	}

	if resp, err := p.ImMng.GroupBatchInfo(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (p *AdminHandler) GroupMemberExtInfo(ctx *gin.Context, req *pbim.GroupMemberExtInfoReq) (*pbim.GroupMemberExtInfoResp, error) {
	if len(req.UserIDs) <= 0 {
		return nil, errorcode.PARAM_ERROR
	}

	if resp, err := p.ImMng.GroupMemberExtInfo(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (p *AdminHandler) GroupIntraCityList(ctx *gin.Context, req *pbim.IntraCityListReq) (*pbim.IntraCityListResp, error) {
	if req.Page == 0 {
		req.Page = 1
	}

	if req.Size == 0 {
		req.Size = 4
	}

	if resp, err := p.ImMng.IntraCityList(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (p *AdminHandler) GroupIntraCityLbs(ctx *gin.Context) (*pbim.IntraCityLbsResp, error) {
	if resp, err := p.ImMng.IntraCityLbs(ctx); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (p *AdminHandler) GroupIntraCitySetting(ctx *gin.Context, req *pbim.IntraCitySettingReq) (*pbim.IntraCitySettingResp, error) {
	if req.GroupId == "" {
		return nil, errorcode.PARAM_ERROR
	}

	if resp, err := p.ImMng.IntraCitySetting(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (p *AdminHandler) GroupIntraCityInfo(ctx *gin.Context, req *pbim.IntraCityInfoReq) (*pbim.IntraCityInfoResp, error) {
	if req.GroupId == "" {
		return nil, errorcode.PARAM_ERROR
	}

	if resp, err := p.ImMng.IntraCityInfo(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (p *AdminHandler) Callback(ctx *gin.Context) {
	body, err := io.ReadAll(ctx.Request.Body)
	if err != nil {
		logger.Errorf(ctx, "read body fail, err: %v", err)
		ctx.AbortWithStatus(http.StatusInternalServerError)
		return
	}
	ctx.Request.Body = io.NopCloser(bytes.NewReader(body))
	command := ctx.Query(constant.CallbackCommand)
	logger.Infof(ctx, "receive openim callback, command: %v, body: %s", command, body)

	resp := p.ImMng.Callback(ctx, command, body)
	ctx.JSON(http.StatusOK, resp)
}

func (p *AdminHandler) SyncIMUserInfo(ctx *gin.Context, req *pbim.SyncUserInfoReq) (*pbim.SyncUserInfoResp, error) {
	logger.Infof(ctx, "SyncIMUserInfo,%+v", req)

	if len(req.UserID) > 0 {
		uid, err := strconv.ParseInt(req.UserID, 10, 64)
		if err != nil {

			return nil, err
		}

		// 昵称 type=1，头像type=2，年龄type=3 , type=0 为由程序设置
		switch req.Type {
		case 1, 2, 3:
			p.moneySvc.UpdateUserTaskProgress(ctx, uid, money_task.TaskTypeEditProfile, 0)
		case 0:
		}
	}

	return p.ImMng.SyncUserInfo(ctx, req)
}

func (p *AdminHandler) CSJTalkADUpload(ctx *gin.Context, req *pbapi.CSJTalkADUploadReq) (*pbapi.CSJTalkADUploadResp, error) {
	userID := middleware.GetUserID(ctx)
	if userID < 1 || req.GetUserId() < 1 {
		logger.Errorf(ctx, "bad uid")
		return nil, errorcode.PARAM_ERROR
	}

	return p.ContentMng.CSJTalkADUpload(ctx, userID, req)
}

func (p *AdminHandler) GetVipRightsConf(ctx *gin.Context) (*vip_mng.VipRightsConf, error) {
	return p.vipMng.GetVipRightsConf(ctx)
}

func (p *AdminHandler) GetAppAD(ctx *gin.Context, _ *pbapi.GetAppAdvertisementReq) (*pbapi.GetAppAdvertisementResp, error) {
	return p.adMng.GetAppAd(ctx)
}
