package data_cache

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"fmt"
	"strings"
)

type userPermissionConst struct {
	ShareTime              int32
	PushTime               int32
	ArrestUnlimited        int32
	IdentityViewUnlimited  int32
	BindPhoneUnlimited     int32
	IdentityShareUnlimited int32
	AsyncReviewImage       int32
}

var (
	UserPermissionConst = &userPermissionConst{
		ShareTime:              1 << 0,
		PushTime:               1 << 1,
		ArrestUnlimited:        1 << 2,
		IdentityViewUnlimited:  1 << 3,
		BindPhoneUnlimited:     1 << 4,
		IdentityShareUnlimited: 1 << 5,
		AsyncReviewImage:       1 << 6,
	}
)

func getRdsEnvPrefix() string {
	if strings.ToLower(config.ServerConfig.Env) == "prod" {
		return "prod"
	} else {
		return "test"
	}
}

// // localcache		用户的所有维度缓存信息。
//func getLocalCacheKeyUserInfo(userId int64) string {
//	return fmt.Sprintf("user_info:%v", userId)
//}

// // db user_infotab redis cache
func getRdsKeyUserInfo(userId int64) string {
	return fmt.Sprintf("platform:%v:cache:userInfo:hash:%v", getRdsEnvPrefix(), userId)
}

func getRdsKeyUserInfoConfig(userId int64) string {
	return fmt.Sprintf("platform:%v:cache:userInfo:config:%v", getRdsEnvPrefix(), userId)
}

func getRdsKeyWorkInfo(workId int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:secretBottleWorksInfo:%v", getRdsEnvPrefix(), workId)
}

// localcache   workid缓存信息
func getLocalCacheKeyWorkInfo(workId int64) string {
	return fmt.Sprintf("work_info:%v", workId)
}

// localcache   workid缓存信息
func getLocalCacheKeyOpenUserInfo(userId int64) string {
	return fmt.Sprintf("open_user:%v", userId)
}

// localcache   UserInfoExtMgModel 缓存信息
func getLocalCacheKeyUserInfoExtMgModelKey(userId int64) string {
	return fmt.Sprintf("UserInfoExtMgModel:%v", userId)
}

// localcache   PoliceInfoMgDB 缓存信息
func getLocalCacheKeyPoliceInfoMgDBModel(userId int64) string {
	return fmt.Sprintf("UserPoliceInfoMgModel:%v", userId)
}

// localcache   UserInfoExtMgModel 缓存信息
func getLocalCacheKeyUserCircleWorksSwitchDbModel(userId int64) string {
	return fmt.Sprintf("UserCircleWorksSwitchDbMode:%v", userId)
}

/*
动态分发池

	key 动态id
	score 发布的时间戳(毫秒)

	时间维度保存的所有内容 workid~ts. zrange 0 1 WITHSCORES
*/
func getRdsKeyPersonalBottleWorksShare() string {
	return fmt.Sprintf("platform:%v:soul_soup:personalBottleWorksShare:applet-qq", getRdsEnvPrefix())
}

// 动态无有效评论曝光次数
func getRdsKeyWorksNoValidNumExposureCount() string {
	return fmt.Sprintf("platform:%v:soul_soup:personalBottleWorksShare:noValidNumExposureCnt", getRdsEnvPrefix())
}

// 优质内容池
func getRdsKeyHighPersonalBottleWorksShare() string {
	return fmt.Sprintf("platform:%v:soul_soup:personalBottleWorksShare:high:applet-qq", getRdsEnvPrefix())
}

// 《高》优质内容池
func getRdsKeyHighPlusPersonalBottleWorksShare() string {
	return fmt.Sprintf("platform:%v:soul_soup:personalBottleWorksShare:highPlus:applet-qq", getRdsEnvPrefix())
}

// 用户已读池子 . 超时时间 = 动态分发时间+1小时
func getKeyUserReadHistoryPool(serIdUk string) (string, int64) {
	return fmt.Sprintf("platform:%v:soul_soup:UserReadHistory:%v", getRdsEnvPrefix(), serIdUk), cm_const.DispatchHighContentMaxPastTimeS + 3600
}

// 用户权限合集 hget constkey ~ []userid:permissionInt
func getRdsKeyUserPermission() string {
	return fmt.Sprintf("platform:%v:soul_soup:whiteList", getRdsEnvPrefix())
}

// 用户会员信息 userid~ 1:ts 2:ts 3:ts
func getRdsKeyMemberType(userId int64) string {
	return fmt.Sprintf("platform:%v:secret:members:info:%v", getRdsEnvPrefix(), userId)
}

// 用户会员信息 userid~ 1:ts 2:ts 3:ts
func getRdsKeyPolice(appName string) string {
	return fmt.Sprintf("platform:%v:%v:userPolice", getRdsEnvPrefix(), appName)
}

// 用户token~useid
func getUserTokenKey(token string) string {
	return fmt.Sprintf("platform:%v:soul_soup:login_token:%v", getRdsEnvPrefix(), token)
}

// 用户Coordinate  soul_soup:secret:coordinate:
func getUserCoordinateKey(userId int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:secret:coordinate:%v", getRdsEnvPrefix(), userId)
}

// 用户黑名单池
func getUserBlackHouseKey() string {
	return fmt.Sprintf("platform:%v:soul_soup:blackHouse", getRdsEnvPrefix())
}

// 每次拉取内容后，记录最低分，下次拉去高于此分的内容直接返回。
func getRdsKeyUserLatestWorkScore(userId int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:UserLatestWorkScore:%v", getRdsEnvPrefix(), userId)
}

// 次数配置。格式: platform:prod:config:times:times_replay_limit_female
func getRdsKeyTimesConfig(busiKey string) string {
	return fmt.Sprintf("platform:%v:config:times:%v", getRdsEnvPrefix(), busiKey)
}

func getRdsKeyCommentNumsOnCommenter(user_id int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:secret:commentnums:user:%v", getRdsEnvPrefix(), user_id)
}

func getRdsKeyCommentNumsOnWork(user_id, work_id int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:secret:commentnums:work:%v:%v", getRdsEnvPrefix(), work_id, user_id)
}

// 用户在同一个动态下评论数超过一定数量[3]的数量
func getRdsKeyUserCommentNumsGtNumsOnWork(workId int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:secret:commentNumsGtNums:work:%v", getRdsEnvPrefix(), workId)
}

func getRdsKeySportRanker(key int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:secret:sport:ranker:%v", getRdsEnvPrefix(), key)
}

func getRdsKeyRobot() string {
	return fmt.Sprintf("platform:%v:robot:rules", getRdsEnvPrefix())
}

func getRdsKeyRobotComment() string {
	return fmt.Sprintf("platform:%v:pub_sub:robot", getRdsEnvPrefix())
}

func getRdsKeyBackground(category string) string {
	// category is talk or work
	return fmt.Sprintf("platform:%v:background:%s", getRdsEnvPrefix(), category)
}

// 用户备注的所有信息
func getRdsKeyRemarkName(userId int64) string {
	return fmt.Sprintf("platform:%v:user:remark_name:%d", getRdsEnvPrefix(), userId)
}

func getRdsKeyAdFeedback(channel, machineId string) string {
	return fmt.Sprintf("platform:%v:ad:%s:%s", getRdsEnvPrefix(), channel, machineId)
}
