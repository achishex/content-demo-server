package wechat_proxy

import (
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
)

func (w WechatMng) GetWechatUserInfo(ctx context.Context, at *WeChatAccessTokenResponse) (*WeChatUserInfoResponse, error) {

	url := fmt.Sprintf(UrlGetUserInfo, at.AccessToken, at.Openid)
	r, err := w.Client.NewRequest().Get(url)
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return nil, errorcode.THIRD_API_ERROR
	}

	var resp WeChatUserInfoResponse
	if err := json.Unmarshal(r.Body(), &resp); err != nil {
		logger.Errorf(ctx, "GetWechatUserInfo: json Unmarshal error: %v", err)
		return nil, errorcode.THIRD_API_ERROR
	}

	return &resp, nil
}
