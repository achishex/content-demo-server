package mg_model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type ISignDailyFortuneMgModel interface {
	GetByIdAndDate(ctx context.Context,
		signId, date int32) (*pbapi.SignDailyFortuneMgDbModel, error)
}

type SignDailyFortuneMgDbImpl struct {
	MgDB *mongo.Database
}

func NewSignDailyFortuneMgModelImpl(db *mongo.Database) ISignDailyFortuneMgModel {
	return &SignDailyFortuneMgDbImpl{MgDB: db}
}
func (impl *SignDailyFortuneMgDbImpl) table() string {
	return "signDailyFortune"
}

// 1   20090606
func (impl *SignDailyFortuneMgDbImpl) GetByIdAndDate(ctx context.Context, signId, date int32) (*pbapi.SignDailyFortuneMgDbModel, error) {
	retItems := make([]*pbapi.SignDailyFortuneMgDbModel, 0)
	collection := impl.MgDB.Collection(impl.table())

	//c.Find(bson.M{"name": "Jimmy Kuu"}).All(&users)
	//find, err := collection.Find(ctx, bson.M{"signId": signId, "daily": date})
	query := bson.M{"signId": signId, "daily": date}
	find, err := collection.Find(ctx, query)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SignDailyFortuneMgDbImpl Find failed. signId=%v,date=%v",
			signId, date), err)
		return nil, err
	}

	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.SignDailyFortuneMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SignDailyFortuneMgDbImpl failed.  signId=%v,date=%v",
				signId, date), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	if len(retItems) > 1 {
		logger.Error(ctx, fmt.Sprintf("get SignDailyFortuneMgDbImpl failed. signId=%v,date=%v",
			signId, date), err)
	}
	return retItems[0], err
}
