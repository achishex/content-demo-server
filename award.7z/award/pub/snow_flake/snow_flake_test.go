package snow_flake

import "testing"

func TestGetSnowflakeID(t *testing.T) {
	t.Log(GetSnowflakeID())
}
