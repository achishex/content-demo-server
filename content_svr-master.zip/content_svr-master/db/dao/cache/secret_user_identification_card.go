package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type SecretUserIdentificationCard struct {
	model.SecretUserIdentificationCardModel
	redisManage *query_rds.Manage
}

func NewCacheSecretUserIdentificationCard(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *SecretUserIdentificationCard {
	return &SecretUserIdentificationCard{
		SecretUserIdentificationCardModel: mongo.SecretUserIdentificationCard,
		redisManage:                       redisManage,
	}
}
