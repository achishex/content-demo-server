package shumei_proxy

import (
	"bytes"
	"context"
	"net/http"
)

type ShumeiProxy struct {
	AccessKey string
	HostImage string
	HostText  string
	HostPhone string
}

type IShumeiProxy interface {
	CheckTxt(ctx context.Context, text string, userId int64, EventID string) (string, *TextResp, error)
	CheckImg(ctx context.Context, text string, userId int64, EventID string) (string, *TextResp, error)
	CheckTelPhone(ctx context.Context, phoneNum string) (int32, *PhoneResp, error)
}

func NewShumeiProxyImpl() IShumeiProxy {
	// 数美老账号
	//return &ShumeiProxy{
	//	AccessKey: "b18camc5HPSQWqAmUdBP",
	//	HostImage: "http://api-img-sh.fengkongcloud.com/image/v4",
	//	HostText:  "http://api-text-gz.fengkongcloud.com/text/v4",
	//}

	// 数美新账号
	return &ShumeiProxy{
		AccessKey: "a1PysGt5DSjg71tlJ4iK",
		HostImage: "http://api-img-sh.fengkongcloud.com/image/v4",
		HostText:  "http://api-text-gz.fengkongcloud.com/text/v4",
		HostPhone: "http://api-tianxiang-bj.fengkongcloud.com/tianxiang/v4",
	}
}

func (p *ShumeiProxy) sendPutRequest(ctx context.Context, url string, body []byte) (*http.Response, error) {
	req, err := http.NewRequest(http.MethodPut, url, bytes.NewBuffer(body))
	if err != nil {
		return nil, err
	}
	req.Header.Add("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	return resp, nil
}

func (p *ShumeiProxy) postRequest(ctx context.Context, url string, body []byte) (*http.Response, error) {
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(body))
	if err != nil {
		return nil, err
	}
	req.Header.Add("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	return resp, nil
}

func (p *ShumeiProxy) getRequest(ctx context.Context, url string) (*http.Response, error) {
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	return resp, nil
}
