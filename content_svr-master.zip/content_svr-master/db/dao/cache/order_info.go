package cache

import (
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type OrderInfo struct {
	query.OrderInfo
	redisManage *query_rds.Manage
}

func NewCacheOrderInfo(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *OrderInfo {
	return &OrderInfo{
		OrderInfo:   query.NewOrderInfo(mysql.OrderInfo),
		redisManage: redisManage,
	}
}
