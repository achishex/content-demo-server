package model

import (
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbdb"
	"content_svr/pub/errors"
	"content_svr/pub/utils"
	"context"
	"encoding/json"
	"github.com/gogo/protobuf/proto"
	"gorm.io/gorm"
	"gorm.io/plugin/dbresolver"
	"time"
)

//RealtimeRoomDbModel
// RealtimeRoomDbModel

type IRealtimeRoomDbModel interface {
	ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.RealtimeRoomDbModel, error)
	CreateOrUpdate(ctx context.Context, model *pbdb.RealtimeRoomDbModel) (*pbdb.RealtimeRoomDbModel, error)
	GetItemById(ctx context.Context, roomId int64) (*pbdb.RealtimeRoomDbModel, error)
	//ListItemByAccountIdsAndType(ctx context.Context, ids int64) ([]*pbapi.RealtimeRoomDbModel, error)
	UpdateItem(ctx context.Context, model *pbdb.RealtimeRoomDbModel) (*pbdb.RealtimeRoomDbModel, error)
	CreateItem(ctx context.Context, model *pbdb.RealtimeRoomDbModel) (*pbdb.RealtimeRoomDbModel, error)
	CountItemsByCondition(ctx context.Context, condition map[string]interface{}) (total int64, _ error)
}

type RealtimeRoomDbModelImpl struct {
	DB *gorm.DB
}

func NewRealtimeRoomImpl(db *gorm.DB) IRealtimeRoomDbModel {
	return &RealtimeRoomDbModelImpl{DB: db}
}

func (impl *RealtimeRoomDbModelImpl) table() string {
	return "realtime_room_tab"
}

func (impl *RealtimeRoomDbModelImpl) GetItemById(ctx context.Context, roomId int64) (*pbdb.RealtimeRoomDbModel, error) {
	model := pbdb.RealtimeRoomDbModel{}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Clauses(dbresolver.Write).
		Where("room_id = ?", roomId).First(&model)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &model, errors.Wrap(result.Error)
}

func (impl *RealtimeRoomDbModelImpl) CreateOrUpdate(ctx context.Context, model *pbdb.RealtimeRoomDbModel) (*pbdb.RealtimeRoomDbModel, error) {
	item, err := impl.GetItemById(ctx, model.GetRoomId())
	if err != nil {
		return nil, err
	}
	if item == nil {
		// CREATE
		item, err = impl.CreateItem(ctx, model)
	} else {
		// UPDATE
		item.Status = proto.Int32(int32(pbconst.BaseTabStatus_valid))
		item.UpdateTime = proto.String(utils.GenDbTime(time.Now()))
		item, err = impl.UpdateItem(ctx, item)
	}
	return item, err
}

func (impl *RealtimeRoomDbModelImpl) UpdateItem(ctx context.Context, model *pbdb.RealtimeRoomDbModel) (*pbdb.RealtimeRoomDbModel, error) {
	modelDict := make(map[string]interface{})
	modelByte, err := json.Marshal(model)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(modelByte, &modelDict)
	if err != nil {
		return nil, err
	}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Model(&pbdb.RealtimeRoomDbModel{RoomId: model.RoomId}).Updates(modelDict)
	return model, errors.Wrap(result.Error)
}

func (impl *RealtimeRoomDbModelImpl) CreateItem(ctx context.Context, model *pbdb.RealtimeRoomDbModel) (*pbdb.RealtimeRoomDbModel, error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Create(model)
	return model, errors.Wrap(result.Error)
}

// offset 开始查的默认值为0
func (impl *RealtimeRoomDbModelImpl) ListItemOffset(ctx context.Context, condition map[string]interface{}, page int, size int) ([]*pbdb.RealtimeRoomDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.RealtimeRoomDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(size).Offset(offset).
		Where(condition).Order("room_id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}

	return items, errors.Wrap(result.Error)
}

func (impl *RealtimeRoomDbModelImpl) ListItemsByCondition(ctx context.Context,
	condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.RealtimeRoomDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.RealtimeRoomDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(int(size)).Offset(int(offset)).
		Where(condition).Order("room_id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *RealtimeRoomDbModelImpl) CountItemsByCondition(ctx context.Context,
	condition map[string]interface{}) (total int64, _ error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Model(&pbdb.RealtimeRoomDbModel{}).Where(condition).Count(&total)
	return total, errors.Wrap(result.Error)
}

//func (impl *RealtimeRoomDbModelImpl) UpdateItemsByCondition(ctx context.Context, condition, changes map[string]interface{}) error {
//	result := impl.DB.WithContext(ctx).Table(impl.table()).Where(condition).Updates(changes)
//
//	return errors.Wrap(result.Error)
//}
//
