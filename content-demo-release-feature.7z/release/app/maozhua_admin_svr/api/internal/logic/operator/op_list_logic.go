package operator

import (
	"context"
	"github.com/jinzhu/copier"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type OpListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewOpListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *OpListLogic {
	return &OpListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *OpListLogic) OpList(req *types.OpInfoListReq) (resp *types.OpInfoListResp, err error) {
	_, offset, limit := req.ParseMysql()

	total, err := l.svcCtx.ManagerDB.OperatorTab.WithContext(l.ctx).Count()
	if err != nil {
		return nil, err
	}
	list, err := l.svcCtx.ManagerDB.OperatorTab.WithContext(l.ctx).Limit(limit).Offset(offset).Find()
	if err != nil {
		return nil, err
	}

	result := make([]types.OpInfoItem, 0)
	err = copier.Copy(&result, &list)

	resp = &types.OpInfoListResp{
		List:  result,
		Total: total,
	}

	return
}
