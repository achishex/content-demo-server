package main

import (
	"bytes"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
)

type DaoInfo struct {
}

type daoTemplate struct {
	MysqlStruct string
	MysqlObject string

	MongoStruct string
	MongoObject string
}

var (
	daoStructTemplate = `{{range .}}*cache.{{.Type}}
{{end}}`
	daoObjectTemplate = `{{range .}}{{.Type}}: cache.NewCache{{.Type}}(mysql, mongo, redisManage),
{{end}}`
)

func (c *DaoInfo) buildDaoTemplate(temp, names string, dbType ...string) string {
	tableNames := duplicateTableName(names)
	bodyTemplate := make([]TemplateObject, 0)
	for _, name := range tableNames {
		name = ChangeToDoubleHump(name)
		bodyTemplate = append(bodyTemplate, TemplateObject{
			Type: name,
		})
		if dbType != nil {
			c.createDaoCacheModelFile(name, dbType[0])
		}
	}
	data, err := parseData(temp, bodyTemplate)
	if err != nil {
		log.Fatal(err)
	}

	return data
}

func (c *DaoInfo) createDaoManageFile() {
	if !dao {
		return
	}
	dt := daoTemplate{}
	dt.MysqlStruct = c.buildDaoTemplate(daoStructTemplate, mysqlTableNames, "mysql")
	dt.MysqlObject = c.buildDaoTemplate(daoObjectTemplate, mysqlTableNames)
	dt.MongoStruct = c.buildDaoTemplate(daoStructTemplate, mongoTableNames, "mongo")
	dt.MongoObject = c.buildDaoTemplate(daoObjectTemplate, mongoTableNames)

	tPath := getPath(filepath.Join(templateDir, daoManageTemplatePath))
	wPath := getPath(filepath.Join(daoManageGoPath))
	if _, err := os.Stat(tPath); err != nil {
		log.Fatal(err)
	}

	tg := templateGroup{
		targets:   make([]target, 0),
		body:      bytes.NewBuffer(nil),
		writePath: wPath,
	}
	tg.targets = append(tg.targets, target{
		srcTemplatePath: tPath,
		data:            dt,
	})

	if err := tg.parse(); err != nil {
		log.Fatal(err)
	}

	FmtFile(wPath)

}

func (c *DaoInfo) createDaoCacheModelFile(name, dbType string) {
	tPath := getPath(filepath.Join(templateDir, daoCacheTemplatePath))
	wPath := getPath(filepath.Join(daoCacheGoPath))
	//fmt.Println(name)
	wPath = strings.ReplaceAll(wPath, "*", ChangeToUnderline(name))
	if _, err := os.Stat(wPath); err == nil {
		return
	}

	tObj := TemplateObject{
		Type: name,
	}
	var member, object string
	switch dbType {
	case "mysql":
		member = fmt.Sprintf("query.%s", name)
		object = fmt.Sprintf("%s: query.New%s(mysql.%s)", name, name, name)
	case "mongo":
		member = fmt.Sprintf("model.%sModel", name)
		object = fmt.Sprintf("%sModel: mongo.%s", name, name)
		tObj.ModelPackPath = fmtString(filepath.Join(packName, mongoDbDir, "model"))
	default:
		log.Fatal(dbType + "error")
	}
	tObj.Member = member
	tObj.Object = object

	tg := templateGroup{
		targets:   make([]target, 0),
		body:      bytes.NewBuffer(nil),
		writePath: wPath,
	}
	tg.targets = append(tg.targets, target{
		srcTemplatePath: tPath,
		data:            tObj,
	})

	if err := tg.parse(); err != nil {
		log.Fatal(err)
	}

	FmtFile(wPath)
}
