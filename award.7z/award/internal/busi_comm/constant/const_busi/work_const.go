package const_busi

// 审核状态
const (
	WorkVerifyStatusWait         = 0 //待审核
	WorkVerifyStatusIgnore       = 1 //忽略
	WorkVerifyStatusPenalize     = 2 //处罚
	WorkVerifyStatusSuspendedInf = 3 //永久封号
)

// 特殊动态标识	0
const (
	WorkSpecialNormal  = 0 //普通
	WorkSpecialMiracle = 1 //神奇骰子
	WorkSpecialWork    = 2 //动态/唠唠
)

const (
	WorkStatusInvalid = 0 //无效
	WorkStatusValid   = 1 //有效
)

// 动态类型 1 图片 2 视频 3 文字 99 表情包
const (
	WorkTypeUnknown int32 = iota
	WorkTypeImage
	WorkTypeVideo
	WorkTypeText
)

// 动态类型下的子类型
const (
	WorkSubTypeUnknown int32 = iota
	WorkSubTypeText          // 文本
	WorkSubTypeCamera        // 相机
	WorkSubTypePhoto         // 相册
	WorkSubTypeEmote         // 表情包
)
