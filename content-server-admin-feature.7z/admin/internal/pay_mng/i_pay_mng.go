package pay_mng

import (
	"content_svr/internal/data_cache"
	"content_svr/internal/inner_mng"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/thirdparty/wechat_proxy"
	"content_svr/protobuf/pbapi"
	"context"
	"net/http"
)

type IPayMng interface {
	//微信支付通知
	WechatPayNotify(ctx context.Context, request *http.Request) map[string]string
	//app支付调起签名
	GenAppSign(ctx context.Context, prepayId string) AppSignResp
	//查询微信订单
	QueryOrderByOutTradeNo(ctx context.Context, req *pbapi.QueryOrderByOutTradeNoReq) (*pbapi.QueryOrderByOutTradeNoResp, error)
}

type PayMng struct {
	DataCache  data_cache.IDataCacheMng
	InnerProxy inner_mng.IInnerProxy
	KafkaProxy kafka_proxy.IKafkaProxy
	WxProxy    wechat_proxy.IWechatProxy
}

func NewPayMng(
	dataCache data_cache.IDataCacheMng,
	innerProxy inner_mng.IInnerProxy,
	kafkaProxy kafka_proxy.IKafkaProxy,
	wxProxy wechat_proxy.IWechatProxy,
) IPayMng {
	return &PayMng{
		DataCache:  dataCache,
		InnerProxy: innerProxy,
		KafkaProxy: kafkaProxy,
		WxProxy:    wxProxy,
	}
}

type AppSignResp struct {
	MchId     string `json:"mchId"`
	PrepayId  string `json:"prepayId"`
	NonceStr  string `json:"nonceStr"`
	Timestamp string `json:"timestamp"`
	Sign      string `json:"sign"`
}
