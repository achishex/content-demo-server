package content_mng

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"time"
)

func (p *ContentMng) GetUnReadMsgNums(ctx context.Context, header *pbapi.HttpHeaderInfo) (int64, error) {
	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil || loginUserInfo == nil || loginUserInfo.UserInfoDbModel.GetUserId() <= 0 {
		logger.Errorf(ctx, "not login in CheckHomePagePrivateMessagePermission")
		return 0, errorcode.MIDAS_LOGIN_ERROR
	}
	eqCond := map[string]interface{}{
		"user_id": loginUserInfo.UserInfoDbModel.GetUserId(),
	}
	queryTime := time.Now().Add(-24 * time.Hour)
	largeCond := map[string]interface{}{
		"create_time": queryTime.Unix(),
	}
	_ = largeCond

	var specialField []string
	specialField = append(specialField, "from_user_id")

	retData, err := p.DataCache.GetImpl().PersonalCardMessageQueueDbModel.GetValidMsgItems(ctx, eqCond, nil, specialField)
	if err != nil {
		logger.Errorf(ctx, "get unread msg nums fail, err: %v, toUser: %v", err, loginUserInfo.UserInfoDbModel.GetUserId())
		return 0, err
	}
	if len(retData) <= 0 {
		logger.Infof(ctx, "has not from user msg, toUser: %v", loginUserInfo.UserInfoDbModel.GetUserId())
		return 0, nil
	}
	deRepeatedFromUseId := map[int64]bool{}
	for _, fieldNameValue := range retData {
		if fromUserId, ok := fieldNameValue["from_user_id"]; ok {
			deRepeatedFromUseId[fromUserId.(int64)] = true
		}
	}
	if len(deRepeatedFromUseId) <= 0 {
		return 0, nil
	}
	//...
	var validFromUserId map[int64]bool
	validFromUserId = p.checkFromUserIsRemove(ctx, deRepeatedFromUseId)

	validMsgItem := int64(0)
	for _, fieldNameValue := range retData {
		//map[string]int64{}
		if fromUserId, ok := fieldNameValue["from_user_id"]; ok {
			if _, isValid := validFromUserId[fromUserId.(int64)]; isValid {
				validMsgItem++
			}
		}
	}
	return validMsgItem, nil
}

func (p *ContentMng) checkFromUserIsRemove(ctx context.Context, fromUserIds map[int64]bool) map[int64]bool {
	//
	userIds := []int64{}
	for id, _ := range fromUserIds {
		userIds = append(userIds, id)
	}
	invalidUserId := map[int64]bool{}
	validUserId := map[int64]bool{}
	statusRet, err := p.DataCache.GetImpl().UserInfoModel.GetStatusByIds(ctx, userIds) //map[userId]status
	if err != nil {
		logger.Errorf(ctx, "find user status fail, %v", err)
		return nil
	}
	//....
	for originUserId, _ := range fromUserIds {
		if status, ok := statusRet[originUserId]; ok {
			if status == const_busi.UserInvalidStatus {
				invalidUserId[originUserId] = true
				//
			} else if status == const_busi.UserValidStatus {
				validUserId[originUserId] = true
				//
			} else {
				validUserId[originUserId] = true
			}
		}
	}
	logger.Infof(ctx, "valid userId: %v, invalid userId: %v", validUserId, invalidUserId)

	if len(invalidUserId) > 0 {
		var delUserIds []int64
		for userId, _ := range invalidUserId {
			delUserIds = append(delUserIds, userId)
		}
		//删除账号无效账号信息; 注销账号不做物理删除.
		//p.DataCache.GetImpl().UserInfoModel.DelUsersFromUserInfo(ctx, delUserIds)
		p.DataCache.DeleteUserInfoFromCache(ctx, delUserIds)
	}
	return validUserId
}
