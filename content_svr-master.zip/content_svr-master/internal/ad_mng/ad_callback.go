package ad_mng

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"encoding/json"
	"fmt"
	"github.com/go-resty/resty/v2"
	"net/url"
)

func adXiaomiCallback(ctx context.Context, req *pbapi.AdXiaomiFeedbackReq) error {
	//type response struct {
	//	Code    int32  `json:"code"`
	//	FailMsg string `json:"fail_msg"`
	//	Success bool   `json:"success"`
	//}
	//resp := &response{}
	urlString := "http://trail.e.mi.com/api/callback"

	callbackParam := req.Callback
	imei := req.Imei
	oaid := req.Oaid
	convTime := req.ClickTime
	convType := req.GetConvType()

	// 构建请求链接
	u, err := url.Parse(urlString)
	if err != nil {
		logger.Error(ctx, "url.Parse", err)
		return err
	}
	query := u.Query()
	query.Set("callback", callbackParam)
	query.Set("imei", imei)
	query.Set("oaid", oaid)
	query.Set("conv_time", convTime)
	query.Set("convType", convType)
	u.RawQuery = query.Encode()

	client := resty.New()
	r, err := client.R().Get(u.String())
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return err
	}
	logger.Infof(ctx, "xiaomi behavior imei: %s oaid: %s request:%v", req.Imei, req.Oaid, u.String())
	logger.Infof(ctx, "xiaomi behavior response:%v", r.String())

	return nil
}

func adBaiduCallback(ctx context.Context, req *pbapi.AdBaiduFeedbackReq) (bool, error) {
	// http://ocpc.baidu.com/ocpcapi/cb/actionCb?a_type=activate&a_value=0&sign=04fcaae4357851ff0ebc574e733d33dd

	aKey := "NTEzODU2ODk="

	// 构建请求链接
	u, err := url.Parse(req.GetCallbackUrl())
	if err != nil {
		logger.Error(ctx, "url.Parse", err)
		return false, err
	}
	query := u.Query()
	query.Set("a_type", req.AType)
	query.Set("a_value", "0")
	query.Set("join_type", req.JoinType)
	u.RawQuery = query.Encode()

	sign := utils.MD5(u.String() + aKey)
	query.Set("sign", sign)
	u.RawQuery = query.Encode()

	client := resty.New()
	r, err := client.R().Get(u.String())
	if err != nil {
		logger.Errorf(ctx, "baidu http error:", err)
		return false, err
	}

	logger.Infof(ctx, "baidu behavior imei: %s oaid: %s request:%v", req.Imei, req.Oaid, u.String())
	logger.Infof(ctx, "baidu behavior response:%v", r.String())

	type response struct {
		ErrorCode int    `json:"error_code"`
		ErrorMsg  string `json:"error_msg"`
	}
	var resp response
	if err := json.Unmarshal(r.Body(), &resp); err != nil {
		return false, err
	}

	return false, nil
}

func adToutiaoCallback(ctx context.Context, req *pbapi.AdToutiaoFeedbackReq) (bool, error) {
	urlString := `https://analytics.oceanengine.com/api/v2/conversion`

	body := map[string]interface{}{
		"event_type": req.GetEventType(),
		"context": map[string]interface{}{
			"ad": map[string]interface{}{
				"callback":   req.GetCallback(), //callback 这里需要填写的就是从启动参数里获取的 clickid
				"match_type": 0,
			},
			"device": map[string]interface{}{
				"imei": req.GetImei(),
				"idfa": req.GetOaid(),
			},
		},
	}

	client := resty.New()
	r, err := client.R().SetBody(body).Post(urlString)
	if err != nil {
		logger.Errorf(ctx, "toutiao http error:", err)
		return false, err
	}

	logger.Infof(ctx, "toutiao behavior imei: %s oaid: %s request:%v", req.Imei, req.Oaid, body)
	logger.Infof(ctx, "toutiao behavior response: %v", r.String())

	type response struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
	}
	resp := response{}
	if err := json.Unmarshal(r.Body(), &resp); err != nil {
		return false, err
	}
	if resp.Code != 0 {
		return false, errors.New(resp.Message)
	}

	return true, nil
}

func adXingtuCallback(ctx context.Context, req *pbapi.AdXingtuFeedbackReq) (bool, error) {
	//url := "https://ad.oceanengine.com/track/activate/"
	//req, err := http.NewRequest(http.MethodGet, url, nil)
	//if err != nil {
	//	log.Println(err)
	//	return nil, errors.New("new request is fail ")
	//}
	//q := req.URL.Query()
	//q.Add("callback","EJiw267wvfQCGKf2g74ZIPD89-vIATAMOAFCIjIwMTkxMTI3MTQxMTEzMDEwMDI2MDc3MjE1MTUwNTczNTBIAQ==")
	//q.Add("imei","0c2bd03c39f19845bf54ea0abafae70e")
	//q.Add("event_type",10)
	//q.Add("conv_time", 1574758519)
	//req.URL.RawQuery = q.Encode()
	//client := &amp;http.Client{}
	//return client.Do(req)

	type response struct {
		Code int    `json:"code"`
		Ret  int    `json:"ret"`
		Msg  string `json:"msg"`
	}

	resp := &response{}
	urlString := "https://ad.oceanengine.com/track/activate/"

	u, err := url.Parse(urlString)
	if err != nil {
		return false, err
	}
	query := u.Query()
	query.Set("callback", req.GetCallbackUrl())
	query.Set("imei", req.GetImei())
	query.Set("oaid", req.GetOaid())
	query.Set("event_type", fmt.Sprintf("%d", req.GetEventType()))
	query.Set("conv_time", req.Timestamp)
	u.RawQuery = query.Encode()

	client := resty.New()
	r, err := client.R().Get(urlString)
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return false, err
	}
	logger.Infof(ctx, "imei: %s oaid: %s xingtu behavior request:%v", req.Imei, req.Oaid, u.String())
	logger.Infof(ctx, "xingtu behavior response:%v", r.String())

	if err := json.Unmarshal(r.Body(), resp); err != nil {
		return false, err
	}

	if resp.Code != 0 {
		return false, nil
	}

	return true, nil
}

func adKuaiShouCallback(ctx context.Context, req *pbapi.AdKuaiShouFeedbackReq) (bool, error) {
	// 文档：https://docs.qingque.cn/d/home/eZQCUW5cBE39_ZlarHp_BWWhP?identityId=CjC4ixjMTQ#section=h.9cnktvm7ek5t
	// 完整文档： https://docs.qingque.cn/d/home/eZQCUW5cBE39_ZlarHp_BWWhP?identityId=CjC4ixjMTQ#section=h.ooxjpou867kp
	// 上报地址： http://ad.partner.gifshow.com/track/activate
	type response struct {
		Result   int    `json:"result"`
		ErrorMsg string `json:"error_msg"`
		HostName string `json:"host-name"`
	}
	resp := &response{}

	urlString := req.GetCallback()
	u, err := url.Parse(urlString)
	if err != nil {
		return false, err
	}
	query := u.Query()
	//query.Set("callback", req.GetCallback())
	query.Set("event_type", fmt.Sprintf("%d", req.GetEventType()))
	query.Set("event_time", req.GetTs())
	u.RawQuery = query.Encode()

	client := resty.New()
	r, err := client.R().Get(u.String())
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return false, err
	}
	logger.Infof(ctx, "kuaishou imei: %s oaid: %s behavior request:%v", req.Imei, req.Oaid, u.String())
	logger.Infof(ctx, "kuaishou behavior response:%v", r.String())

	if err := json.Unmarshal(r.Body(), resp); err != nil {
		return false, err
	}

	if resp.Result != 1 {
		return false, nil
	}

	return true, nil
}
