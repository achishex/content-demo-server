package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/busi_comm/trans"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"content_svr/setting"
	"context"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"regexp"
	"strconv"
	"strings"
	"time"
)

func (p *ContentMng) checkUserStatus(userInfo *data_cache.UserInfoLocal) error {
	status := userInfo.UserInfoDbModel.GetEnabled()
	switch status {
	case const_busi.UserLockTemporary:
		//TODO:
		return errorcode.USER_LOCK_INTERIM
	case const_busi.UserLockPermanent:
		return errorcode.USER_LOCK_PERMANENT
	}
	return nil
}

type IMessageQuery interface {
	PrepareLogicForQuery(ctx context.Context) error
	OfficialMessageTotalQuery(ctx context.Context) error
	NoOfficialMessageTotalQuery(ctx context.Context) error
	MessageDetailQuery(ctx context.Context, userInfo *data_cache.UserInfoLocal) error
	//
	GetQueryMessageTotalRet(ctx context.Context) []*pbapi.PersonalTalkMessageTotalMgDbModel
	GetQueryRecordRet(ctx context.Context) map[int]*pbapi.PersonalTalkMessageRecordMgDbModel
}

func NewTalkMessageQuery(impl *ContentMng, curUserInfo *data_cache.UserInfoLocal, req *pbapi.TalkMessageListReq) IMessageQuery {
	ret := &TalkMessageQuery{
		impl:              impl,
		curUserInfo:       curUserInfo,
		historyTimeMinute: 3 * 24 * 60, //3天前的数据查询
		mutualUserIds:     []int64{},
		req:               req,
		officialIds: map[int64]bool{
			129533901081600: true,
			//4424423168587776: true,
		},
	}
	ret.bbMachineIds = GetBBMachineIds()
	ret.readPacketIds = GetReadPacketIds()
	return ret
}

type TalkMessageQuery struct {
	officialIds   map[int64]bool
	bbMachineIds  map[int64]bool
	readPacketIds map[int64]bool
	impl          *ContentMng
	curUserInfo   *data_cache.UserInfoLocal
	req           *pbapi.TalkMessageListReq

	// 可查询数据的有效时间值， 默认是3天前。
	historyTimeMinute int32

	//query PersonalTalkMessageTotal cond
	skips  int32
	limits int32

	//PersonalTalkMessageTotal query result.
	mutualUserIds        []int64
	messageTotalQueryRet []*pbapi.PersonalTalkMessageTotalMgDbModel

	//PersonalTalkMessageRecord query ret
	recordQueryRet map[int]*pbapi.PersonalTalkMessageRecordMgDbModel
}

func (p *TalkMessageQuery) GetQueryMessageTotalRet(ctx context.Context) []*pbapi.PersonalTalkMessageTotalMgDbModel {
	return p.messageTotalQueryRet
}
func (p *TalkMessageQuery) GetQueryRecordRet(ctx context.Context) map[int]*pbapi.PersonalTalkMessageRecordMgDbModel {
	return p.recordQueryRet
}
func (p *TalkMessageQuery) PrepareLogicForQuery(ctx context.Context) error {
	eqCond := map[string]interface{}{
		"userId": p.curUserInfo.UserInfoDbModel.GetUserId(),
		"mutual": const_busi.MutualUsers,
	}
	mutualIds, err := p.impl.DataCache.GetImpl().SecretUserFollowMgModel.ListByCondition(ctx, eqCond, nil)
	if err != nil {
		logger.Errorf(ctx, "get mutual user fail, err: %v, for user: %v", err, p.curUserInfo.UserInfoDbModel.GetUserId())
		return errorcode.INTERNAL_DB_EXCEPTION
	}
	for i, _ := range mutualIds {
		if mutualIds[i] == nil {
			continue
		}
		p.mutualUserIds = append(p.mutualUserIds, mutualIds[i].TargetUserId)
	}

	if p.req.GetPage() == 0 {
		p.req.Page = proto.Int32(1)
	}
	if p.req.GetRows() == 0 {
		p.req.Rows = proto.Int32(20)
	}
	// page-1 -> page,
	// rows -> size
	// getOffset: page*size
	// limit: size;
	// skip: page*size

	p.skips = (p.req.GetPage() - 1) * p.req.GetRows()
	p.limits = p.req.GetRows()
	return nil
}

func (p *TalkMessageQuery) OfficialMessageTotalQuery(ctx context.Context) error {
	if _, ok := p.officialIds[p.curUserInfo.UserInfoDbModel.GetUserId()]; !ok {
		return nil
	}
	officialIdFilter := bson.M{"toUserId": p.curUserInfo.UserInfoDbModel.GetUserId(), "modeType": 0}
	sortField := map[string]int32{
		"lastReceivedTime": const_busi.SortTypeDesc,
		"unReadCount":      const_busi.SortTypeDesc,
	}

	tmpMsgTotalQueryRet, err := p.impl.DataCache.GetImpl().PersonalTalkMessageTotalMgDbModel.FindItemsWithComplexConds(ctx, officialIdFilter, sortField, p.skips, p.limits)
	if err != nil {
		logger.Errorf(ctx, "query message total fail, err: %v, toUser: %v", err, p.curUserInfo.UserInfoDbModel.GetUserId())
		return err
	}
	if len(tmpMsgTotalQueryRet) <= 0 {
		logger.Infof(ctx, "not find total message, toUser: %v", p.curUserInfo.UserInfoDbModel.GetUserId())
		return nil
	}
	p.messageTotalQueryRet = tmpMsgTotalQueryRet
	return nil
}
func GetBBMachineIds() map[int64]bool {
	bbMachineIds := make(map[int64]bool)
	bbMachineIds[config.ServerConfig.CommentConfig.ReplyCommentOfficialAccount] = true
	return bbMachineIds
}
func GetReadPacketIds() map[int64]bool {
	readPacketIds := make(map[int64]bool)
	readPacketIds[config.ServerConfig.CommentConfig.RedPacketOfficialAccount] = true
	return readPacketIds
}
func (p *TalkMessageQuery) NoOfficialMessageTotalQuery(ctx context.Context) error {
	if _, ok := p.officialIds[p.curUserInfo.UserInfoDbModel.GetUserId()]; ok {
		return nil
	}
	//
	toUserIdAndFilter := bson.M{
		"toUserId": p.curUserInfo.UserInfoDbModel.GetUserId(),
		"modeType": 0,
	}
	orBsonMs := []bson.M{}

	var officialIds []int64
	for k, _ := range p.officialIds {
		if len(officialIds) <= 0 {
			officialIds = make([]int64, 0)
		}
		officialIds = append(officialIds, k)
	}
	fromUseIdIsOfficialOr := bson.M{"fromUserId": bson.M{"$in": officialIds}}
	orBsonMs = append(orBsonMs, fromUseIdIsOfficialOr)

	var bbMachineIds []int64
	for k, _ := range p.bbMachineIds {
		if ok := p.bbMachineIds[k]; ok {
			if len(bbMachineIds) <= 0 {
				bbMachineIds = append(bbMachineIds, k)
			}
		}
	}
	fromUseIdIsBBMachineOr := bson.M{"fromUserId": bson.M{"$in": bbMachineIds}}
	orBsonMs = append(orBsonMs, fromUseIdIsBBMachineOr)

	var redPacketIds []int64
	for k, _ := range p.readPacketIds {
		if ok := p.readPacketIds[k]; ok {
			if len(redPacketIds) <= 0 {
				redPacketIds = append(redPacketIds, k)
			}
		}
	}
	fromUseIdIsReadPacketOr := bson.M{"fromUserId": bson.M{"$in": redPacketIds}}
	orBsonMs = append(orBsonMs, fromUseIdIsReadPacketOr)
	//
	noMutualUserFilterOr := bson.M{}
	fromUserInMutualFilterOr := bson.M{}
	fromUserNoInMutualFilterOr := bson.M{}
	//
	validDuration := -1 * time.Duration(p.historyTimeMinute) * time.Minute
	validId := snow_flake.GetNextId(GetValidTalkMessageTimeStampUnix(ctx, time.Now().Add(validDuration).UnixMilli()))

	if len(p.mutualUserIds) <= 0 {
		noMutualUserFilterOr = bson.M{"workId": bson.M{"$gt": -1}, "_id": bson.M{"$gte": validId}}
		orBsonMs = append(orBsonMs, noMutualUserFilterOr)
	} else {
		//validId := 4515204824006657
		fromUserInMutualFilterOr = bson.M{"fromUserId": bson.M{"$in": p.mutualUserIds}, "workId": -1}
		orBsonMs = append(orBsonMs, fromUserInMutualFilterOr)

		fromUserNoInMutualFilterOr = bson.M{"fromUserId": bson.M{"$nin": p.mutualUserIds}, "workId": bson.M{"$gt": -1}, "_id": bson.M{"$gte": validId}}
		orBsonMs = append(orBsonMs, fromUserNoInMutualFilterOr)
	}

	runFilter := bson.M{
		"$or":  orBsonMs,
		"$and": []bson.M{toUserIdAndFilter},
	}

	sortField := map[string]int32{
		"lastReceivedTime": const_busi.SortTypeDesc,
		"unReadCount":      const_busi.SortTypeDesc,
	}

	tmpMsgTotalQueryRet, err := p.impl.DataCache.GetImpl().PersonalTalkMessageTotalMgDbModel.FindItemsWithComplexConds(ctx, runFilter, sortField, p.skips, p.limits)
	if err != nil {
		logger.Errorf(ctx, "query no official id from tab fail, err: %v, query: %v", err, runFilter)
		return err
	}
	if len(tmpMsgTotalQueryRet) <= 0 {
		logger.Infof(ctx, "not find item for userId: %v", p.curUserInfo.UserInfoDbModel.GetUserId())
		return nil
	}
	p.messageTotalQueryRet = tmpMsgTotalQueryRet
	return nil
}
func (p *TalkMessageQuery) MessageDetailQuery(ctx context.Context, loginUserInfo *data_cache.UserInfoLocal) error {
	if len(p.messageTotalQueryRet) <= 0 {
		return nil
	}
	p.recordQueryRet = nil
	for k, _ := range p.messageTotalQueryRet {
		if p.messageTotalQueryRet[k] == nil {
			continue
		}
		//
		record, err := p.impl.DataCache.GetImpl().PersonalTalkMessageRecordMgDbModel.GetById(ctx, p.messageTotalQueryRet[k].GetLastMessageId())
		if err != nil {
			logger.Errorf(ctx, "find message record fail, err: %v, messgeId: %v", err, p.messageTotalQueryRet[k].GetLastMessageId())
			continue
		}
		if record == nil {
			continue
		}

		checkFromUserInMutual := func(fromUserId int64) bool {
			for _, v := range p.mutualUserIds {
				if fromUserId == v {
					return true
				}
			}
			return false
		}

		checkFromUserUnRegistered := func(fromUserId int64) bool {
			fromUserInfo, err := p.impl.DataCache.GetImpl().GetUserInfoLocal(ctx, nil, fromUserId, true)
			if err == nil && (fromUserInfo == nil || fromUserInfo.UserInfoDbModel.GetStatus() == 0) {
				return true
			}
			return false
		}

		validDuration := -1 * time.Duration(p.historyTimeMinute) * time.Minute
		isUnMutual := checkFromUserInMutual(p.messageTotalQueryRet[k].GetFromUserId()) == false
		isUnRegistered := checkFromUserUnRegistered(p.messageTotalQueryRet[k].GetFromUserId()) == true
		isExpiredItem := record.GetCreateTime() <= GetValidTalkMessageTimeStampUnix(ctx, time.Now().Add(validDuration).UnixMilli())
		if (isUnMutual && isExpiredItem && loginUserInfo.UserInfoDbModel.GetUserType() != const_busi.UserTypeOfficial3) || isUnRegistered {
			logger.Infof(ctx, "msg id: %v is before 3 days, mutual: %v, isExpired, isUnRegister: %v",
				record.GetId(), isUnMutual, isExpiredItem, isUnRegistered)
			continue
		}
		//...isMutual || noExpired || isBBMachine
		if p.recordQueryRet == nil {
			p.recordQueryRet = make(map[int]*pbapi.PersonalTalkMessageRecordMgDbModel)
		}
		p.recordQueryRet[k] = record
	}
	return nil
}

type IMessagePackageFill interface {
	HistoryAppVersionFill(ctx context.Context,
		totalMsg *pbapi.PersonalTalkMessageTotalMgDbModel,
		recordMsg *pbapi.PersonalTalkMessageRecordMgDbModel,
		response *pbapi.PersonalWorkTalkMessageResponse,
		header *pbapi.HttpHeaderInfo) error
	//
	CommonAppVersionFill(ctx context.Context,
		totalMsg *pbapi.PersonalTalkMessageTotalMgDbModel,
		recordMsg *pbapi.PersonalTalkMessageRecordMgDbModel,
		response *pbapi.PersonalWorkTalkMessageResponse, appName string) error
	//
	PackageSessionInfo(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.SimplePageInfo, error)

	//
	CalcPageSize(ctx context.Context, talkMsgRet *pbapi.SimplePageInfo, req *pbapi.TalkMessageListReq) error
}

func NewTalkMessagePackageFill(totalMsg []*pbapi.PersonalTalkMessageTotalMgDbModel, recordMsg map[int]*pbapi.PersonalTalkMessageRecordMgDbModel,
	curUserInfo *data_cache.UserInfoLocal, impl *ContentMng, queryOp IMessageQuery) IMessagePackageFill {
	//
	return &TalkMessagePackageFill{
		totalMsg:    totalMsg,
		recordMsg:   recordMsg,
		curUserInfo: curUserInfo,
		impl:        impl,
		queryOp:     queryOp,
	}
}

type TalkMessagePackageFill struct {
	totalMsg  []*pbapi.PersonalTalkMessageTotalMgDbModel
	recordMsg map[int]*pbapi.PersonalTalkMessageRecordMgDbModel
	//
	response    []*pbapi.PersonalWorkTalkMessageResponse
	curUserInfo *data_cache.UserInfoLocal
	impl        *ContentMng
	queryOp     IMessageQuery
}

func (p *TalkMessagePackageFill) CalcPageSize(ctx context.Context, talkMsgRet *pbapi.SimplePageInfo, req *pbapi.TalkMessageListReq) error {
	if talkMsgRet == nil {
		return nil
	}
	talkMsgRet.CurrentPage = req.GetPage()
	talkMsgRet.Total = int64(len(talkMsgRet.List))

	remainder := talkMsgRet.Total % int64(req.GetRows())
	pages := talkMsgRet.Total / int64(req.GetRows())
	if remainder != 0 && talkMsgRet.Total > 0 {
		pages++
	}
	talkMsgRet.Pages = int32(pages)
	return nil
}

func (p *TalkMessagePackageFill) packageWorkMsgOnMsgPlatform(ctx context.Context, totalMsg *pbapi.PersonalTalkMessageTotalMgDbModel,
	response *pbapi.PersonalWorkTalkMessageResponse) {
	response.Deleted = 1
	workId := response.GetWorkId()
	if workId == const_busi.MutualUserMessageWorkId || workId == const_busi.HomePagePrivateMessageDefaultWorkId {
		return
	}
	workInfo, err := p.impl.DataCache.GetImpl().PersonBottleWorksModel.GetByWorkId(ctx, totalMsg.GetWorkId())
	if err != nil {
		logger.Errorf(ctx, "get work info fail, err: %v, workid: %v", err, totalMsg.GetWorkId())
		return
	}
	if workInfo == nil {
		return
	}
	if workInfo.GetStatus() == 1 { // 作品状态,0:无效；1:有效
		response.Deleted = 0
	}
	response.PushType = workInfo.GetPushType()
	response.Title = workInfo.GetTitle()
	response.Type = workInfo.GetType()
	//
	if len(workInfo.GetEndTime()) > 0 {
		timeVal, err := time.Parse("2006-01-02 15:04:05", workInfo.GetEndTime())
		if err == nil {
			response.EndTime = timeVal.UnixMilli() //是否是毫秒，TODO：
		}
	}
	if workInfo.GetType() != 3 && workInfo.GetId() > 100000 { //// 文件类型 1 图片 2 视频 3 文字
		p.impl.DataCache.GetImpl().WorkObjectAttrModel.DictByWorkIds(ctx, []int64{})
		cond := map[string]interface{}{
			"work_id": workId,
			"status":  1,
		}

		var workObjAttrs []*pbapi.WorkObjectAttr
		itemAttrs, err := p.impl.DataCache.GetImpl().WorkObjectAttrModel.ListItemsByCondition(ctx, cond, 1, cm_const.MaxDbSize)
		if err == nil && len(itemAttrs) > 0 {
			for k, _ := range itemAttrs {
				if itemAttrs[k] == nil {
					continue
				}
				wOAtrr := &pbapi.WorkObjectAttr{
					Id:        itemAttrs[k].GetId(),
					High:      itemAttrs[k].GetHigh(),
					ObjectId:  itemAttrs[k].GetObjectId(),
					Thumbnail: itemAttrs[k].GetThumbnail(),
					Type:      itemAttrs[k].GetType(),
					Width:     itemAttrs[k].GetWidth(),
				}
				workObjAttrs = append(workObjAttrs, wOAtrr)
			}
		}
		response.WorkObject = workObjAttrs
	}
	var enableFlag bool = false
	ret, err := p.impl.DataCache.GetImpl().WorkCommentStatusDbModel.BulkGetStatus(ctx, []int64{workInfo.GetId()})
	if err == nil && ret != nil && len(*ret) > 0 {
		if enable, ok := (*ret)[workInfo.GetId()]; ok {
			if enable == 1 {
				enableFlag = true
			}
		}
	}
	if enableFlag == true {
		response.EnableComment = 1
	} else {
		response.EnableComment = 0
	}
	response.ShowScope = workInfo.GetShowScope()
	//
}

func (p *TalkMessagePackageFill) queryNoAnonymityFromUserInfo(ctx context.Context, totalMsg *pbapi.PersonalTalkMessageTotalMgDbModel,
	response *pbapi.PersonalWorkTalkMessageResponse) {
	if totalMsg.GetPushType() != 2 {
		return
	}
	//
	fromUserInfo, err := p.impl.DataCache.GetUserInfoLocal(ctx, nil, response.GetFromUserId(), false)
	if err != nil || fromUserInfo == nil {
		logger.Errorf(ctx, "get user: %v info fail, err: %v", response.GetFromUserId(), err)
		return
	}
	talkMode := p.impl.DataCache.GetUserInfoTalkMode(ctx, response.GetFromUserId())
	fromUserInfo.PsecretUserExtInfo.TalkMode = &talkMode
	response.FromUserNickName = fromUserInfo.UserInfoDbModel.GetNickName() //TODO: check
	response.FromUserPhoto = fromUserInfo.UserInfoDbModel.GetPhoto()
	//TODO: add province, city
	response.FromUser = trans.TransUserInfoLocalToUserSimple(fromUserInfo)
	remarkName, _ := p.impl.DataCache.GetUserRemarkOne(ctx, totalMsg.GetToUserId(), totalMsg.GetFromUserId())
	response.FromUser.RemarkName = remarkName
}

func (p *TalkMessagePackageFill) PackageSessionInfo(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.SimplePageInfo, error) {
	var talkMsgRet *pbapi.SimplePageInfo = &pbapi.SimplePageInfo{}
	var response []*pbapi.PersonalWorkTalkMessageResponse

	for k, _ := range p.totalMsg {
		if p.totalMsg[k] == nil {
			continue
		}
		if v, ok := p.recordMsg[k]; !ok || v == nil {
			continue
		}
		//...
		item := &pbapi.PersonalWorkTalkMessageResponse{
			FromUserId:  p.totalMsg[k].GetFromUserId(),
			UnReadCount: p.totalMsg[k].GetUnReadCount(),
			SendTime:    p.totalMsg[k].GetLastReceivedTime(),
			WorkId:      p.totalMsg[k].GetWorkId(),
			SessionId:   p.totalMsg[k].Id,
		}
		if p.totalMsg[k].GetFromUserId() == p.curUserInfo.UserInfoDbModel.GetUserId() {
			eqcond := map[string]interface{}{
				"toUserId":   p.curUserInfo.UserInfoDbModel.GetUserId(),
				"fromUserId": p.totalMsg[k].GetToUserId(),
				"status":     1,
			}
			largecond := map[string]interface{}{
				"workId": -1,
			}
			ret, err := p.impl.DataCache.GetImpl().PersonalTalkMessageTotalMgDbModel.GetItemsByConds(ctx, eqcond, largecond, nil, nil, 1)
			if ret != nil && len(ret) > 0 {
				item.SessionId = ret[0].Id
			} else {
				logger.Errorf(ctx, "get item fail, cond: %v, err: %v", eqcond, err)
			}
		}

		if len(p.recordMsg[k].GetContent()) > 0 {
			item.Content = p.recordMsg[k].GetContent()
		} else if p.recordMsg[k].GetMessageType() == 2 {
			item.Content = "[图片]"
		} else if p.recordMsg[k].GetMessageType() == 3 {
			item.Content = "[语音]"
		} else if p.recordMsg[k].GetMessageType() == 99 {
			item.Content = "[自定义表情]"
		}
		//
		item.MessageType = p.recordMsg[k].GetMessageType()
		item.Width = p.recordMsg[k].GetWidth()
		item.High = p.recordMsg[k].GetHigh()
		item.ObjectId = p.recordMsg[k].GetObjectId()
		item.Read = p.recordMsg[k].GetRead()
		item.MessageUserId = p.recordMsg[k].GetFromUserId()
		//
		if p.recordMsg[k].GetFromUserId() == p.curUserInfo.UserInfoDbModel.GetUserId() {
			item.WhetherSend = 1
		}
		item.MemeId = p.recordMsg[k].GetMemeId()
		if p.recordMsg[k].GetFromUserId() <= 0 {
			item.Friend = 0
			item.Black = 0
		}
		blackIn, err := p.impl.DataCache.GetImpl().UserBlackListMgModel.CheckInBlackList(ctx, p.curUserInfo.UserInfoDbModel.GetUserId(),
			p.totalMsg[k].GetFromUserId())
		if err == nil && blackIn {
			item.Black = 1
		}

		blackIn, err = p.impl.DataCache.GetImpl().UserBlackListMgModel.CheckInBlackList(ctx, p.totalMsg[k].GetFromUserId(),
			p.curUserInfo.UserInfoDbModel.GetUserId())
		if err == nil && blackIn {
			item.Black = 2
		}
		p.packageWorkMsgOnMsgPlatform(ctx, p.totalMsg[k], item)
		p.queryNoAnonymityFromUserInfo(ctx, p.totalMsg[k], item)

		if checkNeedProcessMsgType(p.recordMsg[k].GetMessageType()) {
			if isHistoryAppVersion(header.GetVersioncode(), header.GetApptype(), p.recordMsg[k].GetMessageType()) {
				p.HistoryAppVersionFill(ctx, p.totalMsg[k], p.recordMsg[k], item, header)
			} else {
				p.CommonAppVersionFill(ctx, p.totalMsg[k], p.recordMsg[k], item, header.GetAppname())
			}
		}
		response = append(response, item)
	}
	if talkMsgRet == nil {
		talkMsgRet = new(pbapi.SimplePageInfo)
	}
	talkMsgRet.List = response
	return talkMsgRet, nil
}
func (p *TalkMessagePackageFill) HistoryAppVersionFill(ctx context.Context,
	totalMsg *pbapi.PersonalTalkMessageTotalMgDbModel,
	recordMsg *pbapi.PersonalTalkMessageRecordMgDbModel,
	response *pbapi.PersonalWorkTalkMessageResponse,
	header *pbapi.HttpHeaderInfo) error {
	//
	response.MessageType = 1
	response.Content = "ta在动态/评论中@了你，当前版本无法查看"

	return nil
}

func QueryWorkInfoOnTalkMessage(ctx context.Context, workId int64, impl *ContentMng) (*pbapi.WorksForCardMessageResponse, error) {
	workInfo, err := impl.DataCache.GetWorkInfoLocal(ctx, workId, false)
	if err != nil {
		logger.Errorf(ctx, "query workInfo fail, err: %v", err)
		return nil, err
	}
	retWorkInfo := new(pbapi.WorksForCardMessageResponse)
	if workInfo.WorkInfoDbModel.GetStatus() != 0 {
		retWorkInfo.Deleted = true
	}
	//
	retWorkInfo.UserId = workInfo.WorkInfoDbModel.GetUserId()
	retWorkInfo.ClientId = workInfo.WorkInfoDbModel.GetClientId()
	retWorkInfo.Id = workInfo.WorkInfoDbModel.GetId()
	timeVal, err := time.Parse("2006-01-02 15:04:05", workInfo.WorkInfoDbModel.GetCreateTime())
	if err != nil {
		retWorkInfo.CreateTime = timeVal.UnixMilli() //TODO:
	}
	retWorkInfo.Title = workInfo.WorkInfoDbModel.GetTitle()
	retWorkInfo.Type = workInfo.WorkInfoDbModel.GetType()
	retWorkInfo.PushType = workInfo.WorkInfoDbModel.GetPushType()
	retWorkInfo.VisitorCount = workInfo.WorkInfoDbModel.GetVisitorCount()
	retWorkInfo.LikeCount = workInfo.WorkInfoDbModel.GetLikeCount()
	timeVal, err = time.Parse("2006-01-02 15:04:05", workInfo.WorkInfoDbModel.GetStartTime())
	if err == nil {
		retWorkInfo.StartTime = timeVal.UnixMilli() //TODO
	}

	retWorkInfo.Source = workInfo.WorkInfoDbModel.GetSource()
	retWorkInfo.TalkType = workInfo.WorkInfoDbModel.GetWorksType()
	retWorkInfo.BrowseType = workInfo.WorkInfoDbModel.GetBrowseType()
	retWorkInfo.WorksType = workInfo.WorkInfoDbModel.GetWorksType()
	retWorkInfo.Province = workInfo.WorkInfoDbModel.Province
	retWorkInfo.City = workInfo.WorkInfoDbModel.City
	retWorkInfo.Longitude = workInfo.WorkInfoDbModel.GetLongitude()
	retWorkInfo.Latitude = workInfo.WorkInfoDbModel.GetLatitude()
	retWorkInfo.Special = workInfo.WorkInfoDbModel.GetSpecial()
	retWorkInfo.LikeCount = workInfo.WorkInfoDbModel.GetLikeCount()
	timeVal, err = time.Parse("2006-01-02 15:04:05", workInfo.WorkInfoDbModel.GetEndTime())
	if err == nil {
		retWorkInfo.EndTime = timeVal.UnixMilli() //TODO:
	}

	//普通聊天为消息次数，群聊为历史参与人数
	if workInfo.WorkInfoDbModel.GetBrowseType() == 3 {
		retWorkInfo.TalkUserCount = workInfo.WorkInfoDbModel.GetCommentCount() + 1
	} else {
		retWorkInfo.TalkUserCount = workInfo.WorkInfoDbModel.GetCommentCount()
	}

	if workInfo.WorkInfoDbModel.GetWorksType() >= 2 {
		// query table PersonalGroupInfo
	}
	//
	if workInfo.WorkInfoDbModel.GetType() != 3 && workInfo.WorkInfoDbModel.GetId() > 100000 {
		//rdsKey := fmt.Sprintf("%v:cardMessage:workAttrCache:%v", appName, workInfo.GetId())
		eqCond := map[string]interface{}{
			"work_id": workInfo.WorkInfoDbModel.GetId(),
			"status":  1,
		}
		var retWoas []*pbapi.WorkObjectAttr
		woas, err := impl.DataCache.GetImpl().WorkObjectAttrModel.ListItemsByCondition(ctx, eqCond, 1, 10240)
		if err == nil {
			for k, _ := range woas {
				if woas[k] == nil {
					continue
				}
				//....
				retWoa := &pbapi.WorkObjectAttr{
					Id:        woas[k].GetId(),
					Type:      woas[k].GetType(),
					Width:     woas[k].GetWidth(),
					High:      woas[k].GetHigh(),
					ObjectId:  woas[k].GetObjectId(),
					Thumbnail: woas[k].GetThumbnail(),
				}
				retWoas = append(retWoas, retWoa)
			}
		}
		retWorkInfo.WorkObject = retWoas
	}
	workUserInfo, err := impl.DataCache.GetUserInfoLocal(ctx, nil, workInfo.WorkInfoDbModel.GetUserId(), false)
	if err == nil && workUserInfo != nil {
		retWorkInfo.Photo = workUserInfo.UserInfoDbModel.GetPhoto()
		retWorkInfo.NickName = workUserInfo.UserInfoDbModel.GetNickName()
		retWorkInfo.UserInfo = trans.TransUserInfoLocalToUserSimple(workUserInfo)
	}
	//填充tag, 废弃
	//....
	if workInfo.WorkInfoDbModel.GetSpecial() == 3 {
		retWorkInfo.Expands = workInfo.WorksExpandInfo
	}
	retWorkInfo.NewCommentCount = workInfo.WorkInfoDbModel.GetCommentCount()

	eqCond := map[string]interface{}{
		"workId":     workInfo.WorkInfoDbModel.GetId(),
		"remindType": 0,
	}
	// at group
	remindGroup, _ := impl.DataCache.GetImpl().AtDetailMgModel.ListWorkAtGroup(ctx, workId)
	retWorkInfo.RemindGroup = remindGroup
	var remindNodeRet []*pbapi.RemindUserNode // retWorkInfo.RemindNode
	reminds, err := impl.DataCache.GetImpl().UserRemindDetail.GetRemindDetailByConds(ctx, eqCond, nil, nil, nil, 0)
	if err == nil && len(reminds) > 0 {
		for k, _ := range reminds {
			if reminds[k] == nil {
				continue
			}
			//
			remindUserInfo, err := impl.DataCache.GetUserInfoLocal(ctx, nil, reminds[k].GetRemindUserId(), false)
			if err != nil {
				continue
			}
			item := &pbapi.RemindUserNode{}
			if remindUserInfo == nil {
				item.UserId = reminds[k].RemindUserId
				item.OffSet = reminds[k].RemindOffSet
				item.Size = reminds[k].RemindSize
				item.User = &pbapi.UserSimpleResponse{
					UserId:     reminds[k].RemindUserId,
					WrittenOff: proto.Bool(true),
				}
				remindNodeRet = append(remindNodeRet, item)
				continue
			}
			disable := false
			if remindUserInfo.UserInfoDbModel.GetStatus() == 0 {
				disable = true
			}
			item.UserId = reminds[k].RemindUserId
			item.OffSet = reminds[k].RemindOffSet
			item.Size = reminds[k].RemindSize
			item.User = &pbapi.UserSimpleResponse{
				UserId:     reminds[k].RemindUserId,
				NickName:   remindUserInfo.UserInfoDbModel.NickName,
				WrittenOff: proto.Bool(disable),
			}
			remindNodeRet = append(remindNodeRet, item)
		}
	}

	if len(remindNodeRet) > 0 {
		retWorkInfo.RemindNode = remindNodeRet
	}
	return retWorkInfo, nil
}
func (p *TalkMessagePackageFill) QueryWorkInfo(ctx context.Context, workId int64, appName string) (*pbapi.WorksForCardMessageResponse, error) {
	return QueryWorkInfoOnTalkMessage(ctx, workId, p.impl)
}
func GetCommentDetail(ctx context.Context, impl *ContentMng, commentId int64) (*pbmgdb.WorksCommentDetailMgDbModel, error) {
	commentInfo, err := impl.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentById(ctx, commentId)
	if err != nil {
		logger.Errorf(ctx, "get comment Info fail for commentId: %v, err: %v", commentId, err)
		return nil, err
	}
	return commentInfo, nil
}

func PackageReplyCommentMsg(ctx context.Context, impl *ContentMng, commentId int64) (*pbapi.SimpleUserInfo, *pbmgdb.WorksCommentDetailMgDbModel, string, error) {
	content := ""
	replyCommentInfo, err := GetCommentDetail(ctx, impl, commentId)
	if err != nil || replyCommentInfo == nil {
		return nil, nil, content, nil
	}
	commentInfo, err := GetCommentDetail(ctx, impl, replyCommentInfo.GetBeCommentId())

	if commentInfo.GetCommentType() == int32(pbconst.MessageTypeEnum_msg_type_emoji) {
		content = "自定义表情" //TODO:
	} else {
		content = commentInfo.GetComment()
	}
	tmpUserInfo, err := impl.DataCache.GetImpl().GetUserInfoLocal(ctx, nil, replyCommentInfo.GetUserId(), false)
	replyCommentUserInfo := &pbapi.SimpleUserInfo{}
	if err == nil && tmpUserInfo != nil {
		replyCommentUserInfo.UserId = tmpUserInfo.UserInfoDbModel.GetUserId()
		replyCommentUserInfo.NickName = tmpUserInfo.UserInfoDbModel.GetNickName()
	}
	return replyCommentUserInfo, commentInfo, content, nil
}
func (p *TalkMessagePackageFill) CommonAppVersionFill(ctx context.Context,
	totalMsg *pbapi.PersonalTalkMessageTotalMgDbModel,
	recordMsg *pbapi.PersonalTalkMessageRecordMgDbModel,
	response *pbapi.PersonalWorkTalkMessageResponse, appName string) error {

	if recordMsg.MessageWorkId == nil {
		return nil
	}
	switch recordMsg.GetMessageType() {
	case const_busi.MutualNoticeMsgType: // 互爪的动态消息
		workInfo, err := p.QueryWorkInfo(ctx, recordMsg.GetMessageWorkId(), appName)
		if err == nil {
			response.Work = workInfo
		}
	case const_busi.MutualWorkMsgType, const_busi.MutualCommentMsgType: //动态@, //评论@
		eqConds := map[string]interface{}{
			"_id": recordMsg.GetMessageWorkId(),
		}
		remindDetails, err := p.impl.DataCache.GetImpl().UserRemindDetail.GetRemindDetailByConds(ctx, eqConds, nil, nil, nil, 1)
		if err == nil && len(remindDetails) > 0 {
			response.Remind = remindDetails[0]
		}
		if recordMsg.GetMessageType() == const_busi.MutualWorkMsgType && response.Remind != nil { //动态@,
			workInfo, err := p.QueryWorkInfo(ctx, response.Remind.GetWorkId(), appName)
			if err == nil {
				response.Work = workInfo
			}
		}
	case int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply):
		ret, _, content, _ := PackageReplyCommentMsg(ctx, p.impl, recordMsg.GetMessageWorkId()) //回复的评论id， 2 level
		response.ReplyCommentUser = ret
		response.Content = content
	}
	return nil
}
func GetValidTalkMessageTimeStampUnix(ctx context.Context, defaultMillUnix int64) int64 {
	preTimeMill := defaultMillUnix
	if config.ServerConfig.MessageTalkConfig != nil {
		validMinutes := setting.Maozhua.TalkMessageValidMinute.Get()
		if validMinutes > 0 {
			preTimeMill = time.Now().Add(-time.Duration(validMinutes) * time.Minute).UnixMilli()
		}
	}
	return preTimeMill
}
func (p *ContentMng) ListWorkTalks(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.TalkMessageListReq) (*pbapi.SimplePageInfo, error) {
	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil || loginUserInfo == nil || loginUserInfo.UserInfoDbModel.GetUserId() <= 0 {
		logger.Errorf(ctx, "not login in ListWorkTalks")
		return &pbapi.SimplePageInfo{}, errorcode.MIDAS_LOGIN_ERROR
	}
	err = p.checkUserStatus(loginUserInfo)
	if err != nil {
		logger.Errorf(ctx, "check user: %v status fail, err: %v", loginUserInfo.UserInfoDbModel.GetUserId(), err)
		return &pbapi.SimplePageInfo{}, err
	}
	if req.LastTime == nil {
		req.LastTime = proto.Int64(0)
	}
	messageQueryHandle := NewTalkMessageQuery(p, loginUserInfo, req)
	if messageQueryHandle == nil {
		return &pbapi.SimplePageInfo{}, nil
	}
	if err := messageQueryHandle.PrepareLogicForQuery(ctx); err != nil {
		logger.Errorf(ctx, "prepare logic fail, err: %v", err)
		return &pbapi.SimplePageInfo{}, nil
	}
	if err := messageQueryHandle.OfficialMessageTotalQuery(ctx); err != nil {
		logger.Errorf(ctx, "process official user message total fail, userId: %v, err: %v", loginUserInfo.UserInfoDbModel.GetUserId(), err)
		return &pbapi.SimplePageInfo{}, err
	}
	if err := messageQueryHandle.NoOfficialMessageTotalQuery(ctx); err != nil {
		logger.Errorf(ctx, "process no-official user message total fail, userId: %v, err: %v", loginUserInfo.UserInfoDbModel.GetUserId(), err)
		return &pbapi.SimplePageInfo{}, err
	}
	// 用户被注销。fromUserId.

	if err := messageQueryHandle.MessageDetailQuery(ctx, loginUserInfo); err != nil {
		logger.Errorf(ctx, "process message detail query fail, userId: %v, err: %v", loginUserInfo.UserInfoDbModel.GetUserId(), err)
		return &pbapi.SimplePageInfo{}, err
	}

	messageFillHandle := NewTalkMessagePackageFill(messageQueryHandle.GetQueryMessageTotalRet(ctx),
		messageQueryHandle.GetQueryRecordRet(ctx), loginUserInfo, p, messageQueryHandle)
	//
	if messageFillHandle == nil {
		return &pbapi.SimplePageInfo{}, nil
	}
	ret, err := messageFillHandle.PackageSessionInfo(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "package fail, userId: %v", loginUserInfo.UserInfoDbModel.GetUserId())
		return &pbapi.SimplePageInfo{}, err
	}
	if ret == nil {
		return &pbapi.SimplePageInfo{}, nil
	}
	messageFillHandle.CalcPageSize(ctx, ret, req)
	return ret, nil
}

// ////
// official message list
func (p *ContentMng) OfficialNewMsgList(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.PersonalNotificationUnreadTotalResponse, error) {
	var officialMsgHandle IOfficialMsgLogic
	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil || loginUserInfo == nil || loginUserInfo.UserInfoDbModel.GetUserId() <= 0 {
		logger.Errorf(ctx, "not login in ListWorkTalks")
		officialMsgHandle = NewOfficialMsgHandle(p, nil, header)
	} else {
		officialMsgHandle = NewOfficialMsgHandle(p, loginUserInfo, header)
	}
	if officialMsgHandle == nil {
		return nil, nil
	}
	if err := officialMsgHandle.GetLastMsg(ctx); err != nil {
		return nil, err
	}
	if err := officialMsgHandle.GetUnReadMsgNums(ctx); err != nil {
		return nil, err
	}
	return officialMsgHandle.ReturnOfficialMsg(ctx), nil
}

type IOfficialMsgLogic interface {
	GetLastMsg(ctx context.Context) error
	GetUnReadMsgNums(ctx context.Context) error
	ReturnOfficialMsg(ctx context.Context) *pbapi.PersonalNotificationUnreadTotalResponse
}

type officialMsgCommon struct {
	ctxMng *ContentMng
	header *pbapi.HttpHeaderInfo
	//
	appTypeListSys  []int32
	appTypeListSelf []int32
	//
	queryCndOr  []bson.M
	queryCndAnd []bson.M
	showWelcome bool
	//
	last        *pbapi.PersonalUserNotificationResponse
	resultNums  int64
	hasLastItem bool
}

var regExScript string = "<script[^>]*?>[\\s\\S]*?<\\/script>" // 定义script的正则表达式
var regExStyle string = "<style[^>]*?>[\\s\\S]*?<\\/style>"    // 定义style的正则表达式
var regExHtml string = "<[^>]+>"                               // 定义HTML标签的正则表达式
var regExSpace string = "\\s*|\t|\r|\n"                        //定义空格回车换行符

// common data process..
func (o *officialMsgCommon) GetLastMsg(ctx context.Context) error {
	var filter bson.M = bson.M{}
	if len(o.queryCndOr) > 0 {
		filter["$or"] = o.queryCndOr
	}
	if len(o.queryCndAnd) > 0 {
		filter["$and"] = o.queryCndAnd
	}

	sortField := map[string]int32{
		"_id": const_busi.SortTypeDesc,
	}
	data, err := o.ctxMng.DataCache.GetImpl().PersonalUserNotificationMgModel.QueryItemByConds(ctx, filter, sortField)
	if err != nil {
		logger.Errorf(ctx, "err: %v, find item by cond: %v", err, filter)
		return errors.New("not find item")
	}
	//
	if data == nil {
		o.hasLastItem = false
		logger.Infof(ctx, "not find any item by cond: %v", filter)
		//
		o.last = new(pbapi.PersonalUserNotificationResponse)
		welcomeStr := "喵...小猫儿你好，欢迎来到猫爪。\n" +
			"你可以在这里找到一起处关系、解忧小秘密的陌生小哥哥小姐姐聊聊天，还可以一起虾说群聊...\n" +
			"消息24小时后即焚，你可以畅所欲言。\n" +
			"同时请遵守《猫爪公约》，违反公约可能被封号。\n" +
			"祝你在这里聊得开心，喵..."
		o.last.Contents = append(o.last.Contents, &pbapi.PersonalUserNotificationContentResponse{
			Content:  welcomeStr,
			Sort:     1,
			Type:     3,
			TextType: 2,
		})
		o.last.IsNew = 1
		o.last.Html = welcomeStr
		o.last.Type = cm_const.SYSTEM
		o.last.Id = 1
		o.last.Title = "猫爪客服"
		o.last.Timestamp = time.Now().UnixMilli()
		//if userId != nil; timestamp is create_time.
	} else {
		//copy from data to o.last
		o.last = new(pbapi.PersonalUserNotificationResponse)
		o.last.Id = data.GetId()
		o.last.Type = data.GetType()
		o.last.Title = data.GetTitle()
		o.last.Html = data.GetHtml()
		o.last.Url = data.GetUrl()
		o.last.Timestamp = data.GetTimestamp()
		o.last.IsNew = data.GetIsNew()
		o.last.ShowAppeal = data.GetShowAppeal()

		delHTMLTag := func(cnt string) string {
			reg := regexp.MustCompile(strings.Join([]string{"(?i)", regExScript}, ""))
			if reg == nil {
				return cnt
			}
			cnt = reg.ReplaceAllString(cnt, "")
			reg = regexp.MustCompile(strings.Join([]string{"(?i)", regExStyle}, ""))
			if reg == nil {
				return cnt
			}
			cnt = reg.ReplaceAllString(cnt, "")
			//
			reg = regexp.MustCompile(strings.Join([]string{"(?i)", regExHtml}, ""))
			if reg == nil {
				return cnt
			}
			cnt = reg.ReplaceAllString(cnt, "")
			return cnt
		}

		for k, _ := range data.Contents {
			if data.Contents[k] == nil {
				continue
			}
			contentRsp := &pbapi.PersonalUserNotificationContentResponse{}
			contentRsp.Sort = data.Contents[k].GetSort()
			contentRsp.Type = data.Contents[k].GetType()
			contentRsp.Content = data.Contents[k].GetContent()
			contentRsp.Width = data.Contents[k].GetWidth()
			contentRsp.High = data.Contents[k].GetHigh()
			contentRsp.TextType = data.Contents[k].GetTextType()

			if data.Contents[k].TextType == nil || data.Contents[k].GetTextType() != 1 {
				contentRsp.TextType = 2
				o.last.Contents = append(o.last.Contents, contentRsp)
				continue
			}
			contentRsp.TextType = 1
			contentRsp.Content = func(appType string, versionCode string, content string) string {
				var ret string
				if len(appType) <= 0 || len(versionCode) <= 0 {
					ret = delHTMLTag(content)
					return ret
				}
				//////////////////////////////////
				vscode, _ := strconv.Atoi(versionCode)
				if appType == cm_const.AppTypeAppletQq {
					if vscode <= 79 {
						ret = delHTMLTag(content)
					}
				} else if appType == cm_const.AppTypeMobileIos {
					if vscode <= 10051 {
						ret = delHTMLTag(content)
					}
				} else if appType == cm_const.AppTypeMobileAndroid {
					if vscode <= 46 {
						ret = delHTMLTag(content)
					}
				} else {
					ret = delHTMLTag(content)
				}
				return ret
			}(o.header.GetApptype(), o.header.GetVersioncode(), contentRsp.Content)
			o.last.Contents = append(o.last.Contents, contentRsp)

		}
		//
		if o.last.GetIsNew() == 0 {
			o.last.Contents = make([]*pbapi.PersonalUserNotificationContentResponse, 0)
		}
	}
	return nil
}
func (o *officialMsgCommon) ReturnOfficialMsg(ctx context.Context) *pbapi.PersonalNotificationUnreadTotalResponse {
	ret := &pbapi.PersonalNotificationUnreadTotalResponse{
		Total: o.resultNums,
		Last:  o.last,
	}
	return ret
}

func NewOfficialMsgHandle(ctxMng *ContentMng, loginUserInfo *data_cache.UserInfoLocal, header *pbapi.HttpHeaderInfo) IOfficialMsgLogic {
	var ret IOfficialMsgLogic
	common := officialMsgCommon{
		ctxMng:      ctxMng,
		header:      header,
		last:        nil,
		queryCndOr:  nil,
		queryCndAnd: nil,
		showWelcome: true,
		resultNums:  int64(0),
		hasLastItem: true,
	}
	if loginUserInfo == nil {
		ret = &officialMsgOnUnLoginUser{
			officialMsgCommon: common,
		}
	} else {
		ret = &officialMsgOnLoginUser{
			officialMsgCommon: common,
			loginUserInfo:     loginUserInfo,
		}
	}
	return ret
}

// Login user process...
type officialMsgOnLoginUser struct {
	officialMsgCommon
	loginUserInfo *data_cache.UserInfoLocal
}

func (o *officialMsgOnLoginUser) buildQueryCond(ctx context.Context) error {
	reqAppType := o.header.GetApptype()
	if len(reqAppType) <= 0 {
		o.appTypeListSys = append(o.appTypeListSys, 0, cm_const.AppTypeDict[cm_const.AppTypeAppletQq])
	} else {
		o.appTypeListSys = append(o.appTypeListSys, 0, cm_const.AppTypeDict[o.header.GetApptype()])
	}

	if reqAppType == cm_const.AppTypeAppletQq || reqAppType == cm_const.AppTypeAppletWx {
		o.appTypeListSelf = append(o.appTypeListSelf, 0, cm_const.AppTypeDict[cm_const.AppTypeAppletQq], cm_const.AppTypeDict[cm_const.AppTypeAppletWx])
	} else {
		o.appTypeListSelf = append(o.appTypeListSelf, 0, cm_const.AppTypeDict[cm_const.AppTypeMobileAndroid], cm_const.AppTypeDict[cm_const.AppTypeMobileIos])
	}
	//
	userId := o.loginUserInfo.UserInfoDbModel.GetUserId()
	createTime := snow_flake.GetDateTimeBySnowId(userId)
	if createTime <= 0 {
		logger.Errorf(ctx, "get create time  from userId fail, user: %v", userId)
		return errors.New("parse create time by user id")
	}
	o.queryCndOr = append(o.queryCndOr, bson.M{
		"type": cm_const.SYSTEM,
		"appType": bson.M{
			"$in": o.appTypeListSys,
		},
		"start": bson.M{
			"$lte": time.Now().UnixMilli(),
		},
		"end": bson.M{
			"$gte": time.Now().UnixMilli(),
		},
	}, bson.M{
		"userId": userId,
		"appType": bson.M{
			"$in": o.appTypeListSelf,
		},
	})

	o.queryCndAnd = append(o.queryCndAnd, bson.M{
		"timestamp": bson.M{
			"$gte": createTime,
		},
	})
	return nil
}
func (o *officialMsgOnLoginUser) GetLastMsg(ctx context.Context) error {
	//do  other logic
	if err := o.buildQueryCond(ctx); err != nil {
		return err
	}
	err := o.officialMsgCommon.GetLastMsg(ctx)
	if err != nil {
		return err
	}
	if o.hasLastItem == false {
		o.officialMsgCommon.last.Timestamp = snow_flake.GetDateTimeBySnowId(o.loginUserInfo.UserInfoDbModel.GetUserId())
	}
	return nil
}
func (o *officialMsgOnLoginUser) GetUnReadMsgNums(ctx context.Context) error {
	appTypeVal := int32(4)
	if len(o.header.GetApptype()) > 0 {
		appTypeVal = cm_const.AppTypeDict[o.header.GetApptype()]
	}
	condQuery := bson.M{
		"userId":  o.loginUserInfo.UserInfoDbModel.GetUserId(),
		"appType": appTypeVal,
	}
	//
	readCursorRet, err := o.ctxMng.DataCache.GetImpl().NotificationReadCursorMgDbModel.GetItemByCond(ctx, condQuery)
	if err != nil {
		logger.Errorf(ctx, "get read cursor data fail, err: %v", err)
		return nil
	}
	feedBackCriteriaFilter := bson.M{}
	feedBackCriteriaFilter["type"] = cm_const.FEEDBACK
	feedBackCriteriaFilter["userId"] = o.loginUserInfo.UserInfoDbModel.GetUserId()
	if readCursorRet != nil {
		feedBackCriteriaFilter["_id"] = bson.M{"$gt": readCursorRet.GetNotificationId()}
		o.officialMsgCommon.queryCndAnd = append(o.officialMsgCommon.queryCndAnd, bson.M{"_id": bson.M{"$gt": readCursorRet.GetNotificationId()}})
		o.officialMsgCommon.showWelcome = false
	}

	subItemNums, err := o.ctxMng.DataCache.GetImpl().PersonalUserNotificationMgModel.CountByConds(ctx, feedBackCriteriaFilter)
	if err != nil {
		logger.Errorf(ctx, "get subItem nums fail, err: %v", err)
		subItemNums = int64(0)
	}
	//
	totalFilter := bson.M{
		"$or":  o.officialMsgCommon.queryCndOr,
		"$and": o.officialMsgCommon.queryCndAnd,
	}
	totalNums, err := o.ctxMng.DataCache.GetImpl().PersonalUserNotificationMgModel.CountByConds(ctx, totalFilter)
	if err != nil {
		logger.Errorf(ctx, "get total nums fail,err: %v", err)
		return nil
	}
	resultNums := totalNums - subItemNums
	if o.officialMsgCommon.showWelcome {
		resultNums += 1
	}
	o.officialMsgCommon.resultNums = resultNums
	return nil
}

// unlogined user process.
type officialMsgOnUnLoginUser struct {
	officialMsgCommon
}

func (o *officialMsgOnUnLoginUser) buildQueryCond(ctx context.Context) error {
	o.queryCndAnd = append(o.queryCndAnd, bson.M{
		"timestamp": bson.M{
			"gte": time.Now().UnixMilli(),
		},
	})
	return nil
}
func (o *officialMsgOnUnLoginUser) GetLastMsg(ctx context.Context) error {
	//do  other logic
	if err := o.buildQueryCond(ctx); err != nil {
		return err
	}
	return o.officialMsgCommon.GetLastMsg(ctx)
}
func (o *officialMsgOnUnLoginUser) GetUnReadMsgNums(ctx context.Context) error {
	totalFilter := bson.M{
		"$or":  o.officialMsgCommon.queryCndOr,
		"$and": o.officialMsgCommon.queryCndAnd,
	}
	totalNums, err := o.ctxMng.DataCache.GetImpl().PersonalUserNotificationMgModel.CountByConds(ctx, totalFilter)
	if err != nil {
		logger.Errorf(ctx, "get total nums fail,err: %v", err)
		return nil
	}
	resultNums := totalNums
	if o.officialMsgCommon.showWelcome {
		resultNums += 1
	}
	o.officialMsgCommon.resultNums = resultNums
	return nil
}
