package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretActiveUserMgModel interface {
	Get(ctx context.Context, filter any) (*pbmgdb.SecretActiveUserMgDbModel, error)
	Find(ctx context.Context, filter any, options ...*options.FindOptions) ([]*pbmgdb.SecretActiveUserMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.SecretActiveUserMgDbModel, options ...*options.InsertOneOptions) error
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
}

type SecretActiveUser struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretActiveUserMgModelImpl(db *mongo.Database) ISecretActiveUserMgModel {
	return &SecretActiveUser{
		MgDB:  db,
		Table: "secretActiveUser",
	}
}

func (g *SecretActiveUser) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *SecretActiveUser) Get(ctx context.Context, filter any) (*pbmgdb.SecretActiveUserMgDbModel, error) {
	var v *pbmgdb.SecretActiveUserMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretActiveUser:Get failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *SecretActiveUser) Find(ctx context.Context, filter any, options ...*options.FindOptions) ([]*pbmgdb.SecretActiveUserMgDbModel, error) {
	find, err := g.coll().Find(ctx, filter, options...)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretActiveUser:Find failed. cond=%v", filter), err)
		return nil, err
	}

	retItems := make([]*pbmgdb.SecretActiveUserMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.SecretActiveUserMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretActiveUser failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (g *SecretActiveUser) Create(ctx context.Context, data *pbmgdb.SecretActiveUserMgDbModel, options ...*options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data, options...)

	if err != nil {
		logger.Errorf(ctx, "SecretActiveUser:Create : %v", err)
		return err
	}

	return nil
}

func (g *SecretActiveUser) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "SecretActiveUser:updateOne error: %v", err)
		return err
	}

	return nil
}
