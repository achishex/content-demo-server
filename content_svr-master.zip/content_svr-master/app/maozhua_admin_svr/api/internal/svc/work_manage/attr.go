package work_manage

import (
	"content_svr/db/dao"
	mongo "content_svr/db/mongodb/model"
	"context"
)

type WorkCommentAttr struct {
	write, read *dao.ManagerDB
}

func (w *WorkCommentAttr) GetCommentAttr(ctx context.Context, messageType int32, objectId string, userId int64) (*mongo.WorkCommentObjectAttr, error) {
	var attr *mongo.WorkCommentObjectAttr
	switch messageType {
	case mongo.CommentTypeText:
		return attr, nil
	case mongo.CommentTypeImage:
		return attr, nil
	case mongo.CommentTypeVoice:
		return attr, nil
	case mongo.CommentTypeEmote:
		meme, err := w.read.SecretMeme.FindOne(ctx, map[string]interface{}{
			"objectId": objectId,
			"ownerId":  userId,
		})
		if err != nil {
			return nil, err
		}

		attr = &mongo.WorkCommentObjectAttr{
			Width:    meme.Width,
			High:     meme.High,
			ObjectId: meme.ObjectId,
			MemeId:   meme.ID,
		}
	}

	return attr, nil
}
