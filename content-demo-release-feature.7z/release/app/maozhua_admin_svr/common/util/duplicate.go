package util

func DuplicateByInt64(list []int64) []int64 {
	dup := map[int64]struct{}{}
	result := make([]int64, 0)

	for _, v := range list {
		_, exist := dup[v]
		if exist {
			continue
		} else {
			dup[v] = struct{}{}
			result = append(result, v)
		}
	}
	return result
}
