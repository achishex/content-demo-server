package ug

import (
	"content_svr/app/maozhua_admin_svr/common/result"
	"github.com/go-playground/validator/v10"
	"net/http"

	"content_svr/app/maozhua_admin_svr/api/internal/logic/ug"
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"github.com/zeromicro/go-zero/rest/httpx"
)

type verifyAddUgAccountIdReqRequest struct {
	types.AddUgAccountIdReq
}

func (p *verifyAddUgAccountIdReqRequest) Validate() error {
	valid := validator.New()
	if err := valid.Struct(p); err != nil {
		return err
	}
	return nil
}

func AddUgAccountIdHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req verifyAddUgAccountIdReqRequest
		if err := httpx.Parse(r, &req); err != nil {
			result.ParamErrorResult(r, w, err)
			return
		}

		l := ug.NewAddUgAccountIdLogic(r.Context(), svcCtx)
		resp, err := l.AddUgAccountId(&req.AddUgAccountIdReq)
		result.HttpResult(r, w, resp, err)
	}
}
