package model

const collectionNamePersonalUserNotificationMgModel = "personalUserNotification"

type PersonalUserNotificationMgModel struct {
	ID                 int64                                     `json:"id,omitempty" bson:"_id,omitempty"`
	Title              string                                    `json:"title,omitempty" bson:"title,omitempty"`
	Html               string                                    `json:"html,omitempty" bson:"html,omitempty"`
	Url                string                                    `json:"url,omitempty" bson:"url,omitempty"`
	Timestamp          int64                                     `json:"timestamp,omitempty" bson:"timestamp,omitempty"`
	Type               int32                                     `json:"type,omitempty" bson:"type,omitempty"` //类型 1系统公告，2审核消息，3违规处理
	UserId             int64                                     `json:"userId,omitempty" bson:"userId,omitempty"`
	AppType            []int32                                   `json:"appType,omitempty" bson:"appType,omitempty"`
	Start              int64                                     `json:"start,omitempty" bson:"start,omitempty"`
	End                int64                                     `json:"end,omitempty" bson:"end,omitempty"`
	UpdateTime         int64                                     `json:"updateTime,omitempty" bson:"updateTime,omitempty"` //
	Contents           []*PersonalUserNotificationContentMgField `json:"contents,omitempty" bson:"contents,omitempty"`
	IsNew              int32                                     `json:"isNew,omitempty" bson:"isNew,omitempty"`
	ShowAppeal         int32                                     `json:"showAppeal,omitempty" bson:"showAppeal,omitempty"`                 //是否可申诉 1是 0否
	PersonalAttachment *PersonalAttachmentMgField                `json:"personalAttachment,omitempty" bson:"personalAttachment,omitempty"` // 附件

	CreateTime int64 `json:"createTime,omitempty" bson:"createTime,omitempty"`
}

type PersonalUserNotificationContentMgField struct {
	Sort     int32  `json:"sort,omitempty"`
	Type     int32  `json:"type,omitempty"` //1图片 2文字
	Content  string `json:"content,omitempty"`
	Width    int32  `json:"width,omitempty"`
	High     int32  `json:"high,omitempty"`
	TextType int32  `json:"textType,omitempty"`
}

type PersonalAttachmentMgField struct {
	Type       int32    `json:"type,omitempty"` // 1在聊作品 2在聊聊天 3story作品 4story评论 5群聊聊天 6群聊打卡 7自动检测 0无 8时光邮局信件
	WorkId     int64    `json:"workId,omitempty"`
	Content    string   `json:"content,omitempty"`
	UrlsType   int32    `json:"urlsType,omitempty"` // 1图片 2-视频
	Urls       []string `json:"urls,omitempty"`
	FromUserId int64    `json:"fromUserId,omitempty"`
	ToUserId   int64    `json:"toUserId,omitempty"`
	DealStatus int32    `json:"dealStatus,omitempty"`
	Source     int32    `json:"source,omitempty"`   //封禁场景
	ArrestId   int64    `json:"arrestId,omitempty"` //抓捕记录id
}
