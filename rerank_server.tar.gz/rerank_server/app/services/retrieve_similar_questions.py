import pandas as pd
import torch
import time
from typing import List
from pathlib import Path
from app.core.logs import logger
from optimum.onnxruntime import ORTModelForSequenceClassification
from app.models.reranker_protocal import RetrieveSimilarQRequestModel
from app.models.reranker_protocal import RetrieveSimilarQResponseModel
from app.models.reranker_protocal import RetrieveQSimilarQRspItem
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from app.utils.time_op import printTime
import torch.nn.functional as F
import app.services.load_model as load_model
from concurrent.futures import ThreadPoolExecutor

threadNum = 8
languageQAMap = dict()
executor = ThreadPoolExecutor(max_workers=threadNum)

# 根据不同的语言加载不同标准问答数据; 返回问题-答案集合
def reloadFileByLanguage( fileName: str) ->dict:
    qaMap = dict()
    try:
        df = pd.ExcelFile(fileName)
        for sheetName in df.sheet_names:
            sheet_data = pd.read_excel(fileName, sheet_name=sheetName)
            questions = sheet_data[RetrieveSimilarQuestionService.colNameQuestion]
            answers = sheet_data[RetrieveSimilarQuestionService.colNameAwser]

            for q, a in zip(questions, answers):
                qaMap[q] = a
        return qaMap
    except Exception as e:
        logger.error(f"read excel file: {fileName} error: {e}")
        return dict()
    pass

def LoadAllLanguageQuestionAnswers():
    base_dir = Path(__file__).parent.parent
    res_path = base_dir / "resources"
    logger.info(f"res_path: {res_path}")
    file_name_list = [f.name for f in Path(res_path).glob("*.xlsx") if f.is_file()]
    logger.info(f"file name list:{file_name_list} ")

    languageFileMap = dict()
    for fileName in file_name_list:
        if fileName is None:
            continue
        if len(fileName) == 0:
            continue
        firstName = fileName.split("_")[0]
        match firstName:
            case "French":
                languageFileMap["fr"] = (res_path / fileName).resolve()
            case "Italian":
                languageFileMap["it"] = (res_path / fileName).resolve()
            case "Japanese":
                languageFileMap["ja"] = (res_path / fileName).resolve()
            case "German":
                languageFileMap["de"] = (res_path / fileName).resolve()
            case "Spanish":
                languageFileMap["es"] = (res_path / fileName).resolve()
            case "English":
                languageFileMap["en"] =  (res_path / fileName).resolve()
            case _:
                languageFileMap["en"] =  (res_path / fileName).resolve()
    logger.debug(f"language file name map: {languageFileMap}")

    for language, fileName in languageFileMap.items():
        qaMap = reloadFileByLanguage(fileName)
        logger.debug(f"get question, answer content, language: {language}")
        languageQAMap[language] = qaMap

class RetrieveSimilarQuestionService():
    colNameQuestion = 'B'
    colNameAwser = 'H'
      
    def __init__(self): 
        pass
    
    
    def batch_split(self, items: list, batch_size: int) -> list[list]:
        return [items[i:i+batch_size] for i in range(0, len(items), batch_size)]

    def batch_inference(self, query: str, doc_batch: list[str]) -> list[float]:
        prompt = "select most related question for user's question: "
        inputs = [f"{prompt} {query} [SEP] {doc}" for doc in doc_batch]
        encodings = load_model.tokenizer(inputs, padding=True, truncation=True, return_tensors="pt").to(load_model.device)
        with torch.no_grad():
            logits = load_model.model(**encodings).logits.squeeze(-1)
            pass
        scores = F.sigmoid(logits).tolist()
        # return logits.tolist()
        return scores

    def RetrieveSimilarQuestion(self, req: RetrieveSimilarQRequestModel ) ->RetrieveSimilarQResponseModel:
        beginTime = time.time()
        questionAnswerMap = languageQAMap.get(req.language)
        if questionAnswerMap is None:
            logger.error(f"not exist quesion resource for language: {req.language}")
            return None
    
        docs = list(questionAnswerMap.keys())
        batch_size_nums = threadNum
        batches = self.batch_split(docs, batch_size_nums)
        futures = [executor.submit(self.batch_inference, req.query, batch) for batch in batches]
        all_scores = []
        for future in futures:
            all_scores.extend(future.result())
        ranked = sorted(zip(docs, all_scores), key=lambda x: x[1], reverse=True)
        if len(ranked) > req.topK: 
            ranked = ranked[:req.topK]
        
        # logger.info(f"req id: {req.reqId}, language: {req.language}, topK: {req.topK}, similar result: {ranked}")   
        ret : List[RetrieveQSimilarQRspItem] = []
        for question, score in ranked:
            answer = questionAnswerMap.get(question)
            if answer is not None:
                ret.append(RetrieveQSimilarQRspItem(question= question,answer=answer, score=score ))
            else:
                logger.error(f"not exist answer for origin qa map, question: {question}") 
                ret.append(RetrieveQSimilarQRspItem(question= question,score=score ))

        logger.debug(f"req id: {req.reqId}, language: {req.language}, response: {ret}")
        endTime = time.time()
        logger.info(f"reqid:  {req.reqId}, cost millisecond: {(endTime - beginTime) * 1000:.2f}")
        return RetrieveSimilarQResponseModel(similarQAList=ret)