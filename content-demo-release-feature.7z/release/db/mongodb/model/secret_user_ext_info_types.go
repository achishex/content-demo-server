package model

type SecretUserExtInfo struct {
	ID                      int64   `json:"id,omitempty" bson:"_id,omitempty"` // userId
	InviteCode              string  `json:"inviteCode,omitempty" bson:"inviteCode,omitempty"`
	Followed                int32   `json:"followed,omitempty" bson:"followed,omitempty"`   //被关注人数
	ChannelId               int64   `json:"channelId,omitempty" bson:"channelId,omitempty"` //  注册渠道 1自有
	NickName                string  `json:"nickName" bson:"nickName"`
	NickNameVirtual         string  `json:"nickNameVirtual,omitempty" bson:"nickNameVirtual,omitempty"`                 // 虚拟昵称
	PhotoVirtual            string  `json:"photoVirtual,omitempty" bson:"photoVirtual,omitempty"`                       //虚拟头像
	BackgroundImage         string  `json:"backgroundImage,omitempty" bson:"backgroundImage,omitempty"`                 //背景图
	BackgroundImageStatus   int32   `json:"backgroundImageStatus,omitempty" bson:"backgroundImageStatus,omitempty"`     //背景图审核状态 1待审核 11已通过 10一审已拒绝 12一审已忽略 100二审拒绝 101二审通过 102二审忽略
	BackgroundImageShare    int32   `json:"backgroundImageShare,omitempty" bson:"backgroundImageShare,omitempty"`       //背景图分享状态 1已开启 0未开启
	BackgroundImageDownload int32   `json:"backgroundImageDownload,omitempty" bson:"backgroundImageDownload,omitempty"` //背景图下载状态 1已开启 0未开启
	Models                  []int32 `json:"models,omitempty" bson:"models,omitempty"`                                   //可用聊天模式 0聊聊 1唠唠
	CurrentModel            int32   `json:"currentModel,omitempty" bson:"currentModel,omitempty"`                       //聊天模式
	NextChitchatTime        int64   `json:"nextChitchatTime,omitempty" bson:"nextChitchatTime,omitempty"`               //下一次唠唠时间
	Complaint32S            int32   `json:"complaint32s,omitempty" bson:"complaint32s,omitempty"`                       //被投诉次数
	ChitChatCdKey           string  `json:"chitChatCdKey,omitempty" bson:"chitChatCdKey,omitempty"`                     //拥有的激活码数量
	NextCDKeyTime           int64   `json:"nextCDKeyTime,omitempty" bson:"nextCDKeyTime,omitempty"`                     //下次生成激活码的时间
	LastCDKeyUsageTime      int64   `json:"lastCDKeyUsageTime,omitempty" bson:"lastCDKeyUsageTime,omitempty"`           //上次cdkey使用时间
	ChitchatCloseTimes      int64   `json:"chitchatCloseTimes,omitempty" bson:"chitchatCloseTimes,omitempty"`           //唠唠关闭次数
	Ulevel                  int32   `json:"ulevel,omitempty" bson:"ulevel,omitempty"`                                   //用户等级
	Penalties               int32   `json:"penalties,omitempty" bson:"penalties,omitempty"`                             //被处罚次数
	CardId                  string  `json:"cardId,omitempty" bson:"cardId,omitempty"`                                   // 身份证号
	CardName                string  `json:"cardName,omitempty" bson:"cardName,omitempty"`                               // 身份证名字
	NewPenalties            int64   `json:"newPenalties,omitempty" bson:"newPenalties,omitempty"`                       // 新被处罚次数
}
