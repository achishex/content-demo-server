package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type PersonalPoliceInfo struct {
	model.PersonalPoliceInfoModel
	redisManage *query_rds.Manage
}

func NewCachePersonalPoliceInfo(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *PersonalPoliceInfo {
	return &PersonalPoliceInfo{
		PersonalPoliceInfoModel: mongo.PersonalPoliceInfo,
		redisManage:             redisManage,
	}
}
