package errorcode

import (
	"content_svr/pub/errors"
)

func GenBusiErr(busiErr *errors.Error, errMsg string) error {
	return &errors.Error{
		ErrMsg:       "",
		ErrDetail:    nil,
		ErrMsgParams: nil,
		UserMsg:      errMsg,
		UserErrCode:  busiErr.UserErrCode,
		//HttpCode:     0,
		Stack: "",
	}
}

var (
	OK                          = &errors.Error{UserErrCode: 1000, UserMsg: "成功[OK]"}
	UNKNOW_ERROR                = &errors.Error{UserErrCode: 100, UserMsg: "未知错误[UNKNOWN ERROR]"}
	INTERNAL_ERROR              = &errors.Error{UserErrCode: 101, UserMsg: "服务器内部错误"}
	INTERNAL_EXCEPTION          = &errors.Error{UserErrCode: 102, UserMsg: "服务器内部异常"}
	INTERNAL_DB_EXCEPTION       = &errors.Error{UserErrCode: 103, UserMsg: "数据库异常"}
	UNSUPPORTED_OPERATION       = &errors.Error{UserErrCode: 104, UserMsg: "不支持该操作"}
	INSUFFICIENT_PERMISSION     = &errors.Error{UserErrCode: 105, UserMsg: "权限不足"}
	FREQUENT_OPERATION          = &errors.Error{UserErrCode: 106, UserMsg: "操作过于频繁，请稍后再试!"}
	TRIES_LIMIT                 = &errors.Error{UserErrCode: 107, UserMsg: "次数超过限制"}
	READ_JSON_ERROR             = &errors.Error{UserErrCode: 200, UserMsg: "请求的json格式错误"}
	VALIDATE_ERROR              = &errors.Error{UserErrCode: 201, UserMsg: "校验请求参数失败"}
	VALIDATE_SIGN_ERROR         = &errors.Error{UserErrCode: 202, UserMsg: "校验签名失败"}
	VALIDATE_TIMESTAMP_ERROR    = &errors.Error{UserErrCode: 203, UserMsg: "校验时间戳失败，请确认系统时间的准确性"}
	DATA_ERROR                  = &errors.Error{UserErrCode: 204, UserMsg: "数据错误"}
	DATA_NOT_EXISTS             = &errors.Error{UserErrCode: 205, UserMsg: "数据不存在"}
	DATA_EXISTS                 = &errors.Error{UserErrCode: 206, UserMsg: "数据已存在"}
	DATA_INVALID                = &errors.Error{UserErrCode: 207, UserMsg: "数据无效"}
	ALL_GROUP_ERROR             = &errors.Error{UserErrCode: 208, UserMsg: "选择的圈子都不存在"}
	SOME_GROUP_ERROR            = &errors.Error{UserErrCode: 209, UserMsg: "选择的部分圈子不存在"}
	WITHOUT_GROUP_ERROR         = &errors.Error{UserErrCode: 210, UserMsg: "没有圈子"}
	THIRD_NET_ERROR             = &errors.Error{UserErrCode: 211, UserMsg: "请求第三方接口超时或网络出错"}
	THIRD_API_ERROR             = &errors.Error{UserErrCode: 212, UserMsg: "请求第三方接口出错"}
	PARAM_ERROR                 = &errors.Error{UserErrCode: 213, UserMsg: "请求参数错误"}
	REPEAT_PLUS_DAY             = &errors.Error{UserErrCode: 214, UserMsg: "重复操作"}
	VERSION_CODE_IS_NULL        = &errors.Error{UserErrCode: 215, UserMsg: "版本号为空"}
	APP_TYPE_IS_NULL            = &errors.Error{UserErrCode: 216, UserMsg: "客户端类型为空"}
	NOT_SUPPORT_APP_TYPE        = &errors.Error{UserErrCode: 217, UserMsg: "不支持的客户端类型"}
	NOT_AUTH                    = &errors.Error{UserErrCode: 218, UserMsg: "无效操作"}
	LOGIN_INVALID               = &errors.Error{UserErrCode: 219, UserMsg: "登录失效"}
	APP_NAME_IS_NULL            = &errors.Error{UserErrCode: 220, UserMsg: "应用名称为空"}
	NOT_SUPPORT_APP_NAME        = &errors.Error{UserErrCode: 221, UserMsg: "不支持的应用"}
	SENSITIVE_WORD              = &errors.Error{UserErrCode: 222, UserMsg: "请求参数包含非法字符"}
	REPEAT_OPERATION            = &errors.Error{UserErrCode: 223, UserMsg: "频繁操作，请稍后再试"}
	USER_ENABLED_ERROR          = &errors.Error{UserErrCode: 224, UserMsg: "账号状态异常"}
	VERIFY_CODE_INVALID         = &errors.Error{UserErrCode: 230, UserMsg: "验证码无效"}
	ACCOUNT_FROZENED            = &errors.Error{UserErrCode: 301, UserMsg: "账户被冻结"}
	ACCOUNT_CLOSED              = &errors.Error{UserErrCode: 302, UserMsg: "账户已销户"}
	ACCOUNT_STATUS_ERROR        = &errors.Error{UserErrCode: 303, UserMsg: "账户状态不正确"}
	ACCOUNT_DEAL_AMOUNT_ERROR   = &errors.Error{UserErrCode: 304, UserMsg: "账户金额变更失败"}
	ACCOUNT_RECORD_SAVE_ERROR   = &errors.Error{UserErrCode: 305, UserMsg: "账户金额变更记录保存失败"}
	SHARE_FORETELL_LIMIT        = &errors.Error{UserErrCode: 306, UserMsg: "今天分享得星币次数已到上限"}
	SHARE_FORETELL_WORK_LIMIT   = &errors.Error{UserErrCode: 307, UserMsg: "该作品已被分享过"}
	FORETELL_COMMENT_LIMIT      = &errors.Error{UserErrCode: 308, UserMsg: "今天分享得星币次数已到上限"}
	FORETELL_COMMENT_WORK_LIMIT = &errors.Error{UserErrCode: 309, UserMsg: "该作品已被分享过"}
	FORETELL_COMMENT_LIKE_LIMIT = &errors.Error{UserErrCode: 310, UserMsg: "重复点赞"}
	USER_WORKS_LOCK_INTERIM     = &errors.Error{UserErrCode: 601, UserMsg: "临时封禁作品发布权限"}
	USER_WORKS_LOCK_PERMANENT   = &errors.Error{UserErrCode: 602, UserMsg: "永久封禁作品发布权限"}
	UserCommentLockInterim      = &errors.Error{UserErrCode: 603, UserMsg: "临时封禁评论发布权限"}
	UserCommentLockPermanent    = &errors.Error{UserErrCode: 604, UserMsg: "永久封禁评论发布权限"}
	USER_LOCK_INTERIM           = &errors.Error{UserErrCode: 605, UserMsg: "限时封禁账号"}
	USER_LOCK_PERMANENT         = &errors.Error{UserErrCode: 606, UserMsg: "永久封禁账号"}
	BIND_PHONE_REQUIRE          = &errors.Error{UserErrCode: 607, UserMsg: "未绑定手机号"}
	LockFail                    = &errors.Error{UserErrCode: 8000, UserMsg: "获取锁失败"}
	ENCRYPT_ERROR               = &errors.Error{UserErrCode: 1103, UserMsg: "加密出错"}
	DECRYPT_ERROR               = &errors.Error{UserErrCode: 1104, UserMsg: "解密出错"}
	SIGN_ERROR                  = &errors.Error{UserErrCode: 1105, UserMsg: "计算签名出错"}
	SIGN_CHECK_FAIL             = &errors.Error{UserErrCode: 1106, UserMsg: "验证签名失败"}

	WECHAT_CODE_ERROR = &errors.Error{UserErrCode: 42003, UserMsg: "微信授权错误"}
	QQ_CODE_ERROR     = &errors.Error{UserErrCode: 43001, UserMsg: "QQ授权错误"}

	BusinessError          = &errors.Error{UserErrCode: 300, UserMsg: "业务异常"}
	IllegalParamFailed     = &errors.Error{UserErrCode: 3108, UserMsg: "传输参数不正确"}
	PayOrderNotExists      = &errors.Error{UserErrCode: 3302, UserMsg: "支付单不存在"}
	RefundComplete         = &errors.Error{UserErrCode: 3404, UserMsg: "该笔支付已全额退款，不能再发起退款申请"}
	REFUND_AMOUNT_EXCEED   = &errors.Error{UserErrCode: 3412, UserMsg: "申请的退款金额超过了可退款的金额"}
	RefundOrderFailed      = &errors.Error{UserErrCode: 3110, UserMsg: "退款失败"}
	RefundStatusError      = &errors.Error{UserErrCode: 3406, UserMsg: "退款状态异常，不能更新退款状态"}
	RefundStatusUpdateFail = &errors.Error{UserErrCode: 3407, UserMsg: "退款单状态更新失败，请不要同时更新同一退款单"}

	INTERNAL_INTERFACE_ERROR         = &errors.Error{UserErrCode: 400, UserMsg: "内部接口异常"}
	CALL_ACCOUNTING_SERVICE_ERROR    = &errors.Error{UserErrCode: 401, UserMsg: "调用账务服务异常"}
	REFUND_SELLER_BALANCE_NOT_ENOUGH = &errors.Error{UserErrCode: 3413, UserMsg: "收款账号余额不足，请继续收款后再试"}
	Wx_REFUND_CERT_LOAD_FAIL         = &errors.Error{UserErrCode: 4120, UserMsg: "加载微信证书失败，请检查微信证书文件是否上传正确"}
	WX_REFUND_NO_CERT_FILE           = &errors.Error{UserErrCode: 4121, UserMsg: "缺少微信退款证书文件，请上传后重试"}
	WX_REFUND_SUB_MERCHANT_FORBIDDEN = &errors.Error{UserErrCode: 4122, UserMsg: "微信报没有退款权限"}
	WX_REFUND_CERT_NOT_MATCH         = &errors.Error{UserErrCode: 4123, UserMsg: "微信报退款证书文件错误，请重新上传"}
	WX_REFUND_TOO_FREQUENT           = &errors.Error{UserErrCode: 4124, UserMsg: "微信报退款请求过于频繁，请稍后再试"}
	WX_REFUND_SYSTEM_ERROR           = &errors.Error{UserErrCode: 4125, UserMsg: "微信报系统错误，请稍后再试"}
	WX_REFUND_FAIL                   = &errors.Error{UserErrCode: 4107, UserMsg: "微信退款失败"}
	WxpayResponseFailed              = &errors.Error{UserErrCode: 4102, UserMsg: "微信接口报错!"}
	WxpayResponseNullFailed          = &errors.Error{UserErrCode: 4101, UserMsg: "微信支付请求错误,响应为空!"}
	WxpayCommunicationFailed         = &errors.Error{UserErrCode: 4103, UserMsg: "微信接口调用失败"}
	WxappletAppidNull                = &errors.Error{UserErrCode: 4104, UserMsg: "微信小程序APPID为空"}
	WxAppidNull                      = &errors.Error{UserErrCode: 4105, UserMsg: "微信APPID为空"}
	WxPartneridNull                  = &errors.Error{UserErrCode: 4106, UserMsg: "微信商户号为空"}
	WxpayNotifyFailed                = &errors.Error{UserErrCode: 4131, UserMsg: "微信通知出错!"}
	WxPartnerkeyNull                 = &errors.Error{UserErrCode: 4107, UserMsg: "微信商户密钥为空"}

	QQPAY_REFUND_CERT_LOAD_FAIL         = &errors.Error{UserErrCode: 5120, UserMsg: "加载QQ钱包证书失败，请检查QQ钱包证书文件是否上传正确"}
	QQPAY_REFUND_NO_CERT_FILE           = &errors.Error{UserErrCode: 5121, UserMsg: "缺少QQ钱包退款证书文件，请上传后重试"}
	QQPAY_REFUND_SUB_MERCHANT_FORBIDDEN = &errors.Error{UserErrCode: 5122, UserMsg: "QQ钱包报没有退款权限"}
	QQPAY_REFUND_CERT_NOT_MATCH         = &errors.Error{UserErrCode: 5123, UserMsg: "QQ钱包报退款证书文件错误，请重新上传"}
	QQPAY_REFUND_TOO_FREQUENT           = &errors.Error{UserErrCode: 5124, UserMsg: "QQ钱包报退款请求过于频繁，请稍后再试"}
	QQPAY_REFUND_SYSTEM_ERROR           = &errors.Error{UserErrCode: 5125, UserMsg: "QQ钱包报系统错误，请稍后再试"}
	QQPAY_REFUND_FAIL                   = &errors.Error{UserErrCode: 5107, UserMsg: "QQ钱包退款失败"}
	QQPayResponseFailed                 = &errors.Error{UserErrCode: 5102, UserMsg: "QQ钱包接口报错!"}
	QQPayResponseNullFailed             = &errors.Error{UserErrCode: 5101, UserMsg: "QQ钱包支付请求错误,响应为空!"}
	QQPayCommunicationFailed            = &errors.Error{UserErrCode: 5103, UserMsg: "QQ钱包接口调用失败"}
	QQAppletAppidNull                   = &errors.Error{UserErrCode: 5104, UserMsg: "QQ小程序APPID为空"}
	QQAppidNull                         = &errors.Error{UserErrCode: 5105, UserMsg: "QQ公众平台APPID为空"}
	QQPartneridNull                     = &errors.Error{UserErrCode: 5106, UserMsg: "QQ平台商户号为空"}
	QQPayNotifyFailed                   = &errors.Error{UserErrCode: 5131, UserMsg: "QQ钱包通知出错!"}
	QQPartnerkeyNull                    = &errors.Error{UserErrCode: 5107, UserMsg: "QQ平台商户密钥为空"}
	QQAppkeyNull                        = &errors.Error{UserErrCode: 5108, UserMsg: "QQ平台移动应用密钥为空"}

	REALNAME_CHECK_ERROR = &errors.Error{UserErrCode: 5201, UserMsg: "QQ钱包未实名认证!"}

	ALIPAY_SIGN_CHECK_ERROR        = &errors.Error{UserErrCode: 6001, UserMsg: "支付宝签名验证失败"}
	ALIPAY_NOTIFY_DATA_CHECK_ERROR = &errors.Error{UserErrCode: 6002, UserMsg: "支付宝回调数据验证失败"}

	MIDAS_INTERFACE_ERROR        = &errors.Error{UserErrCode: 7001, UserMsg: "米大师接口异常!"}
	MIDAS_BUSY                   = &errors.Error{UserErrCode: 7002, UserMsg: "系统繁忙，请稍候再试!"}
	MIDAS_QQ_SIGN_ERROR          = &errors.Error{UserErrCode: 7003, UserMsg: "qq_sig签名错误!"}
	MIDAS_SIGN_ERROR             = &errors.Error{UserErrCode: 7003, UserMsg: "sig签名错误!"}
	MIDAS_LOGIN_ERROR            = &errors.Error{UserErrCode: 7004, UserMsg: "用户未登录或登录态已过期!"}
	MIDAS_BILL_NO_EXISTS         = &errors.Error{UserErrCode: 7005, UserMsg: "订单已存在!"}
	MIDAS_BALANCE_NOT_ENOUGH     = &errors.Error{UserErrCode: 7006, UserMsg: "余额不足!"}
	MIDAS_INTERFACE_INSUFFICIENT = &errors.Error{UserErrCode: 7007, UserMsg: "没有调用接口的权限!"}
	MIDAS_PARAMS_ERROR           = &errors.Error{UserErrCode: 7008, UserMsg: "参数错误!"}
	MIDAS_ACCESS_TOKEN_ERROR     = &errors.Error{UserErrCode: 7009, UserMsg: "access_token 校验失败，access_token需要放在url中!"}

	IAP_VERIFY_ERROR   = &errors.Error{UserErrCode: 8001, UserMsg: "验证收据出错"}
	IAP_SANDBOX_2_PROD = &errors.Error{UserErrCode: 8002, UserMsg: "receipt是Sandbox receipt，但却发送至生产系统的验证服务"}
	IAP_PROD_2_SANDBOX = &errors.Error{UserErrCode: 8003, UserMsg: "receipt是生产receipt，但却发送至Sandbox环境的验证服务"}
	IAP_INSUFFICIENT   = &errors.Error{UserErrCode: 8004, UserMsg: "无效收据"}

	ICR_VER  = &errors.Error{UserErrCode: 9010, UserMsg: "请下载最新版本注册"}
	ICR_CODE = &errors.Error{UserErrCode: 9011, UserMsg: "邀请码已失效"}

	group_expired                = &errors.Error{UserErrCode: 10001, UserMsg: "群聊已过期"}
	single_talk_limit            = &errors.Error{UserErrCode: 11001, UserMsg: "每日单聊人数已达上限"}
	VERSION_LOW                  = &errors.Error{UserErrCode: 12001, UserMsg: "版本过低，请升级到新版本"}
	cd_key_invalid               = &errors.Error{UserErrCode: 13001, UserMsg: "无效的激活码"}
	cd_key_used                  = &errors.Error{UserErrCode: 13002, UserMsg: "激活码已被使用"}
	cd_key_register_date_invalid = &errors.Error{UserErrCode: 13003, UserMsg: "注册时间不够"}
	cd_key_black_house_invalid   = &errors.Error{UserErrCode: 13004, UserMsg: "近期有违规记录"}
	cd_key_block_invalid         = &errors.Error{UserErrCode: 13005, UserMsg: "近期有封号记录"}

	CommentOpFail            = &errors.Error{UserErrCode: 15000, UserMsg: "操作失败"}
	CommentUnlawfully        = &errors.Error{UserErrCode: 15001, UserMsg: "内容非法"}
	CommentByWorkDeleteFail  = &errors.Error{UserErrCode: 15002, UserMsg: "删除失败"}
	CommentDeleteFail        = &errors.Error{UserErrCode: 15002, UserMsg: "该评论已删除"}
	CommentNumsUsedUpByUser  = &errors.Error{UserErrCode: 15003, UserMsg: "今日评论已达到上限，请明日再来"}
	CommentNumsUsedUpForWork = &errors.Error{UserErrCode: 15004, UserMsg: "这条动态下你已达评论上限\n看看别的动态吧～"}
	CommentDisableForWork    = &errors.Error{UserErrCode: 15005, UserMsg: "关闭了动态评论功能"}
	CommentWorkNotExist      = &errors.Error{UserErrCode: 15006, UserMsg: "删除了动态"}
	Comment_db_op_fail       = &errors.Error{UserErrCode: 15007, UserMsg: "数据库操作失败"}
	CommentIsEmpty           = &errors.Error{UserErrCode: 15008, UserMsg: "评论不存在"}
	CommentUserInBlackHouse  = &errors.Error{UserErrCode: 15009, UserMsg: "小黑屋中，不可评论"}
	CommentLikeFail          = &errors.Error{UserErrCode: 15010, UserMsg: "点赞失败"}
	CommentUnLikeFail        = &errors.Error{UserErrCode: 15011, UserMsg: "取消点赞失败"}

	Sport_three_day_today_no_item = &errors.Error{UserErrCode: 15100, UserMsg: "今日和前三天都没提交步数"}
	Sport_input_step_nums_invalid = &errors.Error{UserErrCode: 15101, UserMsg: "更新步数数据为空"}
	Sport_status_query_fail       = &errors.Error{UserErrCode: 15102, UserMsg: "查询数据失败"}
	Sport_ranker_not_work         = &errors.Error{UserErrCode: 15103, UserMsg: "不允许查询排行榜"}
	Sport_activity_not_begin      = &errors.Error{UserErrCode: 15104, UserMsg: "活动未开始"}
	Sport_push_fail               = &errors.Error{UserErrCode: 15105, UserMsg: "提交步数失败"}
	Sport_step_zero               = &errors.Error{UserErrCode: 15105, UserMsg: "运动步数为零"}
	//
	WorkNotExist    = &errors.Error{UserErrCode: 15200, UserMsg: "该动态已删除"} //动态不存在
	WorkNoInvisible = &errors.Error{UserErrCode: 15201, UserMsg: "该动态已删除"} //动态不存在
	//
	CommentNotExist    = &errors.Error{UserErrCode: 15202, UserMsg: "该评论已删除"}
	CommentNoInvisible = &errors.Error{UserErrCode: 15203, UserMsg: "该评论已删除"}
	//他人主页私聊检查错误码
	HomePagePrivateMsgDisable       = &errors.Error{UserErrCode: 15300, UserMsg: "开通VIP, 即可发私信"}
	HomePagePrivateMsgUsedUp        = &errors.Error{UserErrCode: 15301, UserMsg: "今日私聊已达到上限请明日再来"}
	HomePagePrivateMsgInBlack       = &errors.Error{UserErrCode: 15302, UserMsg: "已被对方拉黑"}
	HomePagePrivateMsgInBlackActive = &errors.Error{UserErrCode: 15303, UserMsg: "把对方拉黑"}
	HomePagePrivateMsgSwallow       = &errors.Error{UserErrCode: 15304, UserMsg: "吞噬内容"}
	HomePagePrivateMsgSelf          = &errors.Error{UserErrCode: 15305, UserMsg: "不能拉黑自己哦～"}
	TalkModeError                   = &errors.Error{UserErrCode: 15306, UserMsg: `暂不支持未成年人切换至“扩列模式”`}
	TalkModeLevelError              = &errors.Error{UserErrCode: 15306, UserMsg: `请升级到 4 级才可启用扩列模式`}
	TalkModeCloseForbiddenError     = &errors.Error{UserErrCode: 15307, UserMsg: "Ta已关闭接收陌生人私信"}
	TalkModeCloseError              = &errors.Error{UserErrCode: 15308, UserMsg: "互关猫友可在好友列表中正常发送哦！"}
	RemarkNameError                 = &errors.Error{UserErrCode: 15309, UserMsg: "互关猫友才可以设置备注哦！"}
	RemarkNameSelfError             = &errors.Error{UserErrCode: 15309, UserMsg: "不允许给自己备注"}
	TalkNoReplyError                = &errors.Error{UserErrCode: 15310, UserMsg: "请耐心等待Ta的回复～"}

	TalkADNoReplyError     = &errors.Error{UserErrCode: 15311, UserMsg: "请耐心等待Ta的回复～"}
	TalkADSendSessError    = &errors.Error{UserErrCode: 15312, UserMsg: "请耐心等待Ta的回复～"}
	TalkMessageLengthError = &errors.Error{UserErrCode: 15310, UserMsg: "字数过长，无法发送"}

	FollowMsgInTargetBlack = &errors.Error{UserErrCode: 15305, UserMsg: "因对方设置，无法关注"}
	FollowMsgInMyBlack     = &errors.Error{UserErrCode: 15306, UserMsg: "ta已在你的黑名单中，无法关注!"}
	FollowMyselfCanNot     = &errors.Error{UserErrCode: 15307, UserMsg: "暂不支持关注自己哦～"}

	// 关于用户级别权限错误
	UserLevelNotEnough = &errors.Error{UserErrCode: 15400, UserMsg: "升级至「Lv.5 大师猫」\n\n即可在评论区发送表情"}

	// 腾讯云验证身份证服务
	TencentSdkError = &errors.Error{UserErrCode: 16000, UserMsg: "身份证验证服务忙，请稍后再试"}
	ExistCardError  = &errors.Error{UserErrCode: 16100, UserMsg: "很抱歉，您提交的身份信息已绑定其他账号，\n\n未通过认证，请重新提交"}
	CardError       = &errors.Error{UserErrCode: 16101, UserMsg: "很抱歉，您提交的身份信息不一致，\n\n未通过认证，请重新提交"}
	//微信用户绑定
	UserBindWechatExists      = &errors.Error{UserErrCode: 16200, UserMsg: "用户已绑定微信账号"}
	UserBindWechatError       = &errors.Error{UserErrCode: 16201, UserMsg: "用户绑定微信账号失败"}
	UserBindWechatExistsError = &errors.Error{UserErrCode: 16202, UserMsg: "微信账号已被绑定"}

	//优质内容接口
	SuperiorContentDetailError = &errors.Error{UserErrCode: 17000, UserMsg: "获取优质内容详情失败"}

	//
	ACLFORBID    = &errors.Error{UserErrCode: 21000, UserMsg: "该地区App无法提供服务"}
	PleaseUseApp = &errors.Error{UserErrCode: 21001, UserMsg: "请使用猫爪app体验~"} //小程序男性不允许发帖

	UserRemindStarTarget           = &errors.Error{UserErrCode: 22000, UserMsg: "互关猫友才可以设置星标哦！"}
	UserRemindStarTargetNewVersion = &errors.Error{UserErrCode: 22001, UserMsg: "请安装最新猫爪app设置您的星标好友～"}
	UserRemindStarTargetMax        = &errors.Error{UserErrCode: 22002, UserMsg: "已达星标猫友上限，无法再设置"}

	SecretKeyError      = &errors.Error{UserErrCode: 30000, UserMsg: "SecretKey错误"}
	AuthSignError       = &errors.Error{UserErrCode: 30001, UserMsg: "授权签名错误"}
	APISignError        = &errors.Error{UserErrCode: 30002, UserMsg: "API签名错误"}
	PaymentNotSupport   = &errors.Error{UserErrCode: 30100, UserMsg: "支付方式不支持"}
	PreCreateOrderError = &errors.Error{UserErrCode: 30101, UserMsg: "预下单失败"}
	GetPreOrderError    = &errors.Error{UserErrCode: 30102, UserMsg: "获取订单失败"}
	GameExists          = &errors.Error{UserErrCode: 30200, UserMsg: "游戏已绑定"}
	GameBindError       = &errors.Error{UserErrCode: 30201, UserMsg: "游戏绑定失败"}

	//体现错误码：
	PhoneCodeVerifyError      = &errors.Error{UserErrCode: 22000, UserMsg: "手机验证码验证失败"}
	KoLaTransferMoneyError    = &errors.Error{UserErrCode: 22001, UserMsg: "提交失败，请重试"}
	KoLaTransferMoneyFail     = &errors.Error{UserErrCode: 22002, UserMsg: "提现失败"}
	KoLaTransferMoneying      = &errors.Error{UserErrCode: 22003, UserMsg: "提现中"}
	KoLaTransferTimesTooMany  = &errors.Error{UserErrCode: 22004, UserMsg: "次数已达上限，明天再来吧～"}
	KoLaTransferNumsOverLimit = &errors.Error{UserErrCode: 22005, UserMsg: "单月总提现不可超过800元～"}
	KoLaTransferMinWithdraw   = &errors.Error{UserErrCode: 22006, UserMsg: "低于最小取现金额%v元"}
	KoLaHallOfFameFail        = &errors.Error{UserErrCode: 22007, UserMsg: "获取可乐名人堂失败"}

	//表情包
	MemeNotFound    = &errors.Error{UserErrCode: 23000, UserMsg: "表情包不存在"}
	MemeReportError = &errors.Error{UserErrCode: 23001, UserMsg: "举报失败"}

	//每日签到 & 等级提升
	DailyVersionLow                  = &errors.Error{UserErrCode: 24001, UserMsg: "请去应用商店更新最新版本App"}
	DailySignInAgain                 = &errors.Error{UserErrCode: 24002, UserMsg: "今日已签到"}
	DailySignInError                 = &errors.Error{UserErrCode: 24003, UserMsg: "签到失败"}
	SpeedCodeGetErrorCauseBlackHouse = &errors.Error{UserErrCode: 24004, UserMsg: "小黑屋中无法领取激活码"}
	SpeedCodeGetErrorCauseNo         = &errors.Error{UserErrCode: 24005, UserMsg: "未满足领取条件"}
	SpeedCodeInvalid                 = &errors.Error{UserErrCode: 24006, UserMsg: "加速码无效"}
	SpeedCodeUsageError              = &errors.Error{UserErrCode: 24007, UserMsg: "加速失败"}

	//OPEN IM
	IMServerError                  = &errors.Error{UserErrCode: 25000, UserMsg: "OPEN_IM服务请求错误"}
	IMGetUserTokenError            = &errors.Error{UserErrCode: 25001, UserMsg: "获取IM_TOKEN失败"}
	IMRegisterUserError            = &errors.Error{UserErrCode: 25002, UserMsg: "IM注册失败"}
	GroupCreateLevelNotEnough      = &errors.Error{UserErrCode: 25100, UserMsg: "升级为「Lv.%d 大师猫」\n\n才可创建群聊"}
	GroupGetMyCreateCountError     = &errors.Error{UserErrCode: 25101, UserMsg: "获取我的群聊数量失败"}
	GroupCreateUpperLimitError     = &errors.Error{UserErrCode: 25102, UserMsg: "群聊创建数量已达上限，无法创建"}
	GroupNameError                 = &errors.Error{UserErrCode: 25103, UserMsg: "群名称非法，请重新输入"}
	GroupIntroduceError            = &errors.Error{UserErrCode: 25104, UserMsg: "群简介非法，请重新输入"}
	GroupFaceImgError              = &errors.Error{UserErrCode: 25105, UserMsg: "群头像非法，请重新上传"}
	GroupBackGroupImgError         = &errors.Error{UserErrCode: 25106, UserMsg: "群聊背景非法，请重新上传"}
	GroupHomepageBackGroupImgError = &errors.Error{UserErrCode: 25107, UserMsg: "群聊主页背景非法，请重新上传"}
	GroupCreateLatestUserNumsError = &errors.Error{UserErrCode: 25108, UserMsg: "至少选择两位好友"}
	GroupCreateError               = &errors.Error{UserErrCode: 25109, UserMsg: "创建群失败"}
	GroupSetError                  = &errors.Error{UserErrCode: 25110, UserMsg: "设置群信息失败"}
	GroupInviteError               = &errors.Error{UserErrCode: 25111, UserMsg: "邀请进群失败"}
	GroupJoinError                 = &errors.Error{UserErrCode: 25112, UserMsg: "申请进群失败"}
	GroupKickError                 = &errors.Error{UserErrCode: 25113, UserMsg: "踢出群失败"}
	GroupNotFoundError             = &errors.Error{UserErrCode: 25114, UserMsg: "群组不存在"}
	GroupStatusDismissed           = &errors.Error{UserErrCode: 25115, UserMsg: "该群聊已解散"}
	GroupStatusFull                = &errors.Error{UserErrCode: 25116, UserMsg: "群组已满员"}
	GroupPermissionDenied          = &errors.Error{UserErrCode: 25117, UserMsg: "权限不足"}
	GroupReportError               = &errors.Error{UserErrCode: 25118, UserMsg: "群举报失败"}
	GroupReportRepeatError         = &errors.Error{UserErrCode: 25119, UserMsg: "举报成功"}
	GroupDismissError              = &errors.Error{UserErrCode: 25120, UserMsg: "解散群失败"}
	GroupQuitError                 = &errors.Error{UserErrCode: 25121, UserMsg: "退出群失败"}
	GroupTransferError             = &errors.Error{UserErrCode: 25122, UserMsg: "转让群失败"}
	GroupSetMemberInfoError        = &errors.Error{UserErrCode: 25123, UserMsg: "设置群成员信息失败"}

	//用户
	UserHomepageBackGroupImgError        = &errors.Error{UserErrCode: 26000, UserMsg: "内容违规，无法保存"}
	UserHomepageBackGroupLevelLimitError = &errors.Error{UserErrCode: 26001, UserMsg: "升级为「Lv.5 大师猫」\n即可编辑主页背景哦"}
)
