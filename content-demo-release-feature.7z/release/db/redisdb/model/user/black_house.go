package user

import (
	"content_svr/db/redisdb/model/internal"
	"content_svr/pub/logger"
	"context"
	"strconv"
)

type userBlackHouse struct {
	internal.RdsInfo
}

func (r *userBlackHouse) getRdsKey() string {
	return r.RdsKey
}

func (r *userBlackHouse) GetUserInBlackHouse(ctx context.Context, userId int64) (int64, error) {
	redisKey := r.getRdsKey()
	outTimeMs, err := r.Client.HGet(ctx, redisKey, strconv.Itoa(int(userId))).Int64()
	if err != nil {
		return 0, err
	}

	return outTimeMs, err
}

func (r *userBlackHouse) SetUserBlackHouse(ctx context.Context, userId int64, expire int64) error {
	redisKey := r.getRdsKey()

	err := r.Client.HSet(ctx, redisKey, userId, expire).Err()
	logger.Infof(ctx, "quding, key=%v, id=%v, expire=%v, err=%v",
		redisKey, userId, expire, err)

	return err
}

func (r *userBlackHouse) RemoveUserFromBlackHouse(ctx context.Context, userId int64) error {
	redisKey := r.getRdsKey()
	logger.Infof(ctx, "quding_from_from_blackhouse, key=%v, user_id=%v",
		redisKey, userId)
	return r.Client.HDel(ctx, redisKey, strconv.Itoa(int(userId))).Err()
}
