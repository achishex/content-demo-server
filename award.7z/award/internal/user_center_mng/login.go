package user_center_mng

import (
	"content_svr/config"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"context"
	"encoding/json"
	"fmt"
	"github.com/go-redis/redis/v8"
	"github.com/samber/lo"
	"io"
	"net/http"
	"sort"
	"strings"
	"time"
)

var QuickLoginAppConf = map[string]string{ //appKey, appSecret
	"1400920109": "beb43b7c5f022444416b23225c2a28b1", // TODO 配置化
}

func (u *UserCenterMng) QuickLogin(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbuserapi.QuickLoginReq) (resp *pbuserapi.QuickLoginResp, err error) {
	// 流程
	// 1. 查手机
	// 2. 检查用户是否注册
	// 3.
	//    3.1 如果用户已注册，快速登录
	//    3.2 如果用户未注册，生成注册code，跳转注册页面

	aresp, err := u.TencentLoginComp.AuthCall(ctx, req)
	if err != nil {
		return nil, err
	}

	if aresp.Result != 0 {
		logger.Errorf(ctx, "req tencent auth err, code: %v, msg: %v", aresp.Result, aresp.Errmsg)
		return nil, fmt.Errorf("%v", aresp.Errmsg)
	}

	if aresp.Mobile == "" {
		logger.Errorf(ctx, "req tencent auth err, empty phone")
		return nil, fmt.Errorf("empty phone")
	}

	userInfoList, err := u.findUserInfoList(ctx, aresp.Mobile)
	if err != nil {
		logger.Errorf(ctx, "findUserInfoList fail, phone: %v err: %v", aresp.Mobile, err)
		return nil, err
	}

	if len(userInfoList) > 0 {
		userInfo := u.getDefaultUserInfo(userInfoList)
		logger.Infof(ctx, "quick login, userinfo: %+v", userInfo)
		token, err := u.login(ctx, header, userInfo)
		if err != nil {
			logger.Errorf(ctx, "login fail, phone: %v , err: %v", aresp.Mobile, err)
			return nil, err
		}

		// 插入登录记录
		m := &pbmgdb.SecretUserLoginInfoMgDbModel{
			Id:         snow_flake.GetSnowflakeID(),
			UserId:     userInfo.GetUserId(),
			NickName:   userInfo.GetNickName(),
			AppVersion: header.GetVersioncode(),
			AppType:    header.GetApptype(),
			LoginTime:  time.Now().UnixMilli(),
			Source:     req.GetSource(),
			Token:      token,
		}
		if err2 := u.DataCache.GetImpl().SecretUserLoginInfoMgModel.Insert(ctx, m); err2 != nil {
			logger.Warnf(ctx, "Insert SecretUserLoginInfoMgModel fail, err: %v", err2)
		}

		return &pbuserapi.QuickLoginResp{
			Token:    token,
			UserId:   userInfo.GetUserId(),
			Nickname: userInfo.GetNickName(),
			Photo:    userInfo.GetPhoto(),
			UserInfo: userInfo2Simple(userInfo),
		}, nil
	} else {
		// 生成注册码，跳java系统注册登录
		// TODO 迁移或重构用户体系
		code, err := u.genRegisterCode(ctx, aresp.Mobile)
		if err != nil {
			return nil, err
		}
		return &pbuserapi.QuickLoginResp{Phone: aresp.Mobile, RegisterVerifyCode: code}, nil
	}
}

func (u *UserCenterMng) removeOldToken(ctx context.Context, userID int64) error {
	rdb := u.DataCache.GetImpl().RedisCli
	oldToken, err := rdb.Get(ctx, u.getLoginIDRedisKey(userID)).Result()
	if err != nil {
		if errors.Is(err, redis.Nil) {
			return nil
		}
		return err
	}
	if oldToken != "" {
		err = rdb.Del(ctx, u.getLoginTokenRedisKey(oldToken)).Err()
	}
	return err
}
func (u *UserCenterMng) getLoginIDRedisKey(userID int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:login_id:%v", config.ServerConfig.Env, userID)
}

func (u *UserCenterMng) getLoginTokenRedisKey(token string) string {
	return fmt.Sprintf("platform:%v:soul_soup:login_token:%v", config.ServerConfig.Env, token)
}

func (u *UserCenterMng) login(ctx context.Context, header *pbapi.HttpHeaderInfo, userInfo *pbapi.UserinfoDbModel) (string, error) {
	// 封禁 1:启用，2:限时封禁，3:永久封禁
	if userInfo.GetEnabled() != 1 {
		return "", &errors.Error{UserErrCode: 224, UserMsg: "帐号违规，已封禁"}
	}

	err := u.removeOldToken(ctx, userInfo.GetUserId())
	if err != nil {
		return "", err
	}

	token := u.genLoginToken()
	li := &LoginInfo{
		AppType:   header.Apptype,
		AppName:   "soul_soup",
		Version:   header.Versioncode,
		LoginTime: time.Now().Format("2006年01月02日 PM15:04"),
		UserId:    userInfo.GetUserId(),
	}

	exp := time.Hour * 24 * 30
	rdb := u.DataCache.GetImpl().RedisCli
	_, err = rdb.Pipelined(ctx, func(p redis.Pipeliner) error {
		p.Set(ctx, u.getLoginTokenRedisKey(token), utils.JsonStr(li), exp)
		p.Set(ctx, u.getLoginIDRedisKey(userInfo.GetUserId()), token, exp)
		return nil
	})
	if err != nil {
		rdb.Del(ctx, u.getLoginTokenRedisKey(token))
		rdb.Del(ctx, u.getLoginIDRedisKey(userInfo.GetUserId()))
		return "", err
	}
	return token, nil
}

func (u *UserCenterMng) genLoginToken() string {
	// TODO jwt
	return utils.MD5(fmt.Sprintf("%v%v", time.Now().UnixMilli(), utils.DefaultRand.Int63()))
}

func (u *UserCenterMng) getDefaultUserInfo(userInfoList []pbapi.UserinfoDbModel) *pbapi.UserinfoDbModel {
	if len(userInfoList) == 0 {
		return nil
	}

	sort.Slice(userInfoList, func(i, j int) bool {
		return userInfoList[i].GetUserId() > userInfoList[j].GetUserId()
	})

	for _, ui := range userInfoList {
		if ui.GetType() == 1 { // 默认用户
			return lo.ToPtr(ui)
		}
	}

	return lo.ToPtr(userInfoList[0])
}

func (u *UserCenterMng) findUserInfoList(ctx context.Context, phone string) ([]pbapi.UserinfoDbModel, error) {
	l1, err := u.DataCache.GetImpl().UserInfoModel.ListByPhone(ctx, phone)
	if err != nil {
		return nil, err
	}

	// 脱敏账号
	encPhone, _ := utils.AESEncrypt([]byte(phone), utils.AesUserKey)
	l2, err := u.DataCache.GetImpl().UserInfoModel.ListByPhone(ctx, encPhone)
	if err != nil {
		return nil, err
	}

	var res []pbapi.UserinfoDbModel
	res = append(res, l1...)
	res = append(res, l2...)
	return res, nil
}

func NewTencentLoginComp(appKeyMap map[string]string) *TencentLoginComp {
	return &TencentLoginComp{appKeyMap: appKeyMap}
}

type TencentLoginComp struct {
	appKeyMap map[string]string
}

func (c *TencentLoginComp) AuthCall(ctx context.Context, in *pbuserapi.QuickLoginReq) (*TencentAuthResp, error) {
	appKey := c.appKeyMap[in.Sdkappid]
	if appKey == "" {
		return nil, fmt.Errorf("invalid appid: %v", in.Sdkappid)
	}

	random := lo.RandomString(10, lo.NumbersCharset)
	ts := time.Now().Unix()
	signContent := fmt.Sprintf("appkey=%s&random=%v&time=%v", appKey, random, ts)
	sig := utils.Sha256String(signContent)

	body := utils.JsonStr(map[string]any{
		"sig":     sig,
		"time":    ts,
		"carrier": in.Carrier,
		"token":   in.LoginToken,
	})
	uurl := fmt.Sprintf("https://yun.tim.qq.com/v5/rapidauth/validate?sdkappid=%v&random=%v", in.Sdkappid, random)

	hreq, err := http.NewRequestWithContext(ctx, http.MethodPost, uurl, strings.NewReader(body))
	if err != nil {
		return nil, err
	}

	hresp, err := utils.DefaultHTTPClient.Do(hreq)
	if err != nil {
		return nil, err
	}

	if hresp.StatusCode != http.StatusOK {
		logger.Errorf(ctx, "http req fail, url: %v, statusCode: %v", uurl, hresp.StatusCode)
		return nil, fmt.Errorf("http req fail")
	}

	res := &TencentAuthResp{}
	if hresp.Body != nil {
		bs, err2 := io.ReadAll(hresp.Body)
		if err2 != nil {
			return nil, fmt.Errorf("read body fail, err: %v", err)
		}
		_ = json.Unmarshal(bs, res)
	}

	return res, nil
}

type TencentAuthResp struct {
	Mobile string `json:"mobile"`
	Errmsg string `json:"errmsg"`
	Result int    `json:"result"`
}

// LoginInfo
// json 格式保持兼容
// "{\"appType\":\"mobile-android\",\"appName\":\"soul_soup\",\"version\":\"2130001\",\"loginTime\":\"2023\xe5\xb9\xb411\xe6\x9c\x881\xe6\x97\xa5 PM5:41\",\"userId\":4517913451005952}"
type LoginInfo struct {
	//应用类型 mobile-ios,mobile-android,applet-wx,applet-qq
	AppType string `json:"appType"`
	//应用名称 AppNameEnum
	AppName string `json:"appName"`
	//本次登陆的客户端版本号
	Version string `json:"version"`
	//登陆时间
	LoginTime string `json:"loginTime"`
	//用户主键
	UserId int64 `json:"userId"`
}

func userInfo2Simple(userInfo *pbapi.UserinfoDbModel) *pbapi.SimpleUserInfo {
	return &pbapi.SimpleUserInfo{
		UserId:   userInfo.GetUserId(),
		NickName: userInfo.GetNickName(), // 这里要用opennickname
		Photo:    userInfo.GetPhoto(),
		Gender:   userInfo.GetGender(),
		Birth:    userInfo.GetBirth(),
		Age:      utils.CalculateAge(userInfo.GetBirth()),
		SignId:   utils.CalculateConstellation(userInfo.GetBirth()),
		City:     userInfo.GetCity(),
		Province: userInfo.GetProvince(),
		//IsConvoy:    userInfo.IsPolice,
		//ShowConvoy:  userInfo.ShowConvoy,
		//MemberType:  userInfo.MemberType,
		WorksLock:   userInfo.GetWorksLock(),
		Enabled:     userInfo.GetEnabled(),
		CommentLock: userInfo.GetCommentLock(),
		//Openid:                  "",
		//ChitChatCdKey:           userInfo.PsecretUserExtInfo.GetChitChatCdKey(),
		//BackgroundImage:         userInfo.PsecretUserExtInfo.GetBackgroundImage(),
		//BackgroundImageShare:    userInfo.PsecretUserExtInfo.GetBackgroundImageShare(),
		//BackgroundImageDownload: userInfo.PsecretUserExtInfo.GetBackgroundImageDownload(),
		//Medals:                  userInfo.UserMedals,
		UserType: userInfo.GetUserType(),
		//ULevel:                  userInfo.PsecretUserExtInfo.GetUlevel(),
		//Tags:                    tags,
		//ChitChatCKeyUpCase: userInfo.PsecretUserExtInfo.GetChitChatCdKey(),
		//TalkMode:           talkMode,
		//RemarkName:         remarkName,
		//StarTarget:         starTarget,
		Description: userInfo.GetDescription(),
		//ModifyIdentity:     modifyIdentity,
		//ModifyBirth:        modifyIdentity,
		//ModifyGender:       modifyGender,
		//Phone:              phone,
		//HomepageBackground: userInfo.PsecretUserExtInfo.GetHomepageBackground(),
	}
}
