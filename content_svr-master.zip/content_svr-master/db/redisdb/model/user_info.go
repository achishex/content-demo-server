package model

import (
	"content_svr/db/redisdb/model/user"
	"github.com/go-redis/redis/v8"
)

type UserInfoRedis struct {
	*user.UserInfoRedis
}

func NewUserInfoRedis(rds *redis.Client, env string) *UserInfoRedis {
	return &UserInfoRedis{
		UserInfoRedis: user.NewUserInfoRedis(rds, env),
	}
}
