#!/bin/bash

### 定时期发帖
debuguserids=(4094329043423232)
title="fjx发帖测试%d"
pushType=2
talkType=1
type=1
browseType=1
special=2
url="http://175.178.206.221:19998/platform/secret/chitchat/works"


qry_times=0
while true
do
    for debuguserid in "${debuguserids[@]}"
    do
        createTime=$(date +%s%3)
        echo $createTime
        qry_times=$((qry_times+1))
        echo $qry_times
        suffix=$((qry_times%10))
        echo $suffix
        data="{\"createTime\":$createTime,\"pushType\":$pushType,\"talkType\":$talkType,\"title\":\"${title//\%d/$suffix}\",\"type\":$type,\"browseType\":$browseType,\"special\":$special}"
        curl -X POST \
             -H "Content-Type: application/json" \
             -H "apptype: mobile-ios" \
             -H "appname: soul_soup" \
             -H "versioncode: 1070000" \
             -H "debuguserid: $debuguserid" \
             -H "platform: ios" \
             -d "$data" \
             "$url"
    done
    sleep 10
done