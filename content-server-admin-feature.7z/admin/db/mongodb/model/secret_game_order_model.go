package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var _ SecretGameOrderModel = (*customSecretGameOrderModel)(nil)

type (
	// SecretGameOrderModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretGameOrderModel.
	SecretGameOrderModel interface {
		secretGameOrderModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretGameOrder, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretGameOrder, error)
	}

	customSecretGameOrderModel struct {
		*defaultSecretGameOrderModel
	}
)

// NewSecretGameOrderModel returns a model for the mongo.
func NewSecretGameOrderModel(cfg MonConfig, opts ...mon.Option) SecretGameOrderModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), collectionNameSecretGameOrder, opts...)
	return &customSecretGameOrderModel{
		defaultSecretGameOrderModel: newDefaultSecretGameOrderModel(conn),
	}
}

func (m *customSecretGameOrderModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	} else {
		flagType = "default"
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customSecretGameOrderModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretGameOrderModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretGameOrder, error) {
	result := make([]SecretGameOrder, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretGameOrderModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretGameOrder, error) {
	var data SecretGameOrder
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
