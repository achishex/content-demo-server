package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

// PersonalUserNotificationMgModel
//  PersonalUserNotificationMgModel

type IPersonalUserNotificationMgModel interface {
	Insert(ctx context.Context, item *pbmgdb.PersonalUserNotificationMgModel) error

	//
	SendNotify(ctx context.Context, toUserId *int64, html string) error
	//
	QueryItemByConds(ctx context.Context, filter bson.M, sortFields map[string]int32) (*pbmgdb.PersonalUserNotificationMgModel, error)
	CountByConds(ctx context.Context, filter bson.M) (int64, error)
}

type PersonalUserNotificationMgDbImpl struct {
	MgDB *mongo.Database
}

func NewPersonalUserNotificationMgModelImpl(db *mongo.Database) IPersonalUserNotificationMgModel {
	return &PersonalUserNotificationMgDbImpl{MgDB: db}
}

func (impl *PersonalUserNotificationMgDbImpl) table() string {
	return "personalUserNotification"
}
func (impl *PersonalUserNotificationMgDbImpl) CountByConds(ctx context.Context, filter bson.M) (int64, error) {
	if len(filter) <= 0 {
		return 0, nil
	}
	collection := impl.MgDB.Collection(impl.table())
	count, err := collection.CountDocuments(ctx, filter)
	if err != nil {
		logger.Errorf(ctx, "get counts fail, err: %v", err)
		return 0, err
	}
	return count, nil
}
func (impl *PersonalUserNotificationMgDbImpl) QueryItemByConds(ctx context.Context, filter bson.M, sortFields map[string]int32) (*pbmgdb.PersonalUserNotificationMgModel, error) {
	collection := impl.MgDB.Collection(impl.table())

	var sortExpand bson.D
	for k, v := range sortFields {
		sortExpand = append(sortExpand, bson.E{Key: k, Value: v})
	}
	opts := options.Find()
	if len(sortFields) > 0 {
		opts.SetSort(sortExpand)
	}
	cursor, err := collection.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "find fail, %v", err)
		return nil, err
	}
	// 遍历查询结果
	var result []*pbmgdb.PersonalUserNotificationMgModel
	for cursor.Next(ctx) {
		item := &pbmgdb.PersonalUserNotificationMgModel{}
		// 解码绑定数据
		err = cursor.Decode(item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to userRemindDetail failed.err=%v", err), err)
			return nil, err
		}
		result = append(result, item)
	}
	if len(result) > 0 {
		return result[0], nil
	}
	return nil, nil
}

func (impl *PersonalUserNotificationMgDbImpl) Insert(ctx context.Context, item *pbmgdb.PersonalUserNotificationMgModel) error {
	collection := impl.MgDB.Collection(impl.table())
	_, err := collection.InsertOne(ctx, item)
	//print(result, err)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PersonalUserNotificationMgDbImpl.Insert  failed. item=%v",
			item), err)
	}
	return err
}

// 发通知。
func (impl *PersonalUserNotificationMgDbImpl) SendNotify(ctx context.Context,
	toUserId *int64, html string) error {
	logger.Infof(ctx, "sendNotify, touserId=%v, html=%v", toUserId, html)
	item := &pbmgdb.PersonalUserNotificationMgModel{
		Id:        snow_flake.GetSnowflakeID(),
		UserId:    toUserId,
		Timestamp: proto.Int64(time.Now().UnixNano() / 1e6),
		Type:      proto.Int32(2), // TODO 枚举  PersonalUserNotificationType
		Title:     proto.String("猫爪客服"),
		//Url:       proto.String(fmt.Sprintf("%v", *workId)),
		AppType:  []int32{0},
		Html:     proto.String(html),
		Contents: impl.buildContents(html),
		IsNew:    proto.Int32(1),
		//Start:      nil,
		//End:        nil,
		//UpdateTime: nil,
		//ShowAppeal:         nil,
		//PersonalAttachment: nil,
	}

	collection := impl.MgDB.Collection(impl.table())
	_, err := collection.InsertOne(ctx, item)
	//print(result, err)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PersonalUserNotificationMgDbImpl.Insert  failed. item=%v",
			item), err)
	}
	return err
}

func (impl *PersonalUserNotificationMgDbImpl) buildContents(html string) []*pbmgdb.PersonalUserNotificationContentMgField {
	resp := make([]*pbmgdb.PersonalUserNotificationContentMgField, 0)
	item := &pbmgdb.PersonalUserNotificationContentMgField{
		Sort:    proto.Int32(1),
		Type:    proto.Int32(3),
		Content: proto.String(html),
		//Width:    nil,
		//High:     nil,
		//TextType: nil,
	}
	resp = append(resp, item)
	return resp
}
