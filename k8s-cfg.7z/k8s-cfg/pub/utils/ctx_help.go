package utils

import (
	"content_svr/protobuf/pbapi"
	"github.com/gin-gonic/gin"
	"net/url"
	"strconv"
	"strings"
)

func GetCtxHeadersSession(c *gin.Context) (*pbapi.HttpHeaderInfo, error) {
	resp := &pbapi.HttpHeaderInfo{}
	resp.Apptype = GetCtxHeadersStrVal(c, "Apptype")
	resp.Appname = GetCtxHeadersStrVal(c, "Appname")
	resp.Token = GetCtxHeadersStrVal(c, "Token")
	resp.Versioncode = GetCtxHeadersStrVal(c, "Versioncode")
	resp.Uk = GetCtxHeadersStrVal(c, "Uk")
	resp.Ip = GetCtxHeadersStrVal(c, "X-Forwarded-For")
	resp.Platform = GetCtxHeadersStrVal(c, "Platform")
	resp.Channel = GetCtxHeadersStrVal(c, "Channel")
	resp.Imei = GetCtxHeadersStrVal(c, "Imei")
	resp.Oaid = GetCtxHeadersStrVal(c, "Oaid")

	resp.Longitude = GetCtxHeadersFloat64(c, "Longitude")
	resp.Latitude = GetCtxHeadersFloat64(c, "Latitude")
	if resp.Longitude == 0 && resp.Latitude == 0 {
		coordinate := GetCtxHeadersStrVal(c, "Coordinate")
		arr := strings.Split(coordinate, ",")
		if len(arr) > 1 { // 兼容小程序和App老版本
			resp.Longitude = GetCtxHeadersFloat64(c, arr[0])
			resp.Latitude = GetCtxHeadersFloat64(c, arr[1])
		}
	}

	resp.Country = GetCtxHeadersStrVal(c, "Country")
	resp.Province = GetCtxHeadersStrVal(c, "Province")
	resp.City = GetCtxHeadersStrVal(c, "City")
	resp.Region = GetCtxHeadersStrVal(c, "Region")

	strUserId := GetCtxHeadersStrVal(c, "Debuguserid")
	userId, _ := strconv.Atoi(strUserId)
	resp.Debuguserid = int64(userId)
	return resp, nil
}

func GetCtxHeadersStrVal(c *gin.Context, key string) string {
	values, exist := c.Request.Header[key]
	if !exist {
		return ""
	}

	rest, err := url.QueryUnescape(values[0])
	if err != nil {
		return ""
	}

	return rest
}

func GetCtxHeadersInt(c *gin.Context, key string) int32 {
	val := GetCtxHeadersStrVal(c, key)
	valInt, err := strconv.Atoi(val)
	if err != nil {
		return 0
	}
	return int32(valInt)
}

func GetCtxHeadersFloat64(c *gin.Context, key string) float64 {
	val := GetCtxHeadersStrVal(c, key)
	valFloat64, err := strconv.ParseFloat(val, 64)
	if err != nil {
		return 0
	}
	return valFloat64
}
