package cache

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	rdsModel "content_svr/db/redisdb/model"
	"content_svr/db/redisdb/query_rds"
	"content_svr/pub/utils"
	"context"
	"github.com/samber/lo"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

type UserRewardMoneyActivity struct {
	model.UserRewardMoneyActivityModel
	Lock        rdsModel.UserRewardMoneyActivityRedisNx
	redisManage *query_rds.Manage
}

func NewCacheUserRewardMoneyActivity(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *UserRewardMoneyActivity {
	return &UserRewardMoneyActivity{
		UserRewardMoneyActivityModel: mongo.UserRewardMoneyActivity,
		Lock:                         redisManage.UserRewardMoneyActivity.UserRewardMoneyActivityRedisNx,
		redisManage:                  redisManage,
	}
}

// UpdateTaskProgress 更新任务进度
func (p *UserRewardMoneyActivity) UpdateTaskProgress(ctx context.Context, userID int64, taskType int32, scope, total uint64) error {
	now := time.Now()
	day := utils.ZeroTime(now)
	complete := scope >= total
	rewardCount := uint64(0)
	if complete {
		rewardCount = 1
	}
	var moneyPlanData = &model.UserRewardMoneyActivity{
		UserId:      userID,
		Day:         day.UnixMilli(),
		Type:        taskType,
		Complete:    complete,
		Scope:       scope,
		RewardCount: rewardCount,
		//CreateTime: 0,
		UpdateTime: now.UnixMilli(),
	}

	filter := map[string]interface{}{
		"user_id": userID,
		"day":     day.UnixMilli(),
		"type":    moneyPlanData.Type,
	}

	moneyPlan, err := p.UserRewardMoneyActivityModel.FindOne(ctx, filter)
	switch err {
	case xerr.DbNotFound:
		moneyPlanData.CreateTime = moneyPlanData.UpdateTime
		if _, err = p.Insert(ctx, moneyPlanData); err != nil {
			return err
		}
	case nil:
		moneyPlanData.ID = moneyPlan.ID
		moneyPlanData.RewardCount = lo.Max([]uint64{moneyPlan.RewardCount, moneyPlanData.RewardCount})
		moneyPlanData.Scope = lo.Max([]uint64{moneyPlan.Scope, moneyPlanData.Scope})
		moneyPlanData.Complete = moneyPlan.Complete || moneyPlanData.Complete
		if _, err = p.UpdateOne(ctx, moneyPlanData); err != nil {
			return err
		}
	default:
		return err
	}

	return nil
}

// FinishTask 提交任务 taskType 对应钱包中的类型，scope值为该任务数值
func (p *UserRewardMoneyActivity) FinishTask(ctx context.Context, userId int64, taskType int32, scopeOpt ...uint64) error {
	var scope uint64
	if len(scopeOpt) != 0 {
		scope = scopeOpt[0]
	}

	now := time.Now()
	day := utils.ZeroTime(now)
	var moneyPlanData = &model.UserRewardMoneyActivity{
		UserId:      userId,
		Day:         day.UnixMilli(),
		Type:        taskType,
		Complete:    true,
		Scope:       scope,
		RewardCount: 1,
		//CreateTime: 0,
		UpdateTime: now.UnixMilli(),
	}

	filter := map[string]interface{}{
		"user_id": userId,
		"day":     day.UnixMilli(),
		"type":    moneyPlanData.Type,
	}

	moneyPlan, err := p.FindOne(ctx, filter)
	switch err {
	case xerr.DbNotFound:
		moneyPlanData.CreateTime = moneyPlanData.UpdateTime
		if _, err = p.Insert(ctx, moneyPlanData); err != nil {
			return err
		}
	case nil:
		moneyPlanData.ID = moneyPlan.ID
		moneyPlanData.RewardCount += moneyPlan.RewardCount
		moneyPlanData.Scope += moneyPlan.Scope
		if _, err = p.UpdateOne(ctx, moneyPlanData); err != nil {
			return err
		}
	default:
		return err
	}

	return nil
}

func (p *UserRewardMoneyActivity) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*model.UserRewardMoneyActivity, error) {
	day := filter["day"]
	if day == nil {
		day = 0
	}
	userId := filter["user_id"]
	taskType := filter["type"]

	award, err := p.redisManage.UserRewardMoneyActivity.Get(ctx, day, userId, taskType)
	if err != nil {
		award, err = p.UserRewardMoneyActivityModel.FindOne(ctx, filter, opts...)
		if err != nil {
			return nil, err
		}

		if err := p.redisManage.UserRewardMoneyActivity.Set(ctx, day, userId, taskType, *award); err != nil {
			return nil, err
		}
		return award, nil

	}

	return award, err
}

func (p *UserRewardMoneyActivity) Insert(ctx context.Context, data *model.UserRewardMoneyActivity) (*mongo.InsertOneResult, error) {
	result, err := p.UserRewardMoneyActivityModel.Insert(ctx, data)
	if err != nil {
		return nil, err
	}
	if err := p.redisManage.UserRewardMoneyActivity.Set(ctx, data.Day, data.UserId, data.Type, *data); err != nil {
		return nil, err
	}

	return result, err
}

func (p *UserRewardMoneyActivity) UpdateOne(ctx context.Context, data *model.UserRewardMoneyActivity) (*mongo.UpdateResult, error) {
	result, err := p.UserRewardMoneyActivityModel.UpdateOne(ctx, data)
	if err != nil {
		return nil, err
	}
	if err := p.redisManage.UserRewardMoneyActivity.Set(ctx, data.Day, data.UserId, data.Type, *data); err != nil {
		return nil, err
	}

	return result, err
}

func (p *UserRewardMoneyActivity) Upsert(ctx context.Context, data *model.UserRewardMoneyActivity, opts ...*options.UpdateOptions) (err error) {
	if data.ID.IsZero() {
		_, err = p.Insert(ctx, data)
	} else {
		_, err = p.UpdateOne(ctx, data)
	}

	return err
}
