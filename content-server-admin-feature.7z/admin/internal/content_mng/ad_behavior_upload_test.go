package content_mng

import (
	"content_svr/internal/ad_mng"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"os"
	"testing"
)

var imeis = []string{
	"866019069342056",
	"861040057226494",
	"860140053951235",
	"866301069942337",
	"869420067298299",
	"860073065558575",
	"861417055093235",
	"869297044702431",
	"861012053636059",
	"860539056348234",
	"862332049258274",
	"869946061275438",
	"862332049258274",
	"869946061275438",
	"862590043455515",
	"866301063372812",
	"865288061881475",
	"863856059059098",
	"865288061881475",
	"864935050209313",
	"860769059181973",
	"860826060434831",
	"866368066411913",
	"860346069970412",
	"866368066411913",
	"864473044468159",
	"868902035995636",
	"860539050479332",
	"866265069331314",
}

func TestMain(m *testing.M) {
	logger.DebugLogger("dev")
	os.Exit(m.Run())
}

func TestContentMng_AdOppoFeedback(t *testing.T) {

	for _, imei := range imeis {

		b := ad_mng.BehaviorUpCtrl{}
		fmt.Println(b.Oppo(context.Background(), nil, &pbapi.AdBehaviorUploadReqV2{
			Imei: imei,
			Type: 3,
		}))
	}

}
