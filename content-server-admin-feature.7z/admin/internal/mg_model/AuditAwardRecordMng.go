package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type IAuditAwardRecordMgModel interface {
	Create(ctx context.Context, data *pbmgdb.AuditAwardRecordMng, opts ...*options.InsertOneOptions) error
	FindOne(ctx context.Context, filter bson.D, opts ...*options.FindOneOptions) (*pbmgdb.AuditAwardRecordMng, error)
	FindAll(ctx context.Context, filter bson.D, opts ...*options.FindOptions) ([]*pbmgdb.AuditAwardRecordMng, error)
	Count(ctx context.Context, filter bson.D, opts ...*options.CountOptions) (int64, error)
	UpdateMap(ctx context.Context, filter, update map[string]interface{}) (*mongo.UpdateResult, error)
}

type AuditAwardRecordMgModelImpl struct {
	MgDB       *mongo.Database
	Collection *mongo.Collection
}

func NewAuditAwardRecordMgModelImpl(db *mongo.Database) IAuditAwardRecordMgModel {
	record := &AuditAwardRecordMgModelImpl{MgDB: db}
	record.Collection = record.MgDB.Collection(record.tableName())
	return record
}

func (impl *AuditAwardRecordMgModelImpl) tableName() string {
	return "audit_award_record"
}

func (impl *AuditAwardRecordMgModelImpl) Create(ctx context.Context, data *pbmgdb.AuditAwardRecordMng, opts ...*options.InsertOneOptions) error {
	result, err := impl.Collection.InsertOne(ctx, data, opts...)
	if err != nil {
		return err
	}

	id, ok := result.InsertedID.(string)
	if !ok {
		return nil
	}
	data.Id = id
	return nil
}

func (impl *AuditAwardRecordMgModelImpl) Update() {}
func (impl *AuditAwardRecordMgModelImpl) Delete() {}

func (impl *AuditAwardRecordMgModelImpl) Count(ctx context.Context, filter bson.D, opts ...*options.CountOptions) (int64, error) {
	return impl.Collection.CountDocuments(ctx, filter, opts...)
}
func (impl *AuditAwardRecordMgModelImpl) FindOne(ctx context.Context, filter bson.D, opts ...*options.FindOneOptions) (*pbmgdb.AuditAwardRecordMng, error) {
	result := &pbmgdb.AuditAwardRecordMng{}
	err := impl.Collection.FindOne(ctx, filter, opts...).Decode(result)
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (impl *AuditAwardRecordMgModelImpl) FindAll(ctx context.Context, filter bson.D, opts ...*options.FindOptions) ([]*pbmgdb.AuditAwardRecordMng, error) {
	cur, err := impl.Collection.Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	result := make([]*pbmgdb.AuditAwardRecordMng, 0)
	for cur.Next(ctx) {
		item := &pbmgdb.AuditAwardRecordMng{}
		if err := cur.Decode(item); err != nil {
			return nil, err
		}
		result = append(result, item)
	}

	return result, err
}

func (impl *AuditAwardRecordMgModelImpl) UpdateMap(ctx context.Context, filter, update map[string]interface{}) (*mongo.UpdateResult, error) {
	conds := bson.D{}
	for key, value := range filter {
		conds = append(conds, bson.E{Key: key, Value: value})
	}

	data := bson.D{}
	for key, value := range update {
		data = append(data, bson.E{Key: key, Value: value})
	}
	updater := bson.D{
		{Key: "$set", Value: data},
	}

	return impl.Collection.UpdateMany(ctx, conds, updater)
}
