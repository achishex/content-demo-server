package model

import (
	"content_svr/protobuf/pbapi"
	"context"
	"gorm.io/gorm"
)

type IAdVivoFeedbackDbModelDbModel interface {
	Create(ctx context.Context, data []*pbapi.AdVivoFeedbackDbModel) error
}

type AdVivoFeedbackDbModelDbModelImpl struct {
	DB *gorm.DB
}

func NewAdVivoFeedbackDbModelDbModelImpl(db *gorm.DB) IAdVivoFeedbackDbModelDbModel {
	return &AdVivoFeedbackDbModelDbModelImpl{DB: db}
}

func (impl *AdVivoFeedbackDbModelDbModelImpl) TableName() string {
	return "ad_vivo_feedback"
}

func (impl *AdVivoFeedbackDbModelDbModelImpl) Create(ctx context.Context, data []*pbapi.AdVivoFeedbackDbModel) error {
	if err := impl.DB.WithContext(ctx).Table(impl.TableName()).Create(data).Error; err != nil {
		return err
	}

	return nil
}
