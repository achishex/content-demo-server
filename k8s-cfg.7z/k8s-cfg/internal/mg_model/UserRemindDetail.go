package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type IUserRemindDetailMgDbModel interface {
	Insert(ctx context.Context, item *pbmgdb.UserRemindDetailMgDbModel) error
	GetRemindDetailByConds(ctx context.Context, eqConds, largeConds, lessConds map[string]interface{}, sortField map[string]int32, limits int32) ([]*pbmgdb.UserRemindDetailMgDbModel, error)
}
type UserRemindDetailMgDbModel struct {
	MgDB *mongo.Database
}

func (impl *UserRemindDetailMgDbModel) collection() string {
	return "userRemindDetail"
}
func NewUserRemindDetailMgModelImpl(db *mongo.Database) IUserRemindDetailMgDbModel {
	return &UserRemindDetailMgDbModel{MgDB: db}
}

func (p *UserRemindDetailMgDbModel) Insert(ctx context.Context, item *pbmgdb.UserRemindDetailMgDbModel) error {
	_, err := p.MgDB.Collection(p.collection()).InsertOne(ctx, item)
	return err
}
func (p *UserRemindDetailMgDbModel) GetRemindDetailByConds(ctx context.Context, eqConds, largeConds,
	lessConds map[string]interface{}, sortField map[string]int32, limits int32) ([]*pbmgdb.UserRemindDetailMgDbModel, error) {
	//
	coll := p.MgDB.Collection(p.collection())
	filter := bson.D{}

	for k, v := range eqConds {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	for k, v := range largeConds {
		filter = append(filter, bson.E{k, bson.D{{"$gt", v}}})
	}
	for k, v := range lessConds {
		filter = append(filter, bson.E{k, bson.D{{"$lt", v}}})
	}
	var sortExpand bson.D
	for k, v := range sortField {
		sortExpand = append(sortExpand, bson.E{Key: k, Value: v})
	}
	//
	opts := options.Find()
	if len(sortExpand) > 0 {
		opts.SetSort(sortExpand)
	}
	if limits > 0 {
		opts.SetLimit(int64(limits))
	}
	cursor, err := coll.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "find fail, %v", err)
		return nil, err
	}
	// 遍历查询结果
	var result []*pbmgdb.UserRemindDetailMgDbModel
	for cursor.Next(ctx) {
		item := &pbmgdb.UserRemindDetailMgDbModel{}
		// 解码绑定数据
		err = cursor.Decode(item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to userRemindDetail failed.err=%v", err), err)
			return nil, err
		}
		result = append(result, item)
	}
	return result, nil
}
