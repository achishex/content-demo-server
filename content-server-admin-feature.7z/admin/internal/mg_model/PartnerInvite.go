package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"errors"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type IPartnerInviteMgModel interface {
	FindOne(ctx context.Context, filter any) (*pbmgdb.PartnerInviteMgDbModel, error)
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.PartnerInviteMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.PartnerInviteMgDbModel, options ...*options.InsertOneOptions) error
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
	CountByCondition(ctx context.Context, filter any, opts ...*options.CountOptions) int64
}

type PartnerInviteMgModel struct {
	MgDB  *mongo.Database
	Table string
}

func NewPartnerInviteMgModel(db *mongo.Database) IPartnerInviteMgModel {
	return &PartnerInviteMgModel{
		MgDB:  db,
		Table: "partner_invite",
	}
}

func (g *PartnerInviteMgModel) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *PartnerInviteMgModel) FindOne(ctx context.Context, filter any) (*pbmgdb.PartnerInviteMgDbModel, error) {
	var v *pbmgdb.PartnerInviteMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if errors.Is(err, mongo.ErrNoDocuments) {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PartnerInvite FindOne failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *PartnerInviteMgModel) Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.PartnerInviteMgDbModel, error) {
	find, err := g.coll().Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	retItems := make([]*pbmgdb.PartnerInviteMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.PartnerInviteMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to Partner failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (g *PartnerInviteMgModel) Create(ctx context.Context, data *pbmgdb.PartnerInviteMgDbModel, options ...*options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data, options...)

	if err != nil {
		logger.Errorf(ctx, "PartnerInvite:Create error : %v", err)
		return err
	}

	return nil
}

func (g *PartnerInviteMgModel) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "PartnerInvite:updateOne error: %v", err)
		return err
	}

	return nil
}

func (g *PartnerInviteMgModel) CountByCondition(ctx context.Context, filter any, opts ...*options.CountOptions) int64 {
	c, err := g.coll().CountDocuments(ctx, filter, opts...)
	if err != nil {
		return 0
	}

	return c
}
