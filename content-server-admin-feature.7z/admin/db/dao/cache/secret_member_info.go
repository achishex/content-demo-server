package cache

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
	"content_svr/pub/logger"
	"context"
	"go.mongodb.org/mongo-driver/mongo"
)

type SecretMemberInfo struct {
	model.SecretMemberInfoModel
	redisManage *query_rds.Manage
}

func NewCacheSecretMemberInfo(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *SecretMemberInfo {
	return &SecretMemberInfo{
		SecretMemberInfoModel: mongo.SecretMemberInfo,
		redisManage:           redisManage,
	}
}

func (p *SecretMemberInfo) Insert(ctx context.Context, data *model.SecretMemberInfo) (*mongo.InsertOneResult, error) {
	result, err := p.SecretMemberInfoModel.Insert(ctx, data)
	switch {
	case err == xerr.DbNotFound:
		return result, err
	case err == nil:
		_ = p.redisManage.UserInfo.SetUserMember(ctx, data.UserId, data.Type, data.Expire)
		return result, err
	default:
		return result, err
	}
}

func (p *SecretMemberInfo) Update(ctx context.Context, data *model.SecretMemberInfo) error {
	result, err := p.SecretMemberInfoModel.UpdateOne(ctx, data)
	switch {
	case err == xerr.DbNotFound:
		return xerr.DbNotFound
	case err == nil:
		if result.ModifiedCount == 0 {
			return xerr.DbDoNothing
		}
		_ = p.redisManage.UserInfo.SetUserMember(ctx, data.UserId, data.Type, data.Expire)
		return nil
	default:
		return err
	}
}

func (p *SecretMemberInfo) UpdateRedis(ctx context.Context, data *model.SecretMemberInfo) {
	memberType := p.redisManage.UserInfo.GetUserMember(ctx, data.UserId)
	if memberType == 0 && data.Enable {
		logger.Infof(context.Background(), "quding2 %v", data)
		p.redisManage.UserInfo.SetUserMember(ctx, data.UserId, data.Type, data.Expire)
	}
}
