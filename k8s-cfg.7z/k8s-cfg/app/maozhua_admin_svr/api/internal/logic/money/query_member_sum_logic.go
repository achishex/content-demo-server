package money

import (
	"context"
	"go.mongodb.org/mongo-driver/bson"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type QueryMemberSumLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewQueryMemberSumLogic(ctx context.Context, svcCtx *svc.ServiceContext) *QueryMemberSumLogic {
	return &QueryMemberSumLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *QueryMemberSumLogic) QueryMemberSum(req *types.MemberSumReq) (resp *types.MemberSumResp, err error) {

	filter := map[string]interface{}{
		"day": bson.D{
			{"$gte", req.TimeStart},
			{"$lte", req.TimeEnd},
		},
	}

	items, err := l.svcCtx.ManagerOnlyReadDB.UserMemberStatistical.FindAll(l.ctx, filter)
	if err != nil {
		return nil, err
	}

	resp = &types.MemberSumResp{List: items}

	return
}
