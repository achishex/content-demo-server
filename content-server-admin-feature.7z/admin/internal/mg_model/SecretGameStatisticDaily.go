package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"context"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretGameStatisticDailyMgModel interface {
	Create(ctx context.Context, data *pbmgdb.SecretGameStatisticDaily, opts ...*options.InsertOneOptions) error
	FindOne(ctx context.Context, filter any, opts ...*options.FindOneOptions) (*pbmgdb.SecretGameStatisticDaily, error)
	FindAll(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretGameStatisticDaily, error)
	Count(ctx context.Context, filter any, opts ...*options.CountOptions) (int64, error)
	Update(ctx context.Context, filter, update any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error)
	Aggregate(ctx context.Context, pipeline any, opts ...*options.AggregateOptions) (*mongo.Cursor, error)
}

type SecretGameStatisticDailyMgModelImpl struct {
	MgDB       *mongo.Database
	Collection *mongo.Collection
}

func NewSecretGameStatisticDailyMgModelImpl(db *mongo.Database) ISecretGameStatisticDailyMgModel {
	record := &SecretGameStatisticDailyMgModelImpl{MgDB: db}
	record.Collection = record.MgDB.Collection(record.tableName())
	return record
}

func (impl *SecretGameStatisticDailyMgModelImpl) tableName() string {
	return "SecretGameStatisticDaily"
}

func (impl *SecretGameStatisticDailyMgModelImpl) Create(ctx context.Context, data *pbmgdb.SecretGameStatisticDaily, opts ...*options.InsertOneOptions) error {
	//data.ID = snow_flake.GetSnowflakeID()
	_, err := impl.Collection.InsertOne(ctx, data, opts...)
	if err != nil {
		return err
	}

	//id, ok := result.InsertedID.(primitive.ObjectID)
	//if !ok {
	//	return nil
	//}
	//data.ID = id
	return nil
}

func (impl *SecretGameStatisticDailyMgModelImpl) Delete() {}

func (impl *SecretGameStatisticDailyMgModelImpl) Count(ctx context.Context, filter any, opts ...*options.CountOptions) (int64, error) {
	return impl.Collection.CountDocuments(ctx, filter, opts...)
}
func (impl *SecretGameStatisticDailyMgModelImpl) FindOne(ctx context.Context, filter any, opts ...*options.FindOneOptions) (*pbmgdb.SecretGameStatisticDaily, error) {
	result := &pbmgdb.SecretGameStatisticDaily{}
	err := impl.Collection.FindOne(ctx, filter, opts...).Decode(result)
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (impl *SecretGameStatisticDailyMgModelImpl) FindAll(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretGameStatisticDaily, error) {
	cur, err := impl.Collection.Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	result := make([]*pbmgdb.SecretGameStatisticDaily, 0)
	for cur.Next(ctx) {
		item := &pbmgdb.SecretGameStatisticDaily{}
		if err := cur.Decode(item); err != nil {
			return nil, err
		}
		result = append(result, item)
	}

	return result, err
}

func (impl *SecretGameStatisticDailyMgModelImpl) Update(ctx context.Context, filter, update any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error) {
	return impl.Collection.UpdateOne(ctx, filter, update, opts...)
}

func (impl *SecretGameStatisticDailyMgModelImpl) UpdateMany(ctx context.Context, filter, update any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error) {
	return impl.Collection.UpdateMany(ctx, filter, update, opts...)
}

func (impl *SecretGameStatisticDailyMgModelImpl) Aggregate(ctx context.Context, pipeline any, opts ...*options.AggregateOptions) (*mongo.Cursor, error) {
	cur, err := impl.Collection.Aggregate(ctx, pipeline, opts...)
	if err != nil {
		return nil, err
	}

	return cur, nil
}
