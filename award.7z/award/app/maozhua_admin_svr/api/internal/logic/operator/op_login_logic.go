package operator

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	_const "content_svr/db/m_const"
	"content_svr/pub/utils"
	"context"
	"encoding/json"
	"fmt"
	"gorm.io/gorm"
	"math/rand"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type OpLoginLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewOpLoginLogic(ctx context.Context, svcCtx *svc.ServiceContext) *OpLoginLogic {
	return &OpLoginLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *OpLoginLogic) OpLogin(req *types.OpLoginInReq) (resp *types.OpLoginInResp, err error) {
	_db := l.svcCtx.ManagerDB.OperatorTab
	result, err := _db.WithContext(l.ctx).Where(_db.Email.Eq(req.Email)).First()
	switch err {
	case gorm.ErrRecordNotFound:
		return nil, xerr.OperatorAccountNoExistError
	case nil:
		break
	default:
		return nil, err
	}

	if result.Status == _const.AccountStatusClose {
		return nil, xerr.OperatorAccountError
	}

	if result.Pwd != req.Pwd {
		return nil, xerr.OperatorAccountPasswordError
	}

	src := fmt.Sprintf("%v_%v", time.Now().UnixNano(), rand.Int())
	token := utils.MD5To32(src)

	info, _ := json.Marshal(result)
	err = l.svcCtx.RedisClient.TokenAdmin.SetToken(token, string(info))
	resp = &types.OpLoginInResp{Token: token}
	return
}
