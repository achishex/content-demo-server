package user

import (
	"content_svr/db/redisdb/model/internal"
	"fmt"
	"github.com/go-redis/redis/v8"
	"time"
)

type UserInfoRedis struct {
	// 用户基础信息
	*userInfo

	// 勋章
	*userMedals

	// 护卫队
	*userPersonalPoliceInfo

	// 会员信息
	*userMember

	// 小黑屋
	*userBlackHouse
}

func NewUserInfoRedis(rds *redis.Client, env string) *UserInfoRedis {
	return &UserInfoRedis{
		userInfo: &userInfo{
			RdsInfo: internal.RdsInfo{
				Env:    env,
				Expire: time.Hour * 24,
				RdsKey: "platform:%v:cache:userInfo:hash:%d",
				Client: rds,
			},
		},
		//userMedals: &userMedals{
		//	RdsInfo: internal.RdsInfo{
		//		Env:    env,
		//		Expire: time.Hour * 24,
		//		RdsKey: "platform:%v:cache:userMedal:hash:%d",
		//		Client: rds,
		//	},
		//},
		//userPersonalPoliceInfo: &userPersonalPoliceInfo{
		//	RdsInfo: internal.RdsInfo{
		//		Env:    env,
		//		Expire: time.Hour * 24,
		//		RdsKey: "platform:%v:cache:userPersonalPoliceInfo:hash:%d",
		//		Client: rds,
		//	},
		//},
		userMember: &userMember{
			RdsInfo: internal.RdsInfo{
				Env:    env,
				Expire: time.Hour * 24,
				RdsKey: "platform:%v:secret:members:info:%v",
				Client: rds,
			},
		},
		userBlackHouse: &userBlackHouse{
			RdsInfo: internal.RdsInfo{
				Env:    env,
				Expire: 0,
				RdsKey: fmt.Sprintf("platform:%s:soul_soup:blackHouse", env),
				Client: rds,
			},
		},
	}
}
