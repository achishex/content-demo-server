package const_busi

const (
	_ = iota
	Boy
	Girl
)

const (
	UserInvalidStatus int32 = 0
	UserValidStatus   int32 = 1
)

const (
	_                     int32 = iota
	UserCardStatus              // 登记
	UserCardSignOutStatus       // 注销
)

const (
	UserLockTemporary int32 = 2 //临时封禁
	UserLockPermanent int32 = 3 //永久封禁
)
const (
	MutualUsers int32 = 1
)

const (
	Mutual = 1 //猫友
	Follow = 2 //关注
	Fans   = 3 //粉丝
)

const (
	MedalPermanentNeedMutualCnt = 12  //社牛永久勋章所需要互关数量
	MedalKingOfCatNeedFollowCnt = 500 //猫王勋章所需被关注数量

	MedalIdXinYa           = 1 // 新芽勋章id
	MedalIdSocialButterfly = 5 //社牛勋章id
	MedalIdKingOfCat       = 6 //猫王
)

const (
	IdentityUnknown  = iota
	IdentityUnderage // 未成年
	IdentityAdult    // 成年
)

const (
	TalkModeUnknown int32 = iota
	TalkModeOpen          // 扩列模式，允许接收陌生人的主动私信
	TalkModeClose         // 闭关模式，拒绝接收陌生人的主动私信
)

const (
	StartTargetOpen  = 1 // 设置星标
	StartTargetClose = 2 // 取消星标
)

// 0非会员 1-svip 2赠送会员 3-普通会员
const (
	NormalUser = iota
	SVipUser
	GiftVipUser
	VipUser
)

// 用户类型 1普通用户 2官方用户 3 bb机 4 机器人
const (
	UserTypeNormal    = 1
	UserTypeOfficial2 = 2 // 官方号，客户端展示 官方标识
	UserTypeOfficial3 = 3 // 官方号，客户端展示官方标识，且不可以聊天
	UserTypeOfficial4 = 4 // 官方号，客户端展示官方标识，且评论不做计数（评论机器人使用）
)

var UserTypeOfficial = []int32{
	UserTypeOfficial2,
	UserTypeOfficial3,
	UserTypeOfficial4,
}

const (
	WorkSettingGenderMen       int32 = 1 //男
	WorkSettingGenderWomen     int32 = 2 //女
	WorkSettingGenderUnlimited int32 = 3 //不限
)
