package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretMemberInfoMgModel interface {
	ListByConditionModel(ctx context.Context,
		cond interface{}, page, size int64) ([]*pbmgdb.SecretMemberInfoMgDbModel, error)
	DictByUserIds(ctx context.Context, userIds []int64) (map[int64]*pbmgdb.SecretMemberInfoMgDbModel, error)
	QueryByUserId(ctx context.Context, userId int64) ([]*pbmgdb.SecretMemberInfoMgDbModel, error)
	UpdateUserMemberByUserId(ctx context.Context, id int64, update map[string]interface{}, incDict map[string]int) error
}

type SecretMemberInfoMgDbImpl struct {
	MgDB *mongo.Database
}

func NewSecretMemberInfoMgModelImpl(db *mongo.Database) ISecretMemberInfoMgModel {
	return &SecretMemberInfoMgDbImpl{MgDB: db}
}

func (impl *SecretMemberInfoMgDbImpl) table() string {
	return "secretMemberInfo"
}

func (impl *SecretMemberInfoMgDbImpl) UpdateUserMemberByUserId(ctx context.Context, id int64,
	data map[string]interface{}, incDict map[string]int) error {
	if len(data)+len(incDict) == 0 {
		return nil
	}
	collection := impl.MgDB.Collection(impl.table())
	update := bson.D{
		{"$set", data},
	}

	filter := bson.D{
		{"userId", id},
	}

	var err error
	exist, err := collection.CountDocuments(ctx, filter)
	if exist == 0 {
		data["_id"] = snow_flake.GetSnowflakeID()
		opts := options.Update().SetUpsert(true) // 存在时更新，不存在时插入
		_, err = collection.UpdateOne(ctx, filter, update, opts)
	} else {
		_, err = collection.UpdateOne(ctx, filter, update)
	}

	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretMemberInfoMgDbImpl.UpdateUserMemberByUserId  failed. id=%v, data=%v, incDict=%v",
			id, data, incDict), err)
	}
	return err
}

func (impl *SecretMemberInfoMgDbImpl) ListByConditionModel(ctx context.Context,
	cond interface{}, page, size int64) ([]*pbmgdb.SecretMemberInfoMgDbModel, error) {
	collection := impl.MgDB.Collection(impl.table())
	findOptions := options.Find()
	findOptions.SetLimit(size)
	findOptions.SetSort(bson.D{
		{"_id", 1}, //升序
	})
	//查询条件
	find, err := collection.Find(ctx, cond, findOptions)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretMemberInfo ListByCondition failed. cond=%v",
			cond), err)
		return nil, err
	}
	retItems := make([]*pbmgdb.SecretMemberInfoMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.SecretMemberInfoMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretMemberInfo failed.cond=%v",
				cond), err)
			//return nil, err
			continue
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (impl *SecretMemberInfoMgDbImpl) DictByUserIds(ctx context.Context, userIds []int64) (map[int64]*pbmgdb.SecretMemberInfoMgDbModel, error) {
	filter := bson.D{
		{"userId", bson.D{
			{"$in", userIds},
		}},
	}
	collection := impl.MgDB.Collection(impl.table())
	cur, err := collection.Find(ctx, filter)
	if err != nil {
		return nil, err
	}

	resp := make(map[int64]*pbmgdb.SecretMemberInfoMgDbModel)
	for cur.Next(ctx) {
		item := &pbmgdb.SecretMemberInfoMgDbModel{}
		// 解码绑定数据
		//v := make(map[string]interface{})
		//err = cur.Decode(&v)
		err = cur.Decode(item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretMemberInfo failed.cond=%v",
				filter), err)
			//return nil, err
			continue
		}
		resp[item.GetUserId()] = item
	}

	return resp, nil
}

func (impl *SecretMemberInfoMgDbImpl) QueryByUserId(ctx context.Context, userId int64) ([]*pbmgdb.SecretMemberInfoMgDbModel, error) {
	condMg := bson.D{
		{"userId", userId},
	}
	return impl.ListByConditionModel(ctx, condMg, 1, 1)
}
