package data_cache

import (
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"strconv"
	"time"
)

// SetActivityRankerByStep
// key: 活动当天日期, 0点时间戳，毫秒
// field: user_id
// score: step_nums
// expire_time： 秒
func (p *DataCacheMng) SetActivityRankerByStep(ctx context.Context, simpleKey int64, user_id int64, step_nums int64, expire_time int64) error {
	rdkey := getRdsKeySportRanker(simpleKey)
	data := []*redis.Z{&redis.Z{Score: float64(step_nums), Member: user_id}}
	_, err := p.RedisCli.ZAdd(ctx, rdkey, data...).Result()
	if err != nil {
		logger.Errorf(ctx, "set redis fail, user_id: %v, step: %v, err: %v", user_id, step_nums, err)
		return nil
	}
	p.RedisCli.Expire(ctx, rdkey, time.Duration(expire_time)*time.Second)
	return nil
}

// GetRankerIdForUser 获取用户的排行榜位置，依次返回排行榜位置，步数，错误
func (p *DataCacheMng) GetRankerIdForUser(ctx context.Context, simpleKey int64, user_id int64) (int64, int64, error) {
	rdkey := getRdsKeySportRanker(simpleKey)
	userIdStr := fmt.Sprintf("%v", user_id)
	siteNums, err := p.RedisCli.ZRevRank(ctx, rdkey, userIdStr).Result()
	if err != nil {
		logger.Errorf(ctx, "not find user ranker id, err: %v", err)
		return -1, 0, err
	}
	score, err := p.RedisCli.ZScore(ctx, rdkey, userIdStr).Result()
	if err != nil {
		logger.Errorf(ctx, "ZScore not find user ranker id, err: %v", err)
		return -1, 0, err
	}

	return siteNums + 1, int64(score), nil
}

func (p *DataCacheMng) GetRankerUserTop20(ctx context.Context, simpleKey int64) (*utils.SortMap, error) {
	key := getRdsKeySportRanker(simpleKey)

	// ZREVRANGE myset 0 9 WITHSCORES
	users, err := p.RedisCli.ZRevRangeWithScores(ctx, key, 0, 20).Result()
	if err != nil {
		return nil, nil
	}

	userMap := utils.NewSortMap()
	for _, user := range users {
		id, err := strconv.Atoi(user.Member.(string))
		if err != nil {
			logger.Error(ctx, "redis 中存储的 user_id 不正确", err)
			continue
		}
		userMap.Set(int64(id), int64(user.Score))
	}
	return userMap, err
}

func (p *DataCacheMng) AggregateRankerUserByRedis(ctx context.Context, simpleKey int64) (int64, int64, error) {
	key := getRdsKeySportRanker(simpleKey)
	result, err := p.RedisCli.ZRevRangeWithScores(ctx, key, 0, -1).Result()
	if err != nil {
		return 0, 0, nil
	}

	var userCount int64
	var stepTotal int64
	for _, user := range result {
		userCount++
		stepTotal += int64(user.Score)
	}

	return userCount, stepTotal, nil
}
