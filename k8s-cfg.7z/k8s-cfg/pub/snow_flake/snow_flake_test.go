package snow_flake

import "testing"

func TestGetSnowflakeID(t *testing.T) {
	SetMachineID(8)
	t.Log(GetSnowflakeID())
	t.Log(GetSnowflakeID())
}
