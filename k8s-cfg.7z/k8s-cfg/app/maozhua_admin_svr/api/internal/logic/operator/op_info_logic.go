package operator

import (
	"context"
	"github.com/jinzhu/copier"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type OpInfoLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewOpInfoLogic(ctx context.Context, svcCtx *svc.ServiceContext) *OpInfoLogic {
	return &OpInfoLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *OpInfoLogic) OpInfo(req *types.OpInfoReq) (resp *types.OpInfoResp, err error) {
	_db := l.svcCtx.ManagerDB.OperatorTab
	result, err := _db.WithContext(l.ctx).Where(_db.Email.Eq(req.CtxEmail)).First()
	if err != nil {
		return nil, err
	}

	resp = &types.OpInfoResp{}
	err = copier.Copy(resp, result)

	return
}
