package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const SecretMedalInfoCollectionName = "secret_medal_info"

var _ SecretMedalInfoModel = (*customSecretMedalInfoModel)(nil)

type (
	// SecretMedalInfoModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretMedalInfoModel.
	SecretMedalInfoModel interface {
		secretMedalInfoModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretMedalInfo, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretMedalInfo, error)
	}

	customSecretMedalInfoModel struct {
		*defaultSecretMedalInfoModel
	}
)

// NewSecretMedalInfoModel returns a model for the mongo.
func NewSecretMedalInfoModel(cfg MonConfig) SecretMedalInfoModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SecretMedalInfoCollectionName)
	return &customSecretMedalInfoModel{
		defaultSecretMedalInfoModel: newDefaultSecretMedalInfoModel(conn),
	}
}

func (m *customSecretMedalInfoModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customSecretMedalInfoModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretMedalInfoModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretMedalInfo, error) {
	result := make([]SecretMedalInfo, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretMedalInfoModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretMedalInfo, error) {
	var data SecretMedalInfo
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
