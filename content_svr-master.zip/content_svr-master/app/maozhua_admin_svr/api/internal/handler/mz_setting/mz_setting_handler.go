package mz_setting

import (
	"content_svr/app/maozhua_admin_svr/common/result"
	"github.com/go-playground/validator/v10"
	"net/http"

	"content_svr/app/maozhua_admin_svr/api/internal/logic/mz_setting"
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"github.com/zeromicro/go-zero/rest/httpx"
)

type verifyMzSettingReqRequest struct {
	types.MzSettingReq
}

func (p *verifyMzSettingReqRequest) Validate() error {
	valid := validator.New()
	if err := valid.Struct(p); err != nil {
		return err
	}
	return nil
}

func MzSettingHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req verifyMzSettingReqRequest
		if err := httpx.Parse(r, &req); err != nil {
			result.ParamErrorResult(r, w, err)
			return
		}

		l := mz_setting.NewMzSettingLogic(r.Context(), svcCtx)
		resp, err := l.MzSetting(&req.MzSettingReq)
		result.HttpResult(r, w, resp, err)
	}
}
