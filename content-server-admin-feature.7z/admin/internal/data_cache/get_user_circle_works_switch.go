package data_cache

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	"time"
)

func (p *DataCacheMng) GetUserCircleWorksSwitchDbModelLd(ctx context.Context, userId int64,
	bSkipCache bool) *pbapi.UserCircleWorksSwitchDbModel {
	//从内存取
	cacheKey := getLocalCacheKeyUserCircleWorksSwitchDbModel(userId)
	if bSkipCache == false {
		cResp, exist := p.LocalCache.Get(cacheKey)
		if exist {
			resp, ok := cResp.(*pbapi.UserCircleWorksSwitchDbModel)
			if ok && resp != nil {
				return resp
			}
		}
	}

	item, err := p.UserCircleWorksSwitchDbModel.GetByUserId(ctx, userId)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("query UserCircleWorksSwitchDbModel failed. userId=%v", userId), nil)
		return nil
	}

	// save 到localcache
	if bSkipCache == false {
		bSuc := p.LocalCache.Set(cacheKey, item, go_cache.WithEx(5*60*time.Second))
		if !bSuc {
			logger.Error(ctx, fmt.Sprintf("save UserCircleWorksSwitchDbModel to local cache failed. userId=%v", userId), nil)
		}
	}
	return item
}
