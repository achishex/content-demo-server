package taskq

import (
	"content_svr/pub/utils"
	"context"
	"github.com/go-redis/redis/v8"
	"github.com/stretchr/testify/assert"
	"sync/atomic"
	"testing"
	"time"
)

func TestTaskQAll(t *testing.T) {
	addr := "127.0.0.1:6379"
	execCount := int64(0)
	cli := redis.NewClient(&redis.Options{
		Addr:     addr,
		DB:       0,
		PoolSize: 100,
	})
	taskType := "type1"
	tq := NewTaskQ(cli)
	tq.Register(taskType, func(ctx context.Context, msg *TaskMsg) error {
		t.Logf("exec task: %+v", msg)
		atomic.AddInt64(&execCount, 1)
		return nil
	})
	t.Log("run taskq ..")
	go tq.Run()

	ctx := context.Background()
	taskID, err := tq.Submit(ctx, &TaskMsg{
		UserID:   "1",
		TaskType: taskType,
	}, time.Second*3)
	assert.Nil(t, err)
	assert.NotEmpty(t, taskID)
	t.Logf("taskID: %v", taskID)

	time.Sleep(2 * time.Second)
	assert.Equal(t, int64(0), execCount)
	time.Sleep(3 * time.Second)
	assert.Equal(t, int64(1), execCount)
}

func TestRandFloat(t *testing.T) {
	for i := 0; i < 10; i++ {
		t.Log(utils.DefaultRand.Float64())
	}
}
