package user_center_mng

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/snow_flake"
	"context"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/copier"
	"github.com/kevwan/mapreduce/v2"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"math"
	"time"
)

// 关注/取消关注
func (u *UserCenterMng) Follow(ctx context.Context, req *pbuserapi.FollowReq) (*pbuserapi.FollowResp, error) {
	var (
		resp = &pbuserapi.FollowResp{}

		curUserId    = middleware.GetUserID(ctx.(*gin.Context))
		targetUserId = req.GetTargetUserId()
	)

	if curUserId == targetUserId {
		return nil, errorcode.FollowMyselfCanNot
	}

	//对方在你的拉黑名单中
	if u.DataCache.CheckUserBlackListMgDBLD(ctx, curUserId, targetUserId) {
		logger.Infof(ctx, "fromUser is in curUser blacklist, skip.from=%v, cur=%v", curUserId, req.TargetUserId)
		return nil, errorcode.FollowMsgInMyBlack
	}

	//在对方的拉黑名单中
	if u.DataCache.CheckUserBlackListMgDBLD(ctx, targetUserId, curUserId) {
		logger.Infof(ctx, "fromUser is in curUser blacklist, skip.from=%v, cur=%v", curUserId, req.TargetUserId)
		return nil, errorcode.FollowMsgInTargetBlack
	}

	var (
		err                          error
		mutual, fans                 = false, false
		meMutualCnt, targetMutualCnt = u.getBothMutualCnt(ctx, curUserId, targetUserId)

		meFollowTarget *pbapi.SecretUserFollowMgDbModel
		targetFollowMe *pbapi.SecretUserFollowMgDbModel
		followDoc      = u.DataCache.GetImpl().SecretUserFollowMgModel
		badgeListDoc   = u.DataCache.GetImpl().SecretUserFollowBadgeListMgDbModel
	)

	if meFollowTarget, err = followDoc.GetByUserId(ctx, curUserId, targetUserId); err != nil {
		return nil, err
	}
	if targetFollowMe, err = followDoc.GetByUserId(ctx, targetUserId, curUserId); err != nil {
		return nil, err
	}

	if meFollowTarget == nil {
		//关注
		follow := &pbapi.SecretUserFollowMgDbModel{
			Id:           snow_flake.GetSnowflakeID(),
			UserId:       curUserId,
			TargetUserId: targetUserId,
			Timestamp:    time.Now().UnixMilli(),
			Mutual:       0,
		}

		fans = true
		if targetFollowMe != nil {
			resp.FollowMe = true
			mutual, fans = true, false

			follow.Mutual = 1
			if err := followDoc.UpdateFollow(ctx, targetFollowMe.Id, bson.D{{"$set", bson.D{{"mutual", 1}}}}, nil); err != nil {
				return nil, err
			}

			//互关次数 & 社牛勋章处理
			meMutualCnt += 1
			targetMutualCnt += 1
			if err := u.checkMedia(ctx, curUserId, meMutualCnt); err != nil {
				return nil, err
			}
			if err := u.checkMedia(ctx, targetUserId, targetMutualCnt); err != nil {
				return nil, err
			}
		}

		if err := followDoc.AddFollow(ctx, follow, nil); err != nil {
			return nil, err
		}
		resp.MeFollow = true

		//红点
		if err := badgeListDoc.AddOne(ctx, &pbmgdb.SecretUserFollowBadgeListMgDbModel{
			Id:           snow_flake.GetSnowflakeID(),
			UserId:       targetUserId,
			TargetUserId: curUserId,
			Mutual:       mutual,
			Fans:         fans,
			CreateTime:   time.Now().UnixMilli(),
		}); err != nil {
			return nil, err
		}

		//对方被关注数+1
		if err := u.updateFollowCnt(ctx, targetUserId, 1); err != nil {
			return nil, err
		}

	} else {
		//取消关注
		resp.MeFollow = true
		if err := followDoc.DelFollow(ctx, bson.D{{"_id", meFollowTarget.Id}}); err != nil {
			return nil, err
		}
		resp.MeFollow = false
		if meFollowTarget.Mutual == 1 && targetFollowMe != nil {
			resp.FollowMe = true

			data := bson.D{
				{"$set", bson.D{
					{"mutual", 0},
					{"starTarget", 0},
					{"remarkName", ""},
				}},
			}
			if err := followDoc.UpdateFollow(ctx, targetFollowMe.Id, data, nil); err != nil {
				return nil, err
			}
			//互关次数 & 社牛勋章处理
			meMutualCnt -= 1
			targetMutualCnt -= 1
			if err := u.checkMedia(ctx, curUserId, meMutualCnt); err != nil {
				return nil, err
			}
			if err := u.checkMedia(ctx, targetUserId, targetMutualCnt); err != nil {
				return nil, err
			}
		}

		//删除红点
		if err := badgeListDoc.DeleteOne(ctx, bson.M{"userId": targetUserId, "targetUserId": curUserId}); err != nil {
			return nil, err
		}

		//被关注数-1
		if err := u.updateFollowCnt(ctx, targetUserId, -1); err != nil {
			return nil, err
		}

		//清理备注
		if err := u.DataCache.DelUserRemarkOne(ctx, curUserId, targetUserId); err != nil {
			logger.Error(ctx, "add black list by remark name error: ", err)
		}
	}

	return resp, nil
}

// 互关次数
func (u *UserCenterMng) getBothMutualCnt(ctx context.Context, userId, targetUserId int64) (int64, int64) {
	filter := bson.D{{"userId", userId}, {"mutual", 1}}
	meCnt := u.DataCache.GetImpl().SecretUserFollowMgModel.GetMutualCnt(ctx, filter)

	filter = bson.D{{"userId", targetUserId}, {"mutual", 1}}
	targetCnt := u.DataCache.GetImpl().SecretUserFollowMgModel.GetMutualCnt(ctx, filter)

	return meCnt, targetCnt
}

// 勋章处理
func (u *UserCenterMng) checkMedia(ctx context.Context, userId, mutualCnt int64) error {
	if mutualCnt >= const_busi.MedalPermanentNeedMutualCnt {
		if err := u.MediaPermanent(ctx, userId, const_busi.MedalIdSocialButterfly); err != nil {
			return err
		}
	}
	return nil
}

// 更新关注次数 & 猫王勋章
func (u *UserCenterMng) updateFollowCnt(ctx context.Context, userId, cnt int64) error {
	if err := u.DataCache.GetImpl().UserInfoExtMgModel.UpdateByCond(ctx,
		bson.M{"_id": userId},
		bson.D{
			{"$inc", bson.M{"followed": cnt}},
		}); err != nil {
		return err
	}

	//猫王勋章
	userExtInfo := u.DataCache.GetImpl().GetUserExtInfoMgDBLd(ctx, userId, false)
	if userExtInfo != nil && userExtInfo.GetFollowed() >= const_busi.MedalKingOfCatNeedFollowCnt {
		if err := u.MediaPermanent(ctx, userId, const_busi.MedalIdKingOfCat); err != nil {
			return err
		}
	} else {
		if err := u.MediaCancel(ctx, userId, const_busi.MedalIdKingOfCat); err != nil {
			return err
		}
	}

	return nil
}

// 猫友/关注/粉丝 列表
func (u *UserCenterMng) FollowList(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbuserapi.FollowListReq) (*pbuserapi.FollowListResp, error) {
	var (
		resp = &pbuserapi.FollowListResp{
			List:        nil,
			CurrentPage: int32(req.Page),
			Pages:       1,
			Total:       0,
		}

		curUserId = middleware.GetUserID(ctx.(*gin.Context))
		listType  = req.ListType
		cond      = map[string]any{}
		finalUid  int64

		followDoc      = u.DataCache.GetImpl().SecretUserFollowMgModel
		badgeDoc       = u.DataCache.GetImpl().SecretUserFollowBadgeListMgDbModel
		badgeFilter    = bson.M{"userId": curUserId}
		badgeDelFilter = bson.M{"userId": curUserId}
	)

	switch listType {
	case const_busi.Mutual:
		cond["userId"] = curUserId
		cond["mutual"] = const_busi.MutualUsers
		//cond["starTarget"] = bson.D{{"$ne", 1}}
		badgeFilter["mutual"] = true
		badgeDelFilter["mutual"] = true
	case const_busi.Follow:
		cond["userId"] = curUserId
	case const_busi.Fans:
		cond["targetUserId"] = curUserId
		badgeFilter["fans"] = true
		badgeDelFilter["fans"] = true
	default:
		return resp, nil
	}

	errReturn := errors.New("empty list")
	if err := mapreduce.Finish(func() error {
		resp.Total = u.getTotalWithFilterNilUser(ctx, header, listType, cond)
		if resp.Total > 0 && req.Size > 0 {
			resp.Pages = int32(math.Ceil(float64(resp.Total) / float64(req.Size)))
		}
		return nil
	}, func() error {
		opts := &options.FindOptions{}
		offset := (req.Page - 1) * req.Size
		opts.Skip = &offset
		opts.Limit = &req.Size
		opts.Sort = bson.D{{"timestamp", -1}}

		var list, listStarTarget, listNoStarFollow []*pbapi.SecretUserFollowMgDbModel
		if err := mapreduce.Finish(func() error {
			if listType == const_busi.Mutual && req.Page == 1 {
				var err error
				// 先查一次星标用户
				cond := map[string]interface{}{
					"userId":     curUserId,
					"mutual":     const_busi.MutualUsers,
					"starTarget": 1,
				}
				listStarTarget, err = followDoc.ListByCondition(ctx, cond, opts)
				if err != nil {
					logger.Infof(ctx, "ListByCondition: %v", cond)
				}
			}
			return nil
		}, func() error {
			var err error
			condNoStar := map[string]any{}
			if err = copier.Copy(&condNoStar, cond); err != nil {
				for k, v := range cond {
					condNoStar[k] = v
				}
			}
			if listType == const_busi.Mutual {
				condNoStar["starTarget"] = bson.D{{"$ne", 1}}
			}
			listNoStarFollow, err = followDoc.ListByCondition(ctx, condNoStar, opts)
			if err != nil {
				return err
			}
			return nil
		}); err != nil {
			return err
		}
		list = append(listStarTarget, listNoStarFollow...)
		if len(list) == 0 {
			return errReturn
		}

		for _, item := range list {
			if listType == const_busi.Fans {
				finalUid = item.UserId
			} else {
				finalUid = item.TargetUserId
			}

			var (
				userInfo    *data_cache.UserInfoLocal
				stat        *pbuserapi.FollowStatusResp
				lastWorkId  int64
				talkMode    int32
				remarkName  string
				badge       *pbmgdb.SecretUserFollowBadgeListMgDbModel
				errContinue = errors.New("continue")
			)

			if err := mapreduce.Finish(func() error {
				var err error
				userInfo, err = u.DataCache.GetUserInfoLocal(ctx, header, finalUid, false)
				if userInfo == nil || err != nil {
					return errContinue
				}
				return nil
			}, func() error {
				talkMode = u.DataCache.GetUserInfoTalkMode(ctx, finalUid)
				return nil
			}, func() error {
				stat, _ = u.getFollowStat(ctx, curUserId, finalUid)
				return nil
			}, func() error {
				lastWorkId = u.getLastWorkByCache(ctx, finalUid)
				return nil
			}, func() error {
				var err error
				remarkName, err = u.DataCache.GetUserRemarkOne(ctx, curUserId, finalUid)
				return err
			}, func() error {
				//列表小红点状态
				badgeFilter["targetUserId"] = finalUid
				badge, _ = badgeDoc.Get(ctx, badgeFilter)
				return nil
			}, func() error {
				if item.GetMutual() == const_busi.Mutual {

					switch listType {
					case const_busi.Fans:
						follow, err := followDoc.GetByUserId(ctx, curUserId, item.UserId)
						if err != nil {
							return err
						}
						item.StarTarget = follow.GetStarTarget()
					case const_busi.Follow:
						follow, err := followDoc.GetByUserId(ctx, curUserId, item.TargetUserId)
						if err != nil {
							return err
						}
						item.StarTarget = follow.GetStarTarget()
					}

				}
				return nil
			}); err != nil && err == errContinue {
				continue
			}

			fi := &pbuserapi.FollowItem{
				Id:        item.Id,
				Timestamp: item.Timestamp,
				UserId:    userInfo.UserInfoDbModel.GetUserId(),
				User: &pbuserapi.FollowUser{
					UserId:     userInfo.UserInfoDbModel.GetUserId(),
					NickName:   userInfo.UserInfoDbModel.GetNickName(),
					Photo:      userInfo.UserInfoDbModel.GetPhoto(),
					Gender:     userInfo.UserInfoDbModel.GetGender(),
					MemberType: userInfo.MemberType,
					UserType:   userInfo.UserInfoDbModel.GetUserType(),
					Ulevel:     userInfo.PsecretUserExtInfo.GetUlevel(),
					TalkMode:   talkMode,
					RemarkName: remarkName,
					StarTarget: item.StarTarget,
				},
				Stat: &pbuserapi.FollowStat{
					FollowMe: stat.FollowMe,
					MeFollow: stat.MeFollow,
				},
				WorkId: lastWorkId,
				Badge:  false,
			}

			if badge != nil {
				if listType == const_busi.Mutual {
					fi.Badge = badge.Mutual
				} else if listType == const_busi.Fans {
					fi.Badge = badge.Fans
				}
			}

			//勋章
			if len(userInfo.UserMedals) > 0 {
				for _, item := range userInfo.UserMedals {
					fi.User.Medals = append(fi.User.Medals, &pbuserapi.FollowMedals{
						Expire:    item.Expire,
						Icon:      item.Icon,
						MedalId:   item.MedalId,
						MedalName: item.MedalName,
						SmallIcon: item.SmallIcon,
						Timestamp: item.Timestamp,
					})
				}
			}

			resp.List = append(resp.List, fi)
		}
		return nil
	}); err == errReturn {
		return resp, nil
	}

	go func() {
		defer func() {
			if err := recover(); err != nil {
				logger.Errorf(ctx, "panic err: %v", err)
			}
		}()

		if err := badgeDoc.DeleteMany(ctx, badgeDelFilter); err != nil {
			logger.Errorf(ctx, "del badge list failed. filter:%v", badgeDelFilter)
		}
	}()

	return resp, nil
}

// 这里有历史数据问题特殊过滤处理
// 原userinfo做过物理删除，导致关注关系中的用户不存在。
func (u *UserCenterMng) getTotalWithFilterNilUser(ctx context.Context, header *pbapi.HttpHeaderInfo, listType int32, cond map[string]any) int64 {
	var (
		finalUid  int64
		followDoc = u.DataCache.GetImpl().SecretUserFollowMgModel
	)

	list, err := followDoc.ListByCondition(ctx, cond, nil)
	total := len(list)
	if err != nil || total == 0 {
		return 0
	}

	if total > 50 {
		return int64(total)
	}

	for _, item := range list {
		if listType == const_busi.Fans {
			finalUid = item.UserId
		} else {
			finalUid = item.TargetUserId
		}

		userInfo, err := u.DataCache.GetUserInfoLocal(ctx, header, finalUid, false)
		if userInfo == nil || err != nil {
			total -= 1
			continue
		}
	}

	return int64(total)
}

// 获取最后发布动态
func (u *UserCenterMng) getLastWork(ctx context.Context, userId int64) int64 {
	cond := map[string]interface{}{
		"userId":     userId,
		"createTime": time.Now().AddDate(0, 0, -1),
	}
	work, err := u.DataCache.GetImpl().PersonBottleWorksModel.GetLastWork(ctx, cond)
	if err != nil {
		//logger.Errorf(ctx, "getLastWork error: %v", err)
		return 0
	}
	return work.GetId()
}

func (u *UserCenterMng) getLastWorkByCache(ctx context.Context, userId int64) int64 {
	if u.DataCache.GetPushChitchatTimes(ctx, userId) > 0 {
		return 1 //此workId相当于bool值，只用于判断有无
	}
	return 0
}

// 关注状态
func (u *UserCenterMng) FollowStat(ctx context.Context, req *pbuserapi.FollowStatusReq) (*pbuserapi.FollowStatusResp, error) {
	var (
		resp = &pbuserapi.FollowStatusResp{}

		curUserId    = middleware.GetUserID(ctx.(*gin.Context))
		targetUserId = req.GetTargetUserId()
	)

	resp, _ = u.getFollowStat(ctx, curUserId, targetUserId)

	return resp, nil
}

// 获取状态
func (u *UserCenterMng) getFollowStat(ctx context.Context, curUserId, targetUserId int64) (*pbuserapi.FollowStatusResp, error) {
	var (
		resp = &pbuserapi.FollowStatusResp{}

		err            error
		meFollowTarget *pbapi.SecretUserFollowMgDbModel
		targetFollowMe *pbapi.SecretUserFollowMgDbModel
		model          = u.DataCache.GetImpl().SecretUserFollowMgModel
	)

	if meFollowTarget, err = model.GetByUserId(ctx, curUserId, targetUserId); err != nil {
		return nil, err
	}
	if targetFollowMe, err = model.GetByUserId(ctx, targetUserId, curUserId); err != nil {
		return nil, err
	}

	if meFollowTarget == nil {
		resp.MeFollow = false
	} else {
		resp.MeFollow = true
	}

	if targetFollowMe == nil {
		resp.FollowMe = false
	} else {
		resp.FollowMe = true
	}
	return resp, nil
}

// 小红点状态
func (u *UserCenterMng) FollowBadge(ctx context.Context) (*pbuserapi.FollowBadgeStatResp, error) {
	var (
		resp = &pbuserapi.FollowBadgeStatResp{
			Mutual: false,
			Fans:   false,
		}

		userId     = middleware.GetUserID(ctx.(*gin.Context))
		badgeListM = u.DataCache.GetImpl().SecretUserFollowBadgeListMgDbModel
	)

	if badgeListM.Exists(ctx, bson.M{"userId": userId, "mutual": true}) {
		resp.Mutual = true
	}

	if badgeListM.Exists(ctx, bson.M{"userId": userId, "fans": true}) {
		resp.Fans = true
	}

	return resp, nil
}
