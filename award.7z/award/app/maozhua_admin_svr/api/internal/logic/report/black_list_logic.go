package report

import (
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type BlackListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewBlackListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *BlackListLogic {
	return &BlackListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *BlackListLogic) BlackList(req *types.BlackListReq) (resp *types.BlackListResp, err error) {
	// todo: add your logic here and delete this line

	return
}
