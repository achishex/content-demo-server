package middleware

import (
	"context"
	"github.com/gin-gonic/gin"
	"net/http"
)

const (
	ginContextName = "gin_context"
)

func GinHandle(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		ctx := &gin.Context{}
		r = r.WithContext(context.WithValue(r.Context(), ginContextName, ctx))
		ctx.Request = r

		// 处理请求
		next(w, r)
	}
}

func GetGinContext(ctx context.Context) *gin.Context {
	ginContext := ctx.Value(ginContextName)
	if ginContext == nil {
		return &gin.Context{}
	}

	return ginContext.(*gin.Context)
}
