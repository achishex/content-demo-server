package mg_model

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISuperiorContentAwardDetailMgModel interface {
	GetLatestItemByUserId(ctx context.Context, userId int64) (*pbmgdb.SuperiorContentAwardDetail, error)
	InsertOneItem(ctx context.Context, item *pbmgdb.SuperiorContentAwardDetail) error
	ListByCond(ctx context.Context, filter bson.D, opts bson.D) ([]*pbmgdb.SuperiorContentAwardDetail, error)
	FindAll(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SuperiorContentAwardDetail, error)
	Count(ctx context.Context, filter bson.D, opts ...*options.CountOptions) (int64, error)
	SumAccountByConds(ctx context.Context, filter bson.D) (float64, error)
	Update(ctx context.Context, filter, update any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error)
	Aggregate(ctx context.Context, filter any, opts ...*options.AggregateOptions) (*mongo.Cursor, error)
	FindOne(ctx context.Context, filter any, opts ...*options.FindOneOptions) (*pbmgdb.SuperiorContentAwardDetail, error)
}

type SuperiorContentAwardDetailMgModelImpl struct {
	MgDB  *mongo.Database
	Table string
}

func NewSuperiorContentAwardDetailMgModelImpl(db *mongo.Database) ISuperiorContentAwardDetailMgModel {
	return &SuperiorContentAwardDetailMgModelImpl{
		MgDB:  db,
		Table: "superior_content_award_detail",
	}
}

func (impl *SuperiorContentAwardDetailMgModelImpl) SumAccountByConds(ctx context.Context, filter bson.D) (float64, error) {
	if len(filter) <= 0 {
		return 0.0, nil
	}

	pipeline := []bson.M{
		{
			"$match": filter,
		},
		{
			"$group": bson.M{"_id": "null", "totalAward": bson.M{"$sum": "$award"}},
		},
	}
	coll := impl.MgDB.Collection(impl.Table)
	cursor, err := coll.Aggregate(ctx, pipeline)
	if err != nil {
		logger.Errorf(ctx, "get sum account fail, err: %v", err)
		return 0.0, err
	}
	defer cursor.Close(ctx)

	for cursor.Next(ctx) {
		var result bson.M
		if err := cursor.Decode(&result); err != nil {
			logger.Errorf(ctx, "get fail for total award!, err: %v", err)
			continue
		}

		if retNums, ok := result["totalAward"].(float64); ok {
			return retNums, nil
		}
	}
	return 0.0, nil
}
func (impl *SuperiorContentAwardDetailMgModelImpl) ListByCond(ctx context.Context, filter bson.D, optsField bson.D) ([]*pbmgdb.SuperiorContentAwardDetail, error) {
	coll := impl.MgDB.Collection(impl.Table)
	opts := options.Find()
	if len(optsField) > 0 {
		opts.SetSort(optsField)
	}
	cursor, err := coll.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "superior award detail fail, err: %v", err)
		return nil, err
	}
	var result []*pbmgdb.SuperiorContentAwardDetail
	for cursor.Next(ctx) {
		data := &pbmgdb.SuperiorContentAwardDetail{}
		err = cursor.Decode(data)
		if err != nil {
			logger.Errorf(ctx, "get superior award detail fail,, err: %v", err)
			return nil, err
		}
		result = append(result, data)
	}
	if len(result) <= 0 {
		return nil, nil
	}
	return result, nil
}

func (impl *SuperiorContentAwardDetailMgModelImpl) FindAll(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SuperiorContentAwardDetail, error) {
	var (
		coll = impl.MgDB.Collection(impl.Table)
	)

	cursor, err := coll.Find(ctx, filter, opts...)
	if err != nil {
		logger.Errorf(ctx, "superior award detail fail, err: %v", err)
		return nil, err
	}
	var result []*pbmgdb.SuperiorContentAwardDetail
	for cursor.Next(ctx) {
		data := &pbmgdb.SuperiorContentAwardDetail{}
		err = cursor.Decode(data)
		if err != nil {
			logger.Errorf(ctx, "get superior award detail fail,, err: %v", err)
			return nil, err
		}
		result = append(result, data)
	}
	if len(result) <= 0 {
		return nil, nil
	}
	return result, nil
}

func (impl *SuperiorContentAwardDetailMgModelImpl) InsertOneItem(ctx context.Context, item *pbmgdb.SuperiorContentAwardDetail) error {
	coll := impl.MgDB.Collection(impl.Table)
	_, err := coll.InsertOne(ctx, item)
	return err
}
func (impl *SuperiorContentAwardDetailMgModelImpl) GetLatestItemByUserId(ctx context.Context, userId int64) (*pbmgdb.SuperiorContentAwardDetail, error) {
	coll := impl.MgDB.Collection(impl.Table)
	filter := bson.D{}
	filter = append(filter, bson.E{Key: "user_id", Value: userId})
	opts := options.Find()
	var sortExpand bson.D
	sortExpand = append(sortExpand, bson.E{Key: "_id", Value: const_busi.MongodbSortDes})
	opts.SetLimit(1)
	opts.SetSort(sortExpand)

	cursor, err := coll.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "find SuperiorContentAwardDetail fail, err: %v", err)
		return nil, err
	}
	var result []*pbmgdb.SuperiorContentAwardDetail
	for cursor.Next(ctx) {
		data := &pbmgdb.SuperiorContentAwardDetail{}
		err = cursor.Decode(data)
		if err != nil {
			logger.Errorf(ctx, "get SuperiorContentAwardDetail query result fail, err: %v", err)
			return nil, err
		}
		result = append(result, data)
	}
	if len(result) <= 0 {
		return nil, nil
	}
	return result[0], nil

}

func (impl *SuperiorContentAwardDetailMgModelImpl) Count(ctx context.Context, filter bson.D, opts ...*options.CountOptions) (int64, error) {
	coll := impl.MgDB.Collection(impl.Table)
	return coll.CountDocuments(ctx, filter, opts...)
}

func (impl *SuperiorContentAwardDetailMgModelImpl) Update(ctx context.Context, filter, update any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error) {
	return impl.MgDB.Collection(impl.Table).UpdateOne(ctx, filter, update, opts...)
}

func (impl *SuperiorContentAwardDetailMgModelImpl) Aggregate(ctx context.Context, pipeline any, opts ...*options.AggregateOptions) (*mongo.Cursor, error) {
	cursor, err := impl.MgDB.Collection(impl.Table).Aggregate(ctx, pipeline, opts...)
	if err != nil {
		return nil, err
	}
	return cursor, nil
}

func (impl *SuperiorContentAwardDetailMgModelImpl) FindOne(ctx context.Context, filter any, opts ...*options.FindOneOptions) (*pbmgdb.SuperiorContentAwardDetail, error) {
	var m pbmgdb.SuperiorContentAwardDetail
	err := impl.MgDB.Collection(impl.Table).FindOne(ctx, filter, opts...).Decode(&m)
	if err != nil {
		return nil, err
	}

	return &m, err
}
