package config

import (
	"content_svr/pub/utils"
	"encoding/json"
	"flag"
	"fmt"
	ormLogger "gorm.io/gorm/logger"
	"os"
	"sort"
	"testing"
)

type MysqlConfig struct {
	Host   string             `json:"host"`
	Port   int                `json:"port"`
	User   string             `json:"user"`
	Pwd    string             `json:"pwd"`
	DBName string             `json:"db_name"`
	Level  ormLogger.LogLevel `json:"level"`
}

type RedisConfig struct {
	Addr string `json:"addr"`
	Pwd  string `json:"pwd"`
}

type MongodbConfig struct {
	URI    string `json:"uri"`
	DBName string `json:"db_name"`
}

func (m *MongodbConfig) GetURL() string {
	return m.URI
}

func (m *MongodbConfig) GetDBName() string {
	return m.DBName
}

type KafkaConfig struct {
	Addr []string `json:"addr"`
}

type SportActivityTimeConfig struct {
	Day int `json:"day"`
	//LastHour       int `json:"activity_open_hour"`
	//LastMinter     int `json:"activity_open_minter"`
	//OpenNextHour   int `json:"sport_end_hour"`
	//OpenNextMinter int `json:"activity_end_minter"`

	ActivityOpenHour   int `json:"activity_open_hour"` // 活动开始时间
	ActivityOpenMinter int `json:"activity_open_minter"`
	ActivityEndHour    int `json:"activity_end_hour"` // 活动结束时间
	ActivityEndMinter  int `json:"activity_end_minter"`
	OpenHour           int `json:"open_hour"`   // 开奖时间
	OpenMinter         int `json:"open_minter"` // 开奖时间
}
type MessageLogic struct {
	DailyFreePrivateTalkMaxNums int `json:"free_talked_max_nums"` //免费被私聊次数上线值
	TempSessionValidMinute      int `json:"temp_session_valid_minute"`
	TalkMessageValidMinute      int `json:"talk_message_valid_minute"`
}

type RealNameAuthentication struct {
	SecretId  string `json:"secret_id"`
	SecretKey string `json:"secret_key"`
}

type AdConfig struct {
	Vivo struct {
		Url          string `json:"url"`
		SrcId        string `json:"src_id"`
		AdvertiserId string `json:"advertiser_id"`
		AccessToken  string `json:"access_token"`
	} `json:"vivo"`
}

type CommentConfig struct {
	ReplyCommentOfficialAccount int64 `json:"reply_comment_official_account"`
	RedPacketOfficialAccount    int64 `json:"red_packet_official_account"`
	OfficialAccount             int64 `json:"official_account"`
}

type ContentConfig struct {
	HighContentFlowRatio      int      `json:"high_content_flow_ratio"`
	HighContentCommentNum     int      `json:"high_content_comment_num"`
	HighFilterRatio           int      `json:"high_filter_ratio"`
	NoValidCommentExposureNum int      `json:"no_valid_comment_exposure_num"`
	GuestWorkIdList           []string `json:"guest_work_id_list"`

	HighPlusContentRatio      int `json:"high_plus_content_ratio"`
	HighPlusContentPeopleNum  int `json:"high_plus_content_people_num"`
	HighPlusContentCommentNum int `json:"high_plus_content_comment_num"`
}

type RewardRules struct {
	Gte int32 `json:"gte"`
	Lt  int32 `json:"lt"`
}
type SuperiorContentConfig struct {
	ListHistoryAwardMinute   int32                `json:"get_history_award_minute"`
	TimerSettlementSecond    int32                `json:"timer_settlement_second"`
	WorkCalcValidMinute      int32                `json:"work_valid_minute"`
	RewardRules              []RewardRules        `json:"reward_rules"`
	KoLaHallOfFameConfigItem KoLaHallOfFameConfig `json:"kola_hall_of_frame"`
}

type WechatConfig struct {
	AppId                      string `json:"app_id"`
	AppSecret                  string `json:"app_secret"`
	MchID                      string `json:"mch_id"`
	MchCertificateSerialNumber string `json:"mch_certificateSerial_number"`
	MchAPIv3Key                string `json:"mch_apiv3_key"`
	PrivateKeyFile             string `json:"private_key_file"`
	PlatformCertFile           string `json:"platform_cert_file"`
	AppPayNotifyUrl            string `json:"app_pay_notify_url"`
}

type KoLaHallOfFameConfig struct {
	Award             float64 `json:"award"` // 废弃
	SettlementEndTime string  `json:"settlement_end_time"`
	Limits            int32   `json:"limits"`
	MedalExpireSecond int64   `json:"medal_expire_second"`
}
type WithdrawConfig struct {
	MinWithdrawAmount      string `json:"min_withdraw_amount"`
	MaxWithdrawAmountMonth string `json:"max_withdraw_amount_month"`
	MaxTimesOneDay         int64  `json:"max_times_one_day"`
}

type LikeConfig struct {
	LikedNumsByOtherOneDay  int64 `json:"liked_num_one_day_by_other"` //被别人点赞数
	ExpireTimeByOtherSecond int64 `json:"expire_second_by_other"`     // 点亮时间长度
	LikedNumsToOtherOneDay  int64 `json:"liked_num_one_day_to_other"` //点赞别人的点赞数
	ExpireTimeToOtherSecond int64 `json:"expire_second_to_other"`     // 点亮时间长度
}

type OpenImConfig struct {
	Secret       string `json:"secret"`
	APIUrl       string `json:"api_url"`
	ClientAPIUrl string `json:"client_api_url"`
	ClientWSUrl  string `json:"client_ws_url"`
	Admin        struct {
		AdminId  string `json:"admin_id"`
		Nickname string `json:"nickname"`
		ImAdmin  string `json:"im_admin"`
	} `json:"admin"`
	Group struct {
		GroupsMaxCreate int `json:"groups_max_create"`
		GroupMaxUser    int `json:"group_max_user"`
	} `json:"group"`
}

type GameCard struct {
	GameId            string `json:"game_id"`
	GameName          string `json:"game_name"`
	GameCardWorkId    int64  `json:"game_card_work_id"`
	GameCardUrl       string `json:"game_card_url"`
	GameCardPageNum   int    `json:"game_card_page_num"`
	GameCardIsVisible bool   `json:"game_card_is_visible"`
}

type PartnerConfig struct {
	NeedInviteNum  uint32 `json:"need_invite_num"`
	TotalRedPacket uint32 `json:"total_red_packet"`
	InviteStages   []*struct {
		NeedPeopleNum  uint32 `json:"need_people_num"`
		Reward         uint32 `json:"reward"`
		TotalPeopleNum uint32 `json:"total_people_num"`
	} `json:"invite_stages"`
	DrawingTime       uint32  `json:"drawing_time"`
	PondRate          float64 `json:"pond_rate"`
	NewUserBeforeDays uint32  `json:"new_user_before_days"`
	PondMaxAmount     uint32  `json:"pond_max_amount"`
}

type Config struct {
	IsDebug                bool                     `json:"is_debug"`
	Env                    string                   `json:"env"`
	Port                   int                      `json:"port"`
	InnerHost              string                   `json:"inner_host"`
	ImageHost              string                   `json:"image_host"`
	CheckSvrHost           string                   `json:"check_svr_host"`
	ServerHost             string                   `json:"server_host"` // 给h5拼的host
	BasicSvrTgt            string                   `json:"basic_svr_tgt"`
	KafkaConfig            *KafkaConfig             `json:"kafka_config"`
	MysqlConfig            *MysqlConfig             `json:"mysql_config"`
	MysqlConfigRead        *MysqlConfig             `json:"mysql_config_read"`
	MysqlImConfig          *MysqlConfig             `json:"mysql_im_config"`
	RedisConfig            *RedisConfig             `json:"redis_config"`
	MongodbConfig          *MongodbConfig           `json:"mongodb_config"`
	MongodbConfigRead      *MongodbConfig           `json:"mongodb_config_read"`
	SportTime              *SportActivityTimeConfig `json:"sport_time_config"`
	MessageTalkConfig      *MessageLogic            `json:"message_talk_config"`
	RealNameAuthentication *RealNameAuthentication  `json:"real_name_authentication"`
	AdConfig               *AdConfig                `json:"ad_config"`
	CommentConfig          *CommentConfig           `json:"comment_config"`
	ContentConfig          *ContentConfig           `json:"content_config"`
	SuperiorContentConfig  *SuperiorContentConfig   `json:"superior_work_content"`
	WechatConfig           *WechatConfig            `json:"wechat_config"`
	WithdrawConfig         *WithdrawConfig          `json:"withdraw_config"`
	ApiWhiteListConfig     map[string]string        `json:"api_white_list_config"`
	LikeConfig             *LikeConfig              `json:"like_config"`
	OpenImConfig           *OpenImConfig            `json:"open_im_config"`
	OfficialCardConfig     []*GameCard              `json:"official_card_config"`
	PartnerConfig          *PartnerConfig           `json:"partner_config"`
}

var (
	ServerConfig Config
)
var _ = func() bool {
	testing.Init()
	return true
}()

func init() {
	//var cfgPath string
	/*	if runtime.GOOS == "darwin" {
			// 本地调试开发使用
			// 若为macOS那么使用下列路径
			base := "../../../build/content_svr/conf/config.json"
			cfgPath, _ = filepath.Abs(base)
			fmt.Println(cfgPath)
		}
	*/
	InitConfig()
}

func InitConfig(path ...string) {
	wpath, err := utils.GetWorkPath()
	if err != nil {
		panic(fmt.Sprintf("get workpath failed. err:%v", err.Error()))
	}

	cfgPath := wpath + "/conf/config.json"
	if f, err := os.Stat(cfgPath); err != nil || f == nil {
		if len(path) > 0 && path[0] != "" {
			cfgPath = path[0]
		} else {
			flag.StringVar(&cfgPath, "e", "./conf/config.json", "config path")
			flag.Parse()
		}
	}

	fileBytes, err := os.ReadFile(cfgPath)
	if err != nil {
		panic(err)
	}
	err = json.Unmarshal(fileBytes, &ServerConfig)
	if err != nil {
		panic(err)
	}

	if ServerConfig.MysqlConfig.Level == 0 {
		ServerConfig.MysqlConfig.Level = ormLogger.Silent
	}
	if ServerConfig.SuperiorContentConfig != nil {
		sort.Slice(ServerConfig.SuperiorContentConfig.RewardRules, func(i, j int) bool {
			return ServerConfig.SuperiorContentConfig.RewardRules[i].Gte <= ServerConfig.SuperiorContentConfig.RewardRules[j].Gte
		})
	}
}

// 获取可见的游戏卡片
func GetGameCards() []*GameCard {
	cards := make([]*GameCard, 0)
	if len(ServerConfig.OfficialCardConfig) <= 0 {
		return cards
	}

	for _, v := range ServerConfig.OfficialCardConfig {
		if v.GameCardIsVisible {
			cards = append(cards, v)
		}
	}

	return cards
}

// 根据卡片的workId获取卡片
func GetGameCardByWorkId(workId int64) *GameCard {
	cards := GetGameCards()
	for _, card := range cards {
		if card.GameCardWorkId == workId {
			return card
		}
	}
	return nil
}
