package model

import (
	"go.uber.org/dig"
	"gorm.io/gorm"
)

type DBGroup struct {
	dig.Out

	DB         *gorm.DB
	ReadDB     *gorm.DB
	PareTimeDB *gorm.DB
	IMDB       *gorm.DB
}
