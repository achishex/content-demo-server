package im_mng

import (
	"content_svr/config"
	"content_svr/db/dao"
	"content_svr/db/dao/cache"
	"content_svr/db/mongodb/model"
	"content_svr/internal/im_mng/open_im_api"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/setting"
	"context"
	"fmt"
	"github.com/OpenIMSDK/protocol/group"
	"github.com/OpenIMSDK/protocol/sdkws"
	"github.com/go-redis/redis/v8"
	"strconv"
	"time"
)

func NewIMRewardComp(rcli *redis.Client,
	caller open_im_api.IOpenIMCaller,
	managerDB *dao.ManagerDB,
) *IMRewardComp {
	return &IMRewardComp{
		rcli:   rcli,
		caller: caller,
		rma:    managerDB.UserRewardMoneyActivity,
	}
}

type IMRewardComp struct {
	rcli   *redis.Client
	caller open_im_api.IOpenIMCaller
	rma    *cache.UserRewardMoneyActivity

	// TODO 分包解决循环依赖
	AwardMoneyAndNotifyFn func(ctx context.Context, content string, money float64, userId int64, itemType int32) error //由content_mng写入
}

// CreateGroupReward 建群奖励
func (c *IMRewardComp) CreateGroupReward(ctx context.Context, userID int64) error {
	ok, err := c.shouldRewardUser(ctx, userID, model.AwardGroupByCreate)
	if err != nil {
		return err
	}

	if ok {
		money := float64(setting.Maozhua.RewardCreateGroup.Get()) / 100.0
		err2 := c.AwardMoneyAndNotifyFn(ctx, "创群奖励", money, userID, model.AwardGroupByCreate)
		if err2 != nil {
			return err2
		}

		err2 = c.rma.FinishTask(ctx, userID, model.AwardGroupByCreate)
		if err2 != nil {
			return err2
		}

	}

	return nil
}

// AddActiveGroupUserAndReward 统计群用户活跃数，满足条件时发放奖励
func (c *IMRewardComp) AddActiveGroupUserAndReward(ctx context.Context, groupID, userID string) error {
	n, err := c.AddActiveGroupUser(ctx, groupID, userID)
	if err != nil {
		return err
	}

	// update task progress
	if n <= int(setting.Maozhua.RewardGroupUserActiveCount.Get()) {
		logger.Infof(ctx, "reward group user, groupID: %v", groupID)
		gi, err2 := c.getGroupInfo(ctx, groupID)
		if err2 != nil {
			logger.Errorf(ctx, "getGroupInfo fail, err: %v", err)
			return err
		}

		logger.Infof(ctx, "update AwardGroupUserByActive progress, userID: %v, scope: %v", gi.CreatorUserID, n)
		creatorUserID, err2 := strconv.ParseInt(gi.CreatorUserID, 10, 64)
		if err2 != nil {
			logger.Errorf(ctx, "malformed userID: %v", gi.CreatorUserID)
			return err2
		}

		err2 = c.rma.UpdateTaskProgress(ctx, creatorUserID, model.AwardGroupUserByActive, uint64(n), setting.Maozhua.RewardGroupUserActiveCount.Get())
		if err2 != nil {
			logger.Errorf(ctx, "UpdateTaskProgress fail userID: %v, err: %v", gi.CreatorUserID, err)
			return err2
		}

		// reward
		if n == int(setting.Maozhua.RewardGroupUserActiveCount.Get()) {
			logger.Infof(ctx, "reward AwardGroupUserByActive, userID: %v", creatorUserID)
			ok, err2 := c.shouldRewardUser(ctx, creatorUserID, model.AwardGroupUserByActive)
			if err2 != nil {
				return err2
			}

			if ok {
				// 奖励
				money := float64(setting.Maozhua.RewardGroupUserActive.Get()) / float64(100)
				err3 := c.AwardMoneyAndNotifyFn(ctx, "群活跃奖励", money, creatorUserID, model.AwardGroupUserByActive)
				if err3 != nil {
					logger.Errorf(ctx, "AwardMoneyAndNotify fail, err: %v", err)
					return err3
				}
				return nil
			}
		}

	}

	return nil
}

// shouldRewardUser 判断是否奖励
func (c *IMRewardComp) shouldRewardUser(ctx context.Context, userID int64, rewardType int32) (bool, error) {

	if rewardType == model.AwardGroupUserByActive {
		// 按天去重
		dateStr := time.Now().Local().Format("20060102")
		key := fmt.Sprintf("platform:%v:reward:im:user:%v:type:%v:%v", config.ServerConfig.Env, userID, rewardType, dateStr)
		ok, err := c.rcli.SetNX(ctx, key, "1", time.Hour*24).Result()
		return ok, err
	}

	if rewardType == model.AwardGroupByCreate {
		//用户只奖励一次
		n, err := c.rma.Count(ctx, map[string]interface{}{"user_id": userID, "type": rewardType})
		if err != nil {
			return false, err
		}
		return n < 1, nil
	}

	return false, nil
}

func (c *IMRewardComp) getGroupInfo(ctx context.Context, groupID string) (*sdkws.GroupInfo, error) {
	ctx = context.WithValue(ctx, open_im_api.CtxApiToken, open_im_api.GetAdminToken())
	resp, err := c.caller.FindGroupInfo(ctx, &group.GetGroupsInfoReq{GroupIDs: []string{groupID}})
	if err != nil {
		return nil, err
	}

	if len(resp.GroupInfos) == 0 {
		return nil, errors.New("not found")
	}

	return resp.GroupInfos[0], nil
}

// AddActiveGroupUser 统计群用户活跃数，返回群组总活跃人数
func (c *IMRewardComp) AddActiveGroupUser(ctx context.Context, groupID, userID string) (int, error) {
	script := `-- luaSaddAndReturnSCard
redis.call('SADD', KEYS[1], ARGV[1])
return redis.call('SCARD', KEYS[1])`

	dateStr := time.Now().Local().Format("20060102")
	key := fmt.Sprintf("platform:%v:active:im:group:%v:%v", config.ServerConfig.Env, groupID, dateStr)

	n, err := c.rcli.Eval(ctx, script, []string{key}, []string{userID}).Int()
	if err != nil {
		return 0, err
	}

	c.rcli.Expire(ctx, key, time.Hour*24)
	return n, nil
}
