package wechat_proxy

import (
	"content_svr/pub/logger"
	"context"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments/app"
	"time"
)

func NewPayProxyMock(payType int32) IPayProxy {
	switch payType {
	case MockPayTypeWeChat:
		return getWechatPayMock()
	}
	return nil
}
func getWechatPayMock() IPayProxy {
	return &WechatPayMock{}
}

type WechatPayMock struct {
}

func (p *WechatPayMock) Transfer(ctx context.Context, req *WeChatPayReq) (*WeChatPayResponse, error) {
	logger.Infof(ctx, "run mock transfer to wechat, req: %v", req.OutBatchNo)

	curStatus := TransStatusAccept
	//curUserId, ok := ctx.Value("curUserId").(int64)
	//if ok && curUserId == 4402386821777408 {
	//	curStatus = TransStatusClosed
	//}
	//

	nowTime := time.Now()
	return &WeChatPayResponse{
		CreateTime:  &nowTime,
		BatchStatus: curStatus,
		OutBatchNo:  req.OutBatchNo,
	}, nil
}
func (p *WechatPayMock) QueryTransferBatchInfo(ctx context.Context, req *BatchQueryByMchIdReq) (*BatchQueryByMchIdResp, error) {
	return p.querySucc(ctx, req)
}

func (p *WechatPayMock) querySucc(ctx context.Context, req *BatchQueryByMchIdReq) (*BatchQueryByMchIdResp, error) {
	nowTime := time.Now()
	details := []TransferDetailItem{
		{
			DetailId:     "succ_query_111",
			OutDetailNo:  req.OutBatchNo,
			DetailStatus: DetailStatusSucc,
		},
	}
	//
	//userId, ok := ctx.Value("testUserId").(int64)
	//if ok && userId == 4402386821777408 {
	//	details[0].DetailStatus = DetailStatusFAIL
	//}

	ret := &BatchQueryByMchIdResp{
		MchId:           "11111",             // 微信支付分配的商户号
		OutBatchNo:      req.OutBatchNo,      // 商户系统内部的商家批次单号，在商户系统内部唯一
		BatchId:         "22222",             // 微信批次单号，微信商家转账系统返回的唯一标识
		AppId:           "33333",             // 申请商户号的appid或商户号绑定的appid（企业号corpid即为此appid）
		BatchStatus:     TransStatusFinished, // WAIT_PAY: 待付款确认。需要付款出资商户在商家助手小程序或服务商助手小程序进行付款确认 ACCEPTED:已受理。批次已受理成功，若发起批量转账的30分钟后，转账批次单仍处于该状态，可能原因是商户账户余额不足等。商户可查询账户资金流水，若该笔转账批次单的扣款已经发生，则表示批次已经进入转账中，请再次查单确认 PROCESSING:转账中。已开始处理批次内的转账明细单 FINISHED:已完成。批次内的所有转账明细单都已处理完成 CLOSED:已关闭。可查询具体的批次关闭原因确认
		BatchType:       "API",               // API:API方式发起   WEB:页面方式发起
		BatchName:       "abc",               //该笔批量转账的名称
		BatchRemark:     "abc1",              // 转账说明，UTF8编码，最多允许32个字符
		CloseReason:     "no",                // 如果批次单状态为“CLOSED”（已关闭），则有关闭原因
		TotalAmount:     100,                 // 转账金额单位为“分”
		TotalNum:        1,                   // 一个转账批次单最多发起三千笔转账
		CreateTime:      &nowTime,            // 批次受理成功时返回，按照使用rfc3339所定义的格式，格式为YYYY-MM-DDThh:mm:ss+TIMEZONE
		UpdateTime:      &nowTime,            // 批次最近一次状态变更的时间，按照使用rfc3339所定义的格式，格式为YYYY-MM-DDThh:mm:ss+TIMEZONE
		SuccessAmount:   100,                 // 转账成功的金额，单位为“分”。当批次状态为“PROCESSING”（转账中）时，转账成功金额随时可能变化
		SuccessNum:      1,                   // 转账成功的笔数。当批次状态为“PROCESSING”（转账中）时，转账成功笔数随时可能变化
		FailAmount:      0,                   // 转账失败的金额，单位为“分”
		FailNum:         0,                   // 转账失败的笔数
		TransferSceneId: "abc",               // 指定的转账场景ID
		TransferDetails: details,             // 当批次状态为“FINISHED”（已完成），且成功查询到转账明细单时返回。包括微信明细单号、明细状态信息
	}
	return ret, nil
}

func (p *WechatPayMock) queryFail(ctx context.Context, req *BatchQueryByMchIdReq) (*BatchQueryByMchIdResp, error) {
	nowTime := time.Now()
	details := []TransferDetailItem{
		{
			DetailId:     "fail_query_111",
			OutDetailNo:  req.OutBatchNo,
			DetailStatus: DetailStatusFAIL,
		},
	}
	ret := &BatchQueryByMchIdResp{
		MchId:           "11111",             // 微信支付分配的商户号
		OutBatchNo:      req.OutBatchNo,      // 商户系统内部的商家批次单号，在商户系统内部唯一
		BatchId:         "22222",             // 微信批次单号，微信商家转账系统返回的唯一标识
		AppId:           "33333",             // 申请商户号的appid或商户号绑定的appid（企业号corpid即为此appid）
		BatchStatus:     TransStatusFinished, // WAIT_PAY: 待付款确认。需要付款出资商户在商家助手小程序或服务商助手小程序进行付款确认 ACCEPTED:已受理。批次已受理成功，若发起批量转账的30分钟后，转账批次单仍处于该状态，可能原因是商户账户余额不足等。商户可查询账户资金流水，若该笔转账批次单的扣款已经发生，则表示批次已经进入转账中，请再次查单确认 PROCESSING:转账中。已开始处理批次内的转账明细单 FINISHED:已完成。批次内的所有转账明细单都已处理完成 CLOSED:已关闭。可查询具体的批次关闭原因确认
		BatchType:       "API",               // API:API方式发起   WEB:页面方式发起
		BatchName:       "abc",               //该笔批量转账的名称
		BatchRemark:     "abc1",              // 转账说明，UTF8编码，最多允许32个字符
		CloseReason:     "no",                // 如果批次单状态为“CLOSED”（已关闭），则有关闭原因
		TotalAmount:     100,                 // 转账金额单位为“分”
		TotalNum:        1,                   // 一个转账批次单最多发起三千笔转账
		CreateTime:      &nowTime,            // 批次受理成功时返回，按照使用rfc3339所定义的格式，格式为YYYY-MM-DDThh:mm:ss+TIMEZONE
		UpdateTime:      &nowTime,            // 批次最近一次状态变更的时间，按照使用rfc3339所定义的格式，格式为YYYY-MM-DDThh:mm:ss+TIMEZONE
		SuccessAmount:   100,                 // 转账成功的金额，单位为“分”。当批次状态为“PROCESSING”（转账中）时，转账成功金额随时可能变化
		SuccessNum:      1,                   // 转账成功的笔数。当批次状态为“PROCESSING”（转账中）时，转账成功笔数随时可能变化
		FailAmount:      0,                   // 转账失败的金额，单位为“分”
		FailNum:         0,                   // 转账失败的笔数
		TransferSceneId: "abc",               // 指定的转账场景ID
		TransferDetails: details,             // 当批次状态为“FINISHED”（已完成），且成功查询到转账明细单时返回。包括微信明细单号、明细状态信息
	}
	return ret, nil
}

func (p *WechatPayMock) queryAccept(ctx context.Context, req *BatchQueryByMchIdReq) (*BatchQueryByMchIdResp, error) {
	nowTime := time.Now()
	ret := &BatchQueryByMchIdResp{
		MchId:           "11111",           // 微信支付分配的商户号
		OutBatchNo:      req.OutBatchNo,    // 商户系统内部的商家批次单号，在商户系统内部唯一
		BatchId:         "22222",           // 微信批次单号，微信商家转账系统返回的唯一标识
		AppId:           "33333",           // 申请商户号的appid或商户号绑定的appid（企业号corpid即为此appid）
		BatchStatus:     TransStatusAccept, // WAIT_PAY: 待付款确认。需要付款出资商户在商家助手小程序或服务商助手小程序进行付款确认 ACCEPTED:已受理。批次已受理成功，若发起批量转账的30分钟后，转账批次单仍处于该状态，可能原因是商户账户余额不足等。商户可查询账户资金流水，若该笔转账批次单的扣款已经发生，则表示批次已经进入转账中，请再次查单确认 PROCESSING:转账中。已开始处理批次内的转账明细单 FINISHED:已完成。批次内的所有转账明细单都已处理完成 CLOSED:已关闭。可查询具体的批次关闭原因确认
		BatchType:       "API",             // API:API方式发起   WEB:页面方式发起
		BatchName:       "abc",             //该笔批量转账的名称
		BatchRemark:     "abc1",            // 转账说明，UTF8编码，最多允许32个字符
		CloseReason:     "no",              // 如果批次单状态为“CLOSED”（已关闭），则有关闭原因
		TotalAmount:     100,               // 转账金额单位为“分”
		TotalNum:        1,                 // 一个转账批次单最多发起三千笔转账
		CreateTime:      &nowTime,          // 批次受理成功时返回，按照使用rfc3339所定义的格式，格式为YYYY-MM-DDThh:mm:ss+TIMEZONE
		UpdateTime:      &nowTime,          // 批次最近一次状态变更的时间，按照使用rfc3339所定义的格式，格式为YYYY-MM-DDThh:mm:ss+TIMEZONE
		SuccessAmount:   100,               // 转账成功的金额，单位为“分”。当批次状态为“PROCESSING”（转账中）时，转账成功金额随时可能变化
		SuccessNum:      1,                 // 转账成功的笔数。当批次状态为“PROCESSING”（转账中）时，转账成功笔数随时可能变化
		FailAmount:      0,                 // 转账失败的金额，单位为“分”
		FailNum:         0,                 // 转账失败的笔数
		TransferSceneId: "abc",             // 指定的转账场景ID
		//TransferDetails: details,             // 当批次状态为“FINISHED”（已完成），且成功查询到转账明细单时返回。包括微信明细单号、明细状态信息
	}
	return ret, nil
}

func (p *WechatPayMock) AppPrepay(ctx context.Context, req *app.PrepayRequest) (*app.PrepayResponse, error) {
	panic("implement me")
}

func (p *WechatPayMock) QueryOrderById(ctx context.Context, req app.QueryOrderByIdRequest) (resp *payments.Transaction, err error) {
	panic("implement me")
}

func (p *WechatPayMock) QueryOrderByOutTradeNo(ctx context.Context, req app.QueryOrderByOutTradeNoRequest) (resp *payments.Transaction, err error) {
	panic("implement me")
}
