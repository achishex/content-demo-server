package model

import (
	"content_svr/db/redisdb/model/internal"
	"github.com/go-redis/redis/v8"
	"time"
)

type TokenRedis struct {
	TokenAdmin      *TokenAdminRedis
	TokenContentSvr *TokenContentSvrRedis
}

func NewToken(rds *redis.Client, env string) *TokenRedis {
	return &TokenRedis{
		TokenAdmin: &TokenAdminRedis{
			RdsInfo: internal.RdsInfo{
				Env:    env,
				Expire: time.Hour * 24 * 7,
				Client: rds,
			},
		},
		TokenContentSvr: &TokenContentSvrRedis{
			RdsInfo: internal.RdsInfo{
				Env:    env,
				Expire: time.Hour * 24,
				Client: rds,
			},
		},
	}
}
