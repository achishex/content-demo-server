package dau

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/db/mongodb/model"
	"context"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"sort"
)

type ListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ListLogic {
	return &ListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ListLogic) List(req *types.DauListReq) (resp *types.DauListResp, err error) {
	dauRespItemList := make([]types.DauRespItem, 0)
	filter, key := GetUserActivityFilter(req.UserActivityFilter)

	channelList, err := l.svcCtx.ReadDB.SecretUserChannelDaily.FindAll(l.ctx, filter)
	if err != nil {
		return nil, err
	}
	targetChannelMap := map[string]model.SecretUserChannelDaily{}
	for _, channelDaily := range channelList {
		uniqueKey := fmt.Sprintf(key, channelDaily.Day)
		item, ok := targetChannelMap[uniqueKey]
		if ok {
			item.ActiveUserCount += channelDaily.ActiveUserCount
			item.ActiveTargetUserCount += channelDaily.ActiveTargetUserCount
			item.NewUserCount += channelDaily.NewUserCount
			item.NewTargetUserCount += channelDaily.NewTargetUserCount
		} else {
			item = channelDaily
		}

		targetChannelMap[uniqueKey] = item
	}

	channelDaily, err := l.svcCtx.SumManage.TodayUserActivity(l.ctx, filter, req.TimeEnd)
	if err != nil {
		return nil, err
	}
	if channelDaily != nil {
		uniqueKey := fmt.Sprintf(key, req.TimeEnd)
		targetChannelMap[uniqueKey] = *channelDaily
	}

	targetChannel := make([]model.SecretUserChannelDaily, 0)
	for _, daily := range targetChannelMap {
		targetChannel = append(targetChannel, daily)
	}

	sort.Slice(targetChannel, func(i, j int) bool {
		return targetChannel[i].Day < targetChannel[j].Day
	})

	for _, daily := range targetChannel {
		item := types.DauRespItem{
			Date:                  daily.Day,
			ActiveUserCount:       daily.ActiveUserCount,
			ActiveTargetUserCount: daily.ActiveTargetUserCount,
			NewUserCount:          daily.NewUserCount,
			NewTargetUserCount:    daily.NewTargetUserCount,
		}

		dauRespItemList = append(dauRespItemList, item)
	}

	resp = &types.DauListResp{
		List: dauRespItemList,
	}

	return
}
