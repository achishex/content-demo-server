package model

import (
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbdb"
	"content_svr/pub/errors"
	"context"
	"encoding/json"
	"github.com/gogo/protobuf/proto"
	"gorm.io/gorm"
	"gorm.io/plugin/dbresolver"
)

// OperatorTab
// OperatorTab

type IOperatorTabDbModel interface {
	ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page int32, size int32) ([]*pbdb.OperatorTabDbModel, error)
	CreateOrUpdate(ctx context.Context, model *pbdb.OperatorTabDbModel) (*pbdb.OperatorTabDbModel, error)
	Get(ctx context.Context, opId int64) (*pbdb.OperatorTabDbModel, error)
	GetByEmail(ctx context.Context, email string) (*pbdb.OperatorTabDbModel, error)
	ListItemByIds(ctx context.Context, opIds []int64) ([]*pbdb.OperatorTabDbModel, error)
	UpdateItem(ctx context.Context, model *pbdb.OperatorTabDbModel) (*pbdb.OperatorTabDbModel, error)
	CreateItem(ctx context.Context, model *pbdb.OperatorTabDbModel) (*pbdb.OperatorTabDbModel, error)
	CountItemsByCondition(ctx context.Context, condition map[string]interface{}) (total int64, _ error)
}

type OperatorTabDbModelImpl struct {
	DB *gorm.DB
}

func NewOperatorTabDbModelImpl(db *gorm.DB) IOperatorTabDbModel {
	return &OperatorTabDbModelImpl{DB: db}
}

func (impl *OperatorTabDbModelImpl) table() string {
	return "operator_tab"
}

func (impl *OperatorTabDbModelImpl) Get(ctx context.Context, opId int64) (*pbdb.OperatorTabDbModel, error) {
	model := pbdb.OperatorTabDbModel{}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Clauses(dbresolver.Write).
		Where("op_id = ?", opId).First(&model)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &model, errors.Wrap(result.Error)
}

func (impl *OperatorTabDbModelImpl) GetByEmail(ctx context.Context, email string) (*pbdb.OperatorTabDbModel, error) {
	model := pbdb.OperatorTabDbModel{}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Clauses(dbresolver.Write).
		Where("email = ?", email).First(&model)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &model, errors.Wrap(result.Error)
}

func (impl *OperatorTabDbModelImpl) ListItemByIds(ctx context.Context, opIds []int64) ([]*pbdb.OperatorTabDbModel, error) {
	var items []*pbdb.OperatorTabDbModel
	if len(opIds) == 0 {
		return items, nil
	}
	result := impl.DB.WithContext(ctx).Table(impl.table()).
		Where("accountid in ", opIds).Order("opIds desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *OperatorTabDbModelImpl) CreateOrUpdate(ctx context.Context, model *pbdb.OperatorTabDbModel) (*pbdb.OperatorTabDbModel, error) {
	item, err := impl.Get(ctx, model.GetOpId())
	if err != nil {
		return nil, err
	}
	if item == nil {
		// CREATE
		item, err = impl.CreateItem(ctx, model)
	} else {
		// UPDATE
		item.Status = proto.Int32(int32(pbconst.BaseTabStatus_valid))
		item.Pwd = model.Pwd
		item, err = impl.UpdateItem(ctx, item)
		if err != nil {
			return nil, err
		}
	}
	return item, err
}

func (impl *OperatorTabDbModelImpl) UpdateItem(ctx context.Context, model *pbdb.OperatorTabDbModel) (*pbdb.OperatorTabDbModel, error) {
	modelDict := make(map[string]interface{})
	modelByte, err := json.Marshal(model)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(modelByte, &modelDict)
	if err != nil {
		return nil, err
	}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Where("op_id = ?", model.GetOpId()).Updates(modelDict)
	return model, errors.Wrap(result.Error)
}

func (impl *OperatorTabDbModelImpl) CreateItem(ctx context.Context, model *pbdb.OperatorTabDbModel) (*pbdb.OperatorTabDbModel, error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Create(model)
	return model, errors.Wrap(result.Error)
}

// offset 开始查的默认值为0
func (impl *OperatorTabDbModelImpl) ListItemOffset(ctx context.Context, condition map[string]interface{}, page int, size int) ([]*pbdb.OperatorTabDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.OperatorTabDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(size).Offset(offset).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}

	return items, errors.Wrap(result.Error)
}

func (impl *OperatorTabDbModelImpl) ListItemsByCondition(ctx context.Context,
	condition map[string]interface{}, page, size int32) ([]*pbdb.OperatorTabDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.OperatorTabDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(int(size)).Offset(int(offset)).
		Where(condition).Order("op_id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *OperatorTabDbModelImpl) CountItemsByCondition(ctx context.Context,
	condition map[string]interface{}) (total int64, _ error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Model(&pbdb.OperatorTabDbModel{}).Where(condition).Count(&total)
	return total, errors.Wrap(result.Error)
}

//func (impl *OperatorTabDbModelImpl) UpdateItemsByCondition(ctx context.Context, condition, changes map[string]interface{}) error {
//	result := impl.DB.WithContext(ctx).Table(impl.table()).Where(condition).Updates(changes)
//
//	return errors.Wrap(result.Error)
//}
//
