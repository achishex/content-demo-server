package data_cache

import (
	"content_svr/internal/busi_comm/constant/var_busi"
	"context"
	"strconv"
)

func (p *DataCacheMng) LoadSuperiorContentAwardSetting(ctx context.Context) error {
	redisKey := getRdsKeyTimesConfig("superior_content_award")
	result, err := p.RedisCli.HGetAll(ctx, redisKey).Result()
	if err != nil {
		return err
	}

	for k, v := range result {
		switch k {
		case "first_work_score":
			value, err := strconv.ParseFloat(v, 10)
			if err != nil {
				return err
			}
			var_busi.AwardFirstWork = value
		}
	}

	return nil
}
