package model

type SuperiorAwardDaily struct {
	Day                          int64 `json:"day" bson:"day"`                                                             // 时间戳
	AwardSettlementSum           int   `json:"award_settlement_sum" bson:"award_settlement_sum"`                           // 当天结算奖励总和
	DeductionIllegalSum          int   `json:"deduction_illegal_sum" bson:"deduction_illegal_sum"`                         // 当天违规扣除总和
	FirstWorkSettlementSum       int   `json:"first_work_settlement_sum" bson:"first_work_settlement_sum"`                 // 当天首条动态奖励总和
	WechatPayWithdrawSuccessSum  int   `json:"wechat_pay_withdraw_success_sum" bson:"wechat_pay_withdraw_success_sum"`     // 当天微信提现成功总和
	WechatPayWithdrawFailSum     int   `json:"wechat_pay_withdraw_fail_sum" bson:"wechat_pay_withdraw_fail_sum"`           // 当天微信提现失败总和
	HallOfFameAwardSettlementSum int   `json:"hall_of_fame_award_settlement_sum" bson:"hall_of_fame_award_settlement_sum"` // 当天排行榜奖励总和

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` // 创建时间
}
