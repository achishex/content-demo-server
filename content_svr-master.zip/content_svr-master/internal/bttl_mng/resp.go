package bttl_mng

type DiscoverResp struct {
	Data          []BttlLiteDTO `json:"data"`
	Size          int           `json:"size"`
	PickChance    int           `json:"pickChance"`
	NextPageToken string        `json:"nextPageToken"` //翻页
}
type PickResp struct {
	PickChance int64 `json:"pickChance"`
}

type ThrowbackResp struct{}

type ReplyResp struct {
	Jump string `json:"jump"`
}

// BttlEx 瓶子扩展信息
type BttlEx struct {
	Nickname string   `json:"nickname"`
	FaceURL  string   `json:"faceURL"`
	Tags     []string `json:"tags"`
}
type BttlLiteDTO struct {
	BttlEx

	BttlID     int64  `json:"bttlID"`
	UserID     int64  `json:"userID"`
	Gender     int    `json:"gender"`
	Content    string `json:"content"`
	City       string `json:"city"`
	CreateTime int64  `json:"createTime"`
}

type BttlDTO struct {
	BttlEx

	BttlID     int64  `json:"bttlID"`
	UserID     int64  `json:"userID"`
	Gender     int    `json:"gender"`
	Content    string `json:"content"`
	City       string `json:"city"`
	Replier    int64  `json:"replier"`
	CreateTime int64  `json:"createTime"`
	ReplyTime  int64  `json:"replyTime"`
}

type BttlJumpDTO struct {
	BttlDTO

	ReplierNickname string `json:"replierNickname"`
	ReplierFaceURL  string `json:"replierFaceURL"`
	Jump            string `json:"jump"`
}
type ListBttlResp struct {
	Data []BttlJumpDTO `json:"data"`
}

type PickADUploadResp struct {
	PickChance int64 `json:"pickChance"`
}

type BttlStatusResp struct {
	PickChance       int64 `json:"pickChance"`
	MaxPickChance    int64 `json:"maxPickChance"`
	CreateChance     int64 `json:"createChance"`
	CreateDailyLimit int64 `json:"createDailyLimit"`
}
