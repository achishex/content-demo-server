package utils

import (
	"time"
)

// Try 执行`do()`，失败休眠`dur`，重试执行`n`次。
func Try(n int, dur time.Duration, do func() error) error {
	if n <= 0 {
		return nil
	}

	var err error
	if err = do(); err == nil {
		return nil
	}

	for i := 1; i < n; i++ {
		time.Sleep(dur)
		if err = do(); err == nil {
			break
		}
	}
	return err
}
