package robot

import (
	"context"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type ListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ListLogic {
	return &ListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ListLogic) List(req *types.RobotListReq) (resp *types.RobotListResp, err error) {
	robots, total, err := l.svcCtx.ManagerDB.MzRobotMng.FindPage(l.ctx, req)
	if err != nil {
		return nil, err
	}

	// 若已经超过生效时间
	now := time.Now().UnixMilli()
	for _, robot := range robots {
		if now >= robot.TimePartEnd {
			robot.Status = false
		}
	}

	resp = &types.RobotListResp{
		Total: total,
		List:  robots,
	}

	return
}
