package content_mng

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"encoding/json"
	"github.com/go-resty/resty/v2"
	"net/url"
)

func (p *ContentMng) setCallbackData(ctx context.Context, channel, data string, machineIds ...string) {
	for _, machineId := range machineIds {
		if machineId == "" {
			continue
		}
		_ = p.DataCache.GetImpl().SetRedisAdCallback(ctx, channel, machineId, data)
	}
}

func (p *ContentMng) getCallbackData(ctx context.Context, channel string, machineIds ...string) string {
	for _, machineId := range machineIds {
		if machineId == "" {
			continue
		}
		data := p.DataCache.GetImpl().GetRedisAdCallback(ctx, channel, machineId)
		if len(data) != 0 {
			return data
		}
	}

	return ""
}

func adXiaomiCallback(ctx context.Context, req *pbapi.AdXiaomiFeedbackReq) (*pbapi.AdXiaomiFeedbackResp, error) {
	resp := &pbapi.AdXiaomiFeedbackResp{Code: 0, FailMsg: "", Success: true}
	urlString := "http://trail.e.mi.com/api/callback"

	callbackParam := req.Callback
	imei := req.Imei
	oaid := req.Oaid
	convTime := req.ClickTime
	convType := req.GetConvType()

	// 构建请求链接
	u, err := url.Parse(urlString)
	if err != nil {
		logger.Error(ctx, "url.Parse", err)
		return nil, err
	}
	query := u.Query()
	query.Set("callback", callbackParam)
	query.Set("imei", imei)
	query.Set("oaid", oaid)
	query.Set("conv_time", convTime)
	query.Set("convType", convType)
	u.RawQuery = query.Encode()

	client := resty.New()
	r, err := client.R().Get(u.String())
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return nil, err
	}
	logger.Infof(ctx, "imei: %s oaid: %s xiaomi behavior request:%v", req.Imei, req.Oaid, u.String())
	logger.Infof(ctx, "xiaomi behavior response:%v", r.String())

	if err := json.Unmarshal(r.Body(), resp); err != nil {
		return nil, err
	}

	return resp, nil
}

func adBaiduCallback(ctx context.Context, req *pbapi.AdBaiduFeedbackReq) error {
	// http://ocpc.baidu.com/ocpcapi/cb/actionCb?a_type=activate&a_value=0&sign=04fcaae4357851ff0ebc574e733d33dd

	aKey := "NTEzODU2ODk="

	sign := utils.MD5(req.GetCallbackUrl() + aKey)

	// 构建请求链接
	u, err := url.Parse(req.GetCallbackUrl())
	if err != nil {
		logger.Error(ctx, "url.Parse", err)
		return err
	}
	query := u.Query()
	query.Set("a_type", req.AType)
	query.Set("a_value", "0")
	query.Set("sign", sign)
	query.Set("join_type", req.JoinType)
	u.RawQuery = query.Encode()

	client := resty.New()
	r, err := client.R().Get(u.String())
	if err != nil {
		logger.Errorf(ctx, "baidu http error:", err)
		return err
	}

	logger.Infof(ctx, "baidu behavior url: %s response:%v", u.String(), r.String())

	return nil
}

func adToutiaoCallback(ctx context.Context, req *pbapi.AdToutiaoFeedbackReq) error {
	urlString := `https://analytics.oceanengine.com/api/v2/conversion`

	body := map[string]interface{}{
		"event_type": req.GetEventType(),
		"context": map[string]interface{}{
			"ad": map[string]interface{}{
				"callback": req.GetCallback(), //callback 这里需要填写的就是从启动参数里获取的 clickid
			},
		},
	}

	client := resty.New()
	r, err := client.R().SetBody(body).Post(urlString)
	if err != nil {
		logger.Errorf(ctx, "baidu http error:", err)
		return err
	}

	type response struct {
		Code    int    `json:"code"`
		Message string `json:"message"`
	}
	resp := response{}
	if err := json.Unmarshal(r.Body(), &resp); err != nil {
		return err
	}
	if resp.Code != 0 {
		logger.Infof(ctx, "toutiao behavior error: %v", r.String())
		return errors.New(resp.Message)
	}

	logger.Infof(ctx, "toutiao behavior response: %v", r.String())

	return nil
}
