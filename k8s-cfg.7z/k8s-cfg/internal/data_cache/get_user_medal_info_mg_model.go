package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	"time"
)

func (p *DataCacheMng) GetUserMedalInfoMgDBLd(ctx context.Context, userId int64, bSkipCache bool) []*pbapi.SecretMedalInfoResponse {
	respRecords := make([]*pbapi.SecretMedalInfoResponse, 0)
	cacheKey := fmt.Sprintf(cache_const.MedalInfoLcache.KeyFmt, userId)
	expire := cache_const.MedalInfoLcache.Expire

	//从内存取
	if bSkipCache == false {
		cResp, exist := p.LocalCache.Get(cacheKey)
		if exist {
			resp, ok := cResp.([]*pbapi.SecretMedalInfoResponse)
			if ok && resp != nil {
				return resp
			}
		}
	}

	//从mg db取. 所有medals信息
	mgItems, err := p.UserMedalMgModel.ListByUserId(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get UserMedalInfo failed. userId=%v, err=%v", userId, err.Error())
		return nil
	}
	medalIds := make([]int64, 0)
	for _, mgItem := range mgItems {
		medalIds = append(medalIds, mgItem.GetMedalId())
	}
	//if len(medalIds) == 0 {
	//	return nil
	//}

	// medalDict
	medalDict, err := p.MedalMgModel.DictByIds(ctx, medalIds)
	if err != nil {
		logger.Error(ctx, "get UserMedalInfo DictByIds err", err)
		return nil
	}

	for _, mgItem := range mgItems {
		if utils.GetCurTsMs() > mgItem.GetExpire() {
			continue
		}
		medalinfo := medalDict[mgItem.GetMedalId()]
		if medalinfo == nil {
			continue
		}

		userMedalInfo := &pbapi.SecretMedalInfoResponse{
			MedalId:   mgItem.GetMedalId(),
			MedalName: medalinfo.GetMedalName(),
			Icon:      medalinfo.GetIcon(),
			Expire:    mgItem.GetExpire(),
			Timestamp: mgItem.GetTimestamp(),
			SmallIcon: medalinfo.GetSmallIcon(),
		}
		respRecords = append(respRecords, userMedalInfo)
	}

	if bSkipCache == false {
		bSuc := p.LocalCache.Set(cacheKey, respRecords, go_cache.WithEx(time.Duration(expire)*time.Second))
		logger.Infof(ctx, "save UserMedalInfo to local cache. userId=%v,val=%v, bSuc=%v", userId, respRecords, bSuc)
	}
	return respRecords
}
