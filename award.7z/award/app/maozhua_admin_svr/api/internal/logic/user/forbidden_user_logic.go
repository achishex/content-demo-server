package user

import (
	"content_svr/db/m_const"
	"content_svr/pub/errors"
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type ForbiddenUserLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewForbiddenUserLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ForbiddenUserLogic {
	return &ForbiddenUserLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ForbiddenUserLogic) ForbiddenUser(req *types.ForBiddenReq) (resp *types.ForBiddenResp, err error) {
	_db := l.svcCtx.ManagerDB.UserInfo

	userInfo, err := _db.FindByUserId(l.ctx, req.UserId)
	if err != nil {
		return nil, err
	}
	var enable int32 = 0
	if userInfo.Enabled == m_const.UserForbidden && req.Forbidden == m_const.UserOpen {
		enable = m_const.UserOpen
	} else if userInfo.Enabled == m_const.UserOpen && req.Forbidden == m_const.UserForbidden {
		enable = m_const.UserForbidden
	}

	if enable == 0 {
		return nil, &errors.Error{UserErrCode: 207, UserMsg: "数据无效"}
	}

	filter := map[string]interface{}{
		"user_id": req.UserId,
	}
	data := map[string]interface{}{
		"enabled": enable,
	}
	_, err = _db.Update(l.ctx, filter, data)
	if err != nil {
		return nil, err
	}

	err = _db.ClearUserInfoRedisCache(l.ctx, req.UserId)
	err = _db.ClearUserTokenRedisCache(l.ctx, req.UserId)

	return
}
