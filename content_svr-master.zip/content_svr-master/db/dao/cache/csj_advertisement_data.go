package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type CsjAdvertisementData struct {
	model.CsjAdvertisementDataModel
	redisManage *query_rds.Manage
}

func NewCacheCsjAdvertisementData(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *CsjAdvertisementData {
	return &CsjAdvertisementData{
		CsjAdvertisementDataModel: mongo.CsjAdvertisementData,
		redisManage:               redisManage,
	}
}
