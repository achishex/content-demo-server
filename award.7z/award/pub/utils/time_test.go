package utils

import (
	"testing"
	"time"
)

func TestCalcTime(t *testing.T) {
	now := time.Now()

	afterTime := CalcTime(now, -2)

	t.Log(afterTime.After(now))  //  相当于 大于
	t.Log(afterTime.Before(now)) //  相当于 小于

}
