package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
	"content_svr/pub/snow_flake"
	"context"
	"go.mongodb.org/mongo-driver/mongo"
)

type SecretBlackHouse struct {
	model.SecretBlackHouseModel
	redisManage *query_rds.Manage
}

func NewCacheSecretBlackHouse(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *SecretBlackHouse {
	return &SecretBlackHouse{
		SecretBlackHouseModel: mongo.SecretBlackHouse,
		redisManage:           redisManage,
	}
}

func (s *SecretBlackHouse) Insert(ctx context.Context, data *model.SecretBlackHouse) (*mongo.InsertOneResult, error) {
	defer s.redisManage.UserInfo.SetUserBlackHouse(ctx, data.UserId, data.End)

	data.ID = snow_flake.GetSnowflakeID()
	return s.SecretBlackHouseModel.Insert(ctx, data)
}
