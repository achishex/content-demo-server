package di

import (
	"content_svr/app/content_svr/handler"
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/internal/game_mng"
	"content_svr/internal/im_mng"
	"content_svr/internal/im_mng/open_im_api"
	"content_svr/internal/inner_mng"
	"content_svr/internal/mg_model"
	"content_svr/internal/model"
	"content_svr/internal/model/im"
	"content_svr/internal/pay_mng"
	"content_svr/internal/security_mng"
	"content_svr/internal/thirdparty/baidu_lbs_yun_proxy"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/internal/thirdparty/wechat_proxy"
	"content_svr/internal/user_center_mng"
	"content_svr/internal/user_level_mng"
	"content_svr/pub/router"
	go_cache "github.com/fanjindong/go-cache"
	"go.uber.org/dig"
)

// NewContainer 测试和线上环境
func NewContainer() *dig.Container {
	c := dig.New()
	c.Provide(NewRdsClientByConf)
	c.Provide(NewPlatformAndIMDB)
	c.Provide(go_cache.NewMemCache)
	c.Provide(NewMongoDBByConf)
	c.Provide(NewKafkaProxyByConf)
	c.Provide(baidu_lbs_yun_proxy.NewBaiduLbsYunProxyImpl)
	c.Provide(shumei_proxy.NewShumeiProxyImpl)
	c.Provide(wechat_proxy.NewWechatMng)
	c.Provide(inner_mng.NewInnerProxyImpl)

	// data cache
	c.Provide(mg_model.NewUserAwardSummaryMgModelImpl)
	c.Provide(mg_model.NewKoLaWithdrawDetailMgModelImpl)
	c.Provide(mg_model.NewSuperiorContentAwardDetailMgModelImpl)
	c.Provide(mg_model.NewSNotificationReadCursorMgModelImpl)
	c.Provide(mg_model.NewCommentLikeDetailMgModelImpl)
	c.Provide(mg_model.NewSportActivityMgModelImpl)
	c.Provide(mg_model.NewPersonalUserAccountMgModelImpl)
	c.Provide(mg_model.NewWorkCommentDetailMgModelImpl)
	c.Provide(mg_model.NewUserCommentUnreadWorkMgModelImpl)
	c.Provide(mg_model.NewSecretShareUserInfoExtMgModelImpl)
	c.Provide(mg_model.NewPersonalPoliceInfoMgModelImpl)
	c.Provide(mg_model.NewWorksExpandRelMgModelImpl)
	c.Provide(mg_model.NewSecretUserMedalInfoMgModelImpl)
	c.Provide(mg_model.NewSecretMedalInfoMgModelImpl)
	c.Provide(mg_model.NewUserBlackListMgModelImpl)
	c.Provide(mg_model.NewPersonalTalkMessageTotalMgModelImpl)
	c.Provide(mg_model.NewSecretUserFollowMgModelImpl)
	c.Provide(mg_model.NewSecretUserFollowBadgeMgModelImpl)
	c.Provide(mg_model.NewSecretUserFollowBadgeListMgModelImpl)
	c.Provide(mg_model.NewSecretWorksLikeRecordMgModelImpl)
	c.Provide(mg_model.NewSecretUserWechatBindListMgModelImpl)
	c.Provide(mg_model.NewPersonalTalkMessageRecordMgModelImpl)
	c.Provide(mg_model.NewSecretMemeMgModelImpl)
	c.Provide(mg_model.NewIpAddressMgModelImpl)
	c.Provide(mg_model.NewSecretChitchatWorkMgModelImpl)
	c.Provide(mg_model.NewSignDailyFortuneMgModelImpl)
	c.Provide(mg_model.NewSecretChitChatCDKeyMgModelImpl)
	c.Provide(mg_model.NewPersonalUserNotificationMgModelImpl)
	c.Provide(mg_model.NewSecretReportMgModelImpl)
	c.Provide(mg_model.NewSecretReportUserMgModelImpl)
	c.Provide(mg_model.NewSecretMemberInfoMgModelImpl)
	c.Provide(mg_model.NewUserRemindDetailMgModelImpl)
	c.Provide(mg_model.NewAuditAwardRecordMgModelImpl)
	c.Provide(mg_model.NewSecretUserIdentificationCardMgModelImpl)
	c.Provide(mg_model.NewAuditMaliciousRecordMgModelImpl)
	c.Provide(mg_model.NewPersonBottleWorksExtMgModelImpl)
	c.Provide(mg_model.NewSecretGameMgModelImpl)
	c.Provide(mg_model.NewSecretGameOrderMgModelImpl)
	c.Provide(mg_model.NewSecretPayOrderInfoMgModelImpl)
	c.Provide(mg_model.NewSecretPayNotifyMgModelImpl)
	c.Provide(mg_model.NewSecretActiveUserMgModelImpl)
	c.Provide(mg_model.NewSecretEmoteAuditRecordMgModelImpl)
	c.Provide(mg_model.NewSecretAuditMgModelImpl)
	c.Provide(mg_model.NewSecretDailySignInMgModelImpl)
	c.Provide(mg_model.NewSecretSpeedCodeMgModelImpl)
	c.Provide(mg_model.NewSecretUserActivityDailyMgModelImpl)
	c.Provide(mg_model.NewImGroup)
	c.Provide(mg_model.NewAtDetailMgModel)
	c.Provide(mg_model.NewSecretUserLoginInfoMgModel)
	c.Provide(model.NewUserinfoDbModelImpl)
	c.Provide(model.NewPersonalBottleWorksDbModelImpl)
	c.Provide(model.NewWorkObjectAttrDbModelImpl)
	c.Provide(model.NewOpenUserDbModelImpl)
	c.Provide(model.NewUserCircleWorksSwitchDbModelImpl)
	c.Provide(model.NewSecretExpandTypeDbModelImpl)
	c.Provide(model.NewPersonalCardMessageQueueDbModelImpl)
	c.Provide(model.NewMaoZhuaXingZuoBirthDbModelImpl)
	c.Provide(model.NewUserLevelUpRecordDbModelImpl)
	c.Provide(model.NewReportRewardDbModelImpl)
	c.Provide(model.NewWorkCommentStatusDbModelImpl)
	c.Provide(model.NewOperatorTabDbModelImpl)
	c.Provide(model.NewAdVivoFeedbackDbModelDbModelImpl)
	//imdb
	c.Provide(im.NewImGroupsDbModelModel)
	c.Provide(im.NewImGroupMemberDbModelModel)
	//data cache
	c.Provide(data_cache.NewDataCacheMng)

	c.Provide(open_im_api.NewOpenIMCaller)
	c.Provide(im_mng.NewIMHelper)
	c.Provide(content_mng.NewSendSessComp)
	c.Provide(content_mng.NewContentMng)
	c.Provide(user_level_mng.NewUserLevelMng)
	c.Provide(security_mng.NewSecurityMng)
	c.Provide(user_center_mng.NewUserCenterMng)
	c.Provide(pay_mng.NewPayMng)
	c.Provide(game_mng.NewGameMng)
	c.Provide(im_mng.NewIMMng)

	// handler
	c.Provide(handler.NewAdminHandler)
	//router
	c.Provide(router.NewRouter)

	return c
}

// NewLocalContainer 本地环境
func NewLocalContainer() *dig.Container {
	c := dig.New()

	return c
}
