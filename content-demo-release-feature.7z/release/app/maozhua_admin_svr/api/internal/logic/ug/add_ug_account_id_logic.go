package ug

import (
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type AddUgAccountIdLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewAddUgAccountIdLogic(ctx context.Context, svcCtx *svc.ServiceContext) *AddUgAccountIdLogic {
	return &AddUgAccountIdLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *AddUgAccountIdLogic) AddUgAccountId(req *types.AddUgAccountIdReq) (resp *types.AddUgAccountIdResp, err error) {
	// todo: add your logic here and delete this line

	return
}
