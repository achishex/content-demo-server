package ug

import (
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type FinishUgPtRecordLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewFinishUgPtRecordLogic(ctx context.Context, svcCtx *svc.ServiceContext) *FinishUgPtRecordLogic {
	return &FinishUgPtRecordLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *FinishUgPtRecordLogic) FinishUgPtRecord(req *types.FinishUgPtRecordReq) (resp *types.FinishUgPtRecordResp, err error) {
	// todo: add your logic here and delete this line

	return
}
