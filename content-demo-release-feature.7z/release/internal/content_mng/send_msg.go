package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/busi_comm/trans"
	"content_svr/internal/data_cache"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"content_svr/setting"
	"context"
	"encoding/json"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"time"
)

type SendMsgSession struct {
	// 非空字段
	curUserId   int64
	curUserInfo *data_cache.UserInfoLocal
	toUserId    int64
	toUserInfo  *data_cache.UserInfoLocal //
	modeType    int32

	// optional
	mutual        int32                     //是否互关a
	workId        int64                     // 互关的话，workid为-1
	workInfo      *data_cache.WorkInfoLocal //互关了，则没有workInfo为nil
	fromWindow    *pbapi.PersonalTalkMessageTotalMgDbModel
	toWindow      *pbapi.PersonalTalkMessageTotalMgDbModel
	curCoordinate *pbapi.Coordinate
	messageWorkId int64                   //新增消息id, 或者是remind id，
	msgType       int32                   //消息类型: 9, 10, 11
	commentId     int64                   //当消息时11是，填充
	remindWorkId  int64                   //当消息是10时，填充
	remindsOnWork []*pbapi.RemindUserNode //当消息为10时，请求的remind info
}

// toUserId 必须>0  workId可以不传
func (p *ContentMng) SendMsg(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.SendMsgReq) (*pbapi.SendMsgSimple, error) {
	//1.1 获取user_id
	var curUserId int64 = 0
	if config.ServerConfig.Env != "prod" && header.Debuguserid > 0 {
		curUserId = header.Debuguserid
	} else {
		curUserIdTmp, err := p.DataCache.GetUserIdByToken(ctx, header.Token)
		if err != nil {
			logger.Errorf(ctx, "get user id by token failed,err=%v", err.Error())
			return nil, errorcode.LOGIN_INVALID
		}
		curUserId = curUserIdTmp
	}
	logAttr := make([]string, 0)
	defer func() {
		logger.Infof(ctx, "SendMsg.curUserId=%v,toUserId=%v,logAttr=%v", curUserId, req.GetToUserId(), logAttr)
	}()

	resp := &pbapi.SendMsgSimple{}
	//1.2 获取当前用户信息 curUserInfo
	if curUserId <= 0 {
		return resp, errorcode.LOGIN_INVALID
	}
	curUserInfo, err := p.DataCache.GetUserInfoLocal(ctx, header, curUserId, false)
	if err != nil || curUserInfo == nil {
		return resp, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "用户不存在")
	}
	if curUserInfo.PsecretUserExtInfo == nil {
		curUserInfo.PsecretUserExtInfo, err = p.DataCache.GetImpl().UserInfoExtMgModel.GetAndCreate(ctx, curUserId)
		if err != nil {
			logger.Error(ctx, "PsecretUserExtInfo is nil, and create it failed", err)
		}
		logger.Infof(ctx, "PsecretUserExtInfo create it, curUserId=%v,toUserId=%v", curUserId, req.GetToUserId())
	}

	//不允许个自己发, tdodo 检查是否当前用户被禁止发言了。
	if curUserId == req.GetToUserId() {
		return resp, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "不能给自己发送消息")
	}

	//1.3 查询 toUser信息
	// todo
	toUserInfo, err := p.DataCache.GetUserInfoLocal(ctx, header, req.GetToUserId(), true)
	if err != nil || toUserInfo == nil {
		return resp, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "对方账号已注销")
	}
	session := &SendMsgSession{
		curUserId:   curUserId,
		curUserInfo: curUserInfo,
		toUserId:    toUserInfo.UserInfoDbModel.GetUserId(),
		toUserInfo:  toUserInfo,
		modeType:    int32(pbconst.PtModelTypeEnum_pt_model_type_normal),
	}

	// 1.4 是否聊天被封禁
	if req.GetWorkId() > 0 {
		if curUserInfo.UserInfoDbModel.GetCommentLock() != 1 {
			return resp, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "当前用户被禁止发言")
		}
		if toUserInfo.UserInfoDbModel.GetCommentLock() != 1 {
			return resp, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "目标用户违规被封禁")
		}
	}

	// 1.5 是否被拉入了黑名单。
	if p.DataCache.CheckUserBlackListMgDBLD(ctx, curUserId, req.GetToUserId()) {
		// cur把to拉黑了，啥都不干，直接返回
		logger.Infof(ctx, "fromUser is in curUser blacklist, skip.from=%v, cur=%v", curUserId, req.GetToUserId())
		return resp, nil
	}
	if p.DataCache.CheckUserBlackListMgDBLD(ctx, req.GetToUserId(), curUserId) {
		// to把cur拉黑了. 报错
		return resp, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "你被对方拉黑了，对方无法接收你的消息")
	}

	// 1.6 是否互关了。
	session.workId = req.GetWorkId()
	session.mutual = p.DataCache.GetUserFollowMgDBLd(ctx, curUserId, req.GetToUserId())
	if session.mutual == int32(pbconst.MutualEnum_mutual_yes) {
		session.workId = -1
	}
	uniqueId := genUniqueId(curUserId, req.GetToUserId(), session.workId, session.modeType)

	// 1.7 获取work信息
	if session.workId > 0 {
		work, err := p.DataCache.GetWorkInfoLocal(ctx, session.workId, false)
		if err != nil || work == nil {
			return resp, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "唠唠作品不存在")
		}
		if work.WorkInfoDbModel.GetStatus() == int32(pbconst.BaseTabStatus_invalid) {
			logger.Infof(ctx, "work is deleted. workid=%v", session.workId)
			return resp, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "作品已删除，回复已关闭")
		}
		session.workInfo = work

		if curUserInfo.UserInfoDbModel.GetUserId() != work.WorkInfoDbModel.GetUserId() {
			// 1.7.1 闭关模式且非互关
			if p.DataCache.GetUserInfoTalkMode(ctx, req.GetToUserId()) == const_busi.TalkModeClose && session.mutual == int32(pbconst.MutualEnum_mutual_not) {
				return resp, errorcode.TalkModeCloseError
			}
		}
	}

	// 1.8 基于workid之下的检查
	session.toWindow = p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, req.GetToUserId()) // 正向
	session.fromWindow = p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, curUserId)       // 反向
	logger.Infof(ctx, "=====uniqueId=3%v, curUserId=%v, touserid=%v, workid=%v, req.workid=%v towindow=%v, fromWindow=%v",
		uniqueId, curUserId, req.GetToUserId(), session.workId, req.GetWorkId(), session.toWindow, session.fromWindow)

	//处理emoji图片。
	if req.GetMemeId() > 0 {
		// 发emoji
		memeItem := p.DataCache.GetSecretMemeMgDBLd(ctx, req.GetMemeId())
		if memeItem != nil {
			req.ObjectId = proto.String(memeItem.GetObjectId())
			req.High = proto.Int32(memeItem.High)
			req.Width = proto.Int32(memeItem.Width)
		} else {
			// 暂时只打印报错，没阻止流程。
			logger.Errorf(ctx, "get GetSecretMemeMgDBLd failed. req=%+v", req)
			return resp, errorcode.GenBusiErr(errorcode.DATA_INVALID, "表情不存在")
		}
	}

	replyType := 0
	//业务检查
	if curUserId != cm_const.OfficialMZUserId {
		//检查发图发表情权限。
		errMsg := p.hasAuthForMsgType(ctx, req.GetMessageType(), req.GetMemeId(), session)
		if errMsg != "" {
			logger.Errorf(ctx, "send_msg failed. no right for this msgType . req=%+v, err=%v", req, err)
			return resp, errorcode.GenBusiErr(errorcode.DATA_INVALID, errMsg)
		}

		// 1.9基于作品的聊天
		if session.workId > 0 {
			// 检查1  对方还未回复情况下，能发送的消息条数限制。
			err = p.checkMsgLimit(ctx, req, session)
			if err != nil {
				logger.Warnf(ctx, "checkMsgLimit failed,  err=%v", err)
				return resp, err
			}

			// 检查2  每日单聊上限度/ 检查帖子非vip可以回复的上限。
			replyType, err = p.updateReplyCount(ctx, header, req, session, uniqueId)
			if err != nil {
				logger.Warnf(ctx, "updateReplyCount failed,  err=%v", err)
				return resp, err
			}
		}

		// 检查 2.2 content_check_svr关键词过滤服务。
		pass := p.checkContent(ctx, header, req, session)
		if !pass {
			// 内容检查不通过。 吞掉内容不报错
			_, err = p.saveHiddenRecord(ctx, header, req, session, uniqueId)
			if err != nil {
				logger.Error(ctx, "saveHiddenRecord failed. ", err)
				return resp, err
			}
			logger.Infof(ctx, "checkContent not pass. over.kw_check=%v, content=%v", pass, req.GetContent())
			return resp, nil
		}
	}

	// 1. 10 根据请求或者根据ip来获取对方位置信息。
	session.curCoordinate = p.getCoordinate(ctx, header, curUserId, req.Latitude, req.Longitude)
	// 至此全部session资料收集完毕 =======

	// 此处才是写入消息时候
	// step 5.1 写record  包含是否能发图片的检查，图片是否违规的检查。
	record, err := p.sendMsgBase(ctx, header, req, session, uniqueId)
	if err != nil {
		logger.Warnf(ctx, "sendMsgBase failed,  err=%v", err)
		return resp, err
	}

	//达到双方互动次数阈值
	interactAddFriedTimes := p.DataCache.GetTimesConfigLR(ctx, "secret_interact_add_friend_times")
	if session.workId > 0 && interactAddFriedTimes > 0 {
		if session.fromWindow != nil && session.toWindow != nil &&
			session.toWindow.GetInteractTimes() >= int32(interactAddFriedTimes-1) &&
			session.fromWindow.GetInteractTimes() >= int32(interactAddFriedTimes) &&
			session.toWindow.GetPushedInteract() != true &&
			session.fromWindow.GetPushedInteract() != true {
			// 发送猫友勋章, 只发送一次。
			err = p.pushInteractMessage(ctx, session)
			if err != nil {
				logger.Error(ctx, "pushInteractMessage failed.", err)
			}
		}
	}

	// 写用户已回复的信息。
	if replyType == 1 { //用户首次回复该帖子
		// 设置一天回复量。
		err = p.DataCache.SetUserCurReplyList(ctx, session.curUserId, session.toUserId)
		if err != nil {
			logger.Errorf(ctx, "SetUserCurReplyList failed. err=%v", err.Error())
		}
	}

	// 封装应答
	resp.SessionId = session.fromWindow.GetId()
	resp.MessageId = record.GetId()
	resp.CreateTime = record.GetCreateTime()
	resp.Status = 1
	resp.FromCoordinate = &pbapi.Coordinate{
		Longitude: session.fromWindow.FromLng,
		Latitude:  session.fromWindow.FromLat,
		Province:  session.fromWindow.FromProvince,
		City:      session.fromWindow.FromCity,
	}
	resp.ToCoordinate = &pbapi.Coordinate{
		Longitude: session.fromWindow.ToLng,
		Latitude:  session.fromWindow.ToLat,
		Province:  session.fromWindow.ToProvince,
		City:      session.fromWindow.ToCity,
	}
	return resp, nil
}

func (p *ContentMng) getRemindInfo(ctx context.Context, workId int64) []*pbapi.RemindUserNode {
	ret := []*pbapi.RemindUserNode{}
	eqConds := map[string]interface{}{
		"workId":     workId,
		"remindType": const_busi.WorkRemindType,
	}
	retData, err := p.DataCache.GetImpl().UserRemindDetail.GetRemindDetailByConds(ctx, eqConds,
		nil, nil, nil, 0)
	if err != nil || len(retData) <= 0 {
		logger.Infof(ctx, "not find remind user info")
		return ret
	}
	for remindIndex, _ := range retData {
		if retData[remindIndex] == nil {
			continue
		}
		//
		ret = append(ret, &pbapi.RemindUserNode{
			UserId: retData[remindIndex].RemindUserId,
			OffSet: retData[remindIndex].RemindOffSet,
			Size:   retData[remindIndex].RemindSize,
		})
	}
	return ret
}
func (p *ContentMng) sendMsgBase(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.SendMsgReq,
	session *SendMsgSession,
	uniqueId int32) (*pbapi.PersonalTalkMessageRecordMgDbModel, error) {
	// step 5.1 写record  包含是否能发图片的检查，图片是否违规的检查。
	record, err := p.savePtRecord(ctx, req, session, uniqueId)
	if err != nil {
		logger.Warnf(ctx, "savePtRecord failed,  err=%v", err)
		return record, err
	}

	// tsn消息推送，腾讯信鸽
	p.tsnPushSingleMessage(ctx, session.workId, session.curUserId, session.toUserId, session.curUserInfo.UserInfoDbModel.NickName,
		nil, req.Content, nil, req.GetMessageType())

	// 写卡片。
	curTimeStr := utils.GenDbTime(time.Now())
	_, err = p.DataCache.InsertPersonalCardMessageQueueDbModel(ctx, &pbapi.PersonalCardMessageQueueDbModel{
		Id:         snow_flake.GetSnowflakeID(),
		UserId:     session.toUserId,
		FromUserId: session.curUserId,
		GroupId:    int64(uniqueId),
		MessageId:  record.Id,
		Type:       1, //	1-单聊 2-群聊
		CreateTime: curTimeStr,
	})
	if err != nil {
		logger.Errorf(ctx, "InsertPersonalCardMessageQueueDbModel failed. err=%v", err.Error())
		return record, err
	}

	// 写入或者更新towindow，fromwindow
	err = p.savePtTotal(ctx, header, req, session, record, uniqueId)
	if err != nil {
		logger.Errorf(ctx, "savePtTotal failed. err=%v", err.Error())
		return record, err //
	}
	var workInfo *pbapi.PersonalBottleWorksSimple
	if session.msgType == int32(pbconst.MessageTypeEnum_msg_type_remind_work) {
		workLocalInfo, err := p.DataCache.GetImpl().GetWorkInfoLD(ctx, session.remindWorkId, true)
		if err != nil || workLocalInfo == nil {
			logger.Errorf(ctx, "get work info fail, err: %v, workId: %v", err, session.remindWorkId)
		} else {
			// at 人
			remindInfo := p.getRemindInfo(ctx, session.remindWorkId)
			workUserInfo, err := p.DataCache.GetImpl().GetUserInfoLocal(ctx, nil, workLocalInfo.WorkInfoDbModel.GetUserId(), false)
			if err != nil || workUserInfo == nil {
				logger.Errorf(ctx, "not get work user info.")
			} else {
				workInfo = trans.TransWorkInfoLocalScoreInfoToWorksSimple(workLocalInfo, workUserInfo, false, nil)
				if workInfo == nil {
					workInfo = &pbapi.PersonalBottleWorksSimple{}
				}
				workInfo.RemindNode = remindInfo
			}
			// at 群
			if remindGroup, err2 := p.DataCache.GetImpl().AtDetailMgModel.ListWorkAtGroup(ctx, session.remindWorkId); err2 == nil {
				workInfo.RemindGroup = remindGroup
			} else {
				logger.Errorf(ctx, "ListWorkAtGroup fail, err: %v", err)
			}
		}
	}
	var remind *pbmgdb.UserRemindDetailMgDbModel
	if session.msgType == int32(pbconst.MessageTypeEnum_msg_type_remind_comment) {
		eqConds := map[string]interface{}{
			"_id": session.messageWorkId,
		}
		remindDb, err := p.DataCache.GetImpl().UserRemindDetail.GetRemindDetailByConds(ctx, eqConds, nil, nil, nil, 0)
		if err == nil && remindDb != nil && len(remindDb) > 0 {
			remindedUserInfo, _ := p.DataCache.GetImpl().GetUserInfoLocal(ctx, nil, remindDb[0].GetRemindUserId(), false)
			userInfo := &pbapi.UserSimpleResponse{}
			if remindedUserInfo != nil {
				userInfo.UserId = remindDb[0].RemindUserId
				userInfo.NickName = remindedUserInfo.UserInfoDbModel.NickName
			}
			remind = remindDb[0]
		}
	}

	if session.msgType == int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply) {
		remind = &pbmgdb.UserRemindDetailMgDbModel{
			WorkId:    proto.Int64(session.remindWorkId), //动态id
			CommentId: proto.Int64(session.commentId),    //回复评论的id
		}

		//获取被回复的评论详情
		repliedCommentDetail, err := p.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentById(ctx, session.messageWorkId)
		workInfo = &pbapi.PersonalBottleWorksSimple{}
		if err == nil {
			workInfo.Title = repliedCommentDetail.GetComment()
		}

		commentDetail, err := p.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentById(ctx, session.commentId)
		if err == nil {
			commentUserInfo, err := p.DataCache.GetUserInfoLocal(ctx, header, commentDetail.GetUserId(), false)
			if err == nil {
				workInfo.UserInfo = &pbapi.SimpleUserInfo{
					UserId:   commentUserInfo.UserInfoDbModel.GetUserId(),
					NickName: commentUserInfo.UserInfoDbModel.GetNickName(),
				}
			}
		}
	}

	// 推送 websocket. 用户私聊消息红点
	err = p.KafkaProxy.SendSignTalkMsg(ctx, session.curUserInfo, record, workInfo, remind)
	if err != nil {
		logger.Errorf(ctx, "push ws to user failed. err=%v", err.Error())
		return record, err //
	}
	return record, nil
}

func (p *ContentMng) getCoordinate(ctx context.Context,
	header *pbapi.HttpHeaderInfo, userId int64, lat, lng *float64) *pbapi.Coordinate {
	//var resp *pbapi.Coordinate = nil

	// 兼容旧逻辑
	if lat != nil && lng != nil {
		header.Longitude = *lng
		header.Latitude = *lat
	}

	coor := p.DataCache.GetUserCoordinateV2(ctx, userId, header)
	return p.DataCache.ConvertFormate(coor)

	//// 根据经纬度找
	//if lat != nil && lng != nil {
	//	resp1, err := p.BaiduLbsProxy.ReverseGeocoding(ctx, lat, lng)
	//	if err == nil && resp1 != nil {
	//		//
	//		return resp1
	//	}
	//} else {
	//	resp = p.DataCache.GetCoordinateByIp(ctx, header.GetIp())
	//	return resp
	//}
	//return resp
}

// 检查条数限制
func (p *ContentMng) checkMsgLimit(ctx context.Context, req *pbapi.SendMsgReq, session *SendMsgSession) error {
	if session.workId <= 0 {
		// 不检查
		return nil
	}

	if session.fromWindow == nil && session.toWindow == nil && session.fromWindow.GetInteractTimes() == 0 {
		// 首次发信息
		if len([]rune(req.GetContent())) > int(setting.Maozhua.TalkMessageStrangerMaxLength.Get()) {
			return errorcode.TalkMessageLengthError
		}
	}

	// todo
	// 检查1 对方未回复的情况下，最多只能发送n条消息。
	if session.fromWindow != nil && session.toWindow != nil && session.fromWindow.GetInteractTimes() == 0 {
		// 对方还未回复，只能发送timeLimit条消息。
		var timeLimit int32 = 1
		switch session.curUserInfo.MemberType {
		case const_busi.NormalUser:
			timeLimit = int32(setting.Maozhua.TalkNoReplyMaxCount.Get())
		case const_busi.VipUser, const_busi.GiftVipUser, const_busi.SVipUser:
			timeLimit = int32(setting.Maozhua.VipTalkNoReplyMaxCount.Get())
		default:
			break
		}

		if len([]rune(req.GetContent())) > int(setting.Maozhua.TalkMessageStrangerMaxLength.Get()) {
			return errorcode.TalkMessageLengthError
		}

		//var timeLimit int32 = 2
		//if session.curUserInfo.MemberType == int32(pbconst.MemberTypeEnum_member_type_svip) {
		//	// SVIP
		//	timeLimit = 4
		//} else if session.curUserInfo.MemberType > 1 {
		//	// vip
		//	timeLimit = 3
		//}
		// 检查
		if session.toWindow.GetInteractTimes() >= timeLimit {
			return errorcode.TalkNoReplyError
		}
	}
	return nil
}

// 检查 curUser每日单聊上限。 true 通过。 false-不通过。
func (p *ContentMng) checkPtTalkReplyLimit(ctx context.Context,
	header *pbapi.HttpHeaderInfo,
	curUserInfo *data_cache.UserInfoLocal, toUserId int64) bool {

	//不在小黑屋的
	if curUserInfo.MemberType > 0 {
		return true
	}

	level := curUserInfo.PsecretUserExtInfo.GetUlevel()
	levCfg := const_busi.GetLevelCfg(level)

	// 允许回复的条数
	timesInt64 := levCfg.DailyTalkLimit
	if curUserInfo.IsInBlackHouse {
		timesInt64 = 2 //小黑屋中的非vip
	}

	// 读取set长度。
	curReplyList := p.DataCache.GetUserCurReplyList(ctx, curUserInfo.UserInfoDbModel.GetUserId())
	if curUserInfo.MemberType == 0 && timesInt64 > 0 &&
		!utils.HasInt64Element(toUserId, curReplyList) && len(curReplyList) >= int(timesInt64) {
		// 当前对象没聊过，而且配置非0，总数超过配置，报错。
		logger.Infof(ctx, "over limit. curReplyList=%v,toUserId=%v, ulevel=%v, timesCfg=%v", level, timesInt64)
		return false
	}
	return true
}

// 安全监测文本、图片
func (p *ContentMng) checkContent(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.SendMsgReq, session *SendMsgSession) bool {
	var (
		bReturn = true // 默认通过

		audit = &pbmgdb.SecretAuditMgDbModel{
			Id:             snow_flake.GetSnowflakeID(),
			Platform:       1,
			EventId:        shumei_proxy.EventIDMessage,
			UserId:         session.curUserId,
			IsRecirculate:  2,
			FeedbackStatus: 2,
			CreateTime:     time.Now().UnixMilli(),
		}
	)

	switch req.GetMessageType() {
	case int32(pbconst.MessageTypeEnum_msg_type_pic):
		picPass, resp := p.checkImage(ctx, req.GetObjectId(), session.curUserId, false, 0, shumei_proxy.EventIDMessage)
		bReturn = bReturn && picPass

		if picPass == false {
			if resp != nil {
				auditResp, _ := json.Marshal(resp)
				audit.RequestId = resp.RequestID
				audit.HookType = cm_const.HookTypeShuMei
				audit.AuditType = cm_const.AuditTypeImg
				audit.ImgUrl = req.GetObjectId()
				audit.AuditResp = string(auditResp)
				_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
			}
		}
		logger.Infof(ctx, "content_check_image, picUrl=%v, imageResult=%v", req.GetObjectId(), picPass)
	case int32(pbconst.MessageTypeEnum_msg_type_txt):
		interact := pbapi.InteractEnum_not
		if session.toWindow != nil && session.toWindow.GetPushedInteract() == true {
			interact = pbapi.InteractEnum_yes
		}
		kwpass, innerResp, err := p.InnerProxy.CheckContent(ctx, &pbapi.PersonalTalkCheckReq{
			WorkId:      session.workId,
			Content:     req.GetContent(),
			Interact:    interact,
			FromUserId:  session.curUserId,
			ToUserId:    session.toUserId,
			Mutual:      session.mutual,
			MessageType: req.MessageType,
			ObjectId:    req.GetObjectId(),
			MemeId:      req.GetMemeId(),
		})
		if err != nil {
			logger.Errorf(ctx, "CheckContent req failed. err=%v", err)
		}

		//平台拦截
		if !kwpass {
			audit.HookType = cm_const.HookTypeMine
			audit.EventId = shumei_proxy.EventIDMessage
			audit.AuditType = cm_const.AuditTypeText
			audit.AuditResp = fmt.Sprintf("本平台内容拦截，结果：%+v", innerResp)
			audit.Content = req.GetContent()
			_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
		}

		bReturn = bReturn && kwpass

		// 非金牌猫友才融合数美的结果
		if bReturn && interact == pbapi.InteractEnum_not {
			// 内容送数美。
			shumeiPass := true //
			//2.1 送数美进行数据检查
			verifyStatus, resp, err := p.ShumeiProxy.CheckTxt(ctx, req.GetContent(), session.curUserId, shumei_proxy.EventIDMessage)
			if err != nil {
				logger.Errorf(ctx, "shumei.checkTxt err=%v", err)
				//return nil, nil, err
			}
			if verifyStatus != "" && verifyStatus != shumei_proxy.TextRiskLevelPASS {
				shumeiPass = false // 不通过
				if resp != nil {
					auditResp, _ := json.Marshal(resp)
					audit.RequestId = resp.RequestID
					audit.HookType = cm_const.HookTypeShuMei
					audit.AuditType = cm_const.AuditTypeText
					audit.EventId = shumei_proxy.EventIDMessage
					audit.AuditResp = string(auditResp)
					audit.RiskLevel = resp.RiskLevel
					audit.Content = req.GetContent()
					_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
				}
			}
			bReturn = bReturn && shumeiPass
			logger.Infof(ctx, "InteractEnum=%v,content_check, kwResult=%v, shumei.Result=%v, bReturn=%v,content=%v",
				interact, kwpass, verifyStatus, bReturn, req.GetContent())
		}
	}

	return bReturn
}

// 保存私聊信息到 PersonalTalkMessageRecord
func (p *ContentMng) savePtRecord(ctx context.Context, req *pbapi.SendMsgReq,
	session *SendMsgSession,
	uniqueId int32) (*pbapi.PersonalTalkMessageRecordMgDbModel, error) {

	msgType := req.MessageType
	messageWorkId := int64(0)
	if session.msgType >= int32(pbconst.MessageTypeEnum_msg_type_mutual_notice) &&
		session.msgType <= int32(pbconst.MessageTypeEnum_msg_type_remind_comment) {
		//
		msgType = session.msgType
		messageWorkId = session.messageWorkId
	}
	if session.msgType == int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply) {
		msgType = session.msgType
		messageWorkId = session.commentId // 回复评论的id; 二级环境
	}
	curTimeMs := utils.GetCurTsMs()
	record := &pbapi.PersonalTalkMessageRecordMgDbModel{
		Id:            snow_flake.GetSnowflakeID(),
		ModeType:      proto.Int32(session.modeType),
		FromUserId:    proto.Int64(session.curUserId),
		ToUserId:      proto.Int64(session.toUserId),
		Content:       req.Content,
		CreateTime:    proto.Int64(curTimeMs),
		Status:        proto.Int32(int32(pbconst.BaseTabStatus_valid)),
		WorkFlag:      proto.Int32(0),
		Read:          proto.Int32(0), // 0
		WorkId:        proto.Int64(session.workId),
		MessageType:   proto.Int32(msgType),
		Width:         req.Width,
		High:          req.High,
		ClientId:      req.ClientId,
		MemeId:        req.MemeId,
		ObjectId:      req.ObjectId,
		MessageWorkId: proto.Int64(messageWorkId),
	}

	//

	if req.GetMessageType() == int32(pbconst.MessageTypeEnum_msg_type_voice) {
		record.Duration = proto.Int32(req.GetDuration())
	}
	record.PushType = proto.Int32(int32(pbconst.PushTypeEnum_push_type_not_anonymous)) //1-匿名 2-非匿名
	record.UniqueId = proto.Int32(uniqueId)
	if session.curCoordinate != nil {
		record.Province = session.curCoordinate.Province
		record.City = session.curCoordinate.City
		record.Latitude = session.curCoordinate.Latitude
		record.Longitude = session.curCoordinate.Longitude
	}

	err := p.DataCache.InsertPersonTalkMsgRecord(ctx, record)
	if err != nil {
		logger.Errorf(ctx, "InsertPersonTalkMsgRecord failed. err=%v", err.Error())
		return record, err
	}
	return record, nil
}

// 通过返回空，不通过返回报错原因。  检查是否有发送  MessageType:  消息类型，1:文字；2:图片；3:语音;默认是文字；99：表情
func (p *ContentMng) hasAuthForMsgType(ctx context.Context, msgType int32, memeId int64,
	session *SendMsgSession) string {

	logger.Infof(ctx, "hasAuthForMsgType, memeId=%v", memeId)
	if session.mutual == 1 {
		// 互关好友，啥都能发。
		return ""
	}

	// 以下是 未互关的
	switch msgType {
	case int32(pbconst.MessageTypeEnum_msg_type_voice):
		// 未互关，不允许发
		return "暂无权限"
	case int32(pbconst.MessageTypeEnum_msg_type_pic):
		// 金牌猫友之前，不允许发
		if session.toWindow == nil || (session.toWindow != nil && session.toWindow.GetPushedInteract() == false) {
			// 还没开始聊 或者开聊后还没达成金牌猫友
			return "请先解锁金牌猫友"
		}
		// 金牌猫友以后，lv3和lv4才能发自定义表情和图片。
		if session.curUserInfo.PsecretUserExtInfo.GetUlevel() < 3 {
			return "等级不够，暂无权限"
		}
		// 小黑屋不能发图
		if session.curUserInfo.IsInBlackHouse == true {
			logger.Infof(ctx, "user is in blackhouse")
			return "暂无权限"
		}
	case int32(pbconst.MessageTypeEnum_msg_type_emoji):
		if memeId <= 100 {
			//系统表情
			return ""
		}
		// 金牌猫友之前， 系统表情以外的，不能发。
		if session.toWindow == nil || (session.toWindow != nil && session.toWindow.GetPushedInteract() == false) {
			// 还没开始聊 或者开聊后还没达成金牌猫友
			return "请先解锁金牌猫友"
		}
		// 金牌猫友以后，lv3和lv4才能发自定义表情和图片。
		if session.curUserInfo.PsecretUserExtInfo.GetUlevel() < 3 {
			return "等级不够，暂无权限"
		}
		// 小黑屋不能发图
		if session.curUserInfo.IsInBlackHouse == true {
			logger.Infof(ctx, "user is in blackhouse")
			return "暂无权限"
		}
	}
	return ""
}

// 保存私聊信息到 PersonalTalkMessageRecord
func (p *ContentMng) saveWorkRecord(ctx context.Context,
	header *pbapi.HttpHeaderInfo, req *pbapi.SendMsgReq,
	session *SendMsgSession,
	uniqueId int32) (*pbapi.PersonalTalkMessageRecordMgDbModel, error) {

	curTimeMs := utils.GetCurTsMs()
	record := &pbapi.PersonalTalkMessageRecordMgDbModel{
		Id:          snow_flake.GetSnowflakeID(),
		ModeType:    proto.Int32(session.modeType),
		FromUserId:  proto.Int64(session.curUserId),
		ToUserId:    proto.Int64(session.toUserId),
		Content:     proto.String(session.workInfo.WorkInfoDbModel.GetTitle()),
		CreateTime:  proto.Int64(curTimeMs),
		Status:      proto.Int32(int32(pbconst.BaseTabStatus_valid)),
		WorkFlag:    proto.Int32(1),
		Read:        proto.Int32(1), // 0
		PushType:    proto.Int32(int32(pbconst.PushTypeEnum_push_type_not_anonymous)),
		WorkId:      proto.Int64(session.workId),
		MessageType: proto.Int32(int32(pbconst.MessageTypeEnum_msg_type_txt)),
		UniqueId:    proto.Int32(uniqueId),
	}

	err := p.DataCache.InsertPersonTalkMsgRecord(ctx, record)
	if err != nil {
		logger.Errorf(ctx, "InsertPersonTalkMsgRecord failed. err=%v", err.Error())
		return record, err
	}
	return record, nil
}

// 隐藏消息，之有发送者自己能看到。
func (p *ContentMng) saveHiddenRecord(ctx context.Context,
	header *pbapi.HttpHeaderInfo, req *pbapi.SendMsgReq,
	session *SendMsgSession,
	uniqueId int32) (*pbapi.PersonalTalkMessageRecordMgDbModel, error) {

	// record
	curTimeMs := utils.GetCurTsMs()
	record := &pbapi.PersonalTalkMessageRecordMgDbModel{
		Id:          snow_flake.GetSnowflakeID(),
		ModeType:    proto.Int32(session.modeType),
		FromUserId:  proto.Int64(session.curUserId),
		ToUserId:    proto.Int64(session.toUserId),
		Content:     proto.String(req.GetContent()),
		CreateTime:  proto.Int64(curTimeMs),
		Status:      proto.Int32(int32(pbconst.BaseTabStatus_invalid)),
		WorkFlag:    proto.Int32(0),
		Read:        proto.Int32(0), // 0
		WorkId:      proto.Int64(session.workId),
		PushType:    proto.Int32(int32(pbconst.PushTypeEnum_push_type_not_anonymous)),
		MessageType: proto.Int32(int32(pbconst.MessageTypeEnum_msg_type_txt)),
		UniqueId:    proto.Int32(uniqueId),
		ObjectId:    proto.String(req.GetObjectId()),
		MemeId:      proto.Int64(req.GetMemeId()),
	}

	err := p.DataCache.InsertPersonTalkMsgRecord(ctx, record)
	if err != nil {
		logger.Errorf(ctx, "saveHiddenRecord.InsertPersonTalkMsgRecord failed. err=%v", err.Error())
		return record, err
	}

	// fromWindow
	if session.fromWindow == nil {
		session.fromWindow = &pbapi.PersonalTalkMessageTotalMgDbModel{
			Id:               snow_flake.GetSnowflakeID(),
			FromUserId:       proto.Int64(session.toUserId),
			ToUserId:         proto.Int64(session.curUserId),
			Status:           proto.Int32(int32(pbconst.BaseTabStatus_valid)),
			WorkId:           record.WorkId,
			UniqueId:         record.UniqueId,
			ModeType:         record.ModeType,
			WorkFlag:         proto.Int32(0),
			PushType:         record.PushType,
			LastMessageId:    proto.Int64(record.Id),
			LastReceivedTime: record.CreateTime,
			UnReadCount:      proto.Int32(0),
			InteractTimes:    proto.Int32(0),
			CreateTime:       proto.Int64(time.Now().UnixMilli()),
		}
		if session.curCoordinate != nil {
			session.fromWindow.FromLat = session.curCoordinate.Latitude
			session.fromWindow.FromLng = session.curCoordinate.Longitude
			session.fromWindow.FromProvince = session.curCoordinate.Province
			session.fromWindow.FromCity = session.curCoordinate.City
		}
		if session.workInfo != nil {
			session.fromWindow.ToLat = session.workInfo.WorkInfoDbModel.Latitude
			session.fromWindow.ToLng = session.workInfo.WorkInfoDbModel.Longitude
			session.fromWindow.ToProvince = session.workInfo.WorkInfoDbModel.Province
			session.fromWindow.ToCity = session.workInfo.WorkInfoDbModel.City
		}

		err = p.DataCache.InsertPersonTalkMsgTotalMgDBLd(ctx, session.fromWindow)
		if err != nil {
			logger.Errorf(ctx, "saveHiddenRecord.InsertPersonTalkMsgTotalMgDBLd failed. err=%v", err)
			return record, err
		}
	} else {
		changes := map[string]interface{}{}
		changes["lastReceivedTime"] = record.GetCreateTime()
		changes["lastMessageId"] = record.GetId()
		changes["workFlag"] = record.GetWorkFlag()
		changes["pushType"] = record.GetPushType()
		err = p.DataCache.UpdatePersonTalkMsgTotalMgDBLd(ctx, session.fromWindow.Id, changes, nil)
		if err != nil {
			logger.Errorf(ctx, "saveHiddenRecord.UpdatePersonTalkMsgTotalMgDBLd failed. err=%v", err)
			return record, err
		}
	}
	return record, nil
}

// 看是否插入拉黑消息
func (p *ContentMng) checkAndSaveDefriendRecord(ctx context.Context,
	header *pbapi.HttpHeaderInfo, req *pbapi.SendMsgReq,
	session *SendMsgSession,
	uniqueId int32) error {

	var err error = nil
	frequency := p.DataCache.GetTimesConfigLR(ctx, "times_black_list_message_frequency")
	if frequency > 0 &&
		(session.toWindow.GetInteractTimes()+1)%int32(frequency) == 0 {
		// 删除历史拉黑记录，
		cond := map[string]interface{}{
			"uniqueId":    uniqueId,
			"fromUserId":  session.toUserId,
			"messageType": int32(pbconst.MessageTypeEnum_msg_type_lahei),
			"status":      int32(pbconst.BaseTabStatus_valid),
		}
		update := map[string]interface{}{"status": 0}
		err = p.DataCache.UpdatePersonTalkMsgRecordDictByCond(ctx, cond, update)
		if err != nil {
			logger.Errorf(ctx, "checkAndSaveDefriendRecord update failed, err=%v", err)
			return err
		}
		//插入一条拉黑记录
		_, err = p.saveDefriendRecord(ctx, header, req, session, uniqueId)
	} else if frequency > 0 && session.toWindow.GetInteractTimes() == 0 {
		//插入一条拉黑记录
		_, err = p.saveDefriendRecord(ctx, header, req, session, uniqueId)
	}
	return err
}

// 保存拉黑消息
func (p *ContentMng) saveDefriendRecord(ctx context.Context,
	header *pbapi.HttpHeaderInfo, req *pbapi.SendMsgReq,
	session *SendMsgSession,
	uniqueId int32) (*pbapi.PersonalTalkMessageRecordMgDbModel, error) {

	curTimeMs := utils.GetCurTsMs()
	record := &pbapi.PersonalTalkMessageRecordMgDbModel{
		Id:          snow_flake.GetSnowflakeID(),
		ModeType:    proto.Int32(session.modeType),
		FromUserId:  proto.Int64(session.curUserId),
		ToUserId:    proto.Int64(session.toUserId),
		Content:     proto.String("拉黑提示"),
		CreateTime:  proto.Int64(curTimeMs),
		Status:      proto.Int32(int32(pbconst.BaseTabStatus_valid)),
		WorkId:      proto.Int64(session.workId),
		WorkFlag:    proto.Int32(0),
		Read:        proto.Int32(0),
		PushType:    proto.Int32(int32(pbconst.PushTypeEnum_push_type_not_anonymous)),
		MessageType: proto.Int32(int32(pbconst.MessageTypeEnum_msg_type_lahei)),
		UniqueId:    proto.Int32(uniqueId),
	}

	err := p.DataCache.InsertPersonTalkMsgRecord(ctx, record)
	if err != nil {
		logger.Errorf(ctx, "InsertPersonTalkMsgRecord failed. err=%v", err.Error())
		return record, err
	}

	p.KafkaProxy.SendSignTalkMsg(ctx, session.curUserInfo, record, nil, nil)
	return record, nil
}

// 发送猫友勋章
func (p *ContentMng) pushInteractMessage(ctx context.Context,
	session *SendMsgSession) error {

	curTimeMs := utils.GetCurTsMs()
	record := &pbapi.PersonalTalkMessageRecordMgDbModel{
		Id:          snow_flake.GetSnowflakeID(),
		ModeType:    proto.Int32(session.modeType),
		FromUserId:  proto.Int64(session.curUserId),
		ToUserId:    proto.Int64(session.toUserId),
		Content:     proto.String("猫友勋章"),
		CreateTime:  proto.Int64(curTimeMs),
		Status:      proto.Int32(int32(pbconst.BaseTabStatus_valid)),
		WorkId:      proto.Int64(session.workId),
		WorkFlag:    proto.Int32(0),
		Read:        proto.Int32(0),
		PushType:    proto.Int32(int32(pbconst.PushTypeEnum_push_type_not_anonymous)),
		MessageType: proto.Int32(int32(pbconst.MessageTypeEnum_msg_type_jpmy)),
		UniqueId:    proto.Int32(session.toWindow.GetUniqueId()),
	}

	err := p.DataCache.InsertPersonTalkMsgRecord(ctx, record)
	if err != nil {
		logger.Errorf(ctx, "InsertPersonTalkMsgRecord failed. err=%v", err.Error())
		return err
	}

	// 更新发送ptTotal记录
	updates := map[string]interface{}{"pushedInteract": true}
	p.DataCache.UpdatePersonTalkMsgTotalMgDBLd(ctx, session.toWindow.GetId(), updates, nil)
	p.DataCache.UpdatePersonTalkMsgTotalMgDBLd(ctx, session.fromWindow.GetId(), updates, nil)

	// 发送wb消息给对方
	p.KafkaProxy.SendSignTalkMsg(ctx, session.curUserInfo, record, nil, nil)

	// 发送wb消息给自己
	record.FromUserId = proto.Int64(session.toUserId)
	record.ToUserId = proto.Int64(session.curUserId)
	p.KafkaProxy.SendSignTalkMsg(ctx, session.toUserInfo, record, nil, nil)
	return nil
}

// 腾讯消息推送服务-信鸽 tsn pushSingleMessage
func (p *ContentMng) tsnPushSingleMessage(ctx context.Context, workId, fromUserId, userId int64,
	title, subTitle, content, icon *string, msgType int32) error {
	if userId <= 0 {
		return nil
	}
	pushContent := ""
	switch msgType {
	case int32(pbconst.MessageTypeEnum_msg_type_txt):
		pushContent = *content
	case int32(pbconst.MessageTypeEnum_msg_type_pic):
		pushContent = "[图片]"
	case int32(pbconst.MessageTypeEnum_msg_type_voice):
		pushContent = "[语音]"
	case int32(pbconst.MessageTypeEnum_msg_type_emoji):
		pushContent = "[表情]"
	default:
		pushContent = "一条消息"
	}
	p.KafkaProxy.TsnPushSingleMessage(ctx, workId, fromUserId, userId, title, subTitle, &pushContent, icon)
	return nil
}

// 保存私聊信息到 PersonalTalkMessageRecord
func (p *ContentMng) savePtTotal(ctx context.Context,
	header *pbapi.HttpHeaderInfo, req *pbapi.SendMsgReq,
	session *SendMsgSession,
	record *pbapi.PersonalTalkMessageRecordMgDbModel,
	uniqueId int32,
) error {

	if session.toWindow == nil {
		session.toWindow = &pbapi.PersonalTalkMessageTotalMgDbModel{
			Id:               snow_flake.GetSnowflakeID(),
			FromUserId:       proto.Int64(session.curUserId),
			ToUserId:         proto.Int64(session.toUserId),
			Status:           proto.Int32(int32(pbconst.BaseTabStatus_valid)),
			WorkId:           proto.Int64(session.workId),
			ModeType:         proto.Int32(session.modeType),
			WorkFlag:         record.WorkFlag,
			PushType:         record.PushType,
			UnReadCount:      proto.Int32(1), //
			LastMessageId:    proto.Int64(record.Id),
			LastReceivedTime: record.CreateTime,
			UniqueId:         record.UniqueId,
			//ZIndex:           0,
			InteractTimes:  proto.Int32(1),
			PushedInteract: proto.Bool(false),
			Platform:       proto.String(header.Platform),
			AppType:        proto.String(header.Apptype),
			CreateTime:     proto.Int64(time.Now().UnixMilli()),
		}
		if session.curCoordinate != nil {
			session.toWindow.FromLat = session.curCoordinate.Latitude
			session.toWindow.FromLng = session.curCoordinate.Longitude
			session.toWindow.FromProvince = session.curCoordinate.Province
			session.toWindow.FromCity = session.curCoordinate.City
		}
		if session.workInfo != nil {
			session.toWindow.ToLat = session.workInfo.WorkInfoDbModel.Latitude
			session.toWindow.ToLng = session.workInfo.WorkInfoDbModel.Longitude
			session.toWindow.ToProvince = session.workInfo.WorkInfoDbModel.Province
			session.toWindow.ToCity = session.workInfo.WorkInfoDbModel.City
		}

		err := p.DataCache.InsertPersonTalkMsgTotalMgDBLd(ctx, session.toWindow)
		if err != nil {
			return err
		}

		// 首次发送时候，加入拉黑消息。
		//_, err = p.saveDefriendRecord(ctx, header, req, session, record.GetUniqueId())
		//if err != nil {
		//	return err
		//}
	} else {
		// 更新消息
		changes := map[string]interface{}{}
		changes["lastReceivedTime"] = record.GetCreateTime()
		changes["lastMessageId"] = record.GetId()
		changes["workFlag"] = record.GetWorkFlag()
		changes["pushType"] = record.GetPushType()

		incrChanges := map[string]int{}
		incrChanges["unReadCount"] = 1
		incrChanges["interactTimes"] = 1
		err := p.DataCache.UpdatePersonTalkMsgTotalMgDBLd(ctx, session.toWindow.GetId(), changes, incrChanges)
		logger.Infof(ctx, "====update towindow, id=%v", session.toWindow.GetId())
		if err != nil {
			return err
		}
		// 插入新拉黑消息
		err = p.checkAndSaveDefriendRecord(ctx, header, req, session, uniqueId)
		if err != nil {
			return err
		}
	}

	//
	if session.fromWindow == nil {
		session.fromWindow = &pbapi.PersonalTalkMessageTotalMgDbModel{
			Id:               snow_flake.GetSnowflakeID(),
			FromUserId:       proto.Int64(session.toUserId),
			ToUserId:         proto.Int64(session.curUserId),
			Status:           proto.Int32(int32(pbconst.BaseTabStatus_valid)),
			WorkId:           record.WorkId,
			UniqueId:         record.UniqueId,
			ModeType:         record.ModeType,
			WorkFlag:         proto.Int32(0),
			PushType:         record.PushType,
			LastMessageId:    proto.Int64(record.GetId()),
			LastReceivedTime: record.CreateTime,
			UnReadCount:      proto.Int32(0),
			InteractTimes:    proto.Int32(0),
			CreateTime:       proto.Int64(time.Now().UnixMilli()),
		}
		if session.curCoordinate != nil {
			session.fromWindow.ToLat = session.curCoordinate.Latitude
			session.fromWindow.ToLng = session.curCoordinate.Longitude
			session.fromWindow.ToProvince = session.curCoordinate.Province
			session.fromWindow.ToCity = session.curCoordinate.City
		}
		if session.workInfo != nil {
			session.fromWindow.FromLat = session.workInfo.WorkInfoDbModel.Latitude
			session.fromWindow.FromLng = session.workInfo.WorkInfoDbModel.Longitude
			session.fromWindow.FromProvince = session.workInfo.WorkInfoDbModel.Province
			session.fromWindow.FromCity = session.workInfo.WorkInfoDbModel.City
		}

		err := p.DataCache.InsertPersonTalkMsgTotalMgDBLd(ctx, session.fromWindow)
		if err != nil {
			return err
		}
	} else {
		// 更新消息
		changes := map[string]interface{}{}
		changes["lastReceivedTime"] = record.GetCreateTime()
		changes["lastMessageId"] = record.GetId()
		changes["workFlag"] = record.GetWorkFlag()
		changes["pushType"] = record.GetPushType()
		err := p.DataCache.UpdatePersonTalkMsgTotalMgDBLd(ctx, session.fromWindow.GetId(), changes, nil)
		logger.Infof(ctx, "====update fromWindow, id=%v", session.fromWindow.GetId())
		if err != nil {
			return err
		}
	}
	return nil
}

// 更新作品回复数 以及 作者回复数字. limitKey.
func (p *ContentMng) updateReplyCount(ctx context.Context,
	header *pbapi.HttpHeaderInfo, req *pbapi.SendMsgReq,
	session *SendMsgSession, uniqueId int32) (int, error) {
	replyType := 0 // 1-用户首次回复帖子   2-作者首次回复当前用户
	if session.workId <= 0 {
		// 不做处理
		return replyType, nil
	}
	if session.workInfo.WorkInfoDbModel.GetUserId() != session.curUserId {
		// 用户回复帖子
		cond := map[string]interface{}{
			"fromUserId": session.curUserId,
			"toUserId":   session.toUserId,
			"modeType":   session.modeType,
			"workId":     session.workId,
			"status":     int32(pbconst.BaseTabStatus_valid)}
		records := p.DataCache.ListPersonTalkMsgRecordByConditionMgDB(ctx, cond)
		if len(records) == 0 {
			// 用户第一次回复该帖子
			replyType = 1
			///check1 检查curUser每日单聊上限。
			if !p.checkPtTalkReplyLimit(ctx, header, session.curUserInfo, session.toUserInfo.UserInfoDbModel.GetUserId()) {
				//检查不通过
				return replyType, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "今日单聊人数已达上限!")
			}

			// check2 检查帖子的可回复上限。
			timesCfgKey := "times_replay_limit"
			if session.curUserInfo.UserInfoDbModel.GetGender() == int32(pbconst.Sex_female) {
				timesCfgKey = timesCfgKey + "_female"
			} else {
				timesCfgKey = timesCfgKey + "_male"
			}
			workReplyCount := session.workInfo.WorkInfoDbModel.GetReplayCount()
			switch header.Apptype {
			case cm_const.AppTypeAppletQq, cm_const.AppTypeAppletWx:
				if header.Apptype == cm_const.AppTypeAppletQq {
					timesCfgKey = timesCfgKey + "_qq"
				} else {
					timesCfgKey = timesCfgKey + "_wx"
				}
				timesCfgKey = timesCfgKey + "_" + header.Platform

				timesCfg := p.DataCache.GetTimesConfigLR(ctx, timesCfgKey)
				logger.Infof(ctx, "=====timesCfgKey=%v, timsCfg=%v, workReplyCount=%v", timesCfgKey, timesCfg, workReplyCount)
				if timesCfg >= -1 &&
					workReplyCount >= int32(timesCfg) &&
					session.curUserInfo.MemberType <= 0 &&
					header.Platform == cm_const.PlatformAndroid {
					return replyType, errorcode.GenBusiErr(errorcode.BusinessError, "回复太火了，只有VIP才可回复")
				}
			case cm_const.AppTypeMobileIos:
				timesCfgKey = timesCfgKey + "_ios"
				timesCfg := p.DataCache.GetTimesConfigLR(ctx, timesCfgKey)
				logger.Infof(ctx, "=====timesCfgKey=%v, timsCfg=%v, workReplyCount=%v", timesCfgKey, timesCfg, workReplyCount)
				if timesCfg >= -1 &&
					workReplyCount >= int32(timesCfg) &&
					session.curUserInfo.MemberType <= 0 {
					return replyType, errorcode.GenBusiErr(errorcode.BusinessError, "回复太火了，只有VIP才可回复")
				}
			case cm_const.AppTypeMobileAndroid:
				timesCfgKey = timesCfgKey + "_android"
				timesCfg := p.DataCache.GetTimesConfigLR(ctx, timesCfgKey)
				logger.Infof(ctx, "=====timesCfgKey=%v, timsCfg=%v, workReplyCount=%v", timesCfgKey, timesCfg, workReplyCount)
				if timesCfg >= -1 &&
					workReplyCount >= int32(timesCfg) &&
					session.curUserInfo.MemberType <= 0 {
					return replyType, errorcode.GenBusiErr(errorcode.BusinessError, "回复太火了，只有VIP才可回复")
				}
			}

			// 保存作品消息
			p.saveWorkRecord(ctx, header, req, session, uniqueId)
			// 更新作品回复数
			p.DataCache.SetUserCommentCountRD(ctx, []int64{session.workId})
		}

	} else {
		// 作者回复帖子
		cond := map[string]interface{}{
			"uniqueId":   uniqueId,
			"fromUserId": session.curUserId,
			"workFlag":   0,
			"status":     int32(pbconst.BaseTabStatus_valid)}
		records := p.DataCache.ListPersonTalkMsgRecordByConditionMgDB(ctx, cond)
		if len(records) == 0 {
			replyType = 2
			logger.Infof(ctx, "author first time reply. req=%v", req)
			p.DataCache.SetAuthorReplyCountD(ctx, []int64{session.workId})
		}

	}
	return replyType, nil
}
