package work

import (
	"content_svr/app/maozhua_admin_svr/common/result"
	"github.com/go-playground/validator/v10"
	"net/http"

	"content_svr/app/maozhua_admin_svr/api/internal/logic/work"
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"github.com/zeromicro/go-zero/rest/httpx"
)

type verifyWorkUpdateResRequest struct {
	types.WorkUpdateRes
}

func (p *verifyWorkUpdateResRequest) Validate() error {
	valid := validator.New()
	if err := valid.Struct(p); err != nil {
		return err
	}
	return nil
}

func WorkUpdateHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req verifyWorkUpdateResRequest
		if err := httpx.Parse(r, &req); err != nil {
			result.ParamErrorResult(r, w, err)
			return
		}

		l := work.NewWorkUpdateLogic(r.Context(), svcCtx)
		resp, err := l.WorkUpdate(&req.WorkUpdateRes)
		result.HttpResult(r, w, resp, err)
	}
}
