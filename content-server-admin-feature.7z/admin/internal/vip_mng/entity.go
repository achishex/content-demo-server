package vip_mng

import (
	"time"
)

type VipOrderInfo struct {
	ID           int64
	VipOrderNo   string
	BizName      string
	MemberType   int
	VipOrderType int
	UserID       int64
	Days         int64
	OrderNo      int64
	Amount       int64
	PayChannel   int
	Refund       int
	CreateTime   *time.Time
	ExpireTime   *time.Time
}

func (*VipOrderInfo) TableName() string {
	return "vip_order_info"
}
