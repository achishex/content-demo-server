package content_mng

import (
	"context"
	"testing"
)

func TestCalcPredictFish(t *testing.T) {
	ctx := context.Background()
	t.Log(calcPredictFish(ctx, -1, -1, -1))
	t.Log(calcPredictFish(ctx, 0, -1, -1))
	t.Log(calcPredictFish(ctx, 0, 0, -1))
	t.Log(calcPredictFish(ctx, 0, 0, 0))
	t.Log(calcPredictFish(ctx, -1, 0, 0))
	t.Log(calcPredictFish(ctx, -1, -1, 0))
	t.Log(calcPredictFish(ctx, 100, 1000, 0))
	t.Log(calcPredictFish(ctx, 100, 1000, 1))
	t.Log(calcPredictFish(ctx, 1000, 100, 1))
}
