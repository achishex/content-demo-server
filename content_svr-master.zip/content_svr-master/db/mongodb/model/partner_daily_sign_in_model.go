package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

var _ PartnerDailySignInModel = (*customPartnerDailySignInModel)(nil)

type (
	// PartnerDailySignInModel is an interface to be customized, add more methods here,
	// and implement the added methods in customPartnerDailySignInModel.
	PartnerDailySignInModel interface {
		partnerDailySignInModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]PartnerDailySignIn, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*PartnerDailySignIn, error)
		InsertMany(ctx context.Context, data []*PartnerDailySignIn, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error)
		Upsert(ctx context.Context, filter, updateData, insertData any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error)
		Insert(ctx context.Context, data *PartnerDailySignIn) (*mongo.InsertOneResult, error)
	}

	customPartnerDailySignInModel struct {
		*defaultPartnerDailySignInModel
	}
)

// NewPartnerDailySignInModel returns a model for the mongo.
func NewPartnerDailySignInModel(cfg MonConfig, opts ...mon.Option) PartnerDailySignInModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), collectionNamePartnerDailySignIn, opts...)
	return &customPartnerDailySignInModel{
		defaultPartnerDailySignInModel: newDefaultPartnerDailySignInModel(conn),
	}
}

func (m *customPartnerDailySignInModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	} else {
		flagType = "default"
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customPartnerDailySignInModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customPartnerDailySignInModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]PartnerDailySignIn, error) {
	result := make([]PartnerDailySignIn, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customPartnerDailySignInModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*PartnerDailySignIn, error) {
	var data PartnerDailySignIn
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customPartnerDailySignInModel) InsertMany(ctx context.Context, data []*PartnerDailySignIn, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error) {
	now := time.Now().UnixMilli()
	insertData := make([]any, 0)
	for _, datum := range data {
		datum.CreateTime = now
		datum.UpdateTime = now
		insertData = append(insertData, datum)
	}
	return m.conn.InsertMany(ctx, insertData, opts...)
}

func (m *customPartnerDailySignInModel) Upsert(ctx context.Context, filter, updateData, insertData any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error) {
	update := bson.D{
		{"$set", updateData},
		{"$setOnInsert", insertData},
	}

	if len(opts) == 0 {
		opt := options.Update().SetUpsert(true)
		return m.conn.UpdateOne(ctx, filter, update, opt)
	} else {
		return m.conn.UpdateOne(ctx, filter, update, opts...)
	}
}

func (m *customPartnerDailySignInModel) Insert(ctx context.Context, data *PartnerDailySignIn) (*mongo.InsertOneResult, error) {
	//data.ID = primitive.NewObjectID()
	//data.ID = snow_flake.GetSnowflakeID()
	return m.defaultPartnerDailySignInModel.Insert(ctx, data)
}
