package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/pub/logger"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	"time"
)

// 0-没有互关  1-互关
func (p *DataCacheMng) GetUserFollowMgDBLd(ctx context.Context, userId, targetUserId int64) int32 {

	cacheKey := fmt.Sprintf(cache_const.SecretFollowLcache.KeyFmt, userId, targetUserId)
	expire := cache_const.SecretFollowLcache.Expire

	//从内存取
	cResp, exist := p.LocalCache.Get(cacheKey)
	if exist {
		resp, ok := cResp.(int32)
		if ok {
			return resp
		}
	}

	//从mg db取. 所有userFollow信息
	var mutual int32 = 0
	mutual, err := p.SecretUserFollowMgModel.GetBothFollow(ctx, userId, targetUserId)
	if err != nil {
		logger.Errorf(ctx, "get UserFollow failed. userId=%v, err=%v", userId, err.Error())
		return 0
	}

	//设置到内存
	bSuc := p.LocalCache.Set(cacheKey, mutual, go_cache.WithEx(time.Duration(expire)*time.Second))
	logger.Infof(ctx, "save UserFollow to local cache. cacheKey=%v, val=%v， bSuc=%v", cacheKey, mutual, bSuc)
	return mutual
}
