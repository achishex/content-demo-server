package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type INotificationReadCursorMgDbModel interface {
	GetItemByCond(ctx context.Context, eqConds map[string]interface{}) (*pbmgdb.PersonalUserNotificationReadCursor, error)
}

type NotificationReadCursorMgDbImpl struct {
	MgDB  *mongo.Database
	Table string
}

func NewSNotificationReadCursorMgModelImpl(db *mongo.Database) INotificationReadCursorMgDbModel {
	return &NotificationReadCursorMgDbImpl{
		MgDB:  db,
		Table: "personalUserNotificationReadCursor",
	}
}

func (p *NotificationReadCursorMgDbImpl) GetItemByCond(ctx context.Context, eqConds map[string]interface{}) (*pbmgdb.PersonalUserNotificationReadCursor, error) {
	if len(eqConds) <= 0 {
		return nil, nil
	}

	coll := p.MgDB.Collection(p.Table)
	filter := bson.D{}
	for k, v := range eqConds {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	cursor, err := coll.Find(ctx, filter)
	if err != nil {
		logger.Errorf(ctx, "find comment detail fail, err: %v", err)
		return nil, err
	}
	for cursor.Next(ctx) {
		retItems := &pbmgdb.PersonalUserNotificationReadCursor{}
		err = cursor.Decode(retItems)
		if err != nil {
			logger.Errorf(ctx, "get PersonalUserNotificationReadCursor fail, err: %v", err)
			return nil, err
		}
		return retItems, nil
	}
	return nil, nil
}
