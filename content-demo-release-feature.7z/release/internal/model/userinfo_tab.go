package model

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"context"
	"github.com/gogo/protobuf/proto"
	"gorm.io/gorm"
	"gorm.io/plugin/dbresolver"
)

type IUserinfoDbModelModel interface {
	// 更新用户信息
	UpdateById(ctx context.Context, userId int64, update *pbapi.UserinfoDbModel) error
	// 获取用户信息
	GetByUserId(ctx context.Context, userId int64) (*pbapi.UserinfoDbModel, error)
	// 获取多个用户信息
	GetByUserIds(ctx context.Context, userIds []int64) ([]*pbapi.UserinfoDbModel, error)

	ListItemsByCondition(ctx context.Context, condition map[string]interface{},
		page, size int32) ([]*pbapi.UserinfoDbModel, error)
	CountItemsByCondition(ctx context.Context, condition map[string]interface{}) (total int64, _ error)
	DictByUserId(ctx context.Context, userIds []int64) (map[int64]*pbapi.UserinfoDbModel, error)
	GetStatusByIds(ctx context.Context, userIds []int64) (map[int64]int32, error)
	DelUsersFromUserInfo(ctx context.Context, userIds []int64) error
}

type UserinfoDbModelImpl struct {
	DB *gorm.DB
}

func NewUserinfoDbModelImpl(db *gorm.DB) IUserinfoDbModelModel {
	return &UserinfoDbModelImpl{DB: db}
}

func (impl *UserinfoDbModelImpl) table() string {
	return "user_info"
}
func (impl *UserinfoDbModelImpl) GetStatusByIds(ctx context.Context, userIds []int64) (map[int64]int32, error) {
	if len(userIds) <= 0 {
		return nil, nil
	}
	var findData map[int64]int32
	dbHandler := impl.DB.WithContext(ctx).Table(impl.table())
	result := dbHandler.Select("user_id", "status").Where("user_id in ?", userIds).Find(&[]pbapi.UserinfoDbModel{})
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return findData, errors.Wrap(result.Error)
	}
	rows, err := result.Rows()
	if err != nil {
		return findData, err
	}
	for rows.Next() {
		user := pbapi.UserinfoDbModel{}
		if err := rows.Scan(&user.UserId, &user.Status); err != nil {
			continue
		}
		if findData == nil {
			findData = make(map[int64]int32)
		}
		findData[user.GetUserId()] = user.GetStatus()
	}
	return findData, errors.Wrap(result.Error)
}
func (impl *UserinfoDbModelImpl) DelUsersFromUserInfo(ctx context.Context, userIds []int64) error {
	if len(userIds) <= 0 {
		return nil
	}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Where("user_id in ? and status = ?", userIds, const_busi.UserInvalidStatus).Delete(&pbapi.UserinfoDbModel{})
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil
	}
	logger.Infof(ctx, "del status = 0, userid: %v from tab: %v", userIds, impl.table())
	return errors.Wrap(result.Error)
}
func (impl *UserinfoDbModelImpl) UpdateById(ctx context.Context, userId int64, update *pbapi.UserinfoDbModel) error {
	result := impl.DB.WithContext(ctx).Table(impl.table()).
		Where(&pbapi.UserinfoDbModel{UserId: proto.Int64(userId)}).Updates(&update)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil
	}
	return errors.Wrap(result.Error)
}

func (impl *UserinfoDbModelImpl) GetByUserIds(ctx context.Context, userIds []int64) ([]*pbapi.UserinfoDbModel, error) {
	result := make([]*pbapi.UserinfoDbModel, 0)
	err := impl.DB.WithContext(ctx).Table(impl.table()).Where(
		"status != ? and user_id in ?", 0, userIds).Find(&result).Error
	if err != nil {
		return nil, err
	}

	return result, err
}

func (impl *UserinfoDbModelImpl) GetByUserId(ctx context.Context, userId int64) (*pbapi.UserinfoDbModel, error) {
	model := pbapi.UserinfoDbModel{}
	result := impl.DB.WithContext(ctx).Clauses(dbresolver.Write).Table("user_info").
		Where(&pbapi.UserinfoDbModel{UserId: proto.Int64(userId)}).First(&model)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &model, errors.Wrap(result.Error)
}

func (impl *UserinfoDbModelImpl) ListItemsByCondition(ctx context.Context, condition map[string]interface{},
	page, size int32) ([]*pbapi.UserinfoDbModel, error) {
	offset := (page - 1) * size
	var items []*pbapi.UserinfoDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(int(size)).Offset(int(offset)).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *UserinfoDbModelImpl) CountItemsByCondition(ctx context.Context, condition map[string]interface{}) (total int64, _ error) {

	err := impl.DB.WithContext(ctx).Table(impl.table()).
		Where(condition).Count(&total).Error

	return total, errors.Wrap(err)
}

func (impl *UserinfoDbModelImpl) DictByUserId(ctx context.Context, userIds []int64) (map[int64]*pbapi.UserinfoDbModel, error) {
	var items []*pbapi.UserinfoDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Model(&pbapi.UserinfoDbModel{}).
		Where("user_id in ?", userIds).Find(&items)

	resp := make(map[int64]*pbapi.UserinfoDbModel)
	for _, item := range items {
		resp[item.GetUserId()] = item
	}
	return resp, errors.Wrap(result.Error)
}
