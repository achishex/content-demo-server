package utils

import (
	"testing"
)

func TestAESEncrypt(t *testing.T) {
	origData := []byte("13040833874")
	t.Log(len(origData), string(origData))

	//origData := GetCtx(conn)
	cryptSting, err := AESEncrypt(origData, AesUserKey)
	if err != nil {
		t.Fatal(err)
	}
	t.Log("cryptSting: ", cryptSting)

	de, err := AESDecrypt(cryptSting, AesUserKey)
	if err != nil {
		t.Fatal(err)
	}

	t.Log(len(de), string(de))

}

func TestAESDecrypt(t *testing.T) {
	b, err := AESDecrypt("rEUU/O3l56rk2AXPxyUYtA==", AesUserKey)
	if err != nil {
		t.Fatal(err)
	}

	t.Log(string(b))

}
