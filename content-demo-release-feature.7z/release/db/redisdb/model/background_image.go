package model

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/redisdb/model/internal"
	"context"
	"encoding/json"
	"fmt"
	"github.com/go-redis/redis/v8"
	"github.com/zeromicro/go-zero/core/logx"
	"time"
)

type BackgroundImageRedis struct {
	internal.RdsInfo
}

func NewBackgroundImageRedis(rds *redis.Client, env string) *BackgroundImageRedis {
	return &BackgroundImageRedis{
		RdsInfo: internal.RdsInfo{
			Env:    env,
			Expire: time.Hour * 24,
			Client: rds,
		},
	}
}

const (
	work = "work" // 动态
	talk = "talk" // 私聊
)

func (r *BackgroundImageRedis) getKey(category int32) string {
	key := ""
	switch category {
	case 1:
		key = work
	case 2:
		key = talk
	}

	return fmt.Sprintf("platform:%v:background:%s", r.Env, key)
}

func (r *BackgroundImageRedis) UpdateRds(ctx context.Context, data *model.BackgroundImage) error {
	result, err := r.DelRds(ctx, data.ID.Hex())
	if err != nil {
		return err
	}
	if result != 0 {
		logx.Info("本次更新 redis 中不存在该条数据")
	}
	return r.SetRds(ctx, data)
}

func (r *BackgroundImageRedis) SetRds(ctx context.Context, data *model.BackgroundImage) error {
	for _, category := range data.Operate {
		key := r.getKey(category)

		t, _ := json.Marshal(data)
		_, err := r.Client.ZAdd(ctx, key, &redis.Z{
			Score:  float64(data.TimePartStart),
			Member: string(t),
		}).Result()
		if err != nil {
			return err
		}
	}

	return nil
}

func (r *BackgroundImageRedis) DelRds(ctx context.Context, bgId string) (int64, error) {
	var count int64
	var operateAll = []int32{1, 2}
	for _, category := range operateAll {
		key := r.getKey(category)

		list, err := r.Client.ZRangeWithScores(ctx, key, 0, -1).Result()
		if err != nil {
			logx.Info(err)
			continue
		}
		if len(list) == 0 {
			continue
		}

		for _, z := range list {
			bg := map[string]interface{}{}
			err := json.Unmarshal([]byte(z.Member.(string)), &bg)
			if err != nil {
				logx.Error(err)
				continue
			}
			if bg["id"] == bgId {
				result, err := r.Client.ZRem(ctx, key, z.Member.(string)).Result()
				if err != nil {
					return 0, err
				}
				count += result
			}
		}

	}
	return count, nil
}
