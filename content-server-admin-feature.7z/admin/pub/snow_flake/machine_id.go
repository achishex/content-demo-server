package snow_flake

import (
	"fmt"
	"net"
	"os"
)

func GetHostnameOrIP() string {
	if hn, _ := os.Hostname(); hn != "" {
		return hn
	}

	if ipv4 := GetLocalIP(); ipv4 != "" {
		return ipv4
	}

	return ""
}

func GetLocalIP() string {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		fmt.Println("get net interface address failed, err = ", err.Error())
		return ""
	}
	for _, addr := range addrs {
		if ip, ok := addr.(*net.IPNet); ok && !ip.IP.IsLoopback() {
			if ip.IP.To4() != nil {
				return ip.IP.String()
			}
		}
	}
	return ""
}
