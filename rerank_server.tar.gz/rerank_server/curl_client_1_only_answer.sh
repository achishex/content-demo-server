#! /usr/bin/env bash 
echo "query: How do I adjust the image to high definition (HD)?"
curl -X POST http://127.0.0.1:7010/smart-customer-service/v1/rerank_after_retrieve \
  -H "Content-Type: application/json" \
  -d @- <<EOF | jq
{
    "reqId":"1000",
    "query": "How do I adjust the image to high definition (HD)?",
    "queryType": 0,
	"onlyAnswerDocs": [
            "ZIP supports automatic ±25° vertical keystone correction and manual adjustment. For horizontal alignment, make sure the lens is level with the projection surface.",
            "Go to \"Settings\" > \"Projection Settings\" to adjust the image size. Use the \"Focus\" button on the remote to focus the image.",
            "● Adjust the projector’s focus orkeystone settings using the remote.\n● Ensure the projection distance is within the lens’s optimal range.\n● Use a blower or soft brush to clean dust or smudges on the lens.",
            "Use the remote control to adjust the projector’s focus or keystone settings.Make sure the projection distance is within the lens’s effective focus range.Use an air blower or soft brush to clean dust or dirt off the lens.",
            "Method 1: Adjust projection distance (simplest)\n\nMove the projector closer to or farther from the wall to resize the image.\n\nMethod 2: Zoom settings (digital adjustment)\n\nSome projectors support a \"Zoom\" feature. Go to \"Settings\" > \"Projection Image\" > \"Image Zoom\" or \"Keystone Correction\" and adjust the size.\n\nMethod 3: Change projection mode (for ceiling/front/side projection)\n\nGo to \"Settings\" > \"Projection Mode\" and switch between front/rear/ceiling modes to ensure proper display.\n\n",
            "Use the remote control to adjust the projector’s focus or keystone settings.Make sure the projection distance is within the lens’s effective focus range.Use an air blower or soft brush to clean dust or dirt off the lens."
    ]
}
EOF
