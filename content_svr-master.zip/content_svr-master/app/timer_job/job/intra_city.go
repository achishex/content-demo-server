package job

import (
	"content_svr/db/dao"
	"content_svr/internal/data_cache"
	"content_svr/pub/logger"
	"context"
	"errors"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
)

// 同城群聊，每天00点重置火力值
func ResetFirepower(reader *dao.ManagerDB, cache data_cache.IDataCacheMng) {
	var ctx = context.Background()

	list, err := reader.IntraCity.FindAll(ctx, bson.M{"is_open_firepower": true})
	if err != nil && !errors.Is(err, mon.ErrNotFound) {
		logger.Error(ctx, "ClearFirepower:FindAll error:%v", err)
	}

	if errors.Is(err, mon.ErrNotFound) || len(list) == 0 {
		return
	}

	for _, item := range list {
		if err := cache.GetImpl().ResetIntraCityGroup(ctx, item.CityCode, item.GroupId); err != nil {
			logger.Errorf(ctx, "ClearFirepower:ResetIntraCityGroup error: %v", err)
		}
		logger.Infof(ctx, "ClearFirepower:ResetIntraCityGroup clear: cityCode:%v, groupId:%v", item.CityCode, item.GroupId)
	}
}
