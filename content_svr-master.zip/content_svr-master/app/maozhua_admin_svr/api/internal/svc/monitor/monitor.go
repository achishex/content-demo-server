package monitor

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"context"
	"encoding/json"
	"github.com/go-redis/redis/v8"
	"github.com/zeromicro/go-zero/core/logx"
)

type robotStatus uint8

const (
	_ robotStatus = iota
	open
	running
	stop
	remove
)

const (
	_ uint8 = iota
	commentCategory
)

var robotMonitor *Monitor

func InitRobotMonitor(writeDB *dao.ManagerDB) *Monitor {
	robotMonitor = newMonitor(writeDB)
	go robotMonitor.run() // 开启监听

	robots, err := writeDB.MzRobot.FindAll(context.Background(), nil)
	if err != nil {
		panic(err)
	}
	for i := 0; i < len(robots); i++ {
		w := NewWorker(&robots[i])
		robotMonitor.RegisterWorker(w)
	}
	return robotMonitor
}

// AppendRobotMonitorMessage 提供外部写入任务方法 map[机器人id]=data
func AppendRobotMonitorMessage(data map[string]interface{}) {
	robotMonitor.addMessage(data)
}

type Monitor struct {
	manageDB *dao.ManagerDB

	// 所有注册的机器人 map[robot 表 _id]机器人协程
	workers map[string]*Worker
	// 注册
	register chan *Worker
	// 注销
	unregister chan string
	// redis 订阅数据，从 content_srv 选择通知哪个机器人，对哪个用户发送消息  map[机器人id]=用户id
	subMessage chan map[string]interface{}

	ctx context.Context
}

func newMonitor(writeDB *dao.ManagerDB) *Monitor {
	return &Monitor{
		manageDB:   writeDB,
		register:   make(chan *Worker, 1),
		unregister: make(chan string),
		workers:    make(map[string]*Worker),
		subMessage: make(chan map[string]interface{}),
		ctx:        context.Background(),
	}
}

func (m *Monitor) run() {
	sub := m.subscript()
	defer func(sub *redis.PubSub) {
		_ = sub.Close()
	}(sub)

	for {
		select {
		case w := <-m.register:
			// 注册机器人
			if err := m.manageDB.MzRobot.UpdateStatus(m.ctx, w.robot.ID.Hex(), w.robot.Status); err != nil {
				if err != xerr.DbDoNothing {
					logx.Error(err)
				}
			}
			m.workers[w.robot.ID.Hex()] = w
			logx.Infof("机器人: %s 注册", w.robot.ID.Hex())
			go w.run()
		case id := <-m.unregister:
			// 注销机器人
			if w, ok := m.workers[id]; ok {
				if err := m.manageDB.MzRobot.UpdateStatus(m.ctx, id, false); err != nil {
					if err != xerr.DbDoNothing {
						logx.Error(err)
					}
				}
				w.notifyExit()
				delete(m.workers, id)
				//logx.Infof("机器人: %s 被删除", id)
			}
		case message := <-sub.Channel():
			// 通过redis获取任务
			data := map[string]interface{}{}
			err := json.Unmarshal([]byte(message.Payload), &data)
			if err != nil {
				logx.Error(err)
				continue
			}
			go m.addMessage(data)
		case data := <-m.subMessage:
			// 分发任务
			for robotId, message := range data {
				w, exist := m.workers[robotId]
				if !exist {
					continue
				}
				if w.status != running {
					// 其他状态丢弃
					continue
				}
				w.addTask(message)
			}

		}
		//fmt.Println("wwwwwww")
	}
}

func (m *Monitor) subscript() *redis.PubSub {
	sub := m.manageDB.MzRobot.Subscript()
	return sub
}

func (m *Monitor) addMessage(data map[string]interface{}) {
	select {
	case m.subMessage <- data:
	case <-m.ctx.Done():
		logx.Info("无法添加消息，机器人监听器已经退出")
	}
}

func (m *Monitor) RegisterWorker(w *Worker) {
	id := w.robot.ID.Hex()
	_, exist := m.workers[id]
	if exist {
		m.UnregisterWork(id)
	}

	select {
	case m.register <- w:
	case <-m.ctx.Done():
		logx.Info("无法注册，机器人监听器已经退出")
	}
}

func (m *Monitor) UnregisterWork(id string) {
	select {
	case m.unregister <- id:
	case <-m.ctx.Done():
		logx.Info("无法注销，机器人监听器已经退出")
	}
}

func (m *Monitor) ResetWorker(robot *model.MzRobot) {
	m.RegisterWorker(NewWorker(robot))
}
