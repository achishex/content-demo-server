package main

import (
	"content_svr/app/di"
	"content_svr/pub/logger"
	"context"
	"github.com/spf13/cobra"
	"go.uber.org/dig"
	"os"
)

func main() {
	root := &cobra.Command{
		Short:   "run job",
		Example: "./job SUBCMD [args]",
		Version: "0.1",
	}

	ctx := context.Background()
	c := di.NewContainer()
	err := c.Invoke(func(in CmdIn) {
		for _, cmd := range in.SubCmds {
			root.AddCommand(cmd)
		}
	})
	if err != nil {
		logger.Errorf(ctx, "di inject, err: %v", err)
		os.Exit(1)
	}

	err = root.Execute()
	if err != nil {
		logger.Errorf(ctx, "execute fail, err: %v", err)
		os.Exit(1)
	}
	logger.Infof(ctx, "exec succ")
}

type CmdIn struct {
	dig.In

	SubCmds []*cobra.Command `group:"jobsubcmd"`
}
