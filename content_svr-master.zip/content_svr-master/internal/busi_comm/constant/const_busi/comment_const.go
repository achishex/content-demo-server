package const_busi

// comment definition
const (
	CommentStatusUnread int32 = 0
	CommentStatusRead   int32 = 1
)

// 评论开关
const (
	WorkCommentStatusDisable int32 = 0 // close
	WorkCommentStatusEnable  int32 = 1 // open
)

// mongodb sort des asc
const (
	MongodbSortDes int32 = -1
	MongodbSortAes int32 = 1
)
const (
	InvalidCommentWorkExpireTm = 12 * 3600
)
const (
	CommentNumsOnWork          = 20
	MaxCommentNumsPerDayPerson = 1000
)

const (
	OfficialPublishWordCount = 500 // 官方账号，动态发布字数限制
	PublishWordCount         = 200 // 动态发布字数限制
	MaxCommentLen            = 100 // 评论字数限制
	ChatWordCount            = 200 // 私聊字数限制
)

const (
	WorkShowScopeGlobal = 1 //全局可见
	WorkShowScopeDis    = 2 //全局不可见
)

const (
	WorkRemindType    = 0 // 发表动态时 @ 消息
	CommentRemindType = 1 // 评论时 @ 消息
)
const (
	SortTypeDesc int32 = -1
	SortTypeAsc  int32 = 1
)
const (
	PageDown int32 = -1
	PageUp   int32 = 1
)

const (
	MutualNoticeMsgType  int32 = 9
	MutualWorkMsgType    int32 = 10
	MutualCommentMsgType int32 = 11
)

const (
	HomePagePrivateMessageDefaultWorkId = 100
	MutualUserMessageWorkId             = -1
)

// const (
//
//	HomePagePrivateMessageFreeTalkedMaxTimes = 4
//
// )
const (
	HomePagePrivateMessageSessionValidDays = 3
)

const WorkIdOnMutualUsers int32 = -1

const (
	LikedOp   int32 = 1
	UnLikedOp int32 = 2
)
const (
	CommentValid   int32 = 1
	CommentInvalid int32 = 2
)

const (
	UserUnRegister int32 = 0
	UserRegistered int32 = 1
)

const (
	_ int32 = iota
	CommentStatusOpen
	CommentStatusClose
)

// 评论类型 1:文字；2:表情；3:语音;默认是文字；99: 表情包
const (
	_                    = iota
	CommentTypeText      = 1
	CommentTypeImage     = 2
	CommentTypeVoice     = 3
	CommentTypeLike      = 4 // 给动态点赞
	CommentTypeReplyText = 12
	CommentTypeEmote     = 99
)

const (
	_ int32 = iota
	CommentOpen
	CommentClose
)

const (
	KoLaHallOfFameNoSettlement  = 0
	KoLaHallOfFameHasSettlement = 1
)

const (
	WalletMsgTypeAward    = 1 //奖励/入账
	WalletMsgTypeWithdraw = 2 //提现
	WalletMsgTypeExpense  = 3 //花费
)

// 1 猫爪运动 2 星座运势 3 可乐名人堂 4 游戏 5 表情广场 6:签到 7 统一路由跳转 8:同城群聊
const (
	DiscoveryTypeSport     = 1
	DiscoveryTypeStarSign  = 2
	DiscoveryTypeKola      = 3
	DiscoveryTypeGame      = 4
	DiscoveryTypeMeme      = 5
	DiscoveryTypeSignIn    = 6
	DiscoveryTypeJump      = 7
	DiscoveryTypeIntraCity = 8
	DiscoveryTypeBottle    = 9
)
