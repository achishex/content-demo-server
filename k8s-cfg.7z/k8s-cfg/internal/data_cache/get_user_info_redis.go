package data_cache

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/pub/logger"
	"content_svr/pub/user"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"strconv"
)

func (p *DataCacheMng) GetUserInfoTalkMode(ctx context.Context, userId int64) int32 {
	// todo
	redisKey := getRdsKeyUserInfoConfig(userId)
	ret, err := p.RedisCli.HGet(ctx, redisKey, "talkMode").Result()

	if len(ret) == 0 {
		userExt, err := p.UserInfoExtMgModel.GetByUserId(ctx, userId)
		if err != nil {
			return const_busi.TalkModeClose
		}

		var talkMode = userExt.GetTalkMode()
		if talkMode == const_busi.TalkModeUnknown {
			userInfo := p.getUserInfoModelLD(ctx, userId, false)
			adult, err := user.JudgeAdult(userInfo.GetBirth())
			if err != nil {
				logger.Error(ctx, "talkMode JudgeAdult", err)
			}
			if !adult {
				talkMode = const_busi.TalkModeClose
			}
		}

		if userExt.GetUlevel() < 4 { // 小于4级用户 全部为闭关模式
			talkMode = const_busi.TalkModeClose
		}

		err = p.SetUserInfoTalkMode(ctx, userId, talkMode)
		if err != nil {
			logger.Error(ctx, "SetUserInfoTalkMode", err)
		}
		//logger.Errorf(ctx, "talkMode 数据库: %d, talkMode=%v", userId, talkMode)
		return talkMode
	} else {
		userExt, err := p.UserInfoExtMgModel.GetByUserId(ctx, userId)
		if err != nil {
			return const_busi.TalkModeClose
		}
		if userExt.GetUlevel() < 4 { // 小于4级用户 全部为闭关模式
			return const_busi.TalkModeClose
		}
	}

	if err != nil && err != redis.Nil { //获取成功
		logger.Error(ctx, fmt.Sprintf("talkMode redis qurey failed. key=%v", redisKey), err)
	}

	talkMode, err := strconv.Atoi(ret)
	if err != nil {
		return 0
	}

	return int32(talkMode)
}

func (p *DataCacheMng) SetUserInfoTalkMode(ctx context.Context, userId int64, mode int32) error {
	redisKey := getRdsKeyUserInfoConfig(userId)
	return p.RedisCli.HSet(ctx, redisKey, "talkMode", mode).Err()
}
