package once

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/pub/logger"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"log"
	"time"
)

func calcSportActivityFish(mngDB *mongo.Client) {
	// 聚合查询出 sportActivityCollection 表中 activity_status 为 2 所有合计信息
	// 更新所有 PersonalUserCollection 表

	db := mngDB.Database(config.ServerConfig.MongodbConfig.DBName)
	sportActivityCollection := db.Collection("user_sport_activity_detail")
	PersonalUserCollection := db.Collection("personalUserAccount")

	ctx := context.Background()
	filter := bson.D{
		{
			"activity_status", bson.D{
				{"$eq", const_busi.SportActivityOpenAward},
			},
		},
	}
	pipeline := []bson.M{
		{"$match": filter},
		{"$group": bson.M{
			"_id":        "$user_id",
			"fish_total": bson.M{"$sum": "$award_fish_nums"},
		},
		},
	}
	cur, err := sportActivityCollection.Aggregate(ctx, pipeline)
	if err != nil {
		log.Fatal(err)
	}

	userFish := map[interface{}]interface{}{}
	for cur.Next(ctx) {
		var m map[string]interface{}
		err := cur.Decode(&m)
		if err != nil {
			logger.Error(ctx, "cur.Decode", err)
			continue
		}

		userFish[m["_id"]] = m["fish_total"]
	}

	for userId, fish := range userFish {
		filter = bson.D{
			{"userId", userId},
		}
		update := bson.D{
			{"$set", map[string]interface{}{
				"fish": fish,
			}},
		}
		updateResult, err := PersonalUserCollection.UpdateOne(ctx, filter, update)
		if err != nil {
			log.Println(err)
		}

		if updateResult.ModifiedCount == 0 {
			log.Println("没有修改任何东西", userId, fish)
		}
		time.Sleep(time.Millisecond * 500)
	}

}
