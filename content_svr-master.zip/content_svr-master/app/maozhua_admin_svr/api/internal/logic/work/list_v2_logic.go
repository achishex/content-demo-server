package work

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/db/mysqldb/model"
	"content_svr/pub/utils"
	"context"
	"time"

	"github.com/zeromicro/go-zero/core/logx"
)

type ListV2Logic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewListV2Logic(ctx context.Context, svcCtx *svc.ServiceContext) *ListV2Logic {
	return &ListV2Logic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ListV2Logic) ListV2(req *types.WorkListResV2) (resp *types.WorkListResp, err error) {
	var restrict = true
	for key, value := range req.Where {
		switch key {
		case "work_ids":
			if v, ok := value.(string); ok {
				restrict = false
				req.Where["work_ids"] = utils.Str2Int64List(v)
			}
		case "user_ids":
			if v, ok := value.(string); ok {
				restrict = false
				req.Where["user_ids"] = utils.Str2Int64List(v)
			}
		case "create_time_start", "create_time_end":
			// todo 限制时间范围，比如不超过三个月
			restrict = false
		}
	}

	if restrict {
		// 当没有填时间范围和id时候，只读取7天前
		now := time.Now().AddDate(0, 0, -7)
		req.Where["create_time_start"] = now.Format("2006-01-02 15:04:05")
	}

	workInfoList, total, err := l.svcCtx.WriteDB.PersonalBottleWorks.FindPage(l.ctx, req)
	if err != nil {
		return nil, err
	}
	userIds := make([]int64, 0)
	workIds := make([]int64, 0)
	for _, work := range workInfoList {
		userIds = append(userIds, work.UserID)
		workIds = append(workIds, work.ID)
	}
	userIds = utils.DuplicateByInt64(userIds)
	workIds = utils.DuplicateByInt64(workIds)

	userInfos, err := l.svcCtx.WriteDB.UserInfo.FindByUserIds(l.ctx, userIds)
	if err != nil {
		return nil, err
	}
	userInfoMap := map[int64]*model.UserInfo{}
	for _, info := range userInfos {
		if info == nil {
			continue
		}
		userInfoMap[info.UserID] = info
	}

	_dbWorkObjectAttr := l.svcCtx.WriteDB.WorkObjectAttr
	workAttr, err := _dbWorkObjectAttr.WithContext(l.ctx).Where(_dbWorkObjectAttr.WorkID.In(workIds...)).Find()
	if err != nil {
		return nil, err
	}
	attrMap := map[int64]*model.WorkObjectAttr{}
	for _, attr := range workAttr {
		if attr == nil {
			continue
		}
		attrMap[attr.WorkID] = attr
	}

	wl := make([]types.WorkItem, 0)
	for _, work := range workInfoList {
		userInfo := userInfoMap[work.UserID]
		if userInfo == nil {
			continue
		}

		attrInfo := attrMap[work.ID]
		var workImageUrl string
		if attrInfo != nil {
			workImageUrl = utils.FixImageUrl(l.svcCtx.Config.ImageHost, attrInfo.ObjectID)
		}

		item := types.WorkItem{
			ID:                  work.ID,
			UserId:              work.UserID,
			Gender:              userInfo.Gender,
			AppType:             work.AppType,
			Type:                work.Type,
			Title:               work.Title,
			WorkObjAttrUrl:      workImageUrl,
			VerifyStatus:        work.VerifyStatus,
			VerifyTime:          work.VerifyTime,
			PersonalLetterCount: work.CommentCount,
			CommentCount:        work.NewCommentCount,
			VisitorCount:        work.VisitorCount,
			Status:              work.Status,
			CreateTime:          work.CreateTime,
			VerifyUser:          work.VerifyUser,
			Arrested:            work.Arrested,
			Ip:                  work.IP,
			ReplayCount:         work.ReplayCount,
			ReportTimes:         work.ReportTimes,
			NewCommentCount:     work.NewCommentCount,
			ShowScope:           work.ShowScope,
		}

		wl = append(wl, item)
	}

	resp = &types.WorkListResp{
		WorkList: wl,
		Total:    total,
	}

	return resp, nil
}
