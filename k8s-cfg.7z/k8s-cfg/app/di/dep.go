package di

import (
	"content_svr/config"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/mg_model"
	"content_svr/internal/model"
	"content_svr/internal/model/im"
	"content_svr/pub/logger"
	"context"
	"fmt"
	rdsV8 "github.com/go-redis/redis/v8"
	"go.mongodb.org/mongo-driver/mongo"
	"gorm.io/gorm"
	"time"
)

func NewKafkaProxyByConf() kafka_proxy.IKafkaProxy {
	return kafka_proxy.NewKafkaProxyImpl(config.ServerConfig.KafkaConfig)
}

func NewMongoDBByConf() (*mongo.Client, *mongo.Database, error) {
	mgcli, err := mg_model.NewMongoDBInstance(config.ServerConfig.MongodbConfig)
	if err != nil {
		return nil, nil, err
	}
	timeoutCtx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()
	err = mgcli.Ping(timeoutCtx, nil)
	if err != nil {
		logger.Error(context.Background(), "ping mongo fail, err: %v", err)
		return nil, nil, err
	}
	return mgcli, mgcli.Database(config.ServerConfig.MongodbConfig.DBName), nil
}
func NewPlatformAndIMDB() (*gorm.DB, im.IMDB, error) {
	db, err := model.NewDBInstance(config.ServerConfig.MysqlConfig)
	if err != nil {
		return nil, nil, fmt.Errorf("new platform db instansce failed, err: %v", err)
	}
	//初始化IM DB
	dbIm, err := model.NewDBInstance(config.ServerConfig.MysqlImConfig)
	if err != nil {
		return nil, nil, fmt.Errorf("new im db instansce failed, err: %v", err)
	}
	return db, im.IMDB(dbIm), nil
}

func NewRdsClientByConf() *rdsV8.Client {
	return newRdsClient(config.ServerConfig.RedisConfig.Addr, config.ServerConfig.RedisConfig.Pwd)
}

func newRdsClient(addr, pwd string) *rdsV8.Client {
	client := rdsV8.NewClient(&rdsV8.Options{
		Addr:         addr,
		Password:     pwd,
		DB:           0,
		ReadTimeout:  2 * time.Minute,
		WriteTimeout: 1 * time.Minute,
		PoolTimeout:  2 * time.Minute,
		IdleTimeout:  10 * time.Minute,
		PoolSize:     1000,
	})
	_, err := client.Ping(context.Background()).Result()
	if err != nil {
		panic(fmt.Sprintf("redis init failed. err:%v", err.Error()))
	}
	return client
}
