package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/busi_comm/trans"
	"content_svr/internal/data_cache"
	"content_svr/internal/mg_model"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"content_svr/setting"
	"context"
	"encoding/json"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

func (p *ContentMng) checkWorkLogic(workInfo *pbapi.PersonalBottleWorksDbModel) error {
	//审核状态 0待审核 1审核通过 2审核拒绝 5隐藏
	if workInfo.GetVerifyStatus() == 2 /*refuse*/ || workInfo.GetVerifyStatus() == 5 /*omit*/ {
		return errorcode.GenBusiErr(errorcode.DATA_INVALID, "work is invalid")
	}
	//TODO: others...
	return nil
}
func (p *ContentMng) SetWorkCommentStatus(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.WorkCommentEnableReq) error {
	_, err := p.getUserInfo(ctx, header)
	if err != nil {
		return err
	}
	if req.GetOp() != const_busi.WorkCommentStatusEnable && req.GetOp() != const_busi.WorkCommentStatusDisable { //0 enable, 1 disable
		return errorcode.GenBusiErr(errorcode.MIDAS_PARAMS_ERROR, "op not is 0/1,invalid")
	}
	workInfo, err := p.DataCache.GetImpl().PersonBottleWorksModel.GetByWorkId(ctx, req.GetWorkId())
	if err != nil || workInfo == nil {
		return errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, fmt.Sprintf("workid: %v not exit", req.GetWorkId()))
	}

	err = p.checkWorkLogic(workInfo)
	if err != nil {
		return err
	}
	return p.DataCache.GetImpl().WorkCommentStatusDbModel.SetStatus(ctx, req)
}

func (p *ContentMng) checkContentSafe(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.WorkCommentPushReq, toUser, fromUser int64) bool {
	var (
		audit = &pbmgdb.SecretAuditMgDbModel{
			Platform:       1,
			EventId:        shumei_proxy.EventIDComment,
			UserId:         toUser,
			WorkId:         req.GetWorkId(),
			CommentId:      req.GetBeCommentId(),
			Content:        req.GetTitle(),
			FeedbackStatus: 2,
			IsRecirculate:  2,
			CreateTime:     time.Now().UnixMilli(),
		}
	)

	if req.CommentType == const_busi.CommentTypeText {
		bRet := true // 默认通过

		//过滤@昵称内容
		content, err := utils.RegFilterRemind.Replace(req.GetTitle(), "", -1, -1)
		if err != nil {
			logger.Errorf(ctx, "checkContentSafe RegFilterRemind:Replace failed", err)
			content = req.GetTitle()
		}

		kwpass, innerResp, err := p.InnerProxy.CheckPublicTxtContent(ctx, &pbapi.PublicTxtCheckReq{
			Content:    content,
			FromUserId: fromUser,
		})
		if err != nil {
			logger.Errorf(ctx, "check comment content req fail, %v", err)
		}

		//本平台拦截
		if !kwpass {
			audit.Id = snow_flake.GetSnowflakeID()
			audit.HookType = cm_const.HookTypeMine
			audit.AuditType = cm_const.AuditTypeText
			audit.EventId = shumei_proxy.EventIDComment
			audit.AuditResp = fmt.Sprintf("本平台内容拦截，结果：%+v", innerResp)
			_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
		}

		bRet = bRet && kwpass
		shumeiPass := true
		verifyStatus, resp, err := p.ShumeiProxy.CheckTxt(ctx, req.GetTitle(), fromUser, shumei_proxy.EventIDMessage)
		if err != nil {
			logger.Errorf(ctx, "shumei check comment fail, %v", err)
		}

		if verifyStatus != "" && verifyStatus != shumei_proxy.TextRiskLevelPASS {
			if resp != nil {
				auditResp, _ := json.Marshal(resp)
				audit.Id = snow_flake.GetSnowflakeID()
				audit.RequestId = resp.RequestID
				audit.RiskLevel = resp.RiskLevel
				audit.AuditResp = string(auditResp)
				audit.HookType = cm_const.HookTypeShuMei
				audit.AuditType = cm_const.AuditTypeText
				audit.EventId = shumei_proxy.EventIDComment
				_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
			}
			shumeiPass = false // 不通过
		}
		bRet = bRet && shumeiPass
		logger.Infof(ctx, "coment content_check, kwResult=%v, shumei.Result=%v, bReturn=%v,content=%v",
			kwpass, verifyStatus, bRet, req.GetTitle())
		return bRet
	} else if req.CommentType == const_busi.CommentTypeEmote {
		if ok, resp := p.checkImage(ctx, req.GetCommentObject().GetObjectId(), fromUser, true, req.GetCommentObject().GetMemeId(), shumei_proxy.EventIDComment); ok == false {
			if resp != nil {
				auditResp, _ := json.Marshal(resp)
				audit.RequestId = resp.RequestID
				audit.RiskLevel = resp.RiskLevel
				audit.AuditResp = string(auditResp)
				audit.HookType = cm_const.HookTypeShuMei
				audit.AuditType = cm_const.AuditTypeEmote
				audit.ImgUrl = req.GetCommentObject().GetObjectId()
				audit.BussId = req.GetCommentObject().GetMemeId()
				_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
			}
			logger.Errorf(ctx, "check emote fail")
			return false
		}
	} else if req.CommentType == const_busi.CommentTypeImage {
		if ok, resp := p.checkImage(ctx, req.GetCommentObject().GetObjectId(), fromUser, false, 0, shumei_proxy.EventIDComment); ok == false {
			if resp != nil {
				auditResp, _ := json.Marshal(resp)
				audit.RequestId = resp.RequestID
				audit.RiskLevel = resp.RiskLevel
				audit.AuditResp = string(auditResp)
				audit.HookType = cm_const.HookTypeShuMei
				audit.AuditType = cm_const.AuditTypeImg
				audit.ImgUrl = req.GetCommentObject().GetObjectId()
				audit.BussId = req.GetCommentObject().GetMemeId()
				_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
			}
			logger.Errorf(ctx, "check pic fail")
			return false
		}
	}
	return true
}

func (p *ContentMng) PushWorkComment(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.WorkCommentPushReq, data *pbapi.WorkCommentPushResp) (int64, error) {
	type procLogicInterface func() (int64, error)
	var commentUserInfo *data_cache.UserInfoLocal
	var permissionProcess []procLogicInterface
	var workInfos *pbapi.PersonalBottleWorksDbModel
	var workUserInfo *pbapi.UserinfoDbModel

	commentUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil {
		return 0, err
	}

	workInfos, err = p.DataCache.GetImpl().PersonBottleWorksModel.GetByWorkId(ctx, req.GetWorkId())
	if err != nil || workInfos == nil {
		return int64(errorcode.CommentWorkNotExist.UserErrCode),
			errorcode.GenBusiErr(errorcode.CommentWorkNotExist,
				fmt.Sprintf("%s%s", "", errorcode.CommentWorkNotExist.UserMsg))
	}

	workUserInfo, err = p.DataCache.GetUserBasicInfo(ctx, workInfos.GetUserId(), false)
	if err != nil {
		return 0, err
	}

	if len([]rune(req.GetTitle())) > const_busi.MaxCommentLen {
		logger.Errorf(ctx, "comment too long, work id: %v", req.GetWorkId())
		return 0, errorcode.GenBusiErr(errorcode.BusinessError, fmt.Sprintf("评论太长"))
	}

	permissionProcess = append(permissionProcess, func() procLogicInterface {
		return func() (int64, error) {
			iBlackHouse := p.DataCache.GetImpl().GetUserInBlackFlag(ctx, commentUserInfo.UserInfoDbModel.GetUserId())
			if iBlackHouse {
				return int64(errorcode.CommentUserInBlackHouse.UserErrCode), errorcode.CommentUserInBlackHouse
			}
			return 0, nil
		}
	}())

	//checkWorkNotExist 动态是否存在
	permissionProcess = append(permissionProcess, func() procLogicInterface {
		return func() (int64, error) {
			if workInfos.GetStatus() == 0 { // 已被删除
				return int64(errorcode.CommentWorkNotExist.UserErrCode),
					errorcode.GenBusiErr(errorcode.CommentWorkNotExist,
						fmt.Sprintf("%s%s", workUserInfo.GetNickName(), errorcode.CommentWorkNotExist.UserMsg))
			}
			if p.DataCache.GetImpl().CheckUserBlackListMgDBLD(ctx, workUserInfo.GetUserId(), commentUserInfo.UserInfoDbModel.GetUserId()) {
				return int64(errorcode.CommentWorkNotExist.UserErrCode),
					errorcode.GenBusiErr(errorcode.CommentWorkNotExist,
						fmt.Sprintf("%s%s", workUserInfo.GetNickName(), errorcode.CommentWorkNotExist.UserMsg))
			}
			//
			return 0, nil
		}
	}())

	if commentUserInfo.UserInfoDbModel.GetUserType() != 2 { // 官方账号不受次数限制
		memberType := commentUserInfo.MemberType
		if memberType != 0 {
			// 会员暂时不处理
		}

		//  用户1天发评论数限制 和 单条评论数限制
		permissionProcess = append(permissionProcess, func() procLogicInterface {
			return func() (int64, error) {
				// 装载redis中的评论最大值设置
				//p.DataCache.LoadTimesConfigComment(ctx, "max_comment_count")

				ulevel := commentUserInfo.PsecretUserExtInfo.GetUlevel()
				levelInfo := const_busi.GetLevelCfg(ulevel)
				var maxCount int64
				maxCount = levelInfo.CommentMaxLimit
				// 读取当前总已评论数
				nums, err := p.DataCache.GetCommentNumsForCommenter(ctx, commentUserInfo.UserInfoDbModel.GetUserId())
				if err != nil {
					return int64(errorcode.CommentOpFail.UserErrCode),
						errorcode.GenBusiErr(errorcode.CommentOpFail, "redis op fail")
				}
				if nums >= maxCount {
					return int64(errorcode.CommentNumsUsedUpByUser.UserErrCode), errorcode.CommentNumsUsedUpByUser
				}

				if workUserInfo.GetUserType() == 2 { // 官方账号发布的动态，单独配置评论数限制
					maxCount = setting.Maozhua.OfficialWorkSingleMaxCommentNums.Get()
				} else {
					maxCount = levelInfo.CommentSingleLimit
				}
				logger.Infof(ctx, "comment_offical_work,author %v,userid %v, workid %v, maxCount %v, userType %v",
					workInfos.GetUserId(), commentUserInfo.UserInfoDbModel.GetUserId(), req.GetWorkId(), maxCount, workUserInfo.GetUserType())
				// 读取当前该条workId评论数
				nums, err = p.DataCache.GetWorkCommenterCommentNums(ctx, commentUserInfo.UserInfoDbModel.GetUserId(), req.GetWorkId())
				if err != nil {
					return int64(errorcode.CommentOpFail.UserErrCode),
						errorcode.GenBusiErr(errorcode.CommentOpFail, "redis op fail")
				}
				if nums >= maxCount {
					return int64(errorcode.CommentNumsUsedUpForWork.UserErrCode), errorcode.CommentNumsUsedUpForWork
				}
				return 0, nil
			}
		}())

		permissionProcess = append(permissionProcess, func() procLogicInterface {
			return func() (int64, error) {
				if req.GetCommentType() == const_busi.CommentTypeEmote &&
					commentUserInfo.PsecretUserExtInfo.GetUlevel() < const_level.UserLevel5 {
					// 表情类型需要五级
					return int64(errorcode.UserLevelNotEnough.UserErrCode), errorcode.UserLevelNotEnough
				}
				return 0, nil
			}
		}())

		// 判断是否内容合法
		permissionProcess = append(permissionProcess, func() procLogicInterface {
			return func() (int64, error) {
				if commentUserInfo.UserInfoDbModel.GetUserId() == cm_const.OfficialMZUserId {
					return 0, nil
				}
				pass := p.checkContentSafe(ctx, header, req, workInfos.GetUserId(), commentUserInfo.UserInfoDbModel.GetUserId())
				if pass == false {
					return int64(errorcode.CommentUnlawfully.UserErrCode), errorcode.CommentUnlawfully
				}
				return 0, nil
			}
		}())

		// 用户1天发评论数 和 单条评论数 计数+1
		permissionProcess = append(permissionProcess, func() procLogicInterface {
			return func() (int64, error) {
				_ = p.DataCache.IncrUserSingleMaxCommentCount(ctx, commentUserInfo.UserInfoDbModel.GetUserId(), 1)
				num, _ := p.DataCache.IncrUserMaxCommentCount(ctx, commentUserInfo.UserInfoDbModel.GetUserId(), req.GetWorkId(), 1)
				//用户在单条动态评论数达到某次数后的人数+1
				if num > int64(config.ServerConfig.ContentConfig.HighPlusContentCommentNum) {
					_ = p.DataCache.IncCommentCountPeopleCountGtN(ctx, req.GetWorkId(), workUserInfo.GetUserId(), commentUserInfo.UserInfoDbModel.GetUserId(), 1)
				}
				return 0, nil
			}
		}())
	}

	//checkWorkCommentEnable 动态是否开启评论
	permissionProcess = append(permissionProcess, func() procLogicInterface {
		return func() (int64, error) {
			worksId := []int64{req.GetWorkId()}
			ret, err := p.GetCommentStatusOnWork(ctx, worksId)
			if err != nil {
				return 0, err
			}
			//
			if ret == nil || len(*ret) <= 0 {
				return 0, nil
			}
			enable, ok := (*ret)[req.GetWorkId()]
			if !ok {
				return 0, nil
			}
			if enable == const_busi.WorkCommentStatusDisable { // 评论关闭
				return int64(errorcode.CommentDisableForWork.UserErrCode),
					errorcode.GenBusiErr(errorcode.CommentDisableForWork,
						fmt.Sprintf("%s%s", workUserInfo.GetNickName(), errorcode.CommentDisableForWork.UserMsg))
			}
			return 0, nil
		}
	}())

	// commentPermissionEnd
	permissionProcess = append(permissionProcess, func() procLogicInterface {
		return func() (int64, error) {
			return 0, nil
		}
	}())

	for _, v := range permissionProcess { //错误时， 首先验证 err； ret是错误码，//成功： err == nil, ret 是comment_id
		if ret, err := v(); err != nil {
			return ret, err
		}
	}

	/////////////////
	var commentData *pbmgdb.WorksCommentDetailMgDbModel
	var beginProcess []procLogicInterface
	checkCommenterForbid := append(beginProcess, func() procLogicInterface {
		return func() (int64, error) {
			//1:启用，2:限时封禁，3:永久封禁
			switch commentUserInfo.UserInfoDbModel.GetCommentLock() {
			case 1:
				return 0, nil
			case 2:
				return int64(errorcode.UserCommentLockInterim.UserErrCode), errors.Wrap(errorcode.UserCommentLockInterim)
			case 3:
				return int64(errorcode.UserCommentLockPermanent.UserErrCode), errors.Wrap(errorcode.UserCommentLockPermanent)
			default:
				return int64(errorcode.UserCommentLockInterim.UserErrCode), errors.Wrap(errorcode.UserCommentLockInterim)
			}
		}
	}())

	buildCommentData := append(checkCommenterForbid, func() procLogicInterface {
		return func() (int64, error) {
			crateTimeNow := time.Now()
			createTimeNowMill := crateTimeNow.UnixMilli()
			data.CreateTime = &createTimeNowMill
			formatTimeStr := crateTimeNow.Format("2006-01-02 15:04:05.000")

			if req.GetLongitude() > 0 && req.GetLatitude() > 0 {
				header.Longitude = req.GetLongitude()
				header.Latitude = req.GetLatitude()
			}

			coord := p.DataCache.GetUserCoordinateV2(ctx, commentUserInfo.UserInfoDbModel.GetUserId(), header)
			commentData = &pbmgdb.WorksCommentDetailMgDbModel{
				Id:              snow_flake.GetSnowflakeID(),
				WorkId:          proto.Int64(req.GetWorkId()),
				UserId:          proto.Int64(commentUserInfo.UserInfoDbModel.GetUserId()),
				Comment:         proto.String(req.GetTitle()),
				Longitude:       proto.Float64(coord.GetLongitude()),
				Latitude:        proto.Float64(coord.GetLatitude()),
				Province:        proto.String(coord.GetProvince()),
				City:            proto.String(coord.GetCity()),
				CreateTime:      &formatTimeStr,
				UpdateTime:      &formatTimeStr,
				Ip:              proto.String(coord.GetIp()),
				Status:          proto.Int32(const_busi.CommentOpen),
				CommentType:     &req.CommentType,
				BeCommentId:     req.BeCommentId,
				BeCommentUserId: req.BeCommentUserId,
			}
			return 0, nil
		}
	}())

	buildCommentAttr := append(buildCommentData, func() procLogicInterface {
		return func() (int64, error) {
			commentData.CommentObject = req.CommentObject
			return 0, nil
		}
	}())

	buildFirstComment := append(buildCommentAttr, func() procLogicInterface {
		return func() (int64, error) {
			// 第一条评论, 赋予 沙发王者 称号

			//回复评论不参与
			if commentData.GetCommentType() == const_busi.CommentTypeReply {
				return 0, nil
			}

			eqConds := map[string]interface{}{
				"work_id": req.GetWorkId(),
				"status":  const_busi.CommentStatusRead,
			}
			retData, err := p.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentDetails(ctx, eqConds, nil, nil, nil, 1)
			if err != nil {
				return 0, err
			}
			if !(retData == nil || len(retData) == 0) {
				// 已存在评论
				return 0, err
			}

			now := time.Now()
			endTime := time.Date(now.Year(), now.Month(), now.Day(),
				0, 0,
				0, 0, now.Location()).Add(time.Hour * 24)
			expire := endTime.Sub(now)
			if err := p.setMedal(ctx, commentUserInfo.UserInfoDbModel.GetUserId(), 11, int64(expire.Seconds())); err != nil {
				return 0, err
			}
			return 0, nil
		}
	}())

	writeDownToDb := append(buildFirstComment, func() procLogicInterface {
		return func() (int64, error) {
			err := p.DataCache.GetImpl().WorkCommentDetailMgModel.Insert(ctx, commentData)
			if err != nil {
				return int64(errorcode.INTERNAL_DB_EXCEPTION.UserErrCode), err
			}
			return commentData.GetId(), nil
		}
	}())

	lastOpToCommentPush := append(writeDownToDb, func() procLogicInterface {
		return func() (int64, error) {
			return 0, nil // -1: omit return value
		}
	}())

	commentId := int64(0)
	for _, v := range lastOpToCommentPush {
		var commentIdBuild = int64(0)
		if commentIdBuild, err = v(); err != nil {
			return 0, err
		}
		if commentIdBuild <= 0 {
			continue
		}
		commentId = commentIdBuild
	}
	if commentId > 0 {
		p.AsyncUpdateCommentGroupNewMsg(ctx, req.GetWorkId(), commentUserInfo.UserInfoDbModel.GetUserId(),
			workInfos.GetUserId(), workInfos.CreateTime)

		// 修改redis评论数成功后，修改数据库评论数
		err = p.DataCache.IncWorkInfoToNewCommentCount(ctx, workInfos.GetId(), 1)
		if err != nil {
			logger.Error(ctx, "IncWorkInfoToNewCommentCount: ", err)
		}

		if err := p.notifyCommentRobot(ctx, workInfos); err != nil {
			logger.Error(ctx, "notifyCommentRobot", err)
		}

		//计算评论人数
		err := p.DataCache.IncWorkInfoToNewCommentPeopleCount(ctx, workInfos.GetId(), workUserInfo.GetUserId(), commentUserInfo.UserInfoDbModel.GetUserId(), 1)
		if err != nil {
			logger.Error(ctx, " : ", err)
		}

		p.SuperiorContentFilter(ctx, workInfos, commentUserInfo.UserInfoDbModel.GetUserId())
	}

	// 发at通知
	NewRemindOpsWriteHandle(commentId, req, p, workInfos, commentUserInfo).WriteRemind(ctx, header)
	// 评论at群通知
	if err = p.processCommentAtGroup(ctx, commentUserInfo, workInfos, commentId, req.RemindGroup); err != nil {
		logger.Errorf(ctx, "processCommentAtGroup fail, err: %v", err)
	}

	//回复评论类型发私聊信息 && 自己评论自己不发消息
	if req.CommentType == const_busi.CommentTypeReply && commentUserInfo.UserInfoDbModel.GetUserId() != req.GetBeCommentUserId() {
		p.ReplyCommentMsgAndNotice(ctx, header, req, workInfos, commentId)
	}

	return commentId, nil
}
func (p *ContentMng) SuperiorContentFilter(ctx context.Context, work *pbapi.PersonalBottleWorksDbModel, commentUserId int64) error {
	superiorContentHandler := NewSuperiorContentInstance(p, work, commentUserId)

	noDo, err := superiorContentHandler.RecordValidCommentUserNums(ctx)
	if err != nil {
		logger.Errorf(ctx, "record valid comment fail, err: %v", err)
		return err
	}
	if noDo == false {
		return nil
	}
	award := float64(0.0)
	if award, err = superiorContentHandler.CheckStatus(ctx); err != nil {
		logger.Errorf(ctx, "check status fail, err: %v", err)
		return err
	}

	go superiorContentHandler.SettlementImmediately(ctx, work.GetUserId(), award)
	return err
}

// ReplyCommentMsgAndNotice 回复评论发送私聊消息
func (p *ContentMng) ReplyCommentMsgAndNotice(
	ctx context.Context,
	header *pbapi.HttpHeaderInfo,
	req *pbapi.WorkCommentPushReq,
	workInfo *pbapi.PersonalBottleWorksDbModel,
	commentId int64,
) {
	var (
		workObj     []*pbapi.WorkObjectAttrRequest = nil
		workObjAttr *pbapi.WorkObjectAttrDbModel   = nil
	)

	if workInfo.GetType() == const_busi.WorkTypeImage {
		workIdList := []int64{workInfo.GetId()}
		ret, err := p.DataCache.GetImpl().WorkObjectAttrModel.DictByWorkIds(ctx, workIdList)
		if err == nil {
			if obj, ok := ret[workInfo.GetId()]; ok {
				if len(obj) > 0 {
					workObjAttr = obj[0]
					workObj = append(workObj, &pbapi.WorkObjectAttrRequest{
						Type:      workObjAttr.Type,
						Width:     workObjAttr.Width,
						High:      workObjAttr.High,
						ObjectId:  workObjAttr.ObjectId,
						Thumbnail: workObjAttr.Thumbnail,
						ImgMd5:    workObjAttr.ImgMd5,
					})
				}
			}
		}
	}

	bbUserInfo, _ := p.GetUserInfo(ctx, config.ServerConfig.CommentConfig.ReplyCommentOfficialAccount) //bb user id

	workRemindInfo := &WorkRemindInfo{
		curUserInfo: bbUserInfo,
		toUserId:    req.GetBeCommentUserId(),
		work:        workInfo,
		workObj:     workObj,
		reqClientId: nil,
		coordinate:  nil,
		msgType:     int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply),
		remindId:    req.GetBeCommentId(), //被评论的评论id, 1 level
		commentId:   commentId,            //回复评论的id, 2 level
		header:      header,
	}
	p.UpdateMsgAndNotice(ctx, workRemindInfo)
}

func (p *ContentMng) notifyCommentRobot(ctx context.Context, workInfos *pbapi.PersonalBottleWorksDbModel) error {
	// 从redis读取机器人发布规则
	rules, err := p.DataCache.GetRobotCommentRules(ctx)
	if err != nil {
		logger.Error(ctx, "DataCache.GetRobotCommentRules", err)
	}
	if len(rules) == 0 {
		// 无机器人活动
		return nil
	}
	message := map[string]int64{}
	count := workInfos.GetNewCommentCount() + 2
	for _, rule := range rules {
		if rule.CommentIndex != count {
			continue
		}
		// 满足规则通知机器人
		message[rule.ID.Hex()] = workInfos.GetId()
		count++
	}
	if len(message) == 0 {
		return nil
	}

	if err := p.DataCache.PushMessageToRobot(message); err != nil {
		return err
	}

	return nil
}

func TimeStrToSecond(str string) (int64, error) {
	if len(str) <= 0 {
		return 0, errors.New("input time is nil")
	}
	timeVal, err := time.ParseInLocation("2006-01-02 15:04:05", str, time.Local)
	if err != nil {
		return 0, errors.New("tran str time to time format fail")
	}
	return timeVal.UnixMilli(), nil
}
func (p *ContentMng) AsyncUpdateCommentGroupNewMsg(ctx context.Context, workId int64, commentorUserId int64, work_user_id int64, workCreateTime *string) {
	func(ctx context.Context, workId int64, commentorUserId int64, workCreateTime *string) {
		//
		work_create_time, err := TimeStrToSecond(*workCreateTime)
		curComment := &pbmgdb.UserCommentUnreadWork{
			UserId:         proto.Int64(commentorUserId),
			WorkId:         proto.Int64(workId),
			Status:         proto.Int32(const_busi.CommentStatusRead),
			WorkCreateTime: &work_create_time,
		}
		//存在 work_id, user_id 相同记录则更新，否则就插入一条新的记录
		err = p.DataCache.GetImpl().UserCommentUnReadWorkMgModel.InsertOrUpdate(
			ctx, curComment)
		if err != nil {
			logger.Errorf(ctx, "update unread or insert unread item to tab:CommentUserUnreadWork fail, work_id: %v, commentor_id: %v",
				workId, commentorUserId)
			return
		}
		eq_conds := map[string]interface{}{
			"work_id": workId,
			"status":  const_busi.CommentStatusRead,
		}
		neq_conds := map[string]interface{}{
			"user_id": commentorUserId,
		}
		update_kv := map[string]interface{}{
			"status": const_busi.CommentStatusUnread,
		}
		err = p.DataCache.GetImpl().UserCommentUnReadWorkMgModel.UpdateItemGeneral(ctx, eq_conds, neq_conds, update_kv)
		if err != nil {
			logger.Errorf(ctx, "update other user on tab:CommentUserUnreadWork from read to unread fail, %v", err)
		}
	}(ctx, workId, commentorUserId, workCreateTime)
}

/*
delete comment operators
*/
func (p *ContentMng) DeleteWorkComment(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.WorkCommentDeleteReq) error {
	//1. 只有workid的用户或则comment_id的user_id人可以删除，其他的人来请求删除都会失败。
	login_user_info, err := p.getUserInfo(ctx, header)
	if err != nil || login_user_info == nil {
		return errorcode.GenBusiErr(errorcode.MIDAS_LOGIN_ERROR, "get login user inf fail")
	}
	work_infos, err := p.DataCache.GetImpl().PersonBottleWorksModel.GetByWorkId(ctx, req.GetWorkId())
	if err != nil || work_infos == nil || work_infos.GetStatus() == 0 {
		logger.Errorf(ctx, "work not exist, workid: %v, comment id: %v", req.GetWorkId(), req.GetCommentId())
		return errors.Wrap(errorcode.CommentByWorkDeleteFail) //已经删除
	}
	toDelComment, _ := p.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentById(ctx, req.GetCommentId())
	if toDelComment.GetStatus() != 1 {
		return errors.Wrap(errorcode.CommentDeleteFail) //已经删除
	}

	check_db := func(work_info *pbapi.PersonalBottleWorksDbModel, login_user_id int64) func() error {
		conds := make(map[string]interface{})
		conds["_id"] = req.GetCommentId()
		conds["work_id"] = work_info.GetId()

		new_values := make(map[string]interface{})
		new_values["status"] = 2 // 0: 无效， 1: 有效  2:删除

		if work_info.GetUserId() != login_user_id {
			conds["user_id"] = login_user_id
		}
		return func() error {
			err = p.DataCache.IncWorkInfoToNewCommentCount(ctx, req.GetWorkId(), -1)
			_ = p.DataCache.IncWorkInfoToNewCommentPeopleCount(ctx, req.GetWorkId(), -1, login_user_id, -1)
			return p.DataCache.GetImpl().WorkCommentDetailMgModel.DeleteItemByCond(ctx, conds, new_values)
		}
	}(work_infos, login_user_info.UserInfoDbModel.GetUserId())

	if err := check_db(); err != nil {
		logger.Errorf(ctx, "delete comment fail, err: %v, work_id: %v, comment_id: %v", err, req.GetWorkId(), req.GetCommentId())
		return errors.Wrap(errorcode.CommentByWorkDeleteFail)
	}
	//清楚评论有效人数。userId, workId, del validCommentUserId, del to do settlement.
	//func() {
	//	if toDelComment == nil {
	//		return
	//	}
	//	//NewSuperiorContentInstance(p, nil, 0).PenalizeWorkAwardWithComment(ctx, req.GetWorkId(), req.GetCommentId(), toDelComment.GetUserId())
	//}()

	return nil
}

/*
拉取评论详情处理逻辑
返回评论详情
*/
func (p *ContentMng) getLikeForUser(ctx context.Context, retData *pbapi.WorkCommentPullResponse, loginUserId, workId int64) *pbapi.WorkCommentPullResponse {
	for index, _ := range retData.Contents {
		if retData.Contents[index] == nil {
			continue
		}
		eqConds := map[string]interface{}{
			"workId":      workId,
			"commentId":   retData.Contents[index].GetId(),
			"likerUserId": loginUserId,
		}
		specialField := map[string]int32{
			"doLike": 1,
		}
		retData.Contents[index].HasLiked = proto.Int32(const_busi.UnLikedOp)
		doLikeRet, err := p.DataCache.GetImpl().CommentLikeDetailMgModel.GetLikeStatus(ctx, eqConds, nil, nil, specialField)
		if err != nil || len(doLikeRet) <= 0 {
			continue
		}
		if v, ok := doLikeRet[0]["doLike"]; ok {
			retData.Contents[index].HasLiked = proto.Int32(v.(int32))
		}
	}
	return retData
}
func (p *ContentMng) PullWorkCommentsDetail(ctx context.Context, header *pbapi.HttpHeaderInfo,
	req *pbapi.WorkCommentPullReq) (*pbapi.WorkCommentPullResponse, error) {

	pullSize := int32(30)
	lastCommentId := int64(0)
	sortType := const_busi.SortTypeDesc
	var upOrDown int32 = const_busi.PageDown // -1: 往下翻，1：往上翻
	var loginUserInfo *data_cache.UserInfoLocal
	var retData *pbapi.WorkCommentPullResponse

	checkReqParam := func() error {
		var err error
		loginUserInfo, err = p.getUserInfo(ctx, header)
		//允许游客模式拉取评论
		//if err != nil || loginUserInfo == nil {
		//	return errorcode.GenBusiErr(errorcode.MIDAS_LOGIN_ERROR, "get login user inf fail")
		//}
		///
		if req.GetWorkId() <= 0 {
			return errorcode.GenBusiErr(errorcode.DATA_INVALID, "work id not set")
		}
		if req.GetRows() > 0 {
			pullSize = req.GetRows()
		}
		if req.GetLastId() > 0 {
			lastCommentId = req.GetLastId()
		}
		if req.GetPullDirection() == 0 || req.GetPullDirection() == const_busi.PageDown {
			upOrDown = const_busi.PageDown
		} else {
			upOrDown = const_busi.PageUp
		}
		//..
		var workInfos *pbapi.PersonalBottleWorksDbModel
		var workUserInfo *pbapi.UserinfoDbModel
		workInfos, err = p.DataCache.GetImpl().PersonBottleWorksModel.GetByWorkId(ctx, req.GetWorkId())
		if err != nil || workInfos == nil {
			return errorcode.GenBusiErr(errorcode.CommentWorkNotExist,
				fmt.Sprintf("%s%s", "", errorcode.CommentWorkNotExist.UserMsg))
		}
		//
		workUserInfo, _ = p.DataCache.GetUserBasicInfo(ctx, workInfos.GetUserId(), false)
		//
		if workInfos.GetStatus() == 0 { // 作品状态,0:无效；1:有效
			return errorcode.GenBusiErr(errorcode.CommentWorkNotExist,
				fmt.Sprintf("%s%s", workUserInfo.GetNickName(),
					errorcode.CommentWorkNotExist.UserMsg))
		}

		worksId := []int64{req.GetWorkId()}
		ret, err := p.GetCommentStatusOnWork(ctx, worksId)
		if err != nil {
			return err
		}
		//
		if ret == nil || len(*ret) <= 0 {
			return errorcode.GenBusiErr(errorcode.CommentDisableForWork,
				fmt.Sprintf("%s%s", workUserInfo.GetNickName(),
					errorcode.CommentDisableForWork.UserMsg))
		}
		enable, ok := (*ret)[req.GetWorkId()]
		if !ok || enable == const_busi.WorkCommentStatusDisable {
			return errorcode.GenBusiErr(errorcode.CommentDisableForWork,
				fmt.Sprintf("%s%s", workUserInfo.GetNickName(),
					errorcode.CommentDisableForWork.UserMsg))
		}
		//游客模式不作拉黑判断
		if loginUserInfo != nil {
			if p.DataCache.GetImpl().CheckUserBlackListMgDBLD(ctx, workUserInfo.GetUserId(), loginUserInfo.UserInfoDbModel.GetUserId()) {
				return errorcode.GenBusiErr(errorcode.HomePagePrivateMsgInBlack, "被动态作者拉黑")
			}
		}
		return nil
	}
	if err := checkReqParam(); err != nil {
		if err == errorcode.HomePagePrivateMsgInBlack {
			return retData, nil
		}
		return nil, err
	}
	eqConds := map[string]interface{}{
		"work_id": req.GetWorkId(),
		"status":  const_busi.CommentStatusRead,
	}
	largeConds := map[string]interface{}{
		"_id": lastCommentId,
	}
	lessConds := map[string]interface{}{}
	//
	sortField := map[string]int32{
		"_id": sortType,
	}
	limits := pullSize
	//

	var err error
	if lastCommentId <= 0 {
		if upOrDown == const_busi.PageUp {
			sortField["_id"] = const_busi.SortTypeAsc
			largeConds["_id"] = 0
			retData, err = p.DataCache.GetImpl().WorkCommentDetailMgModel.GetAllItems(ctx, eqConds, largeConds, lessConds, sortField, limits)
			if err != nil {
				return nil, err
			}
			if retData == nil || len(retData.Contents) <= 0 {
				return nil, nil
			}
		} else {
			largeConds["_id"] = 0
			retData, err = p.DataCache.GetImpl().WorkCommentDetailMgModel.GetAllItems(ctx, eqConds, largeConds, lessConds, sortField, limits)
			if err != nil {
				return nil, err
			}
			if retData == nil || len(retData.Contents) <= 0 {
				return nil, nil
			}
		}
	} else {
		if upOrDown == const_busi.PageDown { //往下翻,找小于lastCommentId的数据
			largeConds = nil
			lessConds["_id"] = lastCommentId
			retData, err = p.DataCache.GetImpl().WorkCommentDetailMgModel.GetAllItems(ctx, eqConds, largeConds, lessConds, sortField, limits)
			if err != nil || retData == nil || len(retData.Contents) <= 0 {
				return nil, err
			}
		} else { // 往上翻, 找大于lastCommentId的数据, 返回从小到大排序
			lessConds = nil
			largeConds["_id"] = lastCommentId
			sortField["_id"] = const_busi.SortTypeAsc
			retData, err = p.DataCache.GetImpl().WorkCommentDetailMgModel.GetAllItems(ctx, eqConds, largeConds, lessConds, sortField, limits)
			if err != nil || retData == nil || len(retData.Contents) <= 0 {
				return nil, err
			}
		}
	}
	if retData == nil {
		return &pbapi.WorkCommentPullResponse{}, nil
	}
	var commenterUserInfo map[int64]*pbapi.UserinfoDbModel = make(map[int64]*pbapi.UserinfoDbModel)
	for _, v := range retData.Contents {
		if v == nil || v.GetFromUserId() <= 0 {
			continue
		}
		commenterUserInfo[v.GetFromUserId()] = &pbapi.UserinfoDbModel{}
	}

	for k, _ := range commenterUserInfo {
		data, err := p.DataCache.GetUserBasicInfo(ctx, k, false)
		if err != nil {
			continue
		}
		commenterUserInfo[k] = data
	}

	for index, _ := range retData.Contents {
		if retData.Contents[index] == nil {
			continue
		}
		userId := retData.Contents[index].GetFromUserId()
		userInfoData, err := p.GetUserInfo(ctx, userId)
		if err != nil {
			return retData, err
		}
		var originCommentUserInfo *pbapi.SimpleUserInfo
		if retData.Contents[index].UserInfo != nil {
			originCommentUserInfo = retData.Contents[index].UserInfo

		}
		if userInfoData == nil {
			continue
		}
		retData.Contents[index].UserInfo = trans.TransUserInfoLocalToUserSimple(userInfoData)
		if originCommentUserInfo != nil {
			retData.Contents[index].UserInfo.Province = originCommentUserInfo.Province
			retData.Contents[index].UserInfo.City = originCommentUserInfo.City
		}

		if retData.Contents[index].GetBeCommentUserInfo() != nil && retData.Contents[index].BeCommentUserInfo.UserId > 0 {
			beCommentUserInfoData, err := p.GetUserInfo(ctx, retData.Contents[index].BeCommentUserInfo.UserId)
			if err != nil {
				return retData, err
			}
			if beCommentUserInfoData != nil {
				retData.Contents[index].BeCommentUserInfo.NickName = beCommentUserInfoData.UserInfoDbModel.GetNickName()
			}
		}
	}

	// at 群
	for index := 0; index < len(retData.Contents); index++ {
		if retData.Contents[index] == nil {
			continue
		}

		remindGroup, err2 := p.DataCache.GetImpl().AtDetailMgModel.ListCommentAtGroup(ctx, retData.Contents[index].GetId())
		if err2 != nil {
			logger.Errorf(ctx, "ListCommentAtGroup fail, err: %v", err2)
			continue
		}

		retData.Contents[index].RemindGroup = remindGroup
	}
	// at 用户
	for index, _ := range retData.Contents {
		if retData.Contents[index] == nil {
			continue
		}
		remindInfos, err := NewRemindOpsReadHandle(p, req.WorkId, retData.Contents[index].Id, const_busi.CommentRemindType).ReadRemind(ctx)
		if err != nil || remindInfos == nil || len(remindInfos) <= 0 {
			continue
		}
		//
		for remindIndex, _ := range remindInfos {
			if remindInfos[remindIndex] == nil {
				continue
			}
			retData.Contents[index].RemindNode = append(retData.Contents[index].RemindNode, &pbapi.RemindUserNode{
				UserId: remindInfos[remindIndex].RemindUserId,
				OffSet: remindInfos[remindIndex].RemindOffSet,
				Size:   remindInfos[remindIndex].RemindSize,
			})
		}
	}

	if loginUserInfo != nil {

		// 根据黑名单多虑评论
		var arrSubResponse []*pbapi.WorkCommentBrief
		for index, _ := range retData.Contents {
			if retData.Contents[index] == nil {
				continue
			}
			commentUserId := retData.Contents[index].GetFromUserId() // 评论的userid
			myUserId := loginUserInfo.UserInfoDbModel.GetUserId()

			// 1 对方在我的黑名单
			if p.DataCache.CheckUserBlackListMgDBLD(ctx, myUserId, commentUserId) {
				continue
			}

			// 2 我在对方的黑名单
			if p.DataCache.CheckUserBlackListMgDBLD(ctx, commentUserId, myUserId) {
				continue
			}

			arrSubResponse = append(arrSubResponse, retData.Contents[index])
		}
		retData.Contents = arrSubResponse

		return p.getLikeForUser(ctx, retData, loginUserInfo.UserInfoDbModel.GetUserId(), req.GetWorkId()), nil
	}

	return retData, nil
}

/*
拉取用户未读评论对应的帖子
*/
//先拉未读评论的帖子;后续通过其他接口去拉每个帖子的评论详情。
func (p *ContentMng) PullUnreadCommentWorkProc(ctx context.Context, header *pbapi.HttpHeaderInfo, pull_size int32, work_id int64) ([]*pbapi.GetReplyMsgSimple, error) {
	var login_user_info *data_cache.UserInfoLocal
	var err error
	login_user_info, err = p.getUserInfo(ctx, header)
	if err != nil || login_user_info == nil || login_user_info.UserInfoDbModel.GetUserId() <= 0 {
		return nil, errorcode.GenBusiErr(errorcode.MIDAS_LOGIN_ERROR, "get login user inf fail")
	}
	conds := make(map[string]interface{})
	conds["user_id"] = login_user_info.UserInfoDbModel.GetUserId()
	conds["status"] = const_busi.CommentStatusUnread // 0,  0: 未读， 1: 已读

	large_conds := make(map[string]interface{})
	if work_id > 0 {
		large_conds["work_id"] = work_id
	}
	// 这条动态发布超过12个小时后，有新的评论也不会再推送。
	time_limit := time.Now().UnixMilli() - const_busi.InvalidCommentWorkExpireTm*1000
	large_conds["work_create_time"] = time_limit

	sorts := make(map[string]int32)
	sorts["work_id"] = const_busi.MongodbSortDes // 1 asc, -1 dec
	limit := pull_size

	works, err := p.DataCache.GetImpl().UserCommentUnReadWorkMgModel.QueryItems(ctx, conds, large_conds, sorts, limit)
	if err != nil || works == nil || len(works) <= 0 {
		return nil, err
	}
	resp := make([]*pbapi.GetReplyMsgSimple, 0)

	works_enable_comments, err := p.DataCache.GetImpl().WorkCommentStatusDbModel.BulkGetStatus(ctx, works)
	if err != nil || works_enable_comments == nil || len(*works_enable_comments) <= 0 {
		logger.Errorf(ctx, "all work comment disable")
		return nil, nil
	}

	enable_comment_on_work := const_busi.WorkCommentStatusEnable
	for _, work_id := range works {
		one_ret := &pbapi.GetReplyMsgSimple{}
		one_ret.WorkId = work_id
		if enable, ok := (*works_enable_comments)[work_id]; !ok || enable == const_busi.WorkCommentStatusDisable {
			continue
		}

		work_info, err := p.DataCache.GetWorkInfoLocal(ctx, work_id, false)
		if err != nil || work_info == nil {
			continue
		}
		work_user_id_info, err := p.DataCache.GetUserInfoLocal(ctx, header, work_info.WorkInfoDbModel.GetUserId(), false)
		if err != nil || work_user_id_info == nil {
			continue
		}

		one_ret.Works = trans.TransWorkInfoLocalScoreInfoToWorksSimple(work_info, work_user_id_info, false, nil)
		if work_info.WorkInfoDbModel.GetStatus() != int32(pbconst.BaseTabStatus_valid) {
			one_ret.Works.Deleted = true
		}
		one_ret.Works.EnableComment = &enable_comment_on_work
		resp = append(resp, one_ret)
	}
	for i, _ := range resp {
		v := resp[i]
		//ctx_copy := ctx
		//var ctx_copy context.Context

		user_id := login_user_info.UserInfoDbModel.GetUserId()
		func(ctx_copy context.Context) {
			from_status := int32(const_busi.CommentStatusUnread)
			to_status := int32(const_busi.CommentStatusRead)
			_ = p.DataCache.GetImpl().UserCommentUnReadWorkMgModel.UpdateItem(ctx_copy, v.GetWorkId(), from_status, to_status, user_id)
		}(ctx)
	}

	// fill remind_group
	for i := 0; i < len(resp); i++ {
		if resp[i].Works != nil {
			remindGroup, _ := p.DataCache.GetImpl().AtDetailMgModel.ListWorkAtGroup(ctx, resp[i].Works.GetId())
			resp[i].Works.RemindGroup = remindGroup
		}
	}

	return resp, nil
}

/*
拉取帖子发表评论状态
*/
func (p *ContentMng) GetCommentStatusOnWork(ctx context.Context, works_ids []int64) (*map[int64]int32, error) {
	if len(works_ids) <= 0 {
		return nil, errors.New("input is invalids")
	}
	//
	ret, err := p.DataCache.GetImpl().WorkCommentStatusDbModel.BulkGetStatus(ctx, works_ids)
	if err != nil {
		logger.Error(ctx, "get comment status fail", err)
		return nil, err
	}
	return ret, nil
}

func (p *ContentMng) GetUserInfo(ctx context.Context, user_id int64) (*data_cache.UserInfoLocal, error) {
	return p.DataCache.GetUserInfoLocal(ctx, nil, user_id, true)
}

func (p *ContentMng) GetUserInfoByHeader(ctx context.Context, header *pbapi.HttpHeaderInfo) (*data_cache.UserInfoLocal, error) {
	return p.getUserInfo(ctx, header)
}

func (p *ContentMng) InsertUnreadCommentItem(ctx context.Context, work_id int64, user_id int64) error {
	if work_id <= 0 || user_id <= 0 {
		return nil
	}
	curentTmMill := time.Now().UnixMilli()
	curComment := &pbmgdb.UserCommentUnreadWork{
		UserId:         proto.Int64(user_id),
		WorkId:         proto.Int64(work_id),
		Status:         proto.Int32(const_busi.CommentStatusRead),
		WorkCreateTime: &curentTmMill,
	}
	//存在 work_id, user_id 相同记录则更新，否则就插入一条新的记录
	err := p.DataCache.GetImpl().UserCommentUnReadWorkMgModel.InsertOrUpdate(
		ctx, curComment)
	if err != nil {
		logger.Errorf(ctx, "update unread comment status fail, workid: %v, userid: %v, err: %v", work_id, user_id, err)
		return err
	}
	return nil
}

// comment like
type ILikeLogicProc interface {
	CheckCommentValid(ctx context.Context) (error, bool)
	DoCommentLikeByUser(ctx context.Context) error
	UpdateCommentLikeNums(ctx context.Context) (int32, error)
	GetLikeCount(ctx context.Context) (int32, error)
}

const (
	WorkCommentLikeSucc     int32 = 1
	WorkCommentLikeRepeated int32 = 2
	WorkCommentLikeFail     int32 = 3
)

type WorkCommentStatusCheck struct {
	commentUserId  int64
	imp            *ContentMng
	likerUser      *data_cache.UserInfoLocal
	op             int32
	req            *pbapi.WorkCommentLikeReq
	retLikedByUser int32 // 1: ok, 2: repeated, 3: fail
}

func (p *WorkCommentStatusCheck) CheckCommentValid(ctx context.Context) (error, bool) {
	eqCond := map[string]interface{}{
		"_id":     p.req.CommentId,
		"work_id": p.req.GetWorkId(),
		"status":  const_busi.CommentValid,
	}
	var retErr error
	if p.req.GetOp() == const_busi.UnLikedOp {
		retErr = errorcode.CommentUnLikeFail
	} else {
		retErr = errorcode.CommentLikeFail
	}
	//
	data, err := p.imp.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentDetails(ctx, eqCond, nil, nil, nil, 0)
	if err != nil {
		logger.Errorf(ctx, "check comment status on 1 fail, err: %v, commentId: %v", err, p.req.GetCommentId())
		return retErr, false
	}
	if len(data) <= 0 {
		logger.Errorf(ctx, "valid comment not exit, commentId: %v", p.req.GetCommentId())
		return retErr, false
	}
	//...
	p.commentUserId = data[0].GetUserId()
	return nil, true
}
func (p *WorkCommentStatusCheck) GetLikeCount(ctx context.Context) (int32, error) {
	eqConds := map[string]interface{}{
		"_id":     p.req.GetCommentId(),
		"work_id": p.req.GetWorkId(),
		"status":  const_busi.CommentValid,
	}
	specialField := map[string]int32{
		"liked_count": 1,
	}
	retData, err := p.imp.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentSpecialFieldVal(ctx, eqConds, nil, nil, nil, 0, specialField)
	if err != nil || len(retData) <= 0 {
		return 0, err
	}
	if nums, ok := retData[0]["liked_count"]; ok {
		return nums.(int32), nil
	}
	return 0, nil
}

func NewLikeHandle(ctx context.Context, op int32, imp *ContentMng, likerUser *data_cache.UserInfoLocal, req *pbapi.WorkCommentLikeReq) ILikeLogicProc {
	tmpCheck := &WorkCommentStatusCheck{
		op:             op,
		imp:            imp,
		likerUser:      likerUser,
		req:            req,
		retLikedByUser: WorkCommentLikeSucc, // default is ok
	}
	///
	switch op {
	case const_busi.UnLikedOp:
		logger.Infof(ctx, "is unlike op")
		return &UnlikeCommentOP{
			WorkCommentStatusCheck: tmpCheck,
		}
	case const_busi.LikedOp:
		logger.Infof(ctx, "is like op")
		return &LikeCommentOP{
			WorkCommentStatusCheck: tmpCheck,
		}
	}
	return nil
}

type LikeCommentOP struct {
	*WorkCommentStatusCheck
}

func (p *LikeCommentOP) DoCommentLikeByUser(ctx context.Context) error {
	commentLike := &pbmgdb.CommentLikeDetailMgDbModel{
		Id:          proto.Int64(snow_flake.GetSnowflakeID()),
		WorkId:      proto.Int64(p.req.GetWorkId()),
		CommentId:   proto.Int64(p.req.GetCommentId()),
		LikerUserId: proto.Int64(p.likerUser.UserInfoDbModel.GetUserId()),
		DoLike:      proto.Int32(p.req.GetOp()),
		CreateTime:  proto.Int64(time.Now().UnixMilli()),
		UpdateTime:  proto.Int64(time.Now().UnixMilli()),
	}
	ret, err := p.imp.DataCache.GetImpl().CommentLikeDetailMgModel.InsertNewOrUpdateOld(ctx, commentLike)
	if err != nil {
		return errorcode.CommentLikeFail
	}
	//
	switch ret {
	case mg_model.LikeUpdateSucc, mg_model.LikeUpdateInsertSucc:
		p.retLikedByUser = WorkCommentLikeSucc

		go func() {
			NewMedalLight(LikeMedalType, p).LightMedal(ctx)
			NewMedalLight(SuperStarMedalType, p).LightMedal(ctx)
		}()

	case mg_model.LikeUpdateRepeated:
		p.retLikedByUser = WorkCommentLikeRepeated
	case mg_model.LikeUpdateFail:
		p.retLikedByUser = WorkCommentLikeFail
	}
	return nil
}
func (p *LikeCommentOP) UpdateCommentLikeNums(ctx context.Context) (int32, error) {
	if p.retLikedByUser == WorkCommentLikeFail {
		return 0, errorcode.CommentLikeFail
	}
	if p.retLikedByUser == WorkCommentLikeRepeated {
		logger.Infof(ctx, "repeated like on comment: %v", p.req.GetCommentId())
		return 0, nil
	}
	if p.retLikedByUser == WorkCommentLikeSucc {
		eqConds := map[string]interface{}{
			"_id":     p.req.GetCommentId(),
			"work_id": p.req.GetWorkId(),
			"status":  const_busi.CommentValid,
		}
		incFields := map[string]interface{}{
			"liked_count": 1,
		}
		if err := p.imp.DataCache.GetImpl().WorkCommentDetailMgModel.UpdateLikeNumsByCond(ctx, eqConds, incFields); err != nil {
			logger.Errorf(ctx, "update like count fail on like, err: %v", err)
			return 0, errorcode.CommentLikeFail
		}
		return 0, nil
	}
	return 0, nil
}

type UnlikeCommentOP struct {
	*WorkCommentStatusCheck
}

func (p *UnlikeCommentOP) DoCommentLikeByUser(ctx context.Context) error {
	commentLike := &pbmgdb.CommentLikeDetailMgDbModel{
		WorkId:      proto.Int64(p.req.GetWorkId()),
		CommentId:   proto.Int64(p.req.GetCommentId()),
		LikerUserId: proto.Int64(p.likerUser.UserInfoDbModel.GetUserId()),
		DoLike:      proto.Int32(p.req.GetOp()),
		UpdateTime:  proto.Int64(time.Now().UnixMilli()),
	}
	ret, err := p.imp.DataCache.GetImpl().CommentLikeDetailMgModel.UpdateItemByCond(ctx, commentLike)
	if err != nil {
		return errorcode.CommentLikeFail
	}
	//
	switch ret {
	case mg_model.UnLikeUpdateSucc:
		p.retLikedByUser = WorkCommentLikeSucc
	case mg_model.UnLikeUpdateRepeated:
		p.retLikedByUser = WorkCommentLikeRepeated
	case mg_model.UnLikeUpdateFail:
		p.retLikedByUser = WorkCommentLikeFail
	}
	return nil
}
func (p *UnlikeCommentOP) UpdateCommentLikeNums(ctx context.Context) (int32, error) {
	if p.retLikedByUser == WorkCommentLikeFail {
		return 0, errorcode.CommentUnLikeFail
	}
	if p.retLikedByUser == WorkCommentLikeRepeated {
		logger.Infof(ctx, "repeated unlike on comment: %v", p.req.GetCommentId())
		return 0, nil
	}
	if p.retLikedByUser == WorkCommentLikeSucc {
		eqConds := map[string]interface{}{
			"_id":     p.req.GetCommentId(),
			"work_id": p.req.GetWorkId(),
			"status":  const_busi.CommentValid,
		}
		incFields := map[string]interface{}{
			"liked_count": -1,
		}
		if err := p.imp.DataCache.GetImpl().WorkCommentDetailMgModel.UpdateLikeNumsByCond(ctx, eqConds, incFields); err != nil {
			logger.Errorf(ctx, "update like count fail on like, err: %v", err)
			return 0, errorcode.CommentUnLikeFail
		}
		return 0, nil
	}
	return 0, nil
}

func (p *ContentMng) LikeWorkComment(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.WorkCommentLikeReq) (nums int32, err error) {
	var likerUserInfo *data_cache.UserInfoLocal = nil
	likerUserInfo, err = p.getUserInfo(ctx, header)
	if err != nil || likerUserInfo == nil {
		return
	}
	likeHandle := NewLikeHandle(ctx, req.GetOp(), p, likerUserInfo, req)
	if likeHandle == nil {
		err = errorcode.MIDAS_PARAMS_ERROR
		return
	}
	if err, _ = likeHandle.CheckCommentValid(ctx); err != nil {
		return
	}
	defer func() {
		nums = int32(0)
		nums, _ = likeHandle.GetLikeCount(ctx)
	}()

	err = likeHandle.DoCommentLikeByUser(ctx)
	if err != nil {
		logger.Errorf(ctx, "do like op fail, err: %v", err)
		return
	}
	_, err = likeHandle.UpdateCommentLikeNums(ctx)
	if err != nil {
		logger.Errorf(ctx, "update like nums fail, err: %v, workId: %v, commentId: %v", err, req.GetWorkId(), req.GetCommentId())
		return
	}
	return
}

//巨星勋章：
//1. 此处的点赞为评论的点赞数：若用户单日发表的所有评论点赞数总和达到200，即可点亮勋章；数值支持配置

// 点赞勋章：
// 1. 此处的点赞为单日点赞别人评论的总数，若超过50则自动点亮；数值支持配置

type ILikeMedalLight interface {
	ReachLightLevel(ctx context.Context) (error, bool)
	LightMedal(ctx context.Context) error
}

const (
	LikeMedalType      = 1
	SuperStarMedalType = 2
)

func NewMedalLight(likeType int32, likeOp *LikeCommentOP) ILikeMedalLight {

	switch likeType {
	case LikeMedalType:
		return &LikeMedalLight{
			likeOp:  likeOp,
			userId:  likeOp.likerUser.UserInfoDbModel.GetUserId(),
			medalNo: 9,
		}

	case SuperStarMedalType:
		return &SuperMediaLight{
			likeOp:        likeOp,
			medalNo:       7,
			commentUserId: likeOp.commentUserId,
		}
	}
	return nil
}

// 点赞勋章
type LikeMedalLight struct {
	likeOp  *LikeCommentOP
	userId  int64
	medalNo int64
}

func (p *LikeMedalLight) ReachLightLevel(ctx context.Context) (error, bool) {
	nowTime := time.Now()
	zeroTime := time.Date(nowTime.Year(), nowTime.Month(), nowTime.Day(), 0, 0, 0, 0, time.Local).UnixMilli()

	filter := bson.M{
		"likerUserId": p.userId,
		"doLike":      const_busi.LikedOp,
		"updateTime":  bson.M{"$gte": zeroTime},
	}

	nums, err := p.likeOp.imp.DataCache.GetImpl().CommentLikeDetailMgModel.GetHasLikedNums(ctx, filter)
	if err != nil {
		logger.Errorf(ctx, "get has liked nums for user: %v fail, err: %v", p.userId, err)
		return err, false
	}

	defaultNums := int64(50)
	if config.ServerConfig.LikeConfig != nil && config.ServerConfig.LikeConfig.LikedNumsToOtherOneDay > 0 {
		defaultNums = config.ServerConfig.LikeConfig.LikedNumsToOtherOneDay
	}

	if nums > defaultNums {
		logger.Infof(ctx, "has reach light level, like nums: %v, user: %v", nums, p.userId)
		return nil, true
	}

	if nums <= 0 {
		filter := bson.M{
			"likerUserId": p.userId,
			"doLike":      const_busi.LikedOp,
			"createTime":  bson.M{"$gte": zeroTime},
		}
		nums, err := p.likeOp.imp.DataCache.GetImpl().CommentLikeDetailMgModel.GetHasLikedNums(ctx, filter)
		if err != nil {
			logger.Errorf(ctx, "get has liked nums for user: %v fail, err: %v", p.userId, err)
			return err, false
		}

		if nums > defaultNums {
			logger.Infof(ctx, "has reach light level, like nums: %v, user: %v", nums, p.userId)
			return nil, true
		}
	}
	return nil, false
}

func (p *LikeMedalLight) LightMedal(ctx context.Context) error {
	err, ready := p.ReachLightLevel(ctx)
	if err != nil {
		return err
	}

	if ready == false {
		return nil
	}

	defaultSecond := int64(172800)

	if config.ServerConfig.LikeConfig != nil && config.ServerConfig.LikeConfig.ExpireTimeToOtherSecond > 0 {
		defaultSecond = config.ServerConfig.LikeConfig.ExpireTimeToOtherSecond
	}

	err = p.likeOp.imp.setMedal(ctx, p.userId, p.medalNo, defaultSecond)
	if err != nil {
		logger.Errorf(ctx, "set medal fail, medal type: %v, err: %v, userId: %v", p.medalNo, err, p.userId)
		return err
	}
	logger.Infof(ctx, "set medal type: %v to user: %v", p.medalNo, p.userId)
	return nil
}

// 巨星勋章
type SuperMediaLight struct {
	likeOp  *LikeCommentOP
	medalNo int64
	//
	commentUserId int64
}

func (p *SuperMediaLight) ReachLightLevel(ctx context.Context) (error, bool) {
	eqConds := make(map[string]interface{})
	eqConds["user_id"] = p.commentUserId
	eqConds["status"] = const_busi.CommentStatusRead

	nowTime := time.Now()
	zeroTimeStr := time.Date(nowTime.Year(), nowTime.Month(), nowTime.Day(), 0, 0, 0, 0, time.Local).Format("2006-01-02 15:04:05.000")
	largeConds := make(map[string]interface{})
	largeConds["create_time"] = zeroTimeStr

	commentDetails, err := p.likeOp.imp.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentDetails(ctx, eqConds, largeConds, nil, nil, 0)
	if err != nil {
		logger.Errorf(ctx, "get comment detail lists fail, err: %v", err)
		return err, false
	}
	if len(commentDetails) <= 0 {
		return nil, false
	}

	var commentIds []int64
	for k, _ := range commentDetails {
		if commentDetails[k] == nil {
			continue
		}
		commentIds = append(commentIds, commentDetails[k].GetId())
	}
	if len(commentIds) <= 0 {
		return nil, false
	}

	filter := bson.M{
		"doLike": const_busi.LikedOp,
		"commentId": bson.M{
			"$in": commentIds,
		},
	}

	nums, err := p.likeOp.imp.DataCache.GetImpl().CommentLikeDetailMgModel.GetHasLikedNums(ctx, filter)
	if err != nil {
		logger.Errorf(ctx, "get liked nums fail, err: %v", err)
		return err, false
	}

	defaultNums := int64(200)
	if config.ServerConfig.LikeConfig != nil && config.ServerConfig.LikeConfig.LikedNumsByOtherOneDay > 0 {
		defaultNums = config.ServerConfig.LikeConfig.LikedNumsByOtherOneDay
	}
	if nums > defaultNums {
		logger.Infof(ctx, "valid like nums: %v more than: %v, for comment of user: %v", nums, defaultNums, p.commentUserId)
		return nil, true
	}
	return nil, false
}
func (p *SuperMediaLight) LightMedal(ctx context.Context) error {
	err, ready := p.ReachLightLevel(ctx)
	if err != nil {
		return err
	}
	if ready == false {
		return nil
	}
	//
	defaultTimeSecond := int64(172800)
	if config.ServerConfig.LikeConfig != nil && config.ServerConfig.LikeConfig.ExpireTimeByOtherSecond > 0 {
		defaultTimeSecond = config.ServerConfig.LikeConfig.ExpireTimeByOtherSecond
	}

	err = p.likeOp.imp.setMedal(ctx, p.commentUserId, p.medalNo, defaultTimeSecond)
	if err != nil {
		logger.Errorf(ctx, "set medal type: %v to user: %v fail, err: %v", p.medalNo, p.commentUserId, err)
		return err
	}
	//
	logger.Infof(ctx, "set medal type: %v to user: %v, valid expire second: %v", p.medalNo, p.commentUserId, defaultTimeSecond)
	return nil
}
