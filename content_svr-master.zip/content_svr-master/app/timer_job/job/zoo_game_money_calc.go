package job

import (
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/internal/zoo_game_mng"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"time"
)

const beginDay = 20240701 // 开始计算的天

// InitZooGameControl 每天凌晨三点整，执行计算
func InitZooGameControl(write, read *dao.ManagerDB) {
	ctrl := newZooGameControl(write, read)
	//ctrl.once()
	//return

	ctx := requestid.WithRequestID(context.Background())
	target := time.Now()
	if err := ctrl.DoTask(ctx, target); err != nil {
		logger.Error(context.Background(), "qd_log,InitZooGameControl:", err)
	}
}

type zooGameControl struct {
	read  *dao.ManagerDB
	write *dao.ManagerDB

	target time.Time
}

func newZooGameControl(write, read *dao.ManagerDB) zooGameControl {
	r := zooGameControl{
		read:  read,
		write: write,
	}

	return r
}

func (r *zooGameControl) once() {
	ctx := requestid.WithRequestID(context.Background())
	target := time.Now()
	if err := r.DoTask(ctx, target); err != nil {
		logger.Error(context.Background(), "qd_log,InitZooGameControl:", err)
	}

	//for i := 4; i >= 0; i-- {
	//	ctrl := newRetainControl(r.write, r.read)
	//	ctx := requestid.WithRequestID(context.Background())
	//	target := time.Now().AddDate(0, 0, -i)
	//	if err := ctrl.DoTask(ctx, target); err != nil {
	//		logger.Error(context.Background(), "InitCalcRetain:", err)
	//	}
	//}
}

func (r *zooGameControl) DoTask(ctx context.Context, target time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "qd_log,zooGameControl recover: %v\n", err)
		}
	}()
	r.target = target

	if err := r.calcMoney(ctx); err != nil {
		logger.Error(ctx, "qd_log,calcMoney: ", err)
		return err
	}

	return nil
}

func (r *zooGameControl) calcMoney(ctx context.Context) error {
	for _, channel := range zoo_game_mng.ZooGameChannels {
		for _, platform := range zoo_game_mng.ZooGamePlatforms {
			for _, game := range zoo_game_mng.ZooGameNames {
				r.calcSortedMoney(ctx, channel, platform, game)
			}
		}
	}

	return nil
}

// 计算根据不同细分维度获取的付费数据
func (r *zooGameControl) calcSortedMoney(ctx context.Context,
	channel zoo_game_mng.ZooGameChannelEnum,
	platform zoo_game_mng.ZooGamePlatformEnum,
	game zoo_game_mng.ZooGameGameNameEnum) {

	endTimeUnix := r.target.Unix()
	for i := 1; i < 46; i++ { // 45天的付费数据
		targetTime := utils.CalcTime(r.target, -i)
		targetDay, _ := utils.TimeByDay(targetTime)
		if targetDay <= uint(beginDay) {
			return
		}

		beginTimeUnix := endTimeUnix - int64(i)*86400
		filter := bson.M{
			"channel":     channel,
			"platform":    platform,
			"gameId":      game,
			"regTime":     bson.M{"$gte": beginTimeUnix, "$lte": beginTimeUnix + 86400},
			"create_time": bson.M{"$gte": beginTimeUnix, "$lte": endTimeUnix},
		}

		list, err := r.read.ZooGamePayInfo.FindAll(ctx, filter)
		if err != nil {
			logger.Error(ctx, "qd_log,calcSubMoney:", err)
		}

		var amount float64 = 0
		for _, pay := range list {
			amount += pay.Amount
		}

		updateFilter := bson.M{
			"platform": int32(platform),
			"channel":  string(channel),
			"gameId":   string(game),
			"day":      targetDay,
		}
		item, _ := r.read.ZooGamePayDaily.FindOne(ctx, updateFilter)

		if item != nil {
			data := item.Data
			data[i] = amount

			updateData := bson.D{
				{"data", data},
				{"update_time", time.Now().UnixMilli()},
			}

			insertData := bson.D{
				{"create_time", time.Now().UnixMilli()},
			}

			_, err = r.write.ZooGamePayDaily.Upsert(ctx, updateFilter, updateData, insertData)
			if err != nil {
				logger.Error(ctx, "qd_log,calcSortedMoney: ", err)
				return
			}
		} else { // 不存在则插入
			data := make(map[int]float64)
			data[i] = amount

			item := &model.ZooGamePayDaily{
				ID:         primitive.NewObjectID(),
				CreateTime: time.Now().UnixMilli(),
				UpdateTime: time.Now().UnixMilli(),
				Platform:   int32(platform),
				Channel:    string(channel),
				GameId:     string(game),
				Day:        targetDay, // 这里使用北京的时区计算昨天的时间，实际就是秘鲁的当天时间。例如 北京时间7月2号下午1点对应秘鲁时间7月1号的数据
				Data:       data,
			}

			_, err := r.write.ZooGamePayDaily.Insert(ctx, item)
			if err != nil {
				logger.Error(ctx, "qd_log,calcSortedMoney: ", err)
				return
			}
		}

		logger.Infof(ctx, "qd_log,calcSortedMoney: day %v, i %v, amount %v", targetDay, i, amount)
	}
}
