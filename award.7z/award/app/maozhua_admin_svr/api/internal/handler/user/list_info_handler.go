package user

import (
	"content_svr/app/maozhua_admin_svr/common/result"
	"github.com/go-playground/validator/v10"
	"net/http"

	"content_svr/app/maozhua_admin_svr/api/internal/logic/user"
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"github.com/zeromicro/go-zero/rest/httpx"
)

type verifyListInfoReqRequest struct {
	types.ListInfoReq
}

func (p *verifyListInfoReqRequest) Validate() error {
	valid := validator.New()
	if err := valid.Struct(p); err != nil {
		return err
	}
	return nil
}

func ListInfoHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req verifyListInfoReqRequest
		if err := httpx.Parse(r, &req); err != nil {
			result.ParamErrorResult(r, w, err)
			return
		}

		l := user.NewListInfoLogic(r.Context(), svcCtx)
		resp, err := l.ListInfo(&req.ListInfoReq)
		result.HttpResult(r, w, resp, err)
	}
}
