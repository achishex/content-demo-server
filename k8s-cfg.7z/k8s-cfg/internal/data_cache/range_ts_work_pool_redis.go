package data_cache

import (
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	rdsV8 "github.com/go-redis/redis/v8"
	"strconv"
)

// AddToTsWorkPoolRedis 向分发池内添加数据
func (p *DataCacheMng) AddToTsWorkPoolRedis(ctx context.Context, workId int64) error {
	redisKey := getRdsKeyPersonalBottleWorksShare()
	_, err := p.RedisCli.ZAdd(ctx, redisKey, &rdsV8.Z{Score: float64(utils.GetCurTsMs()), Member: workId}).Result()
	if err != nil {
		logger.Error(ctx, "TsWorkPoolRedis add to ts pool failed.", err)
		return err
	}
	logger.Infof(ctx, "TsWorkPoolRedis add to ts pool suc, redisKey=%v", redisKey)

	// 临时切分发池备用
	//p.addToTsWorkPoolRedisBackup(ctx, workId)
	return nil
}

// AddToHighTsWorkPoolRedis 优质内容池添加数据
func (p *DataCacheMng) AddToHighTsWorkPoolRedis(ctx context.Context, workId int64) error {
	redisKey := getRdsKeyHighPersonalBottleWorksShare()
	_, err := p.RedisCli.ZRank(ctx, redisKey, strconv.FormatInt(workId, 10)).Result()
	if err == rdsV8.Nil {
		_, err = p.RedisCli.ZAdd(ctx, redisKey, &rdsV8.Z{Score: float64(utils.GetCurTsMs()), Member: workId}).Result()
		if err != nil {
			logger.Error(ctx, "HighTsWorkPoolRedis add to high ts pool failed.", err)
			return err
		}
	}

	if err != nil && err != rdsV8.Nil {
		logger.Error(ctx, "HighTsWorkPoolRedis rank to high ts pool failed.", err)
		return err
	}

	logger.Infof(ctx, "HighTsWorkPoolRedis add to high ts pool suc, redisKey=%v", redisKey)
	return nil
}

// AddToHighPlusTsWorkPoolRedis 《高》优质内容池添加数据
func (p *DataCacheMng) AddToHighPlusTsWorkPoolRedis(ctx context.Context, workId int64) error {
	redisKey := getRdsKeyHighPlusPersonalBottleWorksShare()
	_, err := p.RedisCli.ZRank(ctx, redisKey, strconv.FormatInt(workId, 10)).Result()
	if err == rdsV8.Nil {
		_, err = p.RedisCli.ZAdd(ctx, redisKey, &rdsV8.Z{Score: float64(utils.GetCurTsMs()), Member: workId}).Result()
		if err != nil {
			logger.Error(ctx, "HighPlusTsWorkPoolRedis add to high ts pool failed.", err)
			return err
		}
	}

	if err != nil && err != rdsV8.Nil {
		logger.Error(ctx, "HighPlusTsWorkPoolRedis rank to high ts pool failed.", err)
		return err
	}

	logger.Infof(ctx, "HighPlusTsWorkPoolRedis add to high ts pool suc, redisKey=%v", redisKey)
	return nil
}

// 备份分发池
//func (p *DataCacheMng) addToTsWorkPoolRedisBackup(ctx context.Context, workId int64) error {
//	redisKey := getRdsKeySecretSharePoolTs()
//	_, err := p.RedisCli.ZAdd(ctx, redisKey, &rdsV8.Z{Score: float64(utils.GetCurTsMs()), Member: workId}).Result()
//	if err != nil {
//		logger.Error(ctx, "TsWorkPoolRedis add to ts pool failed.", err)
//		return err
//	}
//	logger.Infof(ctx, "TsWorkPoolRedis add to ts pool suc, redisKey=%v", redisKey)
//
//	return nil
//}

// 时间维度保存的所有内容 workid~ts. zrange platform:prod:soul_soup:secret:sharePool 0 1 WITHSCORES
func getRdsKeySecretSharePoolTs() string {
	return fmt.Sprintf("platform:%v:soul_soup:secret:sharePool", getRdsEnvPrefix())
}

// RangeTsWorkPoolRedis 从分发池获取数据
func (p *DataCacheMng) RangeTsWorkPoolRedis(ctx context.Context, begin, end int64) (map[string]int64, int64, error) {
	redisKey := getRdsKeyPersonalBottleWorksShare()
	result := make(map[string]int64, 0) // workid~ts
	items, err := p.RedisCli.ZRevRangeWithScores(ctx, redisKey, begin, end).Result()
	if err != nil {
		return result, 0, err
	}
	var LatestTsMs int64 = 0
	if len(items) != 0 {
		LatestTsMs = int64(items[0].Score)
	}
	for _, item := range items {
		result[item.Member.(string)] = int64(item.Score) //item.Score 毫秒时间戳
	}
	return result, LatestTsMs, nil
}

// RangeHighTsWorkPoolRedis 从优质分发池获取数据
func (p *DataCacheMng) RangeHighTsWorkPoolRedis(ctx context.Context, begin, end int64) (map[string]int64, int64, error) {
	redisKey := getRdsKeyHighPersonalBottleWorksShare()
	result := make(map[string]int64, 0) // workid~ts
	items, err := p.RedisCli.ZRevRangeWithScores(ctx, redisKey, begin, end).Result()
	if err != nil {
		return result, 0, err
	}
	var LatestTsMs int64 = 0
	if len(items) != 0 {
		LatestTsMs = int64(items[0].Score)
	}
	for _, item := range items {
		result[item.Member.(string)] = int64(item.Score) //item.Score 毫秒时间戳
	}
	return result, LatestTsMs, nil
}

// RangeHighPlusTsWorkPoolRedis 从《高》优质分发池获取数据
func (p *DataCacheMng) RangeHighPlusTsWorkPoolRedis(ctx context.Context, begin, end int64) (map[string]int64, int64, error) {
	redisKey := getRdsKeyHighPlusPersonalBottleWorksShare()
	result := make(map[string]int64, 0) // workid~ts
	items, err := p.RedisCli.ZRevRangeWithScores(ctx, redisKey, begin, end).Result()
	if err != nil {
		return result, 0, err
	}
	var LatestTsMs int64 = 0
	if len(items) != 0 {
		LatestTsMs = int64(items[0].Score)
	}
	for _, item := range items {
		result[item.Member.(string)] = int64(item.Score) //item.Score 毫秒时间戳
	}
	return result, LatestTsMs, nil
}

// CheckExistTsWorkPoolRedis 检查是不是在分发池
//func (p *DataCacheMng) CheckExistTsWorkPoolRedis(ctx context.Context, workid string) (bool, error) {
//	redisKey := getRdsKeyPersonalBottleWorksShare()
//	_, err := p.RedisCli.ZRank(ctx, redisKey, workid).Result() //返回在range的idx位置
//	if err != nil {
//		return false, err
//	} else {
//		return true, err
//	}
//}

// AsyncRemoveFromTsWorkPoolRedis AsyncRemoveFromBaseWorkPoolR 从内容分发池删除
func (p *DataCacheMng) AsyncRemoveFromTsWorkPoolRedis(ctx context.Context, workids []string) bool {
	if len(workids) == 0 {
		return true
	}
	logger.Infof(ctx, "TsWorkPoolRedis AsyncRemoveFromTsWorkPoolRedis, workids =%v", workids)
	redisKey := getRdsKeyPersonalBottleWorksShare()
	count, err := p.RedisCli.ZRem(ctx, redisKey, workids).Result()
	if err == rdsV8.Nil {
		// 不存在改key，返回成功
		logger.Infof(ctx, "TsWorkPoolRedis AsyncRemoveFromTsWorkPoolRedis, query redis not find. zRem failed. key=%v, workids=%v",
			redisKey, workids)
		return true
	}

	if err != nil && err != rdsV8.Nil {
		logger.Error(ctx, fmt.Sprintf("TsWorkPoolRedis AsyncRemoveFromTsWorkPoolRedis, qurey redis failed. zRem failed. key=%v, workids=%v",
			redisKey, workids), err)
		return false
	}

	if int(count) != len(workids) {
		logger.Error(ctx, fmt.Sprintf("TsWorkPoolRedis AsyncRemoveFromTsWorkPoolRedis, zRem return count != len(workids). key=%v, workids=%v, count=%v",
			redisKey, workids, count), err)
		return false
	}

	logger.Infof(ctx, "TsWorkPoolRedis AsyncRemoveFromTsWorkPoolRedis success. key=%v, workids=%v",
		redisKey, workids)
	return true
}

// AsyncRemoveFromHighTsWorkPoolRedis AsyncRemoveFromBaseWorkPoolR 从优质内容分发池删除
func (p *DataCacheMng) AsyncRemoveFromHighTsWorkPoolRedis(ctx context.Context, workids []string) bool {
	if len(workids) == 0 {
		return true
	}
	logger.Infof(ctx, "HighTsWorkPoolRedis AsyncRemoveFromHighTsWorkPoolRedis, workids =%v", workids)
	redisKey := getRdsKeyHighPersonalBottleWorksShare()
	_, err := p.RedisCli.ZRem(ctx, redisKey, workids).Result()
	if err == rdsV8.Nil {
		// 不存在改key，返回成功
		logger.Infof(ctx, "HighTsWorkPoolRedis AsyncRemoveFromHighTsWorkPoolRedis, query redis not find. zRem failed. key=%v, workids=%v",
			redisKey, workids)
		return true
	}

	if err != nil && err != rdsV8.Nil {
		logger.Error(ctx, fmt.Sprintf("HighTsWorkPoolRedis AsyncRemoveFromHighTsWorkPoolRedis, qurey redis failed. zRem failed. key=%v, workids=%v",
			redisKey, workids), err)
		return false
	}

	logger.Infof(ctx, "HighTsWorkPoolRedis AsyncRemoveFromHighTsWorkPoolRedis success. key=%v, workids=%v",
		redisKey, workids)
	return true
}

// AsyncRemoveFromHighTsWorkPoolRedis AsyncRemoveFromHighPlusTsWorkPoolRedis 从《高》优质内容分发池删除
func (p *DataCacheMng) AsyncRemoveFromHighPlusTsWorkPoolRedis(ctx context.Context, workids []string) bool {
	if len(workids) == 0 {
		return true
	}
	logger.Infof(ctx, "HighPlusTsWorkPoolRedis AsyncRemoveFromHighPlusTsWorkPoolRedis, workids =%v", workids)
	redisKey := getRdsKeyHighPlusPersonalBottleWorksShare()
	_, err := p.RedisCli.ZRem(ctx, redisKey, workids).Result()
	if err == rdsV8.Nil {
		// 不存在改key，返回成功
		logger.Infof(ctx, "HighPlusTsWorkPoolRedis AsyncRemoveFromHighPlusTsWorkPoolRedis, query redis not find. zRem failed. key=%v, workids=%v",
			redisKey, workids)
		return true
	}

	if err != nil && err != rdsV8.Nil {
		logger.Error(ctx, fmt.Sprintf("HighPlusTsWorkPoolRedis AsyncRemoveFromHighPlusTsWorkPoolRedis, qurey redis failed. zRem failed. key=%v, workids=%v",
			redisKey, workids), err)
		return false
	}

	logger.Infof(ctx, "HighPlusTsWorkPoolRedis AsyncRemoveFromHighPlusTsWorkPoolRedis success. key=%v, workids=%v",
		redisKey, workids)
	return true
}

// CleanTsWorkPoolRedis 清理普通内容池
func (p *DataCacheMng) CleanTsWorkPoolRedis(ctx context.Context, min, max string) error {
	redisKey := getRdsKeyPersonalBottleWorksShare()

	//查询做个日志备份, 删除不返回值
	rst, err := p.RedisCli.ZRangeByScore(ctx, redisKey, &rdsV8.ZRangeBy{
		Min: min,
		Max: max,
	}).Result()

	if err != nil {
		logger.Error(ctx, fmt.Sprintf("CleanTsWorkPoolRedis, qurey redis failed. ZRangeByScore failed. key=%v, begin=%v, end=%v",
			redisKey, min, max), err)
		return nil
	}

	if len(rst) == 0 {
		return nil
	}
	logger.Infof(ctx, fmt.Sprintf("CleanHighTsWorkPoolRedis, clean list: %v", rst))

	n, err := p.RedisCli.ZRemRangeByScore(ctx, redisKey, min, max).Result()
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("CleanTsWorkPoolRedis, qurey redis failed. ZRemRangeByScore failed. key=%v, begin=%v, end=%v",
			redisKey, min, max), err)
		return err
	}
	logger.Infof(ctx, fmt.Sprintf("CleanTsWorkPoolRedis, clean count: %v", n))

	return nil
}

// CleanHighTsWorkPoolRedis 清理优质内容池
func (p *DataCacheMng) CleanHighTsWorkPoolRedis(ctx context.Context, min, max string) error {
	redisKey := getRdsKeyHighPersonalBottleWorksShare()

	//查询做个日志备份, 删除不返回值
	rst, err := p.RedisCli.ZRangeByScore(ctx, redisKey, &rdsV8.ZRangeBy{
		Min: min,
		Max: max,
	}).Result()

	if err != nil {
		logger.Error(ctx, fmt.Sprintf("CleanHighTsWorkPoolRedis, qurey redis failed. ZRangeByScore failed. key=%v, begin=%v, end=%v",
			redisKey, min, max), err)
		return nil
	}

	if len(rst) == 0 {
		return nil
	}
	logger.Infof(ctx, fmt.Sprintf("CleanHighTsWorkPoolRedis, clean list: %v", rst))

	n, err := p.RedisCli.ZRemRangeByScore(ctx, redisKey, min, max).Result()
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("CleanHighTsWorkPoolRedis, qurey redis failed. ZRemRangeByScore failed. key=%v, begin=%v, end=%v",
			redisKey, min, max), err)
		return err
	}
	logger.Infof(ctx, fmt.Sprintf("CleanHighTsWorkPoolRedis, clean count: %v", n))

	return nil
}

// CleanHighPlusTsWorkPoolRedis 清理《高》优质内容池
func (p *DataCacheMng) CleanHighPlusTsWorkPoolRedis(ctx context.Context, min, max string) error {
	redisKey := getRdsKeyHighPlusPersonalBottleWorksShare()

	//查询做个日志备份, 删除不返回值
	rst, err := p.RedisCli.ZRangeByScore(ctx, redisKey, &rdsV8.ZRangeBy{
		Min: min,
		Max: max,
	}).Result()

	if err != nil {
		logger.Error(ctx, fmt.Sprintf("CleanHighPlusTsWorkPoolRedis, qurey redis failed. ZRangeByScore failed. key=%v, begin=%v, end=%v",
			redisKey, min, max), err)
		return nil
	}

	if len(rst) == 0 {
		return nil
	}
	logger.Infof(ctx, fmt.Sprintf("CleanHighPlusTsWorkPoolRedis, clean list: %v", rst))

	n, err := p.RedisCli.ZRemRangeByScore(ctx, redisKey, min, max).Result()
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("CleanHighPlusTsWorkPoolRedis, qurey redis failed. ZRemRangeByScore failed. key=%v, begin=%v, end=%v",
			redisKey, min, max), err)
		return err
	}
	logger.Infof(ctx, fmt.Sprintf("CleanHighPlusTsWorkPoolRedis, clean count: %v", n))

	return nil
}
