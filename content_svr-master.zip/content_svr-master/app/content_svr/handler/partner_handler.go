package handler

import (
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/middleware"
	"github.com/gin-gonic/gin"
)

func (p *AdminHandler) GetPartnerInfo(ctx *gin.Context) (*pbuserapi.PartnerInfoResp, error) {
	userID := middleware.GetUserID(ctx)
	resp, err := p.PartnerMng.GetPartnerInfo(ctx, userID)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) UseInviteCode(ctx *gin.Context, req *pbuserapi.UseInviteCodeReq) (*pbuserapi.UseInviteCodeResp, error) {
	if req.InviteCode == "" {
		return nil, errorcode.PARAM_ERROR
	}

	resp, err := p.PartnerMng.UseInviteCode(ctx, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}
