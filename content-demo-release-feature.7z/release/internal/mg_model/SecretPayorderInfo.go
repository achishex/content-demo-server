package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretPayOrderInfoMgModel interface {
	Get(ctx context.Context, filter any) (*pbmgdb.SecretPayOrderInfoMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.SecretPayOrderInfoMgDbModel, options ...*options.InsertOneOptions) error
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
}

type SecretPayOrderInfo struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretPayOrderInfoMgModelImpl(db *mongo.Database) ISecretPayOrderInfoMgModel {
	return &SecretPayOrderInfo{
		MgDB:  db,
		Table: "secretPayOrderInfo",
	}
}

func (g *SecretPayOrderInfo) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *SecretPayOrderInfo) Get(ctx context.Context, filter any) (*pbmgdb.SecretPayOrderInfoMgDbModel, error) {
	var v *pbmgdb.SecretPayOrderInfoMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretGame GetByAppKey failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *SecretPayOrderInfo) Create(ctx context.Context, data *pbmgdb.SecretPayOrderInfoMgDbModel, options ...*options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data, options...)

	if err != nil {
		logger.Errorf(ctx, "SecretGame:Bind error : %v", err)
		return err
	}

	return nil
}

func (g *SecretPayOrderInfo) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "SecretPayOrderInfo:updateOne error: %v", err)
		return err
	}

	return nil
}
