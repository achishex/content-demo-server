package utils

import (
	"content_svr/pub/errors"
	"github.com/stretchr/testify/assert"
	"testing"
	"time"
)

func TestTrySucc(t *testing.T) {
	do := func() error { return nil }
	err := Try(3, time.Millisecond, do)
	assert.Nil(t, err)
}

func TestTry3TimesFail(t *testing.T) {
	n := 0
	do := func() error {
		n++
		return errors.New("a err")
	}
	err := Try(3, time.Millisecond, do)
	assert.NotNil(t, err)
	assert.Equal(t, 3, n)
}

func TestTry2TimesSucc(t *testing.T) {
	n := 0
	do := func() error {
		n++
		if n > 1 {
			return nil
		}
		return errors.New("a err")
	}
	err := Try(3, time.Millisecond, do)
	assert.Nil(t, err)
	assert.Equal(t, 2, n)
}
