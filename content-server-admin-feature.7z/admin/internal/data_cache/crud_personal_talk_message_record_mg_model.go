package data_cache

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
)

// 这个得实时查
func (p *DataCacheMng) GetPersonTalkMsgRecordMgDB(ctx context.Context, msgId int64) *pbapi.PersonalTalkMessageRecordMgDbModel {
	//从mg db取. 所有medals信息
	mgItem, err := p.PersonalTalkMessageRecordMgDbModel.GetById(ctx, msgId)
	if err != nil {
		logger.Errorf(ctx, "get GetPersonTalkMsgRecordMgDB failed.  err=%v", err.Error())
		return nil
	}
	return mgItem
}

func (p *DataCacheMng) ListPersonTalkMsgRecordByConditionMgDB(ctx context.Context, cond map[string]interface{}) []*pbapi.PersonalTalkMessageRecordMgDbModel {
	//从mg db取.
	mgItems, err := p.PersonalTalkMessageRecordMgDbModel.ListByCondition(ctx, cond)
	if err != nil {
		logger.Errorf(ctx, "ListPersonTalkMsgRecordByConditionMgDB failed. cond=%+v, err=%v", cond, err.Error())
		return nil
	}
	return mgItems
}

func (p *DataCacheMng) InsertPersonTalkMsgRecord(ctx context.Context, item *pbapi.PersonalTalkMessageRecordMgDbModel) error {
	return p.PersonalTalkMessageRecordMgDbModel.Insert(ctx, item)
}

func (p *DataCacheMng) UpdatePersonTalkMsgRecordDictById(ctx context.Context, id int64, update map[string]interface{}) error {
	return p.PersonalTalkMessageRecordMgDbModel.UpdateDictById(ctx, id, update)
}

func (p *DataCacheMng) UpdatePersonTalkMsgRecordDictByCond(ctx context.Context, cond, update map[string]interface{}) error {
	return p.PersonalTalkMessageRecordMgDbModel.UpdateDictByCond(ctx, cond, update)
}
