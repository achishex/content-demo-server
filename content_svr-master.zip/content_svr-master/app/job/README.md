Job
===

定时任务

## 目录
- cmd 程序入口
- subcmd job子命令
- cronjob 定时调度

## 开发说明
- subcmd定义命令，参考getuservip.go
- di增加构造器
- 本地调试 `cd /syachat-server/build/job; APP_LOGGER=console go run ../../app/job/cmd/main.go getUserVip --uid=4977093215905792`
- 编写cron上线

