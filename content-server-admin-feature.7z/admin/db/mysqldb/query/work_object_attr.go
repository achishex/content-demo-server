package query

import (
	"content_svr/db/mysqldb/model"
	"context"
	"gorm.io/gen"
	"gorm.io/gen/field"
)

type WorkObjectAttr struct {
	workObjectAttr
}

func NewWorkObjectAttr(p workObjectAttr) WorkObjectAttr {
	return WorkObjectAttr{
		workObjectAttr: p,
	}
}

func (p *workObjectAttr) ParseWhere(ctx context.Context, where map[string]interface{}) IWorkObjectAttrDo {
	_do := p.WithContext(ctx)
	if len(where) == 0 {
		return _do
	}

	attrMap := map[string]interface{}{}
	for key, value := range where {
		switch key {
		default:
			if _, exist := p.fieldMap[key]; !exist {
				continue
			}
			attrMap[key] = value
		}
	}

	return _do.Where(field.Attrs(attrMap))
}
func (p *workObjectAttr) FindMap(ctx context.Context, limit, offset int, where map[string]interface{}) ([]*model.WorkObjectAttr, error) {
	_db := p.ParseWhere(ctx, where)
	_db = _db.WithContext(ctx)
	if limit != 0 {
		_db = _db.Limit(limit)
	}
	if offset != 0 {
		_db = _db.Offset(offset)
	}

	return _db.Find()
}

func (p *workObjectAttr) FindOne(ctx context.Context, where map[string]interface{}) (*model.WorkObjectAttr, error) {
	_db := p.ParseWhere(ctx, where)

	return _db.Take()
}

func (p *workObjectAttr) UpdateMap(ctx context.Context, where, update map[string]interface{}) (info gen.ResultInfo, err error) {
	_db := p.ParseWhere(ctx, where)

	return _db.Updates(update)
}
