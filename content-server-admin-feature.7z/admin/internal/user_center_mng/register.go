package user_center_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"github.com/samber/lo"
	"gorm.io/gorm"
	"time"
)

func (u *UserCenterMng) genRegisterCode(ctx context.Context, phone string) (string, error) {
	code := lo.RandomString(6, lo.NumbersCharset)
	key := fmt.Sprintf("platform:%v:verify_sms_valid_register_%v", config.ServerConfig.Env, phone)
	return code, u.DataCache.GetImpl().RedisCli.Set(ctx, key, code, time.Minute*6).Err()
}

// QuickRegister 从java项目迁移过来，暂时用不到
// TODO 异常状态码统一
func (u *UserCenterMng) QuickRegister(ctx context.Context, channel string, phone string) (*pbapi.UserinfoDbModel, error) {
	ib, err := u.DataCache.GetImpl().UserInfoModel.FindBlackListByPhone(ctx, phone)
	if err != nil {
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			logger.Errorf(ctx, "FindBlackListByPhone fail, err: %v", err)
			return nil, err
		} else {
			fmt.Sprint(ib)
			logger.Infof(ctx, "user blocked, phone: %v", phone)
			return nil, fmt.Errorf("user blocked, phone: %v", phone)
		}
	}

	nickname, err := u.randUniqNickName(ctx, "小美_")
	if err != nil {
		return nil, fmt.Errorf("randUniqNickName fail, err: %v", err)
	}

	encPhone, _ := utils.AESEncrypt([]byte(phone), utils.AesUserKey)
	userinfo := &pbapi.UserinfoDbModel{
		AppFlag:  proto.Int32(5),
		Phone:    proto.String(encPhone),
		Gender:   proto.Int32(2), //默认女性
		NickName: proto.String(nickname),
		Type:     proto.Int32(1),
		UserId:   proto.Int64(snow_flake.GetSnowflakeID()),
		Source:   proto.Int32(1),
		Password: proto.String(utils.MD5(lo.RandomString(16, lo.AllCharset))), //TODO 确认默认密码
	}

	err = u.DataCache.GetImpl().UserInfoModel.Insert(ctx, userinfo)
	if err != nil {
		logger.Errorf(ctx, "Insert user fail, err: %v", err)
		return nil, err
	}

	// TODO 用户头像缓存是否必要？
	// TODO 通知es更新
	// 写mongo
	ext := &pbapi.SecretUserExtInfoMgDbModel{
		Id:       userinfo.GetUserId(),
		NickName: userinfo.NickName,
		Ulevel:   proto.Int32(1),
		TalkMode: proto.Int32(2), //闭关
	}
	if ch, ok := cm_const.ChannelDict[channel]; ok {
		ext.ChannelId = proto.Int64(ch)
	}
	err = u.DataCache.GetImpl().UserInfoExtMgModel.Insert(ctx, ext)
	if err != nil {
		logger.Errorf(ctx, "SecretUserExtInfoMgDbModel Insert fail, err: %v", err)
		return nil, err
	}

	// TODO 用户身份

	return userinfo, nil
}

func (u *UserCenterMng) randUniqNickName(ctx context.Context, prefix string) (string, error) {
	for {
		name := prefix + lo.RandomString(6, lo.AlphanumericCharset)
		user, err := u.DataCache.GetImpl().UserInfoExtMgModel.GetByNickname(ctx, name)
		if err != nil {
			return "", err
		}
		if user == nil {
			return name, nil
		}
		time.Sleep(10 * time.Millisecond)
	}
}
