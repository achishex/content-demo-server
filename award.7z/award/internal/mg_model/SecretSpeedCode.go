package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

type ISecretSpeedCodeMgModel interface {
	FindOne(ctx context.Context, filter any) (*pbmgdb.SecretSpeedCodeMgDbModel, error)
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretSpeedCodeMgDbModel, error)
	Create(ctx context.Context, userId int64, options ...*options.InsertOneOptions) (string, error)
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
}

type SecretSpeedCode struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretSpeedCodeMgModelImpl(db *mongo.Database) ISecretSpeedCodeMgModel {
	return &SecretSpeedCode{
		MgDB:  db,
		Table: "secretSpeedCode",
	}
}

func (g *SecretSpeedCode) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *SecretSpeedCode) FindOne(ctx context.Context, filter any) (*pbmgdb.SecretSpeedCodeMgDbModel, error) {
	var v *pbmgdb.SecretSpeedCodeMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretSpeedCode FindOne failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *SecretSpeedCode) Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretSpeedCodeMgDbModel, error) {
	find, err := g.coll().Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	retItems := make([]*pbmgdb.SecretSpeedCodeMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.SecretSpeedCodeMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretSpeedCode failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (g *SecretSpeedCode) Create(ctx context.Context, userId int64, options ...*options.InsertOneOptions) (string, error) {
	item := &pbmgdb.SecretSpeedCodeMgDbModel{
		FromUserId: userId,
		CreateTime: time.Now().UnixMilli(),
	}

	iTryTimes := 0
	speedCode := utils.GenRandomCkCode()
	for iTryTimes < 1000 {
		iTryTimes++
		item.SpeedCode = speedCode
		_, err := g.coll().InsertOne(ctx, item, options...)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("SecretSpeedCode.Create error. item=%v", item), err)
			continue
		}
		break
	}

	return speedCode, nil
}

func (g *SecretSpeedCode) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "SecretSpeedCode:updateOne error: %v", err)
		return err
	}

	return nil
}
