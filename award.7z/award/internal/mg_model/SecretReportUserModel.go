package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretReportUserMgModel interface {
	Create(ctx context.Context, data *pbmgdb.SecretReportUserMng, opts ...*options.InsertOneOptions) error
	FindOne(ctx context.Context, filter bson.D, opts ...*options.FindOneOptions) (*pbmgdb.SecretReportUserMng, error)
	FindAll(ctx context.Context, filter bson.D, opts ...*options.FindOptions) ([]*pbmgdb.SecretReportUserMng, error)
	Count(ctx context.Context, filter bson.D, opts ...*options.CountOptions) (int64, error)
	UpdateMap(ctx context.Context, filter, update map[string]interface{}) (*mongo.UpdateResult, error)
}

type secretReportUserMgModelImpl struct {
	MgDB       *mongo.Database
	Collection *mongo.Collection
}

func NewSecretReportUserMgModelImpl(db *mongo.Database) ISecretReportUserMgModel {
	record := &secretReportUserMgModelImpl{MgDB: db}
	record.Collection = record.MgDB.Collection(record.tableName())
	return record
}

func (impl *secretReportUserMgModelImpl) tableName() string {
	return "secretReportUser"
}

func (impl *secretReportUserMgModelImpl) Create(ctx context.Context, data *pbmgdb.SecretReportUserMng, opts ...*options.InsertOneOptions) error {
	result, err := impl.Collection.InsertOne(ctx, data, opts...)
	if err != nil {
		return err
	}

	id, ok := result.InsertedID.(int64)
	if !ok {
		return nil
	}
	data.ID = id
	return nil
}

func (impl *secretReportUserMgModelImpl) Update() {}
func (impl *secretReportUserMgModelImpl) Delete() {}

func (impl *secretReportUserMgModelImpl) Count(ctx context.Context, filter bson.D, opts ...*options.CountOptions) (int64, error) {
	return impl.Collection.CountDocuments(ctx, filter, opts...)
}
func (impl *secretReportUserMgModelImpl) FindOne(ctx context.Context, filter bson.D, opts ...*options.FindOneOptions) (*pbmgdb.SecretReportUserMng, error) {
	result := &pbmgdb.SecretReportUserMng{}
	err := impl.Collection.FindOne(ctx, filter, opts...).Decode(result)
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (impl *secretReportUserMgModelImpl) FindAll(ctx context.Context, filter bson.D, opts ...*options.FindOptions) ([]*pbmgdb.SecretReportUserMng, error) {
	cur, err := impl.Collection.Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	result := make([]*pbmgdb.SecretReportUserMng, 0)
	for cur.Next(ctx) {
		item := &pbmgdb.SecretReportUserMng{}
		if err := cur.Decode(item); err != nil {
			return nil, err
		}
		result = append(result, item)
	}

	return result, err
}

func (impl *secretReportUserMgModelImpl) UpdateMap(ctx context.Context, filter, update map[string]interface{}) (*mongo.UpdateResult, error) {
	conds := bson.D{}
	for key, value := range filter {
		conds = append(conds, bson.E{Key: key, Value: value})
	}

	data := bson.D{}
	for key, value := range update {
		data = append(data, bson.E{Key: key, Value: value})
	}
	updater := bson.D{
		{Key: "$set", Value: data},
	}

	return impl.Collection.UpdateMany(ctx, conds, updater)
}
