package shumei

import (
	"content_svr/app/maozhua_admin_svr/api/internal/config"
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"context"
	"encoding/json"
	"github.com/go-resty/resty/v2"
	"github.com/zeromicro/go-zero/core/logx"
)

type ShuMei struct {
	accessKey string
	account   string
	appId     string
	channel   string
}

func NewShuMeiSvc(c config.Config) *ShuMei {
	return &ShuMei{
		accessKey: c.ShuMeiConfig.AccessKey,
		account:   c.ShuMeiConfig.Account,
		appId:     c.ShuMeiConfig.AppId,
		channel:   c.ShuMeiConfig.Channel,
	}
}

type response struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

func (s *ShuMei) post(ctx context.Context, url string, body any) (*response, error) {
	r := resty.New().R()

	header := map[string]string{
		"Content-Type": "application/json",
		"X-Accesskey":  s.accessKey,
	}

	v, err := r.SetHeaders(header).SetBody(body).Post(url)
	if err != nil {
		logx.WithContext(ctx).Errorf("shu mei post error : %v", err)
		return nil, err
	}
	logx.WithContext(ctx).Infof("resp: %v", v)

	var resp response
	_ = json.Unmarshal(v.Body(), &resp)

	if resp.Code != 1100 {
		return nil, xerr.NewErrCodeMsg(uint32(resp.Code), resp.Message)
	}

	return &resp, nil
}
