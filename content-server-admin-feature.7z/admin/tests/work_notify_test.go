package tests

import (
	"content_svr/internal/notify_mng"
	"context"
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestWorkNotify(t *testing.T) {
	ctx := context.Background()

	//uid := int64(4725532565906432) // xxx6
	//uid := int64(4838279832698880)
	wid := int64(4838565880497152)

	uids := []int64{
		//4439138144000000,
		4825160158905344,
		//4725532565906432, //mingdong测试账号
		//4600155971848192, //and
		//4560547417753600, //ios
		//4838267042234368, //old and
		//4838279832698880, //old ios
	}

	e := c.Invoke(func(comp *notify_mng.WorkNotifyComp) error {
		for _, uid := range uids {
			if err := comp.PushWorkMsgByWorkID(ctx, uid, wid); err != nil {
				return err
			}
		}
		return nil
	})
	assert.Nil(t, e)
}
