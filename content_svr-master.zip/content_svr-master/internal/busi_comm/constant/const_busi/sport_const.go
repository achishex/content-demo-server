package const_busi

const (
	MaxValidSteIpNumsForUser = 30000
)
const (
	SportActivityOn        int32 = 0 //活动进行中
	SportActivityClose     int32 = 1 //活动已经截止，等待开奖
	SportActivityOpenAward int32 = 2 //活动已开奖
)

const NoSportActivityRank = 1000
