package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"time"
)

// 获取用户签到信息。
func (p *DataCacheMng) GetUserDailySignFlag(ctx context.Context, userId int64) bool {
	redisKey := fmt.Sprintf(cache_const.UserDailySignRcache.KeyFmt, userId, utils.GetCurDate())
	bSigned, _ := p.RedisCli.Get(ctx, redisKey).Bool()
	return bSigned
}

// 设置用户签到信息
func (p *DataCacheMng) SetUserDailySignFlag(ctx context.Context, userId int64) error {
	redisKey := fmt.Sprintf(cache_const.UserDailySignRcache.KeyFmt, userId, utils.GetCurDate())
	expire := cache_const.UserDailySignRcache.Expire
	_, err := p.RedisCli.Set(ctx, redisKey, true, time.Duration(expire)*time.Second).Result()
	return err
}

// 清理 UserDailySignFlag
func (p *DataCacheMng) DelUserDailySignFlag(ctx context.Context, userId int64) error {
	redisKey := fmt.Sprintf(cache_const.UserDailySignRcache.KeyFmt, userId, utils.GetCurDate())
	err := p.RedisCli.Del(ctx, redisKey).Err()
	if err != nil && err != redis.Nil {
		logger.Errorf(ctx, "delkey failed. redisKey=%v, err=%v", redisKey, err)
		return err
	}
	logger.Infof(ctx, "DelUserDailySignFlag suc,key=%v", redisKey)
	return nil
}

//==========以下新版本用户签到============

// 获取用户签到信息。
func (p *DataCacheMng) GetUserDailySign(ctx context.Context, userId int64) bool {
	redisKey := fmt.Sprintf(cache_const.UserDailySignV2Rcache.KeyFmt, userId, utils.GetCurDate())
	bSigned, _ := p.RedisCli.Get(ctx, redisKey).Bool()
	return bSigned
}

// 设置用户签到信息
func (p *DataCacheMng) SetUserDailySign(ctx context.Context, userId int64) error {
	redisKey := fmt.Sprintf(cache_const.UserDailySignV2Rcache.KeyFmt, userId, utils.GetCurDate())
	expire := cache_const.UserDailySignV2Rcache.Expire
	_, err := p.RedisCli.Set(ctx, redisKey, true, time.Duration(expire)*time.Second).Result()
	return err
}

// 清理 DelUserDailySign
func (p *DataCacheMng) DelUserDailySign(ctx context.Context, userId int64) error {
	redisKey := fmt.Sprintf(cache_const.UserDailySignV2Rcache.KeyFmt, userId, utils.GetCurDate())
	err := p.RedisCli.Del(ctx, redisKey).Err()
	if err != nil && err != redis.Nil {
		logger.Errorf(ctx, "delkey failed. redisKey=%v, err=%v", redisKey, err)
		return err
	}
	logger.Infof(ctx, "DelUserDailySignFlag suc,key=%v", redisKey)
	return nil
}
