package job

import (
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"context"
	"fmt"
	"github.com/zeromicro/go-zero/core/threading"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

func InitMemberSum(write, read *dao.ManagerDB) {
	threading.GoSafe(func() {
		ctrl := newUserMemberSumControl(write, read)
		//ctrl.once()
		//return

		ctrl.Do(func() {
			ctx := requestid.WithRequestID(context.Background())
			if err := ctrl.DoTask(ctx, time.Now().AddDate(0, 0, -1)); err != nil {
				logger.Errorf(ctx, "newUserMemberSumControl.DoTask: %v", err)
				// 五分钟后重试
				ctrl.ticker.Reset(time.Minute * 5)
				return
			}

			ctrl.ticker.Reset(ctrl.calcIntervalTime())
		})

	})

}

type userMemberSumControl struct {
	TickerExecute
	write, read *dao.ManagerDB
}

func newUserMemberSumControl(write, read *dao.ManagerDB) userMemberSumControl {
	// 凌晨四点半执行
	ctrl := userMemberSumControl{}
	ctrl.hour = 4
	ctrl.minter = 30
	ctrl.write = write
	ctrl.read = read
	return ctrl
}

func (l userMemberSumControl) once() {
	//ctx := requestid.WithRequestID(context.Background())
	//now := time.Now()
	//target := now.AddDate(0, 0, -1)
	////target := time.Date(2022, 8, 10, now.Hour(), now.Minute(), now.Second(), now.Nanosecond(), now.Location())
	//if err := l.DoTask(ctx, target); err != nil {
	//	logger.Error(context.Background(), "InitMemberSum:", err)
	//}

	for i := 10; i > 0; i-- {
		ctx := requestid.WithRequestID(context.Background())
		now := time.Now()
		target := now.AddDate(0, 0, -i)
		//target := time.Date(2022, 8, 10, now.Hour(), now.Minute(), now.Second(), now.Nanosecond(), now.Location())
		if err := l.DoTask(ctx, target); err != nil {
			logger.Error(context.Background(), "InitMemberSum:", err)
		}
		//break
	}
}

func (l userMemberSumControl) DoTask(ctx context.Context, targetTime time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	data, err := l.calcMemberSum(ctx, targetTime)
	if err != nil {
		return err
	}

	if err := l.saveUserMemberStatistical(ctx, data, targetTime); err != nil {
		return err
	}

	logger.Infof(ctx, "%d 会员充值统计完成\n", l.baseTimeByDay(targetTime))
	return nil
}

func (l userMemberSumControl) calcMemberSum(ctx context.Context, targetTime time.Time) (*model.UserMemberStatistical, error) {

	gtTime := l.baseZeroTime(targetTime)
	ltTime := l.calcZeroTimeByDay(targetTime, 1)

	orders, err := l.read.OrderInfo.WithContext(ctx).Where(
		//l.read.OrderInfo.AppType.In("mobile-ios", "mobile-android"),
		l.read.OrderInfo.Type.Eq(1001),
		l.read.OrderInfo.OrderStatus.Eq(3),
		l.read.OrderInfo.CreateTime.Gt(gtTime.Format("2006-01-02 15:04:05")),
		l.read.OrderInfo.CreateTime.Lt(ltTime.Format("2006-01-02 15:04:05")),
	).Find()
	if err != nil {
		return nil, err
	}

	if len(orders) == 0 {
		return nil, fmt.Errorf("%v 无人充值", l.baseTimeByDay(targetTime))
	}

	data := &model.UserMemberStatistical{
		Day: l.baseZeroTime(targetTime).UnixMilli(),
	}
	for _, order := range orders {
		price := uint(order.Price)
		switch order.AppType {
		case "applet-qq":
			data.QQSum += price
		case "applet-wx":
			data.WeiXinSum += price
		case "mobile-android":
			data.AndroidSum += price
		case "mobile-ios":
			data.IosSum += price
		default:
			data.UnknownSum += price
			continue
		}

		data.PriceSum += price
	}

	return data, nil

}

func (l userMemberSumControl) saveUserMemberStatistical(ctx context.Context, data *model.UserMemberStatistical, targetTime time.Time) error {
	updateFilter := bson.D{
		{"day", data.Day},
	}

	update := bson.D{
		{"$set", data},
		{"$setOnInsert", bson.D{
			{"create_time", targetTime.UnixMilli()},
		}},
	}

	opt := options.Update().SetUpsert(true)
	if _, err := l.write.UserMemberStatistical.Update(ctx, updateFilter, update, opt); err != nil {
		return err
	}

	return nil
}
