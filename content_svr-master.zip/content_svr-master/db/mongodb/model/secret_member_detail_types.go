package model

const SecretMemberDetailCollectionName = "secretMemberDetail"

type SecretMemberDetail struct {
	ID int64 `bson:"_id" json:"id"`

	Day       int   `json:"day" bson:"day"`             // 20231020
	OrderId   int64 `json:"order_id" bson:"orderId"`    // 订单id
	Price     uint  `json:"price" bson:"price"`         // 消费额
	Timestamp int64 `json:"timestamp" bson:"timestamp"` // 创建时间
	Type      int   `json:"type" bson:"type"`           // 1.SVIP 2护卫队vip 3VIP
	UserId    int64 `json:"user_id" bson:"userId"`      // 用户id

}
