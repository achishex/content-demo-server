package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var _ SecretMemberInfoModel = (*customSecretMemberInfoModel)(nil)

type (
	// SecretMemberInfoModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretMemberInfoModel.
	SecretMemberInfoModel interface {
		secretMemberInfoModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretMemberInfo, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretMemberInfo, error)
	}

	customSecretMemberInfoModel struct {
		*defaultSecretMemberInfoModel
	}
)

// NewSecretMemberInfoModel returns a model for the mongo.
func NewSecretMemberInfoModel(cfg MonConfig) SecretMemberInfoModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SecretMemberInfoCollectionName)
	return &customSecretMemberInfoModel{
		defaultSecretMemberInfoModel: newDefaultSecretMemberInfoModel(conn),
	}
}

func (m *customSecretMemberInfoModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			switch k {
			case "user_ids":
				query = append(query, bson.E{Key: "userId", Value: bson.D{
					{"$in", v},
				}})
			default:
				query = append(query, bson.E{Key: k, Value: v})
			}
		}
	}
	return query
}

func (m *customSecretMemberInfoModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretMemberInfo, error) {
	result := make([]SecretMemberInfo, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretMemberInfoModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretMemberInfoModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretMemberInfo, error) {
	var data SecretMemberInfo
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
