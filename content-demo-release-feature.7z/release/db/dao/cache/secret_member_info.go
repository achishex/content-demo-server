package cache

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/redisdb/query_rds"
	"context"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type SecretMemberInfo struct {
	model.SecretMemberInfoModel
	model.SecretUserExtInfoModel
	redisManage *query_rds.Manage
}

func NewCacheSecretMemberInfo(q *query_mng.QueryMng, redisManage *query_rds.Manage) *SecretMemberInfo {
	return &SecretMemberInfo{
		SecretMemberInfoModel:  q.SecretMemberInfo,
		SecretUserExtInfoModel: q.SecretUserExtInfo,
		redisManage:            redisManage,
	}
}

func (p *SecretMemberInfo) Insert(ctx context.Context, data *model.SecretMemberInfo) error {
	_, err := p.SecretMemberInfoModel.Insert(ctx, data)
	if err != nil {
		return err
	}

	return nil
}

func (p *SecretMemberInfo) FindById(ctx context.Context, id string) (*model.SecretMemberInfo, error) {
	return p.SecretMemberInfoModel.FindById(ctx, id)
}

func (p *SecretMemberInfo) Delete(ctx context.Context, id string) (int64, error) {
	return p.SecretUserExtInfoModel.Delete(ctx, id)
}

func (p *SecretMemberInfo) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]model.SecretMemberInfo, error) {
	return p.SecretMemberInfoModel.FindAll(ctx, filter, opts...)
}

func (p *SecretMemberInfo) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*model.SecretMemberInfo, error) {
	return p.SecretMemberInfoModel.FindOne(ctx, filter, opts...)
}

func (p *SecretMemberInfo) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	return p.SecretMemberInfoModel.Count(ctx, filter, opts...)
}

func (p *SecretMemberInfo) FindAllByUserIds(ctx context.Context, userIds []int64) ([]model.SecretMemberInfo, error) {
	result, err := p.SecretMemberInfoModel.FindAll(ctx, map[string]interface{}{
		"user_ids": userIds,
	})
	switch err {
	case xerr.DbNotFound:
		return nil, xerr.DbNotFound
	case nil:
		return result, nil
	default:
		return nil, err
	}

}

func (p *SecretMemberInfo) FindByUserId(ctx context.Context, userId int64) (*model.SecretMemberInfo, error) {
	result, err := p.SecretMemberInfoModel.FindOne(ctx, map[string]interface{}{
		"userId": userId,
	})
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (p *SecretMemberInfo) Update(ctx context.Context, data *model.SecretMemberInfo) error {
	result, err := p.SecretMemberInfoModel.UpdateOne(ctx, data.ID, data)
	switch {
	case err == xerr.DbNotFound:
		return xerr.DbNotFound
	case err == nil:
		if result.ModifiedCount == 0 {
			return xerr.DbDoNothing
		}
		return nil
	default:
		return err
	}
}

func (p *SecretMemberInfo) UpdateMap(ctx context.Context, filter, update map[string]interface{}, opts ...*options.UpdateOptions) error {
	result, err := p.SecretMemberInfoModel.UpdateMap(ctx, filter, update, opts...)
	if err != nil {
		return err
	}
	if result.ModifiedCount == 0 {
		return xerr.DbDoNothing
	}

	return nil
}
