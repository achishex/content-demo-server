package vip_mng

type VipRightsConf struct {
	Vip            VipDesc    `json:"vip"`
	SVip           VipDesc    `json:"svip"`
	SVipRightsHead []VipRight `json:"svip_rights_head"`
}

type VipDesc struct {
	Name   string     `json:"name"`
	Type   int        `json:"type"`
	Rights []VipRight `json:"rights"`
}

type VipRight struct {
	Icon    string `json:"icon"`
	Title   string `json:"title"`
	Content string `json:"content"`
}
