package mg_model

import (
	"content_svr/config"
	"content_svr/protobuf/pbapi"
	"context"
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestAtDetailAll(t *testing.T) {
	// 初始化mongoDB
	ctx := context.Background()
	mgDb, err := NewMongoDBInstance(config.ServerConfig.MongodbConfig)
	if err != nil {
		t.Error("new mongo db instansce failed", err)
		return
	}

	db = mgDb.Database("platform_test")
	at := NewAtDetailMgModel(db)

	atgs := []*pbapi.RemindGroupNode{
		{
			GroupID: "g1",
			Offset:  1,
			Size:    1,
		},
		{
			GroupID: "g2",
			Offset:  2,
			Size:    2,
		},
	}
	err = at.InsertCommentAtGroup(ctx, 999, atgs)
	assert.Nil(t, err)

	got, err := at.ListCommentAtGroup(ctx, 1000)
	assert.Nil(t, err)
	t.Log(got)
}
