package ad_mng

import (
	model2 "content_svr/db/mongodb/model"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"github.com/samber/lo"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

type ADMng struct {
	adModel model2.AppAdvertisementModel
}

func NewADMng(adModel model2.AppAdvertisementModel) *ADMng {
	return &ADMng{adModel: adModel}
}

func (m *ADMng) GetAppAd(ctx context.Context) (*pbapi.GetAppAdvertisementResp, error) {
	nowMs := time.Now().UnixMilli()

	ads, err := m.adModel.FindAll(ctx, map[string]interface{}{
		"enable":     true,
		"start_time": bson.D{{"$lte", nowMs}},
		"end_time":   bson.D{{"$gt", nowMs}},
	})
	if err != nil {
		logger.Errorf(ctx, "find ad fail, err: %v", err)
		return nil, err
	}

	pbads := lo.Map(ads, func(it model2.AppAdvertisement, _ int) *pbapi.AppAdvertisement {
		return &pbapi.AppAdvertisement{
			Id:        it.ID.Hex(),
			Name:      it.Name,
			Type:      it.Type,
			Weight:    int32(it.Weight),
			Cover:     it.Cover,
			Content:   it.Content,
			Dur:       int64(it.Dur),
			RewardDur: int64(it.RewardDur),
			JumpUrl:   it.JumpURL,
			EndTime:   it.EndTime,
		}
	})

	return &pbapi.GetAppAdvertisementResp{AppAd: pbads}, nil
}
