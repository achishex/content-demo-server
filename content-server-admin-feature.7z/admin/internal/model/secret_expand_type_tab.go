package model

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"content_svr/pub/utils"
	"context"
	"gorm.io/gorm"
)

type ISecretExpandTypeDbModel interface {
	ListItemsPathsByCondition(ctx context.Context,
		condition map[string]interface{}, page uint64, size uint64) ([][]*pbapi.SecretExpandTypeDbModel, error)
	ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbapi.SecretExpandTypeDbModel, error)
}

type SecretExpandTypeDbModelImpl struct {
	DB *gorm.DB
}

func NewSecretExpandTypeDbModelImpl(db *gorm.DB) ISecretExpandTypeDbModel {
	return &SecretExpandTypeDbModelImpl{DB: db}
}

func (impl *SecretExpandTypeDbModelImpl) ListItemsPathsByCondition(ctx context.Context,
	condition map[string]interface{}, page uint64, size uint64) ([][]*pbapi.SecretExpandTypeDbModel, error) {
	resp := make([][]*pbapi.SecretExpandTypeDbModel, 0)

	// 查询当前id对应的记录
	srcItems, err := impl.ListItemsByCondition(ctx, condition, page, size)
	if err != nil {
		return nil, err
	}
	if len(srcItems) == 0 {
		return resp, nil
	}

	ids := make([]int64, 0)
	srcIdMap := make(map[int64][]int64)
	for _, item := range srcItems {
		tmpIds := utils.GetIdListFromFmtPath(item.GetPath())
		if len(tmpIds) == 0 {
			continue
		}
		ids = append(ids, tmpIds...)

		curIds := srcIdMap[item.GetId()]
		if len(curIds) == 0 {
			srcIdMap[item.GetId()] = tmpIds
		}
	}
	ids = utils.Int64Set(ids) //去重

	if len(ids) == 0 {
		return resp, nil
	}

	// 查询所有id记录
	cond := map[string]interface{}{"id": ids}
	allItemsDict := make(map[int64]*pbapi.SecretExpandTypeDbModel)
	allItems, err := impl.ListItemsByCondition(ctx, cond, 1, cm_const.MaxDbSize)
	for _, item := range allItems {
		allItemsDict[item.GetId()] = item
	}

	//筛选出所有list
	for _, srcItem := range srcItems {
		destIds := srcIdMap[srcItem.GetId()]
		if len(destIds) == 0 {
			continue
		}
		objList := make([]*pbapi.SecretExpandTypeDbModel, 0)
		for _, id := range destIds {
			obj := allItemsDict[id]
			if obj == nil {
				continue
			}
			objList = append(objList, obj)
		}
		resp = append(resp, objList)
	}
	return resp, nil
}

func (impl *SecretExpandTypeDbModelImpl) ListItemsByCondition(ctx context.Context,
	condition map[string]interface{}, page uint64, size uint64) ([]*pbapi.SecretExpandTypeDbModel, error) {

	offset := (page - 1) * size
	var items []*pbapi.SecretExpandTypeDbModel
	result := impl.DB.WithContext(ctx).Table("secret_expand_type").
		Limit(int(size)).Offset(int(offset)).Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}
