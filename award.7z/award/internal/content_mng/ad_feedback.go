package content_mng

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"encoding/json"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

func (p *ContentMng) adFeedbackV2(ctx context.Context, channel string, machineIds ...string) {
	for _, id := range machineIds {
		if id == "" {
			continue
		}
		code := p.DataCache.GetRedisAdFeedback(ctx, channel, id)
		if code == const_busi.AdFeedbackNil {
			if err := p.DataCache.SetRedisAdFeedback(ctx, channel, id, const_busi.AdFeedbackFormChannel); err != nil {
				logger.Error(ctx, "SetRedisAdFeedback error:", err)
			}
		}
	}
}

func (p *ContentMng) adFeedback(ctx context.Context, channel, imei, oaid string) {
	ImeiCodeOrUserId := p.DataCache.GetRedisAdFeedback(ctx, channel, imei)
	OaidCodeOrUserId := p.DataCache.GetRedisAdFeedback(ctx, channel, oaid)

	switch {
	case ImeiCodeOrUserId > const_busi.AdFeedbackFormChannel:
		// 说明是userId
		// update
		p.adActivityDailyUpdate(ctx, int64(ImeiCodeOrUserId))
	case OaidCodeOrUserId > const_busi.AdFeedbackFormChannel:
		p.adActivityDailyUpdate(ctx, int64(OaidCodeOrUserId))
	case ImeiCodeOrUserId == const_busi.AdFeedbackFormChannel, OaidCodeOrUserId == const_busi.AdFeedbackFormChannel:
		break
	default:
		logger.Infof(ctx, "==market==%s,Imei: %s Oaid: %s\n", channel, imei, oaid)
		if len(imei) > 0 {
			if err := p.DataCache.SetRedisAdFeedback(ctx, channel, imei, const_busi.AdFeedbackFormChannel); err != nil {
				logger.Error(ctx, "SetRedisAdFeedback error:", err)
			}
		}

		if len(oaid) > 0 {
			if err := p.DataCache.SetRedisAdFeedback(ctx, channel, oaid, const_busi.AdFeedbackFormChannel); err != nil {
				logger.Error(ctx, "SetRedisAdFeedback error:", err)
			}
		}
	}
}

func (p *ContentMng) adActivityDailyUpdate(ctx context.Context, userId int64) {
	now := time.Now()
	//dateStr := fmt.Sprintf("%04d%02d%02d", now.Year(), now.Month(), now.Day())
	//day, _ := strconv.Atoi(dateStr)
	day, _ := utils.TimeByDay(now)

	filter := bson.D{
		{"user_id", userId},
		{"day", day},
		{"is_new", 1},
	}
	_, err := p.DataCache.GetImpl().SecretUserActivityDailyMgModel.FindOne(ctx, filter)
	if err != nil {
		logger.Error(ctx, "ad vivo SecretUserActivityDailyMgModel.FindOne", err)
		return
	}

	update := bson.D{
		{"$set", bson.D{
			{"market", 1},
		}},
	}
	_, err = p.DataCache.GetImpl().SecretUserActivityDailyMgModel.Update(ctx, filter, update)
	if err != nil {
		logger.Error(ctx, "ad vivo SecretUserActivityDailyMgModel.Update", err)
		return
	}
}

func (p *ContentMng) AdVivoFeedback(ctx context.Context, req []*pbapi.AdVivoFeedbackDbModel) (*pbapi.AdVivoFeedbackResp, error) {
	// create vivo
	// update user activity table
	if err := p.DataCache.GetImpl().AdVivoFeedbackDbModel.Create(ctx, req); err != nil {
		return &pbapi.AdVivoFeedbackResp{Code: -1, Msg: "操作失败"}, err
	}

	for _, ad := range req {
		p.adFeedback(ctx, cm_const.AppChannelVivo, ad.GetImei(), ad.GetOaid())
	}

	return &pbapi.AdVivoFeedbackResp{Code: 0, Msg: "操作成功"}, nil
}

func (p *ContentMng) AdOppoFeedback(ctx context.Context, req *pbapi.AdOppoFeedbackReq) (*pbapi.AdOppoFeedbackResp, error) {
	p.adFeedback(ctx, cm_const.AppChannelOppo, req.GetImeiMd5(), req.GetOaid())

	return &pbapi.AdOppoFeedbackResp{Code: 0, Msg: "操作成功"}, nil
}

//func (p *ContentMng) AdXiaomiFeedback(ctx context.Context, req *pbapi.AdXiaomiFeedbackReq) (*pbapi.AdXiaomiFeedbackResp, error) {
//	p.adFeedback(ctx, cm_const.AppChannelXiaomi, req.GetImei(), req.GetOaid())
//
//	resp, err := adXiaomiCallback(ctx, req)
//	if err != nil {
//		logger.Error(ctx, "adXiaomiCallback: ", err)
//		return &pbapi.AdXiaomiFeedbackResp{Code: -2, FailMsg: "", Success: false}, err
//	}
//
//	return resp, nil
//}

func (p *ContentMng) AdXiaomiFeedback(ctx context.Context, req *pbapi.AdXiaomiFeedbackReq) (*pbapi.AdXiaomiFeedbackResp, error) {
	p.adFeedback(ctx, cm_const.AppChannelXiaomi, req.GetImei(), req.GetOaid())

	b, err := json.Marshal(req)
	if err != nil {
		logger.Error(ctx, "json.Marshal", err)
		return nil, err
	}
	//_ = p.DataCache.GetImpl().SetRedisAdCallback(ctx, cm_const.AppChannelXiaomi, req.GetImei(), string(b))
	//_ = p.DataCache.GetImpl().SetRedisAdCallback(ctx, cm_const.AppChannelXiaomi, req.GetOaid(), string(b))
	p.setCallbackData(ctx, cm_const.AppChannelXiaomi, string(b), req.GetImei(), req.GetOaid())

	return &pbapi.AdXiaomiFeedbackResp{Code: 0}, nil
}

func (p *ContentMng) AdBaiduFeedback(ctx context.Context, req *pbapi.AdBaiduFeedbackReq) error {
	p.adFeedbackV2(ctx, cm_const.AppChannelBaidu, req.GetImeiMd5(), req.GetOaid())

	b, err := json.Marshal(req)
	if err != nil {
		logger.Error(ctx, "json.Marshal", err)
		return err
	}
	p.setCallbackData(ctx, cm_const.AppChannelBaidu, string(b), req.GetImeiMd5(), req.GetOaid())

	return nil
}

func (p *ContentMng) AdGdtFeedbackReq(ctx context.Context, req *pbapi.AdGdtFeedbackReq) error {
	return nil
}

func (p *ContentMng) AdToutiaoFeedbackReq(ctx context.Context, req *pbapi.AdToutiaoFeedbackReq) error {
	return nil
}
