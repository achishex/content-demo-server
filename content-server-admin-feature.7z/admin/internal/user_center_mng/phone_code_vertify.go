package user_center_mng

import (
	"content_svr/config"
	"content_svr/internal/data_cache"
	"content_svr/pub/logger"
	"context"
	"fmt"
)

type PhoneVerifyLogic struct {
	Code      string
	Phone     string
	MsgType   string
	DataCache data_cache.IDataCacheMng
}

const (
	SmsTypeEnumRegister    int32 = iota //注册
	SmsTypeEnumForgetPwd                //忘记密码
	SmsTypeEnumModifyPhone              //绑定手机号
	SmsTypeEnumLogOff                   //注销
	SmsTypeEnumUnbindPhone              //解绑手机号
	SmsTypeEnumLogin                    //登录
	SmsTypeEnumWithdraw                 //提现 （新增）
)

var SmsTypeDesc = map[int32]string{
	SmsTypeEnumRegister:    "register",
	SmsTypeEnumForgetPwd:   "forgetPwd",
	SmsTypeEnumModifyPhone: "modify_phone",
	SmsTypeEnumLogOff:      "log_off",
	SmsTypeEnumUnbindPhone: "unbind_phone",
	SmsTypeEnumLogin:       "login",
	SmsTypeEnumWithdraw:    "withdraw",
}

const WithdrawMsgType = 121312

func NewIPhoneVerify(phone, code string, msgType string, cache data_cache.IDataCacheMng) *PhoneVerifyLogic {
	return &PhoneVerifyLogic{
		Code:      code,
		Phone:     phone,
		MsgType:   msgType,
		DataCache: cache,
	}
}
func (p *PhoneVerifyLogic) buildCodeCacheKey() string {
	key := fmt.Sprintf("platform:%v:verify_sms_valid_%s_%s", config.ServerConfig.Env, p.MsgType, p.Phone)
	return key
}
func (p *PhoneVerifyLogic) buildSendLimitKey() string {
	key := fmt.Sprintf("platform:%v:send_sms_limit_%v_%v", config.ServerConfig.Env, p.MsgType, p.Phone)
	return key
}
func (p *PhoneVerifyLogic) VerifyCode(ctx context.Context) (bool, error) {
	if len(p.Code) <= 0 || len(p.Phone) <= 0 {
		return false, nil
	}
	codeCacheKey, sendLimitKey := p.buildCodeCacheKey(), p.buildSendLimitKey()
	cacheCode, err := p.DataCache.GetImpl().RedisCli.Get(ctx, codeCacheKey).Result()
	if err != nil {
		logger.Errorf(ctx, "get code cache from redis fail, err: %v, key: %v", err, codeCacheKey)
		return false, err
	}
	if cacheCode != p.Code {
		return false, nil
	}
	p.DataCache.GetImpl().RedisCli.Del(ctx, codeCacheKey)
	p.DataCache.GetImpl().RedisCli.Del(ctx, sendLimitKey)
	return true, nil
}
