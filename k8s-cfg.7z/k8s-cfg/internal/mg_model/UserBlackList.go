package mg_model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"time"
)

type IUserBlackListMgModel interface {
	CheckInBlackList(ctx context.Context, userId, targetUserId int64) (bool, error)
	AddToBlackList(ctx context.Context, userId, targetUserId int64) (bool, error)
}

type UserBlackListMgDbImpl struct {
	MgDB *mongo.Database
}

func NewUserBlackListMgModelImpl(db *mongo.Database) IUserBlackListMgModel {
	return &UserBlackListMgDbImpl{MgDB: db}
}

// 查不到返回nil
func (impl *UserBlackListMgDbImpl) CheckInBlackList(ctx context.Context,
	userId, targetUserId int64) (bool, error) {
	retItems := make([]*pbapi.UserBlackListMgDbModel, 0)
	collection := impl.MgDB.Collection("userBlackList")
	find, err := collection.Find(ctx, bson.M{"userId": userId, "appFlag": 5, "targetUserId": targetUserId}) // appFlag=5 soul_soup  AppNameFlagDict
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("UserBlackListMgDbModel Find failed.userid=%v",
			userId), err)
		return false, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.UserBlackListMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to UserBlackListMgDbModel failed.userid=%v",
				userId), err)
			return false, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return false, nil
	}
	return true, err
}

// AddToBlackList 拉黑
func (impl *UserBlackListMgDbImpl) AddToBlackList(ctx context.Context, userId, targetUserId int64) (bool, error) {
	c := impl.MgDB.Collection("userBlackList")

	d := &pbapi.UserBlackListMgDbModel{
		Id:           snow_flake.GetSnowflakeID(),
		UserId:       userId,
		AppFlag:      5,
		TargetUserId: targetUserId,
		Source:       1,
		CreateTime:   time.Now().UnixMilli(),
	}

	_, err := c.InsertOne(ctx, d)
	if err != nil {
		return false, err
	}

	return true, nil
}
