package job

var (
	// RobotServerControl 飞书serve群里的机器人
	RobotServerControl robotServer
	// RobotBossControl 飞书正式群里的机器人
	RobotBossControl     robotBoss
	RobotGameControl     robotGame
	RobotFacaimaoControl robotFacaimao
)

type robotServer struct {
	robotControl
}

func InitServeRobot() {
	RobotServerControl = robotServer{}
	//RobotServerControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/c02670dc-de16-4af0-a234-d90af25c6f13" // server群，测试用
	RobotServerControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/413b5b96-5259-4ecf-b0dd-d14f976b940c" // test群，测试用
	RobotServerControl.msgChan = make(chan Message, 100)

	go RobotServerControl.monitor()
}

type robotBoss struct {
	robotControl
}

func InitBossRobot() {
	RobotBossControl = robotBoss{}
	RobotBossControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/afd15198-34ea-4788-a306-2e94630458de" // 正式群，不要乱推数据
	RobotBossControl.msgChan = make(chan Message, 100)

	go RobotBossControl.monitor()
}

type robotGame struct {
	robotControl
}

func InitGameRobot() {
	RobotGameControl = robotGame{}
	RobotGameControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/88bfddba-c5cd-4d31-a323-4173cec0f712" // 游戏正式群，不要乱推数据
	RobotGameControl.msgChan = make(chan Message, 100)

	go RobotGameControl.monitor()
}

type robotFacaimao struct {
	robotControl
}

func InitFacaimaoRobot() {
	RobotFacaimaoControl = robotFacaimao{}
	RobotFacaimaoControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/97f9603f-b83b-4ae4-8f75-81aed37f4cb3" // 发财猫正式群，不要乱推数据
	RobotFacaimaoControl.msgChan = make(chan Message, 100)

	go RobotFacaimaoControl.monitor()
}
