package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type SmsRecord struct {
	model.SmsRecordModel
	redisManage *query_rds.Manage
}

func NewCacheSmsRecord(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *SmsRecord {
	return &SmsRecord{
		SmsRecordModel: mongo.SmsRecord,
		redisManage:    redisManage,
	}
}
