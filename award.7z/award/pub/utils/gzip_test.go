package utils

import (
	"github.com/samber/lo"
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestGZip(t *testing.T) {
	input := []byte("hello gzip!")
	enc := GZip(input)
	t.Log(string(enc))
	t.Log(len(input))
	t.Log(len(enc))

	got, err := GUnZip(enc)
	assert.Nil(t, err)
	assert.Equal(t, input, got)
}

func TestGZipLen(t *testing.T) {
	for i := 1; i < 1024; i += 30 {
		s := lo.RandomString(i, lo.AllCharset)
		enc := GZip([]byte(s))
		t.Log(i, len(s), len(enc), float64(len(enc))/float64(len(s)))
	}
}
