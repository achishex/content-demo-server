package middleware

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/im_mng/open_im_api"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"encoding/json"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis/v8"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
)

const (
	appReqHeaderToken   = "Token"
	appReqHeaderImToken = "ImToken"
)

var routerWhiteList = []string{
	"/platform/secret/bottleWorks/share",
	"/platform/api/upload/log",
	"/platform/api/comm/get_app_config",
	"/platform/api/ad/behavior_upload",
	"/platform/api/ad/behavior_upload/v2",
	"/platform/api/ad/vivo/feedback",
	"/platform/api/ad/oppo/feedback",
	"/platform/api/ad/xiaomi/feedback",
	"/platform/api/ad/baidu/feedback",
	"/platform/api/ad/gdt/feedback",
	"/platform/api/ad/toutiao/feedback",

	"/platform/api/user/check_update_user_info",
	"/platform/api/user/work/comment_pull",
	"/platform/api/user/work/comment_pull/v2",
	"/platform/api/inner/audit/notify",
	"/platform/api/inner/check_phone",
	"/platform/api/wechat/pay/notify",
	"/platform/debug/bottleWorks/rm_timeout_works",
	"/platform/debug/common_debug",
	"/platform/api/im/callback",
	"/platform/api/internal/im/sync_user_info",
	"/platform/api/user/quick_login",
}

func AppTokenMiddleware(redis_cli *redis.Client) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		imToken := ctx.Request.Header.Get(appReqHeaderImToken)
		if imToken != "" {
			logger.Infof(ctx, "ImToken:%v", imToken)
			ctx.Set(open_im_api.CtxApiToken, imToken)
		}

		u, err := url.Parse(ctx.Request.RequestURI)
		if err != nil {
			return
		}
		uri := u.Path
		if config.ServerConfig.IsDebug && ctx.Request.Header.Get("Debuguserid") != "" {
			uid, _ := strconv.ParseInt(ctx.Request.Header.Get("Debuguserid"), 10, 64)
			SetUserID(ctx, uid)
			ctx.Next()
			return
		}

		token := ctx.Request.Header.Get(appReqHeaderToken)
		if token != "" {
			rdsKey := fmt.Sprintf(cache_const.UserTokenRcache.KeyFmt, token)
			dateBytes, err := redis_cli.Get(ctx, rdsKey).Result()
			if err == nil && len(dateBytes) != 0 {
				resp := &pbapi.LoginTokenRedis{}
				json.Unmarshal([]byte(dateBytes), resp)
				SetUserID(ctx, resp.GetUserId())
				ctx.Next()
			} else {
				checkLoginInvalid(ctx, uri)
				return
			}
		} else {
			if config.ServerConfig.Env == "test" {
				uid, _ := strconv.ParseInt(ctx.Request.Header.Get("Debuguserid"), 10, 64)
				SetUserID(ctx, uid)
				ctx.Next()
			}

			checkLoginInvalid(ctx, uri)
			return
		}
	}
}

func checkLoginInvalid(ctx *gin.Context, uri string) {
	for _, v := range routerWhiteList {
		if v == uri {
			ctx.Next()
			return
		}
	}

	result := errors.CliError{
		Message:   errorcode.LOGIN_INVALID.ErrMsg,
		MessageId: utils.GetLocalIp() + "_" + requestid.GetRequestID(ctx),
		Status:    errorcode.LOGIN_INVALID.UserErrCode,
		Timestamp: time.Now().UnixNano() / 1e6,
		CostTime:  0,
	}
	ctx.AbortWithStatusJSON(200, result)

	logger.Infof(ctx, "check_login_invalid return login invalid")
}

func AdminAuthMiddleware(redis_cli *redis.Client) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		u, err := url.Parse(ctx.Request.RequestURI)
		if err != nil {
			return
		}
		uri := u.Path

		if uri == "/test/" || uri == "/metrics" {
			ctx.Next()
			return
		}

		token := ctx.Request.Header.Get(appReqHeaderToken)
		// 除了登录外，其他接口都必须传入token
		if token == "" && !strings.Contains(uri, "admin/mz/api/operator/login_in") {
			logger.Errorf(ctx, "token not find")
			ctx.AbortWithStatus(http.StatusForbidden)
			return
		}

		if token != "" {
			rdsKey := fmt.Sprintf(cache_const.AdminTokenRcache.KeyFmt, token)
			emailBytes, err := redis_cli.Get(ctx, rdsKey).Bytes()
			if err != nil {
				logger.Errorf(ctx, "token not find, rdsKey=%v, err=%v", rdsKey, err)
				ctx.AbortWithStatus(http.StatusForbidden)
				return
			}
			SetLoginUser(ctx, string(emailBytes))
		}
		ctx.Next()
	}
}
