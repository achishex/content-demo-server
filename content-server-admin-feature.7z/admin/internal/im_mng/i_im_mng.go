package im_mng

import (
	"content_svr/internal/data_cache"
	"content_svr/internal/im_mng/open_im_api"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/security_mng"
	"content_svr/protobuf/pbim"
	"context"
	"github.com/OpenIMSDK/protocol/group"
	cbapi "github.com/openimsdk/open-im-server/v3/pkg/callbackstruct"
)

type IIMMng interface {
	UserToken(ctx context.Context, req *pbim.IMTokenReq) (*pbim.IMTokenResp, error)
	CreateGroup(ctx context.Context, req *group.CreateGroupReq) (*group.CreateGroupResp, error)
	SetGroupInfo(ctx context.Context, req *SetGroupInfoReq) (*group.SetGroupInfoResp, error)
	InviteToGroup(ctx context.Context, req *group.InviteUserToGroupReq) (*group.InviteUserToGroupResp, error)
	JoinGroup(ctx context.Context, req *group.JoinGroupReq) (*group.JoinGroupResp, error)
	GroupApplicationResponse(ctx context.Context, req *group.GroupApplicationResponseReq) (*group.GroupApplicationResponseResp, error)
	KickGroup(ctx context.Context, req *group.KickGroupMemberReq) (*group.KickGroupMemberResp, error)
	GroupReport(ctx context.Context, req *pbim.GroupReportReq) (*pbim.GroupReportResp, error)
	DismissGroup(ctx context.Context, req *group.DismissGroupReq) (*group.DismissGroupResp, error)
	QuitGroup(ctx context.Context, req *group.QuitGroupReq) (*group.QuitGroupResp, error)
	TransferGroup(ctx context.Context, req *group.TransferGroupOwnerReq) (*group.TransferGroupOwnerResp, error)
	SetGroupMemberInfo(ctx context.Context, req *group.SetGroupMemberInfoReq) (*group.SetGroupMemberInfoResp, error)
	GroupMixInfo(ctx context.Context, req *pbim.GroupMixInfoReq) (*pbim.GroupMixInfoResp, error)
	GroupBatchInfo(ctx context.Context, req *pbim.BatchGroupIsJoinedReq) (*pbim.BatchGroupIsJoinedResp, error)
	GroupMemberExtInfo(ctx context.Context, req *pbim.GroupMemberExtInfoReq) (*pbim.GroupMemberExtInfoResp, error)

	//callback
	SyncUserInfo(ctx context.Context, req *pbim.SyncUserInfoReq) (*pbim.SyncUserInfoResp, error)
	Callback(ctx context.Context, command string, body []byte) cbapi.CallbackResp
}

type IMMng struct {
	DataCache    data_cache.IDataCacheMng
	SecurityMng  security_mng.ISecurityMng
	OpenImCaller open_im_api.IOpenIMCaller
	KafkaProxy   kafka_proxy.IKafkaProxy
	Helper       *IMHelper
	rewardComp   *IMRewardComp
}

func NewIMMng(dataCache data_cache.IDataCacheMng,
	security security_mng.ISecurityMng,
	imCaller open_im_api.IOpenIMCaller,
	kafkaProxy kafka_proxy.IKafkaProxy,
	rewardComp *IMRewardComp,
	helper *IMHelper) IIMMng {
	return &IMMng{
		DataCache:    dataCache,
		SecurityMng:  security,
		OpenImCaller: imCaller,
		KafkaProxy:   kafkaProxy,
		Helper:       helper,
		rewardComp:   rewardComp,
	}
}
