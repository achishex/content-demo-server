package data_cache

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
)

// 直接查db，不走缓存
func (p *DataCacheMng) GetUserWorkLikeMgDB(ctx context.Context, userId int64, workIds []int64) map[int64]*pbapi.SecretWorksLikeRecordMgDbModel {
	//从mg db取. 所有userFollow信息
	mgItem, err := p.SecretWorksLikeRecordMgDbModel.GetById(ctx, userId, workIds)
	if err != nil {
		logger.Errorf(ctx, "get GetUserWorkLikeMgDB failed. userId=%v, err=%v", userId, err.Error())
		return mgItem
	}
	return mgItem
}
