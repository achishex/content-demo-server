package user_center_mng

import (
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"context"
	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
)

// AddBlackList 拉黑/取消拉黑
func (u *UserCenterMng) AddBlackList(ctx context.Context, req *pbuserapi.AddBlackListReq) (*pbuserapi.AddBlackListResp, error) {
	var (
		curUserId    = middleware.GetUserID(ctx.(*gin.Context))
		targetUserId = req.GetTargetUserId()
		resp         = &pbuserapi.AddBlackListResp{}
		err          error

		blDoc = u.DataCache.GetImpl().UserBlackListMgModel
	)

	isBlack, err := blDoc.CheckInBlackList(ctx, curUserId, targetUserId)
	if err != nil {
		return nil, err
	}

	if false == isBlack {
		//拉黑
		_, err = blDoc.AddToBlackList(ctx, curUserId, targetUserId)
		if err != nil {
			return nil, err
		}

		//互相取关
		var (
			meFollowTarget *pbapi.SecretUserFollowMgDbModel
			targetFollowMe *pbapi.SecretUserFollowMgDbModel
			followDoc      = u.DataCache.GetImpl().SecretUserFollowMgModel
		)

		if meFollowTarget, err = followDoc.GetByUserId(ctx, curUserId, targetUserId); err != nil {
			return nil, err
		}

		//我关注对方
		if meFollowTarget != nil {
			if err := followDoc.DelFollow(ctx, bson.D{{"_id", meFollowTarget.Id}}); err != nil {
				return nil, err
			}

			//我的被关注数-1 & 猫王勋章
			if err := u.updateFollowCnt(ctx, curUserId, -1); err != nil {
				return nil, err
			}
		}

		//对方关注我
		if targetFollowMe, err = followDoc.GetByUserId(ctx, targetUserId, curUserId); err != nil {
			return nil, err
		}

		if targetFollowMe != nil {
			if err := followDoc.DelFollow(ctx, bson.D{{"_id", targetFollowMe.Id}}); err != nil {
				return nil, err
			}

			//对方被关注数-1 & 猫王勋章
			if err := u.updateFollowCnt(ctx, targetUserId, -1); err != nil {
				return nil, err
			}
		}

		//互关
		if meFollowTarget != nil && targetFollowMe != nil {
			//互关次数 & 社牛勋章处理
			meMutualCnt, targetMutualCnt := u.getBothMutualCnt(ctx, curUserId, targetUserId)
			meMutualCnt -= 1
			targetMutualCnt -= 1
			if err := u.checkMedia(ctx, curUserId, meMutualCnt); err != nil {
				return nil, err
			}
			if err := u.checkMedia(ctx, targetUserId, targetMutualCnt); err != nil {
				return nil, err
			}
		}

		//清除双方红点
		if err := u.DataCache.GetImpl().SecretUserFollowBadgeListMgDbModel.DeleteMany(ctx,
			bson.M{"$or": []bson.M{
				{"userId": curUserId, "targetUserId": targetUserId},
				{"userId": targetUserId, "targetUserId": curUserId}},
			}); err != nil {
			return nil, err
		}

		//清理备注
		if err := u.DataCache.DelUserRemarkOne(ctx, curUserId, targetUserId); err != nil {
			logger.Error(ctx, "add black list by remark name error: ", err)
		}
	}

	return resp, nil
}
