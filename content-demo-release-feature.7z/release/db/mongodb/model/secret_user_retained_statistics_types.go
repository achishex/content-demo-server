package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type SecretUserRetainedStatistics struct {
	ID primitive.ObjectID `bson:"_id" json:"id"`

	Day        int    `json:"day" bson:"day"`                 // 日期
	RetainType int    `json:"retain_type" bson:"retain_type"` // 天数
	Channel    string `json:"channel" bson:"channel"`         // 渠道 (maozhua, huawei, honor, xiaomi, oppo, vivo, yyb)
	AppType    string `json:"app_type" bson:"app_type"`       // 平台  Android iOS
	Gender     int    `json:"gender" bson:"gender"`           // 性别 1 男 2 女
	Market     int    `json:"market" bson:"market,omitempty"` //  1 推广带来的用户

	NewRetainCount          int `json:"new_retain_count" bson:"new_retain_count"`                     // 新用户数量
	ActiveRetainCount       int `json:"active_retain_count" bson:"active_retain_count"`               // 活跃用户数
	NewTargetRetainCount    int `json:"new_target_retain_count" bson:"new_target_retain_count"`       // 有行为的新用户数量
	ActiveTargetRetainCount int `json:"active_target_retain_count" bson:"active_target_retain_count"` // 有行为的活跃用户数

	CreateTime int64 `json:"-" bson:"create_time"`
}
