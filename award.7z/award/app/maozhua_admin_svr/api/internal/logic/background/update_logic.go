package background

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mongodb/model"
	"context"
	"github.com/jinzhu/copier"
	"reflect"
	"sort"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdateLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewUpdateLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateLogic {
	return &UpdateLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *UpdateLogic) Update(req *types.BackgroundUpdateReq) (resp *types.BackgroundUpdateResp, err error) {
	bImage := &model.BackgroundImage{}
	if err := copier.Copy(bImage, req); err != nil {
		return nil, err
	}

	if err = bImage.ID.UnmarshalText([]byte(req.ID)); err != nil {
		return nil, err
	}

	now := time.Now().UnixMilli()
	if now >= bImage.TimePartEnd {
		bImage.Status = false
	}

	// 判断是否需要检测生效时间的范围重叠
	var checkFlag = true
	bg, err := l.svcCtx.ManagerDB.BackgroundImage.FindById(l.ctx, req.ID)
	if err != nil {
		return nil, err
	}
	sort.Slice(req.Operate, func(i, j int) bool {
		return req.Operate[i] < req.Operate[j]
	})
	if bg.TimePartStart == req.TimePartStart && bg.TimePartEnd == req.TimePartEnd && reflect.DeepEqual(req.Operate, bg.Operate) {
		checkFlag = false
	}

	err = l.svcCtx.ManagerDB.BackgroundImage.Update(l.ctx, bImage, checkFlag)
	switch err {
	case xerr.DbDoNothing:
		logx.Info("本次操作没有修改任何类型， ID", req.ID)
		return resp, nil
	default:
		return
	}
}
