package digc

import (
	"content_svr/app/di"
)

var Container = di.NewContainer()
