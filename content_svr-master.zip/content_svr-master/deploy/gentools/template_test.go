package main

type testTemplate struct {
}
