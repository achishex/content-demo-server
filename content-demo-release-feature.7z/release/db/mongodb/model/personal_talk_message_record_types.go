package model

type PersonalTalkMessageRecord struct {
	ID int64 `bson:"_id" json:"_id"`

	ModeType   int32  `json:"modeType,omitempty" bson:"modeType,omitempty"`     // 0：人与人之间的普通聊天消息；1：微日记消息；2：解忧漂流瓶消息 12：引用 13: 引用作品 1401：运动-人与人之间的普通聊天消息
	FromUserId int64  `json:"fromUserId,omitempty" bson:"fromUserId,omitempty"` // 当前登陆用户，发送信息方
	ToUserId   int64  `json:"toUserId,omitempty" bson:"toUserId,omitempty"`     // 接受信息方
	Content    string `json:"content,omitempty" bson:"content,omitempty"`       // 内容
	CreateTime int64  `json:"createTime,omitempty" bson:"createTime,omitempty"` // 毫秒级别时间戳。 eg: 1682580246655
	Status     int32  `json:"status,omitempty" bson:"status,omitempty"`         // 删除状态 0 被删除 1 正常
	WorkFlag   int32  `json:"workFlag,omitempty" bson:"workFlag,omitempty"`     // 是否是作品内容产生的消息，0：否；1：主作品 2: 附属作品

	MessageType int32 `json:"messageType,omitempty" bson:"messageType,omitempty"` // 消息类型，1 文字；2：图片 4:默认 9: 互爪通知消息，10: @work消息通知， 11： @comment消息通知， 99表情 6:猫友勋章 8:拉黑提示,
	Width       int32 `json:"width,omitempty" bson:"width,omitempty"`             // 图片消息时候图片的宽度
	High        int32 `json:"high,omitempty" bson:"high,omitempty"`               // 图片消息时图片的高度
	// @inject_tag: bson:"duration,omitempty"
	//Duration int32 `protobuf:"varint,16,opt,name=duration,proto3,oneof" json:"duration,omitempty" bson:"duration,omitempty"` // 语音消息的长度
	//// @inject_tag: bson:"objectId,omitempty"
	ObjectId string `json:"objectId,omitempty" bson:"objectId,omitempty"` // 图片消息时图片存储在OSS的标识
	//// @inject_tag: bson:"uniqueId,omitempty"
	UniqueId int32 `json:"uniqueId,omitempty" bson:"uniqueId,omitempty"` // 发送人、接收人、作品、模块构成的唯一标识
	// @inject_tag: bson:"clientId,omitempty"
	//ClientId string `protobuf:"bytes,19,opt,name=clientId,proto3,oneof" json:"clientId,omitempty" bson:"clientId,omitempty"`
	//// @inject_tag: bson:"recallMsgId,omitempty"
	//RecallMsgId int64 `protobuf:"varint,20,opt,name=recallMsgId,proto3,oneof" json:"recallMsgId,omitempty" bson:"recallMsgId,omitempty"` // 被撤回的消息ID
	//// @inject_tag: bson:"memeId,omitempty"
	//MemeId int64 `protobuf:"varint,21,opt,name=memeId,proto3,oneof" json:"memeId,omitempty" bson:"memeId,omitempty"`
	//// @inject_tag: bson:"quoteMsgId,omitempty"
	//QuoteMsgId int64 `protobuf:"varint,22,opt,name=quoteMsgId,proto3,oneof" json:"quoteMsgId,omitempty" bson:"quoteMsgId,omitempty"` // 引用的消息
	//// @inject_tag: bson:"province,omitempty"
	//Province string `protobuf:"bytes,23,opt,name=province,proto3,oneof" json:"province,omitempty" bson:"province,omitempty"`
	//// @inject_tag: bson:"city,omitempty"
	//City string `protobuf:"bytes,24,opt,name=city,proto3,oneof" json:"city,omitempty" bson:"city,omitempty"`
	//// @inject_tag: bson:"ip,omitempty"
	//Ip string `protobuf:"bytes,25,opt,name=ip,proto3,oneof" json:"ip,omitempty" bson:"ip,omitempty"`
	//// @inject_tag: bson:"longitude,omitempty"
	//Longitude float64 `protobuf:"fixed64,26,opt,name=longitude,proto3,oneof" json:"longitude,omitempty" bson:"longitude,omitempty"` // 经度
	//// @inject_tag: bson:"latitude,omitempty"
	//Latitude float64 `protobuf:"fixed64,27,opt,name=latitude,proto3,oneof" json:"latitude,omitempty" bson:"latitude,omitempty"` // 纬度
	//// @inject_tag: bson:"chitchat,omitempty"
	//Chitchat int32 `protobuf:"varint,28,opt,name=chitchat,proto3,oneof" json:"chitchat,omitempty" bson:"chitchat,omitempty"` // 来自唠唠
	//// @inject_tag: bson:"messageWorkId,omitempty"
	//MessageWorkId int64 `protobuf:"varint,29,opt,name=messageWorkId,proto3,oneof" json:"messageWorkId,omitempty" bson:"messageWorkId,omitempty"` //用户存储互爪通知，@work, @comment消息通知
}
