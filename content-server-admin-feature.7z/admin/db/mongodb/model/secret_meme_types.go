package model

const collectionNameSecretMeme = "secretMeme"

type SecretMeme struct {
	ID       int64  `json:"id,omitempty" bson:"_id,omitempty"`
	ObjectId string `json:"objectId,omitempty" bson:"objectId,omitempty"`
	OwnerId  int64  `json:"ownerId,omitempty" bson:"ownerId,omitempty"`
	Width    int32  `json:"width,omitempty" bson:"width,omitempty"`
	High     int32  `json:"high,omitempty" bson:"high,omitempty"`
}
