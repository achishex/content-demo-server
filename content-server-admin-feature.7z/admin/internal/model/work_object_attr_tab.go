package model

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"context"
	"gorm.io/gorm"
)

type IWorkObjectAttrDbModel interface {
	CreateItem(ctx context.Context, model *pbapi.WorkObjectAttrDbModel) (*pbapi.WorkObjectAttrDbModel, error)
	ListItemsByCondition(ctx context.Context, condition map[string]interface{},
		page uint64, size uint64) ([]*pbapi.WorkObjectAttrDbModel, error)
	DictByWorkIds(ctx context.Context,
		workIds []int64) (map[int64][]*pbapi.WorkObjectAttrDbModel, error)
}

type WorkObjectAttrDbModelImpl struct {
	DB *gorm.DB
}

func NewWorkObjectAttrDbModelImpl(db *gorm.DB) IWorkObjectAttrDbModel {
	return &WorkObjectAttrDbModelImpl{DB: db}
}
func (impl *WorkObjectAttrDbModelImpl) table() string {
	return "work_object_attr"
}

func (impl *WorkObjectAttrDbModelImpl) CreateItem(ctx context.Context, model *pbapi.WorkObjectAttrDbModel) (*pbapi.WorkObjectAttrDbModel, error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Create(model)
	return model, errors.Wrap(result.Error)
}

func (impl *WorkObjectAttrDbModelImpl) ListItemsByCondition(ctx context.Context,
	condition map[string]interface{}, page uint64, size uint64) ([]*pbapi.WorkObjectAttrDbModel, error) {
	offset := (page - 1) * size
	var items []*pbapi.WorkObjectAttrDbModel
	result := impl.DB.WithContext(ctx).Table("work_object_attr").
		Limit(int(size)).Offset(int(offset)).Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *WorkObjectAttrDbModelImpl) DictByWorkIds(ctx context.Context,
	workIds []int64) (map[int64][]*pbapi.WorkObjectAttrDbModel, error) {
	resp := make(map[int64][]*pbapi.WorkObjectAttrDbModel)
	if len(workIds) == 0 {
		return resp, nil
	}

	cond := map[string]interface{}{
		"work_id": workIds,
	}
	items, err := impl.ListItemsByCondition(ctx, cond, 1, cm_const.MaxDbSize)
	if err != nil {
		return resp, err
	}

	for _, item := range items {
		attList := resp[item.GetWorkId()]
		if attList == nil {
			attList = make([]*pbapi.WorkObjectAttrDbModel, 0)
		}
		resp[item.GetWorkId()] = append(attList, item)
	}
	return resp, nil
}
