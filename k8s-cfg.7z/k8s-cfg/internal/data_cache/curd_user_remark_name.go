package data_cache

import (
	"content_svr/pub/logger"
	"context"
	"github.com/go-redis/redis/v8"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"strconv"
	"time"
)

// GetUserRemarkOne 获取该用户对某个用户的备注信息
func (p *DataCacheMng) GetUserRemarkOne(ctx context.Context, userId, toUserId int64) (remarkName string, err error) {
	if userId == 0 || toUserId == 0 {
		return "", nil
	}

	rdsKey := getRdsKeyRemarkName(userId)

	// 穿透到数据库
	penetration := func() (string, error) {
		filter := bson.D{
			{"userId", userId},
			{"targetUserId", toUserId},
		}
		follow, err := p.SecretUserFollowMgModel.FindOne(ctx, filter)
		switch err {
		case mongo.ErrNoDocuments:
			// 避免一直穿透到数据库
			_ = p.SetUserRemarkOne(ctx, userId, toUserId, "")
			return remarkName, nil
		case nil:
			remark := follow.GetRemarkName()
			_ = p.SetUserRemarkOne(ctx, userId, toUserId, remark)
			return remark, nil
		default:
			return remarkName, err
		}
	}

	_ = p.RedisCli.Expire(ctx, rdsKey, time.Hour*24*7).Err()
	remarkName, err = p.RedisCli.HGet(ctx, rdsKey, strconv.Itoa(int(toUserId))).Result()
	switch err {
	case redis.Nil:
		// 不存在该键
		remarkName, err = penetration()
	case nil:
		return remarkName, nil
	default:
		// 发生非空错误，穿透到数据库
		logger.Error(ctx, rdsKey, err)
		return penetration()
	}

	return remarkName, err
}

// SetUserRemarkOne 设置备注
func (p *DataCacheMng) SetUserRemarkOne(ctx context.Context, userId, toUserId int64, name string) error {
	rdsKey := getRdsKeyRemarkName(userId)

	err := p.RedisCli.HSet(ctx, rdsKey, toUserId, name).Err()
	if err != nil {
		return err
	}
	_ = p.RedisCli.Expire(ctx, rdsKey, time.Hour*24*7).Err()
	return nil
}

func (p *DataCacheMng) DelUserRemarkOne(ctx context.Context, userId, toUserId int64) error {
	rdsKeyUserId := getRdsKeyRemarkName(userId)
	if err := p.RedisCli.HDel(ctx, rdsKeyUserId, strconv.Itoa(int(toUserId))).Err(); err != nil {
		logger.Error(ctx, "DelUserRemarkOne: ", err)
	}

	rdsKeyToUserId := getRdsKeyRemarkName(toUserId)
	if err := p.RedisCli.HDel(ctx, rdsKeyToUserId, strconv.Itoa(int(userId))).Err(); err != nil {
		logger.Error(ctx, "DelUserRemarkOne: ", err)
	}

	return nil
}
