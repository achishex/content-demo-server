package retain

import (
	"content_svr/app/maozhua_admin_svr/api/internal/logic/dau"
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/db/mongodb/model"
	"context"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"math"
	"sort"
)

type ListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ListLogic {
	return &ListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ListLogic) List(req *types.RetainListReq) (resp *types.RetainListResp, err error) {
	retainList := make([]types.RetainTable, 0)
	filter, key := dau.GetUserActivityFilter(req.UserActivityFilter)

	channelList, err := l.svcCtx.ReadDB.SecretUserChannelDaily.FindAll(l.ctx, filter)
	if err != nil {
		return nil, err
	}
	targetChannelMap := map[string]model.SecretUserChannelDaily{}
	for _, channelDaily := range channelList {
		uniqueKey := fmt.Sprintf(key, channelDaily.Day)
		item, ok := targetChannelMap[uniqueKey]
		if ok {
			item.ActiveUserCount += channelDaily.ActiveUserCount
			item.ActiveTargetUserCount += channelDaily.ActiveTargetUserCount
			item.NewUserCount += channelDaily.NewUserCount
			item.NewTargetUserCount += channelDaily.NewTargetUserCount
		} else {
			item = channelDaily
		}

		targetChannelMap[uniqueKey] = item
	}

	targetChannel := make([]model.SecretUserChannelDaily, 0)
	for _, daily := range targetChannelMap {
		targetChannel = append(targetChannel, daily)
	}

	sort.Slice(targetChannel, func(i, j int) bool {
		return targetChannel[i].Day > targetChannel[j].Day
	})

	for _, channelDaily := range targetChannel {
		retain := types.RetainTable{
			Date: channelDaily.Day,
			//ActiveUserCount: item.ActiveUserCount,
		}

		filter = l.buildFilter(filter, "day", channelDaily.Day)
		filter = l.buildFilter(filter, "retain_type", map[string]interface{}{
			"$in": []int{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29},
		})

		statisticsList, err := l.svcCtx.ReadDB.SecretUserRetainedStatistics.FindAll(l.ctx, filter)
		if err != nil {
			return nil, err
		}

		targetRetainMap := map[string]model.SecretUserRetainedStatistics{}
		for _, retainedStatistics := range statisticsList {
			uniqueKey := fmt.Sprintf(key+"-%d", retainedStatistics.Day, retainedStatistics.RetainType)
			value, ok := targetRetainMap[uniqueKey]
			if ok {
				value.NewRetainCount += retainedStatistics.NewRetainCount
				value.ActiveRetainCount += retainedStatistics.ActiveRetainCount
				value.NewTargetRetainCount += retainedStatistics.NewTargetRetainCount
				value.ActiveTargetRetainCount += retainedStatistics.ActiveTargetRetainCount

			} else {
				value = retainedStatistics
			}

			targetRetainMap[uniqueKey] = value
		}

		targetRetain := make([]model.SecretUserRetainedStatistics, 0)
		for _, daily := range targetRetainMap {
			targetRetain = append(targetRetain, daily)
		}

		for _, statistics := range targetRetain {
			// 分子
			// 分母
			numerator, denominator := l.getNumeratorAndDenominator(req.ListType, statistics, channelDaily)
			retain.ActiveUserCount = denominator
			//logc.Errorf(l.ctx, "分子 %v, 分母 %v， 计算结果：%.4f", numerator, denominator, math.Round(float64(numerator)/float64(denominator)*1000)/1000)
			retain = l.buildRetainTable(retain, statistics.RetainType, numerator, denominator)
		}

		retainList = append(retainList, retain)
	}

	retainNew := types.RetainTable{
		Date: 20300101,
	}
	for i := 0; i < 30; i++ {
		retainNew = l.buildRetainNewTable(retainNew, i, retainList)
	}

	retainList = append(retainList, retainNew)
	resp = &types.RetainListResp{
		List: retainList,
	}

	return
}

func (l *ListLogic) buildFilter(filter map[string]interface{}, key string, value interface{}) map[string]interface{} {
	switch v := value.(type) {
	case int:
		if v == 0 {
			return filter
		}
		filter[key] = value
	case string:
		if v == "" {
			return filter
		}
		filter[key] = value
	default:
		filter[key] = value
	}

	return filter
}

// 获取分子，分母
func (l *ListLogic) getNumeratorAndDenominator(listType int, statistics model.SecretUserRetainedStatistics, item model.SecretUserChannelDaily) (numerator, denominator int) {
	switch listType {
	case 1:
		numerator = statistics.NewRetainCount
		denominator = item.NewUserCount
	case 2:
		numerator = statistics.NewTargetRetainCount
		denominator = item.NewUserCount
	case 3:
		numerator = statistics.ActiveRetainCount
		denominator = item.ActiveUserCount
	case 4:
		numerator = statistics.ActiveTargetRetainCount
		denominator = item.ActiveUserCount
	default:
		return 1, 1
	}

	//if numerator == 0 {
	//	numerator = denominator
	//}
	//
	//if denominator == 0 {
	//	numerator = 0
	//	denominator = 1
	//}

	return
}

func (l *ListLogic) buildRetainTable(retain types.RetainTable, retainType, numerator, denominator int) types.RetainTable {

	//fmt.Printf("日期%d 第%d天后 分子%d 分母%d\n", retain.Date, retainType, numerator, denominator)
	var calc float64
	if denominator == 0 {
		calc = 0
	} else {
		calc = math.Round(float64(numerator)/float64(denominator)*1000) / 1000
	}
	switch retainType {
	case 0:
		retain.DayLater0 = calc
	case 1:
		retain.DayLater1 = calc
	case 2:
		retain.DayLater2 = calc
	case 3:
		retain.DayLater3 = calc
	case 4:
		retain.DayLater4 = calc
	case 5:
		retain.DayLater5 = calc
	case 6:
		retain.DayLater6 = calc
	case 7:
		retain.DayLater7 = calc
	case 8:
		retain.DayLater8 = calc
	case 9:
		retain.DayLater9 = calc
	case 10:
		retain.DayLater10 = calc
	case 11:
		retain.DayLater11 = calc
	case 12:
		retain.DayLater12 = calc
	case 13:
		retain.DayLater13 = calc
	case 14:
		retain.DayLater14 = calc
	case 15:
		retain.DayLater15 = calc
	case 16:
		retain.DayLater16 = calc
	case 17:
		retain.DayLater17 = calc
	case 18:
		retain.DayLater18 = calc
	case 19:
		retain.DayLater19 = calc
	case 20:
		retain.DayLater20 = calc
	case 21:
		retain.DayLater21 = calc
	case 22:
		retain.DayLater22 = calc
	case 23:
		retain.DayLater23 = calc
	case 24:
		retain.DayLater24 = calc
	case 25:
		retain.DayLater25 = calc
	case 26:
		retain.DayLater26 = calc
	case 27:
		retain.DayLater27 = calc
	case 28:
		retain.DayLater28 = calc
	case 29:
		retain.DayLater29 = calc
	default:
		return retain
	}

	return retain
}

func (l *ListLogic) buildRetainNewTable(retain types.RetainTable, retainType int, retainList []types.RetainTable) types.RetainTable {

	switch retainType {
	case 0:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater0 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater0 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 1:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater1 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater1 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 2:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater2 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater2 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 3:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater3 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater3 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 4:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater4 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater4 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 5:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater5 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater5 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 6:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater6 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater6 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 7:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater7 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater7 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 8:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater8 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater8 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 9:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater9 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater9 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 10:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater10 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater10 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 11:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater11 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater11 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 12:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater12 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater12 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 13:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater13 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater13 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 14:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater14 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater14 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 15:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater15 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater15 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 16:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater16 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater16 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 17:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater17 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater17 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 18:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater18 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater18 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 19:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater19 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater19 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 20:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater20 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater20 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 21:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater21 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater21 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 22:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater22 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater22 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 23:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater23 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater23 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 24:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater24 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater24 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 25:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater25 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater25 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 26:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater26 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater26 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 27:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater27 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater27 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 28:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater28 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater28 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 29:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater29 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater29 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	case 30:
		{
			var result float64
			var count int
			for _, item := range retainList {
				result += item.DayLater30 * float64(item.ActiveUserCount)
				count += item.ActiveUserCount
			}

			retain.DayLater30 = safeDiv(result, count)
			retain.ActiveUserCount = count
		}
		break
	default:
		return retain
	}

	return retain
}
