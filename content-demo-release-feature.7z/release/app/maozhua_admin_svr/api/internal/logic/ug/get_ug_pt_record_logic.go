package ug

import (
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type GetUgPtRecordLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewGetUgPtRecordLogic(ctx context.Context, svcCtx *svc.ServiceContext) *GetUgPtRecordLogic {
	return &GetUgPtRecordLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *GetUgPtRecordLogic) GetUgPtRecord(req *types.GetUgPtRecordReq) (resp *types.GetUgPtRecordResp, err error) {
	// todo: add your logic here and delete this line

	return
}
