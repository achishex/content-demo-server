package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type SecretMedalInfo struct {
	model.SecretMedalInfoModel
	redisManage *query_rds.Manage
}

func NewCacheSecretMedalInfo(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *SecretMedalInfo {
	return &SecretMedalInfo{
		SecretMedalInfoModel: mongo.SecretMedalInfo,
		redisManage:          redisManage,
	}
}
