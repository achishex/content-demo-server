package job

import (
	"content_svr/db/dao"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"time"
)

type robotRetainControl struct {
	TickerExecute
	//robotControl

	write, read *dao.ManagerDB
}

func InitRetainRobot(write, read *dao.ManagerDB) {
	robotRetainControl := robotRetainControl{}
	//robotRetainControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/c02670dc-de16-4af0-a234-d90af25c6f13" // server群，测试用
	//robotRetainControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/afd15198-34ea-4788-a306-2e94630458de" // 正式群，不要乱推数据
	//robotRetainControl.msgChan = make(chan Message, 10)

	//robotRetainControl.today = true
	robotRetainControl.hour = 8
	robotRetainControl.minter = 5
	robotRetainControl.write = write
	robotRetainControl.read = read

	//go robotRetainControl.monitor()
	go func() {
		robotRetainControl.Do(func() {
			ctx := requestid.WithRequestID(context.Background())
			if err := robotRetainControl.DoTask(ctx, time.Now().AddDate(0, 0, -1)); err != nil {
				logger.Errorf(ctx, "robotRetainControl.DoTask: %v", err)
				// 五分钟后重试
				robotRetainControl.ticker.Reset(time.Minute * 5)
				return
			}

			robotRetainControl.ticker.Reset(robotRetainControl.calcIntervalTime())
		})
	}()
}

func (r robotRetainControl) DoTask(ctx context.Context, targetTime time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	//

	//dayStr := fmt.Sprintf("%04d%02d%02d", targetTime.Year(), targetTime.Month(), targetTime.Day())
	//day, _ := strconv.Atoi(dayStr)
	day, _ := utils.TimeByDay(targetTime)
	filter := map[string]interface{}{
		"day": day,
	}

	// SecretUserChannelDaily
	channelList, err := r.read.SecretUserChannelDaily.FindAll(ctx, filter)
	if err != nil {
		return err
	}

	activeUserCount := 0
	activeTargetUserCount := 0
	newUserCount := 0
	newTargetUserCount := 0
	for _, item := range channelList {
		activeUserCount += item.ActiveUserCount
		activeTargetUserCount += item.ActiveTargetUserCount
		newUserCount += item.NewUserCount
		newTargetUserCount += item.NewTargetUserCount

	}

	//member, err := r.read.UserMemberStatistical.FindOne(ctx, filter)
	//if err != nil {
	//	return err
	//}

	newUserCountMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("新增活跃用户留存: %d\n", newUserCount),
	}
	newTargetUserCountMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("新增目标用户留存: %d\n", newTargetUserCount),
	}
	activeUserCountMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("老活跃用户留存: %d\n", activeUserCount),
	}
	activeTargetUserCountMessage := item{
		Tag:  "text",
		Text: fmt.Sprintf("老目标用户留存: %.d\n", activeTargetUserCount),
	}
	//WechatPayWithdrawFailSumMessage := item{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天微信提现失败总和: %.2f\n", float64(data.WechatPayWithdrawFailSum)/100),
	//}
	//HallOfFameAwardSettlementSumMessage := item{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天排行榜奖励总和: %.2f\n", float64(data.HallOfFameAwardSettlementSum)/100),
	//}
	//MemberSumMessage := item{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天充值总和: %.2f\n", float64(member.PriceSum)/100),
	//}
	items := []item{
		newUserCountMessage,
		newTargetUserCountMessage,
		activeUserCountMessage,
		activeTargetUserCountMessage,
	}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = fmt.Sprintf("%d DAU统计", r.baseTimeByDay(targetTime))
	m.Content.Post.ZhCn.Content = make([][]item, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	RobotBossControl.SendMessage(m)

	// 统计完成后当天早上8点再发通知
	//now := time.Now()
	//target := time.Date(now.Year(), now.Month(), now.Day(), 8, 0, 0, 0, now.Location())
	//r.SendMessageAfterTime(m, target.Sub(now))

	return nil
}
