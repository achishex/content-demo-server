package version

import (
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"github.com/gin-gonic/gin"
	"time"
)

const (
	WorkPictureVersion = "1070000" // 动态允许发图片,系统卡片对应支持的版本

	CommentEmotionVersion       = "2020001" // 评论允许发表情版本
	SuperiorContentAwardVersion = "2060001" // 优质内容版本
	TalkADVersion               = "2130001" // 聊天广告
	GameCardVersion             = "2140000" //游戏卡片
	AdSignVersion               = "2150000" //广告签到版本
	WalletMsgVersion            = "2160000" //钱包消息版本
	PartnerVersion              = "2170000" //合伙人版本
)

// 新钱包消息版本
func IsWalletMsgVersion(ctx context.Context) bool {
	header, err := utils.GetCtxHeadersSession(ctx.(*gin.Context))
	if err != nil {
		logger.Errorf(ctx, "get context header err: %v", err)
		return false
	}
	logger.Infof(ctx, "header.code: %v", header.Versioncode)
	if header.Versioncode < WalletMsgVersion {
		return false
	}
	return true
}

func GetSuperiorContentVersionTime() int64 {
	return 1698768000000
}

func IsSuperiorContentVersionUser(ctx context.Context, ct string) bool {
	createTime, err := time.Parse("2006-01-02 15:04:05", ct)
	if err != nil {
		logger.Error(ctx, "time.Parse", err)
		return false
	}
	now := time.UnixMilli(GetSuperiorContentVersionTime())

	return createTime.After(now)
}
