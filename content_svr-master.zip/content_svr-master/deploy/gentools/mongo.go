package main

import (
	"bytes"
	"fmt"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)

type MongoInfo struct {
}

func (m *MongoInfo) Check() {
	if err := exec.Command("goctl", "--help").Run(); err != nil {
		log.Fatal(err)
	}
}

func (m *MongoInfo) GenerateModel() {
	if mongoTableNames == "" {
		log.Println("mongoTableNames is empty")
		return
	}

	tableNames := strings.Split(mongoTableNames, ",")

	modelPackPath := getPath(filepath.Join(mongoDbDir, "model"))
	tPath := getPath(filepath.Join(templateDir))
	for _, name := range tableNames {
		name = ChangeToDoubleHump(name)
		args := []string{
			"model",
			"mongo",
			"--type",
			name,
			"--dir",
			modelPackPath,
			"--style",
			"go_zero",
		}

		if tPath != "" {
			args = append(args, "--home")
			args = append(args, tPath)
		}

		fmt.Println(append([]string{"goctl"}, args...))
		if err := exec.Command("goctl", args...).Run(); err != nil {
			fmt.Println(name, err)
		}
	}

	m.GenerateManage()
	m.GenerateConfig()
}

func (m *MongoInfo) GenerateManage() {
	if mongoTableNames == "" {
		log.Println("mongoTableNames is empty")
		return
	}

	headTemplate := TemplateObject{
		ModelPackPath: fmtString(filepath.Join(packName, mongoDbDir, "model")),
	}

	tableNames := strings.Split(mongoTableNames, ",")
	bodyTemplate := make([]TemplateObject, 0)
	for _, name := range tableNames {
		name = ChangeToDoubleHump(name)
		bodyTemplate = append(bodyTemplate, TemplateObject{
			Type: name,
		})
	}

	wPath := getPath(filepath.Join(mongoDbDir, mongoManageGoPath))
	tg := templateGroup{
		targets:   make([]target, 0),
		body:      bytes.NewBuffer(nil),
		writePath: wPath,
	}

	if _, err := os.Stat(wPath); err != nil {
		if err := os.MkdirAll(filepath.Dir(wPath), os.ModeDir); err != nil {
			log.Fatal(err)
		}
	}

	for i := 0; i < len(mongoManageTemplatePath); i++ {
		tPath := getPath(filepath.Join(templateDir, mongoManageTemplatePath[i]))
		if _, err := os.Stat(tPath); err != nil {
			log.Fatal(err)
		}
		mongoManageTemplatePath[i] = tPath
	}

	tg.targets = append(tg.targets,
		target{
			srcTemplatePath: mongoManageTemplatePath[0],
			data:            headTemplate,
		},
		target{
			srcTemplatePath: mongoManageTemplatePath[1],
			data:            bodyTemplate,
		},
	)

	if err := tg.parse(); err != nil {
		log.Fatal(err)
	}
	FmtFile(wPath)

}

func (m *MongoInfo) GenerateConfig() {
	tPath := getPath(filepath.Join(templateDir, mongoConfigTemplatePath))
	wPath := getPath(filepath.Join(mongoDbDir, mongoConfigGoPath))
	if _, err := os.Stat(wPath); err == nil {
		return
	}
	tg := templateGroup{
		targets:   make([]target, 0),
		body:      bytes.NewBuffer(nil),
		writePath: wPath,
	}

	tg.targets = append(tg.targets, target{
		srcTemplatePath: tPath,
	})

	if err := tg.parse(); err != nil {
		log.Fatal(err)
	}
	FmtFile(wPath)
}
