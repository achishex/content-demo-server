package kafka_proxy

import (
	"content_svr/config"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbkfk"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"encoding/json"
	"fmt"
	"github.com/Shopify/sarama"
	"github.com/gogo/protobuf/proto"
	"strings"
	"time"
)

// sendToSander
func (p *KafkaProxyImpl) SendPersonalBottleWorksEs(ctx context.Context, work *pbapi.PersonalBottleWorksDbModel, mType int32) error {
	//topic := getTopic(topicPersonalBottleWorksEs)
	topic := "prod_" + topicPersonalBottleWorksEs
	if strings.ToLower(config.ServerConfig.Env) != "prod" {
		topic = "test_" + topicPersonalBottleWorksEs
	}

	kfkData := &pbkfk.PersonalBottleWorksDto{
		Id:           work.Id,
		UserId:       work.UserId,
		Title:        work.Title,
		Type:         proto.Int32(mType), //1-创建或者更新，2-删除
		VerifyStatus: work.VerifyStatus,
		WorksType:    work.WorksType,
		AppType:      work.AppType,
	}

	if mType == 1 {
		curTimeMs := utils.GetCurTsMs()
		kfkData.CreateTime = &curTimeMs
		if work.GetCreateTime() != "" {
			pTime, err := utils.ParseWithLocal(work.GetCreateTime())
			if err == nil {
				kfkData.CreateTime = proto.Int64(pTime.UnixNano() / 1e6)
			}
		}

		kfkData.SystemTime = &curTimeMs
		if work.GetSystemTime() != "" {
			pTime, err := utils.ParseWithLocal(work.GetSystemTime())
			if err == nil {
				kfkData.SystemTime = proto.Int64(pTime.UnixNano() / 1e6)
			}
		}

		kfkData.StartTime = &curTimeMs
		if work.GetStartTime() != "" {
			pTime, err := utils.ParseWithLocal(work.GetStartTime())
			if err == nil {
				kfkData.StartTime = proto.Int64(pTime.UnixNano() / 1e6)
			}
		}

		timeAfter1 := time.Now().Add(time.Second*time.Duration(1*86400)).UnixNano() / 1e6
		kfkData.EndTime = &timeAfter1
		if work.GetEndTime() != "" {
			pTime, err := utils.ParseWithLocal(work.GetEndTime())
			if err == nil {
				kfkData.EndTime = proto.Int64(pTime.UnixNano() / 1e6)
			}
		}

	}

	dataBytes, _ := json.Marshal(kfkData)
	msg := &sarama.ProducerMessage{
		Topic: topic,
		//Partition: int32(-1),		// 删除掉
		Key:   sarama.StringEncoder(fmt.Sprintf("%v", work.GetId())),
		Value: sarama.ByteEncoder(dataBytes),
	}
	paritition, offset, err := p.Producer.SendMessage(msg)
	//_, _, err := p.Producer.SendMessage(msg)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SendPersonalBottleWorksEs kafka sendmessage failed. topic=%v", topic), err)
		return err
	}
	logger.Infof(ctx, "SendPersonalBottleWorksEs kafka send message suc. topic=%v, body=%v, paritition=%v, offset=%v",
		topic, string(dataBytes), paritition, offset)
	return nil
}
