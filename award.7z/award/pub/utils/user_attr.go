package utils

import (
	"content_svr/pub/errors"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"net/url"
	"strings"
)

// EncryptPhones 加密手机号
func EncryptPhones(phone string) (string, error) {
	cryptText, err := AESEncrypt([]byte(phone), AesUserKey)
	if err != nil {
		return "", errors.New(fmt.Sprintf("AESEncrypt: %v", err))
	}

	return cryptText, err
}

// DecryptPhones 解密手机号
func DecryptPhones(crypt string) (string, error) {
	plainText, err := AESDecrypt(crypt, AesUserKey)
	if err != nil {
		return "", errors.New(fmt.Sprintf("plainText: %v", err))
	}

	return string(plainText), err
}

// FixImageUrl 修正图片链接
func FixImageUrl(host, photo string) string {
	if photo == "" {
		return photo
	}

	if !strings.HasPrefix(photo, "http") {
		parsePhotoUrl, err := url.JoinPath(host, photo)
		if err != nil {
			logx.Error(err)
		}
		return parsePhotoUrl
	} else {
		return photo
	}
}
