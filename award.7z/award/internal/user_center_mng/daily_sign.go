package user_center_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/snow_flake"
	"content_svr/setting"
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
	rdsV8 "github.com/go-redis/redis/v8"
	"github.com/golang/protobuf/proto"
	"github.com/jinzhu/copier"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"sort"
	"time"
)

func (u *UserCenterMng) ResetPenalties(ctx context.Context) {
	userId := middleware.GetUserID(ctx.(*gin.Context))
	if userId > 0 {
		if err := u.DataCache.GetImpl().UserInfoExtMgModel.UpdateDictById(ctx, userId, map[string]any{"penalties": 0}, nil); err != nil {
			logger.Errorf(ctx, "ResetPenalties error : %v ", err)
		}
	}
}

func (u *UserCenterMng) DailySign(ctx context.Context, req *pbuserapi.DailySignReq) (*pbuserapi.LevelUpResp, error) {
	var (
		userId = middleware.GetUserID(ctx.(*gin.Context))
	)

	//签到状态
	signed := u.DataCache.GetImpl().GetUserDailySign(ctx, userId)
	if signed {
		return nil, errorcode.DailySignInAgain
	}

	//设置签到
	if err := u.DataCache.GetImpl().SetUserDailySign(ctx, userId); err != nil {
		return nil, errorcode.DailySignInError
	}

	//更新签到/升级
	resp, err := u.checkLevUpAndUpdate(ctx, userId, 1)
	if err != nil {
		return nil, errorcode.DailySignInError
	}

	return resp, nil
}

func (u *UserCenterMng) LevelInfo(ctx context.Context, req *pbuserapi.LevelCardReq) (*pbuserapi.CurrentLevelInfo, error) {
	userId := middleware.GetUserID(ctx.(*gin.Context))

	userExt, err := u.DataCache.GetImpl().UserInfoExtMgModel.GetAndCreate(ctx, userId)
	if err != nil || userExt == nil {
		logger.Errorf(ctx, "get user ext info failed,err=%v", err.Error())
		return nil, errorcode.DailySignInError
	}

	resp, err := u.checkLevUpAndUpdate(ctx, userId, 0)
	if err != nil {
		return nil, errorcode.DailySignInError
	}

	resp.LevelInfo.SpeedCodeLimitDesc = fmt.Sprintf("1枚加速码可兑换%d天签到哦，可找其他猫友赠送～\n*如有违规记录，则1枚加速码仅可兑换%d天签到哦",
		setting.Maozhua.SpeedCodeExchangeSignTimesForNormal.Get(), setting.Maozhua.SpeedCodeExchangeSignTimesForPenalties.Get())
	return resp.LevelInfo, nil
}

func (u *UserCenterMng) GetSpeedCode(ctx context.Context, req *pbuserapi.GetSpeedCodeReq) (*pbuserapi.GetSpeedCodeResp, error) {
	var (
		userId = middleware.GetUserID(ctx.(*gin.Context))

		resp          = &pbuserapi.GetSpeedCodeResp{}
		dailySignColl = u.DataCache.GetImpl().SecretDailySignInMgModel
		speedCodeColl = u.DataCache.GetImpl().SecretSpeedCodeMgModel
	)

	blackHouseOutTime, err := u.DataCache.GetImpl().GetUserBlackHouseOutTime(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "user in black house,err=%v", err.Error())
		return nil, errorcode.SpeedCodeGetErrorCauseBlackHouse
	}
	if time.Now().UnixNano()/1e6 < blackHouseOutTime {
		return nil, err
	}

	sign, err := dailySignColl.FindOne(ctx, bson.M{"user_id": userId})
	if err != nil {
		logger.Errorf(ctx, "get user daily sign failed,err=%v", err.Error())
		return nil, err
	}

	if sign.SpeedCode != "" {
		resp.SpeedCode = sign.SpeedCode
		return resp, nil
	}

	if sign.SpeedCodeStatus == const_busi.SpeedCodeStatusNo {
		return nil, errorcode.SpeedCodeGetErrorCauseNo
	}

	if sign.SpeedCodeStatus == const_busi.SpeedCodeStatusYes && sign.SpeedCode == "" {
		//生成
		resp.SpeedCode, err = speedCodeColl.Create(ctx, userId)
		if err != nil {
			return resp, nil
		}

		updates := map[string]any{
			"speed_code_status": const_busi.SpeedCodeStatusDraw,
			"speed_code":        resp.SpeedCode,
			"update_time":       time.Now().UnixMilli(),
		}
		if err := dailySignColl.UpdateOne(ctx, bson.M{"user_id": userId}, updates); err != nil {
			return nil, err
		}
	}

	return resp, nil
}

func (u *UserCenterMng) UsageSpeedCode(ctx context.Context, req *pbuserapi.UsageSpeedCodeReq) (*pbuserapi.LevelUpResp, error) {
	var (
		userId        = middleware.GetUserID(ctx.(*gin.Context))
		userExtColl   = u.DataCache.GetImpl().UserInfoExtMgModel
		dailySignColl = u.DataCache.GetImpl().SecretDailySignInMgModel
		speedCodeColl = u.DataCache.GetImpl().SecretSpeedCodeMgModel
		resp          = &pbuserapi.LevelUpResp{}
	)

	userExt, err := userExtColl.GetAndCreate(ctx, userId)
	if err != nil || userExt == nil {
		logger.Errorf(ctx, "get user ext info failed,err=%v", err.Error())
		return nil, errorcode.SpeedCodeUsageError
	}

	if userExt.GetUlevel() == const_busi.UserLevel5 {
		return nil, errorcode.SpeedCodeUsageError
	}

	speedCode, err := speedCodeColl.FindOne(ctx, bson.M{"_id": req.SpeedCode, "status": 0})
	if err != nil || speedCode == nil {
		return nil, errorcode.SpeedCodeInvalid
	}
	if speedCode.FromUserId == userId {
		return nil, errorcode.SpeedCodeUsageError
	}

	signTimes := setting.Maozhua.SpeedCodeExchangeSignTimesForNormal.Get()
	if userExt.GetNewPenalties() > 0 {
		signTimes = setting.Maozhua.SpeedCodeExchangeSignTimesForPenalties.Get()
	}

	if resp, err = u.checkLevUpAndUpdate(ctx, userId, signTimes); err != nil {
		logger.Errorf(ctx, "checkLevUpAndUpdate err : %v", err)
		return nil, err
	}

	updates := map[string]any{
		"sign_in_times":     0,
		"speed_code_status": const_busi.SpeedCodeStatusNo,
		"speed_code":        "",
		"update_time":       time.Now().UnixMilli(),
	}
	if err := dailySignColl.UpdateOne(ctx, bson.M{"user_id": speedCode.FromUserId}, updates); err != nil {
		return nil, err
	}

	if config.ServerConfig.Env == "test" && speedCode.SpeedCode == "MAOZUA" {
		return resp, nil
	}

	if err := speedCodeColl.UpdateOne(ctx,
		bson.M{"_id": speedCode.SpeedCode},
		map[string]any{
			"status":    1,
			"toUserId":  userId,
			"usageTime": time.Now().UnixMilli(),
		}); err != nil {
		return nil, err
	}

	//点亮新芽勋章
	expire := time.Now().Add(time.Hour * 24 * 10).UnixMilli()
	_ = u.MediaAdd(ctx, speedCode.FromUserId, const_busi.MedalIdXinYa, expire)

	return resp, nil
}

func (u *UserCenterMng) LevelRights(ctx context.Context) (*pbuserapi.LevelAllInfoResp, error) {
	var (
		userId = middleware.GetUserID(ctx.(*gin.Context))
		resp   = &pbuserapi.LevelAllInfoResp{
			LevelCards: make([]*pbuserapi.LevelBaseCard, 0),
		}
	)

	userExt, err := u.DataCache.GetImpl().UserInfoExtMgModel.GetAndCreate(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user ext info failed,err=%v", err.Error())
		return resp, nil
	}

	uis := const_busi.GetUserLevelUp(userExt.GetNewPenalties() > 0)
	keys := make([]int32, 0)
	for i, _ := range uis {
		keys = append(keys, i)
	}

	sort.Slice(keys, func(i, j int) bool {
		return keys[i] < keys[j]
	})

	for _, key := range keys {
		item := pbuserapi.LevelBaseCard{}
		err := copier.Copy(&item, uis[key])
		if err != nil {
			continue
		}
		if key > 5 {
			break
		}
		resp.LevelCards = append(resp.LevelCards, &item)
	}

	return resp, nil
}

func (u *UserCenterMng) checkLevUpAndUpdate(ctx context.Context, userId int64, signTimes int32) (*pbuserapi.LevelUpResp, error) {
	var (
		userExtColl   = u.DataCache.GetImpl().UserInfoExtMgModel
		dailySignColl = u.DataCache.GetImpl().SecretDailySignInMgModel
		resp          = &pbuserapi.LevelUpResp{}
	)

	userExt, err := userExtColl.GetAndCreate(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user ext info failed,err=%v", err.Error())
		return nil, err
	}

	sign, err := dailySignColl.FindOne(ctx, bson.M{"user_id": userId})
	if err != nil {
		logger.Errorf(ctx, "get user daily sign failed,err=%v", err.Error())
		return nil, err
	}

	var (
		currLevel   = userExt.GetUlevel()
		isPenalties = userExt.GetNewPenalties() > 0
	)

	if sign == nil {
		currLevelInfo := u.getLevelInfo(ctx, userId, currLevel, 0, isPenalties)

		v := 0
		if signTimes > 1 {
			v = 1
		}
		if err := dailySignColl.Create(ctx, &pbmgdb.SecretDailySignInMgDbModel{
			Id:                 snow_flake.GetSnowflakeID(),
			UserId:             userId,
			SignInTimes:        int32(v),
			CreateTime:         time.Now().UnixMilli(),
			FlagResetPenalties: true,
		}); err != nil {
			return nil, err
		}

		if signTimes-1 > 0 {
			//第一次直接使用加速码
			return u.checkLevUpAndUpdate(ctx, userId, signTimes-1)
		}

		resp.LevelInfo = currLevelInfo
		return resp, nil
	} else {
		currLevelInfo := u.getLevelInfo(ctx, userId, currLevel, sign.SignInTimes, isPenalties)
		currLevelInfo.SpeedCode = sign.SpeedCode
		currLevelInfo.DrawSpeedCodeStatus = sign.SpeedCodeStatus

		resp.BLevelUp, currLevelInfo = u.checkLevelUp(ctx, userId, currLevel, isPenalties, currLevelInfo, signTimes)
		resp.LevelInfo = currLevelInfo

		if resp.BLevelUp == true {
			currLevel = currLevelInfo.Ulevel
			nextLevCfg := const_busi.GetLevelCfg(currLevel)

			// 升级后下一个等级的信息
			nextLevelInfo := u.getLevelInfo(ctx, userId, currLevel, currLevelInfo.NextLevelCard.SignTimes, isPenalties) // 获取下一个等级的信息
			nextLevelInfo.BLevelUp = currLevelInfo.BLevelUp
			if currLevelInfo.SpeedCode != "" {
				nextLevelInfo.SpeedCode = currLevelInfo.SpeedCode
				nextLevelInfo.DrawSpeedCodeStatus = currLevelInfo.DrawSpeedCodeStatus
			}
			resp.LevelInfo = nextLevelInfo

			resp.NextLevelDesc = nextLevCfg.LevelUpDescArr // 填充等级描述
			// 更新等级到userExt表
			update := map[string]interface{}{"ulevel": currLevel}
			if err := userExtColl.UpdateDictById(ctx, userId, update, nil); err != nil {
				logger.Error(ctx, "UpdateDictById info failed", err)
				return nil, err
			}
		}

		// 将更新的记录保存到db
		changes := map[string]interface{}{
			"sign_in_times":     currLevelInfo.NextLevelCard.SignTimes,
			"update_time":       time.Now().UnixMilli(),
			"speed_code_status": currLevelInfo.DrawSpeedCodeStatus,
			"speed_code":        currLevelInfo.SpeedCode,
		}
		cond := map[string]interface{}{"user_id": userId}
		if err := dailySignColl.UpdateOne(ctx, cond, changes); err != nil {
			logger.Error(ctx, "update level info failed", err)
			return resp, err
		}

		resp.LevelInfo.DrawSpeedCodeStatus = currLevelInfo.DrawSpeedCodeStatus
		resp.LevelInfo.SpeedCode = currLevelInfo.SpeedCode
		return resp, nil
	}
}

func (u *UserCenterMng) getLevelInfo(ctx context.Context, userId int64, currLevel, curSignTimes int32, penalties bool) *pbuserapi.CurrentLevelInfo {
	levelCfg := const_busi.GetLevelCfg(currLevel)

	levelInfo := &pbuserapi.CurrentLevelInfo{
		Ulevel:              currLevel,
		LevelTitle:          levelCfg.Title,
		NextLevelCard:       nil,
		BDailySigned:        u.DataCache.GetImpl().GetUserDailySign(ctx, userId),
		HasPunishedHistory:  penalties,
		BLevelUp:            false,
		NextLevelDesc:       levelCfg.LevelUpDescArr,
		DrawSpeedCodeStatus: 0,
		SpeedCode:           "",
	}

	// 下一级卡片信息
	if currLevel < const_busi.UserMaxLevel && currLevel >= const_busi.UserLevel0 {
		nextLvl := const_busi.GetLevelCfg(currLevel + 1)
		nextLvl.BuildTaskMessage(penalties)

		if curSignTimes > nextLvl.FullSignTimes {
			curSignTimes = nextLvl.FullSignTimes
		}

		levelInfo.NextLevelCard = &pbuserapi.NextLevelCard{
			NextUlevel:     nextLvl.Level,
			NextLevelTitle: nextLvl.Title,
			SignTimes:      curSignTimes,
			FullSignTimes:  nextLvl.FullSignTimes,
			LevDesc:        nextLvl.LevelUpDesc,
			RealNameAuth:   proto.Int32(const_level.RealNameAuthClose),
			SheNiuAuth:     proto.Int32(const_level.SheNiuAuthClose),
			NextLevelDesc:  nextLvl.LevelUpDescArr,
		}
	}
	return levelInfo
}

func (u *UserCenterMng) checkLevelUp(ctx context.Context, userId int64, currLevel int32, isPenalties bool, currLevelInfo *pbuserapi.CurrentLevelInfo, addSignTimes int32) (bool, *pbuserapi.CurrentLevelInfo) {
	//检查签到次数条件
	currLevelInfo = u.checkSignTimes(ctx, userId, isPenalties, addSignTimes, currLevelInfo)
	bLevelUp := currLevelInfo.BLevelUp
	logger.Infof(ctx, "bLevelUp:", bLevelUp)

	//获取身份证/社牛认证情况
	authID, authSN := u.getExtCheckInfo(ctx, userId)
	if authID {
		currLevelInfo.NextLevelCard.RealNameAuth = proto.Int32(const_level.RealNameAuthPass)
	} else {
		currLevelInfo.NextLevelCard.RealNameAuth = proto.Int32(const_level.RealNameAuthNoPass)
	}
	if authSN {
		currLevelInfo.NextLevelCard.SheNiuAuth = proto.Int32(const_level.SheNiuAuthPass)
	} else {
		currLevelInfo.NextLevelCard.SheNiuAuth = proto.Int32(const_level.RealNameAuthNoPass)
	}

	//额外升级条件：lv4，身份证/社牛条件
	switch currLevelInfo.Ulevel {
	case const_busi.UserLevel4:
		//违规用户4级，但签到次数不满足
		//fmt.Println("isPenalties, currLevelInfo.NextLevelCard.SignTimes, currLevelInfo.NextLevelCard.FullSignTimes", isPenalties, currLevelInfo.NextLevelCard.SignTimes, currLevelInfo.NextLevelCard.FullSignTimes)
		if isPenalties && currLevelInfo.NextLevelCard.SignTimes != currLevelInfo.NextLevelCard.FullSignTimes {
			return bLevelUp, currLevelInfo
		}

		if authID && authSN {
			bLevelUp = true
		} else {
			bLevelUp = false
		}

		if bLevelUp {
			currLevelInfo.Ulevel += 1
			currLevelInfo.NextLevelCard.SignTimes = 0
			currLevelInfo.BLevelUp = bLevelUp
			return bLevelUp, currLevelInfo
		} else if currLevel != const_busi.UserLevel4 {
			return currLevelInfo.BLevelUp, currLevelInfo
		}
		return bLevelUp, currLevelInfo
	default:
		return bLevelUp, currLevelInfo
	}
}

// 检查签到次数
// return 是否升级/溢出次数/升级数量
func (u *UserCenterMng) checkSignTimes(ctx context.Context, userId int64, isPenalties bool, addSignTimes int32, levelInfo *pbuserapi.CurrentLevelInfo) *pbuserapi.CurrentLevelInfo {
	finalSignTimes := levelInfo.NextLevelCard.SignTimes + addSignTimes
	currFullSignTimes := levelInfo.NextLevelCard.FullSignTimes
	logger.Infof(ctx, "finalSignTimes", finalSignTimes, "currFullSignTimes", currFullSignTimes, "levelInfo", levelInfo)

	if finalSignTimes >= currFullSignTimes {
		//五级，满足领取加速码签到次数
		if levelInfo.Ulevel == const_busi.UserLevel5 {
			if levelInfo.SpeedCode == "" {
				levelInfo.DrawSpeedCodeStatus = const_busi.SpeedCodeStatusDraw
				levelInfo.SpeedCode = u.drawSpeedCode(ctx, userId)
			}
			levelInfo.NextLevelCard.SignTimes = levelInfo.NextLevelCard.FullSignTimes
			return levelInfo
		}

		//当前四级
		if levelInfo.Ulevel == const_busi.UserLevel4 {
			if !isPenalties {
				levelInfo.NextLevelCard.SignTimes = 0
				return levelInfo
			} else {
				levelInfo.NextLevelCard.SignTimes = levelInfo.NextLevelCard.FullSignTimes
				return levelInfo
			}
		}

		//升级
		if levelInfo.Ulevel < const_busi.UserLevel4 {
			levelInfo.Ulevel += 1
			levelInfo = u.getLevelInfo(ctx, userId, levelInfo.Ulevel, levelInfo.NextLevelCard.SignTimes, isPenalties)
		}
		levelInfo.BLevelUp = true
		//升级后成为4级，需再次判断
		if levelInfo.Ulevel == const_busi.UserLevel4 && !isPenalties {
			levelInfo.NextLevelCard.SignTimes = 0
			return levelInfo
		}

		//连续升级（使用加速码时）
		addSignTimes = finalSignTimes - currFullSignTimes
		if levelInfo.Ulevel <= const_busi.UserLevel4 && addSignTimes > 0 {
			levelInfo.NextLevelCard.SignTimes = 0
			return u.checkSignTimes(ctx, userId, isPenalties, addSignTimes, levelInfo)
		}

		//违规4级用户保留当前剩余签到次数
		if levelInfo.Ulevel == const_busi.UserLevel4 && isPenalties {
			levelInfo.NextLevelCard.SignTimes = addSignTimes
		} else {
			levelInfo.NextLevelCard.SignTimes = 0
		}
		return levelInfo
	} else {
		levelInfo.NextLevelCard.SignTimes = finalSignTimes
		return levelInfo
	}
}

// 领取加速码
func (u *UserCenterMng) drawSpeedCode(ctx context.Context, userId int64) string {
	//生成
	speedCode, err := u.DataCache.GetImpl().SecretSpeedCodeMgModel.Create(ctx, userId)
	if err != nil {
		return ""
	}

	updates := map[string]any{
		"speed_code":  speedCode,
		"update_time": time.Now().UnixMilli(),
	}
	if err := u.DataCache.GetImpl().SecretDailySignInMgModel.UpdateOne(ctx, bson.M{"user_id": userId}, updates); err != nil {
		return ""
	}
	return speedCode
}

func (u *UserCenterMng) getExtCheckInfo(ctx context.Context, userId int64) (bool, bool) {
	var (
		authID bool
		authSN bool
	)
	// 身份证
	filter := bson.D{
		{"user_id", userId},
		{"status", const_busi.UserCardStatus},
	}
	_, err := u.DataCache.GetImpl().SecretUserIdentificationCardMgModel.FindOne(ctx, filter)
	switch err {
	case mongo.ErrNoDocuments:
		authID = false
	case nil:
		authID = true
	default:
		logger.Error(ctx, "SecretUserIdentificationCardMgModel.FindOne", err)
		authID = false
	}

	// 5 社牛勋章
	medal, err := u.DataCache.GetImpl().UserMedalMgModel.GetOneByMediaAndUserId(ctx, userId, const_busi.MedalIdSocialButterfly)
	if err != nil {
		if err != rdsV8.Nil {
			logger.Error(ctx, "checkLevelUp.GetOneByMediaAndUserId", err)
		}
		authSN = false
	}
	if medal == nil {
		authSN = false
	} else if medal.GetExpire() > time.Now().UnixMilli() {
		authSN = true
	}

	return authID, authSN
}
