package once

import (
	"content_svr/config"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/user"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"gorm.io/gorm"
	"log"
	"time"
)

func addUserExtTalkMode(mngDB *mongo.Client, mysqlDB *gorm.DB) {
	db := mngDB.Database(config.ServerConfig.MongodbConfig.DBName)
	secretUserExtInfoCollection := db.Collection("secretUserExtInfo")

	var page int = 1
	var size int = 10

	ctx := context.Background()
	for {
		log.Println(page)
		userInfoList := make([]*pbapi.UserinfoDbModel, 0)
		offset := (page - 1) * size
		err := mysqlDB.Table("user_info").Where("app_flag = 5 and status = 1").Limit(size).Offset(offset).Find(&userInfoList).Error
		if err == gorm.ErrRecordNotFound {
			return
		}
		if err != nil {
			logger.Errorf(ctx, "翻页失败 page: %d  err: %v\n", page, err)
			page++
			continue
		}

		if len(userInfoList) == 0 {
			return
		}

		userInfoIds := make([]int64, 0)
		for _, info := range userInfoList {
			if info == nil {
				continue
			}

			adult, err := user.JudgeAdult(info.GetBirth())
			if err != nil {
				logger.Errorf(ctx, "解析生日失败 %v\n", info)
			}

			if !adult {
				userInfoIds = append(userInfoIds, info.GetUserId())
			}

		}

		if len(userInfoIds) == 0 {
			page++
			continue
		}

		logger.Infof(ctx, "update user_id list: %v", userInfoIds)
		filter := bson.M{"_id": bson.M{"$in": userInfoIds}}
		update := bson.M{"$set": bson.M{"talkMode": 2}}
		_, err = secretUserExtInfoCollection.UpdateMany(ctx, filter, update)
		if err != nil {
			logger.Error(ctx, "secretUserExtInfoCollection.UpdateMany", err)
		}

		//if result.ModifiedCount == 0 {
		//	logger.Infof(ctx, "secretUserExtInfoCollection.UpdateMany count: %d, page, %d", 0, page)
		//}

		time.Sleep(time.Millisecond * 100)
		page++
	}

}
