package const_busi

// redis value
const (
	AdFeedbackNil = iota
	_
	AdFeedbackFormChannel // 来自渠道
	_                     // 来自app 该值为userId
)
