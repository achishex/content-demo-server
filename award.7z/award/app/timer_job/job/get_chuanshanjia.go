package job

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"context"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/go-resty/resty/v2"
	"sort"
	"time"
)

func InitCTJ(write, read *dao.ManagerDB) {
	go func() {
		ctrl := newUserCTJControl(write, read)
		//ctrl.once()
		//return

		ctrl.Do(func() {
			ctx := requestid.WithRequestID(context.Background())
			if err := ctrl.DoTask(ctx, time.Now().AddDate(0, 0, -1)); err != nil {
				logger.Errorf(ctx, "newUserCTJControl.DoTask: %v", err)
				// 五分钟后重试
				ctrl.ticker.Reset(time.Minute * 5)
				return
			}

			ctrl.ticker.Reset(ctrl.calcIntervalTime())
		})

	}()
}

type userCTJControl struct {
	TickerExecute
	write, read *dao.ManagerDB
}

func newUserCTJControl(write, read *dao.ManagerDB) userCTJControl {
	// 凌晨四点半执行
	ctrl := userCTJControl{}
	ctrl.hour = 3
	ctrl.minter = 30
	ctrl.write = write
	ctrl.read = read
	return ctrl
}

func (l userCTJControl) once() {
	for i := 15; i > 0; i-- {
		ctx := requestid.WithRequestID(context.Background())
		now := time.Now()
		target := now.AddDate(0, 0, -i)
		//target := time.Date(2022, 8, 10, now.Hour(), now.Minute(), now.Second(), now.Nanosecond(), now.Location())
		if err := l.DoTask(ctx, target); err != nil {
			logger.Error(context.Background(), "InitCTJ:", err)
		}
		//break
	}
}

func (l userCTJControl) DoTask(ctx context.Context, targetTime time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	csjUtil := csjMediaUtil{
		userID:      34341,
		roleID:      34341,
		secureKey:   "09606bebf8c54b1b4e45ae9e13b85d6f",
		version:     "2.0",
		signType:    "MD5",
		keyUserID:   "user_id",
		keyRoleID:   "role_id",
		keyVersion:  "version",
		keySign:     "sign",
		keySignType: "sign_type",
		csjHost:     "https://open-api.csjplatform.com",
	}
	params := map[string]interface{}{
		"currency": "cny",
		"date":     targetTime.Format("2006-01-02"),
		"region":   "cn",
	}

	targetUrl := csjUtil.getMediaRTIncome(params)
	//logger.Info(ctx, targetUrl)
	client := resty.New()
	r, err := client.R().Get(targetUrl)
	if err != nil {
		return err
	}

	body := r.String()
	//logger.Info(ctx, body)

	resp := csjResponse{}
	if err := json.Unmarshal([]byte(body), &resp); err != nil {
		return err
	}

	for _, items := range resp.Data {
		for _, item := range items {
			item.CreateTime = time.Now().UnixMilli()
			data, err := l.read.CsjAdvertisementData.FindOne(ctx, map[string]interface{}{
				"date":  targetTime.Format("2006-01-02"),
				"appid": item.AppId,
			})
			if err == xerr.DbNotFound {
				_, _ = l.read.CsjAdvertisementData.Insert(ctx, item)
			} else {
				_, _ = l.read.CsjAdvertisementData.UpdateOne(ctx, data.ID, item)
			}

		}
	}

	logger.Infof(ctx, "%d 拉取穿山甲数据完成\n", l.baseTimeByDay(targetTime))
	return nil
}

type csjMediaUtil struct {
	userID      int
	roleID      int
	secureKey   string
	version     string
	signType    string
	keyUserID   string
	keyRoleID   string
	keyVersion  string
	keySign     string
	keySignType string
	csjHost     string
}

func (c *csjMediaUtil) signGen(params map[string]interface{}) map[string]string {
	result := make(map[string]string)

	if params == nil {
		fmt.Println("invalid params: ", params)
		return result
	}

	if c.userID != 0 {
		params[c.keyUserID] = c.userID
	}

	if c.roleID != 0 {
		params[c.keyRoleID] = c.roleID
	}

	params[c.keyVersion] = c.version
	params[c.keySignType] = c.signType

	keys := []string{}
	for k, _ := range params {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	rawStr := ""
	for _, k := range keys {
		rawStr += fmt.Sprintf("%s=%v&", k, params[k])
	}

	if len(rawStr) == 0 {
		return result
	}
	signStr := rawStr[:len(rawStr)-1] + c.secureKey

	hashMd5 := md5.New()
	hashMd5.Write([]byte(signStr))
	signBytes := hashMd5.Sum(nil)
	signHex := hex.EncodeToString(signBytes)

	result[c.keySign] = signHex
	result["url"] = rawStr + "sign=" + signHex
	return result
}

func (c *csjMediaUtil) getSignedURL(params map[string]interface{}) string {
	result := c.signGen(params)
	return result["url"]
}

func (c *csjMediaUtil) getMediaRTIncome(params map[string]interface{}) string {
	signedURL := c.getSignedURL(params)
	if signedURL == "" {
		return ""
	}
	return c.csjHost + "/union_media/open_api/rt/income?" + signedURL
}

type csjResponse struct {
	Code    string                                   `json:"Code"`
	Message string                                   `json:"Message"`
	Data    map[string][]*model.CsjAdvertisementData `json:"Data"`
}
