package model

const collectionNamePersonalPoliceDailyData = "personalPoliceDailyData"

type PersonalPoliceDailyData struct {
	ID int64 `bson:"_id,omitempty" json:"id,omitempty"`

	Daily        uint  `json:"daily" bson:"daily"`
	UserId       int64 `json:"user_id" bson:"userId"`
	SuccessCount uint  `json:"success_count" bson:"successCount"`
}
