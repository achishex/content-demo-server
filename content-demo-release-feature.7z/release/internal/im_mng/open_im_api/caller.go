package open_im_api

import (
	"content_svr/config"
	"context"
	"github.com/OpenIMSDK/protocol/auth"
	"github.com/OpenIMSDK/protocol/constant"
	"github.com/OpenIMSDK/protocol/friend"
	"github.com/OpenIMSDK/protocol/group"
	"github.com/OpenIMSDK/protocol/msg"
	"github.com/OpenIMSDK/protocol/sdkws"
	"github.com/OpenIMSDK/protocol/user"
	"github.com/OpenIMSDK/tools/errs"
	"github.com/openimsdk/open-im-server/v3/pkg/apistruct"
)

type IOpenIMCaller interface {
	ImAdminTokenWithDefaultAdmin(ctx context.Context) (string, error)
	UserToken(ctx context.Context, userID string, platform int32) (string, error)
	ForceOffLine(ctx context.Context, userID string) error

	UpdateUserInfo(ctx context.Context, userID string, nickName string, faceURL string) error
	RegisterUser(ctx context.Context, users []*sdkws.UserInfo) error
	UserRegisterCount(ctx context.Context, start int64, end int64) (map[string]int64, int64, error)
	AccountCheck(ctx context.Context, userIds []string) (bool, []string, error)

	ImportFriend(ctx context.Context, ownerUserID string, friendUserID []string) error
	FriendUserIDs(ctx context.Context, userID string) ([]string, error)

	CreateGroup(ctx context.Context, req *group.CreateGroupReq) (*group.CreateGroupResp, error)
	FindGroupInfo(ctx context.Context, req *group.GetGroupsInfoReq) (*group.GetGroupsInfoResp, error)
	SetGroupInfo(ctx context.Context, req *group.SetGroupInfoReq) error
	InviteToGroup(ctx context.Context, req *group.InviteUserToGroupReq) error
	JoinGroup(ctx context.Context, req *group.JoinGroupReq) error
	KickGroup(ctx context.Context, req *group.KickGroupMemberReq) error
	GetGroupsAbstractInfo(ctx context.Context, req *group.GetGroupAbstractInfoReq) (*group.GetGroupAbstractInfoResp, error)
	GroupApplicationResponse(ctx context.Context, req *group.GroupApplicationResponseReq) error
	DismissGroup(ctx context.Context, req *group.DismissGroupReq) error
	QuitGroup(ctx context.Context, req *group.QuitGroupReq) error
	TransferGroup(ctx context.Context, req *group.TransferGroupOwnerReq) error
	SetGroupMemberInfo(ctx context.Context, req *group.SetGroupMemberInfoReq) error
	GetJoinedGroupList(ctx context.Context, req *group.GetJoinedGroupListReq) (*group.GetJoinedGroupListResp, error)
	GetGroupMembersInfo(ctx context.Context, req *group.GetGroupMembersInfoReq) (*group.GetGroupMembersInfoResp, error)

	// 发消息
	SendMsg(ctx context.Context, req *apistruct.SendMsgReq) (*msg.SendMsgResp, error)
}

type OpenIMCaller struct{}

func NewOpenIMCaller() IOpenIMCaller {
	return &OpenIMCaller{}
}

func (c *OpenIMCaller) ImAdminTokenWithDefaultAdmin(ctx context.Context) (string, error) {
	return c.UserToken(ctx, config.ServerConfig.OpenImConfig.Admin.ImAdmin, constant.AdminPlatformID)
}

func (c *OpenIMCaller) ImportFriend(ctx context.Context, ownerUserID string, friendUserIDs []string) error {
	if len(friendUserIDs) == 0 {
		return nil
	}
	_, err := importFriend.Call(ctx, &friend.ImportFriendReq{
		OwnerUserID:   ownerUserID,
		FriendUserIDs: friendUserIDs,
	})
	return err
}

func (c *OpenIMCaller) AccountCheck(ctx context.Context, userIds []string) (bool, []string, error) {
	resp, err := accountCheck.Call(ctx, &user.AccountCheckReq{
		CheckUserIDs: userIds,
	})
	if err != nil && !errs.ErrRecordNotFound.Is(err) {
		return false, userIds, err
	}

	var (
		result        = true
		failedUserIds []string
	)

	if err != nil && errs.ErrRecordNotFound.Is(err) {
		result = false
		failedUserIds = userIds
		return result, failedUserIds, nil
	}

	if len(resp.Results) > 0 {
		for _, v := range resp.Results {
			if v.AccountStatus == "unregistered" {
				result = false
				failedUserIds = append(failedUserIds, v.UserID)
			}
		}
	}

	return result, failedUserIds, nil
}

func (c *OpenIMCaller) UserToken(ctx context.Context, userID string, platformID int32) (string, error) {
	resp, err := userToken.Call(ctx, &auth.UserTokenReq{
		Secret:     config.ServerConfig.OpenImConfig.Secret,
		PlatformID: platformID,
		UserID:     userID,
	})
	if err != nil {
		return "", err
	}
	return resp.Token, nil
}

func (c *OpenIMCaller) UpdateUserInfo(ctx context.Context, userID string, nickName string, faceURL string) error {
	_, err := updateUserInfo.Call(ctx, &user.UpdateUserInfoReq{UserInfo: &sdkws.UserInfo{
		UserID:   userID,
		Nickname: nickName,
		FaceURL:  faceURL,
	}})
	return err
}

func (c *OpenIMCaller) RegisterUser(ctx context.Context, users []*sdkws.UserInfo) error {
	_, err := registerUser.Call(ctx, &user.UserRegisterReq{
		Secret: config.ServerConfig.OpenImConfig.Secret,
		Users:  users,
	})
	return err
}

func (c *OpenIMCaller) ForceOffLine(ctx context.Context, userID string) error {
	for id := range constant.PlatformID2Name {
		_, _ = forceOffLine.Call(ctx, &auth.ForceLogoutReq{
			PlatformID: int32(id),
			UserID:     userID,
		})
	}
	return nil
}

func (c *OpenIMCaller) UserRegisterCount(ctx context.Context, start int64, end int64) (map[string]int64, int64, error) {
	resp, err := registerUserCount.Call(ctx, &user.UserRegisterCountReq{
		Start: start,
		End:   end,
	})
	if err != nil {
		return nil, 0, err
	}
	return resp.Count, resp.Total, nil
}

func (c *OpenIMCaller) FriendUserIDs(ctx context.Context, userID string) ([]string, error) {
	resp, err := friendUserIDs.Call(ctx, &friend.GetFriendIDsReq{UserID: userID})
	if err != nil {
		return nil, err
	}
	return resp.FriendIDs, nil
}

func (c *OpenIMCaller) FindGroupInfo(ctx context.Context, req *group.GetGroupsInfoReq) (*group.GetGroupsInfoResp, error) {
	resp, err := getGroupsInfo.Call(ctx, req)
	if err != nil {
		return nil, err
	}
	return resp, nil
}

func (c *OpenIMCaller) CreateGroup(ctx context.Context, req *group.CreateGroupReq) (*group.CreateGroupResp, error) {
	resp, err := createGroup.Call(ctx, req)
	if err != nil {
		return nil, err
	}
	return resp, nil
}

func (c *OpenIMCaller) SetGroupInfo(ctx context.Context, req *group.SetGroupInfoReq) error {
	_, err := setGroupsInfo.Call(ctx, req)
	if err != nil {
		return err
	}
	return nil
}

func (c *OpenIMCaller) InviteToGroup(ctx context.Context, req *group.InviteUserToGroupReq) error {
	_, _ = inviteToGroup.Call(ctx, req)
	return nil
}

func (c *OpenIMCaller) JoinGroup(ctx context.Context, req *group.JoinGroupReq) error {
	_, err := joinGroup.Call(ctx, req)
	if err != nil {
		return err
	}
	return nil
}

func (c *OpenIMCaller) KickGroup(ctx context.Context, req *group.KickGroupMemberReq) error {
	_, err := kickGroup.Call(ctx, req)
	if err != nil {
		return err
	}
	return nil
}

func (c *OpenIMCaller) GetGroupsAbstractInfo(ctx context.Context, req *group.GetGroupAbstractInfoReq) (*group.GetGroupAbstractInfoResp, error) {
	resp, err := getGroupsAbstractInfo.Call(ctx, req)
	if err != nil {
		return nil, err
	}
	return resp, nil
}

func (c *OpenIMCaller) GroupApplicationResponse(ctx context.Context, req *group.GroupApplicationResponseReq) error {
	_, err := groupApplicationResponse.Call(ctx, req)
	if err != nil {
		return err
	}
	return nil
}

func (c *OpenIMCaller) DismissGroup(ctx context.Context, req *group.DismissGroupReq) error {
	if _, err := dismissGroup.Call(ctx, req); err != nil {
		return err
	}
	return nil
}

func (c *OpenIMCaller) QuitGroup(ctx context.Context, req *group.QuitGroupReq) error {
	if _, err := quitGroup.Call(ctx, req); err != nil {
		return err
	}
	return nil
}

func (c *OpenIMCaller) TransferGroup(ctx context.Context, req *group.TransferGroupOwnerReq) error {
	if _, err := transferGroup.Call(ctx, req); err != nil {
		return err
	}
	return nil
}

func (c *OpenIMCaller) SetGroupMemberInfo(ctx context.Context, req *group.SetGroupMemberInfoReq) error {
	if _, err := setGroupMemberInfo.Call(ctx, req); err != nil {
		return err
	}
	return nil
}

func (c *OpenIMCaller) GetJoinedGroupList(ctx context.Context, req *group.GetJoinedGroupListReq) (*group.GetJoinedGroupListResp, error) {
	if resp, err := getJoinedGroupList.Call(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (c *OpenIMCaller) GetGroupMembersInfo(ctx context.Context, req *group.GetGroupMembersInfoReq) (*group.GetGroupMembersInfoResp, error) {
	if resp, err := getGroupMembersInfo.Call(ctx, req); err != nil {
		return nil, err
	} else {
		return resp, nil
	}
}

func (c *OpenIMCaller) SendMsg(ctx context.Context, req *apistruct.SendMsgReq) (*msg.SendMsgResp, error) {
	return sendMsg.Call(ctx, req)
}
