package once

import (
	"content_svr/config"
	"content_svr/internal/content_mng"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

func (c *command) FirstOnLineHallOfFame() {
	db := c.mngDB.Database(config.ServerConfig.MongodbConfig.DBName)
	superiorContentAwardDetail := db.Collection("superior_content_award_detail")

	defaultEndHourMinute := "23:30"
	if config.ServerConfig.SuperiorContentConfig != nil && len(config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.SettlementEndTime) > 0 {
		defaultEndHourMinute = config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.SettlementEndTime
	}

	cnfEndTime, err := time.Parse("15:04", defaultEndHourMinute)
	if err != nil {
		return
	}
	nowTime := time.Now()
	yesterday := nowTime.AddDate(0, 0, -1)

	beginTime := time.Date(yesterday.Year(), yesterday.Month(), yesterday.Day(), cnfEndTime.Hour(), cnfEndTime.Minute(), 0, 0, time.Local).UnixMilli()

	ctx := context.Background()
	filter := bson.M{
		"$or": []bson.M{
			bson.M{"type": 1},
			bson.M{"type": 3},
		},
		"$and": []interface{}{
			bson.M{"create_time": bson.M{"$gte": beginTime}},
			bson.M{"create_time": bson.M{"$lt": time.Now().UnixMilli()}},
		},
	}
	opts := &options.FindOptions{}
	cur, err := superiorContentAwardDetail.Find(ctx, filter, opts)
	if err != nil {
		panic(err)
	}
	//
	for cur.Next(ctx) {
		var superItem *pbmgdb.SuperiorContentAwardDetail
		err := cur.Decode(&superItem)
		if err != nil {
			logger.Error(ctx, "Decode error:", err)
			continue
		}
		if superItem == nil {
			logger.Errorf(ctx, "award is nil")
			continue
		}
		addHallOFFameHande := content_mng.NewAddKoLaHallOfFameOnce(c.redisDB)

		err = addHallOFFameHande.AddItemToHallOfFame(ctx, superItem.GetUserId(), superItem.GetAward())
		if err != nil {
			logger.Errorf(ctx, "write to hall of fame fail, err: %v, user: %v", err, superItem.GetUserId())
		}
	}

}

func (c *command) findFirst1centItem() (int64, int64, int64) {
	db := c.mngDB.Database(config.ServerConfig.MongodbConfig.DBName)
	superiorContentAwardDetail := db.Collection("superior_content_award_detail")
	//
	ctx := context.Background()
	beginTime := time.Date(time.Now().Year(), time.Now().Month(), time.Now().Day(), 0, 0, 0, 0, time.Local).UnixMilli()
	endTime := beginTime + 24*3600*1000

	filter := bson.M{
		"$or": []bson.M{
			bson.M{"type": 1},
		},
		"$and": []interface{}{
			bson.M{"create_time": bson.M{"$gte": beginTime}},
			bson.M{"create_time": bson.M{"$lt": endTime}},
			bson.M{"award": bson.M{"$eq": 0.1}},
		},
	}
	findOptions := options.Find().SetSort(bson.D{{"create_time", 1}}).SetLimit(1)
	cur, err := superiorContentAwardDetail.Find(ctx, filter, findOptions)
	if err != nil {
		panic(err)
	}

	//最早的一条 0.1
	userId := int64(0)
	id := int64(0)
	create_time := int64(0)
	for cur.Next(ctx) {
		var superItem *pbmgdb.SuperiorContentAwardDetail
		err := cur.Decode(&superItem)
		if err != nil {
			logger.Error(ctx, "Decode error:", err)
			continue
		}
		if superItem == nil {
			logger.Errorf(ctx, "award is nil")
			continue
		}

		userId = superItem.GetUserId()
		id = superItem.GetId()
		create_time = superItem.GetCreatTime()

		logger.Infof(ctx, "user:  %v, id: %v", userId, id)
		break
	}
	return userId, id, create_time
}

func (c *command) Add4centsForAward() {
	userId, id, create_time := c.findFirst1centItem()
	if userId > 0 {

		db := c.mngDB.Database(config.ServerConfig.MongodbConfig.DBName)
		superiorContentAwardDetail := db.Collection("superior_content_award_detail")
		//
		ctx := context.Background()
		beginTime := time.Date(time.Now().Year(), time.Now().Month(), time.Now().Day(), 0, 0, 0, 0, time.Local).UnixMilli()
		endTime := beginTime + 24*3600*1000

		//取一条0.1记录
		//...
		filter := bson.M{
			"$or": []bson.M{
				bson.M{"type": 1},
			},
			"$and": []interface{}{
				bson.M{"create_time": bson.M{"$gte": create_time}},
				bson.M{"create_time": bson.M{"$lt": endTime}},
				bson.M{"user_id": userId},
			},
		}

		findOptions := options.Find().SetSort(bson.D{{"create_time", 1}})
		cur, err := superiorContentAwardDetail.Find(ctx, filter, findOptions)
		if err != nil {
			panic(err)
		}
		//
		for cur.Next(ctx) {
			var superItem *pbmgdb.SuperiorContentAwardDetail
			err := cur.Decode(&superItem)
			if err != nil {
				logger.Error(ctx, "Decode error:", err)
				continue
			}
			if superItem == nil {
				logger.Errorf(ctx, "award is nil")
				continue
			}

			filterItems := bson.D{
				{"_id", superItem.GetId()},
			}
			//
			if id == superItem.GetId() {
				updateItems := bson.D{
					{"$set", bson.D{
						{"can_withdraw_award", superItem.GetCanWithdrawAward() + 0.4},
						{"total_award", superItem.GetTotalAward() + 0.4},
						{"award", superItem.GetAward() + 0.4},
					}},
				}
				_, err = superiorContentAwardDetail.UpdateOne(ctx, filterItems, updateItems)
				if err != nil {
					logger.Errorf(ctx, "update one fail, err: %v", err)
					continue
				}
			} else {

				updateItems := bson.D{
					{"$set", bson.D{
						{"can_withdraw_award", superItem.GetCanWithdrawAward() + 0.4},
						{"total_award", superItem.GetTotalAward() + 0.4},
					}},
				}
				_, err = superiorContentAwardDetail.UpdateOne(ctx, filterItems, updateItems)
				if err != nil {
					logger.Errorf(ctx, "update one fail, err: %v", err)
					continue
				}
			}
		}

		c.Add4centsForAward()
	}
}
