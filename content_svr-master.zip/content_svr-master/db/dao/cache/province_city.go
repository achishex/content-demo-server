package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type ProvinceCity struct {
	model.ProvinceCityModel
	redisManage *query_rds.Manage
}

func NewCacheProvinceCity(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *ProvinceCity {
	return &ProvinceCity{
		ProvinceCityModel: mongo.ProvinceCity,
		redisManage:       redisManage,
	}
}
