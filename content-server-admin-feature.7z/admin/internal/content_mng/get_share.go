package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/internal/busi_comm/version"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"content_svr/setting"
	"context"
	"fmt"
	"github.com/gookit/goutil/timex"
	"math/rand"
	"sort"
	"strconv"
	"time"
)

type UserWorkScoreList []*UserWorkInfoLocalScoreInfo

func (a UserWorkScoreList) Len() int { // 重写 Len() 方法
	return len(a)
}
func (a UserWorkScoreList) Swap(i, j int) { // 重写 Swap() 方法
	a[i], a[j] = a[j], a[i]
}
func (a UserWorkScoreList) Less(i, j int) bool { // 重写 Less() 方法， 从大到小排序
	return a[j].CalcScore < a[i].CalcScore
}

// 当前用户+作品的匹配度打分
type UserWorkInfoLocalScoreInfo struct {
	UserId          int64                     //消费者id		非nil
	UserIdUk        string                    //消费者id		非nil
	Blogin          bool                      //是否登录
	UserInfo        *data_cache.UserInfoLocal //非nil
	WorkInfoLocal   *data_cache.WorkInfoLocal // 非nil
	AuthorInfoLocal *data_cache.UserInfoLocal // 非nil
	Liked           bool                      //是否对作品已点赞。
	CalcScore       float32                   // UserId+ WorkInfoLocal的匹配度打分。
	UserReaded      bool                      //用户是否已读此消息。
	SignStarInfo    *pbapi.StarSignData
	RemindInfo      []*pbapi.RemindUserNode
	RemindGroup     []*pbapi.RemindGroupNode
	Followed        int32 //author is follow user 0, 1
}

// https://wm3zyl5om7.feishu.cn/sheets/shtcnN9bwl2WgeiHQgcXcuzo8Rc?sheet=dPLkcv
func (p *UserWorkInfoLocalScoreInfo) Score(ctx context.Context, coor *pbapi.CoordinateRedis) (float32, int32) {
	userInfo := p.UserInfo
	workDbModel := p.WorkInfoLocal.WorkInfoDbModel
	authorInfo := p.AuthorInfoLocal

	// 只推给从未激活过的账号. currentModel !=1 && chitchatCloseTimes=0
	if p.Blogin == true && workDbModel.GetSpecial() == int32(pbconst.WorkSpecialEnum_work_special_type_autochitcode) {
		if userInfo.PsecretUserExtInfo.GetCurrentModel() != 1 &&
			userInfo.PsecretUserExtInfo.GetChitchatCloseTimes() == 0 {
			//autochitcode 只给女号。
			genderRate := 0
			if userInfo.UserInfoDbModel.GetGender() == int32(pbconst.Sex_female) {
				genderRate = 100
			}
			if rand.Intn(100) < genderRate {
				logger.Infof(ctx, "autochitcode matched, workid=%v, author_id=%v, workTitle=%v, curUserid=%v",
					workDbModel.GetId(), workDbModel.GetUserId(), workDbModel.GetTitle(), p.UserId)
				return 0, int32(pbconst.UserWorkScoreLevelEnum_level_2_uwsl) //命中
			}
		}
		return 0, int32(pbconst.UserWorkScoreLevelEnum_level_0_uwsl)
	}

	var calcScore float32 = 0
	if authorInfo.UserInfoDbModel.GetUserId() == 129533901081600 {
		calcScore += 6001
	}

	timeIntval := time.Now().Unix() - utils.GenTimestamp(workDbModel.GetStartTime())
	if timeIntval < 60 {
		calcScore += 90
	} else if timeIntval >= 60 && timeIntval < 3*60 {
		calcScore += 50
	}

	// author  svip/vip/普通
	var memberScore float32 = 0
	// 女性发帖曝光最高
	if authorInfo.UserInfoDbModel.GetGender() == int32(pbconst.Sex_female) {
		memberScore = 150
	} else {
		//男性 vip 其次
		if authorInfo.MemberType > 0 {
			memberScore = 50
		}
	}
	calcScore += memberScore

	// author 根据level改变权重。
	//switch userInfo.PsecretUserExtInfo.GetUlevel() {
	//case 4:
	//	calcScore += 400
	//case 3:
	//	calcScore += 300
	//case 2:
	//	calcScore += 200
	//case 1:
	//	calcScore += 100
	//}

	// 自定义内容，
	//if p.WorkInfoLocal.WorkInfoDbModel.GetSpecial() == 0 || p.WorkInfoLocal.WorkInfoDbModel.GetSpecial() == 2 {
	//	calcScore += 115
	//}

	// 有附件图片
	if len(p.WorkInfoLocal.WorkObjAttr) > 0 {
		calcScore += 90
	}

	// 异性 memberScore*2
	if p.Blogin == true && authorInfo.UserInfoDbModel.GetGender() != userInfo.UserInfoDbModel.GetGender() {
		calcScore += memberScore * 2
	}

	// 作者男性: 降权重。
	//if authorInfo.UserInfoDbModel.GetGender() == int32(pbconst.Sex_male) {
	//	calcScore -= 220
	//}

	// 同城
	if p.Blogin == true && workDbModel.GetCity() != "" && workDbModel.GetCity() == coor.GetCity() {
		logger.Infof(ctx, "TsWorkPool 同城，加高权重150 city=%v", workDbModel.GetCity())
		calcScore += 150
	}

	// 重复曝光。 降权100分。
	if p.Blogin == true {
		if p.UserReaded {
			calcScore -= 100 //
		} else {
			calcScore += 100 //未曝光过，加分。
		}
	}

	if calcScore >= 5000 {
		//官方号，必出
		return calcScore, int32(pbconst.UserWorkScoreLevelEnum_level_2_uwsl)
	} else if calcScore >= 800 && calcScore < 5000 {
		if rand.Intn(100) < 50 {
			return calcScore, int32(pbconst.UserWorkScoreLevelEnum_level_2_uwsl)
		}
	} else if calcScore >= 600 && calcScore < 800 {
		if rand.Intn(100) < 40 {
			return calcScore, int32(pbconst.UserWorkScoreLevelEnum_level_2_uwsl)
		}
	} else if calcScore >= 500 && calcScore < 600 {
		if rand.Intn(100) < 35 {
			return calcScore, int32(pbconst.UserWorkScoreLevelEnum_level_2_uwsl)
		}
	} else if calcScore >= 350 && calcScore < 500 {
		if rand.Intn(100) < 30 {
			return calcScore, int32(pbconst.UserWorkScoreLevelEnum_level_2_uwsl)
		}
	} else if calcScore >= 200 && calcScore < 350 {
		if rand.Intn(100) < 25 {
			return calcScore, int32(pbconst.UserWorkScoreLevelEnum_level_2_uwsl)
		}
	} else if calcScore >= 100 && calcScore < 200 {
		if rand.Intn(100) < 20 {
			return calcScore, int32(pbconst.UserWorkScoreLevelEnum_level_2_uwsl)
		}
	} else if calcScore >= 50 && calcScore < 100 {
		if rand.Intn(100) < 15 {
			return calcScore, int32(pbconst.UserWorkScoreLevelEnum_level_2_uwsl)
		}
	} else {
		if rand.Intn(100) < 10 {
			return calcScore, int32(pbconst.UserWorkScoreLevelEnum_level_2_uwsl)
		}
	}
	return calcScore, int32(pbconst.UserWorkScoreLevelEnum_level_1_uwsl)
}

func (p *ContentMng) getVisitorCountLimit(ctx context.Context, userWorkScoreItem *UserWorkInfoLocalScoreInfo) int32 {
	var (
		level           int32 = 1
		visitCountLimit int32 = 0
	)
	if userWorkScoreItem.AuthorInfoLocal.PsecretUserExtInfo != nil {
		level = userWorkScoreItem.AuthorInfoLocal.PsecretUserExtInfo.GetUlevel()
	} else {
		logger.Errorf(ctx, "ext info is nll")
	}

	// 大于1级的女性用户，曝光量 等级+1
	if level > 1 && level < const_level.UserMaxLevel && userWorkScoreItem.AuthorInfoLocal.UserInfoDbModel.GetGender() == int32(pbconst.Sex_female) {
		level++
		//logger.Infof(ctx, "female, level++,  result.level=%v", level)
	}

	ulevelCfg := const_busi.GetLevelCfg(ctx, level)
	if userWorkScoreItem.AuthorInfoLocal.MemberType > 0 {
		visitCountLimit = ulevelCfg.VipVisitCountLimit
	} else {
		visitCountLimit = ulevelCfg.NoVipVisitCountLimit
	}

	//女性新用户在注册后的4天内（新手期），发布的动态曝光限流提升至200(配置值）
	regTime, _ := timex.FromString(userWorkScoreItem.UserInfo.UserInfoDbModel.GetCreateTime())
	day := int(-setting.Maozhua.NewUserByDays.Get())
	if userWorkScoreItem.UserInfo.UserInfoDbModel.GetGender() == int32(pbconst.Sex_female) && regTime.UnixMilli() > time.Now().AddDate(0, 0, day).UnixMilli() {
		visitCountLimit += setting.Maozhua.NewFemaleUserExposureLimit.Get()
	}

	return visitCountLimit
}

// 处理100条
func (p *ContentMng) handleBatch(ctx context.Context, header *pbapi.HttpHeaderInfo,
	workIdTsDict map[string]int64,
	userInfoLocal *data_cache.UserInfoLocal,
	revLimit int,
	flagHigh bool,
	flagHighPlus bool) (
	UserWorkScoreList, //高分内容(未读，曝光未满)
	UserWorkScoreList, //普通分内容(未读，曝光未满)
	UserWorkScoreList, // 兜底内容(未读但曝光已满的动态, 作者等级大于1)
	UserWorkScoreList, // 兜底内容(已读的动态, 作者等级大于1)
	error) {

	if revLimit <= 0 {
		logger.Infof(ctx, "TsWorkPool handleBantch, revLimit=%v, skip", revLimit)
		return nil, nil, nil, nil, nil
	}

	wcount := 0
	cTimeMs := utils.GetCurTsMs()
	highScoreWorks := make(UserWorkScoreList, 0)      //高分内容(未读，曝光未满)
	normalScoreWorks := make(UserWorkScoreList, 0)    //普通分内容(未读，曝光未满)
	backupUnReadedWorks := make(UserWorkScoreList, 0) // 兜底内容(未读但曝光已满的动态, 作者等级大于1)
	backupReadedWorks := make(UserWorkScoreList, 0)   // 兜底内容(已读的动态, 作者等级大于1)
	rdsRemoveIds := make([]string, 0)                 // 内容对所有人不可用 后面从待分发池子移除的。

	logHelpList := make([]string, 0) //日志
	defer func() {
		logger.Infof(ctx, "TsWorkPool handleBatch over, flagHigh %v, user_id=%v, wcount=%v, timeCostMs=%v, records=%v, rdsRemoveIds=%v",
			flagHigh, userInfoLocal.UserInfoDbModel.GetUserId(), wcount, utils.GetCurTsMs()-cTimeMs, logHelpList, rdsRemoveIds)
		if flagHighPlus {
			go p.DataCache.AsyncRemoveFromHighPlusTsWorkPoolRedis(ctx, rdsRemoveIds)
		} else if flagHigh {
			go p.DataCache.AsyncRemoveFromHighTsWorkPoolRedis(ctx, rdsRemoveIds)
		} else {
			go p.DataCache.AsyncRemoveFromTsWorkPoolRedis(ctx, rdsRemoveIds)
		}
		sort.Sort(sort.Reverse(highScoreWorks))
		sort.Sort(sort.Reverse(normalScoreWorks))
		sort.Sort(sort.Reverse(backupUnReadedWorks))
		sort.Sort(sort.Reverse(backupReadedWorks))
	}()

	curUserId := userInfoLocal.UserInfoDbModel.GetUserId()
	curUserIdUk := strconv.Itoa(int(curUserId))
	BLogin := true
	if header.Token == "" {
		curUserIdUk = header.Uk
		BLogin = false
	}

	// 获取官方号作品。
	var (
		officialWorkDict map[string]int64
		err              error
	)

	if BLogin {
		officialWorkDict, err = p.DataCache.GetImpl().GetOfficialWorkIdsRd(ctx)
		if err != nil {
			logger.Error(ctx, "TsWorkPool, get official workid failed, err=%v", err)
		}

		for k, v := range officialWorkDict {
			if rand.Intn(100) < 30 { // 30%的概率增加分发到分发队列中
				workIdTsDict[k] = v
			}
		}
	}

	for workIdStr, _ := range workIdTsDict {
		workId, err := utils.Str2Int64(workIdStr)

		sc := NewSuperiorContentInstance(p, nil, 0)
		//如果是已达优质奖励内容， 则有一定概率不分发出去，让更多的优质动态可以获取到奖励 激励更多用户去发优质动态
		//if flagHigh {
		//是否达到优质奖励，当前条件为有效评论人数>10
		//isReach, err := sc.CheckReachAwardCondOnWork(ctx, workId)
		//if err != nil {
		//	continue
		//}
		//config.ServerConfig.ContentConfig.HighFilterRatio 不分发概率，可配置
		//if isReach == 1 && rand.Intn(100) <= config.ServerConfig.ContentConfig.HighFilterRatio {
		//	logger.Infof(ctx, "Be filtered work. workId: %v", workId)
		//	continue
		//}
		//}

		wcount++
		// 已选到足够数据，返回
		if len(highScoreWorks) > revLimit {
			return highScoreWorks, normalScoreWorks, backupUnReadedWorks, backupReadedWorks, nil
		}

		if err != nil {
			//logger.Infof(ctx, "handleBatch:rm_distribute_poll:workid is illegal. work_id=%v",
			//	workIdStr)
			logHelpList = append(logHelpList, fmt.Sprintf("%v,%v", workIdStr, "workid illegal"))
			rdsRemoveIds = append(rdsRemoveIds, workIdStr)
			continue
		}

		// step 1 跳过user已经消费过的数据
		isReaded := false
		if BLogin == true {
			bExist, _, _ := p.DataCache.CheckUserReadHistoryPoolR(ctx, workIdStr, curUserIdUk)
			isReaded = bExist //是否已读
		}

		// start work =======
		// 获取 work 信息
		workinfo, err := p.DataCache.GetWorkInfoLocal(ctx, workId, false)
		if err != nil {
			//logger.Errorf(ctx, "handleBatch:query_failed: get workinfo failed. work_id=%v", workIdStr)
			logHelpList = append(logHelpList, fmt.Sprintf("#worknotfindfailed,%v", workIdStr))
			continue
		}

		//普通动态没有1个有效评论的动态  如果超过n次曝光 则不再给分发曝光
		if false == flagHigh && false == flagHighPlus {
			validUserNums, _ := sc.GetValidCommentUserNums(ctx, workId)
			if validUserNums == 0 && workinfo != nil {
				visitCountLimit := int32(0)
				//女性新用户在注册后的4天内（新手期），发布的动态曝光限流提升至200(配置值）
				regTime, _ := timex.FromString(userInfoLocal.UserInfoDbModel.GetCreateTime())
				day := int(-setting.Maozhua.NewUserByDays.Get())
				if userInfoLocal.UserInfoDbModel.GetGender() == int32(pbconst.Sex_female) && regTime.UnixMilli() > time.Now().AddDate(0, 0, day).UnixMilli() {
					visitCountLimit = setting.Maozhua.NewFemaleUserExposureLimit.Get()
				} else {
					visitCountLimit = int32(config.ServerConfig.ContentConfig.NoValidCommentExposureNum)
				}
				if workinfo.WorkInfoDbModel.GetVisitorCount() >= visitCountLimit {
					//logger.Infof(ctx, "no valid comment skip work. workId: %v, visitorCount: %v, title: %v", workId, workinfo.WorkInfoDbModel.GetVisitorCount(), workinfo.WorkInfoDbModel.GetTitle())
					continue
				}
			}
		}

		// check work status
		if workinfo == nil || workinfo.WorkInfoDbModel.GetStatus() != int32(pbconst.BaseTabStatus_valid) {
			// work没查到或者 status为不可用。
			//logger.Infof(ctx, "rm_distribute_poll:work info not find. work_id=%v", workId)
			logHelpList = append(logHelpList, fmt.Sprintf("#worknotfind, %v", workIdStr))
			rdsRemoveIds = append(rdsRemoveIds, workIdStr)
			continue
		}

		// 检查作品的是否超过分发时间
		if BLogin {
			workDispatchTime := p.getWorkDispatchTime(workinfo.WorkInfoDbModel, flagHigh, flagHighPlus)
			workCreateTime := utils.GenTimestamp(workinfo.WorkInfoDbModel.GetStartTime())
			if time.Now().Unix()-workCreateTime > int64(workDispatchTime) {
				//logger.Infof(ctx, "handleBatch:rm_distribute_poll:over time limit. work_id=%v", workId)
				logHelpList = append(logHelpList, fmt.Sprintf("#overtime,%v", workIdStr))
				continue
			}
		}

		// 动态可见范围
		if workinfo.WorkInfoDbModel.GetShowScope() == int32(pbconst.WorkShowScopeEnum_GLOBAL_SHOW_DIS) {
			logHelpList = append(logHelpList, fmt.Sprintf("#scopdis,%v,%v: %v", workIdStr, "work show scope not ",
				pbconst.WorkShowScopeEnum_GLOBAL_SHOW_DIS))
			rdsRemoveIds = append(rdsRemoveIds, workIdStr)
			continue
		}

		// 跳过自己的动态
		if BLogin == true && workinfo.WorkInfoDbModel.GetUserId() == curUserId {
			//logger.Infof(ctx, "handleBatch:addto_curUserBanWorkids: user_id=author_id, skip. work_id=%v", workId)
			logHelpList = append(logHelpList, fmt.Sprintf("#self,%v", workIdStr))
			continue
		}

		// 代发激活码的动态，不重复分发。
		if isReaded && workinfo.WorkInfoDbModel.GetSpecial() == int32(pbconst.WorkSpecialEnum_work_special_type_autochitcode) {
			logHelpList = append(logHelpList, fmt.Sprintf("#autochitcode %v,%v", workIdStr, "autochitcode work no repeated"))
			continue
		}
		// end work =======

		// start author =======
		// check author info
		authorInfo, err := p.DataCache.GetUserInfoLocal(ctx, header, workinfo.WorkInfoDbModel.GetUserId(), false)
		if err != nil {
			//logger.Errorf(ctx, "handleBatch:query_failed: query authorinfo failed. work_id=%v, user_id=%v", workId, workinfo.WorkInfoDbModel.GetUserId())
			logHelpList = append(logHelpList, fmt.Sprintf("authornofind,fial %v", workIdStr))
			continue
		}

		if authorInfo == nil {
			//logger.Infof(ctx, "handleBatch:rm_distribute_poll:author info not find. work_id=%v", workId)
			logHelpList = append(logHelpList, fmt.Sprintf("#authornofind%v", workIdStr))
			rdsRemoveIds = append(rdsRemoveIds, workIdStr)
			continue
		}

		//会员筛选设置过滤
		if userInfoLocal.MemberType > 0 {
			if userInfoLocal.PsecretUserExtInfo.WorkSetting != nil &&
				userInfoLocal.PsecretUserExtInfo.WorkSetting.GetGender() < const_busi.WorkSettingGenderUnlimited &&
				authorInfo.UserInfoDbModel.GetGender() != userInfoLocal.PsecretUserExtInfo.WorkSetting.GetGender() {
				continue
			}
		} else {
			//4天内的新注册男用户 只返回女性用户的动态，优先带图片
			regTime, _ := timex.FromString(userInfoLocal.UserInfoDbModel.GetCreateTime())
			day := int(-setting.Maozhua.NewUserByDays.Get())
			if userInfoLocal.UserInfoDbModel.GetGender() == int32(pbconst.Sex_male) && regTime.UnixMilli() > time.Now().AddDate(0, 0, day).UnixMilli() {
				if authorInfo.UserInfoDbModel.GetGender() != int32(pbconst.Sex_female) || workinfo.WorkInfoDbModel.GetType() != const_busi.WorkTypeImage {
					continue
				}
			}
		}

		userWorkScoreItem := &UserWorkInfoLocalScoreInfo{
			UserId:          curUserId,
			UserIdUk:        curUserIdUk, //唯一key
			Blogin:          BLogin,
			UserInfo:        userInfoLocal,
			AuthorInfoLocal: authorInfo,
			WorkInfoLocal:   workinfo,
			UserReaded:      isReaded, //
		}

		// 3.7 作者非vip男性用户,最多只给曝光x
		//if authorInfo.MemberType == 0 && authorInfo.UserInfoDbModel.GetGender() == int32(pbconst.Sex_male) {
		//	if workinfo.WorkInfoDbModel.GetVisitorCount() > 299 {
		//		logHelpList = append(logHelpList, fmt.Sprintf("%v,%v", workIdStr, "male_author_novip_limit"))
		//		continue
		//	}
		//}

		authorLevel := authorInfo.PsecretUserExtInfo.GetUlevel()

		// 3.1 对方在我的黑名单
		if BLogin == true && p.DataCache.CheckUserBlackListMgDBLD(ctx, curUserId, authorInfo.UserInfoDbModel.GetUserId()) {
			logHelpList = append(logHelpList, fmt.Sprintf("my_userinblacklist,%v", workIdStr))
			continue
		}

		// 3.2 我在对方的黑名单
		if BLogin == true && p.DataCache.CheckUserBlackListMgDBLD(ctx, authorInfo.UserInfoDbModel.GetUserId(), curUserId) {
			logHelpList = append(logHelpList, fmt.Sprintf("his_userinblacklist,%v", workIdStr))
			continue
		}

		// step 3.3 检查作者是否在白名单和是否在小黑屋。 只有唠唠作品才检查。
		if !p.checkBlackHouse(ctx, userWorkScoreItem) &&
			workinfo.WorkInfoDbModel.GetSpecial() == int32(pbconst.WorkSpecialEnum_work_special_type_laolao) {
			// 作者在黑名单。
			logger.Infof(ctx, "author in black house. authorid=%v, permision=%v",
				authorInfo.UserInfoDbModel.GetUserId(), authorInfo.UserPermission)
			logHelpList = append(logHelpList, fmt.Sprintf("#authorinblackhouse,%v", workIdStr))
			rdsRemoveIds = append(rdsRemoveIds, workIdStr)
			continue
		}

		// 3.4 互关的不分发。
		//if BLogin == true {
		//	mutual := p.DataCache.GetUserFollowMgDBLd(ctx, curUserId, authorInfo.UserInfoDbModel.GetUserId())
		//	if mutual == int32(pbconst.MutualEnum_mutual_yes) {
		//		logHelpList = append(logHelpList, fmt.Sprintf("#mutual,%v", workIdStr))
		//		continue
		//	}
		//}

		// 3.6 已回复的不分发。 //普通消息，模块类型为0.   todo 这个比较消耗db性能，未来考虑根据私聊回复来做。
		//if BLogin == true {
		//	uniqId := genUniqueId(curUserId, authorInfo.UserInfoDbModel.GetUserId(), workId, 0)
		//	record := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqId, authorInfo.UserInfoDbModel.GetUserId())
		//	//logger.Infof(ctx, "====uniqId=%v, record=%+v", uniqId, record)
		//	if record != nil && record.GetInteractTimes() > 0 {
		//		//logger.Infof(ctx, "handleBatch: user has reply the msg. work_id=%v", workId)
		//		logHelpList = append(logHelpList, fmt.Sprintf(",#userhasreplyed %v", workIdStr))
		//		continue
		//	}
		//}

		// step 5 分层检查。  可以考虑不做分层检查。 20230321 注释，不做分层检查
		//if !p.checkIdentity(ctx, userWorkScoreItem) {
		//	//分层检查不通过，当前用户不合适
		//	logger.Infof(ctx, "handleBatch:addto_curUserBanWorkids:checkIdentity not pass. work_id=%v", workId)
		//	continue
		//}

		if isReaded == true {
			if authorLevel > 1 { // 兜底逻辑 已读的动态也记录下来
				logHelpList = append(logHelpList, fmt.Sprintf("#back_readed,%v", workIdStr))
				backupReadedWorks = append(backupReadedWorks, userWorkScoreItem)
			}
			continue
		}

		//优质内容/游客模式不打分直接返回
		if flagHigh || flagHighPlus || !BLogin {
			highScoreWorks = append(highScoreWorks, userWorkScoreItem)
		} else {
			// 曝光限制。vip+用户等级 组合限制用户曝光量大小。
			visitorCountLimit := p.getVisitorCountLimit(ctx, userWorkScoreItem)
			if authorLevel <= 3 && workinfo.WorkInfoDbModel.GetVisitorCount() > visitorCountLimit {
				if authorLevel > 1 {
					logHelpList = append(logHelpList, fmt.Sprintf("#back_unreaded,%v", workIdStr))
					backupUnReadedWorks = append(backupUnReadedWorks, userWorkScoreItem)
				}
				logHelpList = append(logHelpList, fmt.Sprintf("#visitorlimint %v,%v_%v_lv_%v", workIdStr, "union_visit_limit", visitorCountLimit, authorLevel))
				continue
			}

			// step 6 打分。 score 异性，同城，author为vip, 这是最后一步了
			coor := p.DataCache.GetUserCoordinateV2(ctx, curUserId, header)
			curWorkForUserScore, bHighScore := userWorkScoreItem.Score(ctx, coor)
			switch bHighScore {
			case int32(pbconst.UserWorkScoreLevelEnum_level_2_uwsl):
				highScoreWorks = append(highScoreWorks, userWorkScoreItem)
			case int32(pbconst.UserWorkScoreLevelEnum_level_1_uwsl):
				normalScoreWorks = append(normalScoreWorks, userWorkScoreItem)
			default:
			}

			logHelpStr := fmt.Sprintf(",#score %v,%v,%v", workId, curWorkForUserScore, bHighScore)
			logHelpList = append(logHelpList, logHelpStr)
			//logger.Infof(ctx, "handleBatch:add to returnArr. b_high_score=%v. work_id=%v, curScore=%v",
			//	bHighScore, workId, curWorkForUserScore)
		}
	}

	// 日志打印，看官方号的额外曝光量
	if BLogin {
		for _, highScore := range highScoreWorks {
			workId := highScore.WorkInfoLocal.WorkInfoDbModel.GetId()
			if ts, exist := officialWorkDict[fmt.Sprintf("%v", workId)]; exist {
				logger.Infof(ctx, "official extral deliver, workId=%v, ts=%v", workId, utils.GenTimeFromTsMs(ts))
			}
		}
	}

	return highScoreWorks, normalScoreWorks, backupUnReadedWorks, backupReadedWorks, nil
}

func (p *ContentMng) GetShare(ctx context.Context,
	header *pbapi.HttpHeaderInfo,
	req *pbapi.PersonalBottleWorksShareReq) (UserWorkScoreList, error) {

	// userId for debug
	var (
		err       error
		userId    int64 = 0
		userInfo  *data_cache.UserInfoLocal
		curTimeMs = utils.GetCurTsMs()
	)

	if config.ServerConfig.Env != "prod" && header.Debuguserid > 0 {
		userId = header.Debuguserid
	} else if header.Token == "" {
		//未登录
		userInfo = &data_cache.UserInfoLocal{}
	} else {
		if userId, err = p.DataCache.GetUserIdByToken(ctx, header.Token); err != nil {
			return nil, err
		}
	}

	// userInfo
	if userId > 0 {
		userInfo, err = p.DataCache.GetUserInfoLocal(ctx, header, userId, false)
		if err != nil {
			return nil, err
		}
		if userInfo == nil {
			return nil, fmt.Errorf("TsWorkPool, user not find in db")
		}

		if userInfo.PsecretUserExtInfo == nil {
			userInfo.PsecretUserExtInfo, err = p.DataCache.GetImpl().UserInfoExtMgModel.GetAndCreate(ctx, userId)
			if err != nil {
				logger.Error(ctx, "TsWorkPool, get share get and create user extInfo failed, ", err)
				return nil, err
			}
		}
	}

	var (
		page, size             = int64(0), int64(100)
		limit                  = int(req.GetSize())
		flagHigh               = false //优质内容池标识
		flagHighPlus           = false //高优质内容池标识
		resultWorkInfoArr      = make(UserWorkScoreList, 0)
		normalWorksArr         = make(UserWorkScoreList, 0)
		backupUnreadedWorksArr = make(UserWorkScoreList, 0)
		backupReadedWorksArr   = make(UserWorkScoreList, 0)
	)

	//高优质内容额外流量
	r := rand.Intn(100)
	if r <= config.ServerConfig.ContentConfig.HighPlusContentRatio {
		logger.Infof(ctx, "TsWorkPool Premium content plus additional traffic Or Guest")
		flagHighPlus = true
	}

	//游客模式/额外流量 => 优质内容
	if userId == 0 || r <= config.ServerConfig.ContentConfig.HighContentFlowRatio {
		logger.Infof(ctx, "TsWorkPool Premium content additional traffic Or Guest")
		flagHigh = true
	}

	for {
		workIdTsDict := map[string]int64{} //k workId, v score，动态发布时间戳
		LatestTsMs := int64(0)             //最后毫秒时间戳
		maxDispatchTime := int64(0)        //最大分发时间

		if flagHighPlus {
			//《高》优质内容池
			maxDispatchTime = cm_const.DispatchHighContentMaxPastTimeS
			workIdTsDict, LatestTsMs, err = p.DataCache.RangeHighPlusTsWorkPoolRedis(ctx, page*size, (page+1)*size)
			if err != nil {
				return nil, err
			}
		} else if flagHigh {
			//优质内容池
			maxDispatchTime = cm_const.DispatchHighContentMaxPastTimeS
			workIdTsDict, LatestTsMs, err = p.DataCache.RangeHighTsWorkPoolRedis(ctx, page*size, (page+1)*size)
			if err != nil {
				return nil, err
			}
		} else {
			// 从分发池批量捞
			maxDispatchTime = cm_const.DispatchMaxPastTimeS
			workIdTsDict, LatestTsMs, err = p.DataCache.RangeTsWorkPoolRedis(ctx, page*size, (page+1)*size)
			if err != nil {
				return nil, err
			}
		}
		page = page + 1

		var bufTmTs int64 = 1 * 60 * 1000
		logger.Infof(ctx, "len(workIdTsDict)", len(workIdTsDict), "utils.GetCurTsMs()-LatestTsMs-bufTmTs", utils.GetCurTsMs()-LatestTsMs-bufTmTs)
		if len(workIdTsDict) == 0 || utils.GetCurTsMs()-LatestTsMs-bufTmTs > maxDispatchTime*1000 {
			if flagHighPlus {
				if len(resultWorkInfoArr) > 0 {
					break
				} else {
					flagHighPlus = false
					page = 0
					logger.Infof(ctx, "TsWorkPool, 从高优分发池切换到优质分发池/普通分发池=%v", userId)
					continue
				}
			} else if flagHigh {
				if len(resultWorkInfoArr) > 0 {
					break
				} else {
					flagHigh = false
					page = 0
					logger.Infof(ctx, "TsWorkPool, 从高优分发池切换到普通分发池=%v", userId)
					continue
				}
			} else {
				logger.Infof(ctx, "TsWorkPool, over time limit. userId=%v， LatestTsMs=%v", userId, LatestTsMs)
				break
			}
		}

		// 按批次处理 获取高分内容、普通内容
		_highScoreWorks, _normalWorks, _backupUnReadedWorks, _backupReadedWorks, err := p.handleBatch(ctx, header, workIdTsDict, userInfo, limit-len(resultWorkInfoArr), flagHigh, flagHighPlus)
		logger.Infof(ctx, "_highScoreWorks:%v, _normalWorks:%v , _backupUnReadedWorks:%v, _backupReadedWorks:%v", _highScoreWorks, _normalWorks, _backupUnReadedWorks, _backupReadedWorks)
		if err != nil {
			logger.Errorf(ctx, "share:GetUserIdByToken error %v", err)
			return nil, err
		}

		//fmt.Println("_highScoreWorks", _highScoreWorks)

		// 高分内容累加到总list
		resultWorkInfoArr = append(resultWorkInfoArr, _highScoreWorks...)
		if len(resultWorkInfoArr) >= limit {
			// 筛选出足够数据了，弹出
			resultWorkInfoArr = resultWorkInfoArr[0:limit] //只取用前面的limit个。
			break
		}

		if !flagHigh && !flagHighPlus {
			// 记录下 normalWorks 和 backupWorks
			if len(normalWorksArr) < limit && len(_normalWorks) > 0 {
				normalWorksArr = append(normalWorksArr, _normalWorks...)
			}

			if len(backupUnreadedWorksArr) < limit && len(_backupUnReadedWorks) > 0 {
				backupUnreadedWorksArr = append(backupUnreadedWorksArr, _backupUnReadedWorks...)
			}

			if len(backupReadedWorksArr) < limit && len(_backupReadedWorks) > 0 {
				backupReadedWorksArr = append(backupReadedWorksArr, _backupReadedWorks...)
			}
		}

		if page > 1 {
			//第一轮还没选到。
			logger.Infof(ctx, "TsWorkPool, page=%v, len(resultWorkInfoArr)=%v", page, len(resultWorkInfoArr))
		}
	}

	logHelpArr := make([]string, 0)

	// 补偿1 普通分内容(未读，曝光未满)
	if len(resultWorkInfoArr) == 0 && len(normalWorksArr) > limit {
		resultWorkInfoArr = normalWorksArr[0:limit]
		for _, item := range resultWorkInfoArr {
			logHelpArr = append(logHelpArr, fmt.Sprintf("normalwork_%v",
				item.WorkInfoLocal.WorkInfoDbModel.GetId()))
		}
	}

	// 补偿2 兜底内容(未读但曝光已满的动态, 作者等级大于1) backupUnreaded
	if len(resultWorkInfoArr) == 0 && len(backupUnreadedWorksArr) > limit {
		resultWorkInfoArr = backupUnreadedWorksArr[0:limit]
		for _, item := range resultWorkInfoArr {
			logHelpArr = append(logHelpArr, fmt.Sprintf("backup_unreaded_%v_readed_%v",
				item.WorkInfoLocal.WorkInfoDbModel.GetId(), item.UserReaded))
		}
	}

	// 补偿3 兜底内容(已读的动态, 作者等级大于1) backupReaded
	if len(resultWorkInfoArr) == 0 && len(backupReadedWorksArr) > limit {
		resultWorkInfoArr = backupReadedWorksArr[0:limit]
		for _, item := range resultWorkInfoArr {
			logHelpArr = append(logHelpArr, fmt.Sprintf("backup_readed_%v_readed_%v",
				item.WorkInfoLocal.WorkInfoDbModel.GetId(), item.UserReaded))
		}
	}

	//游戏卡片
	if header.GetVersioncode() >= version.GameCardVersion {
		if cards := config.GetGameCards(); len(cards) > 0 {
			var card *config.GameCard
			for range cards {
				card = cards[rand.Intn(len(cards))]
				if game, err := p.DataCache.GetImpl().SecretGameMgModel.GetByGameId(ctx, card.GameId); err == nil && game.DebugMode == 0 {
					ts := p.DataCache.GetImpl().GetUserWorkReadTsRds(ctx, userId, card.GameCardWorkId)
					if utils.GetCurTsMs() > ts {
						resultWorkInfoArr = p.addOfficialWorkId(ctx, header, userId, userInfo, resultWorkInfoArr, card.GameCardWorkId)
						_ = p.DataCache.GetImpl().SetUserWorkReadTsRds(ctx, userId, card.GameCardWorkId)
					}
					break
				}
			}
		}
	}

	// 设置 redis 已读. 用户维度
	workIds := make([]int64, 0)
	workLogData := make([]string, 0)
	for _, rItem := range resultWorkInfoArr {
		workId := rItem.WorkInfoLocal.WorkInfoDbModel.GetId()
		//设置到已读池
		p.DataCache.SetUserReadHistoryPoolR(ctx, strconv.FormatInt(workId, 10), rItem.UserIdUk)
		workIds = append(workIds, workId)
		workLogData = append(workLogData, fmt.Sprintf("%v_%v_%v", workId, rItem.WorkInfoLocal.WorkInfoDbModel.GetSpecial(), rItem.CalcScore))
	}

	// 更新曝光量
	p.DataCache.SetUserVisitorCountRD(ctx, workIds)

	// 读取用户是否已点赞信息
	p.FillWorkInfo(ctx, userId, workIds, resultWorkInfoArr)
	p.PullRemindInfo(ctx, userId, workIds, resultWorkInfoArr)
	timeCostMs := utils.GetCurTsMs() - curTimeMs
	logger.Infof(ctx, "TsWorkPool, get share over. flagHigh %v, timeCostMs=%v, userId=%v, workidsInfo=%v , page=%v, logHelpArr=%v",
		flagHigh, timeCostMs, userId, workLogData, page, logHelpArr)

	for k, _ := range resultWorkInfoArr {
		p.checkLoginUserFollowToUser(ctx, resultWorkInfoArr[k])
	}
	return resultWorkInfoArr, nil
}

func (p *ContentMng) checkLoginUserFollowToUser(ctx context.Context, item *UserWorkInfoLocalScoreInfo) {
	if item == nil {
		return
	}
	if item.AuthorInfoLocal == nil || item.UserInfo == nil {
		return
	}

	data, err := p.DataCache.GetImpl().SecretUserFollowMgModel.GetByUserId(ctx, item.UserInfo.UserInfoDbModel.GetUserId(), item.AuthorInfoLocal.UserInfoDbModel.GetUserId())
	if err == nil && data != nil {
		item.Followed = 1
	} else {
		item.Followed = 0
	}
}

func (p *ContentMng) PullRemindInfo(ctx context.Context, userId int64, workIds []int64, resultWorks UserWorkScoreList) {
	if len(workIds) <= 0 || len(resultWorks) <= 0 {
		return
	}
	// at组
	for i := 0; i < len(resultWorks); i++ {
		if resultWorks[i] == nil {
			continue
		}
		workID := resultWorks[i].WorkInfoLocal.WorkInfoDbModel.GetId()
		remindGroup, err := p.DataCache.GetImpl().AtDetailMgModel.ListWorkAtGroup(ctx, workID)
		if err != nil {
			logger.Errorf(ctx, "ListWorkAtGroup fail, continue, err: %v", err)
			continue
		} else {
			if len(remindGroup) > 0 {
				resultWorks[i].RemindGroup = remindGroup
			}
		}
	}

	// at用户
	for index, _ := range resultWorks {
		if resultWorks[index] == nil {
			continue
		}
		eqConds := map[string]interface{}{
			"workId":     resultWorks[index].WorkInfoLocal.WorkInfoDbModel.GetId(),
			"remindType": const_busi.WorkRemindType,
		}
		retData, err := p.DataCache.GetImpl().UserRemindDetail.GetRemindDetailByConds(ctx, eqConds,
			nil, nil, nil, 0)
		if err != nil || len(retData) <= 0 {
			logger.Infof(ctx, "not find remind user info")
			continue
		}
		for remindIndex, _ := range retData {
			if retData[remindIndex] == nil {
				continue
			}
			//
			resultWorks[index].RemindInfo = append(resultWorks[index].RemindInfo, &pbapi.RemindUserNode{
				UserId: retData[remindIndex].RemindUserId,
				OffSet: retData[remindIndex].RemindOffSet,
				Size:   retData[remindIndex].RemindSize,
			})
		}
	}
}

func (p *ContentMng) getWorkLocalScoreInfo(ctx context.Context, header *pbapi.HttpHeaderInfo, userId int64,
	userInfo *data_cache.UserInfoLocal, systemWorkId int64) *UserWorkInfoLocalScoreInfo {
	workInfo, err := p.DataCache.GetWorkInfoLocal(ctx, systemWorkId, false)
	if err != nil || workInfo == nil {
		return nil
	}
	author, err := p.DataCache.GetUserInfoLocal(ctx, header, workInfo.WorkInfoDbModel.GetUserId(), false)
	result := &UserWorkInfoLocalScoreInfo{
		UserId:          userId,
		UserIdUk:        "",
		Blogin:          true,
		UserInfo:        userInfo,
		WorkInfoLocal:   workInfo,
		AuthorInfoLocal: author,
		Liked:           false,
		CalcScore:       0,
		UserReaded:      false,
		SignStarInfo:    nil,
	}
	if workInfo.WorkInfoDbModel.GetSpecial() == int32(pbconst.WorkSpecialEnum_work_special_type_xingzuo) {
		signStarInfo, err := p.getStarSignInfoBase(ctx, userId)
		if err != nil {
			logger.Error(ctx, "get_share, GetStarSignInfo failed", err)
		}
		result.SignStarInfo = signStarInfo
	}
	return result
}

func (p *ContentMng) AddSystemWorkId(ctx context.Context, header *pbapi.HttpHeaderInfo, userId int64,
	userInfo *data_cache.UserInfoLocal, resultWorkInfoArr []*UserWorkInfoLocalScoreInfo, sysWorkId int64) []*UserWorkInfoLocalScoreInfo {
	//logger.Infof(ctx, "func in AddXingZuoWork, resultWorkInfoArr=%v", utils.StructToJsonString(resultWorkInfoArr))
	if len(resultWorkInfoArr) == 0 {
		return resultWorkInfoArr
	}

	logger.Infof(ctx, "AddSystemWorkId,header=%v", header)
	if !utils.CheckAppVer(header.Apptype, header.Versioncode, sysWorkId) {
		return resultWorkInfoArr
	}

	bReaded := p.DataCache.GetUserSystemWorkReadFlagRds(ctx, userId, sysWorkId)
	logger.Infof(ctx, "GetUserSystemWorkReadFlagRds ret=%v", bReaded)
	if bReaded == true {
		return resultWorkInfoArr
	}

	xingZuocfgTimes := 5 // 配置文件，目前设置为5
	curTimes := 0
	curTimesInt64, err := p.DataCache.GetUserDayWorkCount(ctx, userId)
	if err != nil {
		logger.Error(ctx, "AddXingZuoWork GetUserDayWorkCount failed", err)
	}
	curTimes = int(curTimesInt64)
	// 当前次数比配置次数少，但是加上本次后，>=配置数字
	if curTimes+len(resultWorkInfoArr) >= xingZuocfgTimes && curTimes < xingZuocfgTimes {
		// 在 resultWorkInfoArr[cfgTimes-curTimes]处插入1个元素。
		xingZuoWork := p.getWorkLocalScoreInfo(ctx, header, userId, userInfo, cm_const.SystemWorkIdXingzuo)
		resultWorkInfoArr = append(resultWorkInfoArr, xingZuoWork) //先把原来的切片长度+1
		index := xingZuocfgTimes - curTimes                        //要把新元素插入到第index个位置
		copy(resultWorkInfoArr[index+1:], resultWorkInfoArr[index:])
		resultWorkInfoArr[index] = xingZuoWork //新元素
		//resultWorkInfoArr = resultWorkInfoArr[0 : len(resultWorkInfoArr)-1]
		p.DataCache.SetUserSystemWorkReadFlagRds(ctx, userId, sysWorkId) // 设置今日已分发
		logger.Infof(ctx, "AddXingZuoWork suc, userId=%v", userId)
	}
	if curTimesInt64 < 100 {
		p.DataCache.SetUserDayWorkCount(ctx, userId, int64(len(resultWorkInfoArr)))
	}

	logger.Infof(ctx, "func out AddXingZuoWork, resultWorkInfoArr.ids=%v")
	return resultWorkInfoArr
}

// 支持猫爪官方运营帖子。
func (p *ContentMng) addOfficialWorkId(ctx context.Context, header *pbapi.HttpHeaderInfo, userId int64,
	userInfo *data_cache.UserInfoLocal, resultWorkInfoArr []*UserWorkInfoLocalScoreInfo, workid int64) []*UserWorkInfoLocalScoreInfo {
	logger.Infof(ctx, "enter addOfficialWorkId,userid=%v", userId)
	if len(resultWorkInfoArr) == 0 {
		return resultWorkInfoArr
	}
	destWorkInfo := p.getWorkLocalScoreInfo(ctx, header, userId, userInfo, workid)
	//追加队尾
	resultWorkInfoArr = append(resultWorkInfoArr, destWorkInfo)

	//插到队首
	//resp := make([]*UserWorkInfoLocalScoreInfo, 0)
	//resp = append(resp, destWorkInfo)
	//resp = append(resp, resultWorkInfoArr...)

	logger.Infof(ctx, "addOfficialWorkId over,len=%v", len(resultWorkInfoArr))
	return resultWorkInfoArr
}

// 填充work相关信息
func (p *ContentMng) FillWorkInfo(ctx context.Context, userId int64,
	workIds []int64, resultWorkInfoArr UserWorkScoreList) error {
	if userId == 0 || len(workIds) == 0 {
		return nil
	}
	// 查询当前用户是否给改作品已点赞。  直接查询mgdb
	userWorkLikeDict := p.DataCache.GetUserWorkLikeMgDB(ctx, userId, workIds)
	for _, item := range resultWorkInfoArr {
		userWorklike := userWorkLikeDict[item.WorkInfoLocal.WorkInfoDbModel.GetId()]
		if userWorklike != nil {
			logger.Infof(ctx, "====userWorkLikeDict, set Liked=true. ", len(userWorkLikeDict))
			item.Liked = true
		}
	}
	return nil
}

func (p *ContentMng) checkIdentity(ctx context.Context, userWorkMisc *UserWorkInfoLocalScoreInfo) bool {
	if userWorkMisc.UserInfo == nil {
		//尚未登录，返回成功
		return true
	}

	var viewIdentity int32 = 0
	var authorIdentity int32 = 0
	if userWorkMisc.UserInfo.UserCircleWorksSwitchDbModel != nil {
		viewIdentity = userWorkMisc.UserInfo.UserCircleWorksSwitchDbModel.GetIdentity()
	}
	if userWorkMisc.AuthorInfoLocal.UserCircleWorksSwitchDbModel != nil {
		authorIdentity = userWorkMisc.AuthorInfoLocal.UserCircleWorksSwitchDbModel.GetIdentity()
	}

	viewUserPermission := userWorkMisc.UserInfo.UserPermission
	authorUserPermission := userWorkMisc.AuthorInfoLocal.UserPermission

	// viewer 不受分层限制
	if viewUserPermission > 0 && viewUserPermission&data_cache.UserPermissionConst.IdentityViewUnlimited > 0 {
		//命中 IdentityViewUnlimited
		return true
	}

	// author 不受分层限制
	if authorUserPermission > 0 && authorUserPermission&data_cache.UserPermissionConst.IdentityViewUnlimited > 0 {
		//命中 IdentityViewUnlimited
		return true
	}

	//都是未成年，return true
	if viewIdentity == cm_const.UserIdentityMidSchool && authorIdentity == cm_const.UserIdentityMidSchool {
		return true
	}

	// 都是成年
	if viewIdentity > cm_const.UserIdentityMidSchool && authorIdentity > cm_const.UserIdentityMidSchool {
		return true
	}
	return false
}

// 检查是否在黑名单 通过:true  不通过:false
func (p *ContentMng) checkBlackHouse(ctx context.Context, userWorkMisc *UserWorkInfoLocalScoreInfo) bool {
	authorInfo := userWorkMisc.AuthorInfoLocal
	if authorInfo == nil {
		// 作者信息不存在，前面已经处理过了。 这里不处理，也不拦截。
		return true
	}

	//logger.Infof(ctx, "authorInfo=%v", utils.StructToJsonString(authorInfo))
	authorUserPermission := userWorkMisc.AuthorInfoLocal.UserPermission
	if authorUserPermission > 0 && authorUserPermission&data_cache.UserPermissionConst.ArrestUnlimited > 0 {
		//在抓捕白名单中，直接不拦截。
		return true
	}
	if authorInfo.IsInBlackHouse {
		return false
	}
	return true
}
