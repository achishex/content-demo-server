package query_rds

import (
	"context"
	"github.com/go-redis/redis/v8"
	"testing"
)

type name struct {
	Max0       int32 `redis:"1-max"`
	SingleMax0 int32 `redis:"5-single-max"`
}

func TestRedis(t *testing.T) {
	rdb := redis.NewClient(&redis.Options{
		Addr:     "119.29.185.233:6379", // Redis服务器地址和端口号
		Password: "1qaz2wsx",            // 如果有密码，请在此处设置密码
		DB:       0,                     // 使用默认数据库
	})

	ctx := context.Background()

	str := rdb.HGetAll(ctx, "platform:test:config:times:max_comment_count").Val()
	t.Log(str)

	m := name{}
	err := rdb.HGetAll(ctx, "platform:test:config:times:max_comment_count").Scan(&m)
	if err != nil {
		t.Fatal(err)
	}

	t.Log(m)

}
