package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

var _ ZooGameUserInfoModel = (*customZooGameUserInfoModel)(nil)

type (
	// ZooGameUserInfoModel is an interface to be customized, add more methods here,
	// and implement the added methods in customZooGameUserInfoModel.
	ZooGameUserInfoModel interface {
		zooGameUserInfoModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]ZooGameUserInfo, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*ZooGameUserInfo, error)
		InsertMany(ctx context.Context, data []*ZooGameUserInfo, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error)
		Upsert(ctx context.Context, filter, updateData, insertData any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error)
	}

	customZooGameUserInfoModel struct {
		*defaultZooGameUserInfoModel
	}
)

// NewZooGameUserInfoModel returns a model for the mongo.
func NewZooGameUserInfoModel(cfg MonConfig, opts ...mon.Option) ZooGameUserInfoModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), collectionNameZooGameUserInfo, opts...)
	return &customZooGameUserInfoModel{
		defaultZooGameUserInfoModel: newDefaultZooGameUserInfoModel(conn),
	}
}

func (m *customZooGameUserInfoModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	} else {
		flagType = "default"
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customZooGameUserInfoModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customZooGameUserInfoModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]ZooGameUserInfo, error) {
	result := make([]ZooGameUserInfo, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customZooGameUserInfoModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*ZooGameUserInfo, error) {
	var data ZooGameUserInfo
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customZooGameUserInfoModel) InsertMany(ctx context.Context, data []*ZooGameUserInfo, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error) {
	now := time.Now().UnixMilli()
	insertData := make([]any, 0)
	for _, datum := range data {
		datum.CreateTime = now
		datum.UpdateTime = now
		insertData = append(insertData, datum)
	}
	return m.conn.InsertMany(ctx, insertData, opts...)
}

func (m *customZooGameUserInfoModel) Upsert(ctx context.Context, filter, updateData, insertData any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error) {
	update := bson.D{
		{"$set", updateData},
		{"$setOnInsert", insertData},
	}

	opt := options.Update().SetUpsert(true)
	if len(opts) == 0 {
		return m.conn.UpdateOne(ctx, filter, update, opt)
	} else {
		opts = append([]*options.UpdateOptions{opt}, opts...)
		return m.conn.UpdateOne(ctx, filter, update, opts...)
	}
}

func (m *customZooGameUserInfoModel) Insert(ctx context.Context, data *ZooGameUserInfo) (*mongo.InsertOneResult, error) {
	//data.ID = primitive.NewObjectID()
	//data.ID = snow_flake.GetSnowflakeID()
	return m.defaultZooGameUserInfoModel.Insert(ctx, data)
}
