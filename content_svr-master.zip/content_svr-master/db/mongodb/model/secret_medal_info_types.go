package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

const SecretMedalInfoCollectionName = "secretMedalInfo"

type SecretMedalInfo struct {
	ID primitive.ObjectID `bson:"_id" json:"id"`

	MedalId   int64  `json:"medalId,omitempty"` // 勋章id 1:新芽
	MedalName string `json:"medalName,omitempty"`
	Icon      string `json:"icon,omitempty"`
	Expire    int64  `json:"expire,omitempty"`    // ms级别
	Timestamp int64  `json:"timestamp,omitempty"` // ms级别
	SmallIcon string `json:"small_icon" form:"small_icon"`
}
