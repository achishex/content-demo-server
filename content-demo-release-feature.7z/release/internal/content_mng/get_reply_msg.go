package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/trans"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
)

func (p *ContentMng) GetReplyMsg(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.GetReplyMsgReq) ([]*pbapi.GetReplyMsgSimple, error) {
	var curUserId int64 = 0
	if config.ServerConfig.Env != "prod" && header.Debuguserid > 0 {
		curUserId = header.Debuguserid
	} else {
		curUserIdTmp, err := p.DataCache.GetUserIdByToken(ctx, header.Token)
		if err != nil {
			logger.Errorf(ctx, "get user id by token failed,err=%v", err.Error())
			return nil, err
		}
		curUserId = curUserIdTmp
	}

	resp := make([]*pbapi.GetReplyMsgSimple, 0)
	replyMsgItems := p.DataCache.ListUserReplyMsgDB(ctx, curUserId, req.GetLastId(), req.GetLimit())
	if len(replyMsgItems) == 0 {
		return resp, nil
	}

	// 包装信息
	var worksIds []int64
	for _, replyMsgItem := range replyMsgItems {
		if len(resp) >= int(req.GetLimit()) {
			break
		}
		oneResp := &pbapi.GetReplyMsgSimple{}
		// PersonalTalkMessageRecord 获取私聊信息
		ptMsgItem := p.DataCache.GetPersonTalkMsgRecordMgDB(ctx, replyMsgItem.GetMessageId())
		if ptMsgItem == nil {
			logger.Errorf(ctx, "GetReplyMsg,get ptTalkMsgRecord failed. curUserId=%v, msgId=%v",
				curUserId, replyMsgItem.GetMessageId())
			continue
		}

		// 获取workid
		workId := ptMsgItem.GetWorkId()
		logger.Infof(ctx, "msg replyMsgItem=%+v,ptMsgItem=%v", replyMsgItem, ptMsgItem)

		// 获取from_user_id信息
		fromUserLocalInfo, err := p.DataCache.GetUserInfoLocal(ctx, header, replyMsgItem.GetFromUserId(), false)
		if err != nil {
			logger.Errorf(ctx, "GetReplyMsg,get GetUserInfoLocal failed.curUserId=%v, fromUserId=%v",
				curUserId, replyMsgItem.GetFromUserId())
			continue
		}
		if fromUserLocalInfo == nil {
			logger.Errorf(ctx, "GetReplyMsg,get GetUserInfoLocal is nil. curUserId=%v, fromUserId=%v",
				curUserId, replyMsgItem.GetFromUserId())
			continue
		}

		//组装消息
		oneResp.Id = replyMsgItem.GetMessageId()
		oneResp.WorkId = workId
		oneResp.CreateTime = ptMsgItem.GetCreateTime()
		oneResp.ToUserId = curUserId
		oneResp.Type = replyMsgItem.GetType()
		oneResp.Content = ptMsgItem.GetContent()
		oneResp.FromUserId = ptMsgItem.GetFromUserId()
		oneResp.FromUser = trans.TransUserInfoLocalToUserSimple(fromUserLocalInfo)
		//

		if workId <= 0 || workId == 100 {
			// 互关好友的私聊消息  命中。
			workSimple := &pbapi.PersonalBottleWorksSimple{}
			workSimple.Id = workId
			workSimple.PushType = 2    //
			oneResp.Works = workSimple //work
		} else {
			// 获取work信息
			workInfoLocal, err := p.DataCache.GetWorkInfoLocal(ctx, workId, false)
			if err != nil || workInfoLocal == nil {
				logger.Error(ctx, fmt.Sprintf("GetReplyMsg,get GetWorkInfoLocal failed. curUserId=%v, workId=%v",
					curUserId, workId), err)
				continue
			}

			ptMsgTotalItem := p.DataCache.GetPersonTalkMsgTotalWithIdMgDBLd(ctx, replyMsgItem.GetFromUserId(), curUserId, workId)
			if ptMsgTotalItem == nil {
				logger.Errorf(ctx, "GetReplyMsg,get GetPersonTalkMsgTotalMgDBLd failed. fromUserId=%v, curUserId=%v, workId=%v",
					replyMsgItem.GetFromUserId(), curUserId, workId)
				continue
			}

			//设置经纬度信息
			oneResp.FromCoordinate = &pbapi.Coordinate{
				Longitude: ptMsgTotalItem.FromLng,
				Latitude:  ptMsgTotalItem.FromLat,
				Province:  ptMsgTotalItem.FromProvince,
				City:      ptMsgTotalItem.FromCity,
			}
			oneResp.ToCoordinate = &pbapi.Coordinate{
				Longitude: ptMsgTotalItem.ToLng,
				Latitude:  ptMsgTotalItem.ToLat,
				Province:  ptMsgTotalItem.ToProvince,
				City:      ptMsgTotalItem.ToCity,
			}

			// 设置work
			oneResp.Works = trans.TransWorkInfoLocalScoreInfoToWorksSimple(workInfoLocal,
				fromUserLocalInfo, false, nil) // todo liked
			if workInfoLocal.WorkInfoDbModel.GetStatus() != int32(pbconst.BaseTabStatus_valid) {
				oneResp.Works.Deleted = true
			}
			oneResp.Works.EnableComment = proto.Int32(const_busi.WorkCommentStatusDisable)
			//获取每个帖子的评论开关状态
			worksIds = append(worksIds, workId)
		}
		resp = append(resp, oneResp)
	}
	//
	statusRet, err := p.DataCache.GetImpl().WorkCommentStatusDbModel.BulkGetStatus(ctx, worksIds)
	logger.Infof(ctx, "get status for work id: %v, err: %v", worksIds, err)
	if err == nil && statusRet != nil && len(*statusRet) > 0 {
		for index, _ := range resp {
			if resp[index] != nil && resp[index].GetWorkId() > 0 {
				workId := resp[index].GetWorkId()
				if _, ok := (*statusRet)[workId]; ok {
					resp[index].Works.EnableComment = proto.Int32((*statusRet)[workId])
					logger.Infof(ctx, "workId: %v, enablecomment: %v", workId, resp[index].Works.EnableComment)
				}
			}
		}
	}
	if len(resp) > 0 {
		logger.Infof(ctx, "GetReplyMsg suc, req.limit=%v, curUserId=%v, len(resp)=%v", req.GetLimit(), curUserId, len(resp))
	}

	// 添加评论数
	for i := 0; i < len(resp); i++ {
		workInfos, err := p.DataCache.GetWorkInfoToNewCommentCount(ctx, resp[i].GetId())
		if err != nil {
			logger.Error(ctx, "GetWorkInfoToNewCommentCount: ", err)
			continue
		}
		for _, info := range workInfos {
			resp[i].GetWorks().NewCommentCount = info.NewCommentCount
		}
	}

	return resp, nil
}
