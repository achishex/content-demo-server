package cache

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
	"context"
	"errors"
	"go.mongodb.org/mongo-driver/mongo/options"
	"gorm.io/gorm"
)

type SecretUserExtInfo struct {
	model.SecretUserExtInfoModel
	redisManage *query_rds.Manage
}

func NewCacheSecretUserExtInfo(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *SecretUserExtInfo {
	return &SecretUserExtInfo{
		SecretUserExtInfoModel: mongo.SecretUserExtInfo,
		redisManage:            redisManage,
	}
}

func (p *SecretUserExtInfo) UpdateByUserIdCache(ctx context.Context, userId int64, update map[string]any, opts ...*options.UpdateOptions) error {

	filter := map[string]interface{}{
		"_id": userId,
	}

	_, err := p.SecretUserExtInfoModel.UpdateMap(ctx, filter, update, opts...)
	if err != nil {
		return err
	}

	return p.redisManage.UserInfo.SetUserInfo(ctx, userId, update)
}

func (p *SecretUserExtInfo) FindAllByIdsNoCache(ctx context.Context, userIds []int64) ([]model.SecretUserExtInfo, error) {
	result, err := p.SecretUserExtInfoModel.FindAll(ctx, map[string]interface{}{
		"user_ids": userIds,
	})
	switch {
	case errors.Is(err, gorm.ErrRecordNotFound):
		return nil, xerr.DbNotFound
	case err == nil:
		return result, nil
	default:
		return nil, err
	}

}
