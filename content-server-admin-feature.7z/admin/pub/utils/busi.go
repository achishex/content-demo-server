package utils

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"strconv"
)

func CheckAppVer(appType, Versioncode string, sysWorkId int64) bool {
	destVerCheck := cm_const.SysWorkVerCheckDict[sysWorkId]
	if destVerCheck == nil || Versioncode == "" {
		return false
	}
	versioncodeInt, _ := strconv.Atoi(Versioncode)
	if appType == cm_const.AppTypeMobileIos {
		if versioncodeInt >= destVerCheck.IosVer {
			return true
		}
	} else if appType == cm_const.AppTypeMobileAndroid {
		if versioncodeInt >= destVerCheck.AndroidVer {
			return true
		}
	}
	return false
}
