package cache

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/dao/operate"
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
	"context"
	"github.com/go-redis/redis/v8"
	"github.com/zeromicro/go-zero/core/logx"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type MzRobot struct {
	model.MzRobotModel
	redisManage *query_rds.Manage
}

func NewCacheMzRobot(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *MzRobot {
	return &MzRobot{
		MzRobotModel: mongo.MzRobot,
		redisManage:  redisManage,
	}
}

func (p *MzRobot) Subscript() *redis.PubSub {
	return p.redisManage.MzRobot.Subscript()
}

func (p *MzRobot) Create(ctx context.Context, data *model.MzRobot) error {
	opt := &options.FindOneOptions{}
	opt.Sort = bson.D{
		{Key: "number", Value: -1},
	}
	firstMzRobotMng, err := p.MzRobotModel.FindOne(ctx, nil, opt)
	var newNumber int64
	switch err {
	case xerr.DbNotFound:
		break
	case nil:
		newNumber = firstMzRobotMng.Number
	default:
		return err
	}
	data.Number = newNumber + 1
	insert, err := p.MzRobotModel.Insert(ctx, data)
	if err != nil {
		return err
	}
	data.ID = insert.InsertedID.(primitive.ObjectID)

	if err := p.redisManage.MzRobot.SetRdsRules(ctx, data); err != nil {
		return err
	}

	return nil
}

func (p *MzRobot) FindOne(ctx context.Context, id string) (*model.MzRobot, error) {
	robot, err := p.redisManage.MzRobot.GetRdsRules(ctx, id)
	if err != nil {
		robot, err = p.MzRobotModel.FindById(ctx, id)
		if err != nil {
			return nil, err
		}
		_ = p.redisManage.MzRobot.SetRdsRules(ctx, robot)
	}

	return robot, err
}

func (p *MzRobot) Update(ctx context.Context, data *model.MzRobot) error {
	updateResult, err := p.MzRobotModel.UpdateOne(ctx, data)
	if err != nil {
		return err
	}

	if updateResult.ModifiedCount == 0 {
		return xerr.DbDoNothing
	}

	if err := p.redisManage.MzRobot.SetRdsRules(ctx, data); err != nil {
		return err
	}

	return nil
}

func (p *MzRobot) UpdateMap(ctx context.Context, filer, data map[string]interface{}) (*mongo.UpdateResult, error) {
	return p.MzRobotModel.UpdateMap(ctx, filer, data)
}

func (p *MzRobot) UpdateAllRobotByUserId(ctx context.Context, data *model.MzRobot) error {
	filter := map[string]interface{}{
		"user_id": data.UserId,
	}
	list, err := p.MzRobotModel.FindAll(ctx, filter)
	if err != nil {
		return err
	}
	if len(list) > 1 {
		update := map[string]interface{}{
			"name":   data.Name,
			"header": data.Header,
		}
		_, _ = p.MzRobotModel.UpdateMapMany(ctx, filter, update)

	}
	return nil
}

// UpdateStatus 修改状态
func (p *MzRobot) UpdateStatus(ctx context.Context, id string, status bool) error {
	robot, err := p.FindOne(ctx, id)
	if err != nil {
		return err
	}
	robot.Status = status
	return p.Update(ctx, robot)
}

func (p *MzRobot) Delete(ctx context.Context, id string) (int64, error) {
	flag, err := p.MzRobotModel.Delete(ctx, id)
	switch {
	case err != nil:
		return 0, xerr.DbDoNothing
	case flag == 0:
		return 0, nil
	}

	if err := p.redisManage.MzRobot.DelRdsRules(ctx, id); err != nil {
		logx.WithContext(ctx).Error(err)
		return flag, nil
	}

	return flag, nil

}

func (p *MzRobot) CheckArea(ctx context.Context, id primitive.ObjectID, timePartStart, timePartEnd int64, commentIndex int32) (int64, bool, error) {
	number, ok, err := p.MzRobotModel.CheckArea(ctx, id, timePartStart, timePartEnd, commentIndex)
	if err != nil {
		return 0, false, err
	}

	return number, ok, err
}

func (p *MzRobot) FindPage(ctx context.Context, turner operate.PageTurner) ([]model.MzRobot, int64, error) {
	filter, opt := turner.ParseMongo()
	list, err := p.MzRobotModel.FindAll(ctx, filter, opt)
	if err != nil {
		return nil, 0, err
	}

	total, err := p.MzRobotModel.Count(ctx, filter)
	if err != nil {
		return nil, 0, err
	}

	return list, total, nil
}

func (p *MzRobot) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]model.MzRobot, error) {
	robots, err := p.MzRobotModel.FindAll(ctx, filter, opts...)
	for _, robot := range robots {
		_ = p.redisManage.MzRobot.SetRdsRules(ctx, &robot)
	}

	return robots, err
}

func (p *MzRobot) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	return p.MzRobotModel.Count(ctx, filter, opts...)
}
