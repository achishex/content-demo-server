package content_mng

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/busi_comm/trans"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"github.com/gogo/protobuf/proto"
	"time"
)

func GetRemindInfo(ctx context.Context, p *ContentMng, workId int64) ([]*pbapi.RemindUserNode, error) {
	var remindNode []*pbapi.RemindUserNode
	eqConds := map[string]interface{}{
		"workId":     workId,
		"remindType": const_busi.WorkRemindType,
	}
	retData, err := p.DataCache.GetImpl().UserRemindDetail.GetRemindDetailByConds(ctx, eqConds,
		nil, nil, nil, 0)
	if err != nil || len(retData) <= 0 {
		logger.Infof(ctx, "not find remind user info")
		return nil, err
	}
	for remindIndex, _ := range retData {
		if retData[remindIndex] == nil {
			continue
		}
		//
		remindNode = append(remindNode, &pbapi.RemindUserNode{
			UserId: retData[remindIndex].RemindUserId,
			OffSet: retData[remindIndex].RemindOffSet,
			Size:   retData[remindIndex].RemindSize,
		})
	}

	//remindGroup, _ := p.DataCache.GetImpl().AtDetailMgModel.ListWorkAtGroup(ctx, workId)
	return remindNode, nil
}
func buildWorkInfo(ctx context.Context, p *ContentMng, workId int64, userId int64) (*pbapi.PersonalBottleWorksSimple, error) {
	p.DataCache.DelWorkInfoCache(ctx, workId)
	//
	workInfo, err := p.DataCache.GetWorkInfoLocal(ctx, workId, false)
	if err != nil || workInfo == nil {
		return nil, err
	}
	if workInfo.WorkInfoDbModel.GetStatus() != 1 {
		logger.Infof(ctx, "work not valid: %v", workId)
		return nil, nil
	}
	if workInfo.WorkInfoDbModel.GetShowScope() != 1 && workInfo.WorkInfoDbModel.GetUserId() != userId {
		logger.Errorf(ctx, "work not show global, workid: %v", workInfo.WorkInfoDbModel.GetId())
		return nil, errorcode.CommentNotExist
	}

	//
	var signInfo *pbapi.StarSignData
	if workInfo.WorkInfoDbModel.GetSpecial() == int32(pbconst.WorkSpecialEnum_work_special_type_xingzuo) {
		signStarInfo, err := p.getStarSignInfoBase(ctx, workInfo.WorkInfoDbModel.GetUserId())
		if err != nil {
			logger.Error(ctx, "get_share, GetStarSignInfo failed", err)
		}
		signInfo = signStarInfo
	}
	var extInfo *pbapi.ExtInfo = nil
	if signInfo != nil {
		extInfo = &pbapi.ExtInfo{StarSignData: signInfo}
	}
	userInfo, err := p.DataCache.GetUserInfoLocal(ctx, nil, workInfo.WorkInfoDbModel.GetUserId(), false)
	data := trans.TransWorkInfoLocalScoreInfoToWorksSimple(workInfo, userInfo, false, extInfo)

	followRet, err := p.DataCache.GetImpl().SecretUserFollowMgModel.GetByUserId(ctx, userId, userInfo.UserInfoDbModel.GetUserId())
	if err == nil && followRet != nil {
		data.Followed = proto.Bool(true)
	}

	workIds := []int64{workId}
	//get comment enable status
	statusRet, err := p.GetCommentStatusOnWork(ctx, workIds)
	if err != nil || statusRet == nil || len(*statusRet) <= 0 {
		//
	} else {
		if v, exist := (*statusRet)[workId]; exist {
			data.EnableComment = proto.Int32(v)
		}
	}
	//get work comment nums:
	workInfos, err := p.DataCache.GetWorkInfoToNewCommentCount(ctx, workId)
	if err == nil && workInfos != nil && len(workInfos) > 0 {
		if workInfos[0] != nil {
			data.NewCommentCount = workInfos[0].NewCommentCount
		}
	}

	//getRemindInfo := func() {
	//	eqConds := map[string]interface{}{
	//		"workId":     workId,
	//		"remindType": const_busi.WorkRemindType,
	//	}
	//	retData, err := p.DataCache.GetImpl().UserRemindDetail.GetRemindDetailByConds(ctx, eqConds,
	//		nil, nil, nil, 0)
	//	if err != nil || len(retData) <= 0 {
	//		logger.Infof(ctx, "not find remind user info")
	//		return
	//	}
	//	for remindIndex, _ := range retData {
	//		if retData[remindIndex] == nil {
	//			continue
	//		}
	//		//
	//		data.RemindNode = append(data.RemindNode, &pbapi.RemindUserNode{
	//			UserId: retData[remindIndex].RemindUserId,
	//			OffSet: retData[remindIndex].RemindOffSet,
	//			Size:   retData[remindIndex].RemindSize,
	//		})
	//	}
	//}
	//
	//getRemindInfo()
	return data, nil
}

func buildCommentInfo(ctx context.Context, p *ContentMng, commentInfo *pbmgdb.WorksCommentDetailMgDbModel, resType int32) (*pbapi.WorkCommentBrief, error) {
	if commentInfo == nil {
		return nil, errorcode.CommentNotExist
	}
	userInfoData, err := p.GetUserInfo(ctx, commentInfo.GetUserId())
	if err != nil {
		return nil, errorcode.CommentNotExist
	}
	formatTimeStr := "2006-01-02 15:04:05.000"
	createTimeUnixTime, _ := time.ParseInLocation(formatTimeStr, commentInfo.GetCreateTime(), time.Local)

	remindGroup, _ := p.DataCache.GetImpl().AtDetailMgModel.ListCommentAtGroup(ctx, commentInfo.Id)
	var retRemindInfo []*pbapi.RemindUserNode
	remindInfos, err := NewRemindOpsReadHandle(p, commentInfo.WorkId, &commentInfo.Id, const_busi.CommentRemindType).ReadRemind(ctx)
	if resType != int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply) {
		if err != nil || (len(remindInfos) == 0 && len(remindGroup) == 0) {
			logger.Errorf(ctx, "not find remind info for work: %v, comment id: %v", commentInfo.GetWorkId(), commentInfo.Id)
			return nil, errorcode.CommentNotExist
		}

		for remindIndex, _ := range remindInfos {
			if remindInfos[remindIndex] == nil {
				continue
			}
			retRemindInfo = append(retRemindInfo, &pbapi.RemindUserNode{
				UserId: remindInfos[remindIndex].RemindUserId,
				OffSet: remindInfos[remindIndex].RemindOffSet,
				Size:   remindInfos[remindIndex].RemindSize,
			})
		}
	}
	repliedCommentUserInfo := &data_cache.UserInfoLocal{}
	if resType == int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply) {
		var err error
		repliedCommentUserInfo, err = p.GetUserInfo(ctx, commentInfo.GetBeCommentUserId())
		if err != nil {
			logger.Errorf(ctx, "get replied comment user info fail, replied comment userId: %v", commentInfo.GetBeCommentUserId())
		}
	}

	tmpRet := pbapi.WorkCommentBrief{
		Id:                proto.Int64(commentInfo.Id),
		Comment:           commentInfo.Comment,
		FromUserId:        commentInfo.UserId,
		Ip:                commentInfo.Ip,
		CreateTime:        proto.Int64(createTimeUnixTime.UnixMilli()),
		UserInfo:          trans.TransUserInfoLocalToUserSimple(userInfoData),
		RemindNode:        retRemindInfo,
		CommentType:       commentInfo.CommentType,
		BeCommentUserInfo: trans.TransUserInfoLocalToUserSimple(repliedCommentUserInfo),
		RemindGroup:       remindGroup,
	}
	return &tmpRet, nil
}

type IResCheckLogic interface {
	CheckDeleted(ctx context.Context, userId int64) (*pbapi.CheckResStatusRespMsg, error)
	CheckInvisible(ctx context.Context, userId int64) (*pbapi.CheckResStatusRespMsg, error)
}
type commResInfo struct {
	req    *pbapi.CheckResStatusReqMsg
	impl   *ContentMng
	header *pbapi.HttpHeaderInfo
}

// 动态已删除(包括拉黑)， 动态不可见（），评论已删除， 评论不可见。
type WorkResCheck struct {
	commResInfo
	workInfo   *pbapi.PersonalBottleWorksDbModel
	workDetail *pbapi.PersonalBottleWorksSimple
}

func NewWorkResCheck(header *pbapi.HttpHeaderInfo, req *pbapi.CheckResStatusReqMsg, p *ContentMng) IResCheckLogic {
	return &WorkResCheck{
		commResInfo: commResInfo{
			req:    req,
			impl:   p,
			header: header,
		},
		workInfo: nil,
	}
}
func (p *WorkResCheck) CheckDeleted(ctx context.Context, userId int64) (*pbapi.CheckResStatusRespMsg, error) {
	var err error
	if p.workInfo == nil {
		p.workInfo, err = p.impl.DataCache.GetImpl().PersonBottleWorksModel.GetByWorkId(ctx, p.req.GetWorkId())
	}
	if err != nil || p.workInfo == nil || p.workInfo.GetStatus() == 0 {
		logger.Errorf(ctx, "not exist work")
		return nil, errorcode.WorkNotExist
	}
	p.workDetail, err = buildWorkInfo(ctx, p.impl, p.req.GetWorkId(), userId)
	if err != nil || p.workDetail == nil {
		logger.Errorf(ctx, "not get work info, work id: %v", p.req.GetWorkId())
		return nil, errorcode.WorkNotExist
	}
	reminds, _ := GetRemindInfo(ctx, p.impl, p.req.GetWorkId())
	p.workDetail.RemindNode = append(p.workDetail.RemindNode, reminds...)

	return &pbapi.CheckResStatusRespMsg{
		WorkInfo: p.workDetail,
	}, nil
}
func (p *WorkResCheck) CheckInvisible(ctx context.Context, userId int64) (*pbapi.CheckResStatusRespMsg, error) {
	var err error
	if p.workInfo == nil {
		p.workInfo, err = p.impl.DataCache.GetImpl().PersonBottleWorksModel.GetByWorkId(ctx, p.req.GetWorkId())
		if err != nil || p.workInfo == nil {
			logger.Errorf(ctx, "get work info fail, work id: %d, err: %v", p.req.GetWorkId(), err)
			return nil, errorcode.WorkNotExist
		}
		p.workDetail, err = buildWorkInfo(ctx, p.impl, p.req.GetWorkId(), userId)
		if err != nil || p.workDetail == nil {
			logger.Errorf(ctx, "not get work info fail, err: %v", err)
			return nil, errorcode.WorkNotExist
		}
		reminds, _ := GetRemindInfo(ctx, p.impl, p.req.GetWorkId())
		p.workDetail.RemindNode = append(p.workDetail.RemindNode, reminds...)
	}
	//
	if p.workInfo.GetShowScope() != 1 && p.workInfo.GetUserId() != userId { // only work userid can see.
		logger.Errorf(ctx, "can not show, work: %v", p.workInfo.GetId())
		return nil, errorcode.WorkNoInvisible
	}
	//
	return &pbapi.CheckResStatusRespMsg{
		WorkInfo: p.workDetail,
	}, nil
}

func NewCommentResCheck(header *pbapi.HttpHeaderInfo, req *pbapi.CheckResStatusReqMsg, p *ContentMng) IResCheckLogic {
	return &CommentResCheck{
		commResInfo: commResInfo{
			req:    req,
			impl:   p,
			header: header,
		},
	}
}

type CommentResCheck struct {
	commResInfo
	commentInfo   *pbmgdb.WorksCommentDetailMgDbModel
	commentDetail *pbapi.WorkCommentBrief
	//
	workInfo   *pbapi.PersonalBottleWorksDbModel
	workDetail *pbapi.PersonalBottleWorksSimple
}

func (p *CommentResCheck) CheckDeleted(ctx context.Context, userId int64) (*pbapi.CheckResStatusRespMsg, error) {
	eqConds := map[string]interface{}{
		"work_id": p.req.GetWorkId(),
		"_id":     p.req.GetCommentId(),
	}
	if p.commentInfo == nil {
		retDatas, err := p.impl.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentDetails(ctx, eqConds, nil, nil, nil, 1)
		if p.req.GetResType() == int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply) && (err != nil || len(retDatas) <= 0 || retDatas[0] == nil || retDatas[0].GetStatus() != 1) {
			return &pbapi.CheckResStatusRespMsg{}, errorcode.GenBusiErr(errorcode.CommentNotExist, "该回复已删除")
		}
		if err != nil || len(retDatas) <= 0 || retDatas[0] == nil {
			return &pbapi.CheckResStatusRespMsg{}, errorcode.CommentNotExist
		}
		p.commentInfo = retDatas[0]
		//
		p.workDetail, err = buildWorkInfo(ctx, p.impl, p.req.GetWorkId(), userId)
		if err != nil || p.workDetail == nil {
			logger.Errorf(ctx, "not find work info, workid: %v", p.commentInfo.GetWorkId())
			return nil, errorcode.WorkNotExist
		}

		reminds, _ := GetRemindInfo(ctx, p.impl, p.req.GetWorkId())
		p.workDetail.RemindNode = append(p.workDetail.RemindNode, reminds...)

		p.commentDetail, err = buildCommentInfo(ctx, p.impl, p.commentInfo, p.req.GetResType())
		if err != nil || p.commentDetail == nil {
			logger.Errorf(ctx, "not find comment info, workid: %v, commentId: %v", p.commentInfo.GetWorkId(), p.commentInfo.GetId())
			return nil, errorcode.CommentNotExist
		}
	}
	//
	if p.commentInfo.GetStatus() != 1 {
		return nil, errorcode.CommentNotExist
	}
	return &pbapi.CheckResStatusRespMsg{
		WorkInfo:    p.workDetail,
		CommentInfo: p.commentDetail,
	}, nil
}
func (p *CommentResCheck) CheckInvisible(ctx context.Context, userId int64) (*pbapi.CheckResStatusRespMsg, error) {
	return &pbapi.CheckResStatusRespMsg{
		WorkInfo:    p.workDetail,
		CommentInfo: p.commentDetail,
	}, nil
}

func NewResHandle(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.CheckResStatusReqMsg, p *ContentMng, userId int64) IResCheckLogic {
	if req == nil {
		return nil
	}
	if req.GetResType() == const_busi.MutualNoticeMsgType || req.GetResType() == const_busi.MutualWorkMsgType {
		return NewWorkResCheck(header, req, p)
	}
	if req.GetResType() == const_busi.MutualCommentMsgType || req.GetResType() == int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply) {
		return NewCommentResCheck(header, req, p)
	}
	return nil
}
func (p *ContentMng) CheckResStatusImpl(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.CheckResStatusReqMsg, userId int64) (*pbapi.CheckResStatusRespMsg, error) {
	var resHandle IResCheckLogic = NewResHandle(ctx, header, req, p, userId)
	if resHandle == nil {
		return &pbapi.CheckResStatusRespMsg{}, errorcode.GenBusiErr(errorcode.MIDAS_PARAMS_ERROR, "res type not support")
	}
	//
	ret, err := resHandle.CheckDeleted(ctx, userId)
	if err != nil {
		return ret, err
	}
	ret, err = resHandle.CheckInvisible(ctx, userId)
	if err != nil {
		return ret, err
	}

	// fill remind_group
	if ret.WorkInfo != nil && len(ret.WorkInfo.RemindGroup) == 0 {
		if remindGroup, err2 := p.DataCache.GetImpl().AtDetailMgModel.ListWorkAtGroup(ctx, ret.WorkInfo.GetId()); err2 == nil {
			ret.WorkInfo.RemindGroup = remindGroup
		}
	}
	if ret.CommentInfo != nil && len(ret.CommentInfo.RemindGroup) == 0 {
		if remindGroup, err2 := p.DataCache.GetImpl().AtDetailMgModel.ListCommentAtGroup(ctx, ret.CommentInfo.GetId()); err2 == nil {
			ret.CommentInfo.RemindGroup = remindGroup
		}
	}

	return ret, nil
}
