package util

import (
	"strconv"
	"strings"
)

func StringToStringSlice(input string) []string {
	parts := strings.Split(input, ",")
	result := make([]string, 0)
	for _, part := range parts {
		result = append(result, strings.Trim(part, " "))
	}

	return result
}

func StringToInt64Slice(input string) []int64 {
	parts := strings.Split(input, ",")
	result := make([]int64, 0)
	for _, part := range parts {
		val, err := strconv.ParseInt(strings.Trim(part, " "), 10, 64)
		if err != nil {
			continue
		}
		result = append(result, val)
	}
	return result
}
