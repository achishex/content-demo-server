package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/pub/logger"
	"context"
	"fmt"
)

// 检查 目标用户是否被改用户拉黑。  在黑名单返回 true.    todo 待优化，黑名单实时查db效率太低。
func (p *DataCacheMng) CheckUserBlackListMgDBLD(ctx context.Context, userId, targetUserId int64) bool {
	//从内存取
	cacheKey := fmt.Sprintf(cache_const.UserBlackListLcache.KeyFmt, userId, targetUserId)
	//expire := cache_const.UserBlackListLcache.Expire
	//cResp, exist := p.LocalCache.Get(cacheKey)
	//if exist {
	//	resp, ok := cResp.(bool)
	//	if ok {
	//		return resp
	//	}
	//}

	//从mg db取. 检查是否在黑名单中。
	bInBlackList, err := p.UserBlackListMgModel.CheckInBlackList(ctx, userId, targetUserId)
	if err != nil {
		logger.Errorf(ctx, "get CheckUserBlackList failed. userId=%v, cacheKey=%v, err=%v",
			userId, cacheKey, err.Error())
		return false
	}

	// save 到localcache
	//bSuc := p.LocalCache.Set(cacheKey, bInBlackList, go_cache.WithEx(time.Duration(expire)*time.Second))
	//if !bSuc {
	//	logger.Infof(ctx, "save CheckUserBlackList to local cache. userId=%v, , cacheKey=%v,value=%v, bSuc=%v",
	//		userId, cacheKey, bInBlackList, bSuc)
	//}
	return bInBlackList
}
