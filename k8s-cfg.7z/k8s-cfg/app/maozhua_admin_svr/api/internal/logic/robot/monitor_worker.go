package robot

import (
	"content_svr/db/mongodb/model"
	"context"
	"github.com/zeromicro/go-zero/core/logx"
	"time"
)

type worker struct {
	monitor *monitor
	ctx     context.Context
	env     string
	status  robotStatus // 机器人状态
	doFunc  func(params interface{})

	robot *model.MzRobot

	taskWorkIdChan chan interface{} // 接受需要发评论的消息，workId
	Interval       time.Duration    // 沉睡时间
}

func newWorker(robot *model.MzRobot) *worker {
	w := &worker{
		robot:          robot,
		status:         open,
		monitor:        monitorServe,
		Interval:       time.Second,
		ctx:            context.Background(),
		taskWorkIdChan: make(chan interface{}),
	}

	switch robot.Category {
	case commentCategory:
		w.doFunc = w.doComment
	default:
		w.doFunc = func(params interface{}) {
			logx.Error("不存在该机器人类型的方法")
			w.setStatus(remove)
		}
	}
	return w
}

func (w *worker) setStatus(status robotStatus) {
	w.status = status
}

func (w *worker) run() {
	defer func() {
		if err := recover(); err != nil {
			logx.Errorf("worker panic: %v\n", err)
			return
		}
	}()

	ticker := time.NewTicker(w.Interval)
	for {
		// 判断是否为有效时间段
		if w.waiting() {
			time.Sleep(w.Interval)
			continue
		}

		switch w.status {
		case open, stop:
			break
		case running:
			select {
			case params := <-w.taskWorkIdChan:
				w.doFunc(params)
			case <-ticker.C:
				continue
			}
		case remove:
			return
		}

		time.Sleep(w.Interval)
	}
}

func (w *worker) waiting() bool {
	if w.status == remove {
		// 已经被删除了
		return false
	}
	now := time.Now().UnixMilli()
	//if w.robot.UserId != 0 {
	//	return true
	//}
	switch {
	case now > w.robot.TimePartEnd:
		// 超过生效时间
		w.status = stop
		w.monitor.unregisterWork(w.robot.ID.Hex())
		return false
	case now >= w.robot.TimePartStart && now <= w.robot.TimePartEnd:
		if w.robot.Status && w.status != running {
			w.setStatus(running)
		}
		return false
	case now < w.robot.TimePartStart:
		// 生效时间未到
		return true
	default:
		return true
	}

}

func (w *worker) addTask(params interface{}) {
	select {
	case w.taskWorkIdChan <- params:
	case <-w.ctx.Done():
	}
}

func (w *worker) notifyExit() {
	w.status = remove
}
