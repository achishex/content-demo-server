package di

import (
	"content_svr/app/content_svr/handler"
	"content_svr/app/job/subcmd"
	"content_svr/db/dao"
	model2 "content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/internal/ad_mng"
	"content_svr/internal/bttl_mng"
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/internal/game_mng"
	"content_svr/internal/im_mng"
	"content_svr/internal/im_mng/open_im_api"
	"content_svr/internal/im_mng/open_im_comp"
	"content_svr/internal/inner_mng"
	"content_svr/internal/mg_model"
	"content_svr/internal/model"
	"content_svr/internal/model/im"
	"content_svr/internal/money_task"
	"content_svr/internal/notify_mng"
	"content_svr/internal/palace"
	pjob "content_svr/internal/palace/job"
	"content_svr/internal/partner_mng"
	"content_svr/internal/pay_mng"
	"content_svr/internal/security_mng"
	"content_svr/internal/thirdparty/baidu_lbs_yun_proxy"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/internal/thirdparty/wechat_proxy"
	"content_svr/internal/user_center_mng"
	"content_svr/internal/user_level_mng"
	"content_svr/internal/vip_mng"
	"content_svr/internal/wxreward"
	"content_svr/internal/zoo_game_mng"
	"content_svr/pub/router"
	"content_svr/pub/taskq"
	go_cache "github.com/fanjindong/go-cache"
	"go.uber.org/dig"
)

// NewContainer 测试和线上环境
func NewContainer() *dig.Container {
	c := dig.New()
	c.Provide(NewRdsClientByConf)
	c.Provide(NewPlatformAndIMDB)
	c.Provide(NewParseTimeDB)
	c.Provide(go_cache.NewMemCache)
	c.Provide(NewMongoDBByConf)
	c.Provide(NewKafkaProxyByConf)
	c.Provide(baidu_lbs_yun_proxy.NewBaiduLbsYunProxyImpl)
	c.Provide(shumei_proxy.NewShumeiProxyImpl)
	c.Provide(wechat_proxy.NewWechatMng)
	c.Provide(inner_mng.NewInnerProxyImpl)
	c.Provide(taskq.NewTaskQ)

	// data cache
	c.Provide(mg_model.NewUserAwardSummaryMgModelImpl)
	c.Provide(mg_model.NewKoLaWithdrawDetailMgModelImpl)
	c.Provide(mg_model.NewSuperiorContentAwardDetailMgModelImpl)
	c.Provide(mg_model.NewSNotificationReadCursorMgModelImpl)
	c.Provide(mg_model.NewCommentLikeDetailMgModelImpl)
	c.Provide(mg_model.NewSportActivityMgModelImpl)
	c.Provide(mg_model.NewPersonalUserAccountMgModelImpl)
	c.Provide(mg_model.NewWorkCommentDetailMgModelImpl)
	c.Provide(mg_model.NewUserCommentUnreadWorkMgModelImpl)
	c.Provide(mg_model.NewSecretShareUserInfoExtMgModelImpl)
	c.Provide(mg_model.NewPersonalPoliceInfoMgModelImpl)
	c.Provide(mg_model.NewWorksExpandRelMgModelImpl)
	c.Provide(mg_model.NewSecretUserMedalInfoMgModelImpl)
	c.Provide(mg_model.NewSecretMedalInfoMgModelImpl)
	c.Provide(mg_model.NewUserBlackListMgModelImpl)
	c.Provide(mg_model.NewPersonalTalkMessageTotalMgModelImpl)
	c.Provide(mg_model.NewSecretUserFollowMgModelImpl)
	c.Provide(mg_model.NewSecretUserFollowBadgeMgModelImpl)
	c.Provide(mg_model.NewSecretUserFollowBadgeListMgModelImpl)
	c.Provide(mg_model.NewSecretWorksLikeRecordMgModelImpl)
	c.Provide(mg_model.NewSecretUserWechatBindListMgModelImpl)
	c.Provide(mg_model.NewPersonalTalkMessageRecordMgModelImpl)
	c.Provide(mg_model.NewSecretMemeMgModelImpl)
	c.Provide(mg_model.NewIpAddressMgModelImpl)
	c.Provide(mg_model.NewSecretChitchatWorkMgModelImpl)
	c.Provide(mg_model.NewSignDailyFortuneMgModelImpl)
	c.Provide(mg_model.NewSecretChitChatCDKeyMgModelImpl)
	c.Provide(mg_model.NewPersonalUserNotificationMgModelImpl)
	c.Provide(mg_model.NewSecretReportMgModelImpl)
	c.Provide(mg_model.NewSecretReportUserMgModelImpl)
	c.Provide(mg_model.NewSecretMemberInfoMgModelImpl)
	c.Provide(mg_model.NewUserRemindDetailMgModelImpl)
	c.Provide(mg_model.NewAuditAwardRecordMgModelImpl)
	c.Provide(mg_model.NewSecretUserIdentificationCardMgModelImpl)
	c.Provide(mg_model.NewAuditMaliciousRecordMgModelImpl)
	c.Provide(mg_model.NewPersonBottleWorksExtMgModelImpl)
	c.Provide(mg_model.NewSecretGameMgModelImpl)
	c.Provide(mg_model.NewSecretGameOrderMgModelImpl)
	c.Provide(mg_model.NewSecretPayOrderInfoMgModelImpl)
	c.Provide(mg_model.NewSecretPayNotifyMgModelImpl)
	c.Provide(mg_model.NewSecretActiveUserMgModelImpl)
	c.Provide(mg_model.NewSecretEmoteAuditRecordMgModelImpl)
	c.Provide(mg_model.NewSecretAuditMgModelImpl)
	c.Provide(mg_model.NewSecretDailySignInMgModelImpl)
	c.Provide(mg_model.NewSecretSpeedCodeMgModelImpl)
	c.Provide(mg_model.NewSecretUserActivityDailyMgModelImpl)
	c.Provide(mg_model.NewSecretGameStatisticDailyMgModelImpl)
	c.Provide(mg_model.NewImGroup)
	c.Provide(mg_model.NewAtDetailMgModel)
	c.Provide(mg_model.NewSecretUserLoginInfoMgModel)
	c.Provide(mg_model.NewPartnerMgModel)
	c.Provide(mg_model.NewPartnerInviteMgModel)
	c.Provide(mg_model.NewPartnerDailySignInMgModel)
	c.Provide(mg_model.NewSuperiorAwardDailyMgModel)
	c.Provide(mg_model.NewCsjAdvertisementDataMgModel)

	c.Provide(model.NewUserinfoDbModelImpl)
	c.Provide(model.NewPersonalBottleWorksDbModelImpl)
	c.Provide(model.NewWorkObjectAttrDbModelImpl)
	c.Provide(model.NewOpenUserDbModelImpl)
	c.Provide(model.NewUserCircleWorksSwitchDbModelImpl)
	c.Provide(model.NewSecretExpandTypeDbModelImpl)
	c.Provide(model.NewPersonalCardMessageQueueDbModelImpl)
	c.Provide(model.NewMaoZhuaXingZuoBirthDbModelImpl)
	c.Provide(model.NewUserLevelUpRecordDbModelImpl)
	c.Provide(model.NewReportRewardDbModelImpl)
	c.Provide(model.NewWorkCommentStatusDbModelImpl)
	c.Provide(model.NewOperatorTabDbModelImpl)
	c.Provide(model.NewAdVivoFeedbackDbModelDbModelImpl)
	//imdb
	c.Provide(im.NewImGroupsDbModelModel)
	c.Provide(im.NewImGroupMemberDbModelModel)
	//data cache
	c.Provide(data_cache.NewDataCacheMng)

	c.Provide(open_im_api.NewOpenIMCaller)
	c.Provide(im_mng.NewIMHelper)
	c.Provide(im_mng.NewIMRewardComp)
	c.Provide(content_mng.NewSendSessComp)
	c.Provide(content_mng.NewContentMng)
	c.Provide(user_level_mng.NewUserLevelMng)
	c.Provide(security_mng.NewSecurityMng)
	c.Provide(user_center_mng.NewUserCenterMng)
	c.Provide(pay_mng.NewPayMng)
	c.Provide(game_mng.NewGameMng)
	c.Provide(im_mng.NewIMMng)
	c.Provide(vip_mng.NewVipMng)
	c.Provide(notify_mng.NewInactiveUserNotifyComp)
	c.Provide(notify_mng.NewWorkNotifyComp)
	c.Provide(ad_mng.NewADMng)
	c.Provide(ad_mng.NewBehaviorUpCtrl)
	c.Provide(open_im_comp.NewComponent)

	c.Provide(bttl_mng.NewBttlMng)

	// 海外游戏数据管理
	c.Provide(zoo_game_mng.NewZooGameMng)

	c.Provide(NewQueryMng)
	c.Provide(query.Use)
	c.Provide(query_mng.NewQueryMng)
	//c.Provide(query_rds.NewClient)
	c.Provide(dao.NewDbManager)
	c.Provide(partner_mng.NewPartnerMng)
	// go-zero model
	c.Provide(NewMongoConf)
	c.Provide(model2.NewAppAdvertisementModel)

	// palace
	c.Provide(palace.NewService)
	c.Provide(palace.NewHandler)
	c.Provide(pjob.NewJob)

	// handler
	c.Provide(handler.NewAdminHandler)
	c.Provide(handler.NewInternalHandler)
	//router
	c.Provide(router.NewRouter)

	//wxreward
	c.Provide(wxreward.NewService)
	c.Provide(wxreward.NewHandler)

	// 新升级逻辑
	c.Provide(user_level_mng.NewUserLvlV2Comp)
	c.Provide(user_level_mng.NewUserLvlV2Handler)

	//零花奖励
	c.Provide(money_task.NewService)
	c.Provide(money_task.NewHandler)

	// job
	provideJob(c)
	return c
}

// NewLocalContainer 本地环境
func NewLocalContainer() *dig.Container {
	c := dig.New()

	return c
}

// job 依赖
func provideJob(c *dig.Container) {
	prvdSubCmd := func(constructor any) { c.Provide(constructor, dig.Group("jobsubcmd")) }

	prvdSubCmd(subcmd.NewHelloCmd)
	prvdSubCmd(subcmd.NewMigrateDBCmd)
	prvdSubCmd(subcmd.NewPalaceSettle)
	prvdSubCmd(subcmd.NewDailyNotifyCmd)
}
