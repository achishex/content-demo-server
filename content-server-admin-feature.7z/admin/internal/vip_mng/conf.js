// test
[
    {
        "icon": "/workshop/soup/170012679_icon_guanggao.png",
        "title": "跳过广告",
        "content": "所有广告，直接跳跳跳"
    }, {
    "icon": "/workshop/soup/170012659_icon_yidu.png",
    "title": "消息已读",
    "content": "知道聊天猫友是否查看了你的消息"
}, {
    "icon": "/workshop/soup/170012661_icon_touxiang.png",
    "title": "炫酷头像/主页背景",
    "content": "用户等级解锁后，头像/主页背景支持上传动图"
}, {
    "icon": "/workshop/soup/170012662_icon_vip.png",
    "title": "VIP标识",
    "content": "难以掩盖的尊贵气息"
}
];

[
    {
        "icon": "/workshop/soup/170012668_icon_shaixuan.png",
        "title": "广场筛选特权",
        "content": "广场动态设置性别偏好，更快找到理想型"
    }, {
    "icon": "/workshop/soup/170012669_icon_svip.png",
    "title": "SVIP标识",
    "content": "让你在人群中脱颖而出"
}
];

[
    {
        "icon": "/workshop/soup/170012664_icon_all.png",
        "title": "所有VIP特权",
        "content": "解锁所有VIP特权，享更多超值权益"
    }
];
