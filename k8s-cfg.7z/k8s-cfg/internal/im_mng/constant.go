package im_mng

const (
	LeastGroupUserLimit = 2   //建群最少邀请两位好友
	ContentTypeFace     = 115 //消息类型：表情
)

// 群角色
const (
	GroupMemberRoleOwner  = 100 //群主
	GroupMemberRoleAdmin  = 60  //群管理员
	GroupMemberRoleMember = 20  //群管成员
)

// 群类型
const (
	GroupTypeNormal  = 0 //普通群（3.x 已停用）
	GroupTypeSuper   = 1 //超级群（3.x 已停用）
	GroupTypeWorking = 2 //工作群
)

// 群状态
const (
	GroupStatusOk        = 0 //正常
	GroupStatusBanChat   = 1 //封禁
	GroupStatusDismissed = 2 //解散
	GroupStatusMuted     = 3 //禁言
)

// 入群申请处理状态
const (
	ApplicationStatusAccept  = 1  //已同意
	ApplicationStatusNormal  = 0  //等待处理
	ApplicationStatusDecline = -1 //已拒绝
)

// 进群验证
const (
	GroupVerificationTypeApplyNeedVerificationInviteDirectly = 0 //申请需要同意 邀请直接进
	GroupVerificationTypeAllNeedVerification                 = 1 //所有人进群需要验证，除了群主管理员邀
	GroupVerificationTypeDirectly                            = 2 //直接进群
)

// 是否允许群成员查看其他成员资料或添加群成员为好友
const (
	Allowed    = 0 //允许
	NotAllowed = 1 //不允许
)

// 入群类型
const (
	JoinByAdmin      = 1 //系统
	JoinByInvitation = 2 //邀请
	JoinBySearch     = 3 //搜索
	JoinByQRCode     = 4 //二维码
)

const (
	CallbackCommonErrCode = 1000 //通用错误码，由服务端返回文案
)
