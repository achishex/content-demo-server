package middleware

import (
	"github.com/gin-gonic/gin"
	"net/http"
)

func InternalMW(secret string) gin.HandlerFunc {
	return func(c *gin.Context) {
		tsStr := c.GetHeader("x-req-ts")
		sign := c.GetHeader("x-req-sign")
		if tsStr == "" || sign == "" {
			c.AbortWithStatus(http.StatusForbidden)
			return
		}

		//TODO 签名校验
	}
}
