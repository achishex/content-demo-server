package money

import (
	"content_svr/db/mongodb/model"
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type AwardGameListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewAwardGameListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *AwardGameListLogic {
	return &AwardGameListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *AwardGameListLogic) AwardGameList(req *types.AwardGameListReq) (resp *types.AwardGameListResp, err error) {
	filter, opt := req.ParseMongo()

	count, err := l.svcCtx.ManagerOnlyReadDB.GameStatistical.Count(l.ctx, filter)
	if err != nil {
		return nil, err
	}

	list, err := l.svcCtx.ManagerOnlyReadDB.GameStatistical.FindAll(l.ctx, filter, opt)
	if err != nil {
		return nil, err
	}

	result := map[int64][]model.GameStatistical{}
	for _, statistical := range list {
		if arr, ok := result[statistical.Day]; ok {
			result[statistical.Day] = append(arr, statistical)
		} else {
			result[statistical.Day] = []model.GameStatistical{statistical}
		}
	}

	resp = &types.AwardGameListResp{}
	resp.List = result
	resp.Total = count
	return
}
