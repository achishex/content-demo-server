package data_cache

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	go_cache "github.com/fanjindong/go-cache"
	"time"
)

func (p *DataCacheMng) GetUserPoliceInfoMgDBLd(ctx context.Context, userId int64, bSkipCache bool) *pbapi.PersonalPoliceInfoMgDbModel {

	//从内存取
	cacheKey := getLocalCacheKeyPoliceInfoMgDBModel(userId)
	if bSkipCache == false {
		cResp, exist := p.LocalCache.Get(cacheKey)
		if exist {
			resp, ok := cResp.(*pbapi.PersonalPoliceInfoMgDbModel)
			if ok {
				return resp
			}
		}
	}

	//从mg db取
	mgItem, err := p.PersonalPoliceInfoMgDbModel.GetByUserId(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get PersonalPoliceInfo failed. userId=%v, err=%v", userId, err.Error())
		return nil
	}

	// save 到localcache
	if bSkipCache == false {
		bSuc := p.LocalCache.Set(cacheKey, mgItem, go_cache.WithEx(5*60*time.Second))
		logger.Infof(ctx, "save PersonalPoliceInfo to local cache . userId=%v, mgItem=%+v,bSuc=%v", userId, mgItem, bSuc)

	}
	return mgItem
}
