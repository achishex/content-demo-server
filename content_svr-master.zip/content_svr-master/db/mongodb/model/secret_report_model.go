package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var _ SecretReportModel = (*customSecretReportModel)(nil)

type (
	// SecretReportModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretReportModel.
	SecretReportModel interface {
		secretReportModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretReport, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretReport, error)
	}

	customSecretReportModel struct {
		*defaultSecretReportModel
	}
)

// NewSecretReportModel returns a model for the mongo.
func NewSecretReportModel(cfg MonConfig) SecretReportModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SecretReportCollectionName)
	return &customSecretReportModel{
		defaultSecretReportModel: newDefaultSecretReportModel(conn),
	}
}

func (m *customSecretReportModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			switch k {
			case "create_time_begin":
				query = append(query, bson.E{Key: "timestamp", Value: bson.D{{"$gte", v}}})
			case "create_time_end":
				query = append(query, bson.E{Key: "timestamp", Value: bson.D{{"$lte", v}}})
			case "verify":
				if int64(v.(int64)) == 0 {
					query = append(query, bson.E{Key: "verifyStatus", Value: 0}) // 待审核
				} else {
					query = append(query, bson.E{Key: "verifyStatus", Value: bson.D{{"$ne", 0}}}) // 已审核
				}
			default:
				query = append(query, bson.E{Key: k, Value: v})
			}
		}
	}

	// 只筛新的数据
	query = append(query, bson.E{Key: "arrested", Value: bson.D{{"$gte", 1}}})

	return query
}

func (m *customSecretReportModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretReportModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretReport, error) {
	result := make([]SecretReport, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretReportModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretReport, error) {
	var data SecretReport
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
