package query_rds

import (
	"content_svr/db/redisdb/model"
	"github.com/go-redis/redis/v8"
)

type Manage struct {
	Client *redis.Client
	Env    string

	Token                   *model.TokenRedis
	UserInfo                *model.UserInfoRedis
	MzRobot                 *model.MzRobotRedis
	BackgroundImage         *model.BackgroundImageRedis
	WorkInfo                *model.WorkInfoRedis
	UserRewardMoneyActivity *model.UserRewardMoneyActivityRedis
}

func NewClient(rds *redis.Client, env string) *Manage {
	m := &Manage{
		Client: rds,
		Env:    env,

		Token:                   model.NewToken(rds, env),
		UserInfo:                model.NewUserInfoRedis(rds, env),
		MzRobot:                 model.NewMzRobotRedis(rds, env),
		BackgroundImage:         model.NewBackgroundImageRedis(rds, env),
		WorkInfo:                model.NewWorkInfoRedis(rds, env),
		UserRewardMoneyActivity: model.NewUserRewardMoneyActivityRedis(rds, env),
	}

	return m

}
