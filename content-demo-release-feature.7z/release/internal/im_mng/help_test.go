package im_mng

import (
	"content_svr/internal/im_mng/open_im_api"
	"context"
	"github.com/mitchellh/mapstructure"
	"github.com/openimsdk/open-im-server/v3/pkg/apistruct"
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestMapStruct(t *testing.T) {
	data := &apistruct.TextElem{}
	content := map[string]interface{}{"Content": "111", "content": "222"}
	err := mapstructure.WeakDecode(content, data)
	assert.Nil(t, err)
	t.Log(data)
}

func TestSendGroupCustomMsg(t *testing.T) {
	c := open_im_api.NewOpenIMCaller()
	h := NewIMHelper(c)
	t.Logf("im token: %v", h.GetAdminIMTokenWithCache())
	ctx := context.Background()
	uid := "4725532565906432"
	gid := "4744622432781312"
	rsp, err := h.SendGroupCustomMsg(ctx, &UserLite{
		UserID:   uid,
		NickName: "",
		FaceURL:  "",
	}, gid, &WorkAtMsg{
		Title:  "xxx",
		Type:   111,
		UserID: 111,
		WorkID: 333,
	})
	assert.Nil(t, err)
	t.Logf("resp: %+v", rsp)
}

func TestSendGroupMsg(t *testing.T) {
	c := open_im_api.NewOpenIMCaller()
	h := NewIMHelper(c)
	t.Logf("im token: %v", h.GetAdminIMTokenWithCache())
	ctx := context.Background()
	uid := "4725532565906432"
	gid := "4744622432781312"
	rsp, err := h.SendGroupMsg(ctx, uid, gid)
	assert.Nil(t, err)
	t.Logf("resp: %+v", rsp)
}
