package data_cache

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/internal/model"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"github.com/jinzhu/copier"
	"strconv"
	"time"
)

type WorkInfoDataCache struct {
	redisClient                *redis.Client
	personalBottleWorksDbModel model.IPersonalBottleWorksDbModel

	NewCommentCount int32 `redis:"new_comment_count"` //评论数

	NewCommentPeopleCount int32 `redis:"new_comment_people_count"` //评论人数

	ValidNewCommentPersonCount int32 `redis:"valid_comment_person_count"` //有效评论人数
}

func (w *WorkInfoDataCache) getKey(workId int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:new_work_info:%v", getRdsEnvPrefix(), workId)
}

// set: 评论人集合, 计算评论人数时用于判断是否评论
func (w *WorkInfoDataCache) getPeopleKey(workId int64) string {
	return fmt.Sprintf(cache_const.WorkPeopleCommentCount.KeyFmt, workId)
}

// set: 评论人集合, 计算评论人数时用于判断是否评论
func (w *WorkInfoDataCache) getPeopleCommentCountGtNKey(workId int64) string {
	return fmt.Sprintf(cache_const.WorkPeopleCommentCountGtN.KeyFmt, workId)
}

// 一个work下有效评论人数.
func (w *WorkInfoDataCache) getValidPersonKey(workId int64) string {
	return fmt.Sprintf(cache_const.ValidWorkCommentPersonCount.KeyFmt, workId)
}
func (w *WorkInfoDataCache) getValidPersonKeyExpire() int64 {
	return cache_const.ValidWorkCommentPersonCount.Expire
}

func (w *WorkInfoDataCache) IncCommentCount(ctx context.Context, workId int64, count int64) error {
	redisKey := w.getKey(workId)

	workInfo, err := w.getWorkInfo(ctx, workId)
	if err != nil || workInfo.NewCommentCount == 0 {
		w.redisClient.HSet(ctx, redisKey, "new_comment_count", count)
		return nil
	}

	_, err = w.redisClient.HIncrBy(ctx, redisKey, "new_comment_count", count).Result() //返回设置之后的值
	if err != nil {
		return err
	}
	return nil
}

// 计算评论人数
func (w *WorkInfoDataCache) IncCommentPeopleCount(ctx context.Context, workId, userId, count int64) (int64, error) {
	peopleKey := w.getPeopleKey(workId)

	if count > 0 {
		if w.redisClient.SIsMember(ctx, peopleKey, userId).Val() {
			return 0, nil
		}

		w.redisClient.SAdd(ctx, peopleKey, userId)
	} else {
		if !w.redisClient.SIsMember(ctx, peopleKey, userId).Val() {
			return 0, nil
		}

		w.redisClient.SRem(ctx, peopleKey, userId)
	}

	c, err := w.redisClient.HIncrBy(ctx, w.getKey(workId), "new_comment_people_count", count).Result()
	if err != nil {
		return 0, err
	}

	//自最后评论后保留3天
	w.redisClient.Expire(ctx, peopleKey, time.Duration(cache_const.WorkPeopleCommentCount.Expire)*time.Second)

	return c, nil
}

// 计算评论数大于N，且人数大于N
func (w *WorkInfoDataCache) IncCommentCountPeopleCountGtN(ctx context.Context, workId, userId, count int64) (int64, error) {
	peopleKey := w.getPeopleCommentCountGtNKey(workId)

	if count > 0 {
		if w.redisClient.SIsMember(ctx, peopleKey, userId).Val() {
			return 0, nil
		}

		w.redisClient.SAdd(ctx, peopleKey, userId)
	} else {
		if !w.redisClient.SIsMember(ctx, peopleKey, userId).Val() {
			return 0, nil
		}

		w.redisClient.SRem(ctx, peopleKey, userId)
	}

	c, err := w.redisClient.HIncrBy(ctx, w.getKey(workId), "new_comment_people_count_both_gt_n", count).Result()
	if err != nil {
		return 0, err
	}

	//自最后评论后保留3天
	w.redisClient.Expire(ctx, peopleKey, time.Duration(cache_const.WorkPeopleCommentCountGtN.Expire)*time.Second)

	return c, nil
}

func (w *WorkInfoDataCache) DeleteValidCommentUser(ctx context.Context, workId int64) error {
	key := w.getValidPersonKey(workId)
	ret, err := w.redisClient.Del(ctx, key).Result()
	if err != nil {
		logger.Errorf(ctx, "delete all items for key: %v", key)
		return err
	}
	logger.Infof(ctx, "delete all items for key: %v, del item nums: %v", key, ret)
	return nil
}

// 增加有效评论人数
func (w *WorkInfoDataCache) IncrValidCommentPersonCount(ctx context.Context, workId, userId int64, addOrDel int32) (int64, error) {
	key := w.getValidPersonKey(workId)
	if addOrDel > 0 {
		addRet, err := w.redisClient.SAdd(ctx, key, userId).Result()
		if err != nil {
			logger.Errorf(ctx, "add userId: %v to key: %v fail, err: %v", userId, key, err)
			return 0, err
		}
		if addRet == 0 {
			//repeated item add
		}
		// add new item
	} else {
		remRet, err := w.redisClient.SRem(ctx, key, userId).Result()
		if err != nil {
			logger.Errorf(ctx, "rem userId: %v from key: %v fail, err: %v", userId, key, err)
			return 0, err
		}
		if remRet <= 0 {
			//not exist item rem
		}
		//  exist item rem
	}

	c, err := w.redisClient.SCard(ctx, key).Result()
	if err != nil {
		return 0, err
	}

	//每个动态的有效评论人数, 有效时间戳
	w.redisClient.Expire(ctx, key, time.Duration(w.getValidPersonKeyExpire())*time.Second)
	return c, nil
}
func (w *WorkInfoDataCache) GetValidCommentPersonCount(ctx context.Context, workId int64) (int64, error) {
	key := w.getValidPersonKey(workId)
	ret, err := w.redisClient.SCard(ctx, key).Result()
	if err != nil {
		logger.Errorf(ctx, "get item nums fail, key: %v", key)
		return 0, err
	}
	return ret, nil
}
func (w *WorkInfoDataCache) getWorkInfo(ctx context.Context, workId int64) (*WorkInfoDataCache, error) {
	redisKey := w.getKey(workId)
	workInfo := &WorkInfoDataCache{}
	err := w.redisClient.HGetAll(ctx, redisKey).Scan(workInfo)
	if err == nil {
		return workInfo, nil
	}

	// 缓存中不存在查询 mysql
	workInfoMongo, err := w.personalBottleWorksDbModel.GetByWorkId(ctx, workId)
	if err != nil {
		logger.Error(ctx,
			fmt.Sprintf("SetUserVisitorCountRD set redis failed. workid=%v", workId), err)
	}

	if err := copier.Copy(workInfo, workInfoMongo); err == nil {
		return workInfo, nil
	}

	// 重新缓存
	w.redisClient.HSet(ctx, redisKey, workInfo)

	return workInfo, nil
}

// SetWorkInfoToNewCommentCount 更新用户的 PersonalBottleWorksSimple 对应的 newCommentCount
func (p *DataCacheMng) IncWorkInfoToNewCommentCount(ctx context.Context, workId int64, count int64) error {
	dbCache := WorkInfoDataCache{redisClient: p.RedisCli}

	// 操作redis
	err := dbCache.IncCommentCount(ctx, workId, count)
	if err != nil {
		logger.Error(ctx,
			fmt.Sprintf("SetUserVisitorCountRD set redis failed. workid=%v", workId), err)
	}

	//  修改 db 中数据
	return p.PersonBottleWorksModel.UpdateNewCommentCountToCount(ctx, []int64{workId}, count)
}

func (p *DataCacheMng) GetWorkInfoToNewCommentCount(ctx context.Context, workIds ...int64) ([]*WorkInfoDataCache, error) {
	//err := p.IncWorkInfoToNewCommentCount(ctx, []int64{4448109441123328})
	//if err != nil {
	//	logger.Error(ctx, "IncWorkInfoToNewCommentCount: ", err)
	//}
	dbCache := &WorkInfoDataCache{
		redisClient:                p.RedisCli,
		personalBottleWorksDbModel: p.PersonBottleWorksModel,
	}
	result := make([]*WorkInfoDataCache, 0)
	for _, id := range workIds {
		//workInfo, err := dbCache.getWorkInfo(ctx, 4448109441123328)
		workInfo, err := dbCache.getWorkInfo(ctx, id)
		if err != nil {
			logger.Error(ctx,
				fmt.Sprintf("SetUserVisitorCountRD set redis failed. workid=%v", id), err)
		}

		result = append(result, workInfo)
	}
	return result, nil
}

func (p *DataCacheMng) DeleteCommentUsersOnWork(ctx context.Context, workId int64) error {
	dbCache := WorkInfoDataCache{redisClient: p.RedisCli}
	err := dbCache.DeleteValidCommentUser(ctx, workId)
	if err != nil {
		logger.Errorf(ctx, "DeleteCommentUsersOnWork  fail, err: %v", err)
		return err
	}
	logger.Infof(ctx, "DeleteCommentUsersOnWork workId: %v", workId)
	return nil
}
func (p *DataCacheMng) IncrValidCommentPersonCount(ctx context.Context, workId, userId int64, addOrDel int32) (int32, error) {
	dbCache := WorkInfoDataCache{redisClient: p.RedisCli}
	c, err := dbCache.IncrValidCommentPersonCount(ctx, workId, userId, addOrDel)
	if err != nil {
		logger.Errorf(ctx, "incr valid comment person count fail, err: %v", err)
		return 0, err
	}
	//logger.Infof(ctx, "valid comment user nums: %v, workId: %v, userId: %v, op: %v", c, workId, userId, addOrDel)
	return int32(c), nil
}
func (p *DataCacheMng) GetValidCommentPersonCount(ctx context.Context, workId int64) (int64, error) {
	dbCache := WorkInfoDataCache{redisClient: p.RedisCli}
	c, err := dbCache.GetValidCommentPersonCount(ctx, workId)
	if err != nil {
		logger.Errorf(ctx, "get valid comment user nums, err: %v", err)
		return 0, err
	}
	//logger.Infof(ctx, "valid comment user nums: %v, workId: %v", c, workId)
	return c, nil
}

// IncWorkInfoToNewCommentPeopleCount 计算评论人数
func (p *DataCacheMng) IncWorkInfoToNewCommentPeopleCount(ctx context.Context, workId int64, authorUserId int64, userId int64, count int64) error {
	dbCache := WorkInfoDataCache{redisClient: p.RedisCli}

	//过滤官方机器人回复评论
	if p.IsRobotComment(ctx, userId) {
		return nil
	}

	c, err := dbCache.IncCommentPeopleCount(ctx, workId, userId, count)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("IncWorkInfoToNewCommentPeopleCount: set redis failed. workid=%v", workId), err)
	}

	if c == 0 {
		return nil
	}

	// 1级、2级用户的内容不进入精品分发池
	if c >= int64(config.ServerConfig.ContentConfig.HighContentCommentNum) && count > 0 {
		author := p.GetUserExtInfoMgDBLd(ctx, authorUserId, false)
		if author.GetUlevel() > 2 {
			if err := p.AddToHighTsWorkPoolRedis(ctx, workId); err != nil {
				logger.Error(ctx, fmt.Sprintf("IncWorkInfoToNewCommentPeopleCount: Failed to write the premium content pool. workid=%v", workId), err)
				return err
			}
		}
	}

	if c < int64(config.ServerConfig.ContentConfig.HighContentCommentNum) && count < 0 {
		if p.AsyncRemoveFromHighTsWorkPoolRedis(ctx, []string{strconv.FormatInt(workId, 10)}) {
			logger.Error(ctx, fmt.Sprintf("AsyncRemoveFromHighTsWorkPoolRedis: Failed to delete the premium content pool. workid=%v", workId), err)
			return err
		}
	}

	return nil
}

// IncWorkInfoToNewCommentPeopleCount 计算评论数大于N，且人数大于N
func (p *DataCacheMng) IncCommentCountPeopleCountGtN(ctx context.Context, workId int64, authorUserId, userId int64, count int64) error {
	dbCache := WorkInfoDataCache{redisClient: p.RedisCli}

	//过滤官方机器人回复评论
	if p.IsRobotComment(ctx, userId) {
		return nil
	}

	//计算条件人数
	c, err := dbCache.IncCommentCountPeopleCountGtN(ctx, workId, userId, count)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("IncCommentCountPeopleCountGtN: set redis failed. workid=%v", workId), err)
	}

	author := p.GetUserExtInfoMgDBLd(ctx, authorUserId, false)
	// 1级、2级用户的内容不进入精品分发池
	if author.GetUlevel() <= 2 {
		return nil
	}

	//《高》优质内容池要求
	//同一个人在同一个动态下评论数量大于N，且此条件大于N人
	if c > int64(config.ServerConfig.ContentConfig.HighPlusContentCommentNum) {
		if err := p.AddToHighPlusTsWorkPoolRedis(ctx, workId); err != nil {
			logger.Error(ctx, fmt.Sprintf("AddToHighPlusTsWorkPoolRedis: Failed to add to hight plus premium content pool. workid=%v", workId), err)
		}
	}

	return nil
}
