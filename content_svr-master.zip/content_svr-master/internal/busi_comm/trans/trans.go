package trans

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/utils"
	"github.com/gogo/protobuf/proto"
)

// CacheUserInfo 转化为SimpleUserInfo
func TransWorkObjDbModelToSimpleBatch(dbItems []*pbapi.WorkObjectAttrDbModel) []*pbapi.WorkObjectAttr {
	resp := make([]*pbapi.WorkObjectAttr, 0)
	if len(dbItems) == 0 {
		return resp
	}
	for _, dbitem := range dbItems {
		resp = append(resp, &pbapi.WorkObjectAttr{
			Id:        dbitem.GetId(),
			Type:      dbitem.GetType(),
			Width:     dbitem.GetWidth(),
			High:      dbitem.GetHigh(),
			ObjectId:  dbitem.GetObjectId(),
			Thumbnail: dbitem.GetThumbnail(),
		})
	}
	return resp
}

func TransUserInfoLocalToUserSimple(userInfo *data_cache.UserInfoLocal) *pbapi.SimpleUserInfo {
	if userInfo == nil {
		return nil
	}
	authorInfoLocal := userInfo
	BackgroundImage := ""
	var BackgroundImageShare int32 = 0
	var BackgroundImageDownload int32 = 0
	//需要检查状态为 11 或者102
	uLevel := int32(0)
	if authorInfoLocal.PsecretUserExtInfo != nil &&
		utils.Int64In([]int64{11, 101}, int64(authorInfoLocal.PsecretUserExtInfo.GetBackgroundImageStatus())) {
		BackgroundImage = authorInfoLocal.PsecretUserExtInfo.GetBackgroundImage()
		BackgroundImageShare = authorInfoLocal.PsecretUserExtInfo.GetBackgroundImageShare()
	}
	if authorInfoLocal.PsecretUserExtInfo != nil {
		uLevel = authorInfoLocal.PsecretUserExtInfo.GetUlevel()
	}
	//chitChatCdKey := ""
	//if authorInfoLocal != nil {
	//	chitChatCdKey = authorInfoLocal.PsecretUserExtInfo.GetChitChatCdKey()
	//}
	ShowConvoy := false
	if authorInfoLocal.PersonalPoliceInfoMgModel != nil {
		ShowConvoy = authorInfoLocal.PersonalPoliceInfoMgModel.GetShowConvoy()
	}
	UserMedals := make([]*pbapi.SecretMedalInfoResponse, 0)
	if len(authorInfoLocal.UserMedals) > 0 {
		UserMedals = authorInfoLocal.UserMedals
	}

	userResp := &pbapi.SimpleUserInfo{
		UserId:      authorInfoLocal.UserInfoDbModel.GetUserId(),
		NickName:    authorInfoLocal.UserInfoDbModel.GetNickName(), // 这里要用opennickname
		Photo:       authorInfoLocal.UserInfoDbModel.GetPhoto(),
		Gender:      authorInfoLocal.UserInfoDbModel.GetGender(),
		Birth:       authorInfoLocal.UserInfoDbModel.GetBirth(),
		Age:         utils.CalculateAge(authorInfoLocal.UserInfoDbModel.GetBirth()),
		SignId:      utils.CalculateConstellation(authorInfoLocal.UserInfoDbModel.GetBirth()),
		City:        "", //authorInfoLocal.UserInfoDbModel.GetCity(),
		Province:    "", //authorInfoLocal.UserInfoDbModel.GetProvince(),
		IsConvoy:    authorInfoLocal.IsPolice,
		ShowConvoy:  ShowConvoy,
		MemberType:  authorInfoLocal.MemberType,
		WorksLock:   authorInfoLocal.UserInfoDbModel.GetWorksLock(),
		Enabled:     authorInfoLocal.UserInfoDbModel.GetEnabled(),
		CommentLock: authorInfoLocal.UserInfoDbModel.GetCommentLock(),
		//Openid:                  userInfoLocal.OpenId,
		//ChitChatCdKey:           chitChatCdKey,
		//ChitChatCKeyUpCase:      chitChatCdKey,
		BackgroundImage:         BackgroundImage,
		BackgroundImageShare:    BackgroundImageShare,
		BackgroundImageDownload: BackgroundImageDownload,
		Medals:                  UserMedals,
		UserType:                authorInfoLocal.UserInfoDbModel.GetUserType(),
		ULevel:                  uLevel,
		TalkMode:                authorInfoLocal.PsecretUserExtInfo.GetTalkMode(),
	}
	return userResp
}
func TransWorkInfoLocalScoreInfoToWorksSimple(workLocal *data_cache.WorkInfoLocal,
	authorLocal *data_cache.UserInfoLocal,
	liked bool,
	extInfo *pbapi.ExtInfo) *pbapi.PersonalBottleWorksSimple {
	//workLocal := item.WorkInfoLocal
	//authorLocal := item.AuthorInfoLocal

	curExpand := make([][]*pbapi.WorksExpandTypeSimpleResponse, 0)
	if len(workLocal.WorksExpandInfo) > 0 {
		curExpand = workLocal.WorksExpandInfo
	}

	resp := &pbapi.PersonalBottleWorksSimple{
		Id:            workLocal.WorkInfoDbModel.GetId(),
		UserId:        workLocal.WorkInfoDbModel.GetUserId(),
		UserInfo:      TransUserInfoLocalToUserSimple(authorLocal),
		Photo:         authorLocal.UserInfoDbModel.GetPhoto(),
		NickName:      authorLocal.UserInfoDbModel.GetNickName(),
		Type:          workLocal.WorkInfoDbModel.GetType(),
		PushType:      workLocal.WorkInfoDbModel.GetPushType(),
		Source:        workLocal.WorkInfoDbModel.GetSource(),
		Title:         workLocal.WorkInfoDbModel.GetTitle(),
		WorkObject:    TransWorkObjDbModelToSimpleBatch(workLocal.WorkObjAttr),
		CreateTime:    utils.GenTimestampMs(workLocal.WorkInfoDbModel.GetCreateTime()),
		StartTime:     utils.GenTimestampMs(workLocal.WorkInfoDbModel.GetStartTime()),
		EndTime:       utils.GenTimestampMs(workLocal.WorkInfoDbModel.GetEndTime()),
		VisitorCount:  workLocal.WorkInfoDbModel.GetVisitorCount(),
		TalkUserCount: workLocal.WorkInfoDbModel.GetCommentCount(),
		LikeCount:     workLocal.WorkInfoDbModel.GetLikeCount(),
		Liked:         liked, //item.Liked,
		//ResNum:         workLocal.WorkInfoDbModel.get, //
		//UseUpPushCount: 0,                                      //
		//--FinishShare:    0,                                    //
		TalkType:   1, //写死，默认为1
		TemplateId: workLocal.WorkInfoDbModel.GetTemplateId(),
		City:       workLocal.WorkInfoDbModel.City,
		Province:   workLocal.WorkInfoDbModel.Province,
		//GroupId:    item.WorkInfoLocal.WorkInfoDbModel.Getg(), //
		Longitude:     workLocal.WorkInfoDbModel.Longitude,
		Latitude:      workLocal.WorkInfoDbModel.Latitude,
		QqFriend:      workLocal.WorkInfoDbModel.GetQqFriend(),
		Special:       workLocal.WorkInfoDbModel.Special,
		Expands:       curExpand,
		ExtInfo:       extInfo,
		EnableComment: proto.Int32(const_busi.WorkCommentStatusDisable), //
		Followed:      proto.Bool(false),
		// 结构体定义中不返回的字段
		//BrowseType:     0,
		//ShareStatus:    0,
		//Identity:       0,
		//AppType:        0,
		//Code:         0,
		//Score:          0,
		//WorksType:      0,
		//OppositeSex:    false,
		//TagIds:         "",
	}
	return resp
}
