package model

const SecretAuditCollectionName = "secretAudit"

type SecretAudit struct {
	ID int64 `bson:"_id" json:"id"`

	RequestId       string `json:"request_id,omitempty" bson:"request_id"`             //外部流水号
	AuditType       int32  `json:"audit_type,omitempty" bson:"audit_type"`             //1:文本 2：图片
	Platform        int32  `json:"platform,omitempty" bson:"platform"`                 //平台 1:数美
	EventId         string `json:"event_id,omitempty" bson:"event_id"`                 //渠道 1：文本（article（动态）/comment（评论）/profile（个人简介）/nickname（昵称）/signature（签名）/message（私聊）/text（智能文本识别）/COMMENT（默认文本）2：图片（默认图片（IMAGE）/相册（album)/动态（article）/评论（comment）/头像（headImage）/智能图片识别（image)/私聊（message)
	BussId          int64  `json:"buss_id,omitempty" bson:"buss_id"`                   //业务id
	UserId          int64  `json:"user_id,omitempty" bson:"user_id"`                   //用户id
	WorkId          int64  `json:"work_id,omitempty" bson:"work_id"`                   //动态id
	CommentId       int64  `json:"comment_id,omitempty" bson:"comment_id"`             //评论id
	MessageId       int64  `json:"message_id,omitempty" bson:"message_id"`             //消息id
	ObjectId        string `json:"object_id,omitempty" bson:"object_id"`               //图片对象id
	ImgUrl          string `json:"img_url,omitempty" bson:"img_url"`                   //图片地址
	Content         string `json:"content,omitempty" bson:"content"`                   //文本内容
	OcrContent      string `json:"ocr_content,omitempty" bson:"ocr_content"`           //ocr识别内容 (audit_type=2)
	RiskLevel       string `json:"risk_level,omitempty" bson:"identify_results"`       //识别结果 PASS通过/REVIEW审核/REJECT拒绝
	AuditResp       string `json:"audit_resp,omitempty" bson:"audit_resp"`             //审核响应信息
	VerifyUser      string `json:"verify_user" bson:"verify_user"`                     // 处理人
	VerifyTime      int64  `json:"verify_time" bson:"verify_time"`                     // 处理时间
	FeedbackType    string `json:"feedback_type,omitempty" bson:"feedback_type"`       //反馈类型 miss（漏杀）/error（误杀）
	FeedbackStatus  int32  `json:"feedback_status,omitempty" bson:"feedback_status"`   //反馈结果 1：成功
	FeedbackTime    int64  `json:"feedback_time,omitempty" bson:"feedback_time"`       //反馈时间
	IsRecirculate   int32  `json:"is_recirculate,omitempty" bson:"is_recirculate"`     //重新分发 1: 是 2：否
	RecirculateTime int64  `json:"recirculate_time,omitempty" bson:"recirculate_time"` //重新分发时间
	CreateTime      int64  `json:"create_time,omitempty" bson:"create_time"`           //创建时间
	UpdateTime      int64  `json:"update_time,omitempty" bson:"update_time"`           //更新时间
}
