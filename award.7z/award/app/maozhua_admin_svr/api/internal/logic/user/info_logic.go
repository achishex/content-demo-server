package user

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/pub/utils"
	"context"

	"github.com/zeromicro/go-zero/core/logx"
)

type InfoLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewInfoLogic(ctx context.Context, svcCtx *svc.ServiceContext) *InfoLogic {
	return &InfoLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *InfoLogic) Info(req *types.UserInfoReq) (resp *types.UserInfoResp, err error) {
	info, err := l.svcCtx.ManagerDB.UserInfo.FindByUserId(l.ctx, req.UserId)
	if err != nil {
		return nil, xerr.UserInfoNoFound
	}

	var nickName, photo string
	if info.NickName == "" {
		nickName = info.OpenNickName
	} else {
		nickName = info.NickName
	}

	if info.Photo == "" {
		photo = info.OpenPhoto
	} else {
		photo = info.Photo
	}
	photo = utils.FixImageUrl(l.svcCtx.Config.ImageHost, photo)

	phone, err := utils.AESDecrypt(info.Phone, utils.AesUserKey)
	if err != nil {
		return nil, err
	}

	resp = &types.UserInfoResp{
		Phone:    string(phone),
		NickName: nickName,
		Photo:    photo,
	}

	return resp, nil
}
