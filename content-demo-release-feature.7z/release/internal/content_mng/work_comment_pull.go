package content_mng

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/version"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/middleware"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
)

func (p *ContentMng) PullWorkCommentsV2(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.WorkCommentPullReq) (*pbapi.WorkCommentPullResp, error) {
	var loginUserId int64
	resp := &pbapi.WorkCommentPullResp{}

	ret, err := p.PullWorkCommentsDetail(ctx, header, req)
	if err != nil || len(ret.GetContents()) <= 0 {
		return nil, err
	}

	var comments []*pbapi.WorkCommentBrief
	for k, _ := range ret.GetContents() {
		if ret.GetContents()[k] == nil {
			continue
		}

		if header.GetVersioncode() < version.CommentEmotionVersion && ret.GetContents()[k].GetCommentType() == const_busi.CommentTypeEmote {
			// 老版本
			ret.GetContents()[k].Comment = proto.String("[ 请在最新版猫爪app中查看 ]")
		}

		userId := ctx.Value(middleware.CtxUserID)
		loginUserId, _ = userId.(int64)
		remarkName, _ := p.DataCache.GetUserRemarkOne(ctx, loginUserId, ret.GetContents()[k].GetFromUserId())
		ret.GetContents()[k].UserInfo.RemarkName = remarkName
		comments = append(comments, ret.GetContents()[k])
	}
	resp.Comments = comments

	workInfos, err := p.DataCache.GetWorkInfoToNewCommentCount(ctx, req.GetWorkId())
	if err != nil {
		return nil, err
	}

	for _, info := range workInfos {
		resp.Total = info.NewCommentCount
	}
	//
	{
		awardInfo, _ := NewSuperiorContentInstance(p, nil, 0).GetWorkStatusAndAward(ctx, req.GetWorkId())
		if awardInfo != nil && awardInfo.IsSuperiorContent {
			resp.WorkToast = fmt.Sprintf(SuperiorContentDescOnWorkFmt, awardInfo.LatestAwarded)
			resp.JumpUrl = awardInfo.Url
		}
	}
	return resp, nil
}
