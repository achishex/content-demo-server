package data_cache

import (
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"strconv"
	"time"
)

// 每次用户拉取过后，记录当前的最低分，后续有高于最低分的直接返回。
func (p *DataCacheMng) GetUserLatestWorkScore(ctx context.Context, userId int64) float32 {
	if userId == 0 {
		return 0
	}

	redisKey := getRdsKeyUserLatestWorkScore(userId)   // workid~calcScore
	ret, err := p.RedisCli.Get(ctx, redisKey).Result() //返回在range的idx位置
	if err == redis.Nil {
		return 0
	}
	if err != nil { //获取失败
		logger.Error(ctx, fmt.Sprintf("GetUserLatestWorkScore redis qurey failed. key=%v", redisKey), err)
		return 0
	}
	retFloat, err := strconv.ParseFloat(ret, 32)
	if err != nil { //转化失败
		logger.Error(ctx, fmt.Sprintf("GetUserLatestWorkScore trans to float failed. key=%v, val=%v", redisKey, ret), err)
		return 0
	}
	return float32(retFloat)
}

func (p *DataCacheMng) SetUserLatestWorkScore(ctx context.Context, userId int64, score float32) error {
	redisKey := getRdsKeyUserLatestWorkScore(userId)
	_, err := p.RedisCli.Set(ctx, redisKey, score, time.Duration(5*60)*time.Second).Result()
	if err != nil && err != redis.Nil {
		logger.Error(ctx, fmt.Sprintf("GetUserChitChatCdKey redis qurey failed. key=%v", redisKey), err)
		return err
	}
	return nil
}
