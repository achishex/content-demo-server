package job

import (
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"context"
	"github.com/jinzhu/copier"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"math"
	"time"
)

func InitAwardCalcSum(write, read *dao.ManagerDB) {
	go func() {
		ctrl := newAwardCalcSumControl(write, read)
		//ctrl.once()
		//return

		ctrl.Do(func() {
			ctx := requestid.WithRequestID(context.Background())
			if err := ctrl.DoTask(ctx, time.Now().AddDate(0, 0, -1)); err != nil {
				logger.Errorf(ctx, "newAwardCalcSumControl.DoTask: %v", err)

				// 五分钟后重试
				ctrl.ticker.Reset(time.Minute * 5)
				return
			}

			ctrl.ticker.Reset(ctrl.calcIntervalTime())
		})

	}()
}

const (
	awardSettlementSumType           int = 1 // 当天结算奖励总和
	deductionIllegalSumType          int = 2 // 当天违规扣除总和
	firstWorkSettlementSumType       int = 3 // 当天首条动态奖励总和
	wechatPayWithdrawSuccessSumType  int = 5 // 当天微信提现成功总和
	wechatPayWithdrawFailSumType     int = 6 // 当天微信提现失败总和
	hallOfFameAwardSettlementSumType int = 7 // 当天排行榜奖励总和
)

type awardCalcSumControl struct {
	TickerExecute
	write, read *dao.ManagerDB
}

func newAwardCalcSumControl(write, read *dao.ManagerDB) awardCalcSumControl {
	// 凌晨四点执行
	ctrl := awardCalcSumControl{}
	ctrl.hour = 4
	//ctrl.hour = 9
	//ctrl.minter = 53

	ctrl.write = write
	ctrl.read = read
	return ctrl
}

func (l awardCalcSumControl) once() {

	ctx := requestid.WithRequestID(context.Background())
	now := time.Now()
	target := now.AddDate(0, 0, -1)
	//target := time.Date(now.Year(), now.Month(), 13, now.Hour(), now.Minute(), now.Second(), now.Nanosecond(), now.Location())
	if err := l.DoTask(ctx, target); err != nil {
		logger.Error(context.Background(), "InitAwardCalcSum:", err)
	}

	//for i := 100; i > 0; i-- {
	//	ctx := requestid.WithRequestID(context.Background())
	//	now := time.Now()
	//	target := now.AddDate(0, 0, -i)
	//	//target := time.Date(now.Year(), now.Month(), 13, now.Hour(), now.Minute(), now.Second(), now.Nanosecond(), now.Location())
	//	if err := l.DoTask(ctx, target); err != nil {
	//		logger.Error(context.Background(), "InitAwardCalcSum:", err)
	//	}
	//	//break
	//}
}

func (l awardCalcSumControl) DoTask(ctx context.Context, targetTime time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	//fmt.Println("==============>", targetTime)
	filter := map[string]interface{}{
		"create_time": bson.D{
			{"$gte", l.baseZeroTime(targetTime).UnixMilli()},
			{"$lte", l.calcZeroTimeByDay(targetTime, 1).UnixMilli()},
		},
	}

	awardSettlementSum, err := l.count(ctx, filter, "type", awardSettlementSumType)
	if err != nil {
		return err
	}
	deductionIllegalSum, err := l.count(ctx, filter, "type", deductionIllegalSumType)
	if err != nil {
		return err
	}
	firstWorkSettlementSum, err := l.count(ctx, filter, "type", firstWorkSettlementSumType)
	if err != nil {
		return err
	}
	wechatPayWithdrawSuccessSum, err := l.count(ctx, filter, "type", wechatPayWithdrawSuccessSumType)
	if err != nil {
		return err
	}
	wechatPayWithdrawFailSum, err := l.count(ctx, filter, "type", wechatPayWithdrawFailSumType)
	if err != nil {
		return err
	}
	hallOfFameAwardSettlementSum, err := l.count(ctx, filter, "type", hallOfFameAwardSettlementSumType)
	if err != nil {
		return err
	}

	data := &model.SuperiorAwardDaily{
		Day:                          l.baseZeroTime(targetTime).UnixMilli(),
		AwardSettlementSum:           awardSettlementSum,
		DeductionIllegalSum:          deductionIllegalSum,
		FirstWorkSettlementSum:       firstWorkSettlementSum,
		WechatPayWithdrawSuccessSum:  wechatPayWithdrawSuccessSum,
		WechatPayWithdrawFailSum:     wechatPayWithdrawFailSum,
		HallOfFameAwardSettlementSum: hallOfFameAwardSettlementSum,
	}

	updateFilter := bson.D{
		{"day", l.baseZeroTime(targetTime).UnixMilli()},
	}

	update := bson.D{
		{"$set", data},
		{"$setOnInsert", bson.D{
			{"create_time", targetTime.UnixMilli()},
		}},
	}

	opt := options.Update().SetUpsert(true)
	if _, err := l.write.SuperiorAwardDaily.Update(ctx, updateFilter, update, opt); err != nil {
		return err
	}

	logger.Infof(ctx, "==-==每日奖励计算完成")

	return nil
}

func (l awardCalcSumControl) count(ctx context.Context, filter map[string]interface{}, key string, value interface{}) (int, error) {
	var newFilter map[string]interface{}
	_ = copier.Copy(&newFilter, &filter)
	newFilter[key] = value

	items, err := l.read.SuperiorContentAwardDetail.FindAll(ctx, newFilter)
	if err != nil {
		return 0, err
	}

	var count float64
	for _, detail := range items {
		count += detail.Award
	}

	return int(math.Round(count * 100)), nil

}
