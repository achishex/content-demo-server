package money

import (
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type QueryAwardListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewQueryAwardListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *QueryAwardListLogic {
	return &QueryAwardListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *QueryAwardListLogic) QueryAwardList(req *types.AwardListReq) (resp *types.AwardListResp, err error) {
	filter, opt := req.ParseMongo()

	count, err := l.svcCtx.ManagerDB.SuperiorContentAwardDetail.Count(l.ctx, filter)

	list, err := l.svcCtx.ManagerDB.SuperiorContentAwardDetail.FindAll(l.ctx, filter, opt)
	if err != nil {
		return nil, err
	}

	resp = &types.AwardListResp{
		Total: count,
		List:  list,
	}

	return resp, nil
}
