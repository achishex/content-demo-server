package report

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/db/mysqldb/model"
	"content_svr/pub/utils"
	"context"
	"strconv"
	"strings"
	"time"

	"github.com/jinzhu/copier"
	"go.mongodb.org/mongo-driver/mongo/options"

	"github.com/zeromicro/go-zero/core/logx"
)

type QueryReportListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewQueryReportListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *QueryReportListLogic {
	return &QueryReportListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *QueryReportListLogic) QueryReportList(req *types.QueryReportReq) (resp *types.QueryReportResp, err error) {
	req.OrderKey = "timestamp"
	req.Order = "desc"
	filter, opt := req.ParseMongo()

	count, err := l.svcCtx.WriteDB.SecretReport.Count(l.ctx, filter)
	if err != nil {
		l.Errorf("report_list_error_1, err: %v, filter: %v, opt: %v", err, filter, opt)
		return nil, err
	}

	if count == 0 {
		return &types.QueryReportResp{
			Total: 0,
		}, nil
	}

	list, err := l.svcCtx.WriteDB.SecretReport.FindAll(l.ctx, filter, opt)
	if err != nil {
		l.Errorf("report_list_error_2, err: %v, filter: %v, opt: %v", err, filter, opt)
		return nil, err
	}

	retList := make([]types.QueryReportItem, 0)
	for _, item := range list {
		// 举报 detail
		reportDetail := &types.QueryReportDetail{}
		{
			err = copier.Copy(reportDetail, &item)
			if err != nil {
				l.Errorf("report_list_error_3, err: %v", err)
				return nil, err
			}

			info, err := l.QueryUserInfo(reportDetail.UserId)
			if err != nil {
				l.Errorf("report_list_error_4, err: %v", err)
				return nil, err
			}

			reportDetail.UserInfo = *info
		}

		{
			now := time.Now()
			lastThreeMonth := now.AddDate(0, -2, 0)
			where := map[string]interface{}{
				"user_id":           reportDetail.UserId,
				"create_time_end":   now.Format("2006-01-02 15:04:05"),
				"create_time_begin": lastThreeMonth.Format("2006-01-02 15:04:05"),
			}
			reportDetail.WorkCount, _ = l.svcCtx.WriteDB.PersonalBottleWorks.Count(l.ctx, where)
			//fmt.Println("==============>", time.Since(now))

			filter := map[string]interface{}{
				"fromUserId":      reportDetail.UserId,
				"createTimeStart": lastThreeMonth.UnixMilli(),
				"createTimeEnd":   now.UnixMilli(),
			}
			reportDetail.TalkCount, _ = l.svcCtx.WriteDB.PersonalTalkMessageRecord.Count(l.ctx, filter)
			//fmt.Println("==============>", time.Since(now))
		}

		// 动态详情
		{
			if reportDetail.WorkId > 100 {
				work, err := l.svcCtx.WriteDB.PersonalBottleWorks.FindByWorkId(l.ctx, reportDetail.WorkId)
				if err != nil {
					return nil, err
				}
				tmp := &types.WorkItem{}
				err = copier.Copy(tmp, work)
				if err != nil {
					return nil, err
				}
				if work.Type == model.WorkTypeImage {
					where := map[string]interface{}{
						"work_id": reportDetail.WorkId,
					}
					objects, err := l.svcCtx.WriteDB.WorkObjectAttr.FindMap(l.ctx, 0, 0, where)
					if err != nil {
						l.Errorf("report_list_error_5, err: %v, where: %v", err, where)
						return nil, err
					}

					for i := 0; i < len(objects); i++ {
						objects[i].ObjectID = utils.FixImageUrl(l.svcCtx.Config.ImageHost, objects[i].ObjectID)
					}

					_ = copier.Copy(&tmp.WorkObject, &objects)
				}

				reportDetail.WorkInfo = *tmp
			}
		}

		// 评论详情
		{
			if reportDetail.CommentId > 0 {
				filter := map[string]interface{}{
					"work_id": reportDetail.WorkId,
					"user_id": reportDetail.UserId,
				}
				commentDetails, err := l.svcCtx.WriteDB.WorksCommentDetail.FindAll(l.ctx, filter)
				if err != nil {
					l.Errorf("report_list_error_6, err: %v, filter: %v", err, filter)
					return nil, err
				}
				arr := make([]types.CommentItem, 0)
				for _, detail := range commentDetails {
					tmp := &types.CommentItem{}
					err = copier.Copy(tmp, detail)
					if err != nil {
						l.Errorf("report_list_error_7, err: %v", err)
						return nil, err
					}

					if tmp.CommentObject.ObjectId != "" {
						tmp.CommentObject.ObjectId = utils.FixImageUrl(l.svcCtx.Config.ImageHost, tmp.CommentObject.ObjectId)
					}

					if reportDetail.CommentId == detail.ID {
						n := make([]types.CommentItem, 0)
						n = append(n, *tmp)
						n = append(n, arr...)
						arr = n
					} else {
						arr = append(arr, *tmp)
					}
				}
				reportDetail.Comments = arr
			}
		}

		// 聊天信息
		{
			if reportDetail.Type == 2 {
				uniqueId := genUniqueId(reportDetail.UserId, reportDetail.ReportUserId, reportDetail.WorkId, 0)

				filter := make(map[string]interface{})
				filter["uniqueId"] = uniqueId
				filter["workFlag"] = 0
				filter["status"] = 1

				msgList, err := l.svcCtx.WriteDB.PersonalTalkMessageRecord.FindAll(l.ctx, filter)
				if err != nil {
					l.Errorf("report_list_error_8, err: %v, filter: %v", err, filter)
					return nil, err
				}

				arr := make([]types.TalkMessageItem, 0)
				for _, item := range msgList {

					tmp := &types.TalkMessageItem{}
					err = copier.Copy(tmp, item)
					if err != nil {
						l.Errorf("report_list_error_9, err: %v", err)
						return nil, err
					}

					if tmp.ObjectId != "" {
						tmp.ObjectId = utils.FixImageUrl(l.svcCtx.Config.ImageHost, tmp.ObjectId)
					}
					arr = append(arr, *tmp)
				}

				reportDetail.Messages = arr
			}
		}

		// 举报或抓捕的用户
		reportUsers := make([]types.QueryReportUser, 0)
		{
			filter := make(map[string]interface{})
			filter["reportId"] = reportDetail.ID

			opt := &options.FindOptions{}

			tmpReportUserList, err := l.svcCtx.WriteDB.SecretReportUser.FindAll(l.ctx, filter, opt)
			if err != nil {
				l.Errorf("report_list_error_10, err: %v, filter: %v, opt: %v", err, filter, opt)
				return nil, err
			}

			for _, item := range tmpReportUserList {
				reportUser := &types.QueryReportUser{}

				err = copier.Copy(reportUser, &item)
				if err != nil {
					l.Errorf("report_list_error_11, err: %v", err)
					return nil, err
				}

				info, err := l.QueryUserInfo(reportUser.ReportUserId)
				if err != nil {
					l.Errorf("report_list_error_12, %v, err: %v", reportUser.ReportUserId, err)
					continue
				}
				reportUser.UserInfo = *info
				reportUsers = append(reportUsers, *reportUser)
			}
		}

		retList = append(retList, types.QueryReportItem{
			Item:        *reportDetail,
			ReportUsers: reportUsers,
		})
	}

	resp = &types.QueryReportResp{
		Total: count,
		List:  retList,
	}

	return resp, nil
}

func (l *QueryReportListLogic) QueryUserInfo(id int64) (*types.UserInfo, error) {

	userInfo, err := l.svcCtx.WriteDB.UserInfo.FindByUserId(l.ctx, id)
	if err != nil {
		return nil, err
	}

	tmp := &types.UserInfo{}

	err = copier.Copy(tmp, &userInfo)
	if err != nil {
		return nil, err
	}

	if len(tmp.Photo) > 0 {
		tmp.Photo = utils.FixImageUrl(l.svcCtx.Config.ImageHost, tmp.Photo)
	} else if len(userInfo.OpenPhoto) > 0 {
		tmp.Photo = userInfo.OpenPhoto
	}

	// secretMemberInfo
	//members, err := l.svcCtx.ManagerDB.SecretMemberInfo.FindOne(l.ctx, tmp.UserID)

	return tmp, nil
}

func genUniqueId(fromUserId, toUserId, workId int64, modeType int32) int32 {
	var builder strings.Builder
	if fromUserId < toUserId {
		builder.WriteString(strconv.Itoa(int(fromUserId)))
		builder.WriteString(strconv.Itoa(int(toUserId)))
	} else {
		builder.WriteString(strconv.Itoa(int(toUserId)))
		builder.WriteString(strconv.Itoa(int(fromUserId)))
	}
	builder.WriteString(strconv.Itoa(int(modeType)))
	if workId > 0 {
		builder.WriteString(strconv.Itoa(int(workId)))
	}
	return utils.HashCode(builder.String())
}
