package utils

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestRCEncAndDec(t *testing.T) {
	input := "hello rc4!"
	enc := RC4([]byte(input))
	t.Log(string(enc))

	dec := RC4(enc)
	t.Log(string(dec))

	assert.Equal(t, input, string(dec))
}
