package model

const SmsRecordCollectionName = "smsRecord"

type SmsRecord struct {
	ID        int64  `bson:"_id" json:"_id"`
	Type      string `bson:"type,omitempty" json:"type,omitempty"`
	Phone     string `bson:"phone,omitempty" json:"phone,omitempty"`
	Code      string `bson:"code,omitempty" json:"code,omitempty"`
	Timestamp int64  `bson:"timestamp,omitempty" json:"timestamp,omitempty"`
}
