package const_busi

// redis value
const (
	AdFeedbackNil = iota
	_
	AdFeedbackFormChannel // 来自渠道
	_                     // 来自app 该值为userId
)

const (
	BehaviorTypeActivate         = 1 // 自定义激活
	BehaviorTypeRegister         = 2 // 自定义注册
	BehaviorTypePay              = 3 // 自定义付费
	BehaviorTypeNextDayRetention = 4 // 自定义次留
)
