package content_mng

import (
	"content_svr/pub/logger"
	"context"
)

// false-不封禁 ture-封禁
func (p *ContentMng) AclCheck(ctx context.Context, appType int32, userId int64) bool {
	coo := p.DataCache.GetUserCoordinateRedis(ctx, userId)
	if coo == nil {
		logger.Error(ctx, "AclCheck failed, get Coordinate failed", nil)
		return false
	}
	bForbid := p.InnerProxy.AclForbid(ctx, appType, coo)
	return bForbid
}
