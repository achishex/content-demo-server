package job

import (
	"content_svr/config"
	"content_svr/db/aggregation"
	"content_svr/db/dao"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"time"
)

type notifyMoneyControl struct {
	write, read *dao.ManagerDB
	sumDb       *aggregation.SumManage
}

func newNotifyMoneyControl(write, read *dao.ManagerDB) *notifyMoneyControl {
	return &notifyMoneyControl{
		write: write,
		read:  read,
		sumDb: aggregation.NewSumManage(read, write),
	}
}

func InitMoneyRobot(write, read *dao.ManagerDB) {
	ctx := requestid.WithRequestID(context.Background())
	target := time.Now().AddDate(0, 0, -1)
	ctrl := newNotifyMoneyControl(write, read)
	if err := ctrl.DoTask(ctx, target); err != nil {
		logger.Error(context.Background(), "InitMoneyRobot:", err)
	}

}

func InitMoneyRobotDetail(write, read *dao.ManagerDB) {
	ctx := requestid.WithRequestID(context.Background())
	target := time.Now() //.AddDate(0, 0, -1)
	ctrl := newNotifyMoneyControl(write, read)
	if err := ctrl.DoTaskBy30Min(ctx, target); err != nil {
		logger.Error(context.Background(), "InitCSJ:", err)
	}
}

func (r notifyMoneyControl) DoTask(ctx context.Context, targetTime time.Time) error {
	logger.Infof(ctx, "notifyMoneyControl do task begin")
	filter := map[string]interface{}{
		"day": utils.ZeroTime(targetTime).UnixMilli(),
	}

	data, err := r.read.SuperiorAwardDaily.FindOne(ctx, filter)
	if err != nil {
		logger.Error(ctx, "SuperiorAwardDaily.FindOne", err)
		return err
	}

	var memberSum float64
	if member, err := r.read.UserMemberStatistical.FindOne(ctx, filter); err == nil {
		memberSum = float64(member.PriceSum)
	} else {
		logger.Error(ctx, "UserMemberStatistical.FindOne", err)
	}

	var revenueSum float64
	filter = map[string]interface{}{
		"date": targetTime.Format("2006-01-02"),
	}
	if csjList, err := r.read.CsjAdvertisementData.FindAll(ctx, filter); err == nil {
		for _, csj := range csjList {
			revenueSum += csj.Revenue
		}
	} else {
		logger.Error(ctx, "CsjAdvertisementData.FindOne", err)
	}

	logger.Infof(ctx, "notifyMoneyControl do task begin send msg")

	var sum uint
	sum = data.AwardSettlementSum +
		data.FirstWorkSettlementSum +
		data.HallOfFameAwardSettlementSum +
		data.PartnerInviteReward +
		data.PartnerCarveUp +
		data.SignLevelUpAwardSum +
		data.AwardViewWorkSum +
		data.AwardGameTimeSum +
		data.AwardSportAdSum +
		data.AwardStarSignAdSum +
		data.AwardSignAdSum +
		data.AwardGroupByCreateSum +
		data.AwardGroupUserByActiveSum +
		data.AwardCommentFirstSum +
		data.AwardBindWechatSum

	SumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("奖励总和: %.2f\n", float64(sum)/100),
	}
	CsjSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("穿山甲广告: %.2f\n", revenueSum),
	}
	MemberSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("当天充值: %.2f\n", memberSum/100),
	}
	AwardSettlementSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("优质动态结算奖励总和: %.2f\n", float64(data.AwardSettlementSum)/100),
	}
	DeductionIllegalSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("违规扣除总和: %.2f\n", float64(data.DeductionIllegalSum)/100),
	}
	FirstWorkSettlementSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("首条动态奖励总和: %.2f\n", float64(data.FirstWorkSettlementSum)/100),
	}
	WechatPayWithdrawSuccessSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("微信提现成功总和: %.2f\n", float64(data.WechatPayWithdrawSuccessSum)/100),
	}
	WechatPayWithdrawFailSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("微信提现失败总和: %.2f\n", float64(data.WechatPayWithdrawFailSum)/100),
	}
	HallOfFameAwardSettlementSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("排行榜奖励总和: %.2f\n", float64(data.HallOfFameAwardSettlementSum)/100),
	}
	PartnerInviteRewardSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("合伙人邀请奖励总和: %.2f\n", float64(data.PartnerInviteReward)/100),
	}
	PartnerCarveUpSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("合伙人瓜分奖励总和: %.2f\n", float64(data.PartnerCarveUp)/100),
	}
	SignLevelUpAwardSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("签到升级红包奖励总和: %.2f\n", float64(data.SignLevelUpAwardSum)/100),
	}
	AwardBindWechatSumMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("绑定微信奖励: %.2f\n", float64(data.AwardBindWechatSum)/100),
	}
	//GameSumMessage := plain{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天游戏充值总和: %.2f\n", float64(data.GameSum)/100),
	//}
	//AwardViewWorkSumSumMessage := plain{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天浏览动态奖励总和: %.2f\n", float64(data.AwardViewWorkSum)/100),
	//}
	//AwardGameTimeSumMessage := plain{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天玩游戏时长奖励总和: %.2f\n", float64(data.AwardGameTimeSum)/100),
	//}
	//AwardSportAdSumMessage := plain{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天观看运动广告奖励总和: %.2f\n", float64(data.AwardSportAdSum)/100),
	//}
	//AwardStarSignAdSumMessage := plain{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天观看星座广告奖励总和: %.2f\n", float64(data.AwardStarSignAdSum)/100),
	//}
	//AwardSignAdSumMessage := plain{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天观看签到广告奖励总和: %.2f\n", float64(data.AwardSignAdSum)/100),
	//}
	//AwardGroupByCreateSumMessage := plain{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天创建群聊奖励总和: %.2f\n", float64(data.AwardGroupByCreateSum)/100),
	//}
	//AwardGroupUserByActiveSumMessage := plain{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天群活跃人数奖励总和: %.2f\n", float64(data.AwardGroupUserByActiveSum)/100),
	//}
	//AwardCommentFirstSumMessage := plain{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天首条评论奖励总和: %.2f\n", float64(data.AwardCommentFirstSum)/100),
	//}

	items := []plain{
		SumMessage,
		CsjSumMessage,
		MemberSumMessage,
		//GameSumMessage,
		AwardSettlementSumMessage,
		DeductionIllegalSumMessage,
		FirstWorkSettlementSumMessage,
		WechatPayWithdrawSuccessSumMessage,
		WechatPayWithdrawFailSumMessage,
		HallOfFameAwardSettlementSumMessage,
		PartnerInviteRewardSumMessage,
		PartnerCarveUpSumMessage,
		SignLevelUpAwardSumMessage,
		AwardBindWechatSumMessage,
		//AwardViewWorkSumSumMessage,
		//AwardGameTimeSumMessage,
		//AwardSportAdSumMessage,
		//AwardStarSignAdSumMessage,
		//AwardSignAdSumMessage,
		//AwardGroupByCreateSumMessage,
		//AwardGroupUserByActiveSumMessage,
		//AwardCommentFirstSumMessage,
	}

	day, _ := utils.TimeByDay(targetTime)
	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = fmt.Sprintf("%d 结算统计", day)
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	if config.ServerConfig.Env == "test" {
		RobotServerControl.SendMessage(m)
	} else {
		RobotBossControl.SendMessage(m)
	}

	//RobotServerControl.SendMessage(m)

	logger.Infof(ctx, "notifyMoneyControl do task finish send msg")

	// 统计完成后当天早上8点再发通知
	//now := time.Now()
	//target := time.Date(now.Year(), now.Month(), now.Day(), 8, 0, 0, 0, now.Location())
	//r.SendMessageAfterTime(m, target.Sub(now))

	return nil
}

func (r notifyMoneyControl) DoTaskBy30Min(ctx context.Context, targetTime time.Time) error {
	messageColumn := make([]plain, 0)
	dataMap := map[string]uint{
		"ios":     0,
		"android": 0,
	}
	nowZero := utils.ZeroTime(targetTime)
	member, err := r.sumDb.Member.Today(ctx)
	if err != nil {
		return err
	}

	//logx.Infof("ios,member len,UserMember=%v", len(member))

	for _, statistical := range member {
		ct := utils.ZeroTime(time.UnixMilli(statistical.Day))

		if ct.Sub(nowZero) != 0 {
			continue
		}

		dataMap["ios"] = statistical.IosSum
		dataMap["android"] = statistical.AndroidSum

		break
	}

	messageColumn = append(messageColumn, plain{
		Tag:  "text",
		Text: fmt.Sprintf("当天ios充值总和: %.2f\n", float64(dataMap["ios"])/100),
	})
	messageColumn = append(messageColumn, plain{
		Tag:  "text",
		Text: fmt.Sprintf("当天android充值总和: %.2f\n", float64(dataMap["android"])/100),
	})

	dataMap = map[string]uint{}
	gameList, err := r.read.SecretGame.FindAll(ctx, map[string]interface{}{})
	if err != nil {
		return err
	}
	for _, game := range gameList {
		dataMap[game.GameName] = 0
	}

	gameStatistical, err := r.sumDb.Game.Today(ctx)
	for _, statistical := range gameStatistical {
		_, ok := dataMap[statistical.GameName]
		if ok {
			dataMap[statistical.GameName] = statistical.AmountSum
		}
	}
	for gameName, amount := range dataMap {
		messageColumn = append(messageColumn, plain{
			Tag:  "text",
			Text: fmt.Sprintf("当天游戏-%s充值总和: %.2f\n", gameName, float64(amount)/100),
		})
	}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = fmt.Sprintf("%s 充值统计", targetTime.Format("2006-01-02 15:04:05"))
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, messageColumn)

	if config.ServerConfig.Env == "test" {
		RobotServerControl.SendMessage(m)
	} else {
		RobotBossControl.SendMessage(m)
	}

	return nil
}
