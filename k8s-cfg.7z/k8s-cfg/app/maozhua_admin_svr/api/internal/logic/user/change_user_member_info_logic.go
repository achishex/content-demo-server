package user

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mongodb/model"
	"content_svr/pub/snow_flake"
	"context"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type ChangeUserMemberInfoLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewChangeUserMemberInfoLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ChangeUserMemberInfoLogic {
	return &ChangeUserMemberInfoLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

const (
	_          = iota
	typeDay    // 7 day
	typeMonth  // 31 day
	typeCancel // 取消会员
)

func (l *ChangeUserMemberInfoLogic) ChangeUserMemberInfo(req *types.ChangeUserMemberInfoReq) (resp *types.ChangeUserMemberInfoResp, err error) {
	var duration time.Duration
	switch req.Type {
	case typeDay:
		duration = time.Hour * 24 * 7 // 7 day
	case typeMonth:
		duration = time.Hour * 24 * 31 // 31 day
	case typeCancel:
		duration = -1
	}

	now := time.Now()
	var expire = now.Add(duration).UnixMilli()
	var userMemberType int32 = 3 //普通vip

	newMember := &model.SecretMemberInfo{
		//ID:        0,
		UserId:    req.UserId,
		Type:      userMemberType,
		Expire:    expire,
		Timestamp: now.UnixMilli(),
		Enable:    true,
		RepairNo:  1,
	}
	member, err := l.svcCtx.ManagerDB.SecretMemberInfo.FindOne(l.ctx, map[string]interface{}{
		"userId": req.UserId,
	})
	switch err {
	case xerr.DbNotFound:
		newMember.ID = snow_flake.GetSnowflakeID()
		_, err := l.svcCtx.ManagerDB.SecretMemberInfo.Insert(l.ctx, newMember)
		return nil, err
	case nil:
		newMember.ID = member.ID

		switch {
		case req.Type == typeCancel:
			break
		case member.Enable == true && member.Expire > now.UnixMilli():
			newMember.Type = member.Type
			newMember.Expire = time.UnixMilli(member.Expire).Add(duration).UnixMilli()
		}

		err = l.svcCtx.ManagerDB.SecretMemberInfo.Update(l.ctx, newMember)
		return
	default:
		return nil, err
	}

}
