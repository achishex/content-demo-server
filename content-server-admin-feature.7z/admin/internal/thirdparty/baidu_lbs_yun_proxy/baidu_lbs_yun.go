package baidu_lbs_yun_proxy

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"strconv"
	"strings"
)

func (p *BaiduLbsYunProxyImpl) ReverseGeocodingV2(ctx context.Context, lat float64, lng float64, ip string) (*pbapi.CoordinateRedis, error) {
	if lat == 0 || lng == 0 {
		return &pbapi.CoordinateRedis{}, nil
	}
	uri := fmt.Sprintf("/reverse_geocoding/v3/?ak=%s&output=json&coordtype=%s&ret_coordtype=%s&location=%v,%v",
		p.Ak, "wgs84ll", "bd09ll", lat, lng)
	sn := p.Sign(ctx, uri)
	url := fmt.Sprintf("%v%v&sn=%v", p.Host, uri, sn)
	// req
	sResp, err := p.getRequest(ctx, url)
	if err != nil {
		logger.Errorf(ctx, "baidu_location,1,err=%v", err)
		return nil, err
	}
	sRespBytes, err := io.ReadAll(sResp.Body)
	if err != nil {
		logger.Errorf(ctx, "baidu_location,2,err=%v", err)
		return nil, err
	}

	// 解析
	BResp := &ReverseGeocodingResp{}
	err = json.Unmarshal(sRespBytes, BResp)
	if err != nil {
		logger.Errorf(ctx, "baidu_location,3,err=%v", err)
		return nil, err
	}

	country := BResp.Result.AddressComponent.Country
	province := strings.Replace(BResp.Result.AddressComponent.Province, "省", "", -1)
	province = strings.Replace(province, "市", "", -1)

	city := strings.Replace(BResp.Result.AddressComponent.City, "市", "", -1)
	if len(city) == 0 && BResp.Result.AddressComponent.CityLevel == 2 { // 优先一级市
		city = strings.Replace(BResp.Result.AddressComponent.District, "市", "", -1)
	}

	resp := &pbapi.CoordinateRedis{
		Longitude: lng,
		Latitude:  lat,
		Ip:        ip,
		Country:   country,
		Province:  province,
		City:      city,
		District:  "",
	}

	logger.Infof(ctx, "coordinate_location,baidu ReverseGeocodingV2, lng %v, lat %v,ip %v, province %v, city %v, result %+v", lng, lat, ip, resp.GetProvince(), resp.GetCity(), BResp.Result.AddressComponent)
	return resp, nil
}

func (p *BaiduLbsYunProxyImpl) GetIpAddressV2(ctx context.Context, ip string) (*pbapi.CoordinateRedis, error) {
	uri := fmt.Sprintf("/location/ip?ak=%s&ip=%s&coor=bd09ll", p.Ak, ip)
	sn := p.Sign(ctx, uri)
	url := fmt.Sprintf("%v%v&sn=%v", p.Host, uri, sn)
	// req
	sResp, err := p.getRequest(ctx, url)
	if err != nil {
		logger.Errorf(ctx, "baidu_location,4,err=%v", err)
		return nil, err
	}
	sRespBytes, err := io.ReadAll(sResp.Body)
	if err != nil {
		logger.Errorf(ctx, "baidu_location,5,err=%v", err)
		return nil, err
	}

	// 解析
	BResp := &GetIpAddressResp{}
	err = json.Unmarshal(sRespBytes, BResp)
	if err != nil {
		logger.Errorf(ctx, "baidu_location,6,err=%v", err)
		return nil, err
	}

	var x float64 = 0
	var y float64 = 0
	s, err := strconv.ParseFloat(BResp.Content.Point.X, 64)
	if err != nil {
		//logger.Errorf(ctx, "quding baidu_location,7,err=%v, province %v", err, BResp.Content.AddressDetail.Province)
		return nil, err
	}
	x = s
	s, err = strconv.ParseFloat(BResp.Content.Point.Y, 64)
	if err != nil {
		logger.Errorf(ctx, "baidu_location,8,err=%v", err)
		return nil, err
	}
	y = s

	province := strings.Replace(BResp.Content.AddressDetail.Province, "省", "", -1)
	province = strings.Replace(province, "市", "", -1)
	city := strings.Replace(BResp.Content.AddressDetail.City, "市", "", -1)

	resp := &pbapi.CoordinateRedis{
		Longitude: x,
		Latitude:  y,
		Ip:        ip,
		Country:   "",
		Province:  province,
		City:      city,
		District:  "",
	}

	logger.Infof(ctx, "coordinate_location,baidu GetIpAddressV2, lng %v, lat %v,ip %v, province %v, city %v,result %+v", resp.GetLongitude(), resp.GetLatitude(), ip, resp.GetProvince(), resp.GetCity(), BResp.Content.AddressDetail)
	return resp, nil
}
