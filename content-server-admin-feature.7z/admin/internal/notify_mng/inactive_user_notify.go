package notify_mng

import (
	"content_svr/internal/data_cache"
	"content_svr/internal/kafka_proxy"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/taskq"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"strconv"
	"time"
)

const (
	InactiveUserNotifyTaskType = "InactiveUserNotifyTaskType"
)

func NewInactiveUserNotifyComp(
	tq *taskq.TaskQ,
	dc data_cache.IDataCacheMng,
	k kafka_proxy.IKafkaProxy,
) *InactiveUserNotifyComp {

	c := &InactiveUserNotifyComp{
		tq: tq,
		dc: dc,
		k:  k,
	}
	tq.Register(InactiveUserNotifyTaskType, c.taskHandler) //注册任务处理
	return c
}

// InactiveUserNotifyComp 不活跃用户通知
//
//		1 注册时间未超过一周的新注册用户，第二天下午7点前未登陆
//		2 老用户7天未活跃
//	 跳到首页
type InactiveUserNotifyComp struct {
	tq *taskq.TaskQ
	dc data_cache.IDataCacheMng
	k  kafka_proxy.IKafkaProxy
}

func (c *InactiveUserNotifyComp) SubmitNotifyTask(ctx context.Context, userID int64) error {
	if userID <= 0 {
		logger.Warnf(ctx, "wrong userID: %v", userID)
		return nil
	}

	ui, err := c.dc.GetUserBasicInfo(ctx, userID, false)
	if err != nil {
		return err
	}

	if ui == nil {
		logger.Warnf(ctx, "user not found, userID: %v", userID)
		return nil
	}

	createTimeStr := ui.GetCreateTime()
	if createTimeStr == "" {
		return nil
	}

	createTime, err := c.parseTime(createTimeStr)
	if err != nil {
		logger.Warnf(ctx, "malformed time: %v", createTime)
		return nil
	}

	// 7天后 19:00 通知
	notifyAt := utils.Today(19, 0, 0).AddDate(0, 0, 7)
	if time.Now().AddDate(0, 0, -7).Before(createTime) {
		// 1天后
		notifyAt = utils.Today(19, 0, 0).AddDate(0, 0, 1)
	}

	task := &taskq.TaskMsg{
		UserID:   strconv.FormatInt(userID, 10),
		TaskType: InactiveUserNotifyTaskType,
		TaskID:   c.notifyTaskID(userID),
	}
	delay := notifyAt.Sub(time.Now()) + utils.RandDur(time.Minute*10) //增加10min随机时延，防止同时间任务堆积
	_, err = c.tq.Submit(ctx, task, delay)
	return err
}

func (c *InactiveUserNotifyComp) parseTime(timeStr string) (time.Time, error) {
	if timeStr == "" {
		return time.Time{}, errors.New("empty time str")
	}
	timeLayout := "2006-01-02 15:04:05"  //模版
	loc, _ := time.LoadLocation("Local") //获取当前时区
	//使用模版将需要判断的时间在对应时区转化成time.time类型
	theTime, err := time.ParseInLocation(timeLayout, timeStr, loc)
	return theTime, err
}

func (c *InactiveUserNotifyComp) notifyTaskID(userID int64) string {
	return fmt.Sprintf("inactive_user_notify_%v", userID)
}

func (c *InactiveUserNotifyComp) taskHandler(ctx context.Context, msg *taskq.TaskMsg) error {
	logger.Infof(ctx, "InactiveUserNotify, msg: %+v", msg)
	userID, err := strconv.ParseInt(msg.UserID, 10, 64)
	if err != nil {
		return nil
	}
	return c.k.TsnPushInactiveUserMsg(ctx, userID)
}
