package user_level_mng

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"time"
)

func (p *UserLevelMng) GetChitchatInfo(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbuserapi.ChitchatInfo, error) {
	userId, err := p.getUserId(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "get user id by token failed,err=%v", err.Error())
		return nil, errorcode.LOGIN_INVALID
	}

	// case1, 在小黑屋
	blackHouseOutTime, err := p.DataCache.GetImpl().GetUserBlackHouseOutTime(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user id by token failed,err=%v", err.Error())
		return nil, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "用户不存在")
	}
	if time.Now().UnixNano()/1e6 < blackHouseOutTime {
		//在小黑屋
		resp := &pbuserapi.ChitchatInfo{
			UnionStatus:       cm_const.CdKeyUnionStatusInBlackHouse,
			BlackHouseOutTime: blackHouseOutTime,
		}
		return resp, nil
	}

	// 检查激活码
	extInfo, err := p.DataCache.GetImpl().UserInfoExtMgModel.GetAndCreate(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user id by token failed,err=%v", err.Error())
		return nil, errorcode.INTERNAL_ERROR
	}

	// case2
	if extInfo.GetUlevel() < const_level.UserLevel3 {
		//未开启激活码
		resp := &pbuserapi.ChitchatInfo{
			UnionStatus: cm_const.CdKeyUnionStatusWeiKaiQi,
		}
		return resp, nil
	}

	// 获取用户的激活码。 //用户已生成激活码
	if extInfo.GetChitChatCdKey() != "" {
		cdKeyMgItem, err := p.DataCache.GetImpl().SecretChitChatCDKeyMgDbModel.GetByCdKey(ctx, extInfo.GetChitChatCdKey())
		if err != nil {
			logger.Error(ctx, "get SecretChitChatCDKeyMgDbModel failed, ", err)
			return nil, err
		}
		//4-已生成
		dayCfg := p.DataCache.GetTimesConfigLR(ctx, "times_chitchat_cd_key_expire")
		resp := &pbuserapi.ChitchatInfo{
			UnionStatus:  cm_const.CdKeyUnionStatusYiShengCheng,
			ChitchatCode: extInfo.GetChitChatCdKey(),
			Expire:       cdKeyMgItem.GetCreateTime() + dayCfg*86400*1000,
		}
		return resp, nil
	}

	// 激活码生成中
	if extInfo.GetChitChatCdKey() == "" {
		if extInfo.GetNextCDKeyTime() > time.Now().UnixNano()/1e6 {
			//3-生成中
			resp := &pbuserapi.ChitchatInfo{
				UnionStatus:  cm_const.CdKeyUnionStatusShengChengZhong,
				NextCodeTime: extInfo.GetNextCDKeyTime(),
			}
			return resp, nil
		} else {
			//5-待领取
			resp := &pbuserapi.ChitchatInfo{
				UnionStatus: cm_const.CdKeyUnionStatusDaiLingQu,
			}
			return resp, nil
		}
	}

	logger.Infof(ctx, "not match any case, return weikaiqi, extInfo=%v",
		utils.StructToJsonString(extInfo))
	resp := &pbuserapi.ChitchatInfo{
		UnionStatus: cm_const.CdKeyUnionStatusWeiKaiQi,
	}
	return resp, nil
}
