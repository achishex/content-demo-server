package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"errors"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type IPartnerDailySignInMgModel interface {
	FindOne(ctx context.Context, filter any) (*pbmgdb.PartnerDailySignInMgDbModel, error)
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.PartnerDailySignInMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.PartnerDailySignInMgDbModel, options ...*options.InsertOneOptions) error
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
	CountByCondition(ctx context.Context, filter any, opts ...*options.CountOptions) int64
}

type PartnerDailySignInMgModel struct {
	MgDB  *mongo.Database
	Table string
}

func NewPartnerDailySignInMgModel(db *mongo.Database) IPartnerDailySignInMgModel {
	return &PartnerDailySignInMgModel{
		MgDB:  db,
		Table: "partner_daily_sign_in",
	}
}

func (g *PartnerDailySignInMgModel) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *PartnerDailySignInMgModel) FindOne(ctx context.Context, filter any) (*pbmgdb.PartnerDailySignInMgDbModel, error) {
	var v *pbmgdb.PartnerDailySignInMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if errors.Is(err, mongo.ErrNoDocuments) {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PartnerDailySignIn FindOne failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *PartnerDailySignInMgModel) Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.PartnerDailySignInMgDbModel, error) {
	find, err := g.coll().Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	retItems := make([]*pbmgdb.PartnerDailySignInMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.PartnerDailySignInMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to Partner failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (g *PartnerDailySignInMgModel) Create(ctx context.Context, data *pbmgdb.PartnerDailySignInMgDbModel, options ...*options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data, options...)

	if err != nil {
		logger.Errorf(ctx, "PartnerDailySignIn:Create error : %v", err)
		return err
	}

	return nil
}

func (g *PartnerDailySignInMgModel) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "PartnerDailySignIn:updateOne error: %v", err)
		return err
	}

	return nil
}

func (g *PartnerDailySignInMgModel) CountByCondition(ctx context.Context, filter any, opts ...*options.CountOptions) int64 {
	c, err := g.coll().CountDocuments(ctx, filter, opts...)
	if err != nil {
		return 0
	}

	return c
}
