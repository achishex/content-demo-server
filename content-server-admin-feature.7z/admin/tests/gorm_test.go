package tests

import (
	"content_svr/internal/model"
	"content_svr/internal/vip_mng"
	"content_svr/protobuf/pbdb"
	"github.com/stretchr/testify/assert"
	"gorm.io/gorm"
	"testing"
)

func TestLocTime(t *testing.T) {
	e := c.Invoke(func(pdb model.ParseTimeDB) error {
		db := (*gorm.DB)(pdb)

		m := pbdb.WorkCommentStatusDbModel{}
		err := db.Table("works_comment_status").First(&m).Error
		if err != nil {
			return err
		}

		t.Log(m.GetCreateTime())

		order := &vip_mng.VipOrderInfo{}
		err = db.Model(&vip_mng.VipOrderInfo{}).First(order).Error
		if err != nil {
			return err
		}
		t.Log(order)
		return nil
	})

	assert.Nil(t, e)
}
