package monitor

import (
	"content_svr/db/mongodb/model"
	"content_svr/pub/snow_flake"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"strings"
	"time"
)

func (w *Worker) doComment(params interface{}) {
	var commentId, workId int64
	switch params.(type) {
	case float64:
		commentId = snow_flake.GetSnowflakeID()
		workId = int64(params.(float64))
	case int64:
		// 值为 workId
		commentId = snow_flake.GetSnowflakeID()
		workId = params.(int64)
	case map[string]interface{}:
		// 将commentId 自增1
		value := params.(map[string]interface{})
		workId = int64(value["work_id"].(float64))
		commentId = int64(value["_id"].(float64))
		commentId += 1
	case nil:
		return
	}
	// 发评论
	now := time.Now()
	nowFormat := now.Format("2006-01-02 15:04:05.000")
	if w.robot.Icon != nil && w.robot.Icon.Text == "" {
		w.robot.Icon = nil
	}

	comment := &model.WorksCommentDetail{
		ID:            commentId,
		WorkId:        workId,
		UserId:        w.robot.UserId,
		Comment:       w.robot.Comment,
		Longitude:     0,
		Latitude:      0,
		Ip:            "183.14.134.118",
		Province:      "猫爪宇宙总部",
		City:          "猫爪宇宙总部",
		Status:        1,
		CreateTime:    nowFormat,
		UpdateTime:    nowFormat,
		LikedCount:    0,
		CommentType:   w.robot.CommentType,
		CommentObject: w.robot.CommentObject,
		Jump:          w.robot.Jump,
		Icon:          w.robot.Icon,
	}
	_, err := w.monitor.manageDB.WorksCommentDetail.Insert(w.ctx, comment)
	if err != nil {
		if strings.Contains(err.Error(), "E11000") {
			comment.ID = snow_flake.GetSnowflakeID()
			_, err := w.monitor.manageDB.WorksCommentDetail.Insert(w.ctx, comment)
			if err != nil {
				logx.Error(w.ctx, fmt.Sprintf("userid机器人: %d 异常", w.robot.UserId), err)
				return
			}
		} else {
			logx.Error(w.ctx, fmt.Sprintf("userid机器人: %d 异常", w.robot.UserId), err)
			return
		}

	}

	if err := w.monitor.manageDB.PersonalBottleWorks.IncNewCommentCount(w.ctx, workId, 1); err != nil {
		logx.Error(w.ctx, fmt.Sprintf("userid机器人: %d 异常", w.robot.UserId), err)
		return
	}

	return
}
