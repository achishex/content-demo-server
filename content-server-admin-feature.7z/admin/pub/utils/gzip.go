package utils

import (
	"bytes"
	"compress/gzip"
	"io"
)

func GZip(bs []byte) []byte {
	if len(bs) == 0 {
		return nil
	}

	var b bytes.Buffer
	w := gzip.NewWriter(&b)
	_, _ = w.Write(bs)
	_ = w.Close()

	return b.Bytes()
}

func GUnZip(bs []byte) ([]byte, error) {
	if len(bs) == 0 {
		return nil, nil
	}

	var b bytes.Buffer
	r, err := gzip.NewReader(bytes.NewReader(bs))
	if err != nil {
		return nil, err
	}
	_, err = io.Copy(&b, r)
	if err != nil {
		return nil, err
	}
	return b.Bytes(), nil
}
