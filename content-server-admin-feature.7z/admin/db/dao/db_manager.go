package dao

import (
	"content_svr/db/dao/cache"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type ManagerDB struct {
	// cache mysql
	*cache.PersonalBottleWorks
	*cache.UserInfo
	// cache mongo
	*cache.MzRobot
	*cache.BackgroundImage
	*cache.SecretUserExtInfo
	*cache.SecretMemberInfo
	*cache.SecretBlackHouse
	*cache.UserRewardMoneyActivity

	// mysql
	*query.Query

	// mongo
	*query_mng.QueryMng
}

func NewDbManager(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *ManagerDB {
	m := &ManagerDB{
		Query:    mysql,
		QueryMng: mongo,

		PersonalBottleWorks: cache.NewCachePersonalBottleWorks(mysql, mongo, redisManage),
		UserInfo:            cache.NewCacheUserInfo(mysql, mongo, redisManage),

		MzRobot:                 cache.NewCacheMzRobot(mysql, mongo, redisManage),
		BackgroundImage:         cache.NewCacheBackgroundImage(mysql, mongo, redisManage),
		SecretUserExtInfo:       cache.NewCacheSecretUserExtInfo(mysql, mongo, redisManage),
		SecretMemberInfo:        cache.NewCacheSecretMemberInfo(mysql, mongo, redisManage),
		SecretBlackHouse:        cache.NewCacheSecretBlackHouse(mysql, mongo, redisManage),
		UserRewardMoneyActivity: cache.NewCacheUserRewardMoneyActivity(mysql, mongo, redisManage),
	}

	return m
}
