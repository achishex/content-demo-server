package model

import "go.mongodb.org/mongo-driver/bson/primitive"

const collectionNameGameStatistical = "gameStatistical"

type GameStatistical struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	GameId    string `json:"game_id" bson:"game_id"`       // 游戏id
	GameName  string `json:"game_name" bson:"game_name"`   // 游戏名称
	AmountSum uint   `json:"amount_sum" bson:"amount_sum"` // 金额统计

	Day        int64 `json:"day" bson:"day"`                                     // 统计那一天，时间戳
	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` //创建时间
	UpdateTime int64 `json:"update_time,omitempty" bson:"update_time,omitempty"` //更新时间
}
