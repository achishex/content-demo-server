package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type PersonalPoliceDailyData struct {
	model.PersonalPoliceDailyDataModel
	redisManage *query_rds.Manage
}

func NewCachePersonalPoliceDailyData(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *PersonalPoliceDailyData {
	return &PersonalPoliceDailyData{
		PersonalPoliceDailyDataModel: mongo.PersonalPoliceDailyData,
		redisManage:                  redisManage,
	}
}
