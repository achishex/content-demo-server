package setting

/*
新增配置类型只允许下列格式，否则反射失败
redis tag 没填则自动使用json

	type allSetting struct {
		name struct{
			newConfig `json:"new_config" redis:"redis hash结构下的field" default:"默认值" description:"新配置" category:"分组名"`
		}
	}
*/
type allSetting struct {
	// 关于等级方面的限制
	levelComment
	levelExposure
	levelTalk

	// 私聊消息
	talkMessage

	// 关于用户信息的配置
	userInfo

	// 举报审计
	audit

	// 每日签到&等级提升
	DailySign

	// 官方表情
	OfficialMeme

	AwardConfig

	//群聊
	ImGroup

	// 游戏配置
	GameConfig

	// 用于测试类型
	//testField
}

// testField 用于测试新的类型
type testField struct {
	TestInt     fieldInt     `json:"test_int" redis:"test_int"  default:"123" description:"测试整型类型" category:"test"`
	TestInt32   fieldInt32   `json:"test_int_32" redis:"test_int_32"  default:"123" description:"测试32位整型类型" category:"test"`
	TestInt64   fieldInt64   `json:"test_int_64" redis:"test_int_64"  default:"123" description:"测试64位整型类型" category:"test"`
	TestUint    fieldUint    `json:"test_uint" redis:"test_uint"  default:"123" description:"测试无符号整型类型" category:"test"`
	TestUint32  fieldUint32  `json:"test_uint_32" redis:"test_uint_32"  default:"123" description:"测试无符号32位整型类型" category:"test"`
	TestUint64  fieldUint64  `json:"test_uint_64" redis:"test_uint_64"  default:"123" description:"测试无符号64位整型类型" category:"test"`
	TestFloat64 fieldFloat64 `json:"test_float_64" redis:"test_float_64"  default:"1.23" description:"测试浮点类型" category:"test"`
	TestString  fieldString  `json:"test_string" redis:"test_string"  default:"123" description:"测试字符串类型" category:"test"`
}

// 评论最大数量等级限制
type levelComment struct {
	OfficialWorkSingleMaxCommentNums fieldInt64 `default:"20" json:"official_work_single_max_comment_nums" description:"官方账号发布的动态被评论允许评论的最大值" category:"level"`
	Level0SingleCommentMax           fieldInt64 `default:"0" json:"level_0_single_comment_max" description:"0级单条评论允许评论的最大值" category:"level"`
	Level1SingleCommentMax           fieldInt64 `default:"4" json:"level_1_single_comment_max" description:"1级单条评论允许评论的最大值" category:"level"`
	Level2SingleCommentMax           fieldInt64 `default:"8" json:"level_2_single_comment_max" description:"2级单条评论允许评论的最大值" category:"level"`
	Level3SingleCommentMax           fieldInt64 `default:"30" json:"level_3_single_comment_max" description:"3级单条评论允许评论的最大值" category:"level"`
	Level4SingleCommentMax           fieldInt64 `default:"60" json:"level_4_single_comment_max" description:"4级单条评论允许评论的最大值" category:"level"`
	Level5SingleCommentMax           fieldInt64 `default:"60" json:"level_5_single_comment_max" description:"5级单条评论允许评论的最大值" category:"level"`
	Level0CommentMax                 fieldInt64 `default:"0" json:"level_0_comment_max" description:"0级每日允许评论总数最大值" category:"level"`
	Level1CommentMax                 fieldInt64 `default:"100" json:"level_1_comment_max" description:"1级每日允许评论总数最大值" category:"level"`
	Level2CommentMax                 fieldInt64 `default:"400" json:"level_2_comment_max" description:"2级每日允许评论总数最大值" category:"level"`
	Level3CommentMax                 fieldInt64 `default:"1000" json:"level_3_comment_max" description:"3级每日允许评论总数最大值" category:"level"`
	Level4CommentMax                 fieldInt64 `default:"2000" json:"level_4_comment_max" description:"4级每日允许评论总数最大值" category:"level"`
	Level5CommentMax                 fieldInt64 `default:"2000" json:"level_5_comment_max" description:"5级每日允许评论总数最大值" category:"level"`
}

type levelTalk struct {
	Level0TalkNewPeopleMaxCount fieldInt32 `default:"0" json:"level_0_talk_people_max_count" description:"0级每日可私聊新用户数" category:"talk_level"`
	Level1TalkNewPeopleMaxCount fieldInt32 `default:"10" json:"level_1_talk_people_max_count" description:"1级每日可私聊新用户数" category:"talk_level"`
	Level2TalkNewPeopleMaxCount fieldInt32 `default:"20" json:"level_2_talk_people_max_count" description:"2级每日可私聊新用户数" category:"talk_level"`
	Level3TalkNewPeopleMaxCount fieldInt32 `default:"30" json:"level_3_talk_people_max_count" description:"3级每日可私聊新用户数" category:"talk_level"`
	Level4TalkNewPeopleMaxCount fieldInt32 `default:"40" json:"level_4_talk_people_max_count" description:"4级每日可私聊新用户数" category:"talk_level"`
	Level5TalkNewPeopleMaxCount fieldInt32 `default:"40" json:"level_5_talk_people_max_count" description:"5级每日可私聊新用户数" category:"talk_level"`
}

// 曝光限制
type levelExposure struct {
	Level0Exposure    fieldInt32 `default:"0" json:"level_0_exposure" description:"0级曝光值" category:"exposure"`
	Level1Exposure    fieldInt32 `default:"20" json:"level_1_exposure" description:"1级曝光值" category:"exposure"`
	Level2Exposure    fieldInt32 `default:"299" json:"level_2_exposure" description:"2级曝光值" category:"exposure"`
	Level3Exposure    fieldInt32 `default:"399" json:"level_3_exposure" description:"3级曝光值" category:"exposure"`
	Level4Exposure    fieldInt32 `default:"599" json:"level_4_exposure" description:"4级曝光值" category:"exposure"`
	Level5Exposure    fieldInt32 `default:"599" json:"level_5_exposure" description:"5级曝光值" category:"exposure"`
	VipLevel0Exposure fieldInt32 `default:"0" json:"vip_level_0_exposure" description:"VIP0级曝光值" category:"exposure"`
	VipLevel1Exposure fieldInt32 `default:"20" json:"vip_level_1_exposure" description:"VIP1级曝光值" category:"exposure"`
	VipLevel2Exposure fieldInt32 `default:"399" json:"vip_level_2_exposure" description:"VIP2级曝光值" category:"exposure"`
	VipLevel3Exposure fieldInt32 `default:"599" json:"vip_level_3_exposure" description:"VIP3级曝光值" category:"exposure"`
	VipLevel4Exposure fieldInt32 `default:"999" json:"vip_level_4_exposure" description:"VIP4级曝光值" category:"exposure"`
	VipLevel5Exposure fieldInt32 `default:"999" json:"vip_level_5_exposure" description:"VIP5级曝光值" category:"exposure"`
}

type talkMessage struct {
	TalkNoReplyMaxCount          fieldUint32 `default:"1" json:"talk_no_reply_max_count" description:"非VIP用户对方未回复最多可发送消息数量" category:"talk"`
	VipTalkNoReplyMaxCount       fieldUint32 `default:"4" json:"vip_talk_no_reply_max_count" description:"私聊开通VIP后对方未回复最多可发送消息数量" category:"talk"`
	TalkByOtherMaxCount          fieldUint32 `default:"55" json:"talk_by_other_max_count" description:"被他人私聊的最大值" category:"talk"`
	TempSessionValidMinute       fieldUint32 `default:"4320" json:"temp_session_valid_minute" description:"临时会话保留时间" category:"talk"`
	TalkMessageValidMinute       fieldUint32 `default:"4320" json:"talk_message_valid_minute" description:"私聊信息保留时间" category:"talk"`
	TalkMessageStrangerMaxLength fieldUint32 `default:"20" json:"talk_message_stranger_max_length" description:"单条私信允许的最大长度" category:"talk"`
}

type ImGroup struct {
	MaxGroupLimit         fieldInt32 `default:"5" json:"max_group_limit" description:"允许最大创建群聊数量" category:"im_group"`
	MaxGroupMemberLimit   fieldInt32 `default:"100" json:"max_group_member_limit" description:"允许群聊最大人数" category:"im_group"`
	GroupCreateLevelLimit fieldInt32 `default:"5" json:"group_create_level_limit" description:"创建群等级要求" category:"im_group"`
}

type userInfo struct {
	StarTargetMaxCount fieldInt64 `default:"7" json:"star_target_max_count" description:"星标猫友最大数量" category:"user_info"`
	NewUserByDays      fieldInt32 `default:"4" json:"new_user_by_days" description:"多少天内为新用户" category:"user_info"`
}

type audit struct {
	AwardGroupLength  fieldFloat64 `default:"7" json:"award_group_length" description:"举报奖励一组长度" category:"audit"`
	AwardSuccessCount fieldFloat64 `default:"4" json:"award_success_count" description:"获得奖励需要的举报成功数" category:"audit"`
	AwardFailCount    fieldFloat64 `default:"3" json:"award_fail_count" description:"被封禁需要的举报失败数" category:"audit"`
}

type DailySign struct {
	Level0FullSignTimes          fieldInt32 `default:"0" json:"level_0_full_sign_times" description:"正常用户0级需签到次数" category:"daily_sign"`
	Level1FullSignTimes          fieldInt32 `default:"4" json:"level_1_full_sign_times" description:"正常用户1级需签到次数" category:"daily_sign"`
	Level2FullSignTimes          fieldInt32 `default:"3" json:"level_2_full_sign_times" description:"正常用户2级需签到次数" category:"daily_sign"`
	Level3FullSignTimes          fieldInt32 `default:"2" json:"level_3_full_sign_times" description:"正常用户3级需签到次数" category:"daily_sign"`
	Level4FullSignTimes          fieldInt32 `default:"2" json:"level_4_full_sign_times" description:"正常用户4级需签到次数" category:"daily_sign"`
	Level5FullSignTimes          fieldInt32 `default:"0" json:"level_5_full_sign_times" description:"正常用户5级需签到次数" category:"daily_sign"`
	CodeFullSignTimes            fieldInt32 `default:"4" json:"level_6_full_sign_times" description:"正常用户加速码需签到次数" category:"daily_sign"`
	Level0FullPenaltiesSignTimes fieldInt32 `default:"0" json:"level_0_full_penalties_sign_times" description:"违规用户0级需签到次数" category:"daily_sign"`
	Level1FullPenaltiesSignTimes fieldInt32 `default:"8" json:"level_1_full_penalties_sign_times" description:"违规用户1级需签到次数" category:"daily_sign"`
	Level2FullPenaltiesSignTimes fieldInt32 `default:"4" json:"level_2_full_penalties_sign_times" description:"违规用户2级需签到次数" category:"daily_sign"`
	Level3FullPenaltiesSignTimes fieldInt32 `default:"4" json:"level_3_full_penalties_sign_times" description:"违规用户3级需签到次数" category:"daily_sign"`
	Level4FullPenaltiesSignTimes fieldInt32 `default:"4" json:"level_4_full_penalties_sign_times" description:"违规用户4级需签到次数" category:"daily_sign"`
	Level5FullPenaltiesSignTimes fieldInt32 `default:"4" json:"level_5_full_penalties_sign_times" description:"违规用户5级需签到次数" category:"daily_sign"`
	CodeFullPenaltiesSignTimes   fieldInt32 `default:"4" json:"level_6_full_penalties_sign_times" description:"违规用户加速码需签到次数" category:"daily_sign"`
}

// 此结构的Meme开头的字段名不要修改，添加也以Meme开头
type OfficialMeme struct {
	TotalDisplayQty fieldInt64 `default:"20" json:"total_display_qty" description:"总显示数量，默认20个" category:"meme"`
	OfficialQty     fieldInt64 `default:"4" json:"official_qty" description:"官方表情显示数量，默认4个" category:"meme"`
	Meme1           fieldInt64 `default:"0" json:"meme_1" description:"官方表情1" category:"meme"`
	Meme2           fieldInt64 `default:"0" json:"meme_2" description:"官方表情2" category:"meme"`
	Meme3           fieldInt64 `default:"0" json:"meme_3" description:"官方表情3" category:"meme"`
	Meme4           fieldInt64 `default:"0" json:"meme_4" description:"官方表情4" category:"meme"`
	Meme5           fieldInt64 `default:"0" json:"meme_5" description:"官方表情5" category:"meme"`
	Meme6           fieldInt64 `default:"0" json:"meme_6" description:"官方表情6" category:"meme"`
	Meme7           fieldInt64 `default:"0" json:"meme_7" description:"官方表情7" category:"meme"`
	Meme8           fieldInt64 `default:"0" json:"meme_8" description:"官方表情8" category:"meme"`
	Meme9           fieldInt64 `default:"0" json:"meme_9" description:"官方表情9" category:"meme"`
	Meme10          fieldInt64 `default:"0" json:"meme_10" description:"官方表情10" category:"meme"`
	Meme11          fieldInt64 `default:"0" json:"meme_11" description:"官方表情11" category:"meme"`
	Meme12          fieldInt64 `default:"0" json:"meme_12" description:"官方表情12" category:"meme"`
	Meme13          fieldInt64 `default:"0" json:"meme_13" description:"官方表情13" category:"meme"`
	Meme14          fieldInt64 `default:"0" json:"meme_14" description:"官方表情14" category:"meme"`
	Meme15          fieldInt64 `default:"0" json:"meme_15" description:"官方表情15" category:"meme"`
	Meme16          fieldInt64 `default:"0" json:"meme_16" description:"官方表情16" category:"meme"`
	Meme17          fieldInt64 `default:"0" json:"meme_17" description:"官方表情17" category:"meme"`
	Meme18          fieldInt64 `default:"0" json:"meme_18" description:"官方表情18" category:"meme"`
	Meme19          fieldInt64 `default:"0" json:"meme_19" description:"官方表情19" category:"meme"`
	Meme20          fieldInt64 `default:"0" json:"meme_20" description:"官方表情20" category:"meme"`
}

type AwardConfig struct {
	Level1WorkAward fieldFloat64 `default:"0.1" json:"level_1_work_award" description:"动态满足10个评论的奖励金额" category:"award"`
	Level2WorkAward fieldFloat64 `default:"0.6" json:"level_2_work_award" description:"动态满足50个评论的奖励金额" category:"award"`
}

type GameConfig struct {
	GameDebugUrl fieldString `default:"http://www.baidu.com" json:"game_debug_url" description:"配置测试游戏的url" category:"game"`
}
