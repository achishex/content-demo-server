package util

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
)

var AesUserKey = []byte("eiPJTJcUzz2KMf3DyDMSHfenrcLbmMw4")

func AESEncrypt(plaintext []byte, key []byte) (string, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}

	// 对明文进行填充
	blockSize := block.BlockSize()
	plaintext = pkcs5Padding(plaintext, blockSize)

	ciphertext := make([]byte, len(plaintext))
	mode := cipher.NewCBCEncrypter(block, make([]byte, blockSize))
	mode.CryptBlocks(ciphertext, plaintext)

	// 返回 Base64 编码的密文字符串
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func AESDecrypt(crypt string, key []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	// 解码 Base64 密文字符串
	ciphertextBytes, err := base64.StdEncoding.DecodeString(crypt)
	if err != nil {
		return nil, err
	}

	plaintext := make([]byte, len(ciphertextBytes))
	mode := cipher.NewCBCDecrypter(block, make([]byte, block.BlockSize()))
	mode.CryptBlocks(plaintext, ciphertextBytes)

	// 去除填充字节
	plaintext = pkcs5Unpadding(plaintext)

	return plaintext, nil
}

func PKCS7Padding(origData []byte, blockSize int) []byte {
	padding := blockSize - len(origData)%blockSize
	padText := bytes.Repeat([]byte{byte(padding)}, padding)

	return append(origData, padText...)
}

func PKCS7UnPadding(origData []byte) []byte {
	length := len(origData)
	unPadding := int(origData[length-1])
	return origData[:length-unPadding]
}

func pkcs5Padding(data []byte, blockSize int) []byte {
	padding := blockSize - (len(data) % blockSize)
	padText := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(data, padText...)
}

func pkcs5Unpadding(data []byte) []byte {
	length := len(data)
	unpadding := int(data[length-1])
	return data[:(length - unpadding)]
}
