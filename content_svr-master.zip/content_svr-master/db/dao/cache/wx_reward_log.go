package cache

import (
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type WxRewardLog struct {
	query.WxRewardLog
	redisManage *query_rds.Manage
}

func NewCacheWxRewardLog(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *WxRewardLog {
	return &WxRewardLog{
		WxRewardLog: query.NewWxRewardLog(mysql.WxRewardLog),
		redisManage: redisManage,
	}
}
