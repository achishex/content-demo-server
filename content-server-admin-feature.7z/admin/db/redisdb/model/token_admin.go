package model

import (
	"content_svr/db/redisdb/model/internal"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"time"
)

type TokenAdminRedis struct {
	internal.RdsInfo
}

func NewTokenAdmin(rds *redis.Client, env string) *TokenAdminRedis {
	return &TokenAdminRedis{
		RdsInfo: internal.RdsInfo{
			Env:    env,
			Expire: time.Hour * 24 * 7,
			Client: rds,
		},
	}
}

func (t *TokenAdminRedis) getRdsKey(token string) string {
	return fmt.Sprintf("platform:%v:soul_soup:AdminToken:%v", t.Env, token)
}

func (t *TokenAdminRedis) Auth(token string) (string, error) {
	key := t.getRdsKey(token)
	email, err := t.Client.Get(context.Background(), key).Result()
	if err != nil {
		return "", err
	}

	return email, nil
}

func (t *TokenAdminRedis) SetToken(token, info string) error {
	key := t.getRdsKey(token)
	return t.Client.Set(context.Background(), key, info, t.Expire).Err()
}
