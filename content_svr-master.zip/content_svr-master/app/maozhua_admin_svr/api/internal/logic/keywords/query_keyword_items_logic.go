package keywords

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/app/maozhua_admin_svr/common/xhttp"
	"context"
	"encoding/json"
	"net/url"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type QueryKeywordItemsLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewQueryKeywordItemsLogic(ctx context.Context, svcCtx *svc.ServiceContext) *QueryKeywordItemsLogic {
	return &QueryKeywordItemsLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *QueryKeywordItemsLogic) QueryKeywordItems(req *types.QueryKeywordItemsReq) (resp interface{}, err error) {
	u, err := url.JoinPath(l.svcCtx.Config.CheckContentServe, "/api/platform/keywords/query/")
	if err != nil {
		return nil, err
	}

	body, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}

	response, err := xhttp.Post(u, body)
	if response != nil {
		defer response.Body.Close()
	}
	if err != nil {
		return nil, err
	}

	if response.StatusCode != 200 {
		return nil, xerr.KeywordQueryError
	}

	innerResp := map[string]interface{}{}
	if err := json.NewDecoder(response.Body).Decode(&innerResp); err != nil {
		return nil, err
	}

	return innerResp, nil
}
