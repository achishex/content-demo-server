package const_busi

import "content_svr/setting"

func GetTalkNewPeopleMaxCount(level int32) int32 {
	switch level {
	case UserLevel0:
		return setting.Maozhua.Level0TalkNewPeopleMaxCount.Get()
	case UserLevel1:
		return setting.Maozhua.Level1TalkNewPeopleMaxCount.Get()
	case UserLevel2:
		return setting.Maozhua.Level2TalkNewPeopleMaxCount.Get()
	case UserLevel3:
		return setting.Maozhua.Level3TalkNewPeopleMaxCount.Get()
	case UserLevel4:
		return setting.Maozhua.Level4TalkNewPeopleMaxCount.Get()
	case UserLevel5:
		return setting.Maozhua.Level5TalkNewPeopleMaxCount.Get()
	default:
		return setting.Maozhua.Level0TalkNewPeopleMaxCount.Get()
	}
}
