package util

import (
	"fmt"
	"strconv"
	"time"
)

func TimeByDay(baseTime time.Time) (int, error) {
	dateStr := fmt.Sprintf("%04d%02d%02d", baseTime.Year(), baseTime.Month(), baseTime.Day())
	day, err := strconv.Atoi(dateStr)
	if err != nil {
		return 0, err
	}
	return day, nil
}
