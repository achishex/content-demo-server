package content_mng

import (
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbdb"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"strconv"
	"time"
)

// toUserId 必须>0  workId可以不传
func (p *ContentMng) SetStarSignBirth(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.Birth) error {
	//time.Now().Year()
	//timeStr := fmt.Sprintf("%v-%2d-%2d 00:00:00", time.Now().Year(), req.GetMonth(), req.GetDay())
	//signId := utils.CalculateConstellation(timeStr)
	userInfo, err := p.getUserInfo(ctx, header)
	if err != nil {
		logger.Error(ctx, "SetStarSignBirth failed", err)
		return err
	}
	userId := userInfo.UserInfoDbModel.GetUserId()

	// save 到db
	item := &pbdb.MaoZhuaXingZuoBirthDbModel{
		UserId: &userId,
		Month:  proto.Int32(req.Month),
		Day:    proto.Int32(req.Day),
		Status: proto.Int32(int32(pbconst.BaseTabStatus_valid)),
	}

	_, err = p.DataCache.GetImpl().MaozhuaXingZuoModel.CreateOrUpdate(ctx, item)
	if err != nil {
		logger.Error(ctx, "SetStarSignBirth save to db failed. ", err)
		return err
	}
	return nil
}

// toUserId 必须>0  workId可以不传
func (p *ContentMng) GetStarSignBirth(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.Birth, error) {
	// 获取用户id
	userInfo, err := p.getUserInfo(ctx, header)
	if err != nil {
		logger.Error(ctx, "SetStarSignBirth failed", err)
		return nil, err
	}
	userId := userInfo.UserInfoDbModel.GetUserId()

	// 获取用户设置的birth
	mItem, err := p.DataCache.GetImpl().MaozhuaXingZuoModel.GetItemById(ctx, userId)
	if err != nil {
		return nil, err
	}

	return &pbapi.Birth{
		Month: mItem.GetMonth(),
		Day:   mItem.GetDay(),
	}, nil
}

// toUserId 必须>0  workId可以不传
func (p *ContentMng) GetStarSignInfo(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.StarSignData, error) {
	resp := &pbapi.StarSignData{IsKaiYun: false}
	userInfo, err := p.getUserInfo(ctx, header)
	if err != nil {
		logger.Error(ctx, "SetStarSignBirth failed", err)
		return resp, err
	}
	userId := userInfo.UserInfoDbModel.GetUserId()
	return p.getStarSignInfoBase(ctx, userId)
}

func (p *ContentMng) getStarSignInfoBase(ctx context.Context, userId int64) (*pbapi.StarSignData, error) {
	resp := &pbapi.StarSignData{IsKaiYun: false}
	var month int32 = 1
	var day int32 = 1
	// 获取用户设置的birth
	mItem, err := p.DataCache.GetImpl().MaozhuaXingZuoModel.GetItemById(ctx, userId)
	if err != nil {
		logger.Info(ctx, "GetStarSignInfo getBirthFaile")
		return resp, err
	}
	if mItem == nil {
		return resp, err
	}

	// 已设置开运
	month = mItem.GetMonth()
	day = mItem.GetDay()
	xingZuotimeStr := fmt.Sprintf("%v-%02d-%02d 00:00:00", time.Now().Year(), month, day)

	now := time.Now()
	curDate := fmt.Sprintf("%v%02d%02d", time.Now().Year(), now.Month(), now.Day())
	curDateInt, _ := strconv.Atoi(curDate)
	signId := utils.CalculateConstellation(xingZuotimeStr)
	// 20230609
	resp = p.DataCache.GetSignDailyFortuneMgDBLD(ctx, signId, int32(curDateInt))
	return resp, nil
}
