#! /usr/bin/env bash 

DIR_SCRIPT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"


run_release_prod() {
    echo "运行发布环境  服务"
    cd ${DIR_SCRIPT}/.. 
    docker-compose up ai-rerank-service -d
    echo "check run log......"
    sleep 2
    docker-compose logs ai-rerank-service -n 100
    cd -
}


# 根据参数调用函数
case "$1" in
  prod)
    ${DIR_SCRIPT}/init_env.sh "$1"
    run_release_prod
    ;;

  *)
    echo "未知环境: $1. 请使用 prody"
    exit 1
    ;;
esac