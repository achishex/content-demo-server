package model

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"context"
	"github.com/gogo/protobuf/proto"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
	"gorm.io/plugin/dbresolver"
)

type IPersonalBottleWorksDbModel interface {
	CreateItem(ctx context.Context, model *pbapi.PersonalBottleWorksDbModel) (*pbapi.PersonalBottleWorksDbModel, error)
	GetByWorkId(ctx context.Context, workId int64) (*pbapi.PersonalBottleWorksDbModel, error)
	UpdateVisitorCountCondBatch(ctx context.Context, workId []int64) error
	UpdateNewCommentCountToCount(ctx context.Context, workIds []int64, count int64) error
	UpdateCommentCountCondBatch(ctx context.Context, workIds []int64) error
	UpdateAuthorReplyCountCondBatch(ctx context.Context, workIds []int64) error //更新作者回复标记
	UpdateScopeShowItemWithCond(ctx context.Context, eqConds, lteConds, updateField map[string]interface{}) error
	CountItemsByCondition(ctx context.Context, condition map[string]interface{},
		timeStar, timeEnd string) (total int64, _ error)
	ListItemsByCondition(ctx context.Context, condition map[string]interface{},
		timeStar, timeEnd string, page uint64, size uint64) ([]*pbapi.PersonalBottleWorksDbModel, error)
	ListItemsByCond(ctx context.Context, condition map[string]interface{},
		timeStart, timeEnd string, page, size int32) ([]*pbapi.PersonalBottleWorksDbModel, error)
	GetLastWork(ctx context.Context, condition map[string]any) (*pbapi.PersonalBottleWorksDbModel, error)
}

type PersonalBottleWorksDbModelImpl struct {
	DB *gorm.DB
}

func NewPersonalBottleWorksDbModelImpl(db *gorm.DB) IPersonalBottleWorksDbModel {
	return &PersonalBottleWorksDbModelImpl{DB: db}
}

func (impl *PersonalBottleWorksDbModelImpl) table() string {
	return "personal_bottle_works"
}
func (impl *PersonalBottleWorksDbModelImpl) UpdateScopeShowItemWithCond(ctx context.Context, eqConds, lteConds, updateField map[string]interface{}) error {
	sqlStr := ""
	var sqlVal []interface{}
	for k, v := range eqConds {
		if len(sqlStr) > 0 {
			sqlStr += " AND "
		}
		//
		sqlStr += k + " = ? "
		sqlVal = append(sqlVal, v)
	}

	for k, v := range lteConds {
		if len(sqlStr) > 0 {
			sqlStr += " AND "
		}
		sqlStr += k + " <= ? "
		sqlVal = append(sqlVal, v)
	}
	if len(updateField) <= 0 {
		return errorcode.GenBusiErr(errorcode.IllegalParamFailed, "update field is empty")
	}

	result := impl.DB.WithContext(ctx).Clauses(dbresolver.Write).Table(impl.table()).
		Where(sqlStr, sqlVal...).Updates(updateField)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil
	}

	if result.Error != nil {
		return errors.Wrap(result.Error)
	}
	logger.Infof(ctx, "updated low nums: %v, sql: %v", result.RowsAffected, result.Statement.SQL.String())
	return nil
}

func (impl *PersonalBottleWorksDbModelImpl) CreateItem(ctx context.Context, model *pbapi.PersonalBottleWorksDbModel) (*pbapi.PersonalBottleWorksDbModel, error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Create(model)
	return model, errors.Wrap(result.Error)
}

func (impl *PersonalBottleWorksDbModelImpl) GetByWorkId(ctx context.Context, workId int64) (*pbapi.PersonalBottleWorksDbModel, error) {
	model := pbapi.PersonalBottleWorksDbModel{}
	result := impl.DB.WithContext(ctx).Clauses(dbresolver.Write).Table("personal_bottle_works").
		Where(&pbapi.PersonalBottleWorksDbModel{Id: proto.Int64(workId)}).First(&model)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &model, errors.Wrap(result.Error)
}

func (impl *PersonalBottleWorksDbModelImpl) UpdateVisitorCountCondBatch(ctx context.Context, workIds []int64) error {
	cond := map[string]interface{}{"id": workIds}
	result := impl.DB.WithContext(ctx).Clauses(dbresolver.Write).
		Table("personal_bottle_works").Where(cond).
		UpdateColumn("visitor_count", gorm.Expr("visitor_count  + ?", 1))
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil
	}
	return errors.Wrap(result.Error)
}

func (impl *PersonalBottleWorksDbModelImpl) UpdateNewCommentCountToCount(ctx context.Context, workIds []int64, count int64) error {
	commentCond := clause.Expr{}
	if count > 0 {
		commentCond = gorm.Expr("new_comment_count  + ?", count)
	} else {
		commentCond = gorm.Expr("new_comment_count  - ?", count*-1)
	}
	cond := map[string]interface{}{"id": workIds}
	result := impl.DB.WithContext(ctx).Clauses(dbresolver.Write).
		Table("personal_bottle_works").Where(cond).
		UpdateColumn("new_comment_count", commentCond)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil
	}
	return errors.Wrap(result.Error)
}

func (impl *PersonalBottleWorksDbModelImpl) UpdateCommentCountCondBatch(ctx context.Context, workIds []int64) error {
	cond := map[string]interface{}{"id": workIds}
	result := impl.DB.WithContext(ctx).Clauses(dbresolver.Write).
		Table("personal_bottle_works").Where(cond).
		UpdateColumn("comment_count", gorm.Expr("comment_count  + ?", 1))
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil
	}
	return errors.Wrap(result.Error)
}

// 更新作者已回复的
func (impl *PersonalBottleWorksDbModelImpl) UpdateAuthorReplyCountCondBatch(ctx context.Context, workIds []int64) error {
	cond := map[string]interface{}{"id": workIds}
	result := impl.DB.WithContext(ctx).Clauses(dbresolver.Write).
		Table("personal_bottle_works").Where(cond).
		UpdateColumn("replay_count", gorm.Expr("replay_count  + ?", 1))
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil
	}
	return errors.Wrap(result.Error)
}

func (impl *PersonalBottleWorksDbModelImpl) CountItemsByCondition(ctx context.Context,
	condition map[string]interface{}, timeStar, timeEnd string) (total int64, _ error) {
	qry := impl.DB.WithContext(ctx).Table(impl.table()).Model(&pbapi.PersonalBottleWorksDbModel{}).Where(condition)
	if timeStar != "" && timeEnd != "" {
		qry = qry.Where("create_time > ? and create_time < ?", timeStar, timeEnd)
	}
	result := qry.Count(&total)
	return total, errors.Wrap(result.Error)
}

func (impl *PersonalBottleWorksDbModelImpl) ListItemsByCondition(ctx context.Context,
	condition map[string]interface{}, timeStar, timeEnd string, page uint64, size uint64) ([]*pbapi.PersonalBottleWorksDbModel, error) {
	offset := (page - 1) * size
	var items []*pbapi.PersonalBottleWorksDbModel
	qry := impl.DB.WithContext(ctx).Table(impl.table()).Limit(int(size)).Offset(int(offset)).Where(condition)
	if timeStar != "" && timeEnd != "" {
		qry = qry.Where("create_time > ? and create_time < ?", timeStar, timeEnd)
	}
	result := qry.Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *PersonalBottleWorksDbModelImpl) ListItemsByCond(ctx context.Context, condition map[string]interface{},
	timeStart, timeEnd string, page, size int32) ([]*pbapi.PersonalBottleWorksDbModel, error) {
	offset := (page - 1) * size
	var items []*pbapi.PersonalBottleWorksDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(int(size)).Offset(int(offset)).
		Where(condition).Where("create_time >=? and create_time <= ?", timeStart, timeEnd).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *PersonalBottleWorksDbModelImpl) GetLastWork(ctx context.Context, condition map[string]any) (*pbapi.PersonalBottleWorksDbModel, error) {
	var work pbapi.PersonalBottleWorksDbModel
	if err := impl.DB.WithContext(ctx).Table(impl.table()).
		Where("user_id = ? AND create_time >= ? AND special = ? AND status = ? AND verify_status =?",
			condition["userId"], condition["createTime"], const_busi.WorkSpecialWork, const_busi.WorkStatusValid, const_busi.WorkVerifyStatusIgnore).
		Last(&work).Limit(1).
		Error; err != nil {
		return nil, err
	}
	return &work, nil
}
