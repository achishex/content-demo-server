package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretEmoteAuditRecordMgModel interface {
	FindOne(ctx context.Context, filter any) (*pbmgdb.SecretEmoteAuditRecordMgDbModel, error)
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretEmoteAuditRecordMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.SecretEmoteAuditRecordMgDbModel, options ...*options.InsertOneOptions) error
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
}

type SecretEmoteAuditRecord struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretEmoteAuditRecordMgModelImpl(db *mongo.Database) ISecretEmoteAuditRecordMgModel {
	return &SecretEmoteAuditRecord{
		MgDB:  db,
		Table: "secretEmoteAudit",
	}
}

func (g *SecretEmoteAuditRecord) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *SecretEmoteAuditRecord) FindOne(ctx context.Context, filter any) (*pbmgdb.SecretEmoteAuditRecordMgDbModel, error) {
	var v *pbmgdb.SecretEmoteAuditRecordMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretEmoteAuditRecord FindOne failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *SecretEmoteAuditRecord) Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretEmoteAuditRecordMgDbModel, error) {
	find, err := g.coll().Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	retItems := make([]*pbmgdb.SecretEmoteAuditRecordMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.SecretEmoteAuditRecordMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretEmoteAuditRecord failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (g *SecretEmoteAuditRecord) Create(ctx context.Context, data *pbmgdb.SecretEmoteAuditRecordMgDbModel, options ...*options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data, options...)

	if err != nil {
		logger.Errorf(ctx, "SecretEmoteAuditRecord:Create error : %v", err)
		return err
	}

	return nil
}

func (g *SecretEmoteAuditRecord) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "SecretEmoteAuditRecord:updateOne error: %v", err)
		return err
	}

	return nil
}
