package job

import (
	"bytes"
	"content_svr/config"
	"content_svr/internal/data_cache"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	"github.com/zeromicro/go-zero/core/threading"
	"go.mongodb.org/mongo-driver/bson"
	"net/http"
	"time"
)

// webhook地址
var webhookUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/1669d708-9a2c-4e07-bdb1-83993228064c"

func (p *UserReportChecker) sendMsg(msg Message) {
	if config.ServerConfig.Env == "test" {
		// 测试环境不发机器人通知
		logger.Infof(context.Background(), "%v", msg)
		return
	}
	// json
	contentType := "application/json"
	// data
	sendData, _ := json.Marshal(msg)
	// request
	result, err := http.Post(webhookUrl, contentType, bytes.NewReader(sendData))
	if err != nil {
		logger.Errorf(p.ctx, "quding_report_checker send fail err: %v", err)
		return
	}
	defer result.Body.Close()
}

type UserReportChecker struct {
	ctx    context.Context
	mng    data_cache.IDataCacheMng
	ticker *time.Ticker
}

func NewUserReportChecker(dataOp data_cache.IDataCacheMng) *UserReportChecker {
	return &UserReportChecker{
		ctx: context.Background(),
		mng: dataOp,
	}
}

var (
	startTimeClock = 10               // 早上10点
	endTimeClock   = 20               // 晚上8点
	interval       = 60 * time.Minute // 间隔（分钟）
)

func (p *UserReportChecker) DoTask() {
	go threading.GoSafe(func() {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf(p.ctx, "quding_report_checker catch err: %v", e)
				return
			}
		}()

		firstInterval := interval - time.Duration(time.Now().Minute())*time.Minute
		p.ticker = time.NewTicker(firstInterval)

		//p.doLogic()
		logger.Infof(p.ctx, "quding_report_checker wait %.0f hours to run timer ", interval.Hours())

		for {
			select {
			case <-p.ticker.C:

				if time.Now().Hour() < startTimeClock {
					continue
				}

				if time.Now().Hour() > endTimeClock {
					continue
				}

				p.doLogic()
				p.ticker.Reset(interval)
				//p.ticker.Reset(time.Duration(tickTimeSecond) * time.Second)

				logger.Infof(p.ctx, "quding_report_checker wait %.0f hours to run timer ", interval.Hours())
			}
		}
	})
}

// Type 1.动态 2.单聊 3.带图动态二审 4.背景图二审 10.评论 99. 复审（仅包含动态）
func (p *UserReportChecker) doLogic() {

	type total struct {
		Comment  int64 `json:"comment"`
		Work     int64 `json:"work"`
		TalkBoy  int64 `json:"talk_boy"`  // 男性举报记录数
		TalkGirl int64 `json:"talk_girl"` // 女性举报记录数
	}
	t := total{}

	now := time.Now()
	filter := bson.D{
		{"timestamp", bson.D{
			{"$gte", now.AddDate(0, 0, -2).UnixMilli()},
		}},
		{"verifyStatus", 0},
	}
	workFilter := append(filter, bson.E{Key: "type", Value: 1})
	talkBoyFilter := append(filter, bson.E{Key: "type", Value: 2}, bson.E{Key: "gender", Value: 1})
	talkGirlFilter := append(filter, bson.E{Key: "type", Value: 2}, bson.E{Key: "gender", Value: 2})
	commentFilter := append(filter, bson.E{Key: "type", Value: 10})

	t.Work, _ = p.mng.GetImpl().SecretReport.Count(p.ctx, workFilter)
	t.TalkBoy, _ = p.mng.GetImpl().SecretReport.Count(p.ctx, talkBoyFilter)
	t.TalkGirl, _ = p.mng.GetImpl().SecretReport.Count(p.ctx, talkGirlFilter)
	t.Comment, _ = p.mng.GetImpl().SecretReport.Count(p.ctx, commentFilter)

	workItem := plain{
		Tag:  "text",
		Text: fmt.Sprintf("【动态】举报未处理统计数：%d\n", t.Work),
	}
	commentItem := plain{
		Tag:  "text",
		Text: fmt.Sprintf("【评论】举报未处理统计数：%d\n", t.Comment),
	}
	talkBoyItem := plain{
		Tag:  "text",
		Text: fmt.Sprintf("【私聊】男性被举报未处理统计数：%d\n", t.TalkBoy),
	}
	talkGirlItem := plain{
		Tag:  "text",
		Text: fmt.Sprintf("【私聊】女性被举报未处理统计数：%d\n", t.TalkGirl),
	}
	href := plain{
		Tag:  "a",
		Text: "跳转连接",
		Href: "https://mzadmin.52mengdong.com/#/devile/reprot",
	}

	items := []plain{workItem, commentItem, talkBoyItem, talkGirlItem, href}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = "最近48小时抓捕信息统计"
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	p.sendMsg(m)

}
