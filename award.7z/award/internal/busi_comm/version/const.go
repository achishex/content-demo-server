package version

const (
	WorkPictureVersion = "1070000" // 动态允许发图片,系统卡片对应支持的版本

	CommentEmotionVersion       = "2020001" // 评论允许发表情版本
	SuperiorContentAwardVersion = "2060001" // 优质内容版本
	TalkADVersion               = "2130001" // 聊天广告
	GameCardVersion             = "2140000" //游戏卡片
)
