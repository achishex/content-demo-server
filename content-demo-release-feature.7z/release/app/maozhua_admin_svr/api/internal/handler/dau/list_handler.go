package dau

import (
	"content_svr/app/maozhua_admin_svr/common/result"
	"github.com/go-playground/validator/v10"
	"net/http"

	"content_svr/app/maozhua_admin_svr/api/internal/logic/dau"
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"github.com/zeromicro/go-zero/rest/httpx"
)

type verifyDauListReqRequest struct {
	types.DauListReq
}

func (p *verifyDauListReqRequest) Validate() error {
	valid := validator.New()
	if err := valid.Struct(p); err != nil {
		return err
	}
	return nil
}

func ListHandler(svcCtx *svc.ServiceContext) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req verifyDauListReqRequest
		if err := httpx.Parse(r, &req); err != nil {
			result.ParamErrorResult(r, w, err)
			return
		}

		l := dau.NewListLogic(r.Context(), svcCtx)
		resp, err := l.List(&req.DauListReq)
		result.HttpResult(r, w, resp, err)
	}
}
