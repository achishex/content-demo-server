package data_cache

import (
	"content_svr/db/mongodb/model"
	"context"
	"encoding/json"
	"sort"
)

// GetRobotRules 所有活动中机器人规则  robotId:commentIndex
func (p *DataCacheMng) GetRobotCommentRules(ctx context.Context) ([]model.MzRobot, error) {
	rdsKey := getRdsKeyRobot()
	m, err := p.RedisCli.HGetAll(ctx, rdsKey).Result()
	if err != nil {
		return nil, err
	}

	// 根据索引值，从小到大返回，
	robots := make([]model.MzRobot, 0)
	for _, data := range m {
		r := model.MzRobot{}
		if err := json.Unmarshal([]byte(data), &r); err != nil {
			continue
		}

		if r.CommentIndex <= 1 {
			// 不接受0和1索引位置
			continue
		}

		if r.Category != 1 {
			// 非评论机器人
			continue
		}

		if !r.Status {
			// 未启用
			continue
		}

		robots = append(robots, r)
	}
	sort.Slice(robots, func(i, j int) bool {

		return robots[i].CommentIndex < robots[j].CommentIndex
	})

	return robots, err
}

// PushMessageToRobot 通知机器人对哪条动态发评论  robotId:wordId
func (p *DataCacheMng) PushMessageToRobot(message interface{}) error {
	rdsKey := getRdsKeyRobotComment()
	err := p.RedisCli.Publish(context.Background(), rdsKey, message).Err()
	if err != nil {
		return err
	}

	return nil
}

// 过滤官方机器人回复评论
func (p *DataCacheMng) IsRobotComment(ctx context.Context, userId int64) bool {
	robots, err := p.GetRobotCommentRules(ctx)
	if err != nil || len(robots) == 0 {
		return false
	}

	for _, r := range robots {
		if r.UserId == userId {
			return true
		}
	}

	return false
}
