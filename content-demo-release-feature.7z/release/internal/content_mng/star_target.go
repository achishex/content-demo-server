package content_mng

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbuserapi"
	"content_svr/setting"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

func (p *ContentMng) SetStarTarget(ctx context.Context, loginUserId int64, req *pbuserapi.UserStarTargetReq) (int, error) {
	follow, err := p.DataCache.GetImpl().SecretUserFollowMgModel.GetByUserId(ctx, loginUserId, req.GetToUserId())
	if err != nil {
		return 0, err
	}
	if follow.GetMutual() != const_busi.Mutual {
		return 0, errorcode.UserRemindStarTarget
	}

	if follow.StarTarget != const_busi.StartTargetOpen {
		cond := map[string]interface{}{
			"userId":     loginUserId,
			"starTarget": 1,
		}
		count := p.DataCache.GetImpl().SecretUserFollowMgModel.CountByCondition(ctx, cond)
		if count >= setting.Maozhua.StarTargetMaxCount.Get() {
			return 0, errorcode.UserRemindStarTargetMax
		}
	}

	var starTarget int
	if follow.StarTarget == const_busi.StartTargetOpen {
		starTarget = const_busi.StartTargetClose
	} else {
		starTarget = const_busi.StartTargetOpen
	}
	filter := map[string]interface{}{
		"userId":       loginUserId,
		"targetUserId": req.GetToUserId(),
	}
	update := map[string]interface{}{
		"starTarget": starTarget,
		"timestamp":  time.Now().UnixMilli(),
	}
	if _, err := p.DataCache.GetImpl().SecretUserFollowMgModel.UpsertMapOne(ctx, filter, update); err != nil {
		return 0, err
	}

	return starTarget, nil
}

func (p *ContentMng) GetStarTargetList(ctx context.Context, loginUserId int64) ([]*pbapi.UserinfoDbModel, error) {
	cond := map[string]interface{}{
		"userId":     loginUserId,
		"starTarget": 1,
	}
	opt := &options.FindOptions{}
	opt.Sort = bson.E{
		Key: "timestamp", Value: -1,
	}

	followList, err := p.DataCache.GetImpl().SecretUserFollowMgModel.ListByCondition(ctx, cond, nil)
	if err != nil {
		return nil, err
	}

	if len(followList) == 0 {
		// 没有猫友
		return nil, nil
	}

	userIds := make([]int64, 0)
	for _, follow := range followList {
		userIds = append(userIds, follow.GetTargetUserId())
	}

	return p.DataCache.GetImpl().UserInfoModel.GetByUserIds(ctx, userIds)
}

func (p *ContentMng) GetUserFollowInfo(ctx context.Context, loginUserId, toUserId int64) (*pbapi.SecretUserFollowMgDbModel, error) {
	return p.DataCache.GetImpl().SecretUserFollowMgModel.GetByUserId(ctx, loginUserId, toUserId)

}
