package data_cache

import (
	"context"
	"strconv"
)

// 检查是不是在内容分发池。返回eg:32 按位分配权限。
func (p *DataCacheMng) GetUserPermission(ctx context.Context, userId int64) int32 {
	redisKey := getRdsKeyUserPermission()                                                     // workid~calcScore
	permission, err := p.RedisCli.HGet(ctx, redisKey, strconv.FormatInt(userId, 10)).Result() //返回在range的idx位置
	if err == nil {                                                                           //获取成功
		pMint, err := strconv.Atoi(permission)
		if err == nil { //转化成功
			//logger.Infof(ctx, "GetUserPermission userid=%v, permission=%v", userId, pMint)
			return int32(pMint)
		}
	}
	return 0
}
