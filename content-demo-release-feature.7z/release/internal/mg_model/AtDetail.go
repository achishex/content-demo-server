package mg_model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"context"
	"fmt"
	"github.com/samber/lo"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"time"
)

const (
	AtTargetTypeWork    = 1
	AtTargetTypeComment = 2
	AtTypeGroup         = 1
)

type IAtDetailMgModel interface {
	InsertWorkAtGroup(ctx context.Context, workID int64, ats []*pbapi.RemindGroupNode) error
	InsertCommentAtGroup(ctx context.Context, commentID int64, ats []*pbapi.RemindGroupNode) error
	ListWorkAtGroup(ctx context.Context, workID int64) ([]*pbapi.RemindGroupNode, error)
	ListCommentAtGroup(ctx context.Context, commentID int64) ([]*pbapi.RemindGroupNode, error)
}

type AtDetailMgModel struct {
	MgDB *mongo.Database
}

func NewAtDetailMgModel(db *mongo.Database) IAtDetailMgModel {
	return &AtDetailMgModel{MgDB: db}
}

func (impl *AtDetailMgModel) InsertWorkAtGroup(ctx context.Context, workID int64, ats []*pbapi.RemindGroupNode) error {
	if len(ats) == 0 {
		return nil
	}
	models := lo.Map(ats, impl.toWorkAt(workID))
	inserts := lo.Map(models, func(item *pbmgdb.AtDetailMgDbModel, _ int) interface{} { return item })
	_, err := impl.MgDB.Collection(impl.collection()).InsertMany(ctx, inserts)
	return err
}

func (impl *AtDetailMgModel) InsertCommentAtGroup(ctx context.Context, commentID int64, ats []*pbapi.RemindGroupNode) error {
	if len(ats) == 0 {
		return nil
	}
	models := lo.Map(ats, impl.toCommentAt(commentID))
	entities := lo.Map(models, func(item *pbmgdb.AtDetailMgDbModel, _ int) interface{} { return item })
	_, err := impl.MgDB.Collection(impl.collection()).InsertMany(ctx, entities)
	return err
}

func (impl *AtDetailMgModel) ListWorkAtGroup(ctx context.Context, workID int64) ([]*pbapi.RemindGroupNode, error) {
	filter := bson.D{{"targetId", fmt.Sprint(workID)}, {"targetType", AtTargetTypeWork}, {"atType", AtTypeGroup}}
	cur, err := impl.MgDB.Collection(impl.collection()).Find(ctx, filter)
	if err != nil {
		return nil, err
	}

	var entities []*pbmgdb.AtDetailMgDbModel
	for cur.Next(ctx) {
		t := &pbmgdb.AtDetailMgDbModel{}
		err2 := cur.Decode(t)
		if err2 != nil {
			return nil, err
		}
		entities = append(entities, t)
	}

	res := lo.Map(entities, func(item *pbmgdb.AtDetailMgDbModel, _ int) *pbapi.RemindGroupNode {
		return &pbapi.RemindGroupNode{
			GroupID: item.AtId,
			Offset:  item.Offset,
			Size:    item.Size,
		}
	})
	return res, nil
}

func (impl *AtDetailMgModel) ListCommentAtGroup(ctx context.Context, commentID int64) ([]*pbapi.RemindGroupNode, error) {
	filter := bson.D{{"targetId", fmt.Sprint(commentID)}, {"targetType", AtTargetTypeComment}, {"atType", AtTypeGroup}}
	cur, err := impl.MgDB.Collection(impl.collection()).Find(ctx, filter)
	if err != nil {
		return nil, err
	}

	var entities []*pbmgdb.AtDetailMgDbModel
	for cur.Next(ctx) {
		t := &pbmgdb.AtDetailMgDbModel{}
		err2 := cur.Decode(t)
		if err2 != nil {
			return nil, err
		}
		entities = append(entities, t)
	}

	res := lo.Map(entities, func(item *pbmgdb.AtDetailMgDbModel, _ int) *pbapi.RemindGroupNode {
		return &pbapi.RemindGroupNode{
			GroupID: item.AtId,
			Offset:  item.Offset,
			Size:    item.Size,
		}
	})
	return res, nil
}

func (impl *AtDetailMgModel) collection() string {
	return "secretAtDetail"
}

func (impl *AtDetailMgModel) toCommentAt(commentID int64) func(item *pbapi.RemindGroupNode, _ int) *pbmgdb.AtDetailMgDbModel {
	return func(item *pbapi.RemindGroupNode, _ int) *pbmgdb.AtDetailMgDbModel {
		return &pbmgdb.AtDetailMgDbModel{
			Id:         "",
			TargetId:   fmt.Sprint(commentID),
			TargetType: AtTargetTypeComment,
			AtId:       item.GroupID,
			AtType:     AtTypeGroup,
			CreateTime: time.Now().UnixMilli(),
			Offset:     item.Offset,
			Size:       item.Size,
		}
	}
}

func (impl *AtDetailMgModel) toWorkAt(workID int64) func(item *pbapi.RemindGroupNode, _ int) *pbmgdb.AtDetailMgDbModel {
	return func(item *pbapi.RemindGroupNode, _ int) *pbmgdb.AtDetailMgDbModel {
		return &pbmgdb.AtDetailMgDbModel{
			Id:         "",
			TargetId:   fmt.Sprint(workID),
			TargetType: AtTargetTypeWork,
			AtId:       item.GroupID,
			AtType:     AtTypeGroup,
			CreateTime: time.Now().UnixMilli(),
			Offset:     item.Offset,
			Size:       item.Size,
		}
	}
}
