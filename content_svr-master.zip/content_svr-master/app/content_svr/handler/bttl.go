package handler

import (
	"content_svr/internal/bttl_mng"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/utils"
	"content_svr/setting"
	"github.com/gin-gonic/gin"
	"strconv"
)

func (p *AdminHandler) DiscoverBttl(ctx *gin.Context, req *bttl_mng.DiscoverReq) (*bttl_mng.DiscoverResp, error) {
	uid := middleware.GetUserID(ctx)
	if uid <= 0 {
		return nil, errorcode.PARAM_ERROR
	}
	resp, err := p.bttlMng.Discover(ctx, uid)
	if err != nil {
		logger.Errorf(ctx, "Discover fail, err: %v", err)
	}
	return resp, err
}

func (p *AdminHandler) CreateBttl(ctx *gin.Context, req *bttl_mng.CreateReq) (*bttl_mng.BttlLiteDTO, error) {
	uid := middleware.GetUserID(ctx)
	if uid <= 0 {
		return nil, errorcode.PARAM_ERROR
	}

	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	bttl, err := p.bttlMng.CreateBttl(ctx, header, uid, req.Content)
	if err != nil {
		logger.Errorf(ctx, "CreateBttl fail, err: %v", err)
		return nil, err
	}
	dto := p.bttlMng.Entity2LiteDTO(*bttl)
	return &dto, nil
}

func (p *AdminHandler) PickBttl(ctx *gin.Context) (*bttl_mng.PickResp, error) {
	bttlIDStr := ctx.Param("bttlID")
	if bttlIDStr == "" {
		return nil, errorcode.PARAM_ERROR
	}
	bttlID, err := strconv.ParseInt(bttlIDStr, 10, 64)
	if err != nil || bttlID < 1 {
		return nil, errorcode.PARAM_ERROR
	}

	uid := middleware.GetUserID(ctx)
	if uid <= 0 {
		return nil, errorcode.PARAM_ERROR
	}

	resp, err := p.bttlMng.PickBttl(ctx, uid, bttlID)
	if err != nil {
		logger.Errorf(ctx, "PickBttl fail, err: %v", err)
		return nil, err
	}
	return resp, nil
}

func (p *AdminHandler) ThrowbackBttl(ctx *gin.Context) (*bttl_mng.ThrowbackResp, error) {
	bttlIDStr := ctx.Param("bttlID")
	if bttlIDStr == "" {
		return nil, errorcode.PARAM_ERROR
	}
	bttlID, err := strconv.ParseInt(bttlIDStr, 10, 64)
	if err != nil {
		return nil, errorcode.PARAM_ERROR
	}

	uid := middleware.GetUserID(ctx)
	if uid <= 0 {
		return nil, errorcode.PARAM_ERROR
	}

	resp, err := p.bttlMng.ThrowbackBttl(ctx, uid, bttlID)
	if err != nil {
		logger.Errorf(ctx, "ThrowbackBttl fail, err: %v", err)
		return nil, err
	}
	return resp, nil
}

func (p *AdminHandler) BttlStatus(ctx *gin.Context) (*bttl_mng.BttlStatusResp, error) {
	uid := middleware.GetUserID(ctx)
	if uid <= 0 {
		return nil, errorcode.PARAM_ERROR
	}

	return p.bttlMng.UserStatus(ctx, uid)
}
func (p *AdminHandler) ReplyBttl(ctx *gin.Context, req *bttl_mng.ReplyReq) (*bttl_mng.ReplyResp, error) {
	bttlIDStr := ctx.Param("bttlID")
	if bttlIDStr == "" {
		return nil, errorcode.PARAM_ERROR
	}
	bttlID, err := strconv.ParseInt(bttlIDStr, 10, 64)
	if err != nil {
		return nil, errorcode.PARAM_ERROR
	}

	uid := middleware.GetUserID(ctx)
	if uid <= 0 {
		return nil, errorcode.PARAM_ERROR
	}

	resp, err := p.bttlMng.ReplyBttl(ctx, uid, bttlID, req.Msg)
	if err != nil {
		logger.Errorf(ctx, "ReplyBttl fail, err: %v", err)
		return nil, err
	}
	return resp, nil
}

func (p *AdminHandler) ListBttl(ctx *gin.Context) (*bttl_mng.ListBttlResp, error) {
	uid := middleware.GetUserID(ctx)
	if uid <= 0 {
		return nil, errorcode.PARAM_ERROR
	}

	resp, err := p.bttlMng.ListBttl(ctx, uid)
	if err != nil {
		logger.Errorf(ctx, "ListBttl fail, err: %v", err)
		return nil, err
	}
	return resp, nil
}

func (p *AdminHandler) PickBttlADUpload(ctx *gin.Context) (*bttl_mng.PickADUploadResp, error) {
	uid := middleware.GetUserID(ctx)
	if uid <= 0 {
		return nil, errorcode.PARAM_ERROR
	}

	// TODO 频控中间件
	err := p.bttlMng.ResetPickChance(ctx, uid)
	if err != nil {
		return nil, err
	}
	return &bttl_mng.PickADUploadResp{
		PickChance: setting.Maozhua.BttlConf.PickChance.Get(),
	}, nil
}
