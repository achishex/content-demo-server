package main

import (
	"content_svr/app/app_comm"
	"content_svr/app/content_svr/handler"
	"content_svr/config"
	"content_svr/internal/content_mng"
	"content_svr/internal/game_mng"
	"content_svr/internal/im_mng"
	"content_svr/internal/im_mng/open_im_api"
	"content_svr/internal/inner_mng"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/mg_model"
	"content_svr/internal/model"
	"content_svr/internal/pay_mng"
	"content_svr/internal/security_mng"
	"content_svr/internal/thirdparty/baidu_lbs_yun_proxy"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/internal/thirdparty/wechat_proxy"
	"content_svr/internal/user_center_mng"
	"content_svr/internal/user_level_mng"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/router"
	"content_svr/pub/snow_flake"
	"content_svr/setting"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	rdsV8 "github.com/go-redis/redis/v8"
	"github.com/zeromicro/go-zero/core/logx"
	"time"
)

func main() {
	snow_flake.SetMachineID(config.NodeIdx)
	//初始化DB
	db, err := model.NewDBInstance(config.ServerConfig.MysqlConfig)
	if err != nil {
		logger.Error(context.Background(), "new db instansce failed", err)
		return
	}
	//初始化IM DB
	dbIm, err := model.NewDBInstance(config.ServerConfig.MysqlImConfig)
	if err != nil {
		logger.Error(context.Background(), "new im db instansce failed", err)
		return
	}
	// 初始化mongoDB
	mgDb, err := mg_model.NewMongoDBInstance(config.ServerConfig.MongodbConfig)
	if err != nil {
		logger.Error(context.Background(), "new mongo db instansce failed", err)
		return
	}
	timeoutCtx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()
	err = mgDb.Ping(timeoutCtx, nil)
	if err != nil {
		logger.Error(context.Background(), "ping mongo fail, err: %v", err)
		return
	}

	//初始化本地缓存对象
	localCache := go_cache.NewMemCache()

	//初始化 redis_cli
	rdsClient := InitRdsClient(config.ServerConfig.RedisConfig.Addr, config.ServerConfig.RedisConfig.Pwd)
	if err != nil {
		logger.Error(context.Background(), "new redis client failed", err)
		return
	}

	// 初始化kafka
	kafkaProxy := kafka_proxy.NewKafkaProxyImpl(config.ServerConfig.KafkaConfig)

	// 初始化thirdparty
	bdLbsProxy := baidu_lbs_yun_proxy.NewBaiduLbsYunProxyImpl()

	shumeiProxy := shumei_proxy.NewShumeiProxyImpl()

	wxProxy := wechat_proxy.NewWechatMng()

	// 初始化innerProxy
	innerProxy := inner_mng.NewInnerProxyImpl(rdsClient)

	// 初始化 data_cache层
	dataCache := app_comm.BuildDataCache(db, dbIm, mgDb, rdsClient, bdLbsProxy, localCache)
	imCaller := open_im_api.NewOpenIMCaller()
	imHelper := im_mng.NewIMHelper(imCaller)
	kwMng := content_mng.NewContentMng(dataCache, bdLbsProxy, shumeiProxy, innerProxy, kafkaProxy, imHelper)
	userLevMng := user_level_mng.NewUserLevelMng(dataCache)
	seMng := security_mng.NewSecurityMng(dataCache, bdLbsProxy, shumeiProxy, innerProxy, kafkaProxy)
	ucMng := user_center_mng.NewUserCenterMng(dataCache, innerProxy, kafkaProxy, wxProxy, kwMng)
	payMng := pay_mng.NewPayMng(dataCache, innerProxy, kafkaProxy, wxProxy)
	gameMng := game_mng.NewGameMng(dataCache, innerProxy, kafkaProxy, wxProxy, payMng)
	imMng := im_mng.NewIMMng(dataCache, seMng, imCaller, kafkaProxy, imHelper)

	// 初始化全局唯一配置
	if err := setting.Initialize(rdsClient, config.ServerConfig.Env); err != nil {
		panic(err)
	}
	go setting.Monitor()

	// 初始化handle层
	adminServerHandle := handler.NewAdminHandler(kwMng, userLevMng, seMng, ucMng, gameMng, payMng, imMng, shumeiProxy)
	{
		imHelper.SendMsgFn = adminServerHandle.SendMsg // TODO 分包解决依赖
		imHelper.SendBBMsgFn = kwMng.SendBBMsg
		imHelper.DataCache = dataCache
	}

	appRouter := router.NewRouter(kafkaProxy)
	appRouter.Engine.Use(middleware.AppTokenMiddleware(rdsClient)) // apptoken middware
	appRouter.Engine.Use(middleware.ApiWhiteList(config.ServerConfig))
	appRouter.Engine.Use(middleware.RetainRecord(dataCache))
	handler.SetUrls(appRouter.Engine, adminServerHandle)
	logx.SetLevel(logx.ErrorLevel)
	logger.DebugLogger(config.ServerConfig.Env)
	//运行服务
	logger.Infof(context.Background(), "server starting, port=%v, node_idx=%v....",
		config.ServerConfig.Port, config.NodeIdx)
	appRouter.Run(config.ServerConfig.Port)

}

func InitRdsClient(addr, pwd string) *rdsV8.Client {
	client := rdsV8.NewClient(&rdsV8.Options{
		Addr:         addr,
		Password:     pwd,
		DB:           0,
		ReadTimeout:  2 * time.Minute,
		WriteTimeout: 1 * time.Minute,
		PoolTimeout:  2 * time.Minute,
		IdleTimeout:  10 * time.Minute,
		PoolSize:     1000,
	})
	_, err := client.Ping(context.Background()).Result()
	if err != nil {
		panic(fmt.Sprintf("redis init failed. err:%v", err.Error()))
	}
	return client
}
