package mz_setting

import (
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type MzSettingDeleteLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewMzSettingDeleteLogic(ctx context.Context, svcCtx *svc.ServiceContext) *MzSettingDeleteLogic {
	return &MzSettingDeleteLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *MzSettingDeleteLogic) MzSettingDelete(req *types.MzSettingDeleteReq) (resp *types.MzSettingDeleteResp, err error) {
	//err = l.svcCtx.Maozhua.DeleteRecord(l.ctx, req.Field)

	return
}
