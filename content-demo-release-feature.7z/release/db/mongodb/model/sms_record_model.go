package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const SmsRecordCollectionName = "smsRecord"

var _ SmsRecordModel = (*customSmsRecordModel)(nil)

type (
	// SmsRecordModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSmsRecordModel.
	SmsRecordModel interface {
		smsRecordModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SmsRecord, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SmsRecord, error)
	}

	customSmsRecordModel struct {
		*defaultSmsRecordModel
	}
)

// NewSmsRecordModel returns a model for the mongo.
func NewSmsRecordModel(cfg MonConfig) SmsRecordModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SmsRecordCollectionName)
	return &customSmsRecordModel{
		defaultSmsRecordModel: newDefaultSmsRecordModel(conn),
	}
}

func (m *customSmsRecordModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customSmsRecordModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSmsRecordModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SmsRecord, error) {
	result := make([]SmsRecord, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSmsRecordModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SmsRecord, error) {
	var data SmsRecord
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
