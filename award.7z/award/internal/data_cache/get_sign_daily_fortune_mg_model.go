package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	rdsV8 "github.com/go-redis/redis/v8"
	"math/rand"
	"time"
)

// 获取mgondb 带redis缓存查询mgdb
func (p *DataCacheMng) GetSignDailyFortuneMgDBLD(ctx context.Context, signId, date int32) *pbapi.StarSignData {
	// todo 缓存
	redisKey := fmt.Sprintf(cache_const.XingZuoDailyDetailRcache.KeyFmt, signId, date)
	expire := cache_const.XingZuoDailyDetailRcache.Expire

	// 从redis取
	rdsBytes, err := p.RedisCli.Get(ctx, redisKey).Bytes()
	if err == nil {
		// 有数据
		resp := &pbapi.StarSignData{}
		err = json.Unmarshal(rdsBytes, resp)
		if err != nil {
			logger.Errorf(ctx, "get GetSignDailyFortuneMgDBLD failed. signId=%v,date=%v, err=%v", signId, date, err.Error())
			return nil
		}
		return resp
	}
	// 处理非空报错
	if err != nil && err != rdsV8.Nil {
		logger.Errorf(ctx, "get GetSignDailyFortuneMgDBLD failed. signId=%v,date=%v, err=%v", signId, date, err.Error())
	}

	//从mg db取.
	mgItem, err := p.SignDailyFortuneMg.GetByIdAndDate(ctx, signId, date)
	if err != nil {
		logger.Errorf(ctx, "get GetPersonTalkMsgTotalMgDB failed. signId=%v,date=%v, err=%v", signId, date, err.Error())
		return nil
	}

	XingZuoExtData := &pbapi.StarSignData{
		IsKaiYun: true,
		// 自己的信息
		StarSign:       cm_const.SignIdNameDict[int32(mgItem.GetSignId())],
		StarSignHeader: fmt.Sprintf("workshop/maozhua_system_user/xingzuo_header_%d.png", mgItem.GetSignId()),
		// 速配 对方的信息
		SpeedSignScore: int32(rand.Intn(10) + 90),
		SpeedSign:      cm_const.SignIdNameDict[int32(mgItem.GetSpeedSignId())],
		//SpeedSignHeader: fmt.Sprintf("workshop/maozhua_system_user/xingzuo_header_thumbnail_%d.png", mgItem.GetSpeedSignId()),
		Data: mgItem,
	}

	pbData, err := json.Marshal(XingZuoExtData)
	if err != nil {
		return nil
	}
	err = p.RedisCli.Set(ctx, redisKey, pbData, time.Duration(expire)*time.Second).Err()
	if err != nil {
		return nil
	}
	return XingZuoExtData
}
