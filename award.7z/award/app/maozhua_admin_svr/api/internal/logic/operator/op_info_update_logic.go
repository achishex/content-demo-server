package operator

import (
	xerr2 "content_svr/app/maozhua_admin_svr/common/xerr"
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type OpInfoUpdateLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewOpInfoUpdateLogic(ctx context.Context, svcCtx *svc.ServiceContext) *OpInfoUpdateLogic {
	return &OpInfoUpdateLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *OpInfoUpdateLogic) OpInfoUpdate(req *types.OpInfoUpdateReq) (resp *types.OpInfoUpdateResp, err error) {
	_db := l.svcCtx.ManagerDB.OperatorTab
	ot, err := _db.WithContext(l.ctx).Where(_db.Email.Eq(req.CtxEmail)).First()
	if err != nil {
		return nil, err
	}

	switch {
	case ot.Pwd == req.OriginalPwd:
		// 原密码正确
		break
	case ot.Pwd != req.OriginalPwd:
		return nil, xerr2.NewErrCodeMsg(xerr2.SvcCodeError, "密码不正确")
	case ot.Pwd == req.Pwd:
		return nil, xerr2.NewErrCodeMsg(xerr2.SvcCodeError, "新密码与旧密码一致")
	default:
		return nil, xerr2.NewErrCodeMsg(xerr2.SvcCodeError, "密码不正确")
	}

	info, err := _db.WithContext(l.ctx).Where(_db.OpID.Eq(ot.OpID)).Update(_db.Pwd, req.Pwd)
	if err != nil {
		return nil, err
	}

	if info.RowsAffected == 0 {
		return nil, xerr2.DbDoNothing
	}

	return
}
