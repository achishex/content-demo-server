package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

const collectionNameSecretGameStatisticDaily = "SecretGameStatisticDaily"

type SecretGameStatisticDaily struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	Day      int64 `json:"day,omitempty" bson:"day,omitempty"`
	GameId   int64 `json:"game,omitempty" bson:"day,omitempty"`
	GameName int64 `json:"game_name,omitempty" bson:"game_name,omitempty"`
	UserId   int64 `json:"user_id,omitempty" bson:"user_id,omitempty"`
	UserPv   int64 `json:"user_pv,omitempty" bson:"user_pv,omitempty"`

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` //创建时间
	UpdateTime int64 `json:"update_time,omitempty" bson:"update_time,omitempty"` //更新时间
}
