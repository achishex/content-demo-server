package middleware

import "github.com/gin-gonic/gin"

const (
	ctxNoAuth     = "no_auth"
	ctxNoAuthFlag = true
)

func NoAuthMiddleware() gin.HandlerFunc {
	return func(ctx *gin.Context) {
		ctx.Set(ctxNoAuth, ctxNoAuthFlag)
		ctx.Next()
	}
}
