package data_cache

import (
	"context"
	"time"
)

func (p *DataCacheMng) SetRedisAdCallback(ctx context.Context, channel, machineId, value string) error {
	if channel == "" || machineId == "" {
		return nil
	}
	rdsKey := getRdsKeyAdCallback(channel, machineId)

	if err := p.RedisCli.Set(ctx, rdsKey, value, time.Hour*24).Err(); err != nil {
		return err
	}

	return nil
}

func (p *DataCacheMng) GetRedisAdCallback(ctx context.Context, channel, machineId string) string {
	if channel == "" || machineId == "" {
		return ""
	}
	rdsKey := getRdsKeyAdCallback(channel, machineId)

	value, err := p.RedisCli.Get(ctx, rdsKey).Result()
	if err != nil {
		return ""
	}

	return value
}
