package open_im_api

import (
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"github.com/OpenIMSDK/tools/errs"
	"golang.org/x/sync/singleflight"
	"sync/atomic"
	"time"
)

var (
	adminTokenV atomic.Value
	sf          singleflight.Group
)

func init() {
	adminTokenV.Store("")
}

func GetAdminToken() string {
	return adminTokenV.Load().(string)
}
func RefreshAdminToken() {
	ctx := context.Background()
	sf.Do("RefreshAdminToken", func() (any, error) {
		if e := utils.Try(3, time.Second*3, func() error {
			t, err2 := NewOpenIMCaller().ImAdminTokenWithDefaultAdmin(ctx)
			if err2 != nil {
				return err2
			}
			adminTokenV.Store(t)
			logger.Infof(ctx, "refresh adminIMToken: %v", t)
			return nil
		}); e != nil {
			logger.Errorf(ctx, "refresh adminIMToken fail, err: %v", e)
			return nil, e
		}
		return nil, nil
	})
}

func IsInvalidTokenErr(err error) bool {
	cerr, ok := errs.Unwrap(err).(errs.CodeError)
	return ok && (cerr.Code() >= errs.TokenExpiredError || cerr.Code() <= errs.TokenNotExistError)
}

// WithAdminToken caller带上adminToken，并加上失效重试
func WithAdminToken[Req, Resp any](c ApiCaller[Req, Resp]) ApiCaller[Req, Resp] {
	if GetAdminToken() == "" {
		RefreshAdminToken()
	}

	return callerFn[Req, Resp](func(ctx context.Context, req *Req) (*Resp, error) {
		ctx = context.WithValue(ctx, CtxApiToken, GetAdminToken())
		resp, err := c.Call(ctx, req)
		if err != nil {
			if IsInvalidTokenErr(err) {
				RefreshAdminToken()
				ctx = context.WithValue(ctx, CtxApiToken, GetAdminToken())
				return c.Call(ctx, req)
			}
		}

		return resp, err
	})
}
