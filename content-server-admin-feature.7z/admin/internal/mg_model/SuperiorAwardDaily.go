package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"errors"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISuperiorAwardDailyMgModel interface {
	FindOne(ctx context.Context, filter any) (*pbmgdb.SuperiorAwardDailyMgDbModel, error)
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SuperiorAwardDailyMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.SuperiorAwardDailyMgDbModel, options ...*options.InsertOneOptions) error
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
}

type SuperiorAwardDailyMgModel struct {
	MgDB  *mongo.Database
	Table string
}

func NewSuperiorAwardDailyMgModel(db *mongo.Database) ISuperiorAwardDailyMgModel {
	return &SuperiorAwardDailyMgModel{
		MgDB:  db,
		Table: "superior_award_daily",
	}
}

func (g *SuperiorAwardDailyMgModel) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *SuperiorAwardDailyMgModel) FindOne(ctx context.Context, filter any) (*pbmgdb.SuperiorAwardDailyMgDbModel, error) {
	var v *pbmgdb.SuperiorAwardDailyMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if errors.Is(err, mongo.ErrNoDocuments) {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SuperiorAwardDaily FindOne failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *SuperiorAwardDailyMgModel) Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SuperiorAwardDailyMgDbModel, error) {
	find, err := g.coll().Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	retItems := make([]*pbmgdb.SuperiorAwardDailyMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.SuperiorAwardDailyMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SuperiorAwardDaily failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (g *SuperiorAwardDailyMgModel) Create(ctx context.Context, data *pbmgdb.SuperiorAwardDailyMgDbModel, options ...*options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data, options...)

	if err != nil {
		logger.Errorf(ctx, "SuperiorAwardDaily:Create error : %v", err)
		return err
	}

	return nil
}

func (g *SuperiorAwardDailyMgModel) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "SuperiorAwardDaily:updateOne error: %v", err)
		return err
	}

	return nil
}
