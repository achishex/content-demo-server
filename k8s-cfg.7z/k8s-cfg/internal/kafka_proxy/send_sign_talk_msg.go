package kafka_proxy

import (
	"content_svr/internal/busi_comm/comm_struct"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbkfk"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	"github.com/Shopify/sarama"
	"github.com/fatih/structs"
	"github.com/gogo/protobuf/proto"
)

func (p *KafkaProxyImpl) SendSignTalkMsg(ctx context.Context, curUserInfo *data_cache.UserInfoLocal, record *pbapi.PersonalTalkMessageRecordMgDbModel,
	workInfo *pbapi.PersonalBottleWorksSimple, remind *pbmgdb.UserRemindDetailMgDbModel) error {
	if record == nil {
		return nil
	}
	topic := getTopic(topicPersonalWebsocketMessage)
	wsData := &pbkfk.PersonalSignTalkWsDto{
		Id:         record.GetId(),
		WorkId:     record.WorkId,
		FromUserId: record.FromUserId,
		Province:   record.Province,
		City:       record.City,
		FromUser: &pbkfk.SimpleUserWsInfoResponse{
			UserId:     curUserInfo.UserInfoDbModel.GetUserId(),
			NickName:   curUserInfo.UserInfoDbModel.GetNickName(),
			Photo:      curUserInfo.UserInfoDbModel.GetOpenPhoto(),
			Gender:     curUserInfo.UserInfoDbModel.GetGender(),
			IsConvoy:   curUserInfo.IsPolice,
			ShowConvoy: curUserInfo.ShowConvoy,
			MemberType: curUserInfo.MemberType,
		}, //
		ToUserId:    record.ToUserId,
		Content:     record.Content,
		CreateTime:  record.CreateTime,
		Width:       record.Width,
		High:        record.High,
		ObjectId:    record.ObjectId,
		MessageType: record.MessageType,
		MemeId:      record.MemeId,
		Longitude:   record.Longitude,
		Latitude:    record.Latitude,
		//OpenId:      ,			// todo  fjx
	}

	if record.GetMessageType() == const_busi.MutualWorkMsgType {
		wsData.WorkInfo = workInfo
		logger.Infof(ctx, "workInfo: %#v", workInfo)
	} else if record.GetMessageType() == const_busi.MutualCommentMsgType {
		wsData.Remind = remind
	} else if record.GetMessageType() == int32(pbconst.MessageTypeEnum_msg_type_remind_comment_reply) {
		wsData.Reply = &pbapi.CommentReply{}
		if workInfo.GetUserInfo() != nil {
			wsData.Reply.UserInfo = &pbapi.UserInfo{
				NickName: workInfo.GetUserInfo().GetNickName(),
				UserId:   workInfo.GetUserInfo().GetUserId(),
			}
		}
		wsData.Reply.Work = &pbapi.Work{
			Id: remind.GetWorkId(),
		}
		wsData.Reply.Comment = &pbapi.Comment{
			Id: remind.GetCommentId(),
		}
		wsData.Content = proto.String(workInfo.GetTitle())
	}

	minimumVersion := 0
	if record.GetMessageType() == int32(pbconst.MessageTypeEnum_msg_type_jpmy) {
		minimumVersion = 103019
	} else if record.GetMessageType() == int32(pbconst.MessageTypeEnum_msg_type_lahei) {
		minimumVersion = 103053
	}
	wsMsg := comm_struct.WsMessageKafkaDto{
		UserIds:        []int64{record.GetToUserId()},
		Types:          []string{ConstParamDef.singleTalk},
		Data:           structs.Map(&wsData),
		MinimumVersion: int32(minimumVersion),
	}

	wsMsgBytes, _ := json.Marshal(wsMsg)
	msg := &sarama.ProducerMessage{
		Topic:     topic,
		Partition: int32(-1),
		Key:       sarama.StringEncoder(fmt.Sprintf("%v", record.ToUserId)),
		Value:     sarama.ByteEncoder(wsMsgBytes),
	}
	paritition, offset, err := p.Producer.SendMessage(msg)
	//_, _, err := p.Producer.SendMessage(msg)
	if err != nil {
		logger.Error(ctx, "kafka sendmessage failed.", err)
		return err
	}
	logger.Infof(ctx, "kafka send message suc. topic=%v, body=%v, paritition=%v, offset=%v",
		topic, string(wsMsgBytes), paritition, offset)
	return nil
}
