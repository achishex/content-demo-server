package im_mng

import (
	"content_svr/config"
	"content_svr/internal/data_cache"
	"content_svr/internal/im_mng/open_im_api"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbim"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"encoding/json"
	"fmt"
	"github.com/OpenIMSDK/protocol/constant"
	"github.com/OpenIMSDK/protocol/group"
	"github.com/OpenIMSDK/protocol/msg"
	"github.com/OpenIMSDK/protocol/sdkws"
	"github.com/gin-gonic/gin"
	"github.com/gogo/protobuf/proto"
	"github.com/openimsdk/open-im-server/v3/pkg/apistruct"
	"github.com/samber/lo"
	"strconv"
	"time"
)

// IMHelper IM帮助类
type IMHelper struct {
	// main 注入
	// TODO 分包解决循环依赖
	SendMsgFn   func(ctx *gin.Context, req *pbapi.SendMsgReq) (*pbapi.SendMsgSimple, error)
	SendBBMsgFn func(ctx context.Context, userID int64, msgType int32, content string) error
	DataCache   data_cache.IDataCacheMng

	c open_im_api.IOpenIMCaller
}

func NewIMHelper(c open_im_api.IOpenIMCaller) *IMHelper {

	open_im_api.RefreshAdminToken()
	token := open_im_api.GetAdminToken()
	if token == "" {
		panic(fmt.Errorf("RefreshAdminToken fail"))
	}

	logger.Infof(context.Background(), "cache openim admin token: %v", token)

	h := &IMHelper{
		c: c,
	}

	return h
}

// SendGroupJoinBBMsg BB机发群主入群申请
//
//	userID 申请人userID
//	groupID 群ID
func (h *IMHelper) SendGroupJoinBBMsg(ctx context.Context, userID, groupID string) error {
	if userID == "" || groupID == "" {
		return nil
	}

	userIDI64, err := strconv.ParseInt(userID, 10, 64)
	if err != nil {
		return fmt.Errorf("malformed user id: %v", userID)
	}

	ctx = context.WithValue(ctx, open_im_api.CtxApiToken, open_im_api.GetAdminToken())
	gresp, err := h.c.FindGroupInfo(ctx, &group.GetGroupsInfoReq{GroupIDs: []string{groupID}})
	if err != nil {
		return err
	}

	if len(gresp.GroupInfos) == 0 {
		return fmt.Errorf("group not found, groupID: %v", groupID)
	}
	groupInfo := gresp.GroupInfos[0]
	userInfo, err := h.DataCache.GetUserInfoLocal(ctx, nil, userIDI64, false)
	if err != nil || userInfo == nil {
		return fmt.Errorf("user not found, userID: %v", userID)
	}

	m := &pbim.GroupJoinBBMsg{
		GroupID:   groupID,
		GroupName: groupInfo.GroupName,
		UserID:    userID,
		Nickname:  userInfo.UserInfoDbModel.GetNickName(),
	}

	ownerUserIDI64, err := strconv.ParseInt(groupInfo.OwnerUserID, 10, 64)
	if err != nil {
		return fmt.Errorf("malformed userid: %v", err)
	}

	bs, _ := json.Marshal(m)
	err = h.SendBBMsgFn(ctx, ownerUserIDI64, int32(pbconst.MessageTypeEnum_msg_type_group_join_bb_notice), string(bs))
	if err != nil {
		logger.Errorf(ctx, "SendBBMsg fail, err: %v", err)
		return err
	}
	return nil
}

func (h *IMHelper) getBBUserInfo(ctx context.Context) (*data_cache.UserInfoLocal, error) {
	ui, err := h.DataCache.GetUserInfoLocal(ctx, nil, config.ServerConfig.CommentConfig.ReplyCommentOfficialAccount, true)
	return ui, err
}
func (h *IMHelper) SendGroupShare(ctx *gin.Context, group *sdkws.GroupInfo, invitedUserIDs []string) error {
	if len(invitedUserIDs) == 0 {
		return nil
	}
	g := &pbim.GroupInfoLite{
		GroupID:   group.GroupID,
		GroupName: group.GroupName,
		FaceURL:   group.FaceURL,
	}
	bs, _ := json.Marshal(g)

	for _, iuidStr := range lo.Uniq(invitedUserIDs) {
		iuid, err := strconv.ParseInt(iuidStr, 10, 64)
		if err != nil {
			return fmt.Errorf("malformed uid: %v", iuidStr)
		}
		req := &pbapi.SendMsgReq{
			ToUserId:    iuid,
			Content:     proto.String(string(bs)),
			MessageType: int32(pbconst.MessageTypeEnum_msg_type_group_share),
			WorkId:      proto.Int64(-1),
		}
		_, err = h.SendMsgFn(ctx, req)
		if err != nil {
			return err
		}
	}

	//_, err := im_handler_ref.AdminHandler.SendMsg(ctx, req)
	return nil
}

func (h *IMHelper) SendGroupCustomMsg(ctx context.Context, u *UserLite, groupID string, m ICustomMsg) (*msg.SendMsgResp, error) {
	ctx = context.WithValue(ctx, open_im_api.CtxApiToken, open_im_api.GetAdminToken())
	req := &apistruct.SendMsgReq{
		RecvID: "",
		SendMsg: apistruct.SendMsg{
			SendID:           u.UserID,
			GroupID:          groupID,
			SenderFaceURL:    u.FaceURL,
			SenderNickname:   u.NickName,
			SenderPlatformID: constant.AdminPlatformID,
			Content:          m.Build().ToMap(),
			ContentType:      constant.Custom,
			SessionType:      constant.SuperGroupChatType,
		},
	}
	logger.Infof(ctx, "SendMsg, req: %+v", req)
	resp, err := h.c.SendMsg(ctx, req)
	logger.Infof(ctx, "SendMsg, resp: %+v, err: %v", resp, err)
	return resp, err
}

func (h *IMHelper) SendGroupMsg(ctx context.Context, userID, groupID string) (*msg.SendMsgResp, error) {
	// todo 发文本有BUG, 等更新openim版本修复
	ctx = context.WithValue(ctx, open_im_api.CtxApiToken, open_im_api.GetAdminToken())
	req := &apistruct.SendMsgReq{
		RecvID: "",
		SendMsg: apistruct.SendMsg{
			SendID:           userID,
			GroupID:          groupID,
			SenderFaceURL:    "workshop/secret/def/male.jpg",
			SenderNickname:   "fff",
			SenderPlatformID: constant.AdminPlatformID,
			Content:          map[string]interface{}{"text": "{\"content\":\"hello world\"}", "content": "hello world2"},
			ContentType:      constant.Text,
			SessionType:      constant.SuperGroupChatType,
		},
	}
	resp, err := h.c.SendMsg(ctx, req)
	return resp, err
}

func (h *IMHelper) AsyncUpdateUserInfo(ctx context.Context, user *sdkws.UserInfo) error {
	ctx = context.WithValue(context.Background(), open_im_api.CtxApiToken, open_im_api.GetAdminToken())
	go utils.Try(3, time.Second, func() error {
		check, _, err := h.c.AccountCheck(ctx, []string{user.UserID})
		if err != nil {
			logger.Errorf(ctx, "AccountCheck fail, uid: %v, err: %v", user.UserID, err)
			return err
		}
		if !check {
			return nil
		}

		err = h.c.UpdateUserInfo(ctx, user.UserID, user.Nickname, user.FaceURL)
		if err != nil {
			logger.Errorf(ctx, "UpdateUserInfo fail, uid: %v, err: %v", user.UserID, err)
			return err
		}
		return nil
	})
	return nil
}

// BatchUpdateUserInfo 同步更新用户信息
func (h *IMHelper) BatchUpdateUserInfo(ctx context.Context, users []*sdkws.UserInfo) error {
	if len(users) == 0 {
		return nil
	}

	ctx = context.WithValue(ctx, open_im_api.CtxApiToken, open_im_api.GetAdminToken())

	for _, u := range users {
		err := h.c.UpdateUserInfo(ctx, u.UserID, u.Nickname, u.FaceURL)
		if err != nil {
			logger.Errorf(ctx, "UpdateUserInfo fail, user: %v, err: %v", u, err)
			return err
		}
	}
	return nil
}
