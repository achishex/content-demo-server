package mg_model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type ISecretUserMedalInfoMgModel interface {
	GetById(ctx context.Context, userId, modelId int64) (*pbapi.SecretUserMedalInfoMgDbModel, error)
	ListByUserId(ctx context.Context, workId int64) ([]*pbapi.SecretUserMedalInfoMgDbModel, error)
	ListByCond(ctx context.Context, cond map[string]interface{}) ([]*pbapi.SecretUserMedalInfoMgDbModel, error)
	UpdateDictById(ctx context.Context, id int64, update map[string]interface{}, incDict map[string]int) error
	Insert(ctx context.Context, item *pbapi.SecretUserMedalInfoMgDbModel) error
	CreateOrUpdateRecord(ctx context.Context, item *pbapi.SecretUserMedalInfoMgDbModel) error
	GetOneByMediaAndUserId(ctx context.Context, userId, medalId int64) (*pbapi.SecretUserMedalInfoMgDbModel, error)
}

type SecretUserMedalInfoMgDbImpl struct {
	MgDB *mongo.Database
}

func NewSecretUserMedalInfoMgModelImpl(db *mongo.Database) ISecretUserMedalInfoMgModel {
	return &SecretUserMedalInfoMgDbImpl{MgDB: db}
}
func (impl *SecretUserMedalInfoMgDbImpl) table() string {
	return "secretUserMedalInfo"
}
func (impl *SecretUserMedalInfoMgDbImpl) GetOneByMediaAndUserId(ctx context.Context, userId, medalId int64) (*pbapi.SecretUserMedalInfoMgDbModel, error) {
	filter := bson.D{
		{"medalId", medalId},
		{"userId", userId},
	}
	var medalInfo = &pbapi.SecretUserMedalInfoMgDbModel{}
	result := impl.MgDB.Collection(impl.table()).FindOne(ctx, filter)
	//var m map[string]interface{}
	err := result.Decode(medalInfo)
	if err != nil {
		return nil, err
	}
	return medalInfo, nil
}

func (impl *SecretUserMedalInfoMgDbImpl) CreateOrUpdateRecord(ctx context.Context, item *pbapi.SecretUserMedalInfoMgDbModel) error {
	record, err := impl.GetById(ctx, item.GetUserId(), item.GetMedalId())
	if err != nil {
		logger.Error(ctx, "SecretUserMedalInfoMgDbImpl. CreateOrUpdateRecord getByid failed. ", err)
		return err
	}
	if record == nil {
		err = impl.Insert(ctx, item)
		if err != nil {
			logger.Error(ctx, "SecretUserMedalInfoMgDbImpl. CreateOrUpdateRecord. Insert failed, err", err)
			return err
		}
		logger.Infof(ctx, "SecretUserMedalInfoMgDbImpl. Create suc, item=%v", utils.StructToJsonString(item))
	} else {
		update := map[string]interface{}{
			"userId":    item.UserId,
			"medalId":   item.MedalId,
			"expire":    item.Expire,
			"timestamp": item.Timestamp,
		}
		err = impl.UpdateDictById(ctx, record.GetId(), update, nil)
		if err != nil {
			logger.Error(ctx, "SecretUserMedalInfoMgDbImpl. CreateOrUpdateRecord. UpdateDictById failed, err", err)
			return err
		}
		logger.Infof(ctx, "SecretUserMedalInfoMgDbImpl. UpdateDictById suc, item=%v", utils.StructToJsonString(item))
	}
	return nil
}

func (impl *SecretUserMedalInfoMgDbImpl) GetById(ctx context.Context, userId, modelId int64) (*pbapi.SecretUserMedalInfoMgDbModel, error) {
	retItems := make([]*pbapi.SecretUserMedalInfoMgDbModel, 0)
	collection := impl.MgDB.Collection(impl.table())
	find, err := collection.Find(ctx, bson.M{"userId": userId, "medalId": modelId})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserMedalInfoMgDbImpl Find failed. userId=%v, modelId=%v",
			userId, modelId), err)
		return nil, err
	}

	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.SecretUserMedalInfoMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretUserMedalInfoMgDbImpl failed. userId=%v, modelId=%v",
				userId, modelId), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	if len(retItems) > 1 {
		logger.Error(ctx, fmt.Sprintf("get SecretUserMedalInfoMgDbImpl failed.userId=%v, modelId=%v",
			userId, modelId), err)
	}
	return retItems[0], err
}

// 查不到返回nil
func (impl *SecretUserMedalInfoMgDbImpl) ListByUserId(ctx context.Context, userId int64) ([]*pbapi.SecretUserMedalInfoMgDbModel, error) {
	retItems := make([]*pbapi.SecretUserMedalInfoMgDbModel, 0)
	collection := impl.MgDB.Collection("secretUserMedalInfo")
	find, err := collection.Find(ctx, bson.M{
		"userId": userId,
		//"expire": bson.M{"$gte": time.Now().UnixNano() / 1e6},		//todo
	})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserMedalInfoMgDbModel Find failed.userId=%v",
			userId), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.SecretUserMedalInfoMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretUserMedalInfoMgDbModel failed.userId=%v",
				userId), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	return retItems, err
}

func (impl *SecretUserMedalInfoMgDbImpl) ListByCond(ctx context.Context, cond map[string]interface{}) ([]*pbapi.SecretUserMedalInfoMgDbModel, error) {

	retItems := make([]*pbapi.SecretUserMedalInfoMgDbModel, 0)
	collection := impl.MgDB.Collection("secretUserMedalInfo")
	find, err := collection.Find(ctx, cond)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserMedalInfoMgDbModel Find failed. cond=%v", cond), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.SecretUserMedalInfoMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretUserMedalInfoMgDbModel failed.cond=%v",
				cond), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	return retItems, err
}

func (impl *SecretUserMedalInfoMgDbImpl) Insert(ctx context.Context, item *pbapi.SecretUserMedalInfoMgDbModel) error {
	collection := impl.MgDB.Collection(impl.table())
	_, err := collection.InsertOne(ctx, item)
	//print(result, err)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserMedalInfoMgDbImpl.Insert  failed. item=%v",
			item), err)
	}
	return err
}

func (impl *SecretUserMedalInfoMgDbImpl) UpdateDictById(ctx context.Context, id int64,
	updateDict map[string]interface{}, incDict map[string]int) error {
	if len(updateDict)+len(incDict) == 0 {
		return nil
	}
	collection := impl.MgDB.Collection(impl.table())
	updates := bson.D{}
	if len(updateDict) > 0 {
		updates = append(updates, bson.E{"$set", updateDict})
	}
	if len(incDict) > 0 {
		updates = append(updates, bson.E{"$inc", incDict})
	}

	_, err := collection.UpdateByID(ctx, id, updates)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserMedalInfoMgDbImpl.UpdateDictById  failed. id=%v, updateDict=%v, incDict=%v",
			id, updateDict, incDict), err)
	}
	return err
}
