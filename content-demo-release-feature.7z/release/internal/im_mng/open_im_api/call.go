package open_im_api

import (
	"bytes"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/snow_flake"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"

	constant2 "github.com/OpenIMSDK/protocol/constant"
	"github.com/OpenIMSDK/tools/errs"
)

const (
	CtxApiToken = "api-token"
)

type baseApiResponse[T any] struct {
	ErrCode int    `json:"errCode"`
	ErrMsg  string `json:"errMsg"`
	ErrDlt  string `json:"errDlt"`
	Data    *T     `json:"data"`
}

type ApiCaller[Req, Resp any] interface {
	Call(ctx context.Context, req *Req) (*Resp, error)
}

func NewApiCaller[Req, Resp any](api string, prefix func() string) ApiCaller[Req, Resp] {
	return &caller[Req, Resp]{
		api:    api,
		prefix: prefix,
	}
}

type caller[Req, Resp any] struct {
	api    string
	prefix func() string
}

func (a caller[Req, Resp]) Call(ctx context.Context, req *Req) (*Resp, error) {
	resp, err := a.call(ctx, req)
	if err != nil {
		logger.Infof(ctx, "caller resp", err)
		return nil, err
	}
	logger.Infof(ctx, "resp", resp)
	return resp, nil
}

func (a caller[Req, Resp]) call(ctx context.Context, req *Req) (*Resp, error) {
	url := a.prefix() + a.api
	logger.Infof(ctx, "caller req", "addr", url, "req", req)
	reqBody, err := json.Marshal(req)
	if err != nil {
		return nil, err
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(reqBody))
	if err != nil {
		return nil, err
	}
	opID := requestid.GetRequestID(ctx)
	if opID == "" {
		opID = fmt.Sprintf("req_%v", snow_flake.GetSnowflakeID())
	}
	request.Header.Set(constant2.OperationID, opID)
	if token, _ := ctx.Value(CtxApiToken).(string); token != "" {
		request.Header.Set(constant2.Token, token)
		logger.Infof(ctx, "req token", "token", token)
	}
	response, err := http.DefaultClient.Do(request)
	if err != nil {
		return nil, err
	}
	logger.Infof(ctx, "call caller successfully", "code", response.Status)
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return nil, errors.New(response.Status)
	}
	data, err := io.ReadAll(response.Body)
	if err != nil {
		return nil, err
	}
	logger.Infof(ctx, "read respBody successfully", "body", string(data))
	var resp baseApiResponse[Resp]
	if err := json.Unmarshal(data, &resp); err != nil {
		return nil, err
	}
	if resp.ErrCode != 0 {
		return nil, errs.NewCodeError(resp.ErrCode, resp.ErrMsg).WithDetail(resp.ErrDlt)
	}
	return resp.Data, nil
}
