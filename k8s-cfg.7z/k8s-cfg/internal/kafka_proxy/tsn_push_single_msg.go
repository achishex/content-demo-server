package kafka_proxy

import (
	"content_svr/config"
	"content_svr/protobuf/pbkfk"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	"github.com/Shopify/sarama"
	"github.com/gogo/protobuf/proto"
)

type customContentInfo struct {
	FromUserId int64  `json:"from_user_id,omitempty"`
	WorkId     int64  `json:"work_id,omitempty"`
	MsgType    int32  `json:"msg_type"` // 1:官方消息，2:私聊消息 3:群聊
	GroupId    string `json:"group_id,omitempty"`
}

func (p *KafkaProxyImpl) TsnPushMessage(ctx context.Context, intentStr string, customInfo *customContentInfo, messageData *pbkfk.TsnPushSingleMessageDto) error {

	if messageData == nil || customInfo == nil || customInfo.FromUserId == 0 || len(messageData.GetUserIds()) == 0 {
		return nil
	}

	topic := getTopic(topicSecretPushMessage)

	tsnEnv := ""
	if config.ServerConfig.Env == "prod" {
		tsnEnv = "product"
	} else {
		tsnEnv = "dev"
	}

	CustomContentDictByte, err := json.Marshal(customInfo)
	kfkData := &pbkfk.TsnPushSingleMessageDto{
		Type:     tsnType_single_message,
		Title:    messageData.Title,
		Subtitle: messageData.Subtitle,
		//PlanId:        nil,
		Content:       messageData.Content,
		Icon:          messageData.Icon,
		CustomContent: proto.String(string(CustomContentDictByte)),
		Intent:        proto.String(intentStr),
		UserIds:       messageData.UserIds,
		MessageType:   proto.String(tsnMsgType_notify),
		Environment:   proto.String(tsnEnv),
	}

	dataBytes, _ := json.Marshal(kfkData)
	msg := &sarama.ProducerMessage{
		Topic:     topic,
		Partition: int32(-1),
		Key:       sarama.StringEncoder(fmt.Sprintf("%v", messageData.UserIds)),
		Value:     sarama.ByteEncoder(dataBytes),
	}
	paritition, offset, err := p.Producer.SendMessage(msg)
	//_, _, err := p.Producer.SendMessage(msg)
	if err != nil {
		logger.Error(ctx, "kafka sendmessage failed.", err)
		return err
	}
	logger.Infof(ctx, "TsnPushSingleMessage kafka send message suc. topic=%v, body=%v, paritition=%v, offset=%v",
		topic, string(dataBytes), paritition, offset)
	return nil
}

func (p *KafkaProxyImpl) TsnPushOfficeMessage(ctx context.Context, workId, fromUserId int64, userId []int64,
	title, subTitle, content, icon string) error {

	intentStr := fmt.Sprintf("mzscheme://com.xiyou.miao/chat?from_user_id=%v&msg_type=%v", fromUserId, 2)

	if workId > 0 || workId == -1 {
		intentStr += fmt.Sprintf("&work_id=%v", workId)
	}

	customInfo := &customContentInfo{
		FromUserId: fromUserId,
		WorkId:     workId,
		MsgType:    1,
	}
	messageData := &pbkfk.TsnPushSingleMessageDto{
		Title:    &title,
		Subtitle: &subTitle,
		//PlanId:        nil,
		Content: &content,
		Icon:    &icon,
		UserIds: userId,
	}

	return p.TsnPushMessage(ctx, intentStr, customInfo, messageData)
}

func (p *KafkaProxyImpl) TsnPushSingleMessage(ctx context.Context, workId, fromUserId, userId int64,
	title, subTitle, content, icon *string) error {

	if fromUserId == 0 || userId == 0 {
		return nil
	}

	topic := getTopic(topicSecretPushMessage)

	tsnEnv := ""
	if config.ServerConfig.Env == "prod" {
		tsnEnv = "product"
	} else {
		tsnEnv = "dev"
	}

	// msg_type: 1-官方消息，2-私聊消息
	CustomContentDict := map[string]interface{}{
		"from_user_id": fromUserId,
		"msg_type":     2,
	}

	intentStr := fmt.Sprintf("mzscheme://com.xiyou.miao/chat?from_user_id=%v&msg_type=%v", fromUserId, 2)

	if workId > 0 || workId == -1 {
		intentStr += fmt.Sprintf("&work_id=%v", workId)
		CustomContentDict["work_id"] = workId
	}

	CustomContentDictByte, err := json.Marshal(CustomContentDict)
	kfkData := &pbkfk.TsnPushSingleMessageDto{
		Type:     tsnType_single_message,
		Title:    title,
		Subtitle: subTitle,
		//PlanId:        nil,
		Content:       content,
		Icon:          icon,
		CustomContent: proto.String(string(CustomContentDictByte)),
		Intent:        proto.String(intentStr),
		UserIds:       []int64{userId},
		MessageType:   proto.String(tsnMsgType_notify),
		Environment:   proto.String(tsnEnv),
	}

	dataBytes, _ := json.Marshal(kfkData)
	msg := &sarama.ProducerMessage{
		Topic:     topic,
		Partition: int32(-1),
		Key:       sarama.StringEncoder(fmt.Sprintf("%v", userId)),
		Value:     sarama.ByteEncoder(dataBytes),
	}
	paritition, offset, err := p.Producer.SendMessage(msg)
	//_, _, err := p.Producer.SendMessage(msg)
	if err != nil {
		logger.Error(ctx, "kafka sendmessage failed.", err)
		return err
	}
	logger.Infof(ctx, "TsnPushSingleMessage kafka send message suc. topic=%v, body=%v, paritition=%v, offset=%v",
		topic, string(dataBytes), paritition, offset)
	return nil
}

func (p *KafkaProxyImpl) TsnPushGroupMessage(ctx context.Context, groupId, fromUserId, title, subTitle, content, icon string, userIds []int64) error {
	if len(userIds) <= 0 || fromUserId == "" {
		return nil
	}

	topic := getTopic(topicSecretPushMessage)

	tsnEnv := ""
	if config.ServerConfig.Env == "prod" {
		tsnEnv = "product"
	} else {
		tsnEnv = "dev"
	}

	// msg_type: 1-官方消息，2-私聊消息 3:群聊
	CustomContentDict := map[string]interface{}{
		"from_user_id": fromUserId,
		"msg_type":     3,
		"group_id":     groupId,
	}

	intentStr := fmt.Sprintf("mzscheme://com.xiyou.miao/chat?from_user_id=%v&msg_type=%v&group_id=%v", fromUserId, 3, groupId)

	CustomContentDictByte, err := json.Marshal(CustomContentDict)
	kfkData := &pbkfk.TsnPushSingleMessageDto{
		Type:     tsnType_single_message,
		Title:    proto.String(title),
		Subtitle: proto.String(subTitle),
		//PlanId:        nil,
		Content:       proto.String(content),
		Icon:          proto.String(icon),
		CustomContent: proto.String(string(CustomContentDictByte)),
		Intent:        proto.String(intentStr),
		UserIds:       userIds,
		MessageType:   proto.String(tsnMsgType_notify),
		Environment:   proto.String(tsnEnv),
	}

	dataBytes, _ := json.Marshal(kfkData)
	msg := &sarama.ProducerMessage{
		Topic:     topic,
		Partition: int32(-1),
		Key:       sarama.StringEncoder(fmt.Sprintf("%v", userIds)),
		Value:     sarama.ByteEncoder(dataBytes),
	}
	paritition, offset, err := p.Producer.SendMessage(msg)
	//_, _, err := p.Producer.SendMessage(msg)
	if err != nil {
		logger.Error(ctx, "kafka sendmessage failed.", err)
		return err
	}
	logger.Infof(ctx, "TsnPushGroupMessage kafka send message suc. topic=%v, body=%v, paritition=%v, offset=%v",
		topic, string(dataBytes), paritition, offset)
	return nil
}
