package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

var _ SecretGameModel = (*customSecretGameModel)(nil)

type (
	// SecretGameModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretGameModel.
	SecretGameModel interface {
		secretGameModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretGame, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretGame, error)
		InsertMany(ctx context.Context, data []*SecretGame, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error)
		Upsert(ctx context.Context, filter, updateData, insertData any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error)
	}

	customSecretGameModel struct {
		*defaultSecretGameModel
	}
)

// NewSecretGameModel returns a model for the mongo.
func NewSecretGameModel(cfg MonConfig, opts ...mon.Option) SecretGameModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), collectionNameSecretGame, opts...)
	return &customSecretGameModel{
		defaultSecretGameModel: newDefaultSecretGameModel(conn),
	}
}

func (m *customSecretGameModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	} else {
		flagType = "default"
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customSecretGameModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretGameModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretGame, error) {
	result := make([]SecretGame, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretGameModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretGame, error) {
	var data SecretGame
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretGameModel) InsertMany(ctx context.Context, data []*SecretGame, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error) {
	now := time.Now().UnixMilli()
	insertData := make([]any, 0)
	for _, datum := range data {
		datum.CreateTime = now
		datum.UpdateTime = now
		insertData = append(insertData, datum)
	}
	return m.conn.InsertMany(ctx, insertData, opts...)
}

func (m *customSecretGameModel) Upsert(ctx context.Context, filter, updateData, insertData any, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error) {
	update := bson.D{
		{"$set", updateData},
		{"$setOnInsert", insertData},
	}

	if len(opts) == 0 {
		opt := options.Update().SetUpsert(true)
		return m.conn.UpdateOne(ctx, filter, update, opt)
	} else {
		return m.conn.UpdateOne(ctx, filter, update, opts...)
	}
}
