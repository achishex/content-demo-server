package subcmd

import (
	"content_svr/pub/logger"
	"context"
	"github.com/spf13/cobra"
)

func NewHelloCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "hello",
		Short: "hello greeting",
		Long:  "",
		RunE: func(_ *cobra.Command, args []string) error {
			ctx := context.Background()
			logger.Info(ctx, "hello")
			return nil
		},
	}
}
