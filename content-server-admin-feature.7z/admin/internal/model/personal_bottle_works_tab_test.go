package model

import (
	"content_svr/config"
	"context"
	"gorm.io/gorm"
	"log"
	"os"
	"testing"
)

var db *gorm.DB

func initMysql() {
	var err error
	db, err = NewDBInstance(config.ServerConfig.MysqlConfig, false)
	if err != nil {
		log.Fatal(err)
	}
}

func TestMain(m *testing.M) {
	initMysql()
	os.Exit(m.Run())
}

func TestPersonalBottleWorksDbModelImpl_UpdateNewCommentCountToCount(t *testing.T) {
	impl := PersonalBottleWorksDbModelImpl{}
	impl.DB = db

	err := impl.UpdateNewCommentCountToCount(context.Background(), []int64{4639808724370432}, 0)
	if err != nil {
		log.Fatal(err)
	}
}
