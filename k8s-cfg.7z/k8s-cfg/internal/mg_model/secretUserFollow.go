package mg_model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretUserFollowMgDbModel interface {
	GetByUserId(ctx context.Context,
		userId, targetUserId int64) (*pbapi.SecretUserFollowMgDbModel, error)
	GetSecretUserFollowByUserId(ctx context.Context,
		filter interface{}, opts ...*options.FindOptions) (user []int64, total int64, err error)
	GetBothFollow(ctx context.Context,
		userId, targetUserId int64) (int32, error)
	ListByCondition(ctx context.Context,
		cond map[string]interface{}, opts *options.FindOptions) ([]*pbapi.SecretUserFollowMgDbModel, error)
	GetMutualCnt(ctx context.Context, filter any) int64

	AddFollow(ctx context.Context, data *pbapi.SecretUserFollowMgDbModel, options *options.InsertOneOptions) error
	UpdateFollow(ctx context.Context, id, update any, options *options.UpdateOptions) error
	DelFollow(ctx context.Context, filter any, options ...*options.DeleteOptions) error

	CountByCondition(ctx context.Context, filter any, opts ...*options.CountOptions) int64
	UpsertMapOne(ctx context.Context, filter, update map[string]interface{}) (*mongo.UpdateResult, error)
	UpsertOne(ctx context.Context, filter, update any) (*mongo.UpdateResult, error)
	FindOne(ctx context.Context, filter any, opts ...*options.FindOneOptions) (*pbapi.SecretUserFollowMgDbModel, error)
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbapi.SecretUserFollowMgDbModel, error)
}

type SecretUserFollowMgDbImpl struct {
	MgDB *mongo.Database
}

func NewSecretUserFollowMgModelImpl(db *mongo.Database) ISecretUserFollowMgDbModel {
	return &SecretUserFollowMgDbImpl{MgDB: db}
}

func (impl *SecretUserFollowMgDbImpl) table() string {
	return "secretUserFollow"
}

func (impl *SecretUserFollowMgDbImpl) GetSecretUserFollowByUserId(
	ctx context.Context, filter interface{}, opts ...*options.FindOptions) (
	userList []int64, total int64, err error) {

	total, err = impl.MgDB.Collection(impl.table()).CountDocuments(ctx, filter)
	if err != nil {
		return nil, 0, err
	}

	userList = make([]int64, 0)
	cursor, err := impl.MgDB.Collection(impl.table()).Find(ctx, filter, opts...)
	for cursor.Next(ctx) {
		item := &pbapi.SecretUserFollowMgDbModel{}
		// 解码绑定数据
		err = cursor.Decode(item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to user_sport_activity_detail failed.err=%v", err), err)
			return nil, 0, err
		}
		userList = append(userList, item.TargetUserId)
	}

	return userList, total, err
}

// GetByUserId 查不到返回nil
func (impl *SecretUserFollowMgDbImpl) GetByUserId(ctx context.Context,
	userId, targetUserId int64) (*pbapi.SecretUserFollowMgDbModel, error) {
	retItems := make([]*pbapi.SecretUserFollowMgDbModel, 0)
	collection := impl.MgDB.Collection("secretUserFollow")
	find, err := collection.Find(ctx, bson.M{"userId": userId, "targetUserId": targetUserId})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserFollowMgDbModel Find failed.userid=%v",
			userId), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.SecretUserFollowMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretUserFollowMgDbModel failed.userid=%v",
				userId), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	if len(retItems) > 1 {
		logger.Error(ctx, fmt.Sprintf("get SecretUserFollowMgDbModel failed.userid=%v",
			userId), err)
	}
	return retItems[0], err
}

func (impl *SecretUserFollowMgDbImpl) GetBothFollow(ctx context.Context,
	userId, targetUserId int64) (int32, error) {
	retItems := make([]*pbapi.SecretUserFollowMgDbModel, 0)
	collection := impl.MgDB.Collection("secretUserFollow")
	ids := []int64{userId, targetUserId}
	find, err := collection.Find(ctx, bson.M{"userId": bson.D{{"$in", ids}}, "targetUserId": bson.D{{"$in", ids}}})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserFollowMgDbModel Find failed.userid=%v",
			userId), err)
		return 0, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.SecretUserFollowMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretUserFollowMgDbModel failed.userid=%v",
				userId), err)
			return 0, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return 0, nil
	}
	if len(retItems) == 2 && retItems[0].GetMutual() == retItems[1].GetMutual() && retItems[0].GetMutual() == 1 {
		logger.Infof(ctx, fmt.Sprintf("get SecretUserFollowMgDbModel, both follow .userid=%v",
			userId), err)
		return 1, err
	}
	return 0, nil
}

func (impl *SecretUserFollowMgDbImpl) ListByCondition(ctx context.Context,
	cond map[string]interface{}, opts *options.FindOptions) ([]*pbapi.SecretUserFollowMgDbModel, error) {
	collection := impl.MgDB.Collection(impl.table())
	find, err := collection.Find(ctx, cond, opts)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserFollowMgDbModel ListByCondition failed. cond=%v",
			cond), err)
		return nil, err
	}
	retItems := make([]*pbapi.SecretUserFollowMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbapi.SecretUserFollowMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretUserFollowMgDbModel failed.cond=%v",
				cond), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (impl *SecretUserFollowMgDbImpl) AddFollow(ctx context.Context, data *pbapi.SecretUserFollowMgDbModel, opts *options.InsertOneOptions) error {
	_, err := impl.MgDB.Collection(impl.table()).InsertOne(ctx, data, opts)
	if err != nil {
		return err
	}
	return nil
}

func (impl *SecretUserFollowMgDbImpl) UpdateFollow(ctx context.Context, id, update any, ops *options.UpdateOptions) error {
	_, err := impl.MgDB.Collection(impl.table()).UpdateByID(ctx, id, update, ops)
	if err != nil {
		return err
	}
	return nil
}

func (impl *SecretUserFollowMgDbImpl) DelFollow(ctx context.Context, filter any, options ...*options.DeleteOptions) error {
	_, err := impl.MgDB.Collection(impl.table()).DeleteOne(ctx, filter, options...)
	if err != nil {
		return err
	}
	return nil
}

func (impl *SecretUserFollowMgDbImpl) GetMutualCnt(ctx context.Context, filter any) int64 {
	total, err := impl.MgDB.Collection(impl.table()).CountDocuments(ctx, filter)
	if err != nil {
		return 0
	}
	return total
}

func (impl *SecretUserFollowMgDbImpl) CountByCondition(ctx context.Context, filter any, opts ...*options.CountOptions) int64 {
	c, err := impl.MgDB.Collection(impl.table()).CountDocuments(ctx, filter, opts...)
	if err != nil {
		return 0
	}

	return c
}

func (impl *SecretUserFollowMgDbImpl) UpsertOne(ctx context.Context, filter, update any) (*mongo.UpdateResult, error) {
	opt := options.Update().SetUpsert(true)
	return impl.MgDB.Collection(impl.table()).UpdateOne(ctx, filter, update, opt)
}
func (impl *SecretUserFollowMgDbImpl) UpsertMapOne(ctx context.Context, filter, update map[string]interface{}) (*mongo.UpdateResult, error) {
	conds := bson.D{}
	for key, value := range filter {
		conds = append(conds, bson.E{Key: key, Value: value})
	}

	data := bson.D{}
	for key, value := range update {
		data = append(data, bson.E{Key: key, Value: value})
	}
	updater := bson.D{
		{Key: "$set", Value: data},
	}

	opt := options.Update().SetUpsert(true)
	return impl.MgDB.Collection(impl.table()).UpdateOne(ctx, conds, updater, opt)
}

func (impl *SecretUserFollowMgDbImpl) FindOne(ctx context.Context, filter any, opts ...*options.FindOneOptions) (*pbapi.SecretUserFollowMgDbModel, error) {
	var follow pbapi.SecretUserFollowMgDbModel
	err := impl.MgDB.Collection(impl.table()).FindOne(ctx, filter, opts...).Decode(&follow)
	if err != nil {
		return nil, err
	}

	return &follow, err
}

func (impl *SecretUserFollowMgDbImpl) Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbapi.SecretUserFollowMgDbModel, error) {
	cur, err := impl.MgDB.Collection(impl.table()).Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	result := make([]*pbapi.SecretUserFollowMgDbModel, 0)
	for cur.Next(ctx) {
		var item pbapi.SecretUserFollowMgDbModel
		if err := cur.Decode(&item); err != nil {
			return nil, err
		}
		result = append(result, &item)
	}

	return result, err
}
