package config

import (
	"content_svr/app/maozhua_admin_svr/common/db"
	"github.com/zeromicro/go-zero/rest"
)

type Config struct {
	rest.RestConf
	ProjectEnv        string
	ImageHost         string
	CheckContentServe string
	ContentServe      string

	MysqlConfig         db.Mysql
	MysqlOnlyReadConfig db.Mysql
	MongoConfig         db.MongoConfig
	MongoOnlyReadConfig db.MongoConfig
	RedisConfig         db.RedisConfig

	ShuMeiConfig struct {
		AccessKey string
		Account   string
		AppId     string
		Channel   string
	}
}
