package aggregation

import (
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/utils"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

type Game struct {
	WriteDB, ReadDB *dao.ManagerDB
}

func (s *Game) Today(ctx context.Context) ([]model.GameStatistical, error) {
	nowDay := utils.ZeroTime(time.Now())
	filter := map[string]interface{}{
		"create_time": bson.D{
			{"$gte", nowDay.UnixMilli()},
		},
		"notify_status": 3,
	}
	channelDaily, err := s.GameOrder(ctx, filter)
	if err != nil {
		return nil, err
	}
	return channelDaily, err

}

func (s *Game) GameOrder(ctx context.Context, filter map[string]interface{}) ([]model.GameStatistical, error) {
	var gameTable = map[string]model.GameStatistical{}

	items, err := s.ReadDB.SecretGameOrder.FindAll(ctx, filter)
	if err != nil {
		return nil, err
	}

	// 聚合数据
	now := time.Now()
	nowZero := utils.ZeroTime(now).UnixMilli()
	var sumAllGame uint
	for _, item := range items {
		price := uint(item.Amount)
		if game, ok := gameTable[item.GameId]; ok {
			game.AmountSum += price
			gameTable[item.GameId] = game
		} else {
			var gameName string
			gameInfo, err := s.ReadDB.SecretGame.FindOne(ctx, map[string]interface{}{
				"game_id": item.GameId,
			})
			if err == nil {
				gameName = gameInfo.GameName
			}
			if err != nil {
				return nil, err
			}
			day := time.UnixMilli(item.CreateTime)
			gameTable[item.GameId] = model.GameStatistical{
				GameId:    item.GameId,
				GameName:  gameName,
				AmountSum: price,
				Day:       utils.ZeroTime(day).UnixMilli(),
				//CreateTime: nowZero,
				UpdateTime: nowZero,
			}
		}

		sumAllGame += uint(item.Amount)
	}

	statisticalList := make([]model.GameStatistical, 0)
	for _, statistical := range gameTable {
		statisticalList = append(statisticalList, statistical)
	}

	return statisticalList, nil
}
