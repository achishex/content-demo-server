package work

import (
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type WorkUpdateLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewWorkUpdateLogic(ctx context.Context, svcCtx *svc.ServiceContext) *WorkUpdateLogic {
	return &WorkUpdateLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *WorkUpdateLogic) WorkUpdate(req *types.WorkUpdateRes) (resp *types.WorkUpdateResp, err error) {

	_db := l.svcCtx.ManagerDB.PersonalBottleWork
	_, err = _db.Where(_db.ID.Eq(req.ID)).Update(_db.ShowScope, req.ShowScope)
	if err != nil {
		return nil, err
	}

	return
}
