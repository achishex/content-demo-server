package content_mng

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mongodb/model"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/busi_comm/version"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/utils"
	"content_svr/setting"
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
	"google.golang.org/protobuf/proto"
	"math"
	"strconv"
	"time"
)

var moneyPlanTaskList = []pbuserapi.MoneyPlanItem{
	{
		Type:        model.AwardCommentFirst,
		Desc:        "发送首条评论",
		CounterDesc: "发送\n评论",
	},
	{
		Type:        model.FirstWorkSettlement,
		Desc:        "分享动态",
		CounterDesc: "分享\n动态",
		//ShowStatus:  1,
	},
	{
		Type:        model.AwardGameTime,
		Desc:        "累计玩游戏%v分钟",
		CounterDesc: "玩玩\n游戏",
	},
	{
		Type:        model.AwardGroupByCreate,
		Desc:        "创建群聊",
		CounterDesc: "创建\n群聊",
	},
	{
		Type:        model.AwardGroupUserByActive,
		Desc:        "群聊活跃用户达%v人",
		CounterDesc: "活跃\n群聊",
	},
	{
		Type:        model.AwardSignAd,
		Desc:        "签到领红包",
		CounterDesc: "完成\n签到",
	},
	{
		Type:       model.AwardSettlement,
		Desc:       "单条动态有效评论人数达10人",
		ShowStatus: 1,
	},
	{
		Type:       model.AwardSettlement,
		Desc:       "单条动态有效评论人数达50人",
		ShowStatus: 1,
	},
	{
		Type: model.AwardStarSignAd,
		Desc: "查看星座运势",
	},
	{
		Type: model.AwardSportAd,
		Desc: "提交猫爪运动成绩",
	},
	{
		Type:       model.HallOfFameAwardSettlement,
		Desc:       "登榜可乐名人堂",
		ShowStatus: 1,
	},
}

const (
	clientTypeOld = 0
	clientApp     = 1
	clientH5      = 2
)

const (
	moneyPlanTaskUncompleted = 1
	moneyPlanTaskCompleted   = 2
)

func (p *ContentMng) UploadReward(ctx *gin.Context, req *pbuserapi.UploadRewardReq) (*pbuserapi.UploadRewardResp, error) {
	resp := &pbuserapi.UploadRewardResp{}
	now := time.Now()
	zeroTime := utils.ZeroTime(now)
	userId := middleware.GetUserID(ctx)
	loginUser, err := p.DataCache.GetUserInfoLocal(ctx, nil, userId, false)
	if err != nil || loginUser == nil {
		logger.Error(ctx, "", err)
		return nil, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "用户不存在")
	}

	//fmt.Println("get lock")
	//lock, err := p.ManagerDB.UserRewardMoneyActivity.Lock.GetLock(ctx, zeroTime.UnixMilli(), userId)
	//if err != nil {
	//	return err
	//}
	//defer p.ManagerDB.UserRewardMoneyActivity.Lock.UnLock(ctx, lock)
	//fmt.Println("running")
	//time.Sleep(time.Second * 5)

	switch req.GetType() {
	case model.AwardViewWork, 1:
		if req.GetViewWork() == 0 && req.GetScope() == 0 {
			return nil, errorcode.PARAM_ERROR
		}
		req.Type = model.AwardViewWork
	case model.AwardGameTime, 2:
		if req.GetGameTime() == 0 && req.GetScope() == 0 {
			return nil, errorcode.PARAM_ERROR
		}
		req.Type = model.AwardGameTime
	case model.AwardSportAd, 3:
		req.Type = model.AwardSportAd
	case model.AwardStarSignAd, 4:
		req.Type = model.AwardStarSignAd
	case model.AwardSignAd, 5:
		req.Type = model.AwardSignAd
	default:
		return nil, errorcode.PARAM_ERROR
	}

	filter := map[string]interface{}{
		"user_id": userId,
		"day":     zeroTime.UnixMilli(),
		"type":    req.GetType(),
	}

	var exist = true
	moneyPlan, err := p.ManagerDB.UserRewardMoneyActivity.FindOne(ctx, filter)
	switch err {
	case xerr.DbNotFound:
		moneyPlan = &model.UserRewardMoneyActivity{
			UserId:   userId,
			Day:      zeroTime.UnixMilli(),
			Type:     req.GetType(),
			Complete: false,
		}
		exist = false
	case nil:
		break
	default:
		return nil, err
	}

	var content string
	var reward, scope, total uint64
	switch req.GetType() {
	case model.AwardViewWork:
		total = moneyPlan.Scope + req.GetViewWork() + req.GetScope()
		if moneyPlan.RewardCount >= setting.Maozhua.RewardAdViewWorkTaskMax.Get() {
			break
		}

		scope = req.GetViewWork() + req.GetScope()
		moneyPlan.Scope += scope
		if moneyPlan.Scope%setting.Maozhua.RewardAdViewWorkTaskTarget.Get() != 0 {
			err = p.ManagerDB.UserRewardMoneyActivity.Upsert(ctx, moneyPlan)
			if err != nil {
				return nil, err
			}
			break
		}
		content = "零花钱指南-刷动态领红包"
		reward = setting.Maozhua.RewardAdViewWork.Get()

	case model.AwardGameTime:
		total = moneyPlan.Scope + req.GetGameTime() + req.GetScope()
		if moneyPlan.Complete {
			break
		}
		scope = req.GetGameTime() + req.GetScope()
		moneyPlan.Scope += scope
		if total < setting.Maozhua.GameRewardPlayTime.Get() {
			err = p.ManagerDB.UserRewardMoneyActivity.Upsert(ctx, moneyPlan)
			if err != nil {
				return nil, err
			}
			break
		}

		content = "零花钱指南-玩游戏领红包"
		reward = setting.Maozhua.GameRewardPlay.Get()

	case model.AwardSportAd:
		// 判断是否达到上限金额
		amount := setting.Maozhua.RewardAdSingle.Get()
		maxAmount := moneyPlan.RewardCount * amount
		if maxAmount >= setting.Maozhua.RewardAdDayMax.Get() {
			break
		}

		content = "看视频领红包"
		reward = setting.Maozhua.RewardAdSingle.Get()

	case model.AwardStarSignAd, model.AwardSignAd:
		if exist {
			break
		}
		content = "看视频领红包"
		reward = setting.Maozhua.RewardAdSingle.Get()

	}

	resp.Reward = reward
	resp.Total = total
	if reward > 0 {
		if err := p.ManagerDB.UserRewardMoneyActivity.FinishTask(ctx, userId, req.GetType(), scope); err != nil {
			return nil, err
		}
		amount := float64(reward) / 100
		if err := p.awardMoneyAndNotify(ctx, content, amount, userId, req.Type); err != nil {
			return nil, err
		}
	}

	return resp, err
}

func (p *ContentMng) MoneyPlan(ctx *gin.Context, req *pbuserapi.MoneyPlanReq) (*pbuserapi.MoneyPlanResp, error) {
	userId := middleware.GetUserID(ctx)
	loginUser, err := p.DataCache.GetUserInfoLocal(ctx, nil, userId, false)
	if err != nil || loginUser == nil {
		logger.Error(ctx, "", err)
		return nil, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "用户不存在")
	}
	canWithdrawAward, _ := p.GetCanWithdrawAwardByUserId(ctx, userId)
	resp := &pbuserapi.MoneyPlanResp{
		MoneyPlanItems:    nil,
		CanWithdrawAwards: canWithdrawAward,
	}

	zeroTime := utils.ZeroTime(time.Now())
	filter := map[string]interface{}{
		"user_id": userId,
		"day":     zeroTime.UnixMilli(),
	}
	//lock, err := p.ManagerDB.UserRewardMoneyActivity.Lock.GetLock(ctx, zeroTime.UnixMilli(), userId)
	//if err != nil {
	//	return nil, err
	//}
	//defer p.ManagerDB.UserRewardMoneyActivity.Lock.UnLock(ctx, lock)
	rewardList, err := p.ManagerDB.UserRewardMoneyActivity.FindAll(ctx, filter)
	if err != nil {
		return nil, err
	}
	rewardMap := map[int32]model.UserRewardMoneyActivity{}
	for _, activity := range rewardList {
		rewardMap[activity.Type] = activity
	}

	// 浏览动态任务
	viewWork := make([]*pbuserapi.MoneyPlanItem, 0)
	var i uint64
	for i = 0; i < setting.Maozhua.RewardAdViewWorkTaskMax.Get(); i++ {
		reward := rewardMap[model.AwardViewWork]
		targetCount := setting.Maozhua.RewardAdViewWorkTaskTarget.Get() * (i + 1)
		var completed uint32 = moneyPlanTaskUncompleted
		if reward.Scope >= targetCount {
			completed = moneyPlanTaskCompleted
		}
		var item = &pbuserapi.MoneyPlanItem{
			Count:       reward.Scope,
			TargetCount: targetCount,
			Reward:      setting.Maozhua.RewardAdViewWork.Get(),
			Type:        model.AwardViewWork,
			Status:      completed,
		}
		viewWork = append(viewWork, item)
	}

	moneyPlanItems := make([]*pbuserapi.MoneyPlanItem, 0) // 返回的任务列表
	switch req.Client {
	case clientTypeOld:
		resp.MoneyPlanItems = viewWork
		return resp, nil
	case clientApp:
		moneyPlanItems = append(moneyPlanItems, viewWork...)
	case clientH5:
		break
	}
	for i := 0; i < len(moneyPlanTaskList); i++ {
		if req.Client == clientApp && moneyPlanTaskList[i].CounterDesc == "" {
			continue
		}
		reward := rewardMap[moneyPlanTaskList[i].Type]
		var completed uint32 = moneyPlanTaskUncompleted
		if reward.Complete {
			completed = moneyPlanTaskCompleted
		}
		var targetCount, money uint64
		//var showStatus = moneyPlanTaskList[i].ShowStatus

		var desc = moneyPlanTaskList[i].Desc
		switch moneyPlanTaskList[i].Type {
		case model.AwardSettlement:
			if desc == "单条动态有效评论人数达10人" {
				targetCount = 10
				money = uint64(math.Round(setting.Maozhua.Level1WorkAward.Get() * 100))
			} else {
				targetCount = 50
				money = uint64(math.Round(setting.Maozhua.Level2WorkAward.Get() * 100))
			}
		//case model.DeductionIllegal:
		case model.FirstWorkSettlement:
			if !version.IsSuperiorContentVersionUser(ctx, loginUser.UserInfoDbModel.GetCreateTime()) {
				continue
			}

			count, err := p.judgeFirstWork(ctx, loginUser.UserInfoDbModel, func() {
				completed = moneyPlanTaskUncompleted
			})
			if err != nil {
				return nil, err
			}

			switch {
			case loginUser.UserInfoDbModel.GetGender() == const_busi.Boy && count == 1:
				continue
			case loginUser.UserInfoDbModel.GetGender() == const_busi.Girl && count > 4:
				continue
			case loginUser.UserInfoDbModel.GetGender() == const_busi.Girl && count == 4:
				if reward.ID.IsZero() {
					continue
				}
			}

			money = uint64(math.Round(setting.Maozhua.AwardFirstWork.Get() * 100))
		//case model.WechatPayWithdrawing:
		//case model.WechatPayWithdrawSuccess:
		//case model.WechatPayWithdrawFail:
		case model.HallOfFameAwardSettlement:
			money = setting.Maozhua.RewardKoLaHallOfFame.Get()
		case model.SignLevelUpAward:
			money = setting.Maozhua.RewardAdSingle.Get()
		//case model.AwardViewWork:
		//	targetCount = setting.Maozhua.RewardAdViewWorkTaskTarget.Get()
		//	money = setting.Maozhua.RewardAdViewWork.Get()
		case model.AwardGameTime:
			targetCount = setting.Maozhua.GameRewardPlayTime.Get()
			money = setting.Maozhua.GameRewardPlay.Get()

			minterTarget := targetCount / 60
			desc = fmt.Sprintf(moneyPlanTaskList[i].Desc, minterTarget)
		case model.AwardSportAd, model.AwardStarSignAd, model.AwardSignAd:
			if loginUser.MemberType != 0 {
				// todo 会员不返回广告相关任务
				continue
			}
			money = setting.Maozhua.RewardAdSingle.Get()
		//case model.PartnerInviteReward:
		//case model.PartnerCarveUp:
		//case model.AwardSendShare:
		case model.AwardGroupByCreate:
			filter := map[string]interface{}{
				"user_id": userId,
				"type":    model.AwardGroupByCreate,
				//"complete": true,
			}
			result, err := p.ManagerDB.UserRewardMoneyActivity.FindOne(ctx, filter)
			switch err {
			case xerr.DbNotFound:
				completed = moneyPlanTaskUncompleted
			case nil:
				if result.Complete {
					// 不再显示该任务
					//showStatus = 0
					completed = moneyPlanTaskCompleted
					continue
				}
			default:
				logger.Error(ctx, "SuperiorContentAwardDetail.FindOne", err)
			}
			money = setting.Maozhua.RewardCreateGroup.Get()
		case model.AwardGroupUserByActive:
			//filter := map[string]interface{}{
			//	"user_id": userId,
			//	"type":    model.AwardGroupUserByActive,
			//	//"complete": true,
			//}
			//result, err := p.ManagerDB.UserRewardMoneyActivity.FindOne(ctx, filter)
			//switch err {
			//case xerr.DbNotFound:
			//	completed = 1
			//case nil:
			//	if result.Complete {
			//		// 不再显示该任务
			//		showStatus = 0
			//		completed = 2
			//		continue
			//	}
			//	reward = *result
			//default:
			//	logger.Error(ctx, "SuperiorContentAwardDetail.FindOne", err)
			//}
			desc = fmt.Sprintf(moneyPlanTaskList[i].Desc, setting.Maozhua.RewardGroupUserActiveCount.Get())
			money = setting.Maozhua.RewardGroupUserActive.Get()
		case model.AwardCommentFirst:
			money = setting.Maozhua.RewardFirstComment.Get()
		default:
			money = 0
		}

		var item = &pbuserapi.MoneyPlanItem{
			Count:       reward.Scope,
			TargetCount: targetCount,
			Reward:      money,
			Type:        moneyPlanTaskList[i].Type,
			CounterDesc: moneyPlanTaskList[i].CounterDesc,
			Desc:        desc,
			//ShowStatus:  showStatus,
			Status: completed,
		}
		moneyPlanItems = append(moneyPlanItems, item)

	}

	resp.MoneyPlanItems = moneyPlanItems
	return resp, nil
}

func (p *ContentMng) awardMoneyAndNotify(ctx context.Context, content string, money float64, userId int64, itemType int32) error {
	//value := float64(setting.Maozhua.RewardAdSingle.Get()) / 100

	if err := NewSuperiorContentInstance(p, nil, 0).
		WriteNewItem(ctx, 0, userId, "", money, itemType); err != nil {
		logger.Errorf(ctx, "write sign level up on award fail,err: %v", err)
		return err
	}
	canWithdrawAward, _ := p.GetCanWithdrawAwardByUserId(ctx, userId)
	msgData := &pbapi.Wallet{
		Type:       proto.Int32(const_busi.WalletMsgTypeAward),
		Amount:     proto.String(strconv.FormatFloat(money, 'f', 2, 64)),
		Balance:    proto.String(strconv.FormatFloat(canWithdrawAward, 'f', 2, 64)),
		Desc:       proto.String(content),
		CreateTime: proto.Int64(time.Now().UnixMilli()),
	}

	if err := p.SendWalletMsg(ctx, userId, int32(pbconst.MessageTypeEnum_msg_type_wallet_award_notice), content, msgData); err != nil {
		logger.Errorf(ctx, "sendWalletMsg error: %v", err)
		return err
	}

	return nil
}
