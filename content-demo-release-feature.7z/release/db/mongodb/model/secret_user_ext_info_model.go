package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const SecretUserExtInfoCollectionName = "secretUserExtInfo"

var _ SecretUserExtInfoModel = (*customSecretUserExtInfoModel)(nil)

type (
	// SecretUserExtInfoModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretUserExtInfoModel.
	SecretUserExtInfoModel interface {
		secretUserExtInfoModel
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretUserExtInfo, error)
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretUserExtInfo, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
	}

	customSecretUserExtInfoModel struct {
		*defaultSecretUserExtInfoModel
	}
)

// NewSecretUserExtInfoModel returns a model for the mongo.
func NewSecretUserExtInfoModel(cfg MonConfig) SecretUserExtInfoModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SecretUserExtInfoCollectionName)
	return &customSecretUserExtInfoModel{
		defaultSecretUserExtInfoModel: newDefaultSecretUserExtInfoModel(conn),
	}
}

func (m *customSecretUserExtInfoModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			switch k {
			case "user_ids":
				query = append(query, bson.E{Key: "_id", Value: bson.D{
					{"$in", v},
				}})
			default:
				query = append(query, bson.E{Key: k, Value: v})
			}
		}
	}

	return query
}

func (m *customSecretUserExtInfoModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretUserExtInfo, error) {
	result := make([]SecretUserExtInfo, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretUserExtInfoModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretUserExtInfoModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretUserExtInfo, error) {
	var data SecretUserExtInfo
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
