package user

import (
	"content_svr/app/maozhua_admin_svr/common/digc"
	"content_svr/internal/user_level_mng"
	"content_svr/pub/digutil"
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type ChangeUserLevelLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewChangeUserLevelLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ChangeUserLevelLogic {
	return &ChangeUserLevelLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ChangeUserLevelLogic) ChangeUserLevel(req *types.ChangeUserLevelReq) (resp *types.ChangeUserLevelResp, err error) {
	update := map[string]interface{}{
		"ulevel": req.Ulevel,
	}

	err = l.svcCtx.WriteDB.SecretUserExtInfo.UpdateByUserIdCache(l.ctx, req.UserId, update)

	comp, err := digutil.Get[*user_level_mng.UserLvlV2Comp](digc.Container)
	if err != nil {
		return nil, err
	}
	err = comp.ResetUserLvlCheckinCnt(l.ctx, req.UserId, int(req.Ulevel))
	if err != nil {
		return nil, err
	}

	return
}
