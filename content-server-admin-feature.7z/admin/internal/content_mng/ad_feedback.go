package content_mng

import (
	"content_svr/internal/ad_mng"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"encoding/json"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

func (p *ContentMng) adFeedbackV2(ctx context.Context, channel string, machineIds ...string) {
	for _, id := range machineIds {
		if id == "" {
			continue
		}
		code := p.DataCache.GetRedisAdFeedback(ctx, channel, id)
		if code == const_busi.AdFeedbackNil {
			if err := p.DataCache.SetRedisAdFeedback(ctx, channel, id, const_busi.AdFeedbackFormChannel); err != nil {
				logger.Error(ctx, "SetRedisAdFeedback error:", err)
			}
		}
	}
}

func (p *ContentMng) adFeedback(ctx context.Context, channel, imei, oaid string) {
	ImeiCodeOrUserId := p.DataCache.GetRedisAdFeedback(ctx, channel, imei)
	OaidCodeOrUserId := p.DataCache.GetRedisAdFeedback(ctx, channel, oaid)

	switch {
	case ImeiCodeOrUserId > const_busi.AdFeedbackFormChannel:
		// 说明是userId
		// update
		p.adActivityDailyUpdate(ctx, int64(ImeiCodeOrUserId))
	case OaidCodeOrUserId > const_busi.AdFeedbackFormChannel:
		p.adActivityDailyUpdate(ctx, int64(OaidCodeOrUserId))
	case ImeiCodeOrUserId == const_busi.AdFeedbackFormChannel, OaidCodeOrUserId == const_busi.AdFeedbackFormChannel:
		break
	default:
		logger.Infof(ctx, "==market==%s,Imei: %s Oaid: %s\n", channel, imei, oaid)
		if len(imei) > 0 {
			if err := p.DataCache.SetRedisAdFeedback(ctx, channel, imei, const_busi.AdFeedbackFormChannel); err != nil {
				logger.Error(ctx, "SetRedisAdFeedback error:", err)
			}
		}

		if len(oaid) > 0 {
			if err := p.DataCache.SetRedisAdFeedback(ctx, channel, oaid, const_busi.AdFeedbackFormChannel); err != nil {
				logger.Error(ctx, "SetRedisAdFeedback error:", err)
			}
		}
	}
}

func (p *ContentMng) adActivityDailyUpdate(ctx context.Context, userId int64) {
	now := time.Now()
	//dateStr := fmt.Sprintf("%04d%02d%02d", now.Year(), now.Month(), now.Day())
	//day, _ := strconv.Atoi(dateStr)
	day, _ := utils.TimeByDay(now)

	filter := bson.D{
		{"user_id", userId},
		{"day", day},
		{"is_new", 1},
	}
	_, err := p.DataCache.GetImpl().SecretUserActivityDailyMgModel.FindOne(ctx, filter)
	if err != nil {
		logger.Error(ctx, "ad vivo SecretUserActivityDailyMgModel.FindOne", err)
		return
	}

	update := bson.D{
		{"$set", bson.D{
			{"market", 1},
		}},
	}
	_, err = p.DataCache.GetImpl().SecretUserActivityDailyMgModel.Update(ctx, filter, update)
	if err != nil {
		logger.Error(ctx, "ad vivo SecretUserActivityDailyMgModel.UpdateColumnOne", err)
		return
	}
}

func (p *ContentMng) AdVivoFeedback(ctx context.Context, req []*pbapi.AdVivoFeedbackDbModel) (*pbapi.AdVivoFeedbackResp, error) {
	// create vivo
	// update user activity table
	if err := p.DataCache.GetImpl().AdVivoFeedbackDbModel.Create(ctx, req); err != nil {
		return &pbapi.AdVivoFeedbackResp{Code: -1, Msg: "操作失败"}, err
	}

	for _, ad := range req {
		p.adFeedback(ctx, cm_const.AppChannelVivo, ad.GetImei(), ad.GetOaid())
	}

	return &pbapi.AdVivoFeedbackResp{Code: 0, Msg: "操作成功"}, nil
}

func (p *ContentMng) AdOppoFeedback(ctx context.Context, req *pbapi.AdOppoFeedbackReq) (*pbapi.AdOppoFeedbackResp, error) {
	p.adFeedback(ctx, cm_const.AppChannelOppo, req.GetImeiMd5(), req.GetOaid())

	return &pbapi.AdOppoFeedbackResp{Code: 0, Msg: "操作成功"}, nil
}

//func (p *ContentMng) AdXiaomiFeedback(ctx context.Context, req *pbapi.AdXiaomiFeedbackReq) (*pbapi.AdXiaomiFeedbackResp, error) {
//	p.adFeedback(ctx, cm_const.AppChannelXiaomi, req.GetImei(), req.GetOaid())
//
//	resp, err := adXiaomiCallback(ctx, req)
//	if err != nil {
//		logger.Error(ctx, "adXiaomiCallback: ", err)
//		return &pbapi.AdXiaomiFeedbackResp{Code: -2, FailMsg: "", Success: false}, err
//	}
//
//	return resp, nil
//}

func (p *ContentMng) AdXiaomiFeedback(ctx context.Context, req *pbapi.AdXiaomiFeedbackReq) (*pbapi.AdXiaomiFeedbackResp, error) {
	// 文档 https://api.e.mi.com/doc.html#/1.0.0-mdtag9b26f-omd/document-2bd1c4c260259b072818205a8ae20139
	// https://platform.52mengdong.com/platform/api/ad/xiaomi/feedback?response_validate=false&imei=__IMEI__&oaid=__OAID__&click_time=__TS__&app_id=__APPID__&adid=__ADID__&campaign_id=__CAMPAIGNID__&callback=__CALLBACK__&sign=__SIGN__&ua=__UA__&ip=__IP__
	p.adFeedbackV2(ctx, cm_const.AppChannelXiaomi, req.GetImei(), req.GetOaid())

	b, err := json.Marshal(req)
	if err != nil {
		logger.Error(ctx, "json.Marshal", err)
		return nil, err
	}
	//_ = p.DataCache.GetImpl().SetRedisAdCallback(ctx, cm_const.AppChannelXiaomi, req.GetImei(), string(b))
	//_ = p.DataCache.GetImpl().SetRedisAdCallback(ctx, cm_const.AppChannelXiaomi, req.GetOaid(), string(b))
	behavior := ad_mng.NewBehaviorUpCtrl(p.DataCache)
	behavior.SetCallbackData(ctx, cm_const.AppChannelXiaomi, string(b), req.GetImei(), req.GetOaid())

	return &pbapi.AdXiaomiFeedbackResp{Code: 0}, nil
}

func (p *ContentMng) AdBaiduFeedback(ctx context.Context, req *pbapi.AdBaiduFeedbackReq) error {
	// 文档 https://dev2.baidu.com/content?sceneType=0&pageId=101214&nodeId=662&subhead=2.3%20%E5%BA%94%E7%94%A8API%E6%8A%80%E6%9C%AF%E6%8E%A5%E5%85%A5
	// https://platform.52mengdong.com/platform/api/ad/baidu/feedback?imei_md5={{IMEI_MD5}}&os={{OS}}&ip={{IP}}&ua={{UA}}&ts={{TS}}&userid={{USER_ID}}&pid={{PLAN_ID}}&uid={{UNIT_ID}}&aid={{IDEA_ID}}&click_id={{CLICK_ID}}&callback_url={{CALLBACK_URL}}&oaid={{OAID}}
	p.adFeedbackV2(ctx, cm_const.AppChannelBaidu, req.GetImeiMd5(), req.GetOaid())

	b, err := json.Marshal(req)
	if err != nil {
		logger.Error(ctx, "json.Marshal", err)
		return err
	}
	behavior := ad_mng.NewBehaviorUpCtrl(p.DataCache)
	behavior.SetCallbackData(ctx, cm_const.AppChannelBaidu, string(b), req.GetImeiMd5(), req.GetOaid())

	return nil
}

func (p *ContentMng) AdGdtFeedbackReq(ctx context.Context, req *pbapi.AdGdtFeedbackReq) error {
	// https://developers.e.qq.com/docs/guide/user_actions/new_click_data

	return nil
}

func (p *ContentMng) AdToutiaoFeedbackReq(ctx context.Context, req *pbapi.AdToutiaoFeedbackReq) error {
	// https://event-manager.oceanengine.com/docs/8650/h5_api_docs/
	p.adFeedbackV2(ctx, cm_const.AppChannelToutiao, req.GetImei(), req.GetOaid())

	b, err := json.Marshal(req)
	if err != nil {
		logger.Error(ctx, "json.Marshal", err)
		return err
	}
	behavior := ad_mng.NewBehaviorUpCtrl(p.DataCache)
	behavior.SetCallbackData(ctx, cm_const.AppChannelToutiao, string(b), req.GetImei(), req.GetOaid())
	return nil
}

func (p *ContentMng) AdXingtuFeedbackReq(ctx context.Context, req *pbapi.AdXingtuFeedbackReq) error {
	// https://event-manager.oceanengine.com/docs/8650/h5_api_docs/
	p.adFeedbackV2(ctx, cm_const.AppChannelXingtu, req.GetImei(), req.GetOaid())

	b, err := json.Marshal(req)
	if err != nil {
		logger.Error(ctx, "json.Marshal", err)
		return err
	}
	behavior := ad_mng.NewBehaviorUpCtrl(p.DataCache)
	behavior.SetCallbackData(ctx, cm_const.AppChannelXingtu, string(b), req.GetImei(), req.GetOaid())
	return nil
}
