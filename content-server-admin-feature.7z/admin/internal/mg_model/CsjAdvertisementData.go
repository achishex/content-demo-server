package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"errors"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ICsjAdvertisementDataMgModel interface {
	FindOne(ctx context.Context, filter any) (*pbmgdb.CsjAdvertisementDataMgDbModel, error)
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.CsjAdvertisementDataMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.CsjAdvertisementDataMgDbModel, options ...*options.InsertOneOptions) error
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
}

type CsjAdvertisementDataMgModel struct {
	MgDB  *mongo.Database
	Table string
}

func NewCsjAdvertisementDataMgModel(db *mongo.Database) ICsjAdvertisementDataMgModel {
	return &CsjAdvertisementDataMgModel{
		MgDB:  db,
		Table: "csjAdvertisementData",
	}
}

func (g *CsjAdvertisementDataMgModel) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *CsjAdvertisementDataMgModel) FindOne(ctx context.Context, filter any) (*pbmgdb.CsjAdvertisementDataMgDbModel, error) {
	var v *pbmgdb.CsjAdvertisementDataMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if errors.Is(err, mongo.ErrNoDocuments) {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("CsjAdvertisementData FindOne failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *CsjAdvertisementDataMgModel) Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.CsjAdvertisementDataMgDbModel, error) {
	find, err := g.coll().Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	retItems := make([]*pbmgdb.CsjAdvertisementDataMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.CsjAdvertisementDataMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to CsjAdvertisementData failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (g *CsjAdvertisementDataMgModel) Create(ctx context.Context, data *pbmgdb.CsjAdvertisementDataMgDbModel, options ...*options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data, options...)

	if err != nil {
		logger.Errorf(ctx, "CsjAdvertisementData:Create error : %v", err)
		return err
	}

	return nil
}

func (g *CsjAdvertisementDataMgModel) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "CsjAdvertisementData:updateOne error: %v", err)
		return err
	}

	return nil
}
