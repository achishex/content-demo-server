package subcmd

import (
	"content_svr/config"
	"content_svr/internal/palace/job"
	"content_svr/pub/logger"
	"content_svr/setting"
	"context"
	"github.com/go-redis/redis/v8"
	"github.com/spf13/cobra"
	"time"
)

func NewPalaceSettle(job *job.Job, rdb *redis.Client) *cobra.Command {
	timestr := ""

	cmd := &cobra.Command{
		Use:   "palace_settle",
		Short: "palace_settle",
		Long:  "",
		RunE: func(_ *cobra.Command, args []string) error {
			if err := setting.Initialize(rdb, config.ServerConfig.Env); err != nil {
				return err
			}

			ctx := context.Background()
			logger.Info(ctx, "run palace_settle ...")
			runAt := time.Now()
			if timestr != "" {
				if t, err := time.Parse(time.DateTime, timestr); err == nil {
					runAt = t
				}
			}

			logger.Infof(ctx, "run_at %v", runAt)
			if err := job.Settle(ctx, runAt); err != nil {
				logger.Errorf(ctx, "palace_settle err %v", err)
			}

			logger.Info(ctx, "palace_settle done")
			return nil
		},
	}

	cmd.Flags().StringVar(&timestr, "run_at", "", "run at")
	return cmd
}
