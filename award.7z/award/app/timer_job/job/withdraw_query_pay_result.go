package job

import (
	"content_svr/config"
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/internal/thirdparty/wechat_proxy"
	"content_svr/internal/user_center_mng"
	"content_svr/pub/logger"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

type WithdrawPayQueryTask struct {
	ctx             context.Context
	startTime       time.Time
	cfg             *config.SuperiorContentConfig
	mng             data_cache.IDataCacheMng
	ticker          *time.Ticker
	wxProxy         wechat_proxy.IWechatProxy
	isNotifyOrTimer bool // false: timer, true: notify
}

func NewWithdrawPayQueryTask(dataOp data_cache.IDataCacheMng, wxProxy wechat_proxy.IWechatProxy, cfg *config.SuperiorContentConfig) *WithdrawPayQueryTask {
	return &WithdrawPayQueryTask{
		ctx:       context.Background(),
		startTime: time.Now(),
		cfg:       cfg,
		mng:       dataOp,
		wxProxy:   wxProxy,
	}
}
func (p *WithdrawPayQueryTask) LoopOnce(dur int32) {
	withdrawDetailIds, d := p.GetNextTimerVal(p.ctx)
	p.DoWithdrawLogic(withdrawDetailIds)
	if d != time.Duration(dur)*time.Second && d > 0 {
		logger.Infof(p.ctx, "reset timer dur time: %v", d)
		p.ticker.Reset(d)
	}
}
func (p *WithdrawPayQueryTask) DoWithdrawLogic(ids []int64) {
	if len(ids) <= 0 {
		return
	}
	for _, id := range ids {
		if id <= 0 {
			continue
		}
		filter := bson.D{
			{"_id", id},
		}
		detail, err := p.mng.GetImpl().KoLaWithdrawDetailMgModel.FindOneItem(p.ctx, filter)
		if err != nil {
			logger.Errorf(p.ctx, "not find withdraw item from db, err: %v", err)
			continue
		}
		if detail == nil {
			continue
		}
		if detail.GetStatus() == user_center_mng.WithdrawStatusTypeFail ||
			detail.GetStatus() == user_center_mng.WithdrawStatusOK {
			logger.Infof(p.ctx, "_id: %v has exist and has processed, do not logic again", id)
			//....
			content_mng.NewDelayQueue(p.mng.GetImpl().RedisCli).ExcludeMsgItem(p.ctx, id, content_mng.GetWithdrawQueueKey())
		}

		//发起查询。 检查结果。并更新。

		transMoneyHandler := user_center_mng.NewTransMoneyHandler(
			&user_center_mng.UserCenterMng{
				DataCache:  p.mng,
				WxProxy:    p.wxProxy,
				ContentMng: content_mng.NewContentMng(p.mng, nil, nil, nil, nil, nil, nil),
			}, "", id)

		ret, err := transMoneyHandler.QueryTransferBatchResult(p.ctx, detail)
		if err != nil {
			logger.Errorf(p.ctx, "query status result fail, err: %v", err)
			continue
		}
		status, ok := ret[detail.GetId()]
		if !ok {
			continue
		}
		transMoneyHandler.ProcessQueryPayResult(p.ctx, status, detail)
	}
}

func (p *WithdrawPayQueryTask) GetNextTimerVal(ctx context.Context) ([]int64, time.Duration) {
	duration := time.Duration(p.cfg.TimerSettlementSecond) * time.Second
	//
	timeNow := time.Now()
	ids, err := content_mng.NewWithdrawDelayQueue(p.mng.GetImpl().RedisCli).QueryItemsByTimeCond(p.ctx, 0, timeNow.UnixMilli(),
		content_mng.GetWithdrawQueueKey())

	if p.isNotifyOrTimer == true {
		logger.Infof(ctx, "receive notify, ids: %v", ids)
	}

	if len(ids) <= 0 && err == nil {
		id, createTmMill, err := content_mng.NewWithdrawDelayQueue(p.mng.GetImpl().RedisCli).QueryItemLatest(p.ctx, content_mng.GetWithdrawQueueKey())
		if id > 0 && createTmMill > 0 && err == nil {
			duration = time.UnixMilli(createTmMill).Sub(timeNow)
			logger.Infof(ctx, "next awoken on time: %v second from now", duration*time.Second)
		}
	}
	if err != nil {
		logger.Errorf(p.ctx, "use default timer time, query need settlement node fail, err: %v", err)
	}
	return ids, duration
}

func (p *WithdrawPayQueryTask) DoTask() {
	go func() {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf(p.ctx, "catch err: %v", e)
				return
			}
		}()

		p.ticker = time.NewTicker(time.Duration(p.cfg.TimerSettlementSecond) * time.Second)

		waitNotify := content_mng.NewWithdrawDelayQueue(p.mng.GetImpl().RedisCli).WaitNotify(context.Background())
		if waitNotify == nil {
			logger.Errorf(p.ctx, "wait channel on withdraw pay query task is nil")
			return
		}
		for {
			select {
			case <-p.ticker.C:
				p.isNotifyOrTimer = false
				p.LoopOnce(p.cfg.TimerSettlementSecond)

			case <-waitNotify:
				p.isNotifyOrTimer = true
				logger.Infof(context.Background(), "receive delay queue new item notify on WithdrawPayQueryTask")
				p.LoopOnce(p.cfg.TimerSettlementSecond)

			}
		}
	}()
}
