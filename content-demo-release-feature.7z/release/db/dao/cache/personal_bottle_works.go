package cache

import (
	"content_svr/db/dao/operate"
	"content_svr/db/mysqldb/model"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
	"context"
)

type PersonalBottleWork struct {
	query.PersonalBottleWork
	redisManage *query_rds.Manage
}

func NewCachePersonalBottleWork(q *query.Query, redisManage *query_rds.Manage) *PersonalBottleWork {
	return &PersonalBottleWork{
		PersonalBottleWork: query.NewPersonalBottleWorkModel(q.PersonalBottleWork),
		redisManage:        redisManage,
	}
}
func (p *PersonalBottleWork) IncNewCommentCount(ctx context.Context, workId, count int64) error {
	_, err := p.PersonalBottleWork.WithContext(ctx).Where(
		p.PersonalBottleWork.ID.Eq(workId)).Update(p.PersonalBottleWork.NewCommentCount, p.PersonalBottleWork.NewCommentCount.Add(1))
	if err != nil {
		return err
	}

	err = p.redisManage.WorkInfo.IncWorkInfoCount(ctx, workId, "new_comment_count", count)
	if err != nil {
		return err
	}
	return nil
}

func (p *PersonalBottleWork) UpdateWorkVerifyStatus(ctx context.Context, workId int64, verifyStatus int32) error {
	_, err := p.PersonalBottleWork.WithContext(ctx).Where(
		p.PersonalBottleWork.ID.Eq(workId)).Update(p.PersonalBottleWork.VerifyStatus, verifyStatus)
	if err != nil {
		return err
	}

	err = p.redisManage.WorkInfo.SecretWorkRedis.UpdateWorkVerifyStatus(ctx, workId, 1)
	if err != nil {
		return err
	}

	return nil
}

func (p *PersonalBottleWork) FindByWorkId(ctx context.Context, workId int64) (result *model.PersonalBottleWork, err error) {
	_db := p.PersonalBottleWork
	return _db.WithContext(ctx).Where(_db.ID.Eq(workId)).First()
}

func (p *PersonalBottleWork) FindByWorkIds(ctx context.Context, workIds []int64) (results []*model.PersonalBottleWork, err error) {
	_db := p.PersonalBottleWork
	return _db.WithContext(ctx).Where(_db.ID.In(workIds...)).Find()
}

func (p *PersonalBottleWork) FindPage(ctx context.Context, turner operate.PageTurner) (results []*model.PersonalBottleWork, total int64, err error) {
	where, offset, limit := turner.ParseMysql()
	conds := p.PersonalBottleWork.ParseWhere(where)

	count, err := p.PersonalBottleWork.WithContext(ctx).Where(conds...).Count()
	if err != nil {
		return nil, 0, err
	}

	orderCond := turner.ParseMysqlOrderBy(p.PersonalBottleWork.TableName())

	result, err := p.PersonalBottleWork.WithContext(ctx).Where(conds...).Limit(limit).Offset(offset).Order(orderCond).Find()
	if err != nil {
		return nil, 0, err
	}

	return result, count, nil
}

func (p *PersonalBottleWork) Count(ctx context.Context, where map[string]interface{}) (int64, error) {
	conds := p.PersonalBottleWork.ParseWhere(where)
	return p.PersonalBottleWork.Count(ctx, conds)

}
