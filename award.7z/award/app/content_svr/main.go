package main

import (
	"content_svr/app/content_svr/handler"
	"content_svr/app/di"
	"content_svr/config"
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/internal/im_mng"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/router"
	"content_svr/pub/snow_flake"
	"content_svr/setting"
	"context"
	"github.com/go-redis/redis/v8"
)

func main() {
	snow_flake.SetMachineID(config.NodeIdx)

	ctx := context.Background()
	c := di.NewContainer()

	// inint setting
	err := c.Invoke(func(rdb *redis.Client) {
		if err := setting.Initialize(rdb, config.ServerConfig.Env); err != nil {
			panic(err)
		}
		go setting.Monitor()
	})
	if err != nil {
		logger.Errorf(nil, "Initialize setting fail, err: %v", err)
		panic(err)
	}

	// init im
	err = c.Invoke(func(h *handler.AdminHandler,
		dataCache data_cache.IDataCacheMng,
		mng content_mng.IContentMng,
		imHelper *im_mng.IMHelper) {
		imHelper.SendMsgFn = h.SendMsg // TODO 分包解决依赖
		imHelper.SendBBMsgFn = mng.SendBBMsg
		imHelper.DataCache = dataCache
	})
	if err != nil {
		logger.Errorf(ctx, "Initialize imhelper fail, err: %v", err)
		panic(err)
	}

	err = c.Invoke(func(r *router.Router, rdb *redis.Client, dataCache data_cache.IDataCacheMng, h *handler.AdminHandler) {
		r.Engine.Use(middleware.AppTokenMiddleware(rdb))
		r.Engine.Use(middleware.ApiWhiteList(config.ServerConfig))
		r.Engine.Use(middleware.RetainRecord(dataCache))
		handler.SetUrls(r.Engine, h)
		logger.GoZeroLoadLogger()
		logger.DebugLogger(config.ServerConfig.Env)
		logger.Infof(context.Background(), "server starting, port=%v, node_idx=%v....",
			config.ServerConfig.Port, config.NodeIdx)
		r.Run(config.ServerConfig.Port)
	})

	if err != nil {
		logger.Errorf(ctx, "Run fail, err: ", err)
		panic(err)
	}
	logger.Infof(ctx, "quit app")
}
