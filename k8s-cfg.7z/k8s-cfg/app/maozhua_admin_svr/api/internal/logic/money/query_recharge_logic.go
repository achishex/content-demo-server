package money

import (
	"content_svr/db/mongodb/model"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"sort"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type QueryRechargeLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewQueryRechargeLogic(ctx context.Context, svcCtx *svc.ServiceContext) *QueryRechargeLogic {
	return &QueryRechargeLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *QueryRechargeLogic) QueryRecharge(req *types.QueryRechargeReq) (resp *types.QueryRechargeResp, err error) {
	result := map[string][]types.QueryRechargeItem{}
	lineName := map[string]string{}

	{
		// 游戏充值部分
		gameList, err := l.svcCtx.ManagerOnlyReadDB.SecretGame.FindAll(l.ctx, map[string]interface{}{})
		if err != nil {
			return nil, err
		}
		for _, game := range gameList {
			key := "game_" + game.GameId
			lineName[key] = fmt.Sprintf("游戏-%s充值", game.GameName)
			result[key] = make([]types.QueryRechargeItem, 0)
		}

		filter := map[string]interface{}{
			"day": bson.D{
				{"$gte", req.TimeStart},
				{"$lte", req.TimeEnd},
			},
		}
		gameStatisticalList, err := l.svcCtx.ManagerOnlyReadDB.GameStatistical.FindAll(l.ctx, filter)
		if err != nil {
			return nil, err
		}
		gameStatisticalListPatch, err := l.addGameStatistical(gameList, req.TimeEnd)
		if err != nil {
			return nil, err
		}
		gameStatisticalList = append(gameStatisticalList, gameStatisticalListPatch...)
		for _, statistical := range gameStatisticalList {
			key := "game_" + statistical.GameId
			if arr, ok := result[key]; ok {
				result[key] = append(arr, types.QueryRechargeItem{
					Day:       statistical.Day,
					AmountSum: statistical.AmountSum,
					Name:      lineName[key],
				})
			}
		}

	}

	{
		androidKey := "android"
		iosKey := "ios"
		lineName[androidKey] = "Android 会员充值"
		result[androidKey] = make([]types.QueryRechargeItem, 0)
		lineName[iosKey] = "iOS 会员充值"
		result[iosKey] = make([]types.QueryRechargeItem, 0)

		// 会员充值部分
		filter := map[string]interface{}{
			"day": bson.D{
				{"$gte", req.TimeStart},
				{"$lte", req.TimeEnd},
			},
		}
		memberStatistical, err := l.svcCtx.ManagerOnlyReadDB.UserMemberStatistical.FindAll(l.ctx, filter)
		if err != nil {
			return nil, err
		}
		memberStatisticalPatch, err := l.addUserMemberStatistical(req.TimeEnd)
		if err != nil {
			return nil, err
		}
		memberStatistical = append(memberStatistical, memberStatisticalPatch...)
		for _, statistical := range memberStatistical {
			if arr, ok := result[androidKey]; ok {
				result[androidKey] = append(arr, types.QueryRechargeItem{
					Day:       statistical.Day,
					AmountSum: statistical.AndroidSum,
					Name:      lineName[androidKey],
				})
			}

			if arr, ok := result[iosKey]; ok {
				result[iosKey] = append(arr, types.QueryRechargeItem{
					Day:       statistical.Day,
					AmountSum: statistical.IosSum,
					Name:      lineName[iosKey],
				})
			}

		}
	}

	// 补充零值数据
	for key, items := range result {
		mTime := l.zeroTimeMap(req.TimeStart, req.TimeEnd)
		for _, item := range items {
			mTime[item.Day] = true
		}

		newItems := result[key]
		for day, exist := range mTime {
			if !exist {
				newItems = append(newItems, types.QueryRechargeItem{
					Day:       day,
					AmountSum: 0,
					Name:      lineName[key],
				})
			}
		}

		sort.Slice(newItems, func(i, j int) bool {
			return newItems[i].Day < newItems[j].Day
		})
		result[key] = newItems
	}

	resp = &types.QueryRechargeResp{List: result}

	return
}

func (l *QueryRechargeLogic) zeroTimeMap(timeStart, timeEnd int64) map[int64]bool {
	sTime := utils.ZeroTime(time.UnixMilli(timeStart))
	eTime := utils.ZeroTime(time.UnixMilli(timeEnd))

	mTime := map[int64]bool{}
	for sTime.Before(eTime) {
		mTime[sTime.UnixMilli()] = false
		sTime = sTime.AddDate(0, 0, 1)
	}

	return mTime
}

func (l *QueryRechargeLogic) addGameStatistical(gameList []model.SecretGame, timeEnd int64) ([]model.GameStatistical, error) {
	now := time.Now()
	nowZero := utils.ZeroTime(now).UnixMilli()
	if timeEnd < nowZero {
		return nil, nil
	}

	zeroData := make([]model.GameStatistical, 0)
	for _, game := range gameList {
		zeroData = append(zeroData, model.GameStatistical{
			GameId:   game.GameId,
			GameName: game.GameName,
			Day:      nowZero,
		})
	}

	list, err := l.svcCtx.SumManage.GameOrder.GameOrder(l.ctx, map[string]interface{}{
		"create_time": bson.D{
			{"$gte", nowZero},
		},
		"notify_status": 3,
	})
	if err != nil {
		logx.Error(err)
		return zeroData, err
	}

	if len(list) == 0 {
		return zeroData, nil
	}

	return list, err
}

func (l *QueryRechargeLogic) addUserMemberStatistical(timeEnd int64) ([]model.UserMemberStatistical, error) {
	now := time.Now()
	nowZero := utils.ZeroTime(now)
	if timeEnd < nowZero.UnixMilli() {
		return nil, nil
	}

	defaultData := []model.UserMemberStatistical{
		{
			Day: nowZero.UnixMilli(),
		},
	}

	list, err := l.svcCtx.SumManage.UserMember(l.ctx, nowZero.Format("2006-01-02 15:04:05"))
	if err != nil {
		logx.Error(err)
		return defaultData, err
	}

	if len(list) == 0 {
		return defaultData, err
	}

	return list, nil

}
