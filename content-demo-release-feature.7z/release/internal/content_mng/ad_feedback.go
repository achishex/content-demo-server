package content_mng

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"strconv"
	"time"
)

func (p *ContentMng) adFeedback(ctx context.Context, channel, imei, oaid string) {
	ImeiCodeOrUserId := p.DataCache.GetRedisAdFeedback(ctx, channel, imei)
	OaidCodeOrUserId := p.DataCache.GetRedisAdFeedback(ctx, channel, oaid)

	switch {
	case ImeiCodeOrUserId > const_busi.AdFeedbackFormChannel:
		// 说明是userId
		// update
		p.adActivityDailyUpdate(ctx, int64(ImeiCodeOrUserId))
	case OaidCodeOrUserId > const_busi.AdFeedbackFormChannel:
		p.adActivityDailyUpdate(ctx, int64(OaidCodeOrUserId))
	case ImeiCodeOrUserId == const_busi.AdFeedbackFormChannel, OaidCodeOrUserId == const_busi.AdFeedbackFormChannel:
		break
	default:
		logger.Infof(ctx, "==market== Imei: %s Oaid: %s\n", imei, oaid)
		if len(imei) > 0 {
			if err := p.DataCache.SetRedisAdFeedback(ctx, channel, imei, const_busi.AdFeedbackFormChannel); err != nil {
				logger.Error(ctx, "SetRedisAdFeedback error:", err)
			}
		}

		if len(oaid) > 0 {
			if err := p.DataCache.SetRedisAdFeedback(ctx, channel, oaid, const_busi.AdFeedbackFormChannel); err != nil {
				logger.Error(ctx, "SetRedisAdFeedback error:", err)
			}
		}

	}
}

func (p *ContentMng) adActivityDailyUpdate(ctx context.Context, userId int64) {
	now := time.Now()
	dateStr := fmt.Sprintf("%4d%2d%2d", now.Year(), now.Month(), now.Day())
	day, _ := strconv.Atoi(dateStr)

	filter := bson.D{
		{"user_id", userId},
		{"day", day},
		{"is_new", 1},
	}
	_, err := p.DataCache.GetImpl().SecretUserActivityDailyMgModel.FindOne(ctx, filter)
	if err != nil {
		logger.Error(ctx, "ad vivo SecretUserActivityDailyMgModel.FindOne", err)
		return
	}

	update := bson.D{
		{"$set", bson.D{
			{"market", 1},
		}},
	}
	_, err = p.DataCache.GetImpl().SecretUserActivityDailyMgModel.Update(ctx, filter, update)
	if err != nil {
		logger.Error(ctx, "ad vivo SecretUserActivityDailyMgModel.Update", err)
		return
	}
}

func (p *ContentMng) AdVivoFeedback(ctx context.Context, req []*pbapi.AdVivoFeedbackDbModel) (*pbapi.AdVivoFeedbackResp, error) {
	// create vivo
	// update user activity table
	if err := p.DataCache.GetImpl().AdVivoFeedbackDbModel.Create(ctx, req); err != nil {
		return &pbapi.AdVivoFeedbackResp{Code: -1, Msg: "操作失败"}, err
	}

	for _, ad := range req {
		p.adFeedback(ctx, "vivo", ad.GetImei(), ad.GetOaid())
	}

	return &pbapi.AdVivoFeedbackResp{Code: 0, Msg: "操作成功"}, nil
}

func (p *ContentMng) AdOppoFeedback(ctx context.Context, req *pbapi.AdOppoFeedbackReq) (*pbapi.AdOppoFeedbackResp, error) {
	p.adFeedback(ctx, "oppo", req.GetImeiMd5(), req.GetOaid())

	return &pbapi.AdOppoFeedbackResp{Code: 0, Msg: "操作成功"}, nil
}

func (p *ContentMng) AdXiaomiFeedback(ctx context.Context, req *pbapi.AdXiaomiFeedbackReq) (*pbapi.AdXiaomiFeedbackResp, error) {
	p.adFeedback(ctx, "xiaomi", req.GetImei(), req.GetOaid())

	return &pbapi.AdXiaomiFeedbackResp{Code: 0, FailMsg: ""}, nil
}
