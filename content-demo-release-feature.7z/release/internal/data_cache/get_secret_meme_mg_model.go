package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	"time"
)

func (p *DataCacheMng) GetSecretMemeMgDBLd(ctx context.Context, memeId int64) *pbmgdb.SecretMemeMgDbModel {
	//从内存取
	cacheKey := fmt.Sprintf(cache_const.SecretMemeLcache.KeyFmt, memeId)
	expire := cache_const.SecretMemeLcache.Expire
	cResp, exist := p.LocalCache.Get(cacheKey)
	if exist {
		resp, ok := cResp.(*pbmgdb.SecretMemeMgDbModel)
		if ok && resp != nil {
			return resp
		}
	}

	//从mg db取
	item, err := p.MemeMgDbModel.GetById(ctx, memeId)
	if err != nil {
		logger.Errorf(ctx, "get SecretMeme failed. id=%v, err=%v", memeId, err.Error())
		return nil
	}

	// save 到localcache
	if item != nil {
		bSuc := p.LocalCache.Set(cacheKey, item, go_cache.WithEx(time.Duration(expire)*time.Second))
		logger.Infof(ctx, "save SecretMeme to local cache. id=%v, value=%v, bSuc=%v", memeId, item, bSuc)
	}
	return item
}
