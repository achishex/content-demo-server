package im_mng

import (
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"github.com/OpenIMSDK/protocol/constant"
	"github.com/openimsdk/open-im-server/v3/pkg/apistruct"
	cbapi "github.com/openimsdk/open-im-server/v3/pkg/callbackstruct"
	"strconv"
	"unicode/utf8"
)

func (i *IMMng) Callback(ctx context.Context, command string, body []byte) cbapi.CallbackResp {
	switch command {
	case constant.CallbackBeforeSendGroupMsgCommand:
		return cbwrap(i.callbackBeforeSendGroupMsg)(ctx, body)
	case constant.CallbackOfflinePushCommand:
		return cbwrap(i.CallbackOfflinePushCommand)(ctx, body)
	}

	return cbapi.CommonCallbackResp{}
}

func (i *IMMng) callbackBeforeSendGroupMsg(ctx context.Context, in *cbapi.CallbackBeforeSendGroupMsgReq) *cbapi.CallbackBeforeSendGroupMsgResp {
	if in.ContentType == constant.Text {
		elem := &apistruct.TextElem{}
		_ = json.Unmarshal([]byte(in.Content), elem)
		if utf8.RuneCountInString(elem.Content) > 200 {
			return &cbapi.CallbackBeforeSendGroupMsgResp{
				CommonCallbackResp: cbapi.CommonCallbackResp{
					ErrCode: CallbackCommonErrCode,
					ErrMsg:  "内容长度过长",
					ErrDlt:  "内容长度超过200",
				},
			}
		}
		// TODO
	}
	return &cbapi.CallbackBeforeSendGroupMsgResp{}
}

func (i *IMMng) CallbackOfflinePushCommand(ctx context.Context, in *cbapi.CallbackBeforePushReq) *cbapi.CallbackBeforePushResp {
	var userIds []int64
	if len(in.UserIDList) > 0 {
		for _, v := range in.UserIDList {
			uid, err := strconv.ParseInt(v, 10, 64)
			if err != nil {
				logger.Infof(ctx, "非数值uid %v", uid)
				//过滤非数值uid
				continue
			}
			userIds = append(userIds, uid)
		}
	}

	switch in.ContentType {
	case constant.Text:
		var data apistruct.TextElem
		_ = json.Unmarshal([]byte(in.Content), &data)
		in.Content = data.Content
	case constant.Picture:
		in.Content = "您有一条未读【图片】消息！"
	case constant.Voice:
		in.Content = "您有一条未读【语音】消息！"
	case ContentTypeFace:
		in.Content = "您有一条未读【表情】消息！"
	default:
		logger.Infof(ctx, "暂不推送通知类消息 CallbackBeforePushReq:%v", in)
		return &cbapi.CallbackBeforePushResp{
			CommonCallbackResp: cbapi.CommonCallbackResp{},
			UserIDs:            in.UserIDList,
		}
	}

	if err := i.KafkaProxy.TsnPushGroupMessage(ctx, in.GroupID, in.SendID, "您有一条新消息～", "", in.Content, "", userIds); err != nil {
		logger.Errorf(ctx, "IMMng.CallbackOfflinePushCommand.TsnPushGroupMessage error: %v, req: %v", err, in)
		return &cbapi.CallbackBeforePushResp{
			CommonCallbackResp: cbapi.CommonCallbackResp{
				ActionCode: 0,
				ErrCode:    1001,
				ErrMsg:     "消息推送失败",
				ErrDlt:     "消息推送kafka失败",
			},
		}
	}

	return &cbapi.CallbackBeforePushResp{
		CommonCallbackResp: cbapi.CommonCallbackResp{},
		UserIDs:            in.UserIDList,
	}
}

func cbwrap[I, O any](cb func(context.Context, *I) *O) func(context.Context, []byte) *O {
	return func(ctx context.Context, body []byte) *O {
		in := new(I)
		_ = json.Unmarshal(body, in)
		return cb(ctx, in)
	}
}
