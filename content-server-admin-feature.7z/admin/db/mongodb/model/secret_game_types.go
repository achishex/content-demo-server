package model

const collectionNameSecretGame = "secretGame"

type SecretGame struct {
	ID        int64  `json:"id,omitempty" bson:"_id"`
	AppKey    string `json:"app_key,omitempty" bson:"app_key"`
	AppSecret string `json:"app_secret,omitempty" bson:"app_secret"`
	NotifyUrl string `json:"notify_url,omitempty" bson:"notify_url"` //回调通知地址
	Desc      string `json:"desc,omitempty" bson:"desc"`             //游戏说明
	GameId    string `json:"game_id,omitempty" bson:"game_id"`       //游戏id
	GameName  string `json:"game_name,omitempty" bson:"game_name"`   //游戏名称
	GameIcon  string `json:"game_icon,omitempty" bson:"game_icon"`   //游戏图标
	GameUrl   string `json:"game_url,omitempty" bson:"game_url"`     //游戏图标
	DebugMode int32  `json:"debug_mode,omitempty" bson:"debug_mode"` //是否在调试 1为调试中，用户不可见，仅内部白名单用户可见

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` //创建时间
	UpdateTime int64 `json:"update_time,omitempty" bson:"update_time,omitempty"` //更新时间
}
