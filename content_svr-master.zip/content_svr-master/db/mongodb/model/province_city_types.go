package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

const collectionNameProvinceCity = "provinceCity"

type ProvinceCity struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	Province     string `json:"province,omitempty" bson:"province,omitempty"`
	ProvinceCode string `json:"provinceCode,omitempty" bson:"provinceCode,omitempty"`
	City         string `json:"city,omitempty" bson:"city,omitempty"`
	CityCode     string `json:"cityCode,omitempty" bson:"cityCode,omitempty"`

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` //创建时间
	UpdateTime int64 `json:"update_time,omitempty" bson:"update_time,omitempty"` //更新时间
}
