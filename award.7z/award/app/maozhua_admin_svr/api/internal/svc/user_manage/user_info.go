package user_manage

import (
	"content_svr/db/dao"
	mongo "content_svr/db/mongodb/model"
	mysql "content_svr/db/mysqldb/model"
	"context"
)

type UserInfo struct {
	UserInfo           *mysql.UserInfo
	SecretUserExtInfo  *mongo.SecretUserExtInfo
	UserMedals         []mongo.SecretMedalInfo   // 勋章
	PersonalPoliceInfo *mongo.PersonalPoliceInfo // 护卫队
	IsInBlackHouse     bool                      // 小黑屋
	MemberType         int32                     // 会员类型 done	(0非会员 1-svip 2赠送会员 3-普通会员)
	UserPermission     int32                     // getUserPermission(Long userId) {	// DONE 只从redis取。
}

type UserManage struct {
	ManagerDB *dao.ManagerDB
}

func NewUserManage(mdb *dao.ManagerDB) *UserManage {
	return &UserManage{ManagerDB: mdb}
}

func (u *UserManage) getUserInfo(ctx context.Context, userId int64) *UserInfo {
	// todo 等 java 全部迁移后再编写
	// 查redis
	// redis没查到查mongo
	info, err := u.ManagerDB.UserInfo.FindByUserId(ctx, userId)
	if err != nil {
		return nil
	}
	filter := map[string]interface{}{"_id": userId}
	ext, err := u.ManagerDB.SecretUserExtInfo.FindOne(ctx, filter)
	if err != nil {
		return nil
	}
	//filter = map[string]interface{}{"userId": userId, "expire": bson.D{{"$gte", now.UnixMilli()}}}
	//medals, err := u.ManagerDB.SecretUserMedalInfo.FindAll(ctx, filter)
	//if err != nil {
	//	return nil
	//}
	//
	//userMedals := make([]mongo.SecretMedalInfo, 0)
	//for _, medal := range medals {
	//	userMedals = append(userMedals, u.medals[medal.MedalId])
	//}

	userInfo := &UserInfo{
		UserInfo:           info,
		SecretUserExtInfo:  ext,
		UserMedals:         nil,
		PersonalPoliceInfo: nil,
		IsInBlackHouse:     false,
		MemberType:         0,
	}

	return userInfo
	// 优化：若为注销用户，则返回错误，并缓存其注销状态，以免反复穿透数据库
}
