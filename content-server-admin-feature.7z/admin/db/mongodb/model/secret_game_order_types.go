package model

const collectionNameSecretGameOrder = "secretGameOrder"

type SecretGameOrder struct {
	ID string `bson:"_id,omitempty" json:"id,omitempty"`

	UserId       int64  `json:"user_id,omitempty" bson:"user_id"`             //用户id
	GameId       string `json:"game_id,omitempty" bson:"game_id"`             //游戏id
	Amount       int64  `json:"amount,omitempty" bson:"amount"`               //金额（分）
	OutTradeNum  string `json:"out_trade_num,omitempty" bson:"out_trade_num"` //外部订单号
	ProductName  string `json:"product_name,omitempty" bson:"product_name"`   //商品名称
	Extra        string `json:"extra,omitempty" bson:"extra"`                 //额外数据
	PayType      string `json:"pay_type,omitempty" bson:"pay_type"`           //支付方式 JSAPI：公众号支付 NATIVE：扫码支付 APP：APP支付 MICROPAY：付款码支付 MWEB：H5支付 FACEPAY：刷脸支付
	PayPlatform  int32  `json:"pay_platform,omitempty" bson:"pay_platform"`   //支付平台 1：微信；2支付宝 3：苹果
	NotifyStatus int32  `json:"notify_status,omitempty" bson:"notify_status"` //通知状态 1：回调成功 2：重试中 3：放弃通知
	RetryCount   int32  `json:"retry_count,omitempty" bson:"retry_count"`     //重试通知次数
	CreateTime   int64  `json:"create_time,omitempty" bson:"create_time"`     //创建时间
	UpdateTime   int64  `json:"update_time,omitempty" bson:"update_time"`     //更新时间
}
