package m_const

// 评论类型 1:文字；2:图片；3:语音; 12:回复评论 99：表情
const (
	_ = iota
	CommentText
	CommentImage
	CommentTalkMessage
	CommentReply

	CommentEmote = 99
)
