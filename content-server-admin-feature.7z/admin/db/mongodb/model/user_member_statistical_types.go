package model

import "go.mongodb.org/mongo-driver/bson/primitive"

const collectionNameUserMemberStatistical = "userMemberStatistical"

type UserMemberStatistical struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	Day int64 `json:"day" bson:"day"` // 时间戳

	PriceSum uint `json:"price_sum" bson:"price_sum"` // 总计

	QQSum      uint `json:"qq_sum" bson:"qq_sum"`
	WeiXinSum  uint `json:"wei_xin_sum" bson:"wei_xin_sum"`
	AndroidSum uint `json:"android_sum" bson:"android_sum"`
	IosSum     uint `json:"ios_sum" bson:"ios_sum"`
	UnknownSum uint `json:"unknown_sum" bson:"unknown_sum"`

	CreateTime int64 `json:"-" bson:"create_time,omitempty"` // 创建时间
}
