package user_level_mng

import (
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbdb"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"context"
	"github.com/gogo/protobuf/proto"
)

type LevelSession struct {
	UserId         int64
	CurLevel       int32
	newSignTimes   int32
	newCdKeyTimes  int32
	UserExt        *pbapi.SecretUserExtInfoMgDbModel //非nil ext表，必定非空
	UserSignUpItem *pbdb.UserLevelUpRecordDbModel    //可能nil 用户已签到和收集激活码的记录
	WeiGuiTimes    int32                             //违规次数
	DailySigned    bool                              //今天是否已经签到
}

// gei ss 的对应记录增加条数，返回是否成功。
func (ss *LevelSession) checkCodeAndSign(curUserLevel *pbuserapi.LevelInfo,
	addSignupTimes, addCodeTimes int32) bool {
	// 获取用户要升级的 激活码数量。
	if ss.CurLevel == const_level.UserMaxLevel {
		return false
	}

	bLevUp := false
	// 增加
	new_sign_times := curUserLevel.NextLevelCard.GetSignTimes() + addSignupTimes
	new_cdKey_times := curUserLevel.NextLevelCard.GetChitchatCodeTimes() + addCodeTimes

	// 检查是否超过阈值。 超过则设置为最大值
	if new_sign_times >= curUserLevel.NextLevelCard.GetFullSignTimes() {
		new_sign_times = curUserLevel.NextLevelCard.GetFullSignTimes()
	}
	if new_cdKey_times >= curUserLevel.NextLevelCard.GetFullChitchatCodeTimes() {
		new_cdKey_times = curUserLevel.NextLevelCard.GetFullChitchatCodeTimes()
	}

	// 增加后，检查是否达标
	if new_sign_times >= curUserLevel.NextLevelCard.FullSignTimes &&
		new_cdKey_times >= curUserLevel.NextLevelCard.FullChitchatCodeTimes {
		if curUserLevel.GetUlevel() != const_level.UserLevel4 {
			//达标， 全部清0
			new_sign_times = 0
			new_cdKey_times = 0
		}
		bLevUp = true //设置为true
	}
	ss.newSignTimes = new_sign_times
	ss.newCdKeyTimes = new_cdKey_times
	return bLevUp
}

func (ss *LevelSession) getUserLev() *pbuserapi.LevelInfo {
	levelInfoCfg := const_level.GetLevelCfg(ss.CurLevel)
	resp := &pbuserapi.LevelInfo{
		Ulevel:             ss.CurLevel,
		LevelTitle:         levelInfoCfg.Title,
		NextLevelCard:      nil,
		BDailySigned:       ss.DailySigned,
		HasPunishedHistory: false,
	}
	// 今日是否签到
	// 最高级以下，需要封装下一级卡片信息
	if ss.CurLevel < const_level.UserMaxLevel && ss.CurLevel >= const_level.UserLevel0 {
		//下一级信息
		nextLvl := const_level.GetLevelCfg(ss.CurLevel + 1)
		penalties := ss.WeiGuiTimes > 0 // 是否违规
		nextLvl.BuildTaskMessage(penalties)

		//extTimes := 0
		////违规后，需要增加 激活码个数。
		//if ss.WeiGuiTimes > 0 {
		//	resp.HasPunishedHistory = true
		//	switch nextLvl.Level {
		//	case const_level.UserLevel1:
		//		extTimes = const_level.UserChitchatCodeLevel1
		//	case const_level.UserLevel2:
		//		extTimes = const_level.UserChitchatCodeLevel2
		//	case const_level.UserLevel3:
		//		extTimes = const_level.UserChitchatCodeLevel3
		//	case const_level.UserLevel4:
		//		extTimes = const_level.UserChitchatCodeLevel4
		//	case const_level.UserLevel5:
		//		extTimes = const_level.UserChitchatCodeLevel5
		//	default:
		//		extTimes = const_level.UserChitchatCodeLevel0
		//	}
		//}
		//nextLvl.FullChitchatCodeTimes += int32(extTimes)
		curSignTimes := ss.UserSignUpItem.GetSignTimes()
		if curSignTimes > nextLvl.FullSignTimes {
			curSignTimes = nextLvl.FullSignTimes
		}

		ChitchatCodeTimes := ss.UserSignUpItem.GetChitchatCodeTimes()
		if ChitchatCodeTimes > nextLvl.FullChitchatCodeTimes {
			ChitchatCodeTimes = nextLvl.FullChitchatCodeTimes
		}

		resp.NextLevelCard = &pbuserapi.LevelCard{
			NextUlevel:            nextLvl.Level,
			NextLevelTitle:        nextLvl.Title,
			SignTimes:             curSignTimes,
			FullSignTimes:         nextLvl.FullSignTimes,
			ChitchatCodeTimes:     ChitchatCodeTimes,
			FullChitchatCodeTimes: nextLvl.FullChitchatCodeTimes,
			LevDesc:               nextLvl.LevelUpDesc,
			RealNameAuth:          proto.Int32(const_level.RealNameAuthClose),
			SheNiuAuth:            proto.Int32(const_level.SheNiuAuthClose),
			NextLevelDesc:         nextLvl.LevelUpDescArr,
		}
		// 兜底，万一改配置，导致full比较小，cur比较大。

	}
	return resp
}

func (p *UserLevelMng) getUserLevSession(ctx context.Context, userId int64) (*LevelSession, error) {
	// 获取userExt
	userExt, err := p.DataCache.GetImpl().UserInfoExtMgModel.GetAndCreate(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user extinfo failed,err=%v", err.Error())
		return nil, err
	}
	curLevel := userExt.GetUlevel()

	// 获取当前的 签到量和激活码数量
	lvlUpItem, err := p.DataCache.GetImpl().UserLevelUpRecordDbModel.GetItemById(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user levelupRecord failed,err=%v", err.Error())
		return nil, err
	}
	penalties := userExt.GetPenalties()                                    // 获取当前违规次数。
	DailySigned := p.DataCache.GetImpl().GetUserDailySignFlag(ctx, userId) //今日是否签到
	ss := &LevelSession{
		UserId:         userId,
		CurLevel:       curLevel,
		UserExt:        userExt,
		UserSignUpItem: lvlUpItem,
		WeiGuiTimes:    penalties,
		DailySigned:    DailySigned,
	}
	return ss, nil
}

func (p *UserLevelMng) getUserId(ctx context.Context, header *pbapi.HttpHeaderInfo) (int64, error) {
	if header.Debuguserid != 0 { // TODO 调测
		logger.Infof(ctx, "get by debuguserid!!!!!")
		return header.Debuguserid, nil
	}
	return p.DataCache.GetUserIdByToken(ctx, header.Token)
}
