package shumei

import (
	"context"
)

// 接口地址
const (
	feedBackTextUrl  = "https://api-web.fengkongcloud.com/api/feedback/text/add"
	feedBackImageUrl = "https://api-web.fengkongcloud.com/api/feedback/image/add"
)

// 风险类型
const (
	RiskType0   = "白名单"
	RiskType110 = "暴恐"
	RiskType100 = "涉政"
	RiskType250 = "娇喘"
	RiskType300 = "广告"
	RiskType200 = "色情"
	RiskType210 = "辱骂"
	RiskType400 = "灌水"
	RiskType520 = "未成年人"
	RiskType600 = "违禁"
)

type FeedbackReq struct {
	RequestId    string `json:"requestId"`           //必填 文本回调请求唯一标识，与数美服务返回结果中的requestId对应
	FeedbackType string `json:"type"`                //必填 纠错类型 必传参数 error：误杀 miss：漏杀
	RiskType     int    `json:"riskType,omitempty"`  //可选 内容风险类型 （误杀：不传默认按 “正常” 处理｜漏杀：不传默认按 “黑名单” 处理，部分服务无 “黑名单” 的按 “自定义）
	Timestamp    int64  `json:"timestamp,omitempty"` //可选 默认可以纠错2天内数据，如果需要纠错时间大于2天，必须传该参数
	Account      string `json:"account,omitempty"`   //可选 调用接口的账号
	AppId        string `json:"appId,omitempty"`     //可选 针对指定应用纠错，最多3个
	Channel      string `json:"channel,omitempty"`   //可选 针对指定渠道纠错，最多3个
}

type FeedbackResp struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

// 纠错文本
func (s *ShuMei) FeedbackText(ctx context.Context, req *FeedbackReq) (*FeedbackResp, error) {
	_, err := s.post(ctx, feedBackTextUrl, req)
	if err != nil {
		return nil, err
	}

	return &FeedbackResp{}, nil
}

// 纠错图片
func (s *ShuMei) FeedbackImage(ctx context.Context, req *FeedbackReq) (*FeedbackResp, error) {
	_, err := s.post(ctx, feedBackImageUrl, req)
	if err != nil {
		return nil, err
	}

	return &FeedbackResp{}, nil
}
