package user

import (
	"content_svr/db/redisdb/model/internal"
)

type userPersonalPoliceInfo struct {
	internal.RdsInfo
}
