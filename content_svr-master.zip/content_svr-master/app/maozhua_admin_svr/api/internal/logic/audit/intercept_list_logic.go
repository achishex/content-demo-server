package audit

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mongodb/model"
	"content_svr/pub/utils"
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type InterceptListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewInterceptListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *InterceptListLogic {
	return &InterceptListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *InterceptListLogic) InterceptList(req *types.InterceptListReq) (resp *types.InterceptListResp, err error) {
	filter, opts := req.ParseMongo()
	items, err := l.svcCtx.WriteDB.SecretAudit.FindAll(l.ctx, filter, opts)
	if err != nil {
		return nil, err
	}

	var count int64
	count, err = l.svcCtx.WriteDB.SecretAudit.Count(l.ctx, filter)
	if err != nil {
		return nil, err
	}

	type result struct {
		model.SecretAudit
		WorkStatus *int32 `json:"work_status,omitempty"`
	}

	audits := make([]result, 0)
	for _, audit := range items {
		audit.ImgUrl = utils.FixImageUrl(l.svcCtx.Config.ImageHost, audit.ImgUrl)
		//audits = append(audits, audit)

		var status *int32
		if audit.WorkId > 0 {
			pbw, err := l.svcCtx.WriteDB.PersonalBottleWorks.FindByWorkId(l.ctx, audit.WorkId)
			if err != nil {
				l.Error("cannot find workId: ", audit.WorkId)
				return nil, xerr.WorkInfoNoFound
			}
			status = &pbw.Status
		}

		audits = append(audits, result{
			SecretAudit: audit,
			WorkStatus:  status,
		})

	}

	resp = &types.InterceptListResp{}
	resp.Total = count
	resp.List = audits
	//
	//result = make([]model.SecretAudit, 0)
	//result = append(result, model.SecretAudit{})
	//resp.List = result

	return
}
