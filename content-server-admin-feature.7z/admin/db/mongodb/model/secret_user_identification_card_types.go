package model

const collectionNameSecretUserIdentificationCard = "secretUserIdentificationCard"

type SecretUserIdentificationCard struct {
	ID int64 `bson:"_id,omitempty" json:"id,omitempty"`

	UserId   int64  `json:"user_id,omitempty" bson:"user_id,omitempty"`
	CardId   string `json:"card_id,omitempty" bson:"card_id,omitempty"`
	CardName string `json:"card_name,omitempty" bson:"card_name,omitempty"`
	Status   int32  `json:"status,omitempty" bson:"status,omitempty"`

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` //创建时间
	UpdateTime int64 `json:"update_time,omitempty" bson:"update_time,omitempty"` //更新时间
}
