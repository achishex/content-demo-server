package mz_setting

import (
	"content_svr/setting"
	"context"
	"github.com/jinzhu/copier"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type MzSettingAddLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewMzSettingAddLogic(ctx context.Context, svcCtx *svc.ServiceContext) *MzSettingAddLogic {
	return &MzSettingAddLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *MzSettingAddLogic) MzSettingAdd(req *types.MzSettingAddReq) (resp *types.MzSettingAddResp, err error) {
	record := setting.MaozhuaSettingRecord{}
	if err := copier.Copy(&record, req); err != nil {
		return nil, err
	}

	switch req.Value.(type) {
	case float64:
		record.Value = int64(record.Value.(float64))
		record.DefaultValue = int64(record.DefaultValue.(float64))
	}

	if err := l.svcCtx.Maozhua.UpdateRecord(l.ctx, &record); err != nil {
		return nil, err
	}

	return
}
