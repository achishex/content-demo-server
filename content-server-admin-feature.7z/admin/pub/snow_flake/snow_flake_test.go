package snow_flake

import "testing"

func TestGetSnowflakeID(t *testing.T) {
	InitMachineID()
	t.Log(GetSnowflakeID())
	t.Log(GetSnowflakeID())
}
