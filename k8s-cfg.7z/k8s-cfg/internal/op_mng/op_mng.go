package op_mng

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbadmin"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbdb"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"math/rand"
	"time"
)

func (p *OpMng) LoginIn(ctx context.Context, req *pbadmin.OpLoginInReq) (*pbadmin.OpLoginInResp, error) {
	item, err := p.DataCache.GetImpl().OperatorModel.GetByEmail(ctx, req.GetEmail())
	if err != nil {
		return nil, errorcode.INTERNAL_ERROR
	}
	if item == nil {
		return nil, errorcode.GenBusiErr(errorcode.INTERNAL_ERROR, "用户不存在")
	}
	if item.GetPwd() != req.GetPwd() {
		return nil, errorcode.GenBusiErr(errorcode.INTERNAL_ERROR, "账号密码错误")
	}

	src := fmt.Sprintf("%v_%v", time.Now().UnixNano(), rand.Int())
	token := utils.MD5(src)

	rdsKey := fmt.Sprintf(cache_const.AdminTokenRcache.KeyFmt, token)
	expire := cache_const.AdminTokenRcache.Expire
	p.DataCache.GetImpl().RedisCli.Set(ctx, rdsKey, req.GetEmail(), time.Duration(expire)*time.Second)
	return &pbadmin.OpLoginInResp{Token: token}, nil
}

func (p *OpMng) OpInfo(ctx context.Context) (*pbadmin.OpInfo, error) {
	opEmail := middleware.GetOpEmail(ctx)
	opitem, err := p.DataCache.GetImpl().OperatorModel.GetByEmail(ctx, opEmail)
	if err != nil {
		logger.Error(ctx, "opInfo get user failed", err)
		return nil, err
	}

	return &pbadmin.OpInfo{
		OperatorId: opitem.GetOpId(),
		Email:      opitem.GetEmail(),
		OpType:     opitem.GetOpType(),
		Name:       opitem.GetName(),
		Phone:      opitem.GetPhone(),
		Status:     opitem.GetStatus(),
	}, nil
}

func (p *OpMng) OpInfoUpdate(ctx context.Context, req *pbadmin.OpInfoUpdateReq) error {
	opEmail := middleware.GetOpEmail(ctx)
	opitem, err := p.DataCache.GetImpl().OperatorModel.GetByEmail(ctx, opEmail)
	if err != nil {
		logger.Error(ctx, "opInfo get user failed", err)
		return err
	}
	if opitem.GetPwd() != req.GetOriginalPwd() {
		logger.Error(ctx, "original pwd err", err)
		return err
	}
	opitem.Pwd = &req.Pwd
	_, err = p.DataCache.GetImpl().OperatorModel.UpdateItem(ctx, opitem)
	if err != nil {
		logger.Error(ctx, "update Operator failed", err)
		return err
	}
	return nil
}

func (p *OpMng) OpList(ctx context.Context, req *pbadmin.OpInfoListReq) (*pbadmin.OpInfoListResp, error) {
	if req.GetSize() <= 0 {
		req.Size = proto.Int32(10)
	}

	// TOTAL
	total, err := p.DataCache.GetImpl().OperatorModel.CountItemsByCondition(ctx, nil)
	if err != nil {
		logger.Errorf(ctx, "OpList.CountItemsByCondition query failed, err=%v", err.Error())
		return nil, err
	}

	// items
	items, err := p.DataCache.GetImpl().OperatorModel.ListItemsByCondition(ctx, nil, req.GetPage(), req.GetSize())
	if err != nil {
		logger.Errorf(ctx, "OpList.ListItemsByCondition query failed, err=%v", err.Error())
		return nil, err
	}
	opInfos := p.transToItem(items)

	return &pbadmin.OpInfoListResp{
		OpInfoList: opInfos,
		Total:      total,
	}, nil
}

func (p *OpMng) transToItem(items []*pbdb.OperatorTabDbModel) []*pbadmin.OpInfo {
	resp := make([]*pbadmin.OpInfo, 0)
	for _, item := range items {
		one := &pbadmin.OpInfo{
			OperatorId: item.GetOpId(),
			Email:      item.GetEmail(),
			OpType:     item.GetOpType(),
			Name:       item.GetName(),
			Phone:      item.GetPhone(),
			Status:     1,
		}
		resp = append(resp, one)
	}
	return resp
}

func (p *OpMng) OpAdd(ctx context.Context, req *pbadmin.OpAddReq) error {
	opEmail := middleware.GetOpEmail(ctx)
	opitem, err := p.DataCache.GetImpl().OperatorModel.GetByEmail(ctx, opEmail)
	if err != nil {
		logger.Error(ctx, "opInfo get user failed", err)
		return err
	}
	//用户状态
	if opitem.GetStatus() == int32(pbconst.BaseTabStatus_invalid) {
		return errorcode.USER_ENABLED_ERROR
	}
	// 用户权限检查
	if opitem.GetOpType() == 0 { // 0-普通， 1-管理员
		return errorcode.INSUFFICIENT_PERMISSION
	}

	newItem := &pbdb.OperatorTabDbModel{
		Email:  req.Email,
		Pwd:    req.Pwd,
		Name:   req.Name,
		Phone:  req.Phone,
		OpType: req.OpType,
		Status: proto.Int32(1),
	}
	_, err = p.DataCache.GetImpl().OperatorModel.CreateItem(ctx, newItem)
	if err != nil {
		return err
	}
	return nil
}
