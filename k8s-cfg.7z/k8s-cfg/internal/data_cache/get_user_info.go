package data_cache

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	"github.com/gogo/protobuf/proto"
	"time"
)

// private SimpleUserInfoResponse getUser(Long userId) {

// 内存级缓存.
type UserInfoLocal struct {
	UserInfoDbModel *pbapi.UserinfoDbModel
	IsPolice        bool  //是否为护卫队。done 只从redis读取 读取 userPolice redis而来。 public boolean checkPolice(Long userId) {
	ShowConvoy      bool  // LCACHE+MGDB_PersonalPoliceInfo
	MemberType      int32 // 会员类型 done	(0非会员 1-svip 2赠送会员 3-普通会员)	只从redis读。	 public int getMemberType(Long userId) {
	//OpenUserDbModel              *pbapi.OpenUserDbModel
	UserPermission               int32 // getUserPermission(Long userId) {	// DONE 只从redis取。
	UserCircleWorksSwitchDbModel *pbapi.UserCircleWorksSwitchDbModel
	//Coordinate                   *pbapi.Coordinate                 // 只从redis取。 soul_soup:secret:coordinate:
	PsecretUserExtInfo        *pbapi.SecretUserExtInfoMgDbModel // 可能为空. 只从mg DB取。 done
	IsInBlackHouse            bool                              // 只取用 redis
	PersonalPoliceInfoMgModel *pbapi.PersonalPoliceInfoMgDbModel
	UserMedals                []*pbapi.SecretMedalInfoResponse
	EnableComment             int32 //0:disable, 1: enable
}

func (p *DataCacheMng) GetUserBasicInfo(ctx context.Context, userId int64, bSkipCache bool) (*pbapi.UserinfoDbModel, error) {
	item := p.getUserInfoModelLD(ctx, userId, bSkipCache)
	if item == nil {
		logger.Error(ctx, fmt.Sprintf("getUserInfoModelLD ret nil. userid=%v", userId), nil)
		return nil, nil
	}
	return item, nil
}
func (p *DataCacheMng) DeleteUserInfoFromCache(ctx context.Context, userIds []int64) error {
	for _, userId := range userIds {
		p.deleteUserInfoModelLocalCache(ctx, userId)
		//p.DeleteUserMemberType(ctx, userId)
		//add others...
	}
	return nil
}

// bSkipCache 默认false，不跳过，需要使用cache.
func (p *DataCacheMng) GetUserInfoLocal(ctx context.Context, header *pbapi.HttpHeaderInfo,
	userId int64, bSkipCache bool) (*UserInfoLocal, error) {
	resp := &UserInfoLocal{}
	item := p.getUserInfoModelLD(ctx, userId, bSkipCache)
	if item == nil {
		logger.Error(ctx, fmt.Sprintf("getUserInfoModelLD ret nil. userid=%v", userId), nil)
		return nil, nil
	}

	// 获取用户的最新定位数据
	coor := p.GetUserCoordinateV2(ctx, userId, nil)
	if len(coor.GetProvince()) > 0 || len(coor.GetCity()) > 0 {
		item.Province = proto.String(coor.GetProvince())
		item.City = proto.String(coor.GetCity())
		//logger.Infof(ctx, "get_userinfo_location,user %v, %v, %v", userId, item.GetProvince(), item.GetCity())
	}

	resp.UserInfoDbModel = item                                                                      // lcache +db
	resp.IsPolice = p.GetUserPoliceRedis(ctx, userId)                                                //只走redis了
	resp.MemberType = p.GetUserMemberType(ctx, userId)                                               //只走redis
	resp.UserPermission = p.GetUserPermission(ctx, userId)                                           //只走了redis
	resp.PsecretUserExtInfo = p.GetUserExtInfoMgDBLd(ctx, userId, bSkipCache)                        // lcache+mgDb
	resp.UserCircleWorksSwitchDbModel = p.GetUserCircleWorksSwitchDbModelLd(ctx, userId, bSkipCache) //local +db
	resp.IsInBlackHouse = p.GetUserInBlackFlag(ctx, userId)                                          // 只走了redis
	resp.PersonalPoliceInfoMgModel = p.GetUserPoliceInfoMgDBLd(ctx, userId, bSkipCache)              //lcache+mgDb
	resp.UserMedals = p.GetUserMedalInfoMgDBLd(ctx, userId, bSkipCache)                              //lcache+mgDb

	resp.ShowConvoy = p.getShowConvoy(resp.PersonalPoliceInfoMgModel)
	return resp, nil
}

func (p *DataCacheMng) getShowConvoy(policeInfo *pbapi.PersonalPoliceInfoMgDbModel) bool {
	var showConvoy bool

	if policeInfo == nil {
		return showConvoy
	}

	showConvoy = policeInfo.ShowConvoy

	return showConvoy
}

var localCacheKeyFmtUserinfoDbModel = "UserinfoDbModel:%v" // user_id
func (p *DataCacheMng) setUserInfoModelLocalCache(ctx context.Context, uInfoDbModel *pbapi.UserinfoDbModel) {
	if uInfoDbModel == nil || uInfoDbModel.GetUserId() == 0 {
		return
	}
	lKey := fmt.Sprintf(localCacheKeyFmtUserinfoDbModel, uInfoDbModel.GetUserId())
	bret := p.LocalCache.Set(lKey, uInfoDbModel, go_cache.WithEx(time.Duration(5*60)*time.Second))
	if !bret {
		logger.Error(ctx, fmt.Sprintf("setUserInfoModelLocalCache failed, user_id=%v", uInfoDbModel.GetUserId()), nil)
	}
	return
}
func (p *DataCacheMng) deleteUserInfoModelLocalCache(ctx context.Context, userId int64) {
	lKey := fmt.Sprintf(localCacheKeyFmtUserinfoDbModel, userId)
	bret := p.LocalCache.Del(lKey)
	logger.Infof(ctx, "delete userInfo from cache, ret: %v, user: %v", bret, userId)
}

func (p *DataCacheMng) getUserInfoModelLocalCache(userId int64) *pbapi.UserinfoDbModel {
	if userId == 0 {
		return nil
	}
	lKey := fmt.Sprintf(localCacheKeyFmtUserinfoDbModel, userId)
	cResp, exist := p.LocalCache.Get(lKey)
	if exist && cResp != nil {
		lResp, ok := cResp.(*pbapi.UserinfoDbModel)
		if ok && lResp != nil {
			return lResp
		}
	}
	return nil
}

func (p *DataCacheMng) getUserInfoModelLD(ctx context.Context, userId int64, bSkipCache bool) *pbapi.UserinfoDbModel {
	var err error
	// 从内存取
	if bSkipCache == false {
		item := p.getUserInfoModelLocalCache(userId)
		if item != nil {
			return item
		}
	}

	// 从db取
	item, err := p.UserInfoModel.GetByUserId(ctx, userId)
	if err != nil {
		return nil
	}
	if item == nil {
		return nil
	}
	if item.GetNickName() == "" {
		item.NickName = proto.String(item.GetOpenNickName())
	}
	if item.GetPhoto() == "" {
		item.Photo = proto.String(item.GetOpenPhoto())
	}
	// 返回非空，则设置到内存缓存
	if bSkipCache == false {
		p.setUserInfoModelLocalCache(ctx, item)
	}
	return item
}
