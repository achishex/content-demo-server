package job

import (
	"bytes"
	"content_svr/config"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"
)

type Message struct {
	MsgType string `json:"msg_type"`
	Content struct {
		Post struct {
			ZhCn struct {
				Title   string    `json:"title"`
				Content [][]plain `json:"content"`
			} `json:"zh_cn"`
		} `json:"post"`
	} `json:"content"`
}

type plain struct {
	Tag    string `json:"tag,omitempty"`
	Text   string `json:"text,omitempty"`
	Href   string `json:"href,omitempty"`
	UserId string `json:"user_id,omitempty"`
}

// 飞书群里的机器人
type robotControl struct {
	webUrl  string       // 发送地址
	msgChan chan Message // 需要发送的消息
}

func (r *robotControl) monitor() {
	for {
		select {
		case msg := <-r.msgChan:
			if err := r.notifyRobot(msg); err != nil {
				logger.Error(context.Background(), "robot send message error:", err)
				return
			}
		}
	}
}

func (r *robotControl) notifyRobot(msg Message) error {
	if config.ServerConfig.Env == "test" {
		// 测试环境不发机器人通知
		logger.Infof(context.Background(), "robot message: %v", msg)
		return nil
	}
	// json
	contentType := "application/json"
	// data
	sendData, _ := json.Marshal(msg)
	// request
	result, err := http.Post(r.webUrl, contentType, bytes.NewReader(sendData))
	if err != nil {
		return err
	}
	defer result.Body.Close()
	return nil
}

func (r *robotControl) SendMessage(msg Message) {
	r.msgChan <- msg
}

func (r *robotControl) SendMessageNotify(err any) {
	errMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("【info】%v", err),
	}
	items := []plain{errMessage}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = "代码提醒通知"
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	r.msgChan <- m
}

func (r *robotControl) SendMessageError(err any) {
	errMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("【error】%v", err),
	}
	items := []plain{errMessage}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = "代码错误"
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	r.msgChan <- m
}

func (r *robotControl) SendMessageAfterTime(msg Message, duration time.Duration) {
	go func() {
		timer := time.NewTimer(duration)
		<-timer.C
		timer.Stop()
		r.msgChan <- msg
	}()
}
