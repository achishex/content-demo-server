package cache_const

import (
	"content_svr/config"
	"strings"
)

type cacheDef struct {
	KeyFmt string //key
	Expire int64  //本地重新读取的过期时间。单位秒
	//RedisExpire int64  // redis超时时间, 单位秒
}

func getRdsEnvPrefix() string {
	//logger.Infof(context.Background(), "quding_env: %v ", config.ServerConfig.Env)

	if strings.ToLower(config.ServerConfig.Env) == "prod" {
		return "prod"
	} else {
		return "test"
	}
}

var WorkExpandInfoLcache = cacheDef{
	KeyFmt: "WorkExpandInfoLcache:%v", // work_id
	Expire: 5 * 60,                    //5分钟
}

var MedalInfoLcache = cacheDef{
	KeyFmt: "MedalInfoLcache:%v", // userid
	Expire: 5 * 60,
}

var UserBlackListLcache = cacheDef{
	KeyFmt: "UserBlackListLcache:%v_%v", // userid+targetid
	Expire: 60,                          // 60s
}

var SecretFollowLcache = cacheDef{
	KeyFmt: "SecretFollowLcache:%v_%v", // userid+targetid
	Expire: 60,                         // 60s
}

var PersonTalkMsgTotalLcache = cacheDef{
	KeyFmt: "PersonTalkMsgTotalLcache:%v_%v", // uniqueId+targetid
	Expire: 5 * 60,                           // 60s
}

var PersonTalkMsgTotalWithIdsLcache = cacheDef{
	KeyFmt: "PersonTalkMsgTotalWithIdsLcache:%v_%v_%v", // from_userId+to_userId+workid
	Expire: 5 * 60,                                     // 60s
}

// 次数配置，本地缓存
var TimeConfigLcache = cacheDef{
	KeyFmt: "TimesConfig:%v", // times_replay_limit_female
	Expire: 1 * 60,           // 60s
}

// secret:singleTalkUsers:20230426:421102198901053251
// UserCurReplyList. 用户今日回复了多少用户。用户列表。 sets
var UserCurReplyListRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":secret:singleTalkUsers:%v:%v", //
	Expire: 24 * 60 * 60,
}

// 请求内部服务鉴权
var InnerHttpRedisSign = &cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":app_comm:insideSign:%v", //userId
	Expire: 2,                                                           // 2s
}

var SecretMemeLcache = cacheDef{
	KeyFmt: "SecretMemeLcache:%v", // id
	Expire: 5 * 60,                //5分钟
}

var CoordinateByIpRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":secret:CoordinateByIp:%v", // ip
	Expire: 6 * 60 * 60,                                                   //6h
}

// TODO
var UserModuleBlockRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:%v:%v:%v", // 2, 1, userId
	Expire: 1 * 60,
}

var PushChitchatTimesRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:chitchatTimes:%v:%v", // date, userid
	Expire: 1 * 86400,
}

var BaiDuImgCensorAccessTokenRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":baidu:imgCensorAccessToken", // date, userid
	//Expire: 1 * 86400,		长期有效
}

// 只记录100以内
var UserReadWorkDayCountRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:userReadedCount:%v:%v", // date, userid
	Expire: 1 * 86400,
}

// 系统作品是否已分发。
var SystemWorkReadFlagRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:systemWorkReadFlag:%v:%v:%v", // date, userid, workId
	Expire: 1 * 86400,
}

// 系统作品今天是否已发布。
var SystemWorkPublishFlagRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:systemWorkPublishFlag:%v:%v:%v", // date, userid, workId
	Expire: 1 * 86400,
}

// 星座详情数据。
var XingZuoDailyDetailRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:xingZuoDailyDetail:%v:%v", // signId, date  1,20210405
	Expire: 1 * 86400,
}

// 官方号发帖记录缓存。
var OfficialWorkLcache = cacheDef{
	KeyFmt: "OfficialWorkLcache:%v", // user_id 129533901081600
	Expire: 5 * 60,
}

// 用户签到记录。
var UserDailySignRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:userDailySign:%v:%v", // userId, date  4111376406916096,20210405
	Expire: 1 * 86400,
}

// 用户签到记录。v2
var UserDailySignV2Rcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:userDailySignV2:%v:%v", // userId, date  4111376406916096,20210405
	Expire: 1 * 86400,
}

// 官方作品是否已分发。
var WorkReadTsRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:WorkReadTsRcache:%v:%v", // userid, workId
	Expire: 3 * 3600,
}

// 用户token。
var UserTokenRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:login_token:%v", //
	Expire: 1 * 86400,
}

// 新管理平台登录态。
var AdminTokenRcache = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:AdminToken:%v", // token ~ op.email
	Expire: 7 * 86400,                                                    // 管理后台，7天过期后重新登录
}

// 动态评论人数
var WorkPeopleCommentCount = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:new_work_people_count:%v",
	Expire: 24 * 3 * 3600,
}

// 动态评论数大于N且此人数大于N
var WorkPeopleCommentCountGtN = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:new_work_people_count_gt_n:%v",
	Expire: 24 * 3 * 3600,
}

var ValidWorkCommentPersonCount = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:valid_work_comment_person_count:%v",
	Expire: 24 * 3 * 3600,
}

var SuperiorContentQueueConf = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:superior_content_queue:%v",
	Expire: 0,
}
var SuperiorContentQueueNotifyChName = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:delay_queue_ch:%v",
	Expire: 0,
}

var SuperiorContentWorkOnUserConf = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:superior_content_work_on_user:%v",
	Expire: 0,
}

var SuperiorContentAwardOnWorkConf = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:superior_content_award:%v", // workID
	Expire: 3 * 24 * 3600,
}

var WithdrawPayDetailQueueConf = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:withdraw_wx:all_pay_id", // all
	Expire: 0,
}

var SuperiorContentDistributeLockKey = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:superior_content_lock:%v", // user_id
	Expire: 10,                                                                      // 10 second
}

var KoLaHallOfFameKey = cacheDef{
	KeyFmt: "platform:" + getRdsEnvPrefix() + ":soul_soup:kola_hall_of_fame:%v", //  year_month_day
	Expire: 3 * 24 * 3600,
}
