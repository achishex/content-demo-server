package data_cache

import (
	"content_svr/protobuf/pbapi"
	"context"
	"encoding/json"
	"fmt"
	"github.com/go-redis/redis/v8"
)

func (p *DataCacheMng) GetUserIdByToken(ctx context.Context, token string) (int64, error) {
	redisKey := getUserTokenKey(token)
	ret, err := p.RedisCli.Get(ctx, redisKey).Result() //返回在range的idx位置
	if err != nil && err != redis.Nil {
		return 0, err
	}
	if len(ret) == 0 {
		return 0, fmt.Errorf("user login token not find")
	}
	resp := &pbapi.LoginTokenRedis{}
	err = json.Unmarshal([]byte(ret), resp)
	if err != nil {
		return 0, fmt.Errorf("user login token Unmarshal failed")
	}
	return resp.GetUserId(), nil
}
