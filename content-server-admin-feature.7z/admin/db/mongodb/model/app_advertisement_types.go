package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

const collectionNameAppAdvertisement = "appAdvertisement"

type AppAdvertisement struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	Name      string `json:"name" bson:"name"`             //名称
	Type      string `json:"type" bson:"type"`             // 格式gif
	Weight    int    `json:"weight" bson:"weight"`         // 权重， 1优先级最高
	Cover     string `json:"cover" bson:"cover"`           //封面图（可选）
	Content   string `json:"content" bson:"content"`       //广告内容
	Dur       int    `json:"dur" bson:"dur"`               // 广告时长（秒）
	RewardDur int    `json:"reward_dur" bson:"reward_dur"` //奖励时长
	JumpURL   string `json:"jump_url" bson:"jump_url"`     //跳转链接
	Enable    bool   `json:"enable" bson:"enable"`         //是否上架
	Creator   string `json:"creator" bson:"creator"`       //创建人
	Editor    string `json:"editor" bson:"editor"`         //修改人
	StartTime int64  `json:"start_time" bson:"start_time"` //开启时间
	EndTime   int64  `json:"end_time" bson:"end_time"`     //结束时间
	//LaunchStatus uint   `json:"launch_status" bson:"launch_status"` // 投放状态

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` //创建时间
	UpdateTime int64 `json:"update_time,omitempty" bson:"update_time,omitempty"` //更新时间
}
