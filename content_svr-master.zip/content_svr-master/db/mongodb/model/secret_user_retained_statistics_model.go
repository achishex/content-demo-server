package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var _ SecretUserRetainedStatisticsModel = (*customSecretUserRetainedStatisticsModel)(nil)

type (
	// SecretUserRetainedStatisticsModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretUserRetainedStatisticsModel.
	SecretUserRetainedStatisticsModel interface {
		secretUserRetainedStatisticsModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretUserRetainedStatistics, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretUserRetainedStatistics, error)
		InsertMany(ctx context.Context, data []any, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error)
	}

	customSecretUserRetainedStatisticsModel struct {
		*defaultSecretUserRetainedStatisticsModel
	}
)

// NewSecretUserRetainedStatisticsModel returns a model for the mongo.
func NewSecretUserRetainedStatisticsModel(cfg MonConfig) SecretUserRetainedStatisticsModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SecretUserRetainedStatisticsCollectionName)
	return &customSecretUserRetainedStatisticsModel{
		defaultSecretUserRetainedStatisticsModel: newDefaultSecretUserRetainedStatisticsModel(conn),
	}
}

func (m *customSecretUserRetainedStatisticsModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	} else {
		flagType = "default"
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customSecretUserRetainedStatisticsModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretUserRetainedStatisticsModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretUserRetainedStatistics, error) {
	result := make([]SecretUserRetainedStatistics, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretUserRetainedStatisticsModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretUserRetainedStatistics, error) {
	var data SecretUserRetainedStatistics
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretUserRetainedStatisticsModel) InsertMany(ctx context.Context, data []any, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error) {
	insert, err := m.conn.InsertMany(ctx, data, opts...)
	return insert, err
}
