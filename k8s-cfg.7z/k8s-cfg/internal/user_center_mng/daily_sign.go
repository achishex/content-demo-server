package user_center_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/snow_flake"
	"content_svr/setting"
	"context"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	rdsV8 "github.com/go-redis/redis/v8"
	"github.com/golang/protobuf/proto"
	"github.com/jinzhu/copier"
	"github.com/kevwan/mapreduce/v2"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"sort"
	"time"
)

func (u *UserCenterMng) ResetPenalties(ctx context.Context) {
	userId := middleware.GetUserID(ctx.(*gin.Context))
	if userId > 0 {
		if err := u.DataCache.GetImpl().UserInfoExtMgModel.UpdateDictById(ctx, userId, map[string]any{"penalties": 0}, nil); err != nil {
			logger.Errorf(ctx, "ResetPenalties error : %v ", err)
		}
	}
}

func (u *UserCenterMng) DailySign(ctx context.Context, req *pbuserapi.DailySignReq) (*pbuserapi.LevelUpResp, error) {
	var (
		userId = middleware.GetUserID(ctx.(*gin.Context))
	)

	//签到状态
	signed := u.DataCache.GetImpl().GetUserDailySign(ctx, userId)
	if signed {
		return nil, errorcode.DailySignInAgain
	}

	//设置签到
	if err := u.DataCache.GetImpl().SetUserDailySign(ctx, userId); err != nil {
		return nil, errorcode.DailySignInError
	}

	//更新签到/升级
	resp, err := u.checkLevUpAndUpdate(ctx, userId, 1)
	if err != nil {
		return nil, errorcode.DailySignInError
	}

	return resp, nil
}

func (u *UserCenterMng) LevelInfo(ctx context.Context, req *pbuserapi.LevelCardReq) (*pbuserapi.CurrentLevelInfo, error) {
	userId := middleware.GetUserID(ctx.(*gin.Context))

	userExt, err := u.DataCache.GetImpl().UserInfoExtMgModel.GetAndCreate(ctx, userId)
	if err != nil || userExt == nil {
		logger.Errorf(ctx, "get user ext info failed,err=%v", err.Error())
		return nil, errorcode.DailySignInError
	}

	resp, err := u.checkLevUpAndUpdate(ctx, userId, 0)
	if err != nil {
		return nil, errorcode.DailySignInError
	}

	return resp.LevelInfo, nil
}

func (u *UserCenterMng) GetSpeedCode(ctx context.Context, req *pbuserapi.GetSpeedCodeReq) (*pbuserapi.GetSpeedCodeResp, error) {
	var (
		userId = middleware.GetUserID(ctx.(*gin.Context))

		resp          = &pbuserapi.GetSpeedCodeResp{}
		dailySignColl = u.DataCache.GetImpl().SecretDailySignInMgModel
		speedCodeColl = u.DataCache.GetImpl().SecretSpeedCodeMgModel
	)

	blackHouseOutTime, err := u.DataCache.GetImpl().GetUserBlackHouseOutTime(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "user in black house,err=%v", err.Error())
		return nil, errorcode.SpeedCodeGetErrorCauseBlackHouse
	}
	if time.Now().UnixNano()/1e6 < blackHouseOutTime {
		return nil, err
	}

	sign, err := dailySignColl.FindOne(ctx, bson.M{"user_id": userId})
	if err != nil {
		logger.Errorf(ctx, "get user daily sign failed,err=%v", err.Error())
		return nil, err
	}

	if sign.SpeedCode != "" {
		resp.SpeedCode = sign.SpeedCode
		return resp, nil
	}

	if sign.SpeedCodeStatus == const_busi.SpeedCodeStatusNo {
		return nil, errorcode.SpeedCodeGetErrorCauseNo
	}

	if sign.SpeedCodeStatus == const_busi.SpeedCodeStatusYes && sign.SpeedCode == "" {
		//生成
		resp.SpeedCode, err = speedCodeColl.Create(ctx, userId)
		if err != nil {
			return resp, nil
		}

		updates := map[string]any{
			"speed_code_status": const_busi.SpeedCodeStatusDraw,
			"speed_code":        resp.SpeedCode,
			"update_time":       time.Now().UnixMilli(),
		}
		if err := dailySignColl.UpdateOne(ctx, bson.M{"user_id": userId}, updates); err != nil {
			return nil, err
		}
	}

	return resp, nil
}

func (u *UserCenterMng) UsageSpeedCode(ctx context.Context, req *pbuserapi.UsageSpeedCodeReq) (*pbuserapi.LevelUpResp, error) {
	var (
		userId        = middleware.GetUserID(ctx.(*gin.Context))
		userExtColl   = u.DataCache.GetImpl().UserInfoExtMgModel
		dailySignColl = u.DataCache.GetImpl().SecretDailySignInMgModel
		speedCodeColl = u.DataCache.GetImpl().SecretSpeedCodeMgModel
		resp          = &pbuserapi.LevelUpResp{}
	)

	userExt, err := userExtColl.GetAndCreate(ctx, userId)
	if err != nil || userExt == nil {
		logger.Errorf(ctx, "get user ext info failed,err=%v", err.Error())
		return nil, errorcode.SpeedCodeUsageError
	}

	if userExt.GetUlevel() == const_busi.UserLevel5 {
		return nil, errorcode.SpeedCodeUsageError
	}

	speedCode, err := speedCodeColl.FindOne(ctx, bson.M{"_id": req.SpeedCode, "status": 0})
	if err != nil || speedCode == nil {
		return nil, errorcode.SpeedCodeInvalid
	}
	if speedCode.FromUserId == userId {
		return nil, errorcode.SpeedCodeUsageError
	}

	signTimes := setting.Maozhua.SpeedCodeExchangeSignTimesForNormal.Get()
	if userExt.GetNewPenalties() > 0 {
		signTimes = setting.Maozhua.SpeedCodeExchangeSignTimesForPenalties.Get()
	}

	if resp, err = u.checkLevUpAndUpdate(ctx, userId, signTimes); err != nil {
		logger.Errorf(ctx, "checkLevUpAndUpdate err : %v", err)
		return nil, err
	}

	updates := map[string]any{
		"sign_in_times":     0,
		"speed_code_status": const_busi.SpeedCodeStatusNo,
		"speed_code":        "",
		"update_time":       time.Now().UnixMilli(),
	}
	if err := dailySignColl.UpdateOne(ctx, bson.M{"user_id": speedCode.FromUserId}, updates); err != nil {
		return nil, err
	}

	if config.ServerConfig.Env == "test" && speedCode.SpeedCode == "MAOZUA" {
		return resp, nil
	}

	if err := speedCodeColl.UpdateOne(ctx,
		bson.M{"_id": speedCode.SpeedCode},
		map[string]any{
			"status":    1,
			"toUserId":  userId,
			"usageTime": time.Now().UnixMilli(),
		}); err != nil {
		return nil, err
	}

	//点亮新芽勋章
	expire := time.Now().Add(time.Hour * 24 * 10).UnixMilli()
	_ = u.MediaAdd(ctx, speedCode.FromUserId, const_busi.MedalIdXinYa, expire)

	return resp, nil
}

func (u *UserCenterMng) LevelRights(ctx context.Context) (*pbuserapi.LevelAllInfoResp, error) {
	var (
		userId = middleware.GetUserID(ctx.(*gin.Context))
		resp   = &pbuserapi.LevelAllInfoResp{
			LevelCards: make([]*pbuserapi.LevelBaseCard, 0),
		}
	)

	userExt, err := u.DataCache.GetImpl().UserInfoExtMgModel.GetAndCreate(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user ext info failed,err=%v", err.Error())
		return resp, nil
	}

	uis := const_busi.GetUserLevelUp(ctx, userExt.GetNewPenalties() > 0)
	keys := make([]int32, 0)
	for i := range uis {
		keys = append(keys, i)
	}

	sort.Slice(keys, func(i, j int) bool {
		return keys[i] < keys[j]
	})

	for _, key := range keys {
		item := pbuserapi.LevelBaseCard{}
		err := copier.Copy(&item, uis[key])
		if err != nil {
			continue
		}
		if key > 5 {
			break
		}
		resp.LevelCards = append(resp.LevelCards, &item)
	}

	return resp, nil
}

func (u *UserCenterMng) checkLevUpAndUpdate(ctx context.Context, userId int64, signTimes int32) (*pbuserapi.LevelUpResp, error) {
	var (
		userExtColl   = u.DataCache.GetImpl().UserInfoExtMgModel
		dailySignColl = u.DataCache.GetImpl().SecretDailySignInMgModel
		resp          = &pbuserapi.LevelUpResp{}
	)

	userExt, err := userExtColl.GetAndCreate(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user ext info failed,err=%v", err.Error())
		return nil, err
	}

	sign, err := dailySignColl.FindOne(ctx, bson.M{"user_id": userId})
	if err != nil {
		logger.Errorf(ctx, "get user daily sign failed,err=%v", err.Error())
		return nil, err
	}

	var (
		currLevel   = userExt.GetUlevel()
		isPenalties = userExt.GetNewPenalties() > 0
	)

	if sign == nil {
		currLevelInfo := u.getLevelInfo(ctx, userId, currLevel, 0, isPenalties)

		v := 0
		if signTimes > 1 {
			v = 1
		}
		if err := dailySignColl.Create(ctx, &pbmgdb.SecretDailySignInMgDbModel{
			Id:                 snow_flake.GetSnowflakeID(),
			UserId:             userId,
			SignInTimes:        int32(v),
			CreateTime:         time.Now().UnixMilli(),
			FlagResetPenalties: true,
		}); err != nil {
			return nil, err
		}

		if signTimes-1 > 0 {
			//第一次直接使用加速码
			return u.checkLevUpAndUpdate(ctx, userId, signTimes-1)
		}

		resp.LevelInfo = currLevelInfo
		return resp, nil
	} else {
		currLevelInfo := u.getLevelInfo(ctx, userId, currLevel, sign.SignInTimes, isPenalties)
		currLevelInfo.SpeedCode = sign.SpeedCode
		currLevelInfo.DrawSpeedCodeStatus = sign.SpeedCodeStatus

		currLevelInfo = u.checkLevelUp(ctx, userId, isPenalties, signTimes, currLevelInfo)
		resp.BLevelUp = currLevelInfo.BLevelUp
		resp.LevelInfo = currLevelInfo

		if resp.BLevelUp == true {
			currLevel = currLevelInfo.Ulevel
			nextLevCfg := const_busi.GetLevelCfg(ctx, currLevel)

			// 升级后下一个等级的信息
			nextLevelInfo := u.getLevelInfo(ctx, userId, currLevel, currLevelInfo.NextLevelCard.SignTimes, isPenalties) // 获取下一个等级的信息
			nextLevelInfo.SpeedCode = currLevelInfo.SpeedCode
			nextLevelInfo.DrawSpeedCodeStatus = currLevelInfo.DrawSpeedCodeStatus
			nextLevelInfo.BLevelUp = currLevelInfo.BLevelUp

			resp.LevelInfo = nextLevelInfo
			resp.NextLevelDesc = nextLevCfg.LevelUpDescArr
			// 更新等级到userExt表
			update := map[string]interface{}{"ulevel": currLevel}
			if err := userExtColl.UpdateDictById(ctx, userId, update, nil); err != nil {
				logger.Error(ctx, "UpdateDictById info failed", err)
				return nil, err
			}

			//红包奖励+推送
			if err := u.LevelUpRedPacketAward(ctx, userId, isPenalties, nextLevelInfo.GetRedPacketAmount()); err != nil {
				logger.Errorf(ctx, "level up send rewards error : %v", err)
				return nil, err
			}
		}

		changes := map[string]interface{}{
			"sign_in_times":     currLevelInfo.NextLevelCard.SignTimes,
			"update_time":       time.Now().UnixMilli(),
			"speed_code_status": currLevelInfo.DrawSpeedCodeStatus,
			"speed_code":        currLevelInfo.SpeedCode,
		}
		cond := map[string]interface{}{"user_id": userId}
		if err := dailySignColl.UpdateOne(ctx, cond, changes); err != nil {
			logger.Error(ctx, "update level info failed", err)
			return resp, err
		}

		return resp, nil
	}
}

func (u *UserCenterMng) getLevelInfo(ctx context.Context, userId int64, currLevel, curSignTimes int32, penalties bool) *pbuserapi.CurrentLevelInfo {
	levelCfg := const_busi.GetLevelCfg(ctx, currLevel)

	levelInfo := &pbuserapi.CurrentLevelInfo{
		Ulevel:              currLevel,
		LevelTitle:          levelCfg.Title,
		NextLevelCard:       nil,
		BDailySigned:        u.DataCache.GetImpl().GetUserDailySign(ctx, userId),
		HasPunishedHistory:  penalties,
		BLevelUp:            false,
		NextLevelDesc:       levelCfg.LevelUpDescArr,
		LevelUpPopUp:        levelCfg.GetLevelUpPopUpArr(),
		DrawSpeedCodeStatus: 0,
		SpeedCode:           "",
		AdSwitchSign:        setting.Maozhua.AdSwitchSign.Get(),
		AdSwitchSpeedCode:   setting.Maozhua.AdSwitchSpeedCode.Get(),
		RedPacketAmount:     levelCfg.GetRedPacketAmount(penalties),
		SpeedCodeLimitDesc: fmt.Sprintf("1枚加速码可兑换%d天签到哦，可找其他猫友赠送～\n*如有违规记录，则1枚加速码仅可兑换%d天签到哦",
			setting.Maozhua.SpeedCodeExchangeSignTimesForNormal.Get(), setting.Maozhua.SpeedCodeExchangeSignTimesForPenalties.Get()),
	}

	// 下一级卡片信息
	if currLevel < const_busi.UserMaxLevel && currLevel >= const_busi.UserLevel0 {
		nextLvl := const_busi.GetLevelCfg(ctx, currLevel+1)
		nextLvl.BuildTaskMessage(ctx, penalties)

		if curSignTimes > nextLvl.FullSignTimes {
			curSignTimes = nextLvl.FullSignTimes
		}

		levelInfo.NextLevelCard = &pbuserapi.NextLevelCard{
			NextUlevel:      nextLvl.Level,
			NextLevelTitle:  nextLvl.Title,
			SignTimes:       curSignTimes,
			FullSignTimes:   nextLvl.FullSignTimes,
			LevDesc:         nextLvl.LevelUpDesc,
			RealNameAuth:    proto.Int32(const_level.RealNameAuthClose),
			SheNiuAuth:      proto.Int32(const_level.SheNiuAuthClose),
			NextLevelDesc:   nextLvl.LevelUpDescArr,
			RedPacketAmount: nextLvl.GetRedPacketAmount(penalties),
			CurrentMutual:   proto.Int32(int32(u.DataCache.GetImpl().SecretUserFollowMgModel.GetMutualCnt(ctx, bson.D{{"userId", userId}, {"mutual", 1}}))),
			NeedMutual:      proto.Int32(setting.Maozhua.MedalPermanentNeedMutualCnt.Get()),
		}

		//获取身份证/社牛认证情况
		u.getExtCheckInfo(ctx, userId, levelInfo)
	}
	return levelInfo
}

// 升级
func (u *UserCenterMng) checkLevelUp(ctx context.Context, userId int64, isPenalties bool, addSignTimes int32, levelInfo *pbuserapi.CurrentLevelInfo) *pbuserapi.CurrentLevelInfo {
	var (
		finalSignTimes    = levelInfo.NextLevelCard.SignTimes + addSignTimes
		currFullSignTimes = levelInfo.NextLevelCard.FullSignTimes
	)

	//满足签到次数
	if finalSignTimes >= currFullSignTimes {
		//额外条件
		switch levelInfo.Ulevel {
		case const_busi.UserLevel5:
			if levelInfo.SpeedCode == "" {
				levelInfo.DrawSpeedCodeStatus = const_busi.SpeedCodeStatusDraw
				levelInfo.SpeedCode = u.drawSpeedCode(ctx, userId)
			}
			levelInfo.NextLevelCard.SignTimes = currFullSignTimes
			return levelInfo
		case const_busi.UserLevel4:
			if const_busi.IsAdSignVer(ctx) {
				if levelInfo.NextLevelCard.GetSheNiuAuth() != const_level.SheNiuAuthPass {
					levelInfo.NextLevelCard.SignTimes = currFullSignTimes
					return levelInfo
				}
			} else {
				if levelInfo.NextLevelCard.GetRealNameAuth() != const_level.RealNameAuthPass || levelInfo.NextLevelCard.GetSheNiuAuth() != const_level.SheNiuAuthPass {
					levelInfo.NextLevelCard.SignTimes = currFullSignTimes
					return levelInfo
				}
			}
		case const_busi.UserLevel3:
			if const_busi.IsAdSignVer(ctx) {
				if levelInfo.NextLevelCard.GetRealNameAuth() != const_level.RealNameAuthPass {
					levelInfo.NextLevelCard.SignTimes = currFullSignTimes
					return levelInfo
				}
			} else {
				logger.Infof(ctx, "old")
			}
		}

		//升级
		levelInfo.Ulevel += 1
		levelInfo = u.getLevelInfo(ctx, userId, levelInfo.Ulevel, levelInfo.NextLevelCard.SignTimes, isPenalties)
		levelInfo.BLevelUp = true
		levelInfo.NextLevelCard.SignTimes = 0

		//多余的签到次数，递归执行（使用加速码时）
		overflowTimes := finalSignTimes - currFullSignTimes
		if overflowTimes > 0 {
			return u.checkLevelUp(ctx, userId, isPenalties, overflowTimes, levelInfo)
		}

		return levelInfo
	} else {
		levelInfo.NextLevelCard.SignTimes = finalSignTimes
		return levelInfo
	}
}

// 领取加速码
func (u *UserCenterMng) drawSpeedCode(ctx context.Context, userId int64) string {
	//生成
	speedCode, err := u.DataCache.GetImpl().SecretSpeedCodeMgModel.Create(ctx, userId)
	if err != nil {
		return ""
	}

	updates := map[string]any{
		"speed_code":  speedCode,
		"update_time": time.Now().UnixMilli(),
	}
	if err := u.DataCache.GetImpl().SecretDailySignInMgModel.UpdateOne(ctx, bson.M{"user_id": userId}, updates); err != nil {
		return ""
	}
	return speedCode
}

func (u *UserCenterMng) getExtCheckInfo(ctx context.Context, userId int64, levelInfo *pbuserapi.CurrentLevelInfo) {
	// 身份证
	filter := bson.D{
		{"user_id", userId},
		{"status", const_busi.UserCardStatus},
	}
	_, err := u.DataCache.GetImpl().SecretUserIdentificationCardMgModel.FindOne(ctx, filter)
	switch {
	case errors.Is(err, mongo.ErrNoDocuments):
		levelInfo.NextLevelCard.RealNameAuth = proto.Int32(const_level.RealNameAuthNoPass)
	case err == nil:
		levelInfo.NextLevelCard.RealNameAuth = proto.Int32(const_level.RealNameAuthPass)
	default:
		levelInfo.NextLevelCard.RealNameAuth = proto.Int32(const_level.RealNameAuthNoPass)
	}

	// 5 社牛勋章
	medal, err := u.DataCache.GetImpl().UserMedalMgModel.GetOneByMediaAndUserId(ctx, userId, const_busi.MedalIdSocialButterfly)
	if err != nil {
		if err != rdsV8.Nil {
			logger.Error(ctx, "checkLevelUp.GetOneByMediaAndUserId", err)
		}
		levelInfo.NextLevelCard.SheNiuAuth = proto.Int32(const_level.SheNiuAuthNoPass)
	}
	if medal == nil {
		levelInfo.NextLevelCard.SheNiuAuth = proto.Int32(const_level.SheNiuAuthNoPass)
	} else if medal.GetExpire() > time.Now().UnixMilli() {
		levelInfo.NextLevelCard.SheNiuAuth = proto.Int32(const_level.SheNiuAuthPass)
	}
}

func (u *UserCenterMng) CheckSpeedCode(ctx context.Context, req *pbuserapi.CheckSpeedCodeReq) (*pbuserapi.CheckSpeedCodeResp, error) {
	var (
		userId        = middleware.GetUserID(ctx.(*gin.Context))
		speedCodeColl = u.DataCache.GetImpl().SecretSpeedCodeMgModel
	)

	speedCode, err := speedCodeColl.FindOne(ctx, bson.M{"_id": req.SpeedCode, "status": 0})
	if err != nil || speedCode == nil {
		return nil, errorcode.SpeedCodeInvalid
	}
	if speedCode.FromUserId == userId {
		return nil, errorcode.SpeedCodeInvalid
	}
	return &pbuserapi.CheckSpeedCodeResp{}, nil
}

func (u *UserCenterMng) UsedListSpeedCode(ctx context.Context, req *pbuserapi.SpeedCodeUsedListReq) (*pbuserapi.SpeedCodeUsedListResp, error) {
	var (
		resp          = &pbuserapi.SpeedCodeUsedListResp{List: make([]*pbuserapi.FollowItem, 0)}
		userId        = middleware.GetUserID(ctx.(*gin.Context))
		speedCodeColl = u.DataCache.GetImpl().SecretSpeedCodeMgModel
		skip          = (req.Page - 1) * req.Size
	)

	usedList, err := speedCodeColl.Find(ctx, bson.M{"fromUserId": userId, "status": 1}, &options.FindOptions{
		Limit: &req.Size,
		Skip:  &skip,
		Sort:  bson.D{{"createTime", -1}},
	})
	if err != nil || len(usedList) == 0 {
		return &pbuserapi.SpeedCodeUsedListResp{}, nil
	}

	uniqUser := make(map[int64]*pbmgdb.SecretSpeedCodeMgDbModel, len(usedList))
	for _, v := range usedList {
		if _, ok := uniqUser[v.ToUserId]; ok {
			continue
		}
		uniqUser[v.ToUserId] = v
	}

	for _, user := range uniqUser {
		var (
			userInfo    *data_cache.UserInfoLocal
			stat        *pbuserapi.FollowStatusResp
			talkMode    int32
			continueErr = errors.New("continue")
		)

		if err := mapreduce.Finish(func() error {
			userInfo, err = u.DataCache.GetUserInfoLocal(ctx, nil, user.ToUserId, true)
			if userInfo == nil || *userInfo.UserInfoDbModel.Status == 0 || err != nil {
				return continueErr
			}
			return nil
		}, func() error {
			talkMode = u.DataCache.GetUserInfoTalkMode(ctx, user.ToUserId)
			return nil
		}, func() error {
			if u.DataCache.CheckUserBlackListMgDBLD(ctx, userId, user.ToUserId) {
				return continueErr
			}
			return nil
		}, func() error {
			//在对方的拉黑名单中
			if u.DataCache.CheckUserBlackListMgDBLD(ctx, user.ToUserId, userId) {
				return continueErr
			}
			return nil
		}, func() error {
			//关注状态
			stat, _ = u.getFollowStat(ctx, userId, user.ToUserId)
			return nil
		}); errors.Is(err, continueErr) {
			continue
		}

		fi := &pbuserapi.FollowItem{
			Timestamp: user.CreateTime,
			UserId:    userInfo.UserInfoDbModel.GetUserId(),
			User: &pbuserapi.FollowUser{
				UserId:     userInfo.UserInfoDbModel.GetUserId(),
				NickName:   userInfo.UserInfoDbModel.GetNickName(),
				Photo:      userInfo.UserInfoDbModel.GetPhoto(),
				Gender:     userInfo.UserInfoDbModel.GetGender(),
				MemberType: userInfo.MemberType,
				UserType:   userInfo.UserInfoDbModel.GetUserType(),
				Ulevel:     userInfo.PsecretUserExtInfo.GetUlevel(),
				TalkMode:   talkMode,
			},
			Stat: &pbuserapi.FollowStat{
				FollowMe: stat.FollowMe,
				MeFollow: stat.MeFollow,
			},
			WorkId: u.getLastWorkByCache(ctx, user.ToUserId),
			Badge:  false,
		}

		//勋章
		if len(userInfo.UserMedals) > 0 {
			for _, item := range userInfo.UserMedals {
				fi.User.Medals = append(fi.User.Medals, &pbuserapi.FollowMedals{
					Expire:    item.Expire,
					Icon:      item.Icon,
					MedalId:   item.MedalId,
					MedalName: item.MedalName,
					SmallIcon: item.SmallIcon,
					Timestamp: item.Timestamp,
				})
			}
		}

		resp.List = append(resp.List, fi)
	}

	return resp, nil
}

func (u *UserCenterMng) LevelUpRedPacketAward(ctx context.Context, userId int64, isPenalties bool, award float64) error {
	if award <= 0 || isPenalties {
		return nil
	}

	if err := content_mng.
		NewSuperiorContentInstance(&content_mng.ContentMng{DataCache: u.DataCache}, nil, 0).
		WriteNewItem(ctx, 0, userId, "", award, const_busi.SignLevelUpAward); err != nil {
		logger.Errorf(ctx, "write sign level up on award fail,err: %v", err)
		return err
	}

	if err := u.ContentMng.SendRedPacketMsg(
		ctx,
		userId,
		int32(pbconst.MessageTypeEnum_msg_type_txt),
		"您有一笔奖励金入账，快去看看吧！",
		setting.Maozhua.ReadPacket.Title.Get(),
		setting.Maozhua.ReadPacket.IconUrl.Get(),
		setting.Maozhua.ReadPacket.BackgroundUrl.Get(),
	); err != nil {
		return err
	}

	return nil
}
