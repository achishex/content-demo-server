package job

import (
	"content_svr/pub/logger"
	"context"
	"fmt"
	"strconv"
	"time"
)

type TickerExecute struct {
	year, month, day     int // 增减日期
	hour, minter, second int // 修改时分秒的时间点

	today bool

	ticker *time.Ticker
}

func (t *TickerExecute) calcIntervalTime() time.Duration {
	if t.today {
		t.year = 0
		t.month = 0
		t.day = 0
	} else {
		if t.year == 0 && t.month == 0 && t.day == 0 {
			t.day = 1
		}
	}
	now := time.Now()
	nextDay := now.AddDate(t.year, t.month, t.day)
	nextExecuteTime := time.Date(
		nextDay.Year(),
		nextDay.Month(),
		nextDay.Day(),
		t.hour,
		t.minter,
		t.second,
		0,
		nextDay.Location(),
	)

	var interval time.Duration
	if nextExecuteTime.Before(now) {
		// nextExecuteTime < now
		message := fmt.Sprintf(
			"当前设置执行时间为过去的时间: \n start -> %v\n end  -> %v\n修改为明天的同一时间执行\n %v",
			now, nextExecuteTime, nextExecuteTime.AddDate(0, 0, 1),
		)
		logger.Errorf(context.Background(), message)
		//RobotServerControl.SendMessageNotify(message)
		nextExecuteTime = nextExecuteTime.AddDate(0, 0, 1)
		t.today = false
	}
	interval = nextExecuteTime.Sub(now)
	if interval < 0 {
		logger.Errorf(context.Background(), "interval time error: %v\n", interval)
		RobotServerControl.SendMessageError(fmt.Sprintf("定时器时间设置出错了: \n start -> %v\n end  -> %v\n", now, nextExecuteTime))
		return time.Hour * 24
	}
	return interval
}

func (t *TickerExecute) Do(f func()) {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(context.Background(), "recover: %v\n", err)
		}
	}()
	interval := t.calcIntervalTime()
	t.ticker = time.NewTicker(interval)
	for {
		select {
		case <-t.ticker.C:
			f()
		}
	}
}

func (t *TickerExecute) baseTimeByDay(baseTime time.Time) int {
	dateStr := fmt.Sprintf("%04d%02d%02d", baseTime.Year(), baseTime.Month(), baseTime.Day())
	day, err := strconv.Atoi(dateStr)
	if err != nil {
		panic(err)
	}
	return day
}

func (t *TickerExecute) lastTimeByDay(baseTime time.Time, calcDay int) int {
	if calcDay < 0 {
		panic("time error")
	}
	return t.calcTimeByDay(baseTime, -calcDay)
}

func (t *TickerExecute) calcTimeByDay(baseTime time.Time, calcDay int) int {
	startTime := baseTime.AddDate(0, 0, calcDay)
	dateStr := fmt.Sprintf("%04d%02d%02d", startTime.Year(), startTime.Month(), startTime.Day())
	day, err := strconv.Atoi(dateStr)
	if err != nil {
		panic(err)
	}
	return day
}

func (t *TickerExecute) subTimeByDay(left, right int) int {
	leftTime, err := time.Parse("20060102", strconv.Itoa(left))
	if err != nil {
		panic(err)
	}
	rightTime, err := time.Parse("20060102", strconv.Itoa(right))
	if err != nil {
		panic(err)
	}
	result := leftTime.Sub(rightTime)
	day := result / (time.Hour * 24)
	return int(day.Nanoseconds())
}

func (t *TickerExecute) baseZeroTime(baseTime time.Time) time.Time {
	return time.Date(baseTime.Year(), baseTime.Month(), baseTime.Day(), 0, 0, 0, 0, baseTime.Location())
}

func (t *TickerExecute) calcZeroTimeByDay(baseTime time.Time, day int) time.Time {
	target := baseTime.AddDate(0, 0, day)
	return time.Date(target.Year(), target.Month(), target.Day(), 0, 0, 0, 0, target.Location())
}
