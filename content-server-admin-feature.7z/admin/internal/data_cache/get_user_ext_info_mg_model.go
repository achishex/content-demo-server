package data_cache

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	go_cache "github.com/fanjindong/go-cache"
	"time"
)

func (p *DataCacheMng) GetUserExtInfoMgDBLd(ctx context.Context, userId int64, bSkipCache bool) *pbapi.SecretUserExtInfoMgDbModel {
	//从内存取
	cacheKey := getLocalCacheKeyUserInfoExtMgModelKey(userId)
	if bSkipCache == false {
		cResp, exist := p.LocalCache.Get(cacheKey)
		if exist {
			resp, ok := cResp.(*pbapi.SecretUserExtInfoMgDbModel)
			if ok && resp != nil {
				// 从redis取用户最新信息
				//talkMode := p.GetUserInfoTalkMode(ctx, userId)
				//resp.TalkMode = &talkMode
				return resp
			}
		}
	}

	//从mg db取
	mgModelUserExt, err := p.UserInfoExtMgModel.GetByUserId(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get UserInfoExtMgModel failed. userId=%v, err=%v", userId, err.Error())
		return nil
	}

	// save 到localcache
	if bSkipCache == false {
		bSuc := p.LocalCache.Set(cacheKey, mgModelUserExt, go_cache.WithEx(5*60*time.Second))
		logger.Infof(ctx, "save UserInfoExtMgModel to local cache. userId=%v,value=%v,s bSuc=%v",
			userId, mgModelUserExt, bSuc)
	}
	return mgModelUserExt
}

func (p *DataCacheMng) DelUserExtInfoMgDBLd(ctx context.Context, userIds []int64) {
	for _, uid := range userIds {
		cacheKey := getLocalCacheKeyUserInfoExtMgModelKey(uid)
		p.LocalCache.Del(cacheKey)
	}
}
