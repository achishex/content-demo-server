package main

import (
	"content_svr/app/log_collector/domain"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"github.com/a3d21/bind_etcd_cfg"
	"github.com/robfig/cron/v3"
	"github.com/segmentio/kafka-go"
	clientv3 "go.etcd.io/etcd/client/v3"
	"golang.org/x/time/rate"
	"strconv"
	"time"
)

const (
	TOPIC   = "secret_access_log"
	GroupID = "logCollector"
)

var (
	EtcdEndpoints  = "10.0.0.18:2379"
	EtcdUserName   = "root"
	EtcdUserPasswd = "DrUuBmv9Jrk9w9ah"
	EtchConfKey    = "nf/prod/log-collector"
)

func main() {
	ctx := context.Background()

	v3cli, err := clientv3.New(clientv3.Config{
		Endpoints:   []string{EtcdEndpoints},
		Username:    EtcdUserName,
		Password:    EtcdUserPasswd,
		DialTimeout: 5 * time.Second,
	})
	if err != nil {
		logger.Errorf(ctx, "New etcdclient fail, err: %v", err)
		panic(err)
	}

	// 绑定配置
	lim := rate.NewLimiter(1, 3)
	c, err := bind_etcd_cfg.Bind(v3cli, EtchConfKey, &domain.Conf{}, func(c *domain.Conf) {
		logger.Infof(ctx, "refresh lim %v %v", c.RateLimit, c.RateLimitN)
		if c.RateLimit > 0 {
			lim.SetLimit(rate.Limit(c.RateLimit))
		}
		if c.RateLimitN > 0 {
			lim.SetBurst(c.RateLimitN)
		}
	})
	if err != nil {
		logger.Errorf(ctx, "Bind fail, err: %v", err)
		panic(err)
	}

	logger.Infof(ctx, "load conf: %+v", c.Get())

	repo, err := domain.NewLogRepo(c.Get())
	if err != nil {
		logger.Errorf(ctx, "NewLogRepo fail, err: %v", err)
		panic(err)
	}

	// 自动建索引
	{
		cc := cron.New(cron.WithSeconds())
		_, err := cc.AddFunc("0 0 6 21,22 * ?", func() {
			if err2 := repo.CreateColl(ctx, time.Now().AddDate(0, 1, 0)); err2 != nil {
				logger.Errorf(ctx, "CreateColl fail, err: %v", err)
			}
			if err2 := repo.CreateColl(ctx, time.Now().AddDate(0, 2, 0)); err2 != nil {
				logger.Errorf(ctx, "CreateColl fail, err: %v", err)
			}
			logger.Infof(ctx, "run CreateColl succ..")
		})
		if err != nil {
			logger.Errorf(ctx, "add cron fail, err: %v", err)
			panic(err)
		}

		logger.Infof(ctx, "run cron.")
		go cc.Run()
	}

	r := kafka.NewReader(kafka.ReaderConfig{
		Brokers:        c.Get().KafkaBrokers,
		Topic:          TOPIC,
		GroupID:        GroupID,
		MaxBytes:       10e6, // 10MB
		CommitInterval: time.Second,
	})
	defer r.Close()

	for {
		_ = lim.Wait(ctx)

		m, err2 := r.ReadMessage(ctx)
		if err2 != nil {
			logger.Errorf(ctx, "ReadMessage fail, err: %v", err)
			continue
		}

		klog := &domain.KafkaLog{}
		err2 = json.Unmarshal(m.Value, klog)
		if err2 != nil {
			logger.Errorf(ctx, "malformed msg %s, err: %v", m.Value, err)
			continue
		}
		userID, _ := strconv.ParseInt(klog.UserID, 10, 64)
		e := &domain.LogEntity{
			UserID:  userID,
			AppType: klog.AppType,
			Url:     klog.Url,
			Method:  klog.Method,
			Header:  klog.Header,
			Req:     klog.Req,
			Resp:    klog.Resp,
			Created: klog.Created,
			Dur:     klog.Dur,
		}
		repo.AsyncInsertLog(ctx, e)
	}

}
