package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/logx"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const MzRobotCollectionName = "mz_robot"

var _ MzRobotModel = (*customMzRobotModel)(nil)

type (
	// MzRobotModel is an interface to be customized, add more methods here,
	// and implement the added methods in customMzRobotModel.
	MzRobotModel interface {
		mzRobotModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]MzRobot, error)
		CheckArea(ctx context.Context, startTime, endTime int64, commentIndex int32) (int64, bool, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*MzRobot, error)
		UpdateMapMany(ctx context.Context, filter, data map[string]interface{}, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error)
	}

	customMzRobotModel struct {
		*defaultMzRobotModel
	}
)

// NewMzRobotModel returns a model for the mongo.
func NewMzRobotModel(cfg MonConfig) MzRobotModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), MzRobotCollectionName)
	return &customMzRobotModel{
		defaultMzRobotModel: newDefaultMzRobotModel(conn),
	}
}

func (m *customMzRobotModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	case "update":
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	default:
		for k, v := range filter {
			switch k {
			case "name":
				value, ok := v.(string)
				if !ok {
					logx.Info("robot name value error", v)
					continue
				}
				query = append(query, bson.E{Key: k, Value: "%" + value + "%"})
			case "status":
				query = append(query, bson.E{Key: k, Value: v})
			case "time_part_start":
				query = append(query, bson.E{Key: k, Value: bson.D{{"$gte", v}}})
			case "time_part_end":
				query = append(query, bson.E{Key: k, Value: bson.D{{"$lte", v}}})
			default:
				query = append(query, bson.E{Key: k, Value: v})
			}
		}
	}

	return query
}

func (m *customMzRobotModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]MzRobot, error) {
	result := make([]MzRobot, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customMzRobotModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customMzRobotModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*MzRobot, error) {
	var data MzRobot
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customMzRobotModel) UpdateMapMany(ctx context.Context, filter, data map[string]interface{}, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error) {
	query := m.parseFilter(filter, "update")
	update := bson.D{
		{Key: "$set", Value: data},
	}

	result, err := m.conn.UpdateMany(ctx, query, update)
	switch {
	case err == nil && result != nil && result.ModifiedCount == 0:
		return nil, ErrDoNothing
	case err == nil:
		return result, nil
	case err == mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customMzRobotModel) CheckArea(ctx context.Context, startTime, endTime int64, commentIndex int32) (int64, bool, error) {
	baseQuery := bson.D{
		{"comment_index", commentIndex},
	}

	return checkArea(ctx, m.conn, baseQuery, startTime, endTime)
}
