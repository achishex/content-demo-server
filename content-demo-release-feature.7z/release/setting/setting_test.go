package setting

import (
	"context"
	"encoding/json"
	"fmt"
	rdsV8 "github.com/go-redis/redis/v8"
	"testing"
	"time"
)

var rds *rdsV8.Client

func init() {
	fmt.Println("=====================> test")
	rds = rdsV8.NewClient(&rdsV8.Options{
		Addr:         "119.29.185.233:6379",
		Password:     "1qaz2wsx",
		DB:           0,
		ReadTimeout:  2 * time.Minute,
		WriteTimeout: 1 * time.Minute,
		PoolTimeout:  2 * time.Minute,
		IdleTimeout:  10 * time.Minute,
		PoolSize:     1000,
	})
}

func TestInitialize(t *testing.T) {
	if err := Initialize(rds, "test"); err != nil {
		t.Fatal(err)
	}
	t.Log(Maozhua)

	t.Log(Maozhua.LoadRedisData(context.Background()))

	fmt.Printf("\n\n\n\n============\n\n\n\n")

	t.Log(Maozhua)

	t.Log(Maozhua.Level1SingleCommentMax.Get())
}

func TestServiceConfig_GetAllSetting(t *testing.T) {
	ori := ServiceSetting{}
	ori.Level5CommentMax = fieldInt64{}
	ori.Level5CommentMax.Value = 2000
	ori.Level5CommentMax.Description = "5 level"
	ori.Level5CommentMax.DefaultValue = 2000
	m, err := ori.GetAllSetting()
	if err != nil {
		t.Fatal(err)
	}

	b, err := json.Marshal(m)
	if err != nil {
		t.Fatal(err)
	}
	str := string(b)
	t.Log(str)
}

func TestServiceSetting_LoadRedisData(t *testing.T) {
	ctx := context.Background()

	env := "test"
	ori := ServiceSetting{
		rds:    rds,
		rdsKey: fmt.Sprintf("platform:%s:maozhua:config", env),
		subKey: fmt.Sprintf("platform:%s:maozhua:config:notify", env),
	}
	if err := ori.LoadRedisData(ctx); err != nil {
		t.Fatal(err)
	}

	t.Log(ori)
}
