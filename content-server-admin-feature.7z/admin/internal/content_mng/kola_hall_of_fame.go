package content_mng

import (
	"content_svr/config"
	"content_svr/db/mongodb/model"
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/setting"
	"context"
	"fmt"
	rdsV8 "github.com/go-redis/redis/v8"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"math"
	"strconv"
	"sync"
	"time"
)

const (
	HALLOFFAMELISTLEN int64 = 20
)

type IKoLaHallOfFame interface {
	GetHallOfFameList(ctx context.Context) ([]*pbapi.UserItemOnHalfOfFame, error)
	AddItemToHallOfFame(ctx context.Context, userId int64, award float64) error
	ExpireHallOfFameSession(ctx context.Context) error
	PenalizeWorkAward(ctx context.Context, workId int64) error
	CheckSettlementIsReady(ctx context.Context, cfg *config.KoLaHallOfFameConfig) (int32, error)

	DoSettlementOnHallOfFame(ctx context.Context) error
}

func NewGetKoLaHallOfFameInstance(loginUser *data_cache.UserInfoLocal, mng *ContentMng) IKoLaHallOfFame {
	return &KoLaHallOfFame{
		selfUserInfo: loginUser,
		//
		Mng:         mng,
		limits:      int64(config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.Limits),
		redisClient: mng.DataCache.GetImpl().RedisCli,
		//
		addOpDone: false,
	}
}

func NewAddKoLaHallOfFameInstance(mng *ContentMng) IKoLaHallOfFame {
	return &KoLaHallOfFame{
		Mng:         mng,
		redisClient: mng.DataCache.GetImpl().RedisCli,
		addOpDone:   false,
	}
}
func NewAddKoLaHallOfFameOnce(rd *rdsV8.Client) IKoLaHallOfFame {
	return &KoLaHallOfFame{
		redisClient: rd,
		addOpDone:   false,
	}
}

var FormatHallOfFameListKey string = "%04d_%02d_%02d"

type KoLaHallOfFame struct {
	//get op
	selfUserInfo *data_cache.UserInfoLocal
	//
	Mng         *ContentMng
	redisClient *rdsV8.Client
	limits      int64
	// add op
	addOpDone bool
}

func CheckHallOfFameRankIsEnd() bool {

	defaultEndHourMinute := "23:30"

	if config.ServerConfig.WithdrawConfig != nil && len(config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.SettlementEndTime) > 0 {
		defaultEndHourMinute = config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.SettlementEndTime
	}

	cnfEndTime, err := time.Parse("15:04", defaultEndHourMinute)
	if err != nil {
		return false
	}

	nowTime := time.Now()
	if (cnfEndTime.Hour() > nowTime.Hour()) || (cnfEndTime.Hour() == nowTime.Hour() && cnfEndTime.Minute() > nowTime.Minute()) {
		return false
	}
	return true
}
func getListHallOfFameKey(ctx context.Context) string {
	var nowTime = time.Now()
	postKey := fmt.Sprintf(FormatHallOfFameListKey, nowTime.Year(), int(nowTime.Month()), nowTime.Day())
	ret := fmt.Sprintf(cache_const.KoLaHallOfFameKey.KeyFmt, postKey)
	logger.Infof(ctx, "kola hall of fame list key: %v", ret)
	return ret
}
func getAddHallOfFameKey(ctx context.Context) string {
	defaultEndHourMinute := "23:30"

	if config.ServerConfig.WithdrawConfig != nil && len(config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.SettlementEndTime) > 0 {
		defaultEndHourMinute = config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.SettlementEndTime
	}

	cfgEndTime, err := time.Parse("15:04", defaultEndHourMinute)
	if err != nil {
		logger.Errorf(ctx, "parse time: %v fail, err: %v", defaultEndHourMinute, err)
		return ""
	}
	logger.Infof(ctx, "parse time hour: %v, minute: %v", cfgEndTime.Hour(), cfgEndTime.Minute())

	var (
		postKey string = ""
		nowTime        = time.Now()
	)

	if (cfgEndTime.Hour() > nowTime.Hour()) || (cfgEndTime.Hour() == nowTime.Hour() && cfgEndTime.Minute() >= nowTime.Minute()) {
		postKey = fmt.Sprintf(FormatHallOfFameListKey, nowTime.Year(), int(nowTime.Month()), nowTime.Day())
	} else {
		nextDate := nowTime.AddDate(0, 0, 1)
		postKey = fmt.Sprintf(FormatHallOfFameListKey, nextDate.Year(), int(nextDate.Month()), nextDate.Day()) //年-月-日
	}

	ret := fmt.Sprintf(cache_const.KoLaHallOfFameKey.KeyFmt, postKey)
	logger.Infof(ctx, "kola hall of fame add key: %v", ret)
	return ret
}

// ret: award, create_time
// score 由：award + time("2100-01-01 00:00:00").MillUnix() - create_time,其中时间位于低位，保持 13 十进制位。
// 其中 time.("2100-01-01 00:00:00")对应毫秒时间戳是：
// 4102416000000
// 当前时间：
// 1672502400000
func (p *KoLaHallOfFame) ExpireHallOfFameSession(ctx context.Context) error {
	if p.addOpDone == false {
		return nil
	}

	err := p.redisClient.Expire(ctx, getAddHallOfFameKey(ctx), time.Duration(cache_const.KoLaHallOfFameKey.Expire)*time.Second).Err()
	return err
}

func GetMaxTime() *time.Time {
	maxTime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2100-01-01 00:00:00", time.Local)
	return &maxTime
}
func (p *KoLaHallOfFame) ParseAwardAndCreateTime(ctx context.Context, score float64) (float64, int64, error) {
	maxTimeMillUnix := GetMaxTime().UnixMilli()

	baseValue := math.Pow(10, 13)          // score 是 award *base + (4102416000000 - createTime)
	awardCents := int64(score / baseValue) //单位是分
	award := float64(awardCents) * 0.01    //转化成元

	relativeCreateTime := int64(score - float64(awardCents)*baseValue)
	createTime := maxTimeMillUnix - relativeCreateTime
	logger.Infof(ctx, "origin score: %v, parsed award: %v, parse creatTime: %v", score, award, createTime)
	return award, createTime, nil
}

func (p *KoLaHallOfFame) ComposeAwardAndCreateTime(ctx context.Context, award float64, createTime int64) (float64, error) {
	maxTimeMillUnix := GetMaxTime().UnixMilli()

	baseValue := math.Pow(10, 13) // score 是 award *base + (4102416000000 - createTime)

	awardCents := int64(award * 100) //转化为分
	relativeCreateTime := int64(maxTimeMillUnix - createTime)
	score := float64(awardCents)*baseValue + float64(relativeCreateTime)

	logger.Infof(ctx, "award: %v, create_time: %v compose score: %v", award, createTime, score)
	return score, nil

}
func (p *KoLaHallOfFame) getAwardOnHallOfFameByRank(ctx context.Context, index int32) float64 {
	return 1.00
}
func (p *KoLaHallOfFame) GetTopN(ctx context.Context) ([]*pbapi.UserItemOnHalfOfFame, error) {
	startTime := time.Now()
	defer func() {
		logger.Infof(ctx, "get top n, cost ms: %d", time.Now().Sub(startTime)/time.Millisecond)
	}()

	if p.redisClient == nil {
		logger.Errorf(ctx, "redis handle not init")
		return nil, nil
	}

	key := getListHallOfFameKey(ctx)
	if len(key) <= 0 {
		return nil, nil
	}

	if p.limits <= 0 {
		p.limits = HALLOFFAMELISTLEN
	}

	userLists, err := p.redisClient.ZRevRangeWithScores(ctx, key, 0, p.limits-1).Result()
	if err != nil {
		logger.Errorf(ctx, "get hall of fame list fail, err: %v, key: %v", err, key)
		return nil, err
	}
	var validUseList []*pbapi.UserItemOnHalfOfFame

	var (
		rank int32 = 0
		//initAward float64 = 0.0001
	)

	for k, _ := range userLists {
		userId, err := strconv.ParseInt(userLists[k].Member.(string), 10, 64)
		if err != nil {
			logger.Errorf(ctx, "parse user fail, origin: %v, err: %v", userLists[k].Member, err)
			return nil, err
		}

		totalAward, _, err := p.ParseAwardAndCreateTime(ctx, userLists[k].Score)
		if err != nil {
			logger.Errorf(ctx, "parse award and create_time from score on hall of fame fail, score: %v", userLists[k].Score)
			return nil, err
		}

		rank++

		//if totalAward != initAward {
		//	rank++
		//	initAward = totalAward
		//}

		validUseList = append(validUseList, &pbapi.UserItemOnHalfOfFame{
			UserInfo: &pbapi.UserInfoOnHallOfFame{
				UserId: userId,
			},

			Award:      p.getAwardOnHallOfFameByRank(ctx, int32(k)),
			TotalAward: TranFloatWith2Bit(totalAward),
			Rank:       rank,
		})
	}

	return validUseList, nil
}
func (p *KoLaHallOfFame) GetRelatedUsers(ctx context.Context) ([]*pbapi.SecretUserFollowMgDbModel, error) {
	startTime := time.Now()
	defer func() {
		logger.Infof(ctx, "GetRelatedUsers cost ms: %d", time.Now().Sub(startTime)/time.Millisecond)
	}()

	filter := bson.M{
		"$or": []interface{}{
			bson.M{"userId": p.selfUserInfo.UserInfoDbModel.GetUserId()},
			bson.M{"targetUserId": p.selfUserInfo.UserInfoDbModel.GetUserId()},
		},
	}

	relations, err := p.Mng.DataCache.GetImpl().SecretUserFollowMgModel.ListByCondition(ctx, filter, nil)
	if err != nil {
		logger.Errorf(ctx, "get relation for user: %v fail, err: %v", p.selfUserInfo.UserInfoDbModel.GetUserId(), err)
		return nil, err
	}
	return relations, nil

}
func (p *KoLaHallOfFame) IsOfficial(userId int64) bool {
	if userId == config.ServerConfig.CommentConfig.ReplyCommentOfficialAccount {
		return true
	}
	return false
}
func (p *KoLaHallOfFame) PackageHallOfFameItem(ctx context.Context, item *pbapi.UserItemOnHalfOfFame, relations []*pbapi.SecretUserFollowMgDbModel) error {
	startTime := time.Now()
	defer func() {
		logger.Infof(ctx, "PackageHallOfFameItem cost ms: %d", time.Now().Sub(startTime)/time.Millisecond)
	}()

	//p.Mng.DataCache.GetUserInfoLocal(ctx, nil, item.GetUserInfo().GetUserId(), false)
	//userInfo, err := p.Mng.GetUserInfo(ctx, item.GetUserInfo().GetUserId())
	getUserInfoCost := time.Now()
	userInfo, err := p.Mng.DataCache.GetUserInfoLocal(ctx, nil, item.GetUserInfo().GetUserId(), false)
	if err != nil {
		logger.Errorf(ctx, "get user info fail, err: %v, userId: %d", err, item.GetUserInfo().GetUserId())
		return err
	}
	logger.Infof(ctx, "get user info cost ms: %d", time.Now().Sub(getUserInfoCost)/time.Millisecond)

	if userInfo == nil {
		logger.Errorf(ctx, "get user info is nil, userId: %v", item.GetUserInfo().GetUserId())
		return errorcode.ACCOUNT_CLOSED
	}

	item.UserInfo.Gender = userInfo.UserInfoDbModel.GetGender()
	item.UserInfo.MemberType = userInfo.MemberType
	item.UserInfo.Photo = userInfo.UserInfoDbModel.GetPhoto()
	item.UserInfo.NickName = userInfo.UserInfoDbModel.GetNickName()
	item.UserInfo.TalkClose = p.Mng.GetUserInfoTalkMode(ctx, item.GetUserInfo().GetUserId())

	item.UserInfo.UserType = 1
	if p.IsOfficial(item.UserInfo.UserId) {
		item.UserInfo.UserType = 2 //

	} else if userInfo.UserInfoDbModel.GetUserType() != 1 {
		item.UserInfo.UserType = 2
	}

	item.Stat = &pbapi.StatHallOfFame{
		FollowedMe: false,
		MeFollowed: false,
	}

	for k, _ := range relations {
		if relations[k] == nil {
			continue
		}

		if relations[k].GetUserId() == p.selfUserInfo.UserInfoDbModel.GetUserId() && relations[k].GetTargetUserId() == item.GetUserInfo().GetUserId() {
			if relations[k].GetMutual() == 1 {
				item.Stat.FollowedMe = true
				item.Stat.MeFollowed = true
				break
			}
			//
			item.Stat.FollowedMe = false
			item.Stat.MeFollowed = true
			break
		}

		if relations[k].GetUserId() == item.GetUserInfo().GetUserId() && relations[k].GetTargetUserId() == p.selfUserInfo.UserInfoDbModel.GetUserId() {
			if relations[k].GetMutual() == 1 {
				item.Stat.FollowedMe = true
				item.Stat.MeFollowed = true
				break
			}

			item.Stat.FollowedMe = true
			item.Stat.MeFollowed = false
			break
		}
	}

	return nil
}
func (p *KoLaHallOfFame) PackageHallOfFameOnReadyRes(ctx context.Context, item *pbapi.UserItemOnHalfOfFame, relations []*pbapi.SecretUserFollowMgDbModel, taskGroups map[int32]*TaskGroup) error {
	startTime := time.Now()
	defer func() {
		logger.Infof(ctx, "PackageHallOfFameItem cost ms: %d", time.Now().Sub(startTime)/time.Millisecond)
	}()

	//p.Mng.DataCache.GetUserInfoLocal(ctx, nil, item.GetUserInfo().GetUserId(), false)
	//userInfo, err := p.Mng.GetUserInfo(ctx, item.GetUserInfo().GetUserId())
	//
	//getUserInfoCost := time.Now()
	//userInfo, err := p.Mng.DataCache.GetUserInfoLocal(ctx, nil, item.GetUserInfo().GetUserId(), false)
	//if err != nil {
	//	logger.Errorf(ctx, "get user info fail, err: %v, userId: %d", err, item.GetUserInfo().GetUserId())
	//	return err
	//}
	//logger.Infof(ctx, "get user info cost ms: %d", time.Now().Sub(getUserInfoCost)/time.Millisecond)

	//if userInfo == nil {
	//	logger.Errorf(ctx, "get user info is nil, userId: %v", item.GetUserInfo().GetUserId())
	//	return errorcode.ACCOUNT_CLOSED
	//}

	item.UserInfo.UserType = 1
	if p.IsOfficial(item.UserInfo.UserId) {
		item.UserInfo.UserType = 2 //
	}

	var task ITask
	if userInfoTaskGroup, ok := taskGroups[UserInfoType]; ok {
		task, ok = userInfoTaskGroup.tasks[item.GetUserInfo().GetUserId()]
		if !ok {
			logger.Errorf(ctx, "get user info is nil, userId: %v", item.GetUserInfo().GetUserId())
			return errorcode.ACCOUNT_CLOSED
		}

		switch task.(type) {
		case *TaskQueryUserInfo:
			userInfoTask := task.(*TaskQueryUserInfo)
			if userInfoTask == nil {
				logger.Errorf(ctx, "get user info is nil, userId: %v", item.GetUserInfo().GetUserId())
				return errorcode.ACCOUNT_CLOSED
			}

			if userInfoTask.err != nil {
				logger.Errorf(ctx, "get user info fail, err: %v", userInfoTask.err)
				return userInfoTask.err
			}

			//
			if userInfoTask.userInfo != nil {
				item.UserInfo.Gender = userInfoTask.userInfo.UserInfoDbModel.GetGender()
				item.UserInfo.MemberType = userInfoTask.userInfo.MemberType
				item.UserInfo.Photo = userInfoTask.userInfo.UserInfoDbModel.GetPhoto()
				item.UserInfo.NickName = userInfoTask.userInfo.UserInfoDbModel.GetNickName()
				if userInfoTask.userInfo.UserInfoDbModel.GetUserType() != 1 {
					item.UserInfo.UserType = 2
				}
			}
		}
	}

	if talkCloseTaskGroup, ok := taskGroups[TalkCloseType]; ok {
		if task, ok = talkCloseTaskGroup.tasks[item.GetUserInfo().GetUserId()]; ok {
			logger.Infof(ctx, "is talk close")
			switch task.(type) {
			case *TaskTalkClose:
				talkCloseTask := task.(*TaskTalkClose)
				if talkCloseTask != nil {
					item.UserInfo.TalkClose = talkCloseTask.talkClose
				}
			}
		}
	}

	item.Stat = &pbapi.StatHallOfFame{
		FollowedMe: false,
		MeFollowed: false,
	}

	for k, _ := range relations {
		if relations[k] == nil {
			continue
		}

		if relations[k].GetUserId() == p.selfUserInfo.UserInfoDbModel.GetUserId() && relations[k].GetTargetUserId() == item.GetUserInfo().GetUserId() {
			if relations[k].GetMutual() == 1 {
				item.Stat.FollowedMe = true
				item.Stat.MeFollowed = true
				break
			}
			//
			item.Stat.FollowedMe = false
			item.Stat.MeFollowed = true
			break
		}

		if relations[k].GetUserId() == item.GetUserInfo().GetUserId() && relations[k].GetTargetUserId() == p.selfUserInfo.UserInfoDbModel.GetUserId() {
			if relations[k].GetMutual() == 1 {
				item.Stat.FollowedMe = true
				item.Stat.MeFollowed = true
				break
			}

			item.Stat.FollowedMe = true
			item.Stat.MeFollowed = false
			break
		}
	}

	return nil
}

const (
	UserInfoType  int32 = 1
	TalkCloseType int32 = 2
)

func (p *KoLaHallOfFame) GetHallOfFameList(ctx context.Context) ([]*pbapi.UserItemOnHalfOfFame, error) {

	rankItems, err := p.GetTopN(ctx)

	if err != nil {
		return nil, err
	}
	if len(rankItems) <= 0 {
		logger.Infof(ctx, "not get hall of fame list user, is empty")
		return nil, nil
	}
	relations, err := p.GetRelatedUsers(ctx)
	if err != nil {
		logger.Errorf(ctx, "get relation fail, err: %v", err)
		return nil, nil
	}

	var userInfoTskGroup TaskGroup
	var talkCloseTskGroup TaskGroup
	var taskGroups map[int32]*TaskGroup = make(map[int32]*TaskGroup)

	for index, _ := range rankItems {
		if rankItems[index] == nil {
			continue
		}

		userInfoTskGroup.RegisterTask(rankItems[index].GetUserInfo().GetUserId(), NewTaskQueryUserInfo(index, rankItems[index].GetUserInfo().GetUserId(), p.Mng.DataCache))
		talkCloseTskGroup.RegisterTask(rankItems[index].GetUserInfo().GetUserId(), NewTaskTalkClose(index, rankItems[index].GetUserInfo().GetUserId(), p.Mng.DataCache))
	}
	//
	userInfoTskGroup.Start(ctx)
	talkCloseTskGroup.Start(ctx)
	//
	userInfoTskGroup.Wait()
	talkCloseTskGroup.Wait()
	//
	taskGroups[UserInfoType] = &userInfoTskGroup
	taskGroups[TalkCloseType] = &talkCloseTskGroup

	for k, _ := range rankItems {
		if rankItems[k] == nil {
			continue
		}

		if err := p.PackageHallOfFameOnReadyRes(ctx, rankItems[k], relations, taskGroups); err != nil {
			logger.Errorf(ctx, "package hall of fame item fail, userId: %v, err: %v", rankItems[k].GetUserInfo().GetUserId(), err)
			continue
		}

	}
	return rankItems, nil
}
func (p *KoLaHallOfFame) AddItemToRedisOnHallOfFame(ctx context.Context, score float64, member int64) error {
	key := getAddHallOfFameKey(ctx)
	scoreNew, _ := p.ComposeAwardAndCreateTime(ctx, score, time.Now().UnixMilli())

	if _, err := p.redisClient.ZAdd(ctx, key,
		&rdsV8.Z{
			Score:  scoreNew,
			Member: strconv.FormatInt(member, 10),
		}).Result(); err != nil {

		logger.Errorf(ctx, "add item to redis fail, err: %v, member: %v, score: %v", err, member, scoreNew)
		return err
	}
	return nil
}
func (p *KoLaHallOfFame) AddItemToHallOfFame(ctx context.Context, userId int64, award float64) error {
	key := getAddHallOfFameKey(ctx)
	if len(key) <= 0 {
		logger.Errorf(ctx, "get add to hall of fame key is nil, userId: %v", userId)
		return errors.New("key is nil")
	}

	scoreAward, err := p.redisClient.ZScore(ctx, key, strconv.FormatInt(userId, 10)).Result()
	if err != nil && err != rdsV8.Nil {
		logger.Errorf(ctx, "get score by key: %v, userId: %v, err: %v", key, userId, err)
		return err
	}

	if err == rdsV8.Nil {
		if err := p.AddItemToRedisOnHallOfFame(ctx, award, userId); err != nil {
			logger.Errorf(ctx, "add first item on user to redis fail, err: %v, userId: %v, award: %v", err, userId, award)
			return err
		}

		p.addOpDone = true
		logger.Infof(ctx, "add first item on user to hall of fame succ, userId: %v, award: %v", userId, award)
		return nil
	}

	originAward, _, _ := p.ParseAwardAndCreateTime(ctx, scoreAward)
	newAward := originAward + award

	if err := p.AddItemToRedisOnHallOfFame(ctx, newAward, userId); err != nil {
		logger.Errorf(ctx, "add other item on user to redis fail, err: %v, userId: %v, award: %v", err, userId, newAward)
		return err
	}

	p.addOpDone = true
	logger.Infof(ctx, "add other item on user to hall of fame succ, userId: %v, award: %v", userId, newAward)
	return nil
}
func (p *KoLaHallOfFame) SubItemFromHallOfFame(ctx context.Context, userId int64, award float64) error {
	if award <= 0.0001 {
		return nil
	}
	key := getAddHallOfFameKey(ctx)
	if len(key) <= 0 {
		logger.Errorf(ctx, "get add to hall of fame key is nil, userId: %v", userId)
		return errors.New("key is nil")
	}

	scoreAward, err := p.redisClient.ZScore(ctx, key, strconv.FormatInt(userId, 10)).Result()
	if err != nil && err != rdsV8.Nil {
		logger.Errorf(ctx, "get score by key: %v, userId: %v, err: %v", key, userId, err)
		return err
	}
	if err == rdsV8.Nil {
		logger.Infof(ctx, "not has award on hall of fame, userId: %v, key: %v", userId, key)
		return nil
	}

	originAward, _, _ := p.ParseAwardAndCreateTime(ctx, scoreAward)
	newAward := originAward - award
	if newAward < 0.0001 {
		newAward = 0.0
	}
	if err := p.AddItemToRedisOnHallOfFame(ctx, newAward, userId); err != nil {
		logger.Errorf(ctx, "add other item on user to redis fail, err: %v, userId: %v, award: %v", err, userId, newAward)
		return err
	}
	logger.Infof(ctx, "sub award: %v, ret award: %v for user: %v", award, newAward, userId)
	return nil
}

func (p *KoLaHallOfFame) PenalizeWorkAward(ctx context.Context, workId int64) error {
	workInfo, err := GetWorkInfoOnPenalizedWork(ctx, p.Mng, workId)
	if err != nil {
		return err
	}
	if workInfo == nil {
		return nil
	}

	defaultEndHourMinute := "23:30"

	if config.ServerConfig.WithdrawConfig != nil && len(config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.SettlementEndTime) > 0 {
		defaultEndHourMinute = config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.SettlementEndTime
	}

	cfgEndTime, err := time.Parse("15:04", defaultEndHourMinute)
	if err != nil {
		logger.Errorf(ctx, "parse time: %v fail, err: %v", defaultEndHourMinute, err)
		return err
	}
	logger.Infof(ctx, "parse time hour: %v, minute: %v", cfgEndTime.Hour(), cfgEndTime.Minute())

	var (
		nowTime = time.Now()
	)

	filter := bson.D{
		{"work_id", workInfo.WorkInfoDbModel.GetId()},
		{"user_id", workInfo.WorkInfoDbModel.GetUserId()},
		{"type", model.AwardSettlement},
	}
	opts := bson.D{}
	opts = append(opts, bson.E{Key: "_id", Value: const_busi.SortTypeDesc})

	if nowTime.Hour() > cfgEndTime.Hour() || (nowTime.Hour() == cfgEndTime.Hour() && nowTime.Minute() > cfgEndTime.Minute()) {
		nextDay := time.Now().AddDate(0, 0, 1)
		logger.Infof(ctx, "not penalize work on hall of fame built, just penalize next day: %04d_%02d_%02d", nextDay.Year(), int(nextDay.Month()), nextDay.Day())

		filter = append(filter,
			bson.E{Key: "create_time", Value: bson.D{{"$gte",
				time.Date(time.Now().Year(), time.Now().Month(), time.Now().Day(), cfgEndTime.Hour(), cfgEndTime.Minute(), cfgEndTime.Second(), 0, time.Local).UnixMilli()}}})
	} else {
		logger.Infof(ctx, "penalize work on this hall of fame: %04d_%02d_%02d", time.Now().Year(), int(time.Now().Month()), time.Now().Day())

		yesterday := time.Now().AddDate(0, 0, -1)
		filter = append(filter,
			bson.E{Key: "create_time", Value: bson.D{{"$gte",
				time.Date(yesterday.Year(), yesterday.Month(), yesterday.Day(), cfgEndTime.Hour(), cfgEndTime.Minute(), cfgEndTime.Second(), 0, time.Local).UnixMilli()}}},
			bson.E{Key: "create_time", Value: bson.D{{"$lte", time.Now().UnixMilli()}}})
	}

	targetAwardItem, err := p.Mng.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.ListByCond(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "not get work award item, workId: %v, userId: %v, err: %v", workInfo.WorkInfoDbModel.GetId(), workInfo.WorkInfoDbModel.GetUserId(), err)
		return err
	}
	if len(targetAwardItem) <= 0 {
		logger.Infof(ctx, "not find work award dur this time, workId: %v, userId: %v, err: %v", workInfo.WorkInfoDbModel.GetId(), workInfo.WorkInfoDbModel.GetUserId())
		return nil
	}

	var awardValue float64 = 0.0000
	for k, _ := range targetAwardItem {
		if targetAwardItem[k] == nil || targetAwardItem[k].GetAward() <= 0.0001 {
			continue
		}

		awardValue += targetAwardItem[k].GetAward()
	}
	if awardValue <= 0.0001 {
		return nil
	}

	p.SubItemFromHallOfFame(ctx, workInfo.WorkInfoDbModel.GetUserId(), awardValue)
	return nil
}

func NewSettleKolaHallOfFameInstance(mng *ContentMng) IKoLaHallOfFame {
	return &KoLaHallOfFame{
		Mng:         mng,
		redisClient: mng.DataCache.GetImpl().RedisCli,
		addOpDone:   false,
		limits:      int64(config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.Limits),
	}
}

func (p *KoLaHallOfFame) CheckSettlementIsReady(ctx context.Context, cfg *config.KoLaHallOfFameConfig) (int32, error) {

	defaultEndHourMinute := "23:30"
	if cfg != nil && len(cfg.SettlementEndTime) > 0 {
		defaultEndHourMinute = cfg.SettlementEndTime
		logger.Infof(ctx, "use cfg settlement time: %v", defaultEndHourMinute)
	} else {
		logger.Infof(ctx, "user default end time: %v", defaultEndHourMinute)
	}

	cfgEndTime, err := time.Parse("15:04", defaultEndHourMinute)
	if err != nil {
		logger.Errorf(ctx, "parse time: %v fail, err: %v", defaultEndHourMinute, err)
		return 0, err
	}
	logger.Infof(ctx, "parse time hour: %v, minute: %v", cfgEndTime.Hour(), cfgEndTime.Minute())

	nowTime := time.Now()
	toExpireTime := int32(0)
	if (cfgEndTime.Hour() > nowTime.Hour()) || (cfgEndTime.Hour() == nowTime.Hour() && cfgEndTime.Minute() > nowTime.Minute()) {

		toExpireTime = int32(time.Date(nowTime.Year(), nowTime.Month(), nowTime.Day(), cfgEndTime.Hour(), cfgEndTime.Minute(), 0, 0, time.Local).Sub(nowTime) / time.Second)
		logger.Infof(ctx, "task to ready need to wait for: %v second", toExpireTime)

	} else {
		logger.Infof(ctx, "has ready to settlement for hall of fame")
	}

	return toExpireTime, nil
}

func (p *KoLaHallOfFame) DoSettlementOnHallOfFame(ctx context.Context) error {
	// 获取 排行榜列表，然后检查 每条记录是否存在，存在则添加，粗存在则添加。
	items, err := p.GetTopN(ctx)
	if err != nil {
		logger.Infof(ctx, "get topN from hall of fame fail, err: %v", err)
		return err
	}

	if len(items) <= 0 {
		logger.Errorf(ctx, "get hall of fame is empty")
		return nil
	}

	for k, _ := range items {
		if items[k] == nil {
			continue
		}
		// *pbapi.UserItemOnHalfOfFame, user_id, type: 7, hall_of_fame_term
		term := fmt.Sprintf(FormatHallOfFameListKey, time.Now().Year(), int(time.Now().Month()), time.Now().Day())

		settlementHandle := NewHallOfFameInstance(p.Mng)
		item, err := settlementHandle.FindHallOfFameItem(ctx, items[k].UserInfo.GetUserId(), term)
		if err != nil {
			logger.Errorf(ctx, "find item fail on hall of fame, err: %v, userId: %v, term: %v", err, items[k].UserInfo.GetUserId(), term)
			continue
		}

		if item != nil {
			logger.Infof(ctx, "has exist item on hall of fame, userId: %v, term: %v", items[k].UserInfo.GetUserId(), term)
			continue
		}
		award := float64(setting.Maozhua.RewardKoLaHallOfFame.Get()) / 100
		err = settlementHandle.WriteHallOfFameItem(ctx, items[k].UserInfo.GetUserId(), award, term)
		if err != nil {
			logger.Errorf(ctx, "write award on hall of fame to superior tab fail, err: %v, userId: %v, term: %v",
				err, items[k].UserInfo.GetUserId(), term)
			continue
		}

		p.LightMvpMedal(ctx, items[k].UserInfo.GetUserId())

		go func(userId int64) {
			//钱包消息
			award := float64(setting.Maozhua.RewardKoLaHallOfFame.Get()) / 100
			canWithdrawAward, _ := p.Mng.GetCanWithdrawAwardByUserId(ctx, userId)
			msgData := &pbapi.Wallet{
				Type:       proto.Int32(const_busi.WalletMsgTypeAward),
				Amount:     proto.String(strconv.FormatFloat(award, 'f', 2, 64)),
				Balance:    proto.String(strconv.FormatFloat(canWithdrawAward, 'f', 2, 64)),
				Desc:       proto.String("上榜可乐名人堂"),
				CreateTime: proto.Int64(time.Now().UnixMilli()),
			}
			if err := p.Mng.SendWalletMsg(ctx, userId, int32(pbconst.MessageTypeEnum_msg_type_wallet_award_notice), "您有一笔奖励金入账，快去看看吧！", msgData); err != nil {
				logger.Errorf(ctx, "sendWalletMsg error: %v", err)
			}
		}(items[k].UserInfo.GetUserId())
	}
	return nil
}

func GetMvpMedalExpireTimeSecond() int64 {
	defaultExpireTimeSecond := int64(7 * 24 * 3600)
	if config.ServerConfig.SuperiorContentConfig != nil && config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.MedalExpireSecond > 0 {
		defaultExpireTimeSecond = config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.MedalExpireSecond
	}

	return defaultExpireTimeSecond // days
}
func GetMvpMedalNo() int64 {
	return 12
}
func (p *KoLaHallOfFame) LightMvpMedal(ctx context.Context, userId int64) error {
	//勋章名称：MVP勋章
	//勋章描述：获得可乐名人堂奖励即点亮，若隔7天未达将消失
	//勋章展示逻辑：
	//       a)用户获得一次名人堂奖励结算后，同时点亮该勋章；
	//       b) 一次点亮后，若后续再未触发点亮条件，则该勋章可维持点亮状态7天
	err := p.Mng.setMedal(ctx, userId, GetMvpMedalNo(), GetMvpMedalExpireTimeSecond())
	if err != nil {
		logger.Errorf(ctx, "light mvp medal fail, err: %v, userId: %v, medal no: %v, expireSecond: %v",
			err, userId, GetMvpMedalNo(), GetMvpMedalExpireTimeSecond())
		return err
	}
	return nil
}

type ITask interface {
	Run(ctx context.Context) error
	GetTaskType() string
	GetTaskId() int32
}

type TaskQueryUserInfo struct {
	serialNum int
	// in
	userId int64
	handle data_cache.IDataCacheMng
	// out
	userInfo *data_cache.UserInfoLocal
	err      error
}

func NewTaskQueryUserInfo(i int, userId int64, h data_cache.IDataCacheMng) ITask {
	return &TaskQueryUserInfo{
		userId:    userId,
		handle:    h,
		serialNum: i,
	}
}
func (tq *TaskQueryUserInfo) Run(ctx context.Context) error {
	userInfo, err := tq.handle.GetUserInfoLocal(ctx, nil, tq.userId, false)
	if err != nil {
		logger.Errorf(ctx, "get user info fail, err: %v, userId: %d", err, tq.userId)
		tq.err = err
		return err
	}
	tq.userInfo = userInfo
	return nil
}
func (tq *TaskQueryUserInfo) GetTaskType() string {
	return "hall of fame, get user info"
}
func (tq *TaskQueryUserInfo) GetTaskId() int32 {
	return int32(tq.serialNum)
}

// /
func NewTaskTalkClose(i int, userId int64, h data_cache.IDataCacheMng) ITask {
	return &TaskTalkClose{
		serialNum: i,
		userId:    userId,
		handle:    h,
	}
}

type TaskTalkClose struct {
	serialNum int
	// in
	userId int64
	handle data_cache.IDataCacheMng
	// out
	err       error
	talkClose int32
}

func (tt *TaskTalkClose) Run(ctx context.Context) error {
	tt.talkClose = tt.handle.GetUserInfoTalkMode(ctx, tt.userId)
	return nil
}
func (tt *TaskTalkClose) GetTaskType() string {
	return "hall of fame, talk close"
}
func (tt *TaskTalkClose) GetTaskId() int32 {
	return int32(tt.serialNum)
}

// ///////
type TaskGroup struct {
	wg    sync.WaitGroup
	tasks map[int64]ITask //userId, ITask
}

func (tg *TaskGroup) RegisterTask(id int64, tsk ITask) {
	if tg.tasks == nil {
		tg.tasks = make(map[int64]ITask)
	}
	tg.tasks[id] = tsk
}
func (tg *TaskGroup) Start(ctx context.Context) error {
	taskNums := len(tg.tasks)
	if taskNums <= 0 {
		return nil
	}

	for id, _ := range tg.tasks {
		tg.wg.Add(1)

		go func(index int64) {
			defer func() {
				if e := recover(); e != nil {
					logger.Errorf(ctx, "receive panic, task id: %v, userId: %v,, busi type: %v", tg.tasks[index].GetTaskId(), index, tg.tasks[index].GetTaskType())
				}
				tg.wg.Done()
			}()

			err := tg.tasks[index].Run(ctx)
			if err != nil {
				logger.Errorf(ctx, "run task fail, task index: %v, userId: %v, err: %v, busi type: %v", tg.tasks[index].GetTaskId(), index, err, tg.tasks[index].GetTaskType())
			}
		}(id)
	}
	return nil
}
func (tg *TaskGroup) Wait() error {
	tg.wg.Wait()
	return nil
}
