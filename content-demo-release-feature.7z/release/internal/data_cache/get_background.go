package data_cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"time"
)

// GetBackgroundWithTalk 私聊背景
func (p *DataCacheMng) GetBackgroundWithTalk(ctx context.Context) (string, error) {
	rdsKey := getRdsKeyBackground("talk")
	bg, err := p.getRdsBackgroundImage(ctx, rdsKey)
	if err != nil || bg == nil {
		return "", err
	}

	return bg.Image, nil
}

// GetBackgroundWithWork 动态背景
func (p *DataCacheMng) GetBackgroundWithWork(ctx context.Context) (string, error) {
	rdsKey := getRdsKeyBackground("work")
	bg, err := p.getRdsBackgroundImage(ctx, rdsKey)
	if err != nil || bg == nil {
		return "", err
	}

	return bg.Image, nil
}

func (p *DataCacheMng) getRdsBackgroundImage(ctx context.Context, rdsKey string) (*model.BackgroundImage, error) {
	list, err := p.RedisCli.ZRangeWithScores(ctx, rdsKey, 0, -1).Result()
	if err != nil {
		return nil, err
	}

	if len(list) == 0 {
		return nil, nil
	}

	for _, data := range list {
		nowTime := time.Now().UnixMilli()
		startTime := int64(data.Score)

		if nowTime < startTime {
			continue
		}

		bg := model.BackgroundImage{}
		if err := json.Unmarshal([]byte(data.Member.(string)), &bg); err != nil {
			logger.Error(ctx, "getRdsBackgroundImage.json.Unmarshal", err)
		}

		if !bg.Status {
			// 未开启
			continue
		}

		if nowTime > bg.TimePartEnd {
			_, _ = p.RedisCli.ZRem(ctx, rdsKey, data.Member).Result()
			continue
		}

		return &bg, nil
	}

	return nil, nil
}
