package talk

import (
	"content_svr/app/maozhua_admin_svr/common/util_user"
	"context"
	"go.mongodb.org/mongo-driver/bson"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type TalkListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewTalkListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *TalkListLogic {
	return &TalkListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *TalkListLogic) TalkList(req *types.TalkListRes) (resp *types.TalkListResp, err error) {
	filter, opt := req.ParseMongo()
	opt.Sort = bson.D{{"createTime", -1}}

	total, err := l.svcCtx.ManagerDB.PersonalTalkMessageRecord.Count(l.ctx, filter)
	if err != nil {
		return nil, err
	}
	records, err := l.svcCtx.ManagerDB.PersonalTalkMessageRecord.FindAll(l.ctx, filter, opt)
	if err != nil {
		return nil, err
	}

	for i := 0; i < len(records); i++ {
		records[i].ObjectId = util_user.FixImageUrl(l.svcCtx.Config.ImageHost, records[i].ObjectId)
	}

	resp = &types.TalkListResp{}
	resp.Total = total
	resp.List = records

	return
}
