package mg_model

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"github.com/gookit/goutil/timex"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

type IWorkCommentDetailMgModel interface {
	Insert(ctx context.Context, item *pbmgdb.WorksCommentDetailMgDbModel) error
	InsertMany(ctx context.Context, items []*pbmgdb.WorksCommentDetailMgDbModel) error
	UpdateLikeNumsByCond(ctx context.Context, eqConds map[string]interface{}, inc map[string]interface{}) error

	UpdateItemById(ctx context.Context, id int64, status int32) error
	GetItemById(ctx context.Context, id int64) (*pbmgdb.WorksCommentDetailMgDbModel, error)
	DeleteItemsByCond(ctx context.Context, conds map[string]interface{}, new_values map[string]interface{}) (int64, error)
	DeleteItemByCond(ctx context.Context, conds map[string]interface{}, new_values map[string]interface{}) error
	BulkGetItemsById(ctx context.Context, size int32, comment_id int64, work_id int64, sortType int32) (*pbapi.WorkCommentPullResponse, error)
	GetAllItems(ctx context.Context, eqConds, largeConds, lessConds map[string]interface{}, sortField map[string]int32, limits int32) (*pbapi.WorkCommentPullResponse, error)
	GetCommentById(ctx context.Context, id int64) (*pbmgdb.WorksCommentDetailMgDbModel, error)
	GetCommentDetails(ctx context.Context, eqConds, largeConds, lessConds map[string]interface{}, sortField map[string]int32, limits int32) ([]*pbmgdb.WorksCommentDetailMgDbModel, error)
	GetCommentSpecialFieldVal(ctx context.Context, eqConds, largeConds, lessConds map[string]interface{}, sortField map[string]int32, limits int32,
		specialField map[string]int32) ([]map[string]interface{}, error)
	IsDailyFirstComment(ctx context.Context, userId int64) (bool, error)
}
type WorkCommentDetailMgDbImpl struct {
	MgDB *mongo.Database
}

func NewWorkCommentDetailMgModelImpl(db *mongo.Database) IWorkCommentDetailMgModel {
	return &WorkCommentDetailMgDbImpl{MgDB: db}
}
func (impl *WorkCommentDetailMgDbImpl) GetCommentSpecialFieldVal(ctx context.Context, eqConds, largeConds, lessConds map[string]interface{}, sortField map[string]int32, limits int32,
	specialField map[string]int32) ([]map[string]interface{}, error) {
	coll := impl.MgDB.Collection(impl.collection())
	filter := bson.D{}
	for k, v := range eqConds {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	for k, v := range largeConds {
		filter = append(filter, bson.E{k, bson.D{{"$gt", v}}})
	}
	for k, v := range lessConds {
		filter = append(filter, bson.E{k, bson.D{{"$lt", v}}})
	}
	var sortExpand bson.D
	for k, v := range sortField {
		sortExpand = append(sortExpand, bson.E{Key: k, Value: v})
	}
	//
	opts := options.Find()
	if len(sortExpand) > 0 {
		opts.SetSort(sortExpand)
	}

	if limits > 0 {
		opts.SetLimit(int64(limits))
	}
	var projection bson.D
	for k, v := range specialField {
		projection = append(projection, bson.E{Key: k, Value: v})
	}
	opts.SetProjection(projection)

	cursor, err := coll.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "find comment detail fail, err: %v", err)
		return nil, err
	}
	//
	var retData []map[string]interface{}
	for cursor.Next(ctx) {
		var result bson.M
		err = cursor.Decode(&result)
		if err != nil {
			logger.Errorf(ctx, "get comment detail query result fail, err: %v", err)
			return nil, err
		}

		var tmpRet map[string]interface{}
		for k, v := range result {
			if tmpRet == nil {
				tmpRet = make(map[string]interface{})
			}
			tmpRet[k] = v
		}
		retData = append(retData, tmpRet)
	}
	return retData, nil
}
func (impl *WorkCommentDetailMgDbImpl) UpdateLikeNumsByCond(ctx context.Context, eqConds map[string]interface{}, inc map[string]interface{}) error {
	coll := impl.MgDB.Collection(impl.collection())
	filter := bson.D{}
	for k, v := range eqConds {
		filter = append(filter, bson.E{Key: k, Value: v})
	}

	incFieldValues := bson.D{}
	for k, v := range inc {
		incFieldValues = append(incFieldValues, bson.E{Key: k, Value: v})
	}
	update := bson.D{}
	update = append(update, bson.E{Key: "$inc", Value: incFieldValues})
	_, err := coll.UpdateOne(ctx, filter, update)
	return err

}
func (impl *WorkCommentDetailMgDbImpl) GetCommentById(ctx context.Context, id int64) (*pbmgdb.WorksCommentDetailMgDbModel, error) {
	filter := bson.D{
		{"_id", id},
	}
	w := &pbmgdb.WorksCommentDetailMgDbModel{}
	result := impl.MgDB.Collection(impl.collection()).FindOne(ctx, filter)
	if err := result.Decode(w); err != nil {
		return nil, err
	}
	return w, nil
}

func (impl *WorkCommentDetailMgDbImpl) GetCommentDetails(ctx context.Context, eqConds, largeConds, lessConds map[string]interface{},
	sortField map[string]int32, limits int32) ([]*pbmgdb.WorksCommentDetailMgDbModel, error) {
	coll := impl.MgDB.Collection(impl.collection())
	filter := bson.D{}
	for k, v := range eqConds {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	for k, v := range largeConds {
		filter = append(filter, bson.E{k, bson.D{{"$gt", v}}})
	}
	for k, v := range lessConds {
		filter = append(filter, bson.E{k, bson.D{{"$lt", v}}})
	}
	var sortExpand bson.D
	for k, v := range sortField {
		sortExpand = append(sortExpand, bson.E{Key: k, Value: v})
	}
	//
	opts := options.Find()
	if len(sortExpand) > 0 {
		opts.SetSort(sortExpand)
	}
	if limits > 0 {
		opts.SetLimit(int64(limits))
	}

	cursor, err := coll.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "find comment detail fail, err: %v", err)
		return nil, err
	}
	var result []*pbmgdb.WorksCommentDetailMgDbModel
	for cursor.Next(ctx) {
		data := &pbmgdb.WorksCommentDetailMgDbModel{}
		err = cursor.Decode(data)
		if err != nil {
			logger.Errorf(ctx, "get comment detail query result fail, err: %v", err)
			return nil, err
		}
		result = append(result, data)
	}
	if len(result) <= 0 {
		return nil, nil
	}
	return result, nil
}
func (impl *WorkCommentDetailMgDbImpl) GetAllItems(ctx context.Context, eqConds, largeConds, lessConds map[string]interface{},
	sortField map[string]int32, limits int32) (*pbapi.WorkCommentPullResponse, error) {
	var result []*pbmgdb.WorksCommentDetailMgDbModel
	var err error
	result, err = impl.GetCommentDetails(ctx, eqConds, largeConds, lessConds, sortField, limits)
	if err != nil || len(result) <= 0 {
		return &pbapi.WorkCommentPullResponse{Contents: make([]*pbapi.WorkCommentBrief, 0)}, nil
	}
	//
	var arrSubResponse []*pbapi.WorkCommentBrief
	for i, _ := range result {
		formatTimeStr := "2006-01-02 15:04:05.000"
		createTimeUnixTime, _ := time.ParseInLocation(formatTimeStr, *result[i].CreateTime, time.Local)
		createTimeUnix := createTimeUnixTime.UnixMilli()
		arrSubResponse = append(arrSubResponse, &pbapi.WorkCommentBrief{
			Id:         &result[i].Id,
			Comment:    result[i].Comment,
			FromUserId: result[i].UserId,
			Ip:         result[i].Ip,
			CreateTime: &createTimeUnix,
			UserInfo: &pbapi.SimpleUserInfo{
				City:     result[i].GetCity(),
				Province: result[i].GetProvince(),
			},
			CommentObject: result[i].GetCommentObject(),
			LikeNums:      proto.Int32(int32(result[i].GetLikedCount())),
			CommentType:   result[i].CommentType,
			BeCommentUserInfo: &pbapi.SimpleUserInfo{
				UserId: result[i].GetBeCommentUserId(),
			},
			Icon: result[i].Icon,
			Jump: result[i].Jump,
		})
	}

	return &pbapi.WorkCommentPullResponse{
		Contents: arrSubResponse,
	}, nil
}
func (impl *WorkCommentDetailMgDbImpl) BulkGetItemsById(ctx context.Context, size int32,
	commentId int64, workId int64, sortType int32) (*pbapi.WorkCommentPullResponse, error) {

	coll := impl.MgDB.Collection(impl.collection())
	// filter

	eq_filter := bson.D{
		{"$and",
			bson.A{
				bson.D{{"work_id", workId}},
				bson.D{{"status", 1}},
			},
		},
	}
	arrange_filter := bson.D{
		{
			"_id", bson.D{{"$gt", commentId}},
		},
	}

	filter := bson.D{
		{
			"$and",
			bson.A{
				eq_filter,
				arrange_filter,
			},
		},
	}

	opts := options.Find().SetSort(bson.D{{"_id", sortType}}).SetLimit(int64(size)) // 1: asc, -1: desc
	cursor, err := coll.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "find comment detail fail, err: %v", err)
		return nil, err
	}
	var result []*pbmgdb.WorksCommentDetailMgDbModel
	for cursor.Next(ctx) {
		data := &pbmgdb.WorksCommentDetailMgDbModel{}
		err = cursor.Decode(data)
		if err != nil {
			logger.Errorf(ctx, "get comment detail query result fail, err: %v", err)
			return nil, err
		}
		result = append(result, data)
	}
	if len(result) <= 0 {
		return nil, nil
	}

	var arrSubResponse []*pbapi.WorkCommentBrief
	for i, _ := range result {
		formatTimeStr := "2006-01-02 15:04:05.000"
		createTimeUnixTime, _ := time.ParseInLocation(formatTimeStr, *result[i].CreateTime, time.Local)
		createTimeUnix := createTimeUnixTime.UnixMilli()
		arrSubResponse = append(arrSubResponse, &pbapi.WorkCommentBrief{
			Id:         &result[i].Id,
			Comment:    result[i].Comment,
			Ip:         result[i].Ip,
			FromUserId: result[i].UserId,
			CreateTime: &createTimeUnix,
		})
	}

	return &pbapi.WorkCommentPullResponse{
		Contents: arrSubResponse,
	}, nil
}

func (impl *WorkCommentDetailMgDbImpl) updateStatus(conds map[string]interface{}, new_values map[string]interface{}) (
	filter bson.D, update bson.D) {
	//
	if len(conds) <= 0 || len(new_values) <= 0 {
		return nil, nil
	}
	filter = bson.D{}
	for k, v := range conds {
		filter = append(filter, bson.E{Key: k, Value: v})
	}

	set_field_value := bson.D{}
	for k, v := range new_values {
		set_field_value = append(set_field_value, bson.E{Key: k, Value: v})
	}

	set_field_value = append(set_field_value, bson.E{Key: "update_time", Value: time.Now().Format("2006-01-02 15:04:05.000")})

	//currentDateBsonD := bson.D{}
	//currentDateBsonD = append(currentDateBsonD, bson.E{Field: "update_time", Value: true})

	update = bson.D{}
	update = append(update, bson.E{Key: "$set", Value: set_field_value})
	//update = append(update, bson.E{Field: "$currentDate", Value: currentDateBsonD})

	return filter, update
}

func (impl *WorkCommentDetailMgDbImpl) DeleteItemsByCond(ctx context.Context, conds map[string]interface{},
	new_values map[string]interface{}) (int64, error) {
	filter, update := impl.updateStatus(conds, new_values)
	if filter == nil || update == nil {
		return 0, nil
	}
	resultUpdate, err := impl.MgDB.Collection(impl.collection()).UpdateMany(ctx, filter, update)
	if err != nil {
		return 0, err
	}
	if resultUpdate.ModifiedCount == 0 {
		logger.Warnf(ctx,
			fmt.Sprintf("WorkCommentDetailMgDbImpl.DeleteItemsByCond: ##%v##%v##", filter, update),
			errors.New("没有删除任何一条评论"))
	}
	return resultUpdate.ModifiedCount, err
}

func (impl *WorkCommentDetailMgDbImpl) DeleteItemByCond(ctx context.Context, conds map[string]interface{},
	new_values map[string]interface{}) error {
	filter, update := impl.updateStatus(conds, new_values)
	if filter == nil || update == nil {
		return nil
	}
	_, err := impl.MgDB.Collection(impl.collection()).UpdateOne(ctx, filter, update)
	return err
}
func (impl *WorkCommentDetailMgDbImpl) collection() string {
	return "works_comment_detail"
}
func (impl *WorkCommentDetailMgDbImpl) Insert(ctx context.Context, item *pbmgdb.WorksCommentDetailMgDbModel) error {
	_, err := impl.MgDB.Collection(impl.collection()).InsertOne(ctx, item)
	return err
}

func (impl *WorkCommentDetailMgDbImpl) InsertMany(ctx context.Context, items []*pbmgdb.WorksCommentDetailMgDbModel) error {
	insert := make([]interface{}, 0)
	for _, item := range items {
		insert = append(insert, item)
	}
	_, err := impl.MgDB.Collection(impl.collection()).InsertMany(ctx, insert)
	return err
}

func (impl *WorkCommentDetailMgDbImpl) UpdateItemById(ctx context.Context, id int64, status int32) error {
	//TODO:
	return nil
}
func (impl *WorkCommentDetailMgDbImpl) GetItemById(ctx context.Context, id int64) (*pbmgdb.WorksCommentDetailMgDbModel, error) {
	//TODO:
	return nil, nil
}

// 是否首条评论
func (impl *WorkCommentDetailMgDbImpl) IsDailyFirstComment(ctx context.Context, userId int64) (bool, error) {
	b := bson.M{"user_id": userId, "create_time": bson.M{"$gte": timex.Datetime(timex.DayStart(time.Now()), timex.LayoutWithMs3)}}
	c, err := impl.MgDB.Collection(impl.collection()).CountDocuments(ctx, b)
	if err != nil {
		return false, nil
	}

	if c > 1 {
		return false, nil
	}

	return true, nil
}

// new again....
type IUserCommentUnreadWorkMgModel interface {
	InsertOrUpdate(ctx context.Context, item *pbmgdb.UserCommentUnreadWork) error
	UpdateItem(ctx context.Context, workId int64, from_status int32, to_status int32, include_user int64) error
	UpdateItemGeneral(ctx context.Context, eq_conds, neq_conds map[string]interface{}, up_kv map[string]interface{}) error
	QueryItems(ctx context.Context, conds map[string]interface{}, large_conds map[string]interface{},
		sorts map[string]int32, limit int32) ([]int64, error)
}
type UserCommentUnreadWorkMgModelImpl struct {
	MgDB *mongo.Database
}

func NewUserCommentUnreadWorkMgModelImpl(db *mongo.Database) IUserCommentUnreadWorkMgModel {
	return &UserCommentUnreadWorkMgModelImpl{MgDB: db}
}
func (impl *UserCommentUnreadWorkMgModelImpl) collection() string {
	return "CommentUserUnreadWork"
}

func GetLocalTimeInt() int64 {
	return time.Now().Unix()
}

func (impl *UserCommentUnreadWorkMgModelImpl) UpdateItemGeneral(ctx context.Context, eq_conds, neq_conds map[string]interface{}, up_kv map[string]interface{}) error {
	coll := impl.MgDB.Collection(impl.collection())
	var conds_expand bson.D
	//
	for k, v := range eq_conds {
		conds_expand = append(conds_expand, bson.E{Key: k, Value: v})
	}
	for k, v := range neq_conds {
		conds_expand = append(conds_expand, bson.E{k, bson.D{{"$ne", v}}})
	}

	var update_mg_kv bson.D
	if len(up_kv) > 0 {
		update_mg_kv = append(update_mg_kv, bson.E{"$set", up_kv})
	}
	ret, err := coll.UpdateMany(ctx, conds_expand, update_mg_kv)
	if err != nil {
		logger.Errorf(ctx, "update tab: %v fail, err: %v", impl.collection(), err)
		return errors.Wrap(errorcode.Comment_db_op_fail)
	}
	//
	debug_info := "eq_cond: "
	for k, v := range eq_conds {
		debug_info += fmt.Sprintf("%v: %v", k, v)
	}
	//
	neq_conds_str := "neq_eq: "
	for k, v := range neq_conds {
		neq_conds_str += fmt.Sprintf("%v: %v", k, v)
	}
	//
	up_data_str := "update_v: "
	for k, v := range up_kv {
		up_data_str += fmt.Sprintf("%v: %v", k, v)
	}
	logger.Infof(ctx, "UpdateItemGeneral: op tab: %v, modify nums: %v, %v, %v, %v", impl.collection(), ret.ModifiedCount, debug_info, neq_conds_str, up_data_str)
	return nil
}
func (impl *UserCommentUnreadWorkMgModelImpl) InsertOrUpdate(ctx context.Context, item *pbmgdb.UserCommentUnreadWork) error {
	coll := impl.MgDB.Collection(impl.collection())
	//update({work_id:123, user_id: 123}, {$set: {status:0}, $currentDate: {update_time: true}, {upsert: true}})
	local_time_ux_mill := time.Now().UnixMilli()
	filter := bson.D{
		{"user_id", item.GetUserId()},
		{"work_id", item.GetWorkId()}}

	update := bson.D{
		{"$set", bson.D{
			{"user_id", item.GetUserId()},
			{"work_id", item.GetWorkId()},
			{"status", item.GetStatus()}}}, //这是更新字段
		{"$setOnInsert", bson.D{
			{"create_time", local_time_ux_mill}, //这是插入字段 TODO:
			{"work_create_time", item.GetWorkCreateTime()},
		}},
		{"$currentDate", bson.D{ //更新时每次自动更新时间,
			{"update_time", true}}}}
	opts := options.Update().SetUpsert(true)
	op_ret, err := coll.UpdateOne(ctx, filter, update, opts)
	if err != nil {
		logger.Errorf(ctx, "op to tab: %v fail, work id: %v, user_id: %v, err: %v", impl.collection(), item.GetWorkId(), item.GetUserId(), err)
		return err
	}
	logger.Infof(ctx, "op to tab: %v, work id: %v, user_id: %v, upsert nums: %v, modify nums: %v",
		impl.collection(), item.GetWorkId(), item.GetUserId(), op_ret.ModifiedCount, op_ret.UpsertedCount)
	return nil
}
func (impl *UserCommentUnreadWorkMgModelImpl) UpdateItem(ctx context.Context, workId int64, from_status int32, to_status int32, include_user int64) error {
	coll := impl.MgDB.Collection(impl.collection())
	latest_time_stamp_ms := time.Now().UnixMilli() - const_busi.InvalidCommentWorkExpireTm*1000 //  latest 12 hours,只能拉最近12小时的未读帖子评论
	//
	var filter bson.D
	if include_user > 0 {
		filter = bson.D{
			{"user_id", include_user},
			{"work_id", workId},
			{"status", from_status}, // TODO define macro 1
			{"work_create_time", bson.D{
				{"$gt", latest_time_stamp_ms}}}}
	} else {
		filter = bson.D{
			{"work_id", workId},
			{"status", from_status}, // TODO define macro 1
			{"work_create_time", bson.D{
				{"$gt", latest_time_stamp_ms}}}}
	}

	update := bson.D{
		{"$set", bson.D{
			{"status", to_status},
		}},
		{"$currentDate", bson.D{
			{"update_time", true},
		}},
	}

	op_ret, err := coll.UpdateMany(ctx, filter, update)
	if err != nil {
		logger.Errorf(ctx, "update tab: %v fail, err: %v", impl.collection(), err)
		return err
	}
	logger.Infof(ctx, "workid: %v, update tab: %v, op nums: %v， status: %v to %v",
		workId, impl.collection(), op_ret.ModifiedCount, from_status, to_status)
	return nil
}
func (impl *UserCommentUnreadWorkMgModelImpl) QueryItems(ctx context.Context,
	conds map[string]interface{}, largeConds map[string]interface{}, sorts map[string]int32, limit int32) ([]int64, error) {
	//
	coll := impl.MgDB.Collection(impl.collection())

	var conds_expand bson.D
	for k, v := range conds {
		conds_expand = append(conds_expand, bson.E{k, v})
	}
	for k, v := range largeConds {
		conds_expand = append(conds_expand, bson.E{k, bson.D{{"$gt", v}}})
	}
	filter := conds_expand
	var sort_expand bson.D
	for k, v := range sorts {
		sort_expand = append(sort_expand, bson.E{Key: k, Value: v})
	}
	//
	opts := options.Find()
	if len(sort_expand) > 0 {
		opts.SetSort(sort_expand)
	}
	if limit > 0 {
		opts.SetLimit(int64(limit))
	}

	cursor, err := coll.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "find fail, %v", err)
		return nil, err
	}
	// 遍历查询结果
	var result []*pbmgdb.UserCommentUnreadWork
	for cursor.Next(ctx) {
		item := &pbmgdb.UserCommentUnreadWork{}
		// 解码绑定数据
		err = cursor.Decode(item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to UserCommentUnreadWork failed.err=%v", err), err)
			return nil, err
		}
		result = append(result, item)
	}

	var works_ret []int64
	for i, _ := range result {
		works_ret = append(works_ret, result[i].GetWorkId())
	}
	return works_ret, nil
}
