package panichelper

import (
	"context"
	"testing"
)

func TestPanicRecover(t *testing.T) {
	ctx := context.Background()
	defer PanicRecover(ctx)

	t.Log(1)
	panic(2)
	t.Log(3)
}
