package model

const SecretReportUserCollectionName = "secretReportUser"

type SecretReportUser struct {
	ID           int64 `bson:"_id" json:"_id"`
	Timestamp    int64 `json:"timestamp,omitempty" bson:"timestamp"`       // 创建时间
	ReportId     int64 `json:"reportId,omitempty" bson:"reportId"`         // SecretReport 中的 id
	ReportUserId int64 `json:"reportUserId,omitempty" bson:"reportUserId"` // 举报人/抓捕人用户id
	Source       int32 `json:"source,omitempty" bson:"source"`             //举报来源 1护卫队 2用户
	ReportType   int32 `json:"reportType,omitempty" bson:"reportType"`     //举报类型 0默认 1诈骗/广告 2骚扰/低俗 3性别不符 4头像昵称 5盗图网图 10辱骂/攻击
	WorkId       int64 `json:"workId,omitempty" bson:"workId"`             //动态id
	CommentId    int64 `json:"commentId,omitempty" bson:"commentId"`       //评论id
	UserId       int64 `json:"userId,omitempty" bson:"userId"`             //用户id
}
