package baidu_lbs_yun_proxy

import (
	"bytes"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/utils"
	"context"
	"net/http"
	"net/url"
)

type BaiduLbsYunProxyImpl struct {
	Host string
	Ak   string
	Sn   string
}

type IBaiduLbsYunProxy interface {
	GetIpAddressV2(ctx context.Context, ip string) (*pbapi.CoordinateRedis, error)
	ReverseGeocodingV2(ctx context.Context, lat float64, lng float64, ip string) (*pbapi.CoordinateRedis, error)
}

func NewBaiduLbsYunProxyImpl() IBaiduLbsYunProxy {
	return &BaiduLbsYunProxyImpl{
		Host: "https://api.map.baidu.com",
		Ak:   "SSqUwGGXZ6PVIA0CawrKvnnjvetqKdK4",
		Sn:   "FMRZKfenBhmhwXGAc4WVauGGkliyiNAc",
	}
}

func (p *BaiduLbsYunProxyImpl) sendPutRequest(ctx context.Context, url string, body []byte) (*http.Response, error) {
	req, err := http.NewRequest(http.MethodPut, url, bytes.NewBuffer(body))
	if err != nil {
		return nil, err
	}
	req.Header.Add("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	return resp, nil
}

//func (p *BaiduLbsYunProxyImpl) postRequest(ctx context.Context, url string, body []byte) (*http.Response, error) {
//	req, err := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(body))
//	if err != nil {
//		return nil, err
//	}
//	req.Header.Add("Content-Type", "application/json")
//	client := &http.Client{}
//	resp, err := client.Do(req)
//	if err != nil {
//		return nil, err
//	}
//	return resp, nil
//}

//func (p *BaiduLbsYunProxyImpl) postForm(ctx context.Context, url string, body []byte) (*http.Response, error) {
//	req, err := http.NewRequest(http.MethodPost, url, bytes.NewBuffer(body))
//	if err != nil {
//		return nil, err
//	}
//	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")
//	client := &http.Client{}
//	resp, err := client.Do(req)
//	if err != nil {
//		return nil, err
//	}
//	return resp, nil
//}

func (p *BaiduLbsYunProxyImpl) getRequest(ctx context.Context, url string) (*http.Response, error) {
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	return resp, nil
}

func (p *BaiduLbsYunProxyImpl) Sign(ctx context.Context, uri string) string {
	srcStr := uri + p.Sn
	urlEdStr := url.QueryEscape(srcStr)
	md5 := utils.MD5(urlEdStr)
	//logger.Infof(ctx, "====srcStr=%v, urlEdStr=%v", srcStr, urlEdStr)
	return md5
}
