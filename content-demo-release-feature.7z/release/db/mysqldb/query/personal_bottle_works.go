package query

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mysqldb/model"
	"context"
	"github.com/zeromicro/go-zero/core/logx"
	"gorm.io/gen"
	"gorm.io/gen/field"
)

type PersonalBottleWork struct {
	personalBottleWork
}

func NewPersonalBottleWorkModel(p personalBottleWork) PersonalBottleWork {
	return PersonalBottleWork{personalBottleWork: p}
}

func (p *personalBottleWork) ParseWhere(where map[string]interface{}) []gen.Condition {
	eqConds := make([]gen.Condition, 0)
	for key, value := range where {
		switch key {
		case "create_time_begin", "create_time_start":
			v, ok := value.(string)
			if !ok || len(v) == 0 {
				continue
			}
			eqConds = append(eqConds, p.CreateTime.Gt(v))
		case "create_time_end":
			v, ok := value.(string)
			if !ok || len(v) == 0 {
				continue
			}
			eqConds = append(eqConds, p.CreateTime.Lt(v))
		case "work_ids":
			v, ok := value.([]int64)
			if !ok || len(v) == 0 {
				continue
			}
			eqConds = append(eqConds, p.ID.In(v...))
		case "user_ids":
			v, ok := value.([]int64)
			if !ok || len(v) == 0 {
				continue
			}
			eqConds = append(eqConds, p.UserID.In(v...))
		default:
			d := &fieldValue{value: value}
			eqConds = append(eqConds, field.NewField(p.TableName(), key).Eq(d))
		}

	}

	return eqConds
}

func (p *personalBottleWork) Find(ctx context.Context, limit, offset int, where map[string]interface{}) ([]*model.PersonalBottleWork, error) {
	conds := p.ParseWhere(where)
	_db := p.WithContext(ctx)
	if limit != 0 {
		_db = _db.Limit(limit)
	}
	if offset != 0 {
		_db = _db.Offset(offset)
	}
	if where != nil {
		_db = _db.Where(conds...)
	}

	return _db.Find()
}

func (p *personalBottleWork) FindOne(ctx context.Context, where map[string]interface{}) (*model.PersonalBottleWork, error) {
	conds := p.ParseWhere(where)
	_db := p.WithContext(ctx)

	if where != nil {
		_db = _db.Where(conds...)
	}

	return _db.Take()
}

func (p *personalBottleWork) UpdateMap(ctx context.Context, where, update map[string]interface{}) (info gen.ResultInfo, err error) {
	conds := p.ParseWhere(where)
	if len(conds) == 0 {
		return gen.ResultInfo{}, xerr.DbUpdateMastWhere
	}
	info, err = p.WithContext(ctx).Where(conds...).Updates(update)
	if info.RowsAffected == 0 {
		logx.Infow("invalid update",
			logx.Field("table_name", p.TableName()),
			logx.Field("table_name_filter", where),
			logx.Field("table_name_data", update),
		)
	}
	return info, err
}

func (p *personalBottleWork) Count(ctx context.Context, conds []gen.Condition) (int64, error) {
	return p.WithContext(ctx).Where(conds...).Count()
}
