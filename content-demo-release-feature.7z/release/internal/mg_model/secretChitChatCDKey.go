package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretChitChatCDKeyMgDbModel interface {
	GetById(ctx context.Context, cdKey string) (*pbmgdb.SecretChitChatCDKeyMgDbModel, error)
	Insert(ctx context.Context, item *pbmgdb.SecretChitChatCDKeyMgDbModel) error
	UpdateDictByCdKey(ctx context.Context, cdKey string, update interface{}) error
	UpdateDictByCond(ctx context.Context, cond, update map[string]interface{}) error
	ListByCondition(ctx context.Context, cond map[string]interface{}) ([]*pbmgdb.SecretChitChatCDKeyMgDbModel, error)
	CountByCondition(ctx context.Context, cond map[string]interface{}) (int64, error)
	GetByUserId(ctx context.Context, userId int64) (*pbmgdb.SecretChitChatCDKeyMgDbModel, error)
	GetByCdKey(ctx context.Context,
		cdKey string) (*pbmgdb.SecretChitChatCDKeyMgDbModel, error)
	CreateCdKey(ctx context.Context, fromUserId, expireTime int64) (string, error)
}

type secretChitChatCDKeyMgDbImpl struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretChitChatCDKeyMgModelImpl(db *mongo.Database) ISecretChitChatCDKeyMgDbModel {
	return &secretChitChatCDKeyMgDbImpl{
		MgDB:  db,
		Table: "secretChitChatCDKey",
	}
}

// GetById 查不到返回nil
func (impl *secretChitChatCDKeyMgDbImpl) GetById(ctx context.Context, cdKey string) (*pbmgdb.SecretChitChatCDKeyMgDbModel, error) {
	retItems := make([]*pbmgdb.SecretChitChatCDKeyMgDbModel, 0)
	collection := impl.MgDB.Collection(impl.Table)
	find, err := collection.Find(ctx, bson.M{"_id": cdKey})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretChitChatCDKeyMgDbModel Find failed. _id=%v",
			cdKey), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbmgdb.SecretChitChatCDKeyMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretChitChatCDKeyMgDbModel failed. _id=%v",
				cdKey), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	if len(retItems) > 1 {
		logger.Error(ctx, fmt.Sprintf("get SecretChitChatCDKeyMgDbModel failed._id=%v",
			cdKey), err)
	}
	return retItems[0], nil
}

func (impl *secretChitChatCDKeyMgDbImpl) GetByCdKey(ctx context.Context,
	cdKey string) (*pbmgdb.SecretChitChatCDKeyMgDbModel, error) {

	item := &pbmgdb.SecretChitChatCDKeyMgDbModel{}
	collection := impl.MgDB.Collection(impl.Table)
	err := collection.FindOne(ctx, bson.M{"_id": cdKey}).Decode(item)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretChitChatCDKeyMgDbModel Find failed.cdKey=%v",
			cdKey), err)
		return nil, err
	}
	return item, err
}

func (impl *secretChitChatCDKeyMgDbImpl) GetByUserId(ctx context.Context, userId int64) (*pbmgdb.SecretChitChatCDKeyMgDbModel, error) {
	retItems := make([]*pbmgdb.SecretChitChatCDKeyMgDbModel, 0)
	collection := impl.MgDB.Collection(impl.Table)
	//
	findOptions := options.Find()
	findOptions.SetSort(bson.D{
		bson.E{Key: "createTime", Value: -1}, //倒序
	})
	//
	find, err := collection.Find(ctx, bson.M{"userId": userId}, findOptions)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretChitChatCDKeyMgDbModel Find failed. userId=%v",
			userId), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbmgdb.SecretChitChatCDKeyMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretChitChatCDKeyMgDbModel failed. userId=%v",
				userId), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	return retItems[0], nil
}

func (impl *secretChitChatCDKeyMgDbImpl) ListByCondition(ctx context.Context,
	cond map[string]interface{}) ([]*pbmgdb.SecretChitChatCDKeyMgDbModel, error) {
	collection := impl.MgDB.Collection(impl.Table)
	find, err := collection.Find(ctx, cond)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretChitChatCDKeyMgDbModel ListByCondition failed. cond=%v",
			cond), err)
		return nil, err
	}
	retItems := make([]*pbmgdb.SecretChitChatCDKeyMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.SecretChitChatCDKeyMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretChitChatCDKeyMgDbModel failed.cond=%v",
				cond), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (impl *secretChitChatCDKeyMgDbImpl) Insert(ctx context.Context, item *pbmgdb.SecretChitChatCDKeyMgDbModel) error {
	collection := impl.MgDB.Collection(impl.Table)
	_, err := collection.InsertOne(ctx, item)
	return err
}

func (impl *secretChitChatCDKeyMgDbImpl) UpdateDictByCdKey(ctx context.Context, cdKey string, update interface{}) error {
	collection := impl.MgDB.Collection(impl.Table)
	_, err := collection.UpdateByID(ctx, cdKey, update)
	return err
}

func (impl *secretChitChatCDKeyMgDbImpl) UpdateDictByCond(ctx context.Context, cond, update map[string]interface{}) error {
	collection := impl.MgDB.Collection(impl.Table)
	if len(update) == 0 || len(cond) == 0 {
		return nil
	}

	mgUpdates := bson.D{}
	if len(update) > 0 {
		mgUpdates = append(mgUpdates, bson.E{Key: "$set", Value: update})
	}
	_, err := collection.UpdateMany(ctx, cond, mgUpdates)
	return err
}

func (impl *secretChitChatCDKeyMgDbImpl) CountByCondition(ctx context.Context, cond map[string]interface{}) (int64, error) {
	collection := impl.MgDB.Collection(impl.Table)
	total, err := collection.CountDocuments(ctx, cond)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretChitChatCDKeyMgDbModel CountByCondition failed. cond=%v",
			cond), err)
		return 0, err
	}
	return total, nil
}

func (impl *secretChitChatCDKeyMgDbImpl) CreateCdKey(ctx context.Context, fromUserId, expireTime int64) (string, error) {

	item := &pbmgdb.SecretChitChatCDKeyMgDbModel{
		FromUserId: proto.Int64(fromUserId),
		CreateTime: proto.Int64(utils.GetCurTsMs()),
		Status:     proto.Int32(0),
		ExpireTime: proto.Int64(expireTime),
	}

	iTryTimes := 0
	cdKey := ""
	for iTryTimes < 1000 {
		iTryTimes++
		cdKey = utils.GenRandomCkCode()
		item.Id = cdKey
		err := impl.Insert(ctx, item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("CreateCdKey.Insert  failed. item=%v",
				item), err)
			continue
		}
		break
	}
	return cdKey, nil
}
