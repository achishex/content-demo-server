package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"context"
	"github.com/gogo/protobuf/proto"
	"strconv"
	"strings"
	"time"
)

func (p *ContentMng) GetUserInfoTalkMode(ctx context.Context, userId int64) int32 {
	return p.DataCache.GetUserInfoTalkMode(ctx, userId)
}

func (p *ContentMng) GetUserId(ctx context.Context,
	token string) (int64, error) {
	uid, err := p.DataCache.GetUserIdByToken(ctx, token)
	if err != nil {
		logger.Errorf(ctx, "get user id by token failed,err=%v", err.Error())
		return 0, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "用户不存在")
	}
	return uid, nil
}

func (p *ContentMng) GetUserMemberType(ctx context.Context, userId int64) (int32, int64) {
	//
	memberType, memberExpire := p.DataCache.GetImpl().GetUserMember(ctx, userId)
	return memberType, memberExpire
}

func (p *ContentMng) getUserInfo(ctx context.Context,
	header *pbapi.HttpHeaderInfo) (*data_cache.UserInfoLocal, error) {
	var curUserId int64 = 0
	if config.ServerConfig.Env != "prod" && header.Debuguserid > 0 {
		curUserId = header.Debuguserid
	} else {
		curUserIdTmp, err := p.DataCache.GetUserIdByToken(ctx, header.Token)
		if err != nil {
			logger.Errorf(ctx, "get user id by token failed,err=%v", err.Error())
			return nil, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "用户不存在")
		}
		curUserId = curUserIdTmp
	}

	if curUserId <= 0 {
		return nil, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "用户不存在")
	}
	curUserInfo, err := p.DataCache.GetUserInfoLocal(ctx, header, curUserId, true)
	if err != nil || curUserInfo == nil {
		return nil, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "用户不存在")
	}
	return curUserInfo, nil
}

func genUniqueId(from_user_id, to_user_id, workid int64, modeType int32) int32 {
	var builder strings.Builder
	if from_user_id < to_user_id {
		builder.WriteString(strconv.Itoa(int(from_user_id)))
		builder.WriteString(strconv.Itoa(int(to_user_id)))
	} else {
		builder.WriteString(strconv.Itoa(int(to_user_id)))
		builder.WriteString(strconv.Itoa(int(from_user_id)))
	}
	builder.WriteString(strconv.Itoa(int(modeType)))
	if workid > 0 {
		builder.WriteString(strconv.Itoa(int(workid)))
	}
	return utils.HashCode(builder.String())
}

func (p *ContentMng) getWorkDispatchTime(workModel *pbapi.PersonalBottleWorksDbModel, flagHigh, flagHighPlus bool) int {
	dispatchTime := cm_const.DispatchMaxPastTimeS
	if flagHigh || flagHighPlus {
		dispatchTime = cm_const.DispatchHighContentMaxPastTimeS
	}
	if workModel.GetSpecial() != int32(pbconst.WorkSpecialEnum_work_special_type_laolao) {
		dispatchTime = 5 * 60
	}
	return dispatchTime
}

func (p *ContentMng) setMedal(ctx context.Context, userId, MedalId, timeSecond int64) error {
	nowAfter2Day := time.Now().Add(time.Second * time.Duration(timeSecond))
	umItem := &pbapi.SecretUserMedalInfoMgDbModel{
		Id:        proto.Int64(snow_flake.GetSnowflakeID()),
		UserId:    proto.Int64(userId),
		MedalId:   proto.Int64(MedalId),
		Expire:    proto.Int64(nowAfter2Day.UnixNano() / 1e6),
		Timestamp: proto.Int64(utils.GetCurTsMs()),
	}
	err := p.DataCache.GetImpl().UserMedalMgModel.CreateOrUpdateRecord(ctx, umItem)
	if err != nil {
		logger.Errorf(ctx, "setMedal failed.", err)
		return err
	}
	return nil
}
