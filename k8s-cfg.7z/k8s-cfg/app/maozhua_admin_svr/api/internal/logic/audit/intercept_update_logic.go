package audit

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/svc/shumei"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/thirdparty/shumei_proxy"
	"context"
	"github.com/zeromicro/go-zero/core/logx"
	"time"
)

type InterceptUpdateLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewInterceptUpdateLogic(ctx context.Context, svcCtx *svc.ServiceContext) *InterceptUpdateLogic {
	return &InterceptUpdateLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

const (
	FeedbackNone      = "none"  //不操作
	FeedbackTypeMiss  = "miss"  //漏杀
	FeedbackTypeError = "error" //误杀

	RecirculateYes = 1 //重新分发
)

func (l *InterceptUpdateLogic) InterceptUpdate(req *types.InterceptUpdateReq) (resp *types.InterceptUpdateResp, err error) {
	audit, err := l.svcCtx.ManagerDB.SecretAudit.FindById(l.ctx, req.Id)
	if err != nil {
		l.Logger.Errorf("l.svcCtx.ManagerDB.SecretAudit.FindById, err: %v", err)
		return nil, err
	}

	if audit == nil {
		return nil, xerr.DbNotFound
	}

	//反馈
	if req.FeedbackType != FeedbackNone {
		fbReq := &shumei.FeedbackReq{
			RequestId:    audit.RequestId,
			FeedbackType: req.FeedbackType,
			RiskType:     0,
			Timestamp:    audit.CreateTime,
			Channel:      audit.EventId,
		}

		switch audit.AuditType {
		case cm_const.AuditTypeText:
			if _, err = l.svcCtx.ShuMei.FeedbackText(l.ctx, fbReq); err != nil {
				return nil, err
			}
		case cm_const.AuditTypeImg, cm_const.AuditTypeEmote:
			if _, err = l.svcCtx.ShuMei.FeedbackImage(l.ctx, fbReq); err != nil {
				return nil, err
			}
		default:
			return nil, xerr.FeedbackTypeNotSupport
		}

		audit.FeedbackStatus = 1
		audit.FeedbackTime = time.Now().UnixMilli()
	}

	//重新分发
	if audit.EventId == shumei_proxy.EventIDArticle && req.IsRecirculate == RecirculateYes && audit.WorkId > 0 {
		err := l.svcCtx.RedisClient.WorkInfo.AddToTsWorkPoolRedis(l.ctx, audit.WorkId)
		if err != nil {
			logx.WithContext(l.ctx).Errorf("重新分发失败, err: %v", err)
			return nil, xerr.FeedbackTypeError
		}
		audit.IsRecirculate = 1
	}

	//更新状态
	audit.UpdateTime = time.Now().UnixMilli()
	audit.VerifyUser = req.CtxName
	audit.VerifyTime = time.Now().UnixMilli()
	_, err = l.svcCtx.ManagerDB.SecretAudit.UpdateOne(l.ctx, audit.ID, audit)
	if err != nil {
		logx.WithContext(l.ctx).Errorf("更新反馈错误, err: %v", err)
		return nil, xerr.FeedbackTypeError
	}

	l.svcCtx.ManagerDB.PersonalBottleWork.UpdateWorkVerifyStatus(l.ctx, audit.WorkId, 1)

	return &types.InterceptUpdateResp{}, nil
}
