package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type SuperiorAwardDaily struct {
	model.SuperiorAwardDailyModel
	redisManage *query_rds.Manage
}

func NewCacheSuperiorAwardDaily(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *SuperiorAwardDaily {
	return &SuperiorAwardDaily{
		SuperiorAwardDailyModel: mongo.SuperiorAwardDaily,
		redisManage:             redisManage,
	}
}
