package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type IAuditMaliciousRecordMgModel interface {
	FindOne(ctx context.Context, filter bson.D, opts ...*options.FindOneOptions) (*pbmgdb.AuditMaliciousRecordMng, error)
	Create(ctx context.Context, data *pbmgdb.AuditMaliciousRecordMng, opts ...*options.InsertOneOptions) error
}

type AuditMaliciousRecordMgModelImpl struct {
	MgDB       *mongo.Database
	Collection *mongo.Collection
}

func NewAuditMaliciousRecordMgModelImpl(db *mongo.Database) IAuditMaliciousRecordMgModel {
	record := &AuditMaliciousRecordMgModelImpl{MgDB: db}
	record.Collection = record.MgDB.Collection(record.tableName())
	return record
}

func (impl *AuditMaliciousRecordMgModelImpl) tableName() string {
	return "audit_malicious_record"
}

func (impl *AuditMaliciousRecordMgModelImpl) FindOne(ctx context.Context, filter bson.D, opts ...*options.FindOneOptions) (*pbmgdb.AuditMaliciousRecordMng, error) {
	result := &pbmgdb.AuditMaliciousRecordMng{}
	err := impl.Collection.FindOne(ctx, filter, opts...).Decode(result)
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (impl *AuditMaliciousRecordMgModelImpl) Create(ctx context.Context, data *pbmgdb.AuditMaliciousRecordMng, opts ...*options.InsertOneOptions) error {
	result, err := impl.Collection.InsertOne(ctx, data, opts...)
	if err != nil {
		return err
	}

	id, ok := result.InsertedID.(string)
	if !ok {
		return nil
	}
	data.Id = id
	return nil
}
