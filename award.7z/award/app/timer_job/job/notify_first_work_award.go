package job

import (
	"content_svr/config"
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/internal/content_mng"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"context"
	"github.com/zeromicro/go-zero/core/threading"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

func InitUserNotify(write, read *dao.ManagerDB, contentMng content_mng.IContentMng) {
	threading.GoSafe(func() {
		ctrl := newUserNotifyControl(write, read, contentMng)
		//ctrl.once()
		//return

		ctrl.Do(func() {
			ctx := requestid.WithRequestID(context.Background())
			if err := ctrl.DoTask(ctx, time.Now().AddDate(0, 0, -1)); err != nil {
				logger.Errorf(ctx, "InitUserNotify.DoTask: %v", err)
				// 五分钟后重试
				ctrl.ticker.Reset(time.Minute * 5)
				return
			}

			ctrl.today = false
			ctrl.ticker.Reset(ctrl.calcIntervalTime())
		})

	})
}

type userNotifyControl struct {
	TickerExecute
	PageControl
	write, read *dao.ManagerDB
	ContentMng  *content_mng.ContentMng
}

func newUserNotifyControl(write, read *dao.ManagerDB, contentMng content_mng.IContentMng) *userNotifyControl {
	// 每天20点执行
	ctrl := &userNotifyControl{}
	ctrl.DefaultPage()
	ctrl.today = true
	ctrl.hour = 20
	ctrl.minter = 0
	ctrl.write = write
	ctrl.read = read
	ctrl.ContentMng = contentMng.(*content_mng.ContentMng)
	return ctrl
}

func (l *userNotifyControl) once() {
	for i := 1; i > 0; i-- {
		ctx := requestid.WithRequestID(context.Background())
		now := time.Now()
		target := now.AddDate(0, 0, -i)
		if err := l.DoTask(ctx, target); err != nil {
			logger.Error(context.Background(), "InitMemberSum:", err)
		}
		//break
	}
}

func (l *userNotifyControl) DoTask(ctx context.Context, targetTime time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	var versionTime int64 = 1698768000000 // 2023-11-01 00:00:00
	lastDay15 := l.calcZeroTimeByDay(targetTime, -15).UnixMilli()
	var gTime int64 = 0
	if versionTime >= lastDay15 {
		gTime = versionTime
	} else {
		gTime = lastDay15
	}

	if err := l.PageTurning(func() (bool, error) {
		opt := l.GetMongoPage()
		filter := map[string]interface{}{
			"is_new": 1,
			"create_time": bson.D{
				{"$gte", gTime},
			},
			//"user_id": 4461762751496192,
		}

		userDailies, err := l.read.SecretUserActivityDaily.FindAll(ctx, filter, opt)
		if err != nil {
			return false, err
		}

		if len(userDailies) == 0 {
			return false, nil
		}

		if err := l.notifyUser(ctx, userDailies); err != nil {
			return false, err
		}

		return true, nil
	}); err != nil {
		logger.Error(ctx, "PageTurning: ", err)
		return err
	}

	logger.Info(context.Background(), "通知当天8点前未发布动态且还能领取发帖红包奖励的用户")
	return nil
}

func (l *userNotifyControl) notifyUser(ctx context.Context, userDailies []model.SecretUserActivityDaily) error {
	userIds := make([]int64, 0)
	for _, daily := range userDailies {
		filter := map[string]interface{}{
			"user_id": daily.UserId,
			"type":    model.FirstWorkSettlement,
		}
		count, err := l.read.SuperiorContentAwardDetail.Count(ctx, filter)
		if err != nil {
			return err
		}

		switch daily.Gender {
		case model.SexBoy:
			if count == 0 {
				userIds = append(userIds, daily.UserId)

			}
		case model.SexGirl:
			if count < 4 {
				userIds = append(userIds, daily.UserId)

			}
		}
	}

	if len(userIds) == 0 {
		logger.Info(ctx, "没有满足发奖励通知的用户")
		return nil
	}

	title := "您有一个现金红包待领取！"
	content := "分享动态立得现金奖励～冲冲冲！"
	fromId := config.ServerConfig.CommentConfig.OfficialAccount

	logger.Infof(ctx, "本次推送账号：%v", userIds)
	err := l.ContentMng.KafkaProxy.TsnPushOfficeMessage(ctx, -1, fromId, userIds, title, "", content, "")
	if err != nil {
		logger.Error(ctx, "SendNotifyMsg", err)
	}

	return nil
}
