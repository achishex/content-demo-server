package sum_manage

import (
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/utils"
	"context"
	"time"
)

type Member struct {
	ManagerDB, ManagerOnlyReadDB *dao.ManagerDB
}

func (s *Member) UserMember(ctx context.Context, createTime string) ([]model.UserMemberStatistical, error) {
	var memberTable = map[int64]model.UserMemberStatistical{}

	orders, err := s.ManagerOnlyReadDB.OrderInfo.WithContext(ctx).Where(
		//l.read.OrderInfo.AppType.In("mobile-ios", "mobile-android"),
		s.ManagerOnlyReadDB.OrderInfo.Type.Eq(1001),
		s.ManagerOnlyReadDB.OrderInfo.OrderStatus.Eq(3),
		s.ManagerOnlyReadDB.OrderInfo.CreateTime.Gte(createTime),
	).Find()

	//orders, err := s.ManagerOnlyReadDB.OrderInfo.FindAll(ctx, 0, 0, where)
	if err != nil {
		return nil, err
	}

	if len(orders) == 0 {
		return nil, nil
	}

	for _, order := range orders {
		createTime, err := time.Parse("2006-01-02 15:04:05", order.CreateTime)
		if err != nil {
			return nil, err
		}
		zero := utils.ZeroTime(createTime).UnixMilli()
		var data model.UserMemberStatistical
		if value, exist := memberTable[zero]; exist {
			data = value
		}

		data.Day = zero
		price := uint(order.Price)
		switch order.AppType {
		case "applet-qq":
			data.QQSum += price
		case "applet-wx":
			data.WeiXinSum += price
		case "mobile-android":
			data.AndroidSum += price
		case "mobile-ios":
			data.IosSum += price
		default:
			data.UnknownSum += price
			continue
		}

		data.PriceSum += price
		memberTable[zero] = data
	}

	result := make([]model.UserMemberStatistical, 0)
	for _, statistical := range memberTable {
		result = append(result, statistical)
	}

	return result, nil

}
