package content_mng

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"github.com/kevwan/mapreduce/v2"
)

func (p *ContentMng) NewGetShare(ctx context.Context, loginUserId int64, data []*pbapi.PersonalBottleWorksSimple) ([]*pbapi.PersonalBottleWorksSimple, error) {

	var (
		err     error
		bgImage string
	)

	bgImage, err = p.GetBackgroundWithWork(ctx)
	if err != nil {
		logger.Error(ctx, "GetBackgroundWithWork", err)
	}

	for i := 0; i < len(data); i++ {
		workInfos, err := p.DataCache.GetWorkInfoToNewCommentCount(ctx, data[i].GetId())
		if err != nil {
			logger.Error(ctx, "GetWorkInfoToNewCommentCount: ", err)
			continue
		}
		for _, wi := range workInfos {
			var (
				remarkName string
				talkMode   int32
			)

			if err := mapreduce.Finish(func() error {
				remarkName, err = p.DataCache.GetUserRemarkOne(ctx, loginUserId, data[i].UserInfo.GetUserId())
				return err
			}, func() error {
				talkMode = p.GetUserInfoTalkMode(ctx, data[i].UserInfo.GetUserId())
				return nil
			}); err != nil {
				logger.Error(ctx, "GetUserRemarkOne: ", err)
				continue
			}
			//fmt.Println(loginUserId, data[i].UserInfo.GetUserId())
			data[i].NewCommentCount = wi.NewCommentCount
			data[i].BgImage = &bgImage
			data[i].UserInfo.RemarkName = remarkName
			data[i].UserInfo.TalkMode = talkMode
		}
	}

	return data, nil

}
