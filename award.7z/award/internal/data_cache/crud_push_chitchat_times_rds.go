package data_cache

import (
	"content_svr/internal/busi_comm/cache_const"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	rdsV8 "github.com/go-redis/redis/v8"
	"time"
)

func (p *DataCacheMng) GetPushChitchatTimes(ctx context.Context, userId int64) int {
	DateStr := utils.GetCurDate()
	redisKey := fmt.Sprintf(cache_const.PushChitchatTimesRcache.KeyFmt, DateStr, userId) // workid~calcScore
	ret, err := p.RedisCli.Get(ctx, redisKey).Int()                                      //返回在range的idx位置
	if err != nil {
		if err != rdsV8.Nil {
			logger.Error(ctx, "GetPushChitchatTimesKey failed. ", err)
		}
		return 0
	}
	return ret
}

func (p *DataCacheMng) SetPushChitchatTimes(ctx context.Context, userId int64) (int, error) {
	DateStr := utils.GetCurDate()
	redisKey := fmt.Sprintf(cache_const.PushChitchatTimesRcache.KeyFmt, DateStr, userId) // workid~calcScore

	ret, err := p.RedisCli.IncrBy(ctx, redisKey, 1).Uint64()
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SetPushChitchatTimesKey failed. redisKey=%v", redisKey), err)
		return 0, err
	}
	err = p.RedisCli.Expire(ctx, redisKey, time.Second*time.Duration(utils.SecondsUntilEndOfToday())).Err()
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SetPushChitchatTimesKey failed. redisKey=%v", redisKey), err)
		return 0, err
	}
	return int(ret), nil
}
