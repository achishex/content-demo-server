package job

import (
	"content_svr/internal/content_mng"
	"content_svr/pub/logger"
	"content_svr/setting"
	"context"
	"fmt"
	"time"
)

func TimerSportFish(dataOp content_mng.IContentMng) error {
	now := time.Now()
	activityNums := getActivityNums(now)
	if ok := updateSportStatus(dataOp, activityNums); ok {
		// 成功操作定时器后，更新下一次可定时器执行时间
		logger.Info(context.Background(), fmt.Sprintf("已开奖%d", activityNums))
	} else {
		logger.Error(context.Background(), fmt.Sprintf("开奖失败: 本期应该开奖 %d", activityNums), nil)
	}

	return nil
}

func getActivityNums(date time.Time) int64 {
	return time.Date(date.Year(), date.Month(), date.Day(),
		setting.Maozhua.FishSport.ActivityOpenHour.Get(), setting.Maozhua.FishSport.ActivityOpenMinute.Get(),
		date.Second(), 0, date.Location()).Add(-time.Hour * 24).UnixMilli()
}

func updateSportStatus(dataOp content_mng.IContentMng, activityNums int64) bool {
	totalFishNums, totalStepNums, totalUserNums, err := dataOp.QueryTotalFishAndStepNums(context.Background(), activityNums)
	logger.Infof(context.Background(),
		"begin to load total fish and user nums, now: %v, total fish nums: %v, total step num: %v",
		time.Now(), totalFishNums, totalStepNums)
	if err != nil {
		logger.Error(context.Background(), "QueryTotalFishAndStepNums error:", err)
		return false
	}
	if totalUserNums == 0 {
		// 没人任何人参加
		return true
	}

	err = dataOp.UpdateFishNumsForAllUser(context.Background(), activityNums, totalFishNums, totalStepNums, totalUserNums)
	if err != nil {
		logger.Error(context.Background(), "UpdateFishNumsForAllUser error:", err)
		return false
	}

	return true
}
