package content_mng

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"context"
	"github.com/gogo/protobuf/proto"
	"time"
)

type IRemindCommentProc interface {
	WriteRemind(ctx context.Context, header *pbapi.HttpHeaderInfo) (int64, error)
	ReadRemind(ctx context.Context) ([]*pbmgdb.UserRemindDetailMgDbModel, error)
}
type RemindCommentProcess struct {
	//write items:
	commentId   int64
	req         *pbapi.WorkCommentPushReq
	impl        *ContentMng
	workInfo    *pbapi.PersonalBottleWorksDbModel
	commentUser *data_cache.UserInfoLocal
	//read items:
	workId  *int64
	msgType int32
}

func NewRemindOpsWriteHandle(commentId int64, req *pbapi.WorkCommentPushReq,
	imp *ContentMng, workInfo *pbapi.PersonalBottleWorksDbModel,
	commentUser *data_cache.UserInfoLocal) IRemindCommentProc {
	return &RemindCommentProcess{
		commentId:   commentId,
		req:         req,
		impl:        imp,
		workInfo:    workInfo,
		commentUser: commentUser,
	}
}

func (p *RemindCommentProcess) WriteRemind(ctx context.Context, header *pbapi.HttpHeaderInfo) (int64, error) {
	if p == nil || p.commentId <= 0 || p.req == nil {
		return 0, nil
	}
	if len(p.req.RemindNode) <= 0 {
		return 0, nil
	}
	var workObjAttr *pbapi.WorkObjectAttrDbModel = nil
	var workObj []*pbapi.WorkObjectAttrRequest = nil
	if p.workInfo.GetType() == const_busi.WorkTypeImage {
		workIdList := []int64{p.workInfo.GetId()}
		ret, err := p.impl.DataCache.GetImpl().WorkObjectAttrModel.DictByWorkIds(ctx, workIdList)
		if err == nil {
			if obj, ok := ret[p.workInfo.GetId()]; ok {
				if len(obj) > 0 {
					workObjAttr = obj[0]
					workObj = append(workObj, &pbapi.WorkObjectAttrRequest{
						Type:      workObjAttr.Type,
						Width:     workObjAttr.Width,
						High:      workObjAttr.High,
						ObjectId:  workObjAttr.ObjectId,
						Thumbnail: workObjAttr.Thumbnail,
						ImgMd5:    workObjAttr.ImgMd5,
					})
				}
			}
		}
	}

	msgType := pbconst.MessageTypeEnum_msg_type_remind_comment
	for i := 0; i < len(p.req.RemindNode); i++ {
		if p.req.RemindNode[i] == nil {
			continue
		}
		commentRemindItem := &pbmgdb.UserRemindDetailMgDbModel{
			Id:            snow_flake.GetSnowflakeID(),
			WorkId:        proto.Int64(p.req.GetWorkId()),
			WorkUserId:    proto.Int64(p.workInfo.GetUserId()),
			RemindUserId:  proto.Int64(p.req.RemindNode[i].GetUserId()),
			RemindOffSet:  proto.Int32(p.req.RemindNode[i].GetOffSet()),
			RemindType:    proto.Int32(const_busi.CommentRemindType),
			CommentUserId: proto.Int64(p.commentUser.UserInfoDbModel.GetUserId()),
			CreateTime:    proto.Int64(time.Now().UnixMilli()),
			CommentId:     proto.Int64(p.commentId),
			RemindSize:    proto.Int32(p.req.RemindNode[i].GetSize()),
		}
		if err := p.impl.DataCache.GetImpl().UserRemindDetail.Insert(ctx, commentRemindItem); err != nil {
			logger.Errorf(ctx, "work: %v, user: %v, comment_id: %v, insert comment remind fail, err: %v",
				p.req.GetWorkId(), p.commentUser.UserInfoDbModel.GetUserId(), p.commentId)
			return -1, errorcode.GenBusiErr(errorcode.BusinessError, "insert comment remind to tab fail")
		}

		workRemindInfo := &WorkRemindInfo{
			curUserInfo: p.commentUser,
			toUserId:    p.req.RemindNode[i].GetUserId(),
			work:        p.workInfo,
			workObj:     workObj,
			reqClientId: nil,
			coordinate:  nil,
			msgType:     int32(msgType),
			remindId:    commentRemindItem.GetId(),
			commentId:   p.commentId,
			header:      header,
		}
		p.impl.UpdateMsgAndNotice(ctx, workRemindInfo)
	}

	return 0, nil
}

func NewRemindOpsReadHandle(imp *ContentMng, workId, commentId *int64, msgType int32) IRemindCommentProc {
	return &RemindCommentProcess{
		workId:    workId,
		commentId: *commentId,
		msgType:   msgType,
		impl:      imp,
	}
}

func (p *RemindCommentProcess) ReadRemind(ctx context.Context) ([]*pbmgdb.UserRemindDetailMgDbModel, error) {
	if p.impl == nil || p.workId == nil || p.commentId <= 0 {
		return nil, nil
	}
	//
	eqConds := map[string]interface{}{
		"workId":     *p.workId,
		"commentId":  p.commentId,
		"remindType": p.msgType,
	}
	retData, err := p.impl.DataCache.GetImpl().UserRemindDetail.GetRemindDetailByConds(ctx, eqConds, nil, nil, nil, 0)
	if err != nil {
		logger.Errorf(ctx, "get remind info fail, workid: %v, commentid: %v, err: %v",
			*p.workId, p.commentId, err)
		return nil, err
	}
	return retData, nil
}

//
