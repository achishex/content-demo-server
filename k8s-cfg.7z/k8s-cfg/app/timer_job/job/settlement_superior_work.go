package job

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/pub/logger"
	"context"
	"math"
	"time"
)

//读取延迟队列（截止到当前时间段），
//如果没有，则获取近的一条记录，更新定时器时间继续等待一段固定时间，
//存在需要处理的获取workId, 通过workId 获取有效评论人数，计算评论人数的金额，写入到 已结算的表中。
// 找到最新的一条记录userId，获取userTotalAward, 计算新记录，插入新记录： userTotalAward +/-当前的值。
// 已结算表包括：id, workUserId, workId, settlementType, settlementAward, createTime, userTotalAward
//并核算每个用户的总金额数,并更新。
//删除延迟队列元素，删除用户等待结算的队列元素。

type KoLaPlanSettlement struct {
	ctx       context.Context
	startTime time.Time
	cfg       *config.SuperiorContentConfig
	mng       data_cache.IDataCacheMng
	ticker    *time.Ticker

	isTimerOrNotify bool // false: timer, true: notify
}

func NewKoLaPlanSettlement(dataOp data_cache.IDataCacheMng, cfg *config.SuperiorContentConfig) *KoLaPlanSettlement {
	return &KoLaPlanSettlement{
		ctx:       context.Background(),
		startTime: time.Now(),
		cfg:       cfg,
		mng:       dataOp,
	}
}

func (p *KoLaPlanSettlement) GetAllItems(ctx context.Context) ([]int64, time.Duration) {
	duration := time.Duration(p.cfg.TimerSettlementSecond) * time.Second
	workIds, err := content_mng.NewDelayQueue(p.mng.GetImpl().RedisCli).QueryAllItems(p.ctx, content_mng.GetSuperiorContentQueueKey())
	if err != nil {
		logger.Errorf(ctx, "get works id from delay queue fail, err: %v, key: %v", err, content_mng.GetSuperiorContentQueueKey())
		return nil, duration
	}
	if len(workIds) <= 0 {
		//logger.Infof(ctx, "not get any item, key: %v", content_mng.GetSuperiorContentQueueKey())
	} else {
		logger.Infof(ctx, "recv works: %v, nowTime: %v", workIds, time.Now())
	}
	return workIds, duration
}
func (p *KoLaPlanSettlement) GetNextTimerVal(ctx context.Context) ([]int64, time.Duration) {
	duration := time.Duration(p.cfg.TimerSettlementSecond) * time.Second
	//
	timeNow := time.Now()
	workIds, err := content_mng.NewDelayQueue(p.mng.GetImpl().RedisCli).QueryItemsByTimeCond(p.ctx, 0, timeNow.UnixMilli(), content_mng.GetSuperiorContentQueueKey())
	if len(workIds) <= 0 && err == nil {
		workId, createTmMill, err := content_mng.NewDelayQueue(p.mng.GetImpl().RedisCli).QueryItemLatest(p.ctx, content_mng.GetSuperiorContentQueueKey())
		if workId > 0 && createTmMill > 0 && err == nil {
			duration = time.UnixMilli(createTmMill).Sub(timeNow)
			logger.Infof(ctx, "KoLaPlanSettlement, next timer dur: %v", duration)
		}
	}
	if err != nil {
		logger.Errorf(p.ctx, "use default timer time, query need settlement node fail, err: %v", err)
	}
	if p.isTimerOrNotify {
		logger.Infof(ctx, "recv notify, get ids: %v", workIds)
	}

	return workIds, duration
}
func (p *KoLaPlanSettlement) LoopOnce(dur int32) {
	workIds, d := p.GetNextTimerVal(p.ctx)
	p.DoSettlement(workIds)
	if d != time.Duration(dur)*time.Second && d > 0 {
		p.ticker.Reset(d)
	}
}

func (p *KoLaPlanSettlement) LoopOnceGetAll(dur int32) {
	workIds, d := p.GetAllItems(p.ctx)
	p.DoSettlementImmediately(workIds)
	if d != time.Duration(dur)*time.Second && d > 0 {
		p.ticker.Reset(d)
	}
}
func (p *KoLaPlanSettlement) TimerSettlement() {
	go func() {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf(p.ctx, "catch err: %v", e)
				return
			}
		}()

		p.ticker = time.NewTicker(time.Duration(p.cfg.TimerSettlementSecond) * time.Second)

		waitNotify := content_mng.NewDelayQueue(p.mng.GetImpl().RedisCli).WaitNotify(context.Background())
		if waitNotify == nil {
			logger.Errorf(p.ctx, "wait channel is nil")
			return
		}
		for {
			select {
			case <-p.ticker.C:
				p.isTimerOrNotify = false
				p.LoopOnceGetAll(p.cfg.TimerSettlementSecond)

			case <-waitNotify:
				logger.Infof(context.Background(), "receive delay queue new item notify on KoLaPlanSettlement")
				p.isTimerOrNotify = true
				p.LoopOnceGetAll(p.cfg.TimerSettlementSecond)
			}
		}
	}()
}

func (p *KoLaPlanSettlement) DoSettlementImmediately(workIds []int64) {
	if len(workIds) <= 0 {
		return
	}
	mngInstance := &content_mng.ContentMng{
		DataCache: p.mng,
	}
	for k, _ := range workIds {
		workInfo, err := p.mng.GetWorkInfoLocal(p.ctx, workIds[k], false)
		if err != nil {
			logger.Errorf(p.ctx, "get work info fail, err: %v, workId: %v", err, workIds[k])
			continue
		}
		commentUserNums, err := content_mng.NewSuperiorContentInstance(mngInstance, workInfo.WorkInfoDbModel, 0).GetValidCommentUserNums(p.ctx, workIds[k])
		if err != nil {
			logger.Errorf(p.ctx, "calc valid comment user nums fail, err: %v, workId: %v", err, workIds[k])
			continue
		}
		award, err := content_mng.NewSuperiorContentInstance(mngInstance, workInfo.WorkInfoDbModel, 0).CalcPreAward(p.ctx, int32(commentUserNums))
		if err != nil {
			logger.Errorf(p.ctx, "calc award fail, commentUserNums: %v, workId: %v, err: %v", commentUserNums, workIds[k], err)
			continue
		}

		var needDo bool = true
		if awardList, err := content_mng.NewSuperiorContentInstance(mngInstance, workInfo.WorkInfoDbModel, 0).GetSuperiorContentItemOnWork(p.ctx, workIds[k]); err != nil {
			logger.Errorf(p.ctx, "get award list fail on work: %v, err: %v", workIds[k], err, err)
			continue
		} else {
			for i, _ := range awardList {
				if awardList[i] == nil {
					continue
				}
				//
				if awardList[i].GetSettlementType() == const_busi.AWardSettlement && math.Abs(award-awardList[i].GetAward()) <= 0.0001 {
					needDo = false
					break
				}
			}
		}

		if needDo == false {
			content_mng.NewSuperiorContentInstance(mngInstance, workInfo.WorkInfoDbModel, 0).DelHasSettlementItem(p.ctx, workIds[k], workInfo.WorkInfoDbModel.GetUserId())
			continue
		}

		err = content_mng.NewSuperiorContentInstance(mngInstance, nil, 0).WriteNewItem(p.ctx, workIds[k], workInfo.WorkInfoDbModel.GetUserId(),
			workInfo.WorkInfoDbModel.GetTitle(), award, const_busi.AWardSettlement)
		if err != nil {
			logger.Errorf(p.ctx, "insert new item to db fail, err: %v", err)
			continue
		}
		//更新到总表中...

		// 清除已经处理的。
		content_mng.NewSuperiorContentInstance(mngInstance, workInfo.WorkInfoDbModel, 0).DelHasSettlementItem(p.ctx, workIds[k], workInfo.WorkInfoDbModel.GetUserId())
	}

}

func (p *KoLaPlanSettlement) DoSettlement(workIds []int64) {
	if len(workIds) <= 0 {
		return
	}
	mngInstance := &content_mng.ContentMng{
		DataCache: p.mng,
	}
	for k, _ := range workIds {
		workInfo, err := p.mng.GetWorkInfoLocal(p.ctx, workIds[k], false)
		if err != nil {
			logger.Errorf(p.ctx, "get work info fail, err: %v, workId: %v", err, workIds[k])
			continue
		}
		commentUserNums, err := content_mng.NewSuperiorContentInstance(mngInstance, workInfo.WorkInfoDbModel, 0).GetValidCommentUserNums(p.ctx, workIds[k])
		if err != nil {
			logger.Errorf(p.ctx, "calc valid comment user nums fail, err: %v, workId: %v", err, workIds[k])
			continue
		}
		award, err := content_mng.NewSuperiorContentInstance(mngInstance, workInfo.WorkInfoDbModel, 0).CalcPreAward(p.ctx, int32(commentUserNums))
		if err != nil {
			logger.Errorf(p.ctx, "calc award fail, commentUserNums: %v, workId: %v, err: %v", commentUserNums, workIds[k], err)
			continue
		}

		//// 查找work的UserId 最新的一条记录
		//totalAwardRet, err := mngInstance.GetTotalAwardOnUser(p.ctx, workInfo.WorkInfoDbModel.GetUserId())
		//if err != nil {
		//	logger.Errorf(p.ctx, "get latest award fail, userId: %v, err: %v", workInfo.WorkInfoDbModel.GetUserId(), err)
		//	continue
		//}
		//totalAward := award
		//if totalAwardRet > 0.0001 {
		//	totalAward += totalAwardRet
		//}
		////
		//newAwardItem := &pbmgdb.SuperiorContentAwardDetail{
		//	Id:             snow_flake.GetSnowflakeID(),
		//	WorkId:         proto.Int64(workIds[k]),
		//	UserId:         proto.Int64(workInfo.WorkInfoDbModel.GetUserId()),
		//	SettlementType: proto.Int32(const_busi.AWardSettlement),
		//	Award:          proto.Float64(award),
		//	CreatTime:      proto.Int64(time.Now().UnixMilli()),
		//	TotalAward:     proto.Float64(totalAward),
		//	WorkContent:    proto.String(workInfo.WorkInfoDbModel.GetTitle()),
		//}
		//// 包括记录本次新增记录，本次动态得分在缓存中的值。
		//err = content_mng.NewSuperiorContentInstance(mngInstance, workInfo.WorkInfoDbModel, 0).AddNewItemAwardRecord(p.ctx, newAwardItem)

		err = content_mng.NewSuperiorContentInstance(mngInstance, nil, 0).WriteNewItem(p.ctx, workIds[k], workInfo.WorkInfoDbModel.GetUserId(),
			workInfo.WorkInfoDbModel.GetTitle(), award, const_busi.AWardSettlement)
		if err != nil {
			logger.Errorf(p.ctx, "insert new item to db fail, err: %v", err)
			continue
		}
		//更新到总表中...

		// 清除已经处理的。
		content_mng.NewSuperiorContentInstance(mngInstance, workInfo.WorkInfoDbModel, 0).DelHasSettlementItem(p.ctx, workIds[k], workInfo.WorkInfoDbModel.GetUserId())
	}

}

//

type KoLaHallOfFameSettlement struct {
	ctx       context.Context
	startTime time.Time
	cfg       *config.KoLaHallOfFameConfig
	mng       data_cache.IDataCacheMng
	ticker    *time.Ticker
}

func NewKoLaHallOfFameSettlement(dataOp data_cache.IDataCacheMng, cfg *config.KoLaHallOfFameConfig) *KoLaHallOfFameSettlement {
	return &KoLaHallOfFameSettlement{
		ctx:       context.Background(),
		startTime: time.Now(),
		cfg:       cfg,
		mng:       dataOp,
	}
}

func (p *KoLaHallOfFameSettlement) DoTask() {
	go func() {
		defer func() {
			if e := recover(); e != nil {
				logger.Errorf(p.ctx, "catch err: %v", e)
				return
			}
		}()

		doLogicHande := content_mng.NewSettleKolaHallOfFameInstance(&content_mng.ContentMng{DataCache: p.mng})
		toExpireSecond, err := doLogicHande.CheckSettlementIsReady(p.ctx, p.cfg)
		tickTimeSecond := int32(5)

		if err == nil && toExpireSecond > 0 {
			tickTimeSecond = toExpireSecond
			logger.Infof(p.ctx, "need to wait: %v second", toExpireSecond)
		}
		if err != nil {
			logger.Errorf(p.ctx, "check settlement is ready fail, err: %v", err)
		}

		p.ticker = time.NewTicker(time.Duration(tickTimeSecond) * time.Second)

		for {
			select {
			case <-p.ticker.C:
				p.settlementDoLogic(p.ctx, doLogicHande)

				nextDur, err := p.CalcNextRunTimeDuration(p.ctx)
				if err != nil || nextDur <= 0 {
					p.ticker.Reset(5 * time.Second)

				} else {
					logger.Infof(p.ctx, "wait %v second to run timer calc", nextDur)
					p.ticker.Reset(time.Duration(nextDur) * time.Second)
				}
			}
		}
	}()
}

func (p *KoLaHallOfFameSettlement) CalcNextRunTimeDuration(ctx context.Context) (int32, error) {

	defaultEndHourMinute := "23:30"
	if p.cfg != nil && len(p.cfg.SettlementEndTime) > 0 {
		defaultEndHourMinute = p.cfg.SettlementEndTime
		logger.Infof(ctx, "use cfg settlement time: %v", defaultEndHourMinute)
	} else {
		logger.Infof(ctx, "user default end time: %v", defaultEndHourMinute)
	}

	cfgEndTime, err := time.Parse("15:04", defaultEndHourMinute)
	if err != nil {
		logger.Errorf(ctx, "parse time: %v fail, err: %v", defaultEndHourMinute, err)
		return 0, err
	}
	logger.Infof(ctx, "parse time hour: %v, minute: %v", cfgEndTime.Hour(), cfgEndTime.Minute())

	nowTime := time.Now()
	toExpireTime := int32(0)
	if (cfgEndTime.Hour() > nowTime.Hour()) || (cfgEndTime.Hour() == nowTime.Hour() && cfgEndTime.Minute() >= nowTime.Minute()) {
		toExpireTime = int32(time.Date(nowTime.Year(), nowTime.Month(), nowTime.Day(), cfgEndTime.Hour(), cfgEndTime.Minute(), 0, 0, time.Local).Sub(nowTime) / time.Second)
		logger.Infof(ctx, "task to ready need to wait for: %v second", toExpireTime)

	} else {
		toExpireTime = int32(time.Date(nowTime.Year(), nowTime.Month(), nowTime.Day()+1, cfgEndTime.Hour(), cfgEndTime.Minute(), 0, 0, time.Local).Sub(nowTime) / time.Second)
		logger.Infof(ctx, "task to ready need to wait for: %v second", toExpireTime)
	}

	return toExpireTime, nil
}

func (p *KoLaHallOfFameSettlement) settlementDoLogic(ctx context.Context, hallOfFameHande content_mng.IKoLaHallOfFame) {
	hallOfFameHande.DoSettlementOnHallOfFame(ctx)
}
