package middleware

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/pub/errors"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"github.com/gin-gonic/gin"
	"strconv"
	"strings"
	"time"
)

func ApiWhiteList(conf config.Config) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		list := conf.ApiWhiteListConfig
		if len(list) == 0 {
			return
		}

		uid := strconv.FormatInt(GetUserID(ctx), 10)
		uri := ctx.Request.RequestURI

		var (
			uidStr string
			ok     bool
		)

		if uidStr, ok = config.ServerConfig.ApiWhiteListConfig[uri]; !ok {
			return
		}

		uidList := strings.Split(strings.ReplaceAll(strings.Trim(uidStr, " "), "，", ","), ",")
		for _, u := range uidList {
			if u == uid {
				return
			}
		}

		result := errors.CliError{
			Message:   errorcode.INSUFFICIENT_PERMISSION.ErrMsg,
			MessageId: utils.GetLocalIp() + "_" + requestid.GetRequestID(ctx),
			Status:    errorcode.INSUFFICIENT_PERMISSION.UserErrCode,
			Timestamp: time.Now().UnixNano() / 1e6,
			CostTime:  0,
		}
		ctx.AbortWithStatusJSON(200, result)
	}
}
