package utils

import (
	"crypto/rc4"
)

const (
	RC4Key = "T5vS+Y&G11=9eJYeEw2dpt=42>&O]>J8"
)

func RC4(in []byte) []byte {
	if len(in) == 0 {
		return in
	}

	out := make([]byte, len(in))

	c, _ := rc4.NewCipher([]byte(RC4Key))
	c.XORKeyStream(out, in)
	return out
}
