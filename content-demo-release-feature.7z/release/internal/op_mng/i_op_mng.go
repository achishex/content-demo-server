package op_mng

import (
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbadmin"
	"context"
)

type OpMng struct {
	DataCache data_cache.IDataCacheMng
}

type IOpMng interface {
	LoginIn(ctx context.Context, req *pbadmin.OpLoginInReq) (*pbadmin.OpLoginInResp, error)
	OpInfo(ctx context.Context) (*pbadmin.OpInfo, error)
	OpList(ctx context.Context, req *pbadmin.OpInfoListReq) (*pbadmin.OpInfoListResp, error)
	OpAdd(ctx context.Context, req *pbadmin.OpAddReq) error
	OpInfoUpdate(ctx context.Context, req *pbadmin.OpInfoUpdateReq) error
}

func NewOpMng(
	dataCache data_cache.IDataCacheMng) IOpMng {
	return &OpMng{
		DataCache: dataCache,
	}
}
