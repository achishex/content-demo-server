package content_mng

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

func (p *ContentMng) Debug(ctx context.Context) error {

	return nil
}

func (p *ContentMng) DebugAddToDeliver(ctx context.Context, req *pbapi.DebugUserIdReq) error {
	//加入到分发池子
	err := p.DataCache.AddToTsWorkPoolRedis(ctx, req.GetUserId())
	if err != nil {
		logger.Errorf(ctx, "add work to tsPool failed.", err)
		return err
	}
	logger.Infof(ctx, "add id=%v to fenfa suc", req.GetUserId())
	return nil
}

func (p *ContentMng) DebugFirstAward(ctx context.Context, work *pbapi.DebugWork) error {

	query := map[string]interface{}{
		"id": work.GetWorkId(),
	}
	update := map[string]interface{}{
		"create_time": time.UnixMilli(work.GetCreateTime()).Format("2006-01-02 15:04:05"),
	}
	if err := p.DataCache.GetImpl().PersonBottleWorksModel.Update(ctx, query, update); err != nil {
		return err
	}

	filter := bson.D{
		{"type", 3},
		{"work_id", work.GetWorkId()},
	}
	data := bson.D{
		{"$set", bson.D{
			{"create_time", work.GetCreateTime()},
		}},
	}
	if _, err := p.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.Update(ctx, filter, data); err != nil {
		return err
	}

	return nil
}
