package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/busi_comm/version"
	"content_svr/internal/data_cache"
	"content_svr/internal/im_mng"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"content_svr/setting"
	"context"
	"encoding/json"
	"fmt"
	"github.com/golang/protobuf/proto"
	"github.com/samber/lo"
	"go.mongodb.org/mongo-driver/bson"
	"strconv"
	"time"
)

// return bSwallow
func (p *ContentMng) PushChitchatParamCheck(ctx context.Context, header *pbapi.HttpHeaderInfo,
	req *pbapi.PushChitchatReq, curUserInfo *data_cache.UserInfoLocal) (bool, error) {
	bSwallow := true
	userId := curUserInfo.UserInfoDbModel.GetUserId()
	//if curUserInfo.UserInfoDbModel.GetWorksLock() != 1 { //作品发布锁定，1:启用，2:限时封禁，3:永久封禁
	//	logger.Infof(ctx, "skip,user work lock=%v", curUserInfo.UserInfoDbModel.GetWorksLock())
	//	return bSwallow, nil
	//}

	// 检查模块维度，是否被封禁 . Integer type, Integer module, Long userId
	//if p.DataCache.CheckByTypeAndModule(ctx, 2, 1, curUserInfo.UserInfoDbModel.GetUserId()) {
	//	logger.Infof(ctx, "skip,user Module lock")
	//	return bSwallow, nil
	//}

	// 检查能否发布系统卡片发布。 eg 星座卡片。
	if req.GetSystemWorkId() == cm_const.SystemWorkIdXingzuo {
		if !utils.CheckAppVer(header.Apptype, header.Versioncode, cm_const.SystemWorkIdXingzuo) {
			logger.Infof(ctx, "have no right to push xingzuo card.")
			return bSwallow, errorcode.GenBusiErr(errorcode.BusinessError, "暂无权限")
		}
		isPublished := p.DataCache.GetUserSystemWorkPublishFlagRds(ctx, userId, cm_const.SystemWorkIdXingzuo)
		if isPublished {
			return bSwallow, errorcode.GenBusiErr(errorcode.BusinessError, "今日已爪，明天再来吧～")
		}
		return false, nil //检查成功，不吞内容。
	}

	// 检查唠唠发布权限 小黑屋、间隔时间、等级
	err := p.checkPush(ctx, header, curUserInfo)
	if err != nil {
		logger.Infof(ctx, "check push failed.  err=%v", err)
		return bSwallow, err
	}

	switch req.Type {
	case const_busi.WorkTypeText:
		break
	case const_busi.WorkTypeImage:
		// 低版本的不允许发带图帖子。
		if header.Versioncode < version.WorkPictureVersion {
			logger.Infof(ctx, "skip, push img with low version")
			return bSwallow, nil
		}

		switch req.GetSubType() {
		case const_busi.WorkSubTypeUnknown:
			// 旧版没区分相册还是相机类型，不判断等级
			if header.Versioncode < version.SuperiorContentAwardVersion {
				break
			}
		case const_busi.WorkSubTypeCamera:
			break
		case const_busi.WorkSubTypePhoto, const_busi.WorkSubTypeEmote:
			// 需要判断是否为5级用户
			if curUserInfo.PsecretUserExtInfo.GetUlevel() != const_level.UserMaxLevel {
				return bSwallow, nil
			}
		default:
			return bSwallow, nil
		}
	}

	// 检查手机号绑定
	permission := curUserInfo.UserPermission
	if permission&data_cache.UserPermissionConst.BindPhoneUnlimited == 0 {
		// 需要检查手机绑定
		if curUserInfo.UserInfoDbModel.GetPhone() == "" {
			return bSwallow, errorcode.GenBusiErr(errorcode.BusinessError, "请先验证手机号")
		}
	}

	//
	if req.Type == const_busi.WorkTypeText && req.GetTitle() == "" {
		return bSwallow, errorcode.GenBusiErr(errorcode.BusinessError, "内容不能为空")
	}

	return false, nil
}

// 返回 workid
func (p *ContentMng) PushChitchat(ctx context.Context, header *pbapi.HttpHeaderInfo,
	req *pbapi.PushChitchatReq) (int64, error) {

	curUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil {
		return 0, err
	}
	logAttr := make([]string, 0)
	userId := curUserInfo.UserInfoDbModel.GetUserId()
	defer func() {
		logger.Infof(ctx, "pushChitchat, curUserId=%v, logAttr=%v, err=%v", userId, logAttr, err)
	}()

	if curUserInfo.PsecretUserExtInfo == nil {
		mgModel, err := p.DataCache.GetImpl().UserInfoExtMgModel.GetAndCreate(ctx, curUserInfo.UserInfoDbModel.GetUserId())
		if err != nil {
			logger.Error(ctx, "push chitchat, GetAndCreate UserInfoExtMgModel failed", err)
			return 0, err
		}
		curUserInfo.PsecretUserExtInfo = mgModel
	}

	//VerifyStatus1 := p.checkTitle(ctx, userId, req.GetTitle()) // 检查用户维度，是否被封禁
	//print(VerifyStatus1)
	////////////
	if userId != cm_const.OfficialMZUserId {
		bSwallow, err := p.PushChitchatParamCheck(ctx, header, req, curUserInfo)
		if err != nil {
			// 日志，check failed
			logAttr = append(logAttr, fmt.Sprintf("ParamCheckfailed:%v", err.Error()))
			return 0, err
		}
		if bSwallow {
			logAttr = append(logAttr, "bSwallow")
			return 0, nil
		}
		logAttr = append(logAttr, "allow")
	}

	// 2023-06-29 新增逻辑，小程序男性都不允许发贴
	if utils.HasStringElement(header.Apptype, []string{cm_const.AppTypeAppletQq, cm_const.AppTypeAppletWx}) &&
		curUserInfo.UserInfoDbModel.GetGender() == int32(pbconst.Sex_male) {
		logAttr = append(logAttr, "male_applet_forbid_chitchat")
		return 0, errorcode.PleaseUseApp
	}

	//预生成workId，避免再次关联更新
	var preWorkId = snow_flake.GetSnowflakeID()

	// 检查
	VerifyStatus := int32(pbconst.WorkAuditResultEnum_war_pass)
	if config.ServerConfig.Env != "prod" && header.Debuguserid > 0 {
		VerifyStatus = int32(pbconst.WorkAuditResultEnum_war_pass)
	} else {
		VerifyStatus = p.checkWorkTitleAndImage(ctx, userId, req, preWorkId, curUserInfo.PsecretUserExtInfo.GetUlevel())

		if VerifyStatus == int32(pbconst.WorkAuditResultEnum_war_refuse) {
			if curUserInfo.PsecretUserExtInfo.GetUlevel() >= 5 {
				// qudingding 被拦截的动态 提示人工处理
				items := make([]utils.LarkMessageItem, 0)

				workItem := utils.LarkMessageItem{
					Tag:  "text",
					Text: fmt.Sprintf("workId：%d\n", preWorkId),
				}
				items = append(items, workItem)

				//userItem := utils.LarkMessageItem{
				//	Tag:  "text",
				//	Text: fmt.Sprintf("userId：%d\n", curUserInfo.UserInfoDbModel.GetUserId()),
				//}
				//items = append(items, userItem)

				titleItem := utils.LarkMessageItem{
					Tag:  "text",
					Text: fmt.Sprintf("title：%v\n", req.GetTitle()),
				}
				items = append(items, titleItem)

				//if len(req.GetWorkObjects()) > 0 {
				//	var imageUrl = config.ServerConfig.ImageHost + req.GetWorkObjects()[0].GetObjectId()
				//	//imageItem := utils.LarkMessageItem{
				//	//	Tag:      "img",
				//	//	ImageKey: fmt.Sprintf("动态图片：%v\n", imageUrl),
				//	//}
				//	imageItem := utils.LarkMessageItem{
				//		Tag:      "text",
				//		ImageKey: fmt.Sprintf("图片：%v\n", imageUrl),
				//	}
				//	items = append(items, imageItem)
				//}

				href := utils.LarkMessageItem{
					Tag:  "a",
					Text: "去处理",
					Href: fmt.Sprintf("https://mzadmin.52mengdong.com/#/devile/intercept?work_id=%d", preWorkId),
				}
				items = append(items, href)

				larkMessage := utils.LarkMessage{}
				larkMessage.MsgType = "post"
				larkMessage.Content.Post.ZhCn.Title = "5级用户被拦截的动态"
				larkMessage.Content.Post.ZhCn.Content = make([][]utils.LarkMessageItem, 0)
				larkMessage.Content.Post.ZhCn.Content = append(larkMessage.Content.Post.ZhCn.Content, items)

				utils.LarkSendMsg(utils.LarkWebhookUrlReportRelease, larkMessage)
			}
		}
	}

	// 构建work对象
	work, coordinate := p.buildWorks(ctx, header, curUserInfo, req, VerifyStatus, preWorkId)

	// 保存作品
	work, err = p.DataCache.GetImpl().PersonBottleWorksModel.CreateItem(ctx, work)
	if err != nil {
		return 0, errorcode.GenBusiErr(errorcode.BusinessError, "投递失败")
	}
	err = p.createPersonBottleWorksExtMgDbModel(ctx, header, req.GetType(), req.GetSubType(), work.GetId())
	if err != nil {
		return 0, errorcode.GenBusiErr(errorcode.BusinessError, "投递失败")
	}

	//设置redis status，showScope缓存
	if err := p.DataCache.SetWorkStatus(ctx, []int64{work.GetId()}, work.GetStatus()); err != nil {
		logger.Errorf(ctx, "PushChitchat: SetWorkShowScope. redis set error. workId: %v, status: %v, error: %v", work.Id, work.GetStatus(), err)
	}
	if err := p.DataCache.SetWorkShowScope(ctx, []int64{work.GetId()}, work.GetShowScope()); err != nil {
		logger.Errorf(ctx, "PushChitchat: SetWorkShowScope. redis set error. workId: %v, showScope: %v, error: %v", work.Id, work.GetShowScope(), err)
	}

	// 是否为首条动态
	if header.Versioncode >= version.SuperiorContentAwardVersion && VerifyStatus != int32(pbconst.WorkAuditResultEnum_war_refuse) {
		// 女性用户首条动态每日一次奖励，共四次，男性一次
		count, err := p.DataCache.SumFirstWork(ctx, userId)
		switch {
		case err != nil:
			logger.Error(ctx, "SumFirstWork", err)
			break
		case count == 0 && curUserInfo.UserInfoDbModel.GetGender() == 1:
			// 男性用户未发布过动态
			// 男性用户成功发布首条动态获得奖励
			if err := p.awardWorkToFirstWork(ctx, work.GetId(), work.GetUserId(), work.GetTitle()); err != nil {
				logger.Error(ctx, "awardWorkToFirstWork", err)
			}
		case count == 0 && curUserInfo.UserInfoDbModel.GetGender() == 2:
			//用户成功发布首条动态
			if err := p.awardWorkToFirstWork(ctx, work.GetId(), work.GetUserId(), work.GetTitle()); err != nil {
				logger.Error(ctx, "awardWorkToFirstWork", err)
			}
		case count < 4 && curUserInfo.UserInfoDbModel.GetGender() == 2:
			ok, err := p.DataCache.CheckUserCreateTimeToAwardFirstWork(ctx, userId, curUserInfo.UserInfoDbModel.GetCreateTime())
			if err != nil {
				logger.Error(ctx, "CheckUserCreateTimeToAwardFirstWork", err)
			}
			if ok {
				if err := p.awardWorkToFirstWork(ctx, work.GetId(), work.GetUserId(), work.GetTitle()); err != nil {
					logger.Error(ctx, "awardWorkToFirstWork", err)
				}
			}

		}

	}

	// //保存作品属性
	for _, attr := range req.WorkObjects {
		workAttrModel := &pbapi.WorkObjectAttrDbModel{
			Type:      attr.Type,
			WorkId:    work.Id,
			Width:     attr.Width,
			High:      attr.High,
			ObjectId:  attr.ObjectId,
			Thumbnail: attr.Thumbnail,
			ImgMd5:    nil,
			Status:    proto.Int32(int32(pbconst.BaseTabStatus_valid)),
		}

		_, err = p.DataCache.GetImpl().WorkObjectAttrModel.CreateItem(ctx, workAttrModel)
		if err != nil {
			logger.Errorf(ctx, "create workobjattr record failed", err)
			return 0, err
		}
	}

	// 通过的内容， 重置冷却时间，加入到分发池。
	if VerifyStatus == int32(pbconst.WorkAuditResultEnum_war_pass) {
		// 重置倒计时
		timeCdMs := p.getCdTimeMs(ctx, curUserInfo.MemberType)
		//logger.Infof(ctx, "cdtime, userId=%v, timeCdMs=%v", userId, timeCdMs)
		changes := map[string]interface{}{
			"nextChitchatTime": utils.GetCurTsMs() + timeCdMs, // cd时间60s
		}
		err = p.DataCache.GetImpl().UserInfoExtMgModel.UpdateDictById(ctx, curUserInfo.UserInfoDbModel.GetUserId(), changes, nil)
		if err != nil {
			logger.Errorf(ctx, "PushChitchat, update UserInfoExtMgModel failed.", err)
			return 0, err
		}

		//加入到分发池子
		err = p.DataCache.AddToTsWorkPoolRedis(ctx, work.GetId())
		if err != nil {
			logger.Errorf(ctx, "add work to tsPool failed.", err)
			return 0, err
		}

		// 加入复审池子 SecretChitchatWork done
		if work.GetUserId() != cm_const.OfficialMZUserId {
			fsWork := &pbmgdb.SecretChitchatWorkMgDbModel{
				Id:           work.GetId(),
				UserId:       work.UserId,
				WorkStatus:   work.Status,
				Timestamp:    proto.Int64(utils.GenTimestampMs(work.GetCreateTime())),
				VerifyStatus: proto.Int32(0),
				Gender:       curUserInfo.UserInfoDbModel.Gender,
				MemberType:   proto.Int32(curUserInfo.MemberType),
			}
			err = p.DataCache.GetImpl().SecretChitchatWork.Insert(ctx, fsWork)
			if err != nil {
				logger.Errorf(ctx, "add work to SecretChitchatWork failed.", err)
				//return 0, err
			}
		}

		// 发送互关消息
		// TODO 存在异步ctx失效bug
		go p.asyncPushAllChitChatMessage(ctx, header, curUserInfo, coordinate, req, work)
		if err2 := p.processWorkAtGroup(ctx, curUserInfo, work, req.RemindGroup); err2 != nil {
			logger.Infof(ctx, "processWorkAtGroup fail, err: %v", err2)
		}
	}

	//更新最后唠唠时间 done
	changes := map[string]interface{}{
		"lastChitChatTime": utils.GetCurTsMs(), // cd时间60s
	}
	p.DataCache.GetImpl().UserInfoExtMgModel.UpdateDictById(ctx, curUserInfo.UserInfoDbModel.GetUserId(), changes, nil)

	// 推送到es,完成统计
	p.KafkaProxy.SendPersonalBottleWorksEs(ctx, work, 1)

	//记录每日投递次数
	pTimes, err := p.DataCache.SetPushChitchatTimes(ctx, userId)
	if err != nil {
		logger.Error(ctx, "SetPushChitchatTimes failed", err)
	}
	if pTimes > 3 {
		//发送话痨勋章
		p.setMedal(ctx, userId, 2, 2*86400)
	}

	//发放美图勋章
	if req.GetType() == const_busi.WorkTypeImage {
		p.setMedal(ctx, userId, 8, 2*86400)
	}

	// 设置星座幸运卡
	if req.GetSystemWorkId() == cm_const.SystemWorkIdXingzuo {
		p.DataCache.SetUserSystemWorkPublishFlagRds(ctx, userId, cm_const.SystemWorkIdXingzuo)
	}
	//
	p.updateWorkCommentStatus(ctx, req, work.GetId(), userId)
	p.InsertUnreadCommentItem(ctx, work.GetId(), userId)

	if curUserInfo.UserInfoDbModel.GetUserId() != cm_const.OfficialMZUserId {
		logger.Infof(ctx, "== quding 官方账号不再限制3条动态可见")
		p.CheckAndUpdateBeforeHistoryWorks(ctx, work.GetId(), curUserInfo.UserInfoDbModel.GetUserId())
	}

	return work.GetId(), nil
}

func (p *ContentMng) awardWorkToFirstWork(ctx context.Context, workId, userId int64, content string) error {
	//用户成功发布首条动态即奖励
	err := NewSuperiorContentInstance(p, nil, 0).WriteNewItem(ctx, workId,
		userId, content, setting.Maozhua.AwardFirstWork.Get(), const_busi.FirstWorkSettlement)

	if err != nil {
		logger.Errorf(ctx, "write first work on award fail,err: %v", err)
		return err
	}
	err = p.SendRedPacketMsg(ctx, userId,
		int32(pbconst.MessageTypeEnum_msg_type_txt),
		fmt.Sprintf(setting.Maozhua.ReadPacket.Content.Get(), setting.Maozhua.AwardFirstWork.Get()),
		setting.Maozhua.ReadPacket.Title.Get(),
		setting.Maozhua.ReadPacket.IconUrl.Get(),
		setting.Maozhua.ReadPacket.BackgroundUrl.Get(),
	)
	if err != nil {
		return err
	}
	//addHallOFFameHande := NewAddKoLaHallOfFameInstance(p)
	//err = addHallOFFameHande.AddItemToHallOfFame(ctx, userId, var_busi.AwardFirstWork)
	//if err != nil {
	//	logger.Errorf(ctx, "err: %v, add award: %v on user: %v, to hall of fame when first work send",
	//		err, var_busi.AwardFirstWork, userId)
	//	return err
	//}
	//logger.Infof(ctx, "succ, write award: %v on user: %v to hall of fame when first work send",
	//	var_busi.AwardFirstWork, userId)

	return err
}

func (p *ContentMng) CheckAndUpdateBeforeHistoryWorks(ctx context.Context, workId int64, userId int64) error {
	conds := map[string]interface{}{
		"user_id":    userId,
		"status":     1,
		"show_scope": const_busi.WorkShowScopeGlobal, // 1: global show, 2: not global show
	}
	SizeGet := 4
	size := uint64(SizeGet)
	page := uint64(1)
	ret, err := p.DataCache.GetImpl().PersonBottleWorksModel.ListItemsByCondition(ctx, conds, "", "", page, size)
	if err != nil {
		logger.Errorf(ctx, "query user work fail, err: %v, user: %v", err, userId)
		return err
	}
	if len(ret) < SizeGet {
		return nil
	}
	lteConds := map[string]interface{}{
		"id": ret[3].GetId(),
	}

	updateField := map[string]interface{}{
		"show_scope": const_busi.WorkShowScopeDis,
	}
	err = p.DataCache.GetImpl().PersonBottleWorksModel.UpdateScopeShowItemWithCond(ctx, conds, lteConds, updateField)
	if err != nil {
		logger.Errorf(ctx, "update scope show fail, err: %v", err)
		return err
	}

	//更新缓存可见状态
	if err := p.DataCache.SetWorkShowScope(ctx, []int64{ret[3].GetId()}, const_busi.WorkShowScopeDis); err != nil {
		logger.Errorf(ctx, "PushChitchat: SetWorkShowScope. redis set error. workId: %v, showScope: %v, error: %v", ret[3].GetId(), const_busi.WorkShowScopeDis, err)
	}

	// 从分发池删除 仅自己可见的动态
	rdsRemoveIds := []string{strconv.FormatInt(ret[3].GetId(), 10)}
	go p.DataCache.AsyncRemoveFromTsWorkPoolRedis(ctx, rdsRemoveIds)
	logger.Infof(ctx, "CheckAndUpdateBeforeHistoryWorks remove work from pool: %v", rdsRemoveIds)

	//
	p.DataCache.DelWorkInfoCache(ctx, workId)
	return nil
}

func (p *ContentMng) updateWorkCommentStatus(ctx context.Context, req *pbapi.PushChitchatReq, workId int64, userId int64) error {
	if req.GetEnableComment() != const_busi.WorkCommentStatusDisable && req.GetEnableComment() != const_busi.WorkCommentStatusEnable { //0:close 1: open
		logger.Errorf(ctx, " enableComment val not in (0,1), workId: %v, userId: %v", workId, userId)
		return errorcode.GenBusiErr(errorcode.MIDAS_INTERFACE_INSUFFICIENT, "enableComment value not in (0,1)")
	}

	//默认：未传使能字段，或者传了并设置为 const_busi.WORK_COMMENT_STATUS_ENABLE，默认就开
	op := const_busi.WorkCommentStatusEnable
	// 默认只有开的操作
	//if req.EnableComment != nil && req.GetEnableComment() == const_busi.WorkCommentStatusDisable {
	//	op = const_busi.WorkCommentStatusDisable
	//} else {
	//	logger.Infof(ctx, "set enableComment ON: %v", const_busi.WorkCommentStatusEnable)
	//}

	reqEnableWorkComment := &pbapi.WorkCommentEnableReq{
		WorkId: workId,
		Op:     op,
	}
	err := p.DataCache.GetImpl().WorkCommentStatusDbModel.SetStatus(ctx, reqEnableWorkComment)
	if err != nil {
		logger.Errorf(ctx, "set work comment status fail, %v", err)
	}
	return err
}

func (p *ContentMng) checkPush(ctx context.Context, header *pbapi.HttpHeaderInfo, curUserInfo *data_cache.UserInfoLocal) error {
	if curUserInfo.IsInBlackHouse {
		logger.Infof(ctx, "user in blackhouse, fobid to publish ")
		return errorcode.GenBusiErr(errorcode.BusinessError, "小黑屋期间不能分享!")
	}
	if curUserInfo.PsecretUserExtInfo.GetUlevel() == 0 {
		logger.Infof(ctx, "push chitchat, level=0,")
		return errorcode.GenBusiErr(errorcode.BusinessError, "暂无权限")
	}
	if curUserInfo.PsecretUserExtInfo.GetNextChitchatTime() > utils.GetCurTsMs() {
		return errorcode.GenBusiErr(errorcode.BusinessError, "间隔期间不能分享!")
	}
	return nil
}

// 有图片就wait
// WAIT_AUDIT(0,"待审核"),PASS(1,"审核通过"),REFUSE(2,"审核拒绝"),HIDDEN(5,"隐藏不显示");
func (p *ContentMng) checkWorkTitleAndImage(ctx context.Context, userId int64, req *pbapi.PushChitchatReq, preWorkId int64, level int32) int32 {
	var audit = &pbmgdb.SecretAuditMgDbModel{
		Id:             snow_flake.GetSnowflakeID(),
		HookType:       cm_const.HookTypeMine,
		AuditType:      cm_const.AuditTypeText,
		Platform:       1,
		EventId:        shumei_proxy.EventIDArticle,
		UserId:         userId,
		Content:        req.GetTitle(),
		IsRecirculate:  2,
		FeedbackStatus: 2,
		CreateTime:     time.Now().UnixMilli(),
		WorkId:         preWorkId,
	}
	title := req.GetTitle()

	if userId == cm_const.OfficialMZUserId {
		return int32(pbconst.WorkAuditResultEnum_war_pass)
	}

	// 看跟历史发帖是否相似。 相似就隐藏
	//cond := map[string]interface{}{
	//	"user_id": userId,
	//}
	//items, err := p.DataCache.GetImpl().PersonBottleWorksModel.ListItemsByCondition(ctx, cond, "", "", 1, 1)
	//if err != nil {
	//	logger.Error(ctx, "checkWorkTitle ListItemsByCondition failed", err)
	//	return int32(pbconst.WorkAuditResultEnum_war_wait)
	//}
	//if len(items) > 0 {
	//	if items[0].GetTitle() == title {
	//		// 文本相同  // todo 未来要做成文本相似度过高。
	//		logger.Infof(ctx, "hiddlen. work title is the same", title)
	//		audit.AuditResp = "已存在相同文本"
	//
	//		if len(req.GetWorkObjects()) > 0 { // 补充图片展示
	//			audit.ImgUrl = req.GetWorkObjects()[0].GetObjectId()
	//		}
	//		_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
	//		return int32(pbconst.WorkAuditResultEnum_war_refuse)
	//	}
	//}

	//过滤@昵称内容
	checkTitle, err := utils.RegFilterRemind.Replace(title, "", -1, -1)
	if err != nil {
		logger.Errorf(ctx, "push_chit_chat RegFilterRemind:Replace failed", err)
		checkTitle = title
	}
	// 请求大雄的黑名名单库
	ret, err := p.InnerProxy.ChitChatPostCheck(ctx, checkTitle, userId, level)
	if err != nil {
		logger.Errorf(ctx, "push_chit_chat ChitChatPostCheck failed", err)
	}
	if ret.GetIResultCode() != 0 {
		logger.Infof(ctx, "push_chit_chat inner check not pass. ret=%v", ret)
		audit.AuditResp = fmt.Sprintf("本平台黑名单/内容拦截，结果：%+v", ret)
		if len(req.GetWorkObjects()) > 0 { // 补充图片展示
			audit.ImgUrl = req.GetWorkObjects()[0].GetObjectId()
		}
		_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
		return int32(pbconst.WorkAuditResultEnum_war_refuse)
	}

	if config.ServerConfig.Env == "test" {
		return int32(pbconst.WorkAuditResultEnum_war_pass)
	}

	// 数美审核
	verifyResult, resp, err := p.ShumeiProxy.CheckTxt(ctx, title, userId, shumei_proxy.EventIDArticle)
	if err != nil {
		logger.Errorf(ctx, "push_chit_chat shumeicheck failed", err)
	}
	if verifyResult != "" && verifyResult != shumei_proxy.TextRiskLevelPASS {
		logger.Infof(ctx, "push_chit_chat shumei check not pass. verifyResult=%v, content=%v", verifyResult, title)
		if resp != nil {
			auditResp, _ := json.Marshal(resp)
			audit.RequestId = resp.RequestID
			audit.HookType = cm_const.HookTypeShuMei
			audit.AuditType = cm_const.AuditTypeText
			audit.RiskLevel = resp.RiskLevel
			audit.AuditResp = string(auditResp)
			audit.EventId = shumei_proxy.EventIDArticle
			audit.Platform = 2
			if len(req.GetWorkObjects()) > 0 { // 补充图片展示
				audit.ImgUrl = req.GetWorkObjects()[0].GetObjectId()
			}
			_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
		}

		return int32(pbconst.WorkAuditResultEnum_war_refuse)
	}

	// 图片送审 当前使用数美
	for _, attr := range req.GetWorkObjects() {
		bPass := false
		resp := &shumei_proxy.TextResp{}
		auditType := int32(0)
		//如果是表情包：查看此表情地址是否已检查过，减少数美请求
		if req.SubType != nil && *req.SubType == const_busi.WorkSubTypeEmote {
			auditType = cm_const.AuditTypeEmote
			bPass, resp = p.checkImage(ctx, attr.GetObjectId(), userId, true, 0, shumei_proxy.EventIDArticle)
		} else {
			auditType = cm_const.AuditTypeImg
			bPass, resp = p.checkImage(ctx, attr.GetObjectId(), userId, false, 0, shumei_proxy.EventIDArticle)
		}

		if bPass == false {
			if resp != nil {
				auditResp, _ := json.Marshal(resp)
				audit.RequestId = resp.RequestID
				audit.HookType = cm_const.HookTypeShuMei
				audit.AuditType = auditType
				audit.ImgUrl = attr.GetObjectId()
				audit.RiskLevel = resp.RiskLevel
				audit.AuditResp = string(auditResp)
				audit.Platform = 2
				_ = p.DataCache.GetImpl().SecretAuditMgDbModel.Create(ctx, audit)
			}

			return int32(pbconst.WorkAuditResultEnum_war_refuse)
		}
	}
	return int32(pbconst.WorkAuditResultEnum_war_pass)
}

func (p *ContentMng) getCdTimeMs(ctx context.Context, memberType int32) int64 {
	if config.ServerConfig.Env == "test" {
		return 5 * 1000
	}

	// 后台配置 https://admin.52mengdong.com/#/secret/chitchatConfig
	var cdTimeMin int64 = 25 // 默认25分钟
	switch memberType {
	case int32(pbconst.MemberTypeEnum_member_type_svip):
		cdTimeMin = p.DataCache.GetTimesConfigLR(ctx, "times_chitchat_push_frequency_svip")
	case int32(pbconst.MemberTypeEnum_member_type_vip), int32(pbconst.MemberTypeEnum_member_type_freevip):
		cdTimeMin = p.DataCache.GetTimesConfigLR(ctx, "times_chitchat_push_frequency_vip")
	case int32(pbconst.MemberTypeEnum_member_type_normal):
		cdTimeMin = p.DataCache.GetTimesConfigLR(ctx, "times_chitchat_push_frequency_normal")
	}

	return cdTimeMin * 60 * 1000
}

// asyncCheckImage.
func (p *ContentMng) checkImage(ctx context.Context, objectId string, userId int64, isEmote bool, memeId int64, eventId string) (bool, *shumei_proxy.TextResp) {
	// 审核结果类型，可取值1、2、3、4，分别代表1：合规，2：不合规，3：疑似，4：审核失败
	//baiDuResult, err := p.BaiduLbsProxy.CheckImage(ctx, url)
	//if err != nil {
	//	logger.Error(ctx, "baiduyun CheckImage failed", err)
	//}

	var url = config.ServerConfig.ImageHost + objectId

	getMemeId := func() int64 {
		if m, err := p.DataCache.GetImpl().MemeMgDbModel.Find(ctx, bson.M{"objectId": objectId}); len(m) > 0 && err == nil {
			return m[0].Id
		}
		return 0
	}

	if isEmote {
		emote, _ := p.DataCache.GetImpl().SecretEmoteAuditRecordMgModel.FindOne(ctx, bson.M{"object_id": objectId})
		if emote != nil {
			update := map[string]any{"last_use_time": time.Now().UnixMilli()}
			if emote.MemeId == 0 {
				if memeId > 0 {
					update["meme_id"] = memeId
				} else {
					//只查一次, 也可对以往数据增量补全
					update["meme_id"] = getMemeId()
				}
			}
			if err := p.DataCache.GetImpl().SecretEmoteAuditRecordMgModel.UpdateOne(ctx, bson.M{"_id": emote.Id}, update); err != nil {
				logger.Errorf(ctx, "ContentMng:checkImage:SecretEmoteAuditRecordMgModel:UpdateOne() update fail: %v", err)
			}
			return emote.ShumeiRiskLevel == shumei_proxy.TextRiskLevelPASS || emote.ShumeiRiskLevel == shumei_proxy.TextRiskLevelREVIEW, nil
		} else {
			shumeiResult, resp, err := p.ShumeiProxy.CheckImg(ctx, url, userId, eventId)
			if err != nil {
				logger.Error(ctx, "ShumeiProxy CheckImage Emote failed", err)
				if resp == nil {
					resp = &shumei_proxy.TextResp{
						Message: err.Error(),
					}
				}
			}
			auditResult := shumeiResult == shumei_proxy.TextRiskLevelPASS || shumeiResult == shumei_proxy.TextRiskLevelREVIEW

			if memeId == 0 {
				memeId = getMemeId()
			}

			_ = p.DataCache.GetImpl().SecretEmoteAuditRecordMgModel.Create(ctx, &pbmgdb.SecretEmoteAuditRecordMgDbModel{
				Id:              snow_flake.GetSnowflakeID(),
				ObjectId:        objectId,
				MemeId:          memeId,
				AuditResult:     auditResult,
				CreateTime:      time.Now().UnixMilli(),
				ShumeiRiskLevel: shumeiResult,
				LastUseTime:     time.Now().UnixMilli(),
			})
			return auditResult, resp
		}
	} else {
		shumeiResult, resp, err := p.ShumeiProxy.CheckImg(ctx, url, userId, eventId)
		if err != nil {
			logger.Error(ctx, "ShumeiProxy CheckImage failed", err)
			if resp == nil {
				resp = &shumei_proxy.TextResp{
					Message: err.Error(),
				}
			}
		}
		auditResult := shumeiResult == shumei_proxy.TextRiskLevelPASS || shumeiResult == shumei_proxy.TextRiskLevelREVIEW

		return auditResult, resp
	}
}

func (p *ContentMng) buildWorks(ctx context.Context,
	header *pbapi.HttpHeaderInfo, curUserInfo *data_cache.UserInfoLocal,
	req *pbapi.PushChitchatReq, VerifyStatus int32, preWorkId int64) (*pbapi.PersonalBottleWorksDbModel, *pbapi.Coordinate) {

	now := time.Now()
	nowAfter3 := time.Now().Add(time.Second * 3 * 86400)
	work := &pbapi.PersonalBottleWorksDbModel{
		Id:              proto.Int64(preWorkId),
		ClientId:        req.ClientId,
		UserId:          curUserInfo.UserInfoDbModel.UserId,                //
		AppType:         proto.Int32(cm_const.AppTypeDict[header.Apptype]), //
		Source:          proto.Int32(0),
		Type:            proto.Int32(req.Type),
		WorksType:       proto.Int32(1), //，1:单聊；2:群聊
		PushType:        req.PushType,
		BrowseType:      req.BrowseType,
		Title:           req.Title,
		VerifyStatus:    proto.Int32(VerifyStatus),
		ShareStatus:     proto.Int32(1),
		StartTime:       proto.String(utils.GenDbTime(now)),
		EndTime:         proto.String(utils.GenDbTime(nowAfter3)),
		FileSize:        req.FileSize,
		CommentCount:    proto.Int32(0),
		VisitorCount:    proto.Int32(0),
		LikeCount:       proto.Int32(0),
		HugCount:        proto.Int32(0),
		CheerCount:      proto.Int32(0),
		Status:          proto.Int32(int32(pbconst.BaseTabStatus_valid)),
		CreateTime:      proto.String(utils.GenDbTime(now)),
		TemplateId:      req.TemplateId,
		VerifyUser:      nil,
		Arrested:        proto.Int32(0),
		Ip:              proto.String(header.GetIp()),
		ReplayCount:     proto.Int32(0),
		QqFriend:        proto.Int32(req.QqFriend),
		Special:         req.Special,
		ReportTimes:     proto.Int32(0),
		ShowScope:       proto.Int32(const_busi.WorkShowScopeGlobal),
		NewCommentCount: proto.Int32(0),
	}

	// 经纬度优先使用接口数据
	if req.GetLongitude() > 0 && req.GetLatitude() > 0 {
		header.Longitude = req.GetLongitude()
		header.Latitude = req.GetLatitude()
	}

	coordinate := p.DataCache.GetUserCoordinateV2(ctx, curUserInfo.UserInfoDbModel.GetUserId(), header)
	if coordinate != nil {
		work.Latitude = proto.Float64(coordinate.GetLatitude())
		work.Longitude = proto.Float64(coordinate.GetLongitude())
		work.Province = proto.String(coordinate.GetProvince())
		work.City = proto.String(coordinate.GetCity())
		work.Address = proto.String(coordinate.GetDistrict())
	}

	return work, p.DataCache.ConvertFormate(coordinate)
}

func (p *ContentMng) createPersonBottleWorksExtMgDbModel(ctx context.Context, header *pbapi.HttpHeaderInfo, workType, subType int32, workId int64) error {
	if header.Versioncode < version.SuperiorContentAwardVersion {
		switch workType {
		case const_busi.WorkTypeText:
			// 旧版本的发文字默认为1
			subType = const_busi.WorkSubTypeText
		case const_busi.WorkTypeImage:
			// 旧版本的发图片默认为2
			subType = const_busi.WorkSubTypeCamera
		}
	}
	err := p.DataCache.GetImpl().PersonBottleWorksExtMgModel.Create(ctx, &pbmgdb.PersonBottleWorksExtMgDbModel{
		Id:      workId,
		SubType: subType,
	})
	if err != nil {
		return err
	}

	return nil
}

func (p *ContentMng) asyncPushAllChitChatMessage(ctx context.Context,
	header *pbapi.HttpHeaderInfo,
	curUserInfo *data_cache.UserInfoLocal,
	coordinate *pbapi.Coordinate,
	req *pbapi.PushChitchatReq,
	work *pbapi.PersonalBottleWorksDbModel) error {

	//List<SecretUserFollow> list = MongoUtil.find(new Query(Criteria.where("targetUserId").is(userId).and("mutual").is(1)), SecretUserFollow.class);
	//if (CollectionUtils.isNotEmpty(list)) {
	//	personalTalkMessageService.sendMessageByFriend(list.stream().map(SecretUserFollow::getUserId).collect(Collectors.toList()), works);
	//}
	//curUserId := curUserInfo.UserInfoDbModel.GetUserId()

	//cond := map[string]interface{}{
	//	"targetUserId": work.GetUserId(),
	//	"mutual":       1,
	//}
	//ufItems, err := p.DataCache.GetImpl().SecretUserFollowMgModel.ListByCondition(ctx, cond)
	//if err != nil {
	//	logger.Error(ctx, "asyncPushAllchitChatMessage getFollows failed ", err)
	//	return err
	//}
	//
	if len(req.RemindNode) > 0 {
		p.processRemindLogicOnChitChat(ctx, req, nil, work, curUserInfo, coordinate, header)
	} else {
		//p.processMutualLogicOnChitChat(ctx, req, ufItems, work, curUserInfo, coordinate, header)
	}

	//var workid int64 = -1
	//modeType := int32(pbconst.PtModelTypeEnum_pt_model_type_normal)
	//for _, ufitem := range ufItems {
	//
	//	// 发文本
	//	sendTxtReq := &pbapi.SendMsgReq{
	//		ToUserId:    ufitem.UserId,
	//		Content:     work.Title,
	//		WorkId:      proto.Int64(workid),
	//		MessageType: int32(pbconst.MessageTypeEnum_msg_type_txt),
	//		Width:       nil,
	//		High:        nil,
	//		Duration:    nil,
	//		ObjectId:    nil,
	//		ClientId:    req.ClientId,
	//		MemeId:      nil,
	//		SessionType: nil,
	//		Longitude:   work.Longitude,
	//		Latitude:    work.Latitude,
	//	}
	//
	//	toUserInfo, err := p.DataCache.GetUserInfoLocal(ctx, header, ufitem.GetUserId(), false)
	//	if err != nil {
	//		logger.Error(ctx, "GetUserInfoLocal failed", err)
	//		continue
	//	}
	//
	//	uniqueId := genUniqueId(curUserId, ufitem.GetUserId(), workid, modeType)
	//	toWindow := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, ufitem.GetUserId()) // 正向
	//	fromWindow := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, curUserId)        // 反向
	//
	//	sendSession := &SendMsgSession{
	//		curUserId:     curUserInfo.UserInfoDbModel.GetUserId(),
	//		curUserInfo:   curUserInfo,
	//		toUserId:      ufitem.GetUserId(),
	//		toUserInfo:    toUserInfo,
	//		modeType:      modeType,
	//		mutual:        1,
	//		workId:        -1,
	//		workInfo:      nil,
	//		fromWindow:    fromWindow,
	//		toWindow:      toWindow,
	//		curCoordinate: coordinate,
	//	}
	//	_, err = p.sendMsgBase(ctx, header, sendTxtReq, sendSession, uniqueId)
	//	if err != nil {
	//		logger.Warnf(ctx, "sendTxtReq.sendMsgBase failed, err=%v", err)
	//		return err
	//	}
	//
	//	// 发图片
	//	if work.GetType() == int32(pbconst.UserInfoType_user_info_type_pic) && len(req.WorkObjects) != 0 {
	//		sendImageReq := &pbapi.SendMsgReq{
	//			ToUserId:    ufitem.UserId,
	//			Content:     work.Title,
	//			WorkId:      proto.Int64(workid),
	//			MessageType: int32(pbconst.MessageTypeEnum_msg_type_pic),
	//			Width:       req.WorkObjects[0].Width,
	//			High:        req.WorkObjects[0].High,
	//			Duration:    nil,
	//			ObjectId:    req.WorkObjects[0].ObjectId,
	//			ClientId:    req.ClientId,
	//			MemeId:      nil,
	//			SessionType: nil,
	//			Longitude:   work.Longitude,
	//			Latitude:    work.Latitude,
	//		}
	//		_, err = p.sendMsgBase(ctx, header, sendImageReq, sendSession, uniqueId)
	//		if err != nil {
	//			logger.Warnf(ctx, "sendImageReq.sendMsgBase failed,  err=%v", err)
	//			return err
	//		}
	//	}
	//}
	return nil
}

func (p *ContentMng) insertRemindItem(ctx context.Context, workId int64, workUserId int64, toUserNode *pbapi.RemindUserNode) (int64, error) {
	if toUserNode == nil {
		return -1, errorcode.GenBusiErr(errorcode.BusinessError, "param invalid")
	}
	remindItem := &pbmgdb.UserRemindDetailMgDbModel{
		Id:            snow_flake.GetSnowflakeID(),
		WorkId:        proto.Int64(workId),
		WorkUserId:    proto.Int64(workUserId),
		RemindUserId:  proto.Int64(toUserNode.GetUserId()),
		RemindOffSet:  proto.Int32(toUserNode.GetOffSet()),
		RemindType:    proto.Int32(const_busi.WorkRemindType), //0:work @
		CommentUserId: proto.Int64(0),
		CreateTime:    proto.Int64(time.Now().UnixMilli()),
		CommentId:     proto.Int64(0),
		RemindSize:    toUserNode.Size,
	}

	if err := p.DataCache.GetImpl().UserRemindDetail.Insert(ctx, remindItem); err != nil {
		logger.Errorf(ctx, "work: %v, insert user remind to tab fail, err: %v", err)
		return -1, err
	}
	return remindItem.GetId(), nil
}
func (p *ContentMng) processMutualLogicOnChitChat(ctx context.Context, req *pbapi.PushChitchatReq,
	mutualUsers []*pbapi.SecretUserFollowMgDbModel, work *pbapi.PersonalBottleWorksDbModel,
	curUserInfo *data_cache.UserInfoLocal, coordinate *pbapi.Coordinate, header *pbapi.HttpHeaderInfo) {
	//
	if req == nil || len(mutualUsers) <= 0 {
		return
	}
	msgWorkId := work.GetId()
	msgType := pbconst.MessageTypeEnum_msg_type_mutual_notice
	for i := 0; i < len(mutualUsers); i++ {
		if mutualUsers[i] == nil {
			continue
		}
		workObjs := req.WorkObjects
		workRemindInfo := &WorkRemindInfo{
			curUserInfo: curUserInfo,
			toUserId:    mutualUsers[i].GetUserId(),
			work:        work,
			workObj:     workObjs,
			reqClientId: req.ClientId,
			coordinate:  coordinate,
			msgType:     int32(msgType),
			remindId:    msgWorkId,
			commentId:   0,
			header:      header,
		}
		p.UpdateMsgAndNotice(ctx, workRemindInfo)
	}

}

type WorkRemindInfo struct {
	curUserInfo *data_cache.UserInfoLocal
	toUserId    int64
	work        *pbapi.PersonalBottleWorksDbModel
	workObj     []*pbapi.WorkObjectAttrRequest
	reqClientId *string
	coordinate  *pbapi.Coordinate
	msgType     int32
	remindId    int64
	commentId   int64
	header      *pbapi.HttpHeaderInfo
	reminds     []*pbapi.RemindUserNode
}

func (p *ContentMng) processCommentAtGroup(ctx context.Context, userInfo *data_cache.UserInfoLocal, work *pbapi.PersonalBottleWorksDbModel, commentID int64, groups []*pbapi.RemindGroupNode) error {
	if len(groups) == 0 {
		return nil
	}
	// 除重
	uniqGroups := lo.UniqBy(groups, func(item *pbapi.RemindGroupNode) string { return fmt.Sprint(item) })

	err := p.DataCache.GetImpl().AtDetailMgModel.InsertCommentAtGroup(ctx, commentID, uniqGroups)
	if err != nil {
		logger.Errorf(ctx, "InsertCommentAtGroup fail, err: %v", err)
		return nil
	}

	// 从DB读最新用户头像&昵称
	latestUserInfo, err := p.DataCache.GetUserBasicInfo(ctx, userInfo.UserInfoDbModel.GetUserId(), true)
	if err != nil {
		logger.Errorf(ctx, "GetUserBasicInfo fail, err: %v", err)
		return err
	}

	// 异步发通知
	// distinct groupID
	groupIDs := lo.Uniq(lo.Map(uniqGroups, func(item *pbapi.RemindGroupNode, _ int) string { return item.GroupID }))
	nctx := context.Background()
	go func() {
		for _, gid := range groupIDs {
			user := userInfo.UserInfoDbModel
			msg := &im_mng.CommentAtMsg{
				Title:     work.GetTitle(),
				WorkID:    work.GetId(),
				CommentID: commentID,
			}
			u := &im_mng.UserLite{
				UserID:   fmt.Sprint(latestUserInfo.GetUserId()),
				NickName: latestUserInfo.GetNickName(),
				FaceURL:  latestUserInfo.GetPhoto(),
			}
			resp, err2 := p.IMHelper.SendGroupCustomMsg(nctx, u, gid, msg)
			if err2 != nil {
				logger.Errorf(nctx, "SendGroupCustomMsg fail, CommentAtGroup err: %v", err)
			} else {
				logger.Infof(nctx, "SendGroupCustomMsg, CommentAtGroup uid: %v gid: %v resp: %v", user.GetUserId(), gid, resp)
			}
		}
	}()

	return nil

}
func (p *ContentMng) processWorkAtGroup(ctx context.Context, userInfo *data_cache.UserInfoLocal, work *pbapi.PersonalBottleWorksDbModel, groups []*pbapi.RemindGroupNode) error {
	if len(groups) == 0 {
		return nil
	}
	// 除重
	uniqGroups := lo.UniqBy(groups, func(item *pbapi.RemindGroupNode) string { return fmt.Sprint(item) })

	err := p.DataCache.GetImpl().AtDetailMgModel.InsertWorkAtGroup(ctx, work.GetId(), uniqGroups)
	if err != nil {
		logger.Errorf(ctx, "InsertWorkAtGroup fail, err: %v", err)
		return nil
	}

	latestUserInfo, err := p.DataCache.GetUserBasicInfo(ctx, userInfo.UserInfoDbModel.GetUserId(), true)
	if err != nil {
		logger.Errorf(ctx, "GetUserBasicInfo fail, err:% err", err)
		return err
	}

	// 异步发通知
	// distinct groupID
	groupIDs := lo.Uniq(lo.Map(uniqGroups, func(item *pbapi.RemindGroupNode, _ int) string { return item.GroupID }))
	nctx := context.Background()

	go func() {
		for _, gid := range groupIDs {
			user := userInfo.UserInfoDbModel
			msg := &im_mng.WorkAtMsg{
				Title:  work.GetTitle(),
				Type:   work.GetType(),
				UserID: user.GetUserId(),
				WorkID: work.GetId(),
			}
			u := &im_mng.UserLite{
				UserID:   fmt.Sprintf("%v", user.GetUserId()),
				NickName: latestUserInfo.GetNickName(),
				FaceURL:  latestUserInfo.GetPhoto(),
			}
			resp, err2 := p.IMHelper.SendGroupCustomMsg(nctx, u, gid, msg)
			if err2 != nil {
				logger.Errorf(nctx, "SendGroupCustomMsg fail, WorkAtGroup, err: %v", err)
			} else {
				logger.Infof(nctx, "SendGroupCustomMsg succ, WorkAtGroup, uid: %v gid: %v resp: %v", user.GetUserId(), gid, resp)
			}
		}
	}()

	return nil
}

func (p *ContentMng) processRemindLogicOnChitChat(ctx context.Context, req *pbapi.PushChitchatReq,
	mutualUsers []*pbapi.SecretUserFollowMgDbModel, work *pbapi.PersonalBottleWorksDbModel,
	curUserInfo *data_cache.UserInfoLocal, coordinate *pbapi.Coordinate, header *pbapi.HttpHeaderInfo) {
	//
	if req == nil || req.GetRemindNode() == nil || len(req.GetRemindNode()) <= 0 {
		return
	}
	//
	//userIds := make(map[int64]bool)
	//for _, v := range mutualUsers {
	//	if v == nil {
	//		continue
	//	}
	//	userIds[v.GetUserId()] = true
	//}

	var validRemindUsers []*pbapi.RemindUserNode
	for i := 0; i < len(req.GetRemindNode()); i++ {
		if req.GetRemindNode()[i] == nil {
			continue
		}
		//userId := req.GetRemindNode()[i].GetUserId()
		//if _, ok := userIds[userId]; !ok {
		//	continue
		//}
		validRemindUsers = append(validRemindUsers, req.GetRemindNode()[i])
	}

	if len(validRemindUsers) <= 0 {
		logger.Errorf(ctx, "work user id: %v", work.GetUserId())
		return
	}
	logger.Infof(ctx, "work user id: %v", work.GetUserId())
	//...
	msgType := pbconst.MessageTypeEnum_msg_type_remind_work
	for i := 0; i < len(validRemindUsers); i++ {
		if validRemindUsers[i] == nil {
			continue
		}

		remindId, err := p.insertRemindItem(ctx, work.GetId(), curUserInfo.UserInfoDbModel.GetUserId(), validRemindUsers[i])
		if err != nil {
			logger.Errorf(ctx, "insert remind fail for work")
			continue
		}
		workObjs := req.WorkObjects

		workRemindInfo := &WorkRemindInfo{
			curUserInfo: curUserInfo,
			toUserId:    validRemindUsers[i].GetUserId(),
			work:        work,
			workObj:     workObjs,
			reqClientId: req.ClientId,
			coordinate:  coordinate,
			msgType:     int32(msgType),
			remindId:    remindId,
			commentId:   0,
			header:      header,
			reminds:     req.RemindNode,
		}
		p.UpdateMsgAndNotice(ctx, workRemindInfo)
	}
}

func (p *ContentMng) SendBBMsg(ctx context.Context, userID int64, msgType int32, content string) error {
	bbUserID := config.ServerConfig.CommentConfig.ReplyCommentOfficialAccount
	return p.SendNotifyMsg(ctx, bbUserID, userID, msgType, "", content)
}

func (p *ContentMng) SendNotifyMsg(ctx context.Context, fromId, toId int64, msgType int32, title, content string) error {
	workId := int64(-1) //互关
	sendReq := &pbapi.SendMsgReq{
		ToUserId:    toId,
		Title:       &title,
		Content:     &content,
		WorkId:      &workId,
		MessageType: msgType,
	}

	uniqueId := genUniqueId(fromId, toId, workId, int32(pbconst.PtModelTypeEnum_pt_model_type_normal))
	toWindow := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, toId)     // 正向
	fromWindow := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, fromId) // 反向

	fromUserInfo, err := p.GetUserInfo(ctx, fromId)
	if err != nil {
		return err
	}
	toUserInfo, err := p.DataCache.GetUserInfoLocal(ctx, nil, toId, false)
	if err != nil {
		return err
	}

	sendSession := &SendMsgSession{
		curUserId:   fromId,
		curUserInfo: fromUserInfo,
		toUserId:    toId,
		toUserInfo:  toUserInfo,
		modeType:    0,
		mutual:      1,
		workId:      -1,
		workInfo:    nil,
		fromWindow:  fromWindow,
		toWindow:    toWindow,
		msgType:     msgType,
	}
	bbHeader := &pbapi.HttpHeaderInfo{
		Apptype:  "sys",
		Platform: "sys",
	}
	_, err = p.sendMsgBase(ctx, bbHeader, sendReq, sendSession, uniqueId)
	if err != nil {
		logger.Warnf(ctx, "sendTxtReq.sendMsgBase failed, err=%v", err)
		return err
	}
	return nil

}

// 红包消息
func (p *ContentMng) SendRedPacketMsg(ctx context.Context, userID int64, msgType int32, content, title, iconUrl, backgroundUrl string) error {
	workId := int64(-1) //互关
	sendReq := &pbapi.SendMsgReq{
		ToUserId:      userID,
		Content:       &content,
		WorkId:        &workId,
		MessageType:   msgType,
		Title:         &title,
		IconUrl:       &iconUrl,
		BackgroundUrl: &backgroundUrl,
	}

	readPacketUserID := config.ServerConfig.CommentConfig.ReadPacketOfficialAccount
	uniqueId := genUniqueId(readPacketUserID, userID, workId, int32(pbconst.PtModelTypeEnum_pt_model_type_normal))
	toWindow := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, userID)             // 正向
	fromWindow := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, readPacketUserID) // 反向

	readPacketUserInfo, err := p.GetUserInfo(ctx, readPacketUserID)
	if err != nil {
		return err
	}
	userInfo, err := p.DataCache.GetUserInfoLocal(ctx, nil, userID, false)
	if err != nil {
		return err
	}

	sendSession := &SendMsgSession{
		curUserId:   readPacketUserID,
		curUserInfo: readPacketUserInfo,
		toUserId:    userID,
		toUserInfo:  userInfo,
		modeType:    0,
		mutual:      1,
		workId:      -1,
		workInfo:    nil,
		fromWindow:  fromWindow,
		toWindow:    toWindow,
		msgType:     msgType,
	}
	readPacketHeader := &pbapi.HttpHeaderInfo{
		Apptype:  "sys",
		Platform: "sys",
	}
	_, err = p.sendMsgBase(ctx, readPacketHeader, sendReq, sendSession, uniqueId)
	if err != nil {
		logger.Warnf(ctx, "sendTxtReq.sendMsgBase failed, err=%v", err)
		return err
	}
	return nil
}

func (p *ContentMng) UpdateMsgAndNotice(ctx context.Context, workRemindInfo *WorkRemindInfo) {
	//
	v10717 := int32(1)
	modeType := int32(pbconst.PtModelTypeEnum_pt_model_type_normal)
	workId := int64(-1)

	//
	sendTxtReq := &pbapi.SendMsgReq{
		ToUserId:    workRemindInfo.toUserId,
		Content:     workRemindInfo.work.Title,
		WorkId:      proto.Int64(workId),
		MessageType: workRemindInfo.msgType,
		Width:       nil,
		High:        nil,
		Duration:    nil,
		ObjectId:    nil,
		ClientId:    workRemindInfo.reqClientId,
		MemeId:      nil,
		SessionType: nil,
		Longitude:   workRemindInfo.work.Longitude,
		Latitude:    workRemindInfo.work.Latitude,
	}
	toUserInfo, err := p.DataCache.GetUserInfoLocal(ctx, nil, workRemindInfo.toUserId, false)
	if err != nil {
		logger.Error(ctx, "GetUserInfoLocal failed", err)
		return
	}
	curUserId := workRemindInfo.curUserInfo.UserInfoDbModel.GetUserId()

	uniqueId := genUniqueId(curUserId, workRemindInfo.toUserId, workId, modeType)
	toWindow := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, workRemindInfo.toUserId) // 正向
	fromWindow := p.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, curUserId)             // 反向

	sendSession := &SendMsgSession{
		curUserId:     workRemindInfo.curUserInfo.UserInfoDbModel.GetUserId(),
		curUserInfo:   workRemindInfo.curUserInfo,
		toUserId:      workRemindInfo.toUserId,
		toUserInfo:    toUserInfo,
		modeType:      modeType,
		mutual:        1,
		workId:        -1,
		workInfo:      nil,
		fromWindow:    fromWindow,
		toWindow:      toWindow,
		curCoordinate: workRemindInfo.coordinate,
		msgType:       workRemindInfo.msgType,
		messageWorkId: workRemindInfo.remindId,     //和互爪消息通知的workid复用。回复评论时beCommentId复用, 1 级
		commentId:     workRemindInfo.commentId,    //回复评论的 id
		remindWorkId:  workRemindInfo.work.GetId(), //复用动态id
		remindsOnWork: workRemindInfo.reminds,
	}
	_, err = p.sendMsgBase(ctx, workRemindInfo.header, sendTxtReq, sendSession, uniqueId)
	if err != nil {
		logger.Warnf(ctx, "sendTxtReq.sendMsgBase failed, err=%v", err)
		return
	}
	// 后续版本， 对图片的处理
	if v10717 == 1 {
		return
	}
	if workRemindInfo.work.GetType() == const_busi.WorkTypeImage && len(workRemindInfo.workObj) != 0 {
		sendImageReq := &pbapi.SendMsgReq{
			ToUserId:    workRemindInfo.toUserId,
			Content:     workRemindInfo.work.Title,
			WorkId:      proto.Int64(workId),
			MessageType: int32(pbconst.MessageTypeEnum_msg_type_pic),
			Width:       workRemindInfo.workObj[0].Width,
			High:        workRemindInfo.workObj[0].High,
			Duration:    nil,
			ObjectId:    workRemindInfo.workObj[0].ObjectId,
			ClientId:    workRemindInfo.reqClientId,
			MemeId:      nil,
			SessionType: nil,
			Longitude:   workRemindInfo.work.Longitude,
			Latitude:    workRemindInfo.work.Latitude,
		}
		_, err = p.sendMsgBase(ctx, workRemindInfo.header, sendImageReq, sendSession, uniqueId)

		if err != nil {
			logger.Warnf(ctx, "sendImageReq.sendMsgBase failed,  err=%v", err)
			return
		}
	}
}
