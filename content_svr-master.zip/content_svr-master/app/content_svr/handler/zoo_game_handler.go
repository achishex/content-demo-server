package handler

import (
	"content_svr/internal/zoo_game_mng"
	"github.com/gin-gonic/gin"
)

func (p *AdminHandler) AdjustRegisterCallback(ctx *gin.Context, req *zoo_game_mng.ZooAjustReq) (*zoo_game_mng.ZooAjustResp, error) {
	p.zooGameMng.HandleRegisterEvent(ctx, req)

	return &zoo_game_mng.ZooAjustResp{}, nil
}

func (p *AdminHandler) AdjustPayCallback(ctx *gin.Context, req *zoo_game_mng.ZooAjustReq) (*zoo_game_mng.ZooAjustResp, error) {
	p.zooGameMng.HandlePayEvent(ctx, req)

	return &zoo_game_mng.ZooAjustResp{}, nil
}
