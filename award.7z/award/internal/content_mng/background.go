package content_mng

import "context"

func (p *ContentMng) GetBackgroundWithTalk(ctx context.Context) (string, error) {
	bgImage, err := p.DataCache.GetBackground(ctx, "talk")
	if err != nil {
		return "", err
	}

	return bgImage, err
}

func (p *ContentMng) GetBackgroundWithWork(ctx context.Context) (string, error) {
	bgImage, err := p.DataCache.GetBackground(ctx, "work")
	if err != nil {
		return "", err
	}

	return bgImage, err
}

func (p *ContentMng) GetBackgroundWithTalkGroup(ctx context.Context) (string, error) {
	bgImage, err := p.DataCache.GetBackground(ctx, "talk_group")
	if err != nil {
		return "", err
	}

	return bgImage, err
}
