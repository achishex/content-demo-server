package once

import (
	"content_svr/db/mongodb/model"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/snow_flake"
	"context"
	"fmt"
	"log"
	"time"
)

func (c *command) fixUserLevelNoAuthName() {
	filter := map[string]interface{}{
		"ulevel": 5,
	}

	ctx := requestid.WithRequestID(context.Background())
	users, err := c.read.SecretUserExtInfoModel.FindAll(ctx, filter)
	if err != nil {
		log.Fatal(err)
	}

	var (
		notFound []int64
		found    []int64
		sucs     []int64
	)

	for _, user := range users {
		filter = map[string]interface{}{
			"user_id": user.ID,
			"status":  1,
		}

		one, _ := c.read.SecretUserIdentificationCard.FindOne(ctx, filter)
		if one == nil {
			notFound = append(notFound, user.ID)

			update := map[string]interface{}{
				"ulevel": 4,
			}

			if err = c.write.SecretUserExtInfo.UpdateByUserIdCache(ctx, user.ID, update); err != nil {
				logger.Infof(ctx, "update suc: userId: %v, error: %v", user.ID, err)
			} else {
				logger.Infof(ctx, "update suc: userId: %v", user.ID)
			}

			msg := `为维护友好的社区氛围，对于未完成实名认证的用户将降到“Lv.4 高级猫”。
请您前往“发现”-“签到升级”中完成实名认证即可升级至“Lv.5 大师猫”～`

			contents := make([]*model.PersonalUserNotificationContentMgField, 0)
			field := &model.PersonalUserNotificationContentMgField{
				Sort:    1,
				Type:    3,
				Content: msg,
			}
			contents = append(contents, field)

			item := &model.PersonalUserNotificationMgModel{
				ID:        snow_flake.GetSnowflakeID(),
				UserId:    user.ID,
				Timestamp: time.Now().UnixNano() / 1e6,
				Type:      2,
				Title:     "猫爪客服",
				AppType:   []int32{0},
				Html:      msg,
				Contents:  contents,
				IsNew:     1,
			}

			if res, err := c.write.PersonalUserNotificationMgModel.Insert(ctx, item); err != nil {
				logger.Errorf(ctx, "insert error: %v", err)
				continue
			} else {
				fmt.Println(res)
			}

			if err != nil {
				logger.Error(ctx, fmt.Sprintf("PersonalUserNotificationMgDbImpl.Insert  failed. item=%v", item), err)
			}

			sucs = append(sucs, user.ID)

			continue
		}
		found = append(found, user.ID)
	}

	logger.Infof(ctx, "userLen: %v", len(users))

	logger.Infof(ctx, "found: %v", found)
	logger.Infof(ctx, "foundLen: %v", len(found))

	logger.Infof(ctx, "notFound: %v", notFound)
	logger.Infof(ctx, "notFoundLen: %v", len(notFound))

	logger.Infof(ctx, "suc: %v", sucs)
	logger.Infof(ctx, "sucLen: %v", len(sucs))

	return

}
