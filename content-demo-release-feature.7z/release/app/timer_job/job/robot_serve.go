package job

type robotServerControl struct {
	robotControl
}

// RobotServerControl 飞书serve群里的机器人
var RobotServerControl robotServerControl

func InitServeRobot() {
	RobotServerControl = robotServerControl{}
	RobotServerControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/c02670dc-de16-4af0-a234-d90af25c6f13"
	RobotServerControl.msgChan = make(chan Message, 10)

	go RobotServerControl.monitor()
}
