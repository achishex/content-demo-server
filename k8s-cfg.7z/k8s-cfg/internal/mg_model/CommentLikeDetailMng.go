package mg_model

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ICommentLikeDetailMgModel interface {
	InsertNewOrUpdateOld(ctx context.Context, item *pbmgdb.CommentLikeDetailMgDbModel) (int32, error)
	UpdateItemByCond(ctx context.Context, item *pbmgdb.CommentLikeDetailMgDbModel) (int32, error)
	GetLikeStatus(ctx context.Context, eqConds, largeConds, lessConds map[string]interface{}, specialField map[string]int32) ([]map[string]interface{}, error)
	GetHasLikedNums(ctx context.Context, filter bson.M) (int64, error)
}

type CommentLikeDetailMgDbImpl struct {
	MgDB *mongo.Database
}

func NewCommentLikeDetailMgModelImpl(db *mongo.Database) ICommentLikeDetailMgModel {
	return &CommentLikeDetailMgDbImpl{MgDB: db}
}
func (impl *CommentLikeDetailMgDbImpl) collection() string {
	return "comment_like_detail"
}

const (
	LikeUpdateSucc       int32 = 1
	LikeUpdateInsertSucc int32 = 2
	LikeUpdateFail       int32 = 3
	LikeUpdateRepeated   int32 = 4
)
const (
	UnLikeUpdateSucc     int32 = 1
	UnLikeUpdateFail     int32 = 3
	UnLikeUpdateRepeated int32 = 4
)

func (impl *CommentLikeDetailMgDbImpl) GetHasLikedNums(ctx context.Context, filter bson.M) (int64, error) {
	if len(filter) <= 0 {
		return 0, nil
	}

	coll := impl.MgDB.Collection(impl.collection())
	nums, err := coll.CountDocuments(ctx, filter)
	return nums, err
}
func (impl *CommentLikeDetailMgDbImpl) GetLikeStatus(ctx context.Context, eqConds, largeConds, lessConds map[string]interface{}, specialField map[string]int32) ([]map[string]interface{}, error) {
	coll := impl.MgDB.Collection(impl.collection())
	filter := bson.D{}
	for k, v := range eqConds {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	for k, v := range largeConds {
		filter = append(filter, bson.E{k, bson.D{{"$gt", v}}})
	}
	for k, v := range lessConds {
		filter = append(filter, bson.E{k, bson.D{{"$lt", v}}})
	}
	//
	var projection bson.D
	for k, v := range specialField {
		projection = append(projection, bson.E{Key: k, Value: v})
	}
	opts := options.Find().SetProjection(projection)
	cursor, err := coll.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "find comment detail fail, err: %v", err)
		return nil, err
	}
	//
	var retData []map[string]interface{}
	for cursor.Next(ctx) {
		var result bson.M
		err = cursor.Decode(&result)
		if err != nil {
			logger.Errorf(ctx, "get comment detail query result fail, err: %v", err)
			return nil, err
		}

		var tmpRet map[string]interface{}
		for k, v := range result {
			if tmpRet == nil {
				tmpRet = make(map[string]interface{})
			}
			tmpRet[k] = v
		}
		retData = append(retData, tmpRet)
	}
	return retData, nil
}
func (impl *CommentLikeDetailMgDbImpl) UpdateItemByCond(ctx context.Context, item *pbmgdb.CommentLikeDetailMgDbModel) (int32, error) {
	coll := impl.MgDB.Collection(impl.collection())
	filter := bson.D{
		{"likerUserId", item.GetLikerUserId()},
		{"workId", item.GetWorkId()},
		{"commentId", item.GetCommentId()},
		{"doLike", const_busi.LikedOp}, //目前只针对点赞的记录进行更新，状态变为取消状态。
	}

	update := bson.D{
		{"$set", bson.D{ //更新字段
			{"doLike", const_busi.UnLikedOp},
			{"updateTime", item.GetUpdateTime()}},
		},
	}
	opRet, err := coll.UpdateOne(ctx, filter, update)
	if err != nil {
		logger.Errorf(ctx, "op to tab from liked to unliked: %v fail, work id: %v, userId: %v, err: %v",
			impl.collection(), item.GetWorkId(), item.GetLikerUserId(), err)
		if mongo.IsDuplicateKeyError(err) {
			return UnLikeUpdateRepeated, nil
		}
		return UnLikeUpdateFail, err
	}
	logger.Infof(ctx, "op to tab from tab from liked to unliked: %v, work id: %v, user_id: %v, modify nums: %v, upsert nums: %v, filter_hit nums: %v",
		impl.collection(), item.GetWorkId(), item.GetLikerUserId(), opRet.ModifiedCount, opRet.UpsertedCount, opRet.MatchedCount)
	if opRet.MatchedCount == 1 {
		return UnLikeUpdateSucc, nil
	}
	if opRet.ModifiedCount <= 0 {
		return UnLikeUpdateRepeated, nil
	}
	return UnLikeUpdateFail, nil
}

// return: int32 表示是更新状态成功 1，插入新记录成功 2， 失败：更新操作操作失败 3，重复更新操作 4
func (impl *CommentLikeDetailMgDbImpl) InsertNewOrUpdateOld(ctx context.Context, item *pbmgdb.CommentLikeDetailMgDbModel) (int32, error) {
	coll := impl.MgDB.Collection(impl.collection())
	filter := bson.D{
		{"likerUserId", item.GetLikerUserId()},
		{"workId", item.GetWorkId()},
		{"commentId", item.GetCommentId()},
		{"doLike", const_busi.UnLikedOp}, //目前只针对取消点赞状态进行更新， 不存在或者存在相同的则插入，因为有位移索引，所以插入相同会返回失败。
	}

	update := bson.D{
		{"$set", bson.D{ //更新字段
			{"doLike", const_busi.LikedOp},
			{"updateTime", item.GetUpdateTime()}},
		},
		{"$setOnInsert", bson.D{ //不满足filter时，插入这些字段；满足filter发生更新，不做处理
			{"createTime", item.GetCreateTime()},
			{"_id", item.GetId()},
			{"likerUserId", item.GetLikerUserId()},
			{"workId", item.GetWorkId()},
			{"commentId", item.GetCommentId()}},
		},
	}
	opts := options.Update().SetUpsert(true)
	opRet, err := coll.UpdateOne(ctx, filter, update, opts)
	if err != nil {
		logger.Errorf(ctx, "op to tab: %v fail, work id: %v, userId: %v, err: %v", impl.collection(), item.GetWorkId(), item.GetLikerUserId(), err)
		if mongo.IsDuplicateKeyError(err) {
			return LikeUpdateRepeated, nil
		}
		return LikeUpdateFail, err
	}
	logger.Infof(ctx, "op to tab: %v, work id: %v, user_id: %v, modify nums: %v, upsert nums: %v, filter_hit nums: %v",
		impl.collection(), item.GetWorkId(), item.GetLikerUserId(), opRet.ModifiedCount, opRet.UpsertedCount, opRet.MatchedCount)
	if opRet.MatchedCount == 1 {
		return LikeUpdateSucc, nil
	}
	if opRet.ModifiedCount <= 0 {
		return LikeUpdateInsertSucc, nil
	}
	return LikeUpdateInsertSucc, nil
}
