package model

import (
	"content_svr/db/redisdb/model/internal"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"time"
)

type TokenContentSvr struct {
	internal.RdsInfo
}

func NewTokenContentSvr(rds *redis.Client, env string) *TokenContentSvr {
	return &TokenContentSvr{
		RdsInfo: internal.RdsInfo{
			Env:    env,
			Expire: time.Hour * 24,
			Client: rds,
		},
	}
}

func (t *TokenContentSvr) getRdsKeyUserId(userId int64) string {
	return fmt.Sprintf("platform:%v:soul_soup:login_id:%d", t.Env, userId)
}

func (t *TokenContentSvr) getRdsKeyTokenInfo(token string) string {
	return fmt.Sprintf("platform:%v:soul_soup:login_token:%v", t.Env, token)
}

func (t *TokenContentSvr) DelToken(ctx context.Context, userId int64) error {
	userIdRdsKey := t.getRdsKeyUserId(userId)

	token, err := t.Client.Get(ctx, userIdRdsKey).Result()
	switch err {
	case redis.Nil:
		return nil
	case nil:
		break
	default:
		return err
	}

	if _, err := t.Client.Del(ctx, userIdRdsKey).Result(); err != nil {
		return err
	}

	if _, err := t.Client.Del(ctx, t.getRdsKeyTokenInfo(token)).Result(); err != nil {
		return err
	}
	return nil
}
