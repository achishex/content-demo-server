package pay_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	localUtils "content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/wechatpay-apiv3/wechatpay-go/core"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments/app"
	"github.com/wechatpay-apiv3/wechatpay-go/utils"
	"strconv"
	"time"
)

func (p *PayMng) GenAppSign(ctx context.Context, prepayId string) AppSignResp {
	appId := config.ServerConfig.WechatConfig.AppId
	mchId := config.ServerConfig.WechatConfig.MchID
	nonceStr := snow_flake.GetSnowflakeID()
	ts := time.Now().Unix()
	source := fmt.Sprintf("%s\n%v\n%v\n%s\n", appId, ts, nonceStr, prepayId)
	logger.Infof(ctx, "source str: %s", source)

	wPath, err := localUtils.GetWorkPath()
	if err != nil {
		panic(fmt.Sprintf("get workpath failed. err:%v", err.Error()))
	}

	mchPrivateKey, err := utils.LoadPrivateKeyWithPath(wPath + "/cert/" + config.ServerConfig.WechatConfig.PrivateKeyFile)
	if err != nil {
		logger.Errorf(ctx, "load private key file fail, err: %v", err)
		return AppSignResp{}
	}

	rsaSign, err := utils.SignSHA256WithRSA(source, mchPrivateKey)
	if err != nil {
		return AppSignResp{}
	}
	return AppSignResp{
		MchId:     mchId,
		PrepayId:  prepayId,
		NonceStr:  strconv.FormatInt(nonceStr, 10),
		Timestamp: strconv.FormatInt(ts, 10),
		Sign:      rsaSign,
	}
}

// 查询微信订单状态
func (p *PayMng) QueryOrderByOutTradeNo(ctx context.Context, req *pbapi.QueryOrderByOutTradeNoReq) (*pbapi.QueryOrderByOutTradeNoResp, error) {
	prepay, err := p.WxProxy.QueryOrderByOutTradeNo(ctx, app.QueryOrderByOutTradeNoRequest{
		OutTradeNo: core.String(req.GetOutTradeNo()),
		Mchid:      core.String(config.ServerConfig.WechatConfig.MchID),
	})
	if err != nil {
		logger.Errorf(ctx, "call wechatPay prepay fail : %v", err)
		return nil, errorcode.PreCreateOrderError
	}

	if prepay == nil {
		return nil, nil
	}

	return &pbapi.QueryOrderByOutTradeNoResp{
		Appid:          prepay.Appid,
		Attach:         prepay.Attach,
		BankType:       prepay.BankType,
		OutTradeNo:     prepay.OutTradeNo,
		SuccessTime:    prepay.SuccessTime,
		TradeState:     prepay.TradeState,
		TradeStateDesc: prepay.TradeStateDesc,
		TradeType:      prepay.TradeType,
		TransactionId:  prepay.TransactionId,
	}, nil
}
