package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/data_cache"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"content_svr/setting"
	"context"
	"github.com/gogo/protobuf/proto"
	"time"
)

type IPrivateMessageCheck interface {
	CheckIsMutualUsers(ctx context.Context) error
	CheckIsInUserBlackList(ctx context.Context) error
	CheckPermissionInSession(ctx context.Context) error
	CheckPermissionNotInSession(ctx context.Context) error
	CheckInSession(ctx context.Context) bool
}

func NewCheckPrivateMessageInstance(imp *ContentMng, curUserInfo *data_cache.UserInfoLocal, toUserId int64) IPrivateMessageCheck {
	return &privateMsgCheckInstance{
		imp:            imp,
		curUserInfo:    curUserInfo,
		toUserId:       toUserId,
		defaultWorkId:  const_busi.HomePagePrivateMessageDefaultWorkId,
		defaultModType: int32(pbconst.PtModelTypeEnum_pt_model_type_normal),
	}
}

type privateMsgCheckInstance struct {
	imp            *ContentMng
	curUserInfo    *data_cache.UserInfoLocal
	toUserId       int64
	defaultWorkId  int64
	defaultModType int32
}

func (p *privateMsgCheckInstance) CheckIsMutualUsers(ctx context.Context) error {
	if isMutual, err := p.imp.DataCache.GetImpl().SecretUserFollowMgModel.GetBothFollow(ctx, p.curUserInfo.UserInfoDbModel.GetUserId(), p.toUserId); err == nil && isMutual == int32(pbconst.MutualEnum_mutual_yes) {
		return nil
	}
	return errors.New("not mutual users")
}
func (p *privateMsgCheckInstance) CheckIsInUserBlackList(ctx context.Context) error {
	//检查 当前用户是否被 toUserId 拉黑
	if isIn := p.imp.DataCache.CheckUserBlackListMgDBLD(ctx, p.toUserId, p.curUserInfo.UserInfoDbModel.GetUserId()); isIn {
		return errorcode.HomePagePrivateMsgInBlack
	}
	return nil
}
func (p *privateMsgCheckInstance) CheckPermissionInSession(ctx context.Context) error {
	return nil
}

// 0: {0, "小猫崽", 0, 0, 2, 0, 0, 2, "", nil},
// 1: {1, "小奶猫", 49, 49, 10, 7, 1, 10, "", nil},
// 2: {2, "初级猫", 99, 199, 20, 3, 0, 20, "", nil},
// 3: {3, "中级猫", 199, 399, 30, 7, 1, 30, "", nil},
// 4: {4, "高级猫", 699, 999, 40, 30, 6, 40, "", nil},
func testMockTempSessionNumsOnLevel(level int32) int32 {
	mockLevelInfo := map[int32]int32{
		0: 2,
		1: 3,
		2: 4,
		3: 5,
		4: 6,
	}
	if ret, ok := mockLevelInfo[level]; ok {
		return ret
	} else {
		return 2
	}
}
func CheckPermissionOnLevel(ctx context.Context, level int32, talkedNums int32) bool {
	levelInfo := const_busi.GetLevelCfg(ctx, level)
	if levelInfo == nil {
		logger.Infof(ctx, "level info is nil")
		return false // no level, no permission
	}
	logger.Infof(ctx, "user level: %v, limit nums: %v", level, levelInfo.DailyTalkNewObjNums)
	if talkedNums >= levelInfo.DailyTalkNewObjNums {
		logger.Infof(ctx, "max talk obj nums: %v, has talked nums: %v",
			levelInfo.DailyTalkNewObjNums, talkedNums)
		return false // no permission
	}

	logger.Infof(ctx, "quding max talk obj nums: %v, has talked nums: %v",
		levelInfo.DailyTalkNewObjNums, talkedNums)
	return true
}
func (p *privateMsgCheckInstance) GetTalkedNumsOnToUser(ctx context.Context, todayTime int64) (uint32, error) {
	//id :4094329043423232
	eqConds := map[string]interface{}{
		"toUserId": p.toUserId,
		"workId":   const_busi.HomePagePrivateMessageDefaultWorkId,
		"status":   1,
	}
	largeConds := map[string]interface{}{
		"create_time": todayTime,
	}
	nums, err := p.imp.DataCache.GetImpl().PersonalTalkMessageTotalMgDbModel.GetFromUserNumsByConds(ctx, eqConds, largeConds, nil)
	if err != nil {
		logger.Errorf(ctx, "get talk nums on to user: %v fail, err: %v", p.toUserId, err)
	}
	return uint32(nums), nil
}
func getValidSessionBeginTimeMill(ctx context.Context) int64 {
	beforeThreeTime := time.Now().AddDate(0, 0, const_busi.HomePagePrivateMessageSessionValidDays*-1)
	preTimeMill := beforeThreeTime.UnixMilli()
	if config.ServerConfig.MessageTalkConfig != nil {
		validMinutes := setting.Maozhua.TempSessionValidMinute.Get()
		preTimeMill = time.Now().Add(-time.Duration(validMinutes) * time.Minute).UnixMilli()
	}
	logger.Infof(ctx, "get valid session begin time mill: %v", preTimeMill)
	return preTimeMill
}
func (p *privateMsgCheckInstance) CheckInSession(ctx context.Context) bool {
	//查询3天内有效的临时会话记录.
	uniqueId := genUniqueId(p.curUserInfo.UserInfoDbModel.GetUserId(), p.toUserId, p.defaultWorkId, p.defaultModType)

	seqTime := snow_flake.GetNextId(getValidSessionBeginTimeMill(ctx))
	largeCond := map[string]interface{}{
		"_id": seqTime,
	}
	eqCond := map[string]interface{}{
		"uniqueId": uniqueId,
		"toUserId": p.toUserId,
		"workId":   const_busi.HomePagePrivateMessageDefaultWorkId,
	}
	existTalk, err := p.imp.DataCache.GetImpl().PersonalTalkMessageTotalMgDbModel.CheckIdExists(ctx, eqCond, largeCond, nil)
	if err != nil {
		logger.Errorf(ctx, "get PersonalTalkMessageTotal fail, err: %v", err)
	}
	if existTalk {
		logger.Infof(ctx, "has exist valid talk session")
		return true
	}
	return false
}

//	func getTalkedMaxNumsCfg() int32 {
//		var talkedMaxTimes int32 = const_busi.HomePagePrivateMessageFreeTalkedMaxTimes
//		if config.ServerConfig.MessageTalkConfig != nil {
//			talkedMaxTimes = int32(config.ServerConfig.MessageTalkConfig.DailyFreePrivateTalkMaxNums)
//		}
//		return talkedMaxTimes
//	}
func GetTodayBeginIdNums() int64 {
	todayTime := time.Date(time.Now().Year(), time.Now().Month(), time.Now().Day(), 0, 0, 0, 0, time.Local).UnixMilli()
	todayTimeSeq := snow_flake.GetNextId(int64(todayTime))
	return todayTimeSeq
}
func (p *privateMsgCheckInstance) CheckPermissionNotInSession(ctx context.Context) error {
	//需要查看： 单日私聊新猫友的上限数，不包括互爪好友私聊，包括基于作品的私聊，临时会话私聊
	if p.curUserInfo.MemberType > 0 {
		logger.Infof(ctx, "user: %v is vip", p.curUserInfo.UserInfoDbModel.GetUserId())
		return nil
	}

	todayTime := time.Date(time.Now().Year(), time.Now().Month(), time.Now().Day(), 0, 0, 0, 0, time.Local).UnixMilli()
	//查询被聊用户当天免费被聊人数
	/** 2023-11-13 删除私聊限制 https://project.feishu.cn/maozhua/story/detail/21436180?parentUrl=%2Fmaozhua%2FstoryView%2FShiHn234R
	talkedNums, err := p.GetTalkedNumsOnToUser(ctx, todayTime)
	if err != nil {
		logger.Errorf(ctx, "get talked nums for user: %v fail, err: %v", p.toUserId, err)
	}
	if talkedNums >= setting.Maozhua.TalkByOtherMaxCount.Get() {
		logger.Infof(ctx, "user: %v talked nums is max times: %v", p.toUserId, talkedNums)
		return errorcode.HomePagePrivateMsgDisable
	} */

	// 当前用户私聊别人
	largeCond := map[string]interface{}{
		"create_time": todayTime,
	}
	eqCond := map[string]interface{}{
		"fromUserId": p.curUserInfo.UserInfoDbModel.GetUserId(),
		"status":     1,
	}
	noEqCond := map[string]interface{}{
		"workId": const_busi.WorkIdOnMutualUsers,
	}
	talkedObj, err := p.imp.DataCache.GetImpl().PersonalTalkMessageTotalMgDbModel.GetToUserNumsByConds(ctx, eqCond, largeCond, nil, noEqCond)
	if err != nil {
		logger.Errorf(ctx, "get talked object nums fail, err: %v", err)
	}
	for _, v := range talkedObj {
		if v == p.toUserId {
			logger.Infof(ctx, "to user has talked, %v", p.toUserId)
			return nil
		}
	}
	talkedObjNums := int32(len(talkedObj))
	if !CheckPermissionOnLevel(ctx, p.curUserInfo.PsecretUserExtInfo.GetUlevel(), talkedObjNums) {
		logger.Errorf(ctx, "has no permission as level low")
		return errorcode.HomePagePrivateMsgUsedUp
	}
	if p.curUserInfo.IsInBlackHouse && talkedObjNums >= 2 { //小黑屋只能了聊2个人。
		logger.Errorf(ctx, "user is in BlackHouse and talked obj nums more than 2")
		return errorcode.HomePagePrivateMsgUsedUp
	}
	return nil
}

var (
	checkRetIsMutual       int32 = 1 //检查结果是互爪好友
	checkRetSessionValid   int32 = 2 //检查结果是存在有效会话
	checkRetSessionInvalid int32 = 3 //检查结果是存在无效会话
)

func (p *ContentMng) checkProcess(ctx context.Context, loginUserInfo *data_cache.UserInfoLocal, req *pbapi.HomePagePrivateMessageCheck) (int32, error) {
	procInstance := NewCheckPrivateMessageInstance(p, loginUserInfo, req.GetToUserId())
	if procInstance.CheckIsInUserBlackList(ctx) != nil {
		logger.Infof(ctx, "%v in %v black list", loginUserInfo.UserInfoDbModel.GetUserId(), req.GetToUserId())
		return 0, errorcode.HomePagePrivateMsgInBlack
	}
	//
	if procInstance.CheckIsMutualUsers(ctx) == nil {
		logger.Infof(ctx, "is mutual, toUser: %v", req.GetToUserId())
		return checkRetIsMutual, nil
	}
	isIn := procInstance.CheckInSession(ctx)
	if isIn {
		// add other check in session.
		if err := procInstance.CheckPermissionInSession(ctx); err != nil {
			logger.Infof(ctx, "has valid session but no permission")
			return 0, err
		}
		return checkRetSessionValid, nil
	}
	if err := procInstance.CheckPermissionNotInSession(ctx); err != nil {
		logger.Infof(ctx, "have no valid session and no permission")
		return 0, err
	}
	return checkRetSessionInvalid, nil
}
func (p *ContentMng) CheckHomePagePrivateMessagePermission(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.HomePagePrivateMessageCheck) error {
	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil || loginUserInfo == nil {
		logger.Errorf(ctx, "not login in CheckHomePagePrivateMessagePermission")
		return errorcode.MIDAS_LOGIN_ERROR
	}

	if p.GetUserInfoTalkMode(ctx, req.ToUserId) == const_busi.TalkModeClose {
		return errorcode.TalkModeCloseForbiddenError
	}

	_, err = p.checkProcess(ctx, loginUserInfo, req)
	return err
}

type IPrivateMessagePush interface {
	SendPrivateMessage(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.HomePagePrivateMessagePushResp, error)
}

func NewPushMessageInstance(ctx context.Context, instanceType int32, req *pbapi.HomePagePrivateMessagePushReq, curUserInfo *data_cache.UserInfoLocal, impl *ContentMng) IPrivateMessagePush {
	switch instanceType {
	case checkRetIsMutual:
		logger.Infof(ctx, "is mutual users")
		return &MutualUserPush{
			commonReqRes: commonReqRes{
				req:         req,
				curUserInfo: curUserInfo,
				impl:        impl,
			},
		}
	case checkRetSessionValid:
		logger.Infof(ctx, "is exist session")
		return &SessionValidPush{
			commonReqRes: commonReqRes{
				req:         req,
				curUserInfo: curUserInfo,
				impl:        impl,
			},
		}
	case checkRetSessionInvalid:
		logger.Infof(ctx, "is new session")
		return &SessionInValidPush{
			commonReqRes: commonReqRes{
				req:         req,
				curUserInfo: curUserInfo,
				impl:        impl,
			},
		}
	}
	return nil
}

type commonReqRes struct {
	req         *pbapi.HomePagePrivateMessagePushReq
	curUserInfo *data_cache.UserInfoLocal
	toUserInfo  *data_cache.UserInfoLocal
	impl        *ContentMng
}

func (p *commonReqRes) checkTemporarySessionParameters(ctx context.Context) error {
	if p.req.GetWorkId() != const_busi.HomePagePrivateMessageDefaultWorkId {
		logger.Errorf(ctx, "req privateMessage on temporary session fail, workId: %v", p.req.GetWorkId())
		return errorcode.MIDAS_PARAMS_ERROR
	}
	return nil
}
func (p *commonReqRes) procNeMutualAuth(ctx context.Context, msgType int32, memeId int64, session *SendMsgSession) string {
	retMsg := ""
	switch msgType {
	case int32(pbconst.MessageTypeEnum_msg_type_voice):
		// 未互关，不允许发
		return "暂无权限"
	case int32(pbconst.MessageTypeEnum_msg_type_pic):
		// 金牌猫友之前，不允许发
		if session.toWindow == nil || (session.toWindow != nil && session.toWindow.GetPushedInteract() == false) {
			// 还没开始聊 或者开聊后还没达成金牌猫友
			return "请先解锁金牌猫友"
		}
		// 金牌猫友以后，lv3和lv4才能发自定义表情和图片。
		if session.curUserInfo.PsecretUserExtInfo.GetUlevel() < 3 {
			return "等级不够，暂无权限"
		}
		// 小黑屋不能发图
		if session.curUserInfo.IsInBlackHouse == true {
			logger.Infof(ctx, "user is in blackhouse")
			return "暂无权限"
		}
	case int32(pbconst.MessageTypeEnum_msg_type_emoji):
		if memeId <= 100 {
			//系统表情
			return retMsg
		}
		// 金牌猫友之前， 系统表情以外的，不能发。
		if session.toWindow == nil || (session.toWindow != nil && session.toWindow.GetPushedInteract() == false) {
			// 还没开始聊 或者开聊后还没达成金牌猫友
			return "请先解锁金牌猫友"
		}
		// 金牌猫友以后，lv3和lv4才能发自定义表情和图片。
		if session.curUserInfo.PsecretUserExtInfo.GetUlevel() < 3 {
			return "等级不够，暂无权限"
		}
		// 小黑屋不能发图
		if session.curUserInfo.IsInBlackHouse == true {
			logger.Infof(ctx, "user is in blackhouse")
			return "暂无权限"
		}
	}
	return retMsg
}

func (p *commonReqRes) processNoOfficial(ctx context.Context, header *pbapi.HttpHeaderInfo,
	req *pbapi.SendMsgReq, session *SendMsgSession, uniqueId int32) error {
	//
	var err error
	pass := p.impl.checkContent(ctx, header, req, session)
	if !pass {
		// 内容检查不通过。 吞掉内容不报错
		_, err = p.impl.saveHiddenRecord(ctx, header, req, session, uniqueId)
		if err != nil {
			logger.Error(ctx, "saveHiddenRecord failed. ", err)
			return err
		}
		logger.Infof(ctx, "checkContent not pass. over.kw_check=%v, content=%v", pass, req.GetContent())
		return errorcode.HomePagePrivateMsgSwallow
	}
	return nil
}
func (p *commonReqRes) checkLogicBefore(ctx context.Context, header *pbapi.HttpHeaderInfo) error {
	curUserId := p.curUserInfo.UserInfoDbModel.GetUserId()
	curUserInfo := p.curUserInfo
	dataCache := p.impl.DataCache
	req := p.req

	var err error
	if p.curUserInfo.PsecretUserExtInfo == nil {
		curUserInfo.PsecretUserExtInfo, err = dataCache.GetImpl().UserInfoExtMgModel.GetAndCreate(ctx, curUserId)
		if err != nil {
			logger.Error(ctx, "PsecretUserExtInfo is nil, and create it failed", err)
		}
		logger.Infof(ctx, "PsecretUserExtInfo create it, curUserId=%v,toUserId=%v", curUserId, req.GetToUserId())
	}

	//不允许给自己发, tdodo 检查是否当前用户被禁止发言了。
	if curUserId == p.req.GetToUserId() {
		return errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "不能给自己发送消息")
	}

	//1.3 查询 toUser信息
	p.toUserInfo, err = dataCache.GetUserInfoLocal(ctx, header, req.GetToUserId(), false)
	if err != nil || p.toUserInfo == nil {
		return errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "对方账号已注销")
	}

	// 1.5 是否被拉入了黑名单。
	if dataCache.CheckUserBlackListMgDBLD(ctx, curUserId, req.GetToUserId()) {
		// cur把to拉黑了，啥都不干，直接返回
		logger.Infof(ctx, "fromUser is in curUser blacklist, skip.from=%v, cur=%v", curUserId, p.req.GetToUserId())
		return errorcode.HomePagePrivateMsgInBlackActive
	}
	if dataCache.CheckUserBlackListMgDBLD(ctx, req.GetToUserId(), curUserId) {
		// to把cur拉黑了. 报错
		return errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "你被对方拉黑了，对方无法接收你的消息")
	}
	return nil
}
func (p *commonReqRes) procEmoji(ctx context.Context, header *pbapi.HttpHeaderInfo) error {
	//处理emoji图片。
	if p.req.GetMemeId() > 0 {
		// 发emoji
		memeItem := p.impl.DataCache.GetSecretMemeMgDBLd(ctx, p.req.GetMemeId())
		if memeItem != nil {
			p.req.ObjectId = proto.String(memeItem.GetObjectId())
			p.req.High = proto.Int32(memeItem.High)
			p.req.Width = proto.Int32(memeItem.Width)
		} else {
			// 暂时只打印报错，没阻止流程。
			logger.Errorf(ctx, "get GetSecretMemeMgDBLd failed. req=%+v", p.req)
			return errorcode.GenBusiErr(errorcode.DATA_INVALID, "表情不存在")
		}
	}
	return nil
}
func (p *commonReqRes) checkLogicAfter(ctx context.Context, header *pbapi.HttpHeaderInfo, session *SendMsgSession, uniqueId int32, basicReq *pbapi.SendMsgReq) (*pbapi.HomePagePrivateMessagePushResp, error) {
	resp := &pbapi.HomePagePrivateMessagePushResp{}
	// 1. 10 根据请求或者根据ip来获取对方位置信息。
	session.curCoordinate = p.impl.getCoordinate(ctx, header, session.curUserId, p.req.Latitude, p.req.Longitude)
	// 至此全部session资料收集完毕 =======

	// step 5.1 写record  包含是否能发图片的检查，图片是否违规的检查。
	record, err := p.impl.sendMsgBase(ctx, header, basicReq, session, uniqueId)
	if err != nil {
		logger.Warnf(ctx, "sendMsgBase failed,  err=%v", err)
		return resp, err
	}

	//达到双方互动次数阈值
	interactAddFriedTimes := p.impl.DataCache.GetTimesConfigLR(ctx, "secret_interact_add_friend_times")
	if session.workId > 0 && interactAddFriedTimes > 0 {
		if session.fromWindow != nil && session.toWindow != nil &&
			session.toWindow.GetInteractTimes() >= int32(interactAddFriedTimes-1) &&
			session.fromWindow.GetInteractTimes() >= int32(interactAddFriedTimes) &&
			session.toWindow.GetPushedInteract() != true &&
			session.fromWindow.GetPushedInteract() != true {
			// 发送猫友勋章, 只发送一次。
			err = p.impl.pushInteractMessage(ctx, session)
			if err != nil {
				logger.Error(ctx, "pushInteractMessage failed.", err)
			}
		}
	}
	// 封装应答
	resp.SessionId = session.fromWindow.GetId()
	resp.MessageId = record.GetId()
	resp.CreateTime = record.GetCreateTime()
	resp.Status = 1
	resp.FromCoordinate = &pbapi.Coordinate{
		Longitude: session.fromWindow.FromLng,
		Latitude:  session.fromWindow.FromLat,
		Province:  session.fromWindow.FromProvince,
		City:      session.fromWindow.FromCity,
	}
	resp.ToCoordinate = &pbapi.Coordinate{
		Longitude: session.fromWindow.ToLng,
		Latitude:  session.fromWindow.ToLat,
		Province:  session.fromWindow.ToProvince,
		City:      session.fromWindow.ToCity,
	}
	return resp, nil
}

type MutualUserPush struct {
	commonReqRes
}

func (p *MutualUserPush) SendPrivateMessage(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.HomePagePrivateMessagePushResp, error) {
	resp := &pbapi.HomePagePrivateMessagePushResp{}
	if err := p.commonReqRes.checkLogicBefore(ctx, header); err != nil {
		if err == errorcode.HomePagePrivateMsgInBlackActive {
			return resp, nil
		}
		return nil, err
	}

	curUserId := p.curUserInfo.UserInfoDbModel.GetUserId()
	curUserInfo := p.curUserInfo
	dataCache := p.impl.DataCache
	toUserInfo := p.toUserInfo
	req := p.req

	session := &SendMsgSession{
		curUserId:   curUserId,
		curUserInfo: curUserInfo,
		toUserId:    toUserInfo.UserInfoDbModel.GetUserId(),
		toUserInfo:  toUserInfo,
		modeType:    int32(pbconst.PtModelTypeEnum_pt_model_type_normal),
	}

	session.workId = -1
	uniqueId := genUniqueId(curUserId, req.GetToUserId(), session.workId, session.modeType)

	// 1.8 基于workid之下的检查
	session.toWindow = dataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, req.GetToUserId()) // 正向
	session.fromWindow = dataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, curUserId)       // 反向
	logger.Infof(ctx, "=====uniqueId=2%v, curUserId=%v, touserid=%v, workid=%v, req.workid=%v towindow=%v, fromWindow=%v",
		uniqueId, curUserId, req.GetToUserId(), session.workId, req.GetWorkId(), session.toWindow, session.fromWindow)

	//处理emoji图片。
	if p.procEmoji(ctx, header) != nil {
		return resp, nil
	}

	basicReq := &pbapi.SendMsgReq{
		ToUserId:    req.ToUserId,
		Content:     req.Content,
		WorkId:      req.WorkId,
		MessageType: req.MessageType,
		Width:       req.Width,
		High:        req.High,
		Duration:    req.Duration,
		ObjectId:    req.ObjectId,
		ClientId:    req.ClientId,
		MemeId:      req.MemeId,
		SessionType: req.SessionType,
		Longitude:   req.Longitude,
		Latitude:    req.Latitude,
	}
	//业务检查
	iMutualUserPushOfficial := NewMutualSessionOfficial(header, basicReq, session, uniqueId, p)
	ret, err := iMutualUserPushOfficial.NotNeedDoLogic(ctx, curUserId)
	if err != nil || ret == 1 {
		return resp, err
	}
	err = iMutualUserPushOfficial.NeedDoLogic(ctx)
	if err != nil {
		return resp, err
	}

	return p.checkLogicAfter(ctx, header, session, uniqueId, basicReq)
}

// SessionValidPush 有效临时会话（3天内）
type SessionValidPush struct {
	commonReqRes
}

func (p *SessionValidPush) checkDailyTalkNewUserNums(ctx context.Context, header *pbapi.HttpHeaderInfo,
	session *SendMsgSession, uniqueId int32) (int32, error) {
	//检查 curUser私聊新猫友的线上限
	//has check in CheckPermissionInSession()
	replyType := int32(0) // 1-用户首次回复帖子   2-作者首次回复当前用户
	timesCfgKey := "times_replay_limit"
	if session.curUserInfo.UserInfoDbModel.GetGender() == int32(pbconst.Sex_female) {
		timesCfgKey = timesCfgKey + "_female"
	} else {
		timesCfgKey = timesCfgKey + "_male"
	}
	//
	workReplyCount := int32(0)
	if session.workInfo != nil {
		workReplyCount = session.workInfo.WorkInfoDbModel.GetReplayCount()
	}
	switch header.Apptype {
	case cm_const.AppTypeAppletQq, cm_const.AppTypeAppletWx:
		if header.Apptype == cm_const.AppTypeAppletQq {
			timesCfgKey = timesCfgKey + "_qq"
		} else {
			timesCfgKey = timesCfgKey + "_wx"
		}
		timesCfgKey = timesCfgKey + "_" + header.Platform

		timesCfg := p.impl.DataCache.GetTimesConfigLR(ctx, timesCfgKey)
		logger.Infof(ctx, "=====timesCfgKey=%v, timsCfg=%v, workReplyCount=%v", timesCfgKey, timesCfg, workReplyCount)
		if timesCfg >= -1 &&
			workReplyCount >= int32(timesCfg) &&
			session.curUserInfo.MemberType <= 0 &&
			header.Platform == cm_const.PlatformAndroid {
			return replyType, errorcode.GenBusiErr(errorcode.BusinessError, "回复太火了，只有VIP才可回复")
		}
	case cm_const.AppTypeMobileIos:
		timesCfgKey = timesCfgKey + "_ios"
		timesCfg := p.impl.DataCache.GetTimesConfigLR(ctx, timesCfgKey)
		logger.Infof(ctx, "=====timesCfgKey=%v, timsCfg=%v, workReplyCount=%v", timesCfgKey, timesCfg, workReplyCount)
		if timesCfg >= -1 &&
			workReplyCount >= int32(timesCfg) &&
			session.curUserInfo.MemberType <= 0 {
			return replyType, errorcode.GenBusiErr(errorcode.BusinessError, "回复太火了，只有VIP才可回复")
		}
	case cm_const.AppTypeMobileAndroid:
		timesCfgKey = timesCfgKey + "_android"
		timesCfg := p.impl.DataCache.GetTimesConfigLR(ctx, timesCfgKey)
		logger.Infof(ctx, "=====timesCfgKey=%v, timsCfg=%v, workReplyCount=%v", timesCfgKey, timesCfg, workReplyCount)
		if timesCfg >= -1 &&
			workReplyCount >= int32(timesCfg) &&
			session.curUserInfo.MemberType <= 0 {
			return replyType, errorcode.GenBusiErr(errorcode.BusinessError, "回复太火了，只有VIP才可回复")
		}
	}

	// 保存作品消息
	//p.saveWorkRecord(ctx, header, session, uniqueId)
	return replyType, nil
}
func (p *SessionValidPush) saveWorkRecord(ctx context.Context, header *pbapi.HttpHeaderInfo,
	session *SendMsgSession, uniqueId int32) (*pbapi.PersonalTalkMessageRecordMgDbModel, error) {
	curTimeMs := utils.GetCurTsMs()
	record := &pbapi.PersonalTalkMessageRecordMgDbModel{
		Id:          snow_flake.GetSnowflakeID(),
		ModeType:    proto.Int32(session.modeType),
		FromUserId:  proto.Int64(session.curUserId),
		ToUserId:    proto.Int64(session.toUserId),
		Content:     p.req.Content,
		CreateTime:  proto.Int64(curTimeMs),
		Status:      proto.Int32(int32(pbconst.BaseTabStatus_valid)),
		WorkFlag:    proto.Int32(0),
		Read:        proto.Int32(1), // 0
		PushType:    proto.Int32(int32(pbconst.PushTypeEnum_push_type_not_anonymous)),
		WorkId:      proto.Int64(session.workId),
		MessageType: proto.Int32(int32(pbconst.MessageTypeEnum_msg_type_txt)),
		UniqueId:    proto.Int32(uniqueId),
	}

	err := p.impl.DataCache.InsertPersonTalkMsgRecord(ctx, record)
	if err != nil {
		logger.Errorf(ctx, "InsertPersonTalkMsgRecord failed. err=%v", err.Error())
		return record, err
	}
	return record, nil
}
func (p *SessionValidPush) processMsgLimit(ctx context.Context, header *pbapi.HttpHeaderInfo, session *SendMsgSession) error {

	if p.impl.SendSessComp.EnableTalkAD(header.GetVersioncode()) {
		// 未回复时，总发送数
		noreply := session.fromWindow == nil || session.fromWindow.GetInteractTimes() == 0
		if noreply && session.toWindow.GetInteractTimes() >= setting.Maozhua.TalkADNoReplyMaxCount.Get() { //未回复
			return errorcode.TalkADNoReplyError
		}

		// 判断remain
		var ss *pbapi.SendSess
		var err error
		if noreply {
			ss, err = p.impl.SendSessComp.GetNoReplySess(ctx, session.curUserId, session.toUserId, session.toWindow.GetInteractTimes(), session.curUserInfo.MemberType)
		} else {
			ss, err = p.impl.SendSessComp.GetSendSess(ctx, session.curUserId, session.toUserId, session.curUserInfo.MemberType)
		}
		if err != nil {
			logger.Errorf(ctx, "get sess fail, err: %v", err)
			return err
		}

		if ss.Remain <= 0 {
			logger.Warnf(ctx, "sendmsg limit, uid: %v, to: %v, sendsess: %v", session.curUserId, session.toUserInfo, ss)
			return errorcode.TalkADSendSessError
		}

	} else {
		// 检查1 对方未回复的情况下，最多只能发送n条消息。
		if session.fromWindow != nil && session.toWindow != nil && session.fromWindow.GetInteractTimes() == 0 {
			var timeLimit int32 = 1
			switch session.curUserInfo.MemberType {
			case const_busi.NormalUser:
				timeLimit = int32(setting.Maozhua.TalkNoReplyMaxCount.Get())
			case const_busi.VipUser, const_busi.GiftVipUser, const_busi.SVipUser:
				timeLimit = int32(setting.Maozhua.VipTalkNoReplyMaxCount.Get())
			default:
				break
			}

			// 检查
			if session.toWindow.GetInteractTimes() >= timeLimit {
				return errorcode.TalkNoReplyError
			}
		}
	}

	return nil
}
func (p *SessionValidPush) processNoOfficial(ctx context.Context, header *pbapi.HttpHeaderInfo,
	req *pbapi.SendMsgReq, session *SendMsgSession, uniqueId int32) error {
	//add self logic:
	if ret := p.procNeMutualAuth(ctx, p.req.GetMessageType(), req.GetMemeId(), session); len(ret) > 0 {
		logger.Errorf(ctx, "send_msg failed. no right for this msgType. req=%+v, err=%v", req, ret)
		return errorcode.GenBusiErr(errorcode.DATA_INVALID, ret)
	}
	if err := p.processMsgLimit(ctx, header, session); err != nil {
		return err
	}
	if _, err := p.checkDailyTalkNewUserNums(ctx, header, session, uniqueId); err != nil {
		logger.Errorf(ctx, "check daily talk new user nums fail, err: %v", err)
		return err
	}
	return p.commonReqRes.processNoOfficial(ctx, header, req, session, uniqueId)
}
func (p *SessionValidPush) SendPrivateMessage(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.HomePagePrivateMessagePushResp, error) {
	logger.Infof(ctx, "exist session, req: %v", *(p.req))
	//
	resp := &pbapi.HomePagePrivateMessagePushResp{}

	if err := p.checkTemporarySessionParameters(ctx); err != nil {
		logger.Errorf(ctx, "invalid session push fail, err: %v", err)
		return resp, err
	}
	if err := p.commonReqRes.checkLogicBefore(ctx, header); err != nil {
		if err == errorcode.HomePagePrivateMsgInBlackActive {
			return resp, nil
		}
		return nil, err
	}

	curUserId := p.curUserInfo.UserInfoDbModel.GetUserId()
	curUserInfo := p.curUserInfo
	toUserInfo := p.toUserInfo
	req := p.req

	session := &SendMsgSession{
		curUserId:   curUserId,
		curUserInfo: curUserInfo,
		toUserId:    toUserInfo.UserInfoDbModel.GetUserId(),
		toUserInfo:  toUserInfo,
		workId:      req.GetWorkId(),
		modeType:    int32(pbconst.PtModelTypeEnum_pt_model_type_normal),
	}
	uniqueId := genUniqueId(curUserId, req.GetToUserId(), session.workId, session.modeType)
	session.toWindow = p.impl.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, req.GetToUserId()) // 正向
	session.fromWindow = p.impl.DataCache.GetPersonTalkMsgTotalMgDB(ctx, uniqueId, curUserId)       // 反向
	logger.Infof(ctx, "=====uniqueId=1%v, curUserId=%v, touserid=%v, workid=%v, req.workid=%v towindow=%v, fromWindow=%v",
		uniqueId, curUserId, req.GetToUserId(), session.workId, req.GetWorkId(), session.toWindow, session.fromWindow)

	//处理emoji图片。
	if p.procEmoji(ctx, header) != nil {
		return resp, nil
	}
	basicReq := &pbapi.SendMsgReq{
		ToUserId:    req.ToUserId,
		Content:     req.Content,
		WorkId:      req.WorkId,
		MessageType: req.MessageType,
		Width:       req.Width,
		High:        req.High,
		Duration:    req.Duration,
		ObjectId:    req.ObjectId,
		ClientId:    req.ClientId,
		MemeId:      req.MemeId,
		SessionType: req.SessionType,
		Longitude:   req.Longitude,
		Latitude:    req.Latitude,
	}
	//业务检查
	iSessionValidPushOfficial := NewValidSessionOfficial(header, basicReq, session, uniqueId, p)
	ret, err := iSessionValidPushOfficial.NotNeedDoLogic(ctx, curUserId)
	if err != nil || ret == 1 {
		return resp, err
	}
	err = iSessionValidPushOfficial.NeedDoLogic(ctx)
	if err != nil {
		return resp, err
	}

	resp, err = p.checkLogicAfter(ctx, header, session, uniqueId, basicReq)
	if err != nil {
		return resp, err
	}
	// 记数
	if session.fromWindow == nil || session.fromWindow.GetInteractTimes() < 1 { //对方未首次回复
		_ = p.impl.SendSessComp.DecrNoReplySendRemain(ctx, curUserId, toUserInfo.UserInfoDbModel.GetUserId())
	} else {
		_ = p.impl.SendSessComp.IncrSendSessCount(ctx, curUserId, toUserInfo.UserInfoDbModel.GetUserId())
	}

	return resp, err
}

// SessionInValidPush 陌生人私聊
type SessionInValidPush struct {
	commonReqRes
}

func (p *SessionInValidPush) processNoOfficial(ctx context.Context, header *pbapi.HttpHeaderInfo,
	req *pbapi.SendMsgReq, session *SendMsgSession, uniqueId int32) error {
	//add SessionInValidPush self logic:
	if ret := p.procNeMutualAuth(ctx, p.req.GetMessageType(), req.GetMemeId(), session); len(ret) > 0 {
		logger.Errorf(ctx, "send_msg failed. no right for this msgType . req=%+v, err=%v", req, ret)
		return errorcode.GenBusiErr(errorcode.DATA_INVALID, ret)
	}
	return p.commonReqRes.processNoOfficial(ctx, header, req, session, uniqueId)
}
func (p *SessionInValidPush) deleteExpireOneSession(ctx context.Context, uniqueId int32, curUserId, toUserId int64) error {
	eqCondFromUser := map[string]interface{}{
		"uniqueId":   uniqueId,
		"status":     1,
		"workId":     const_busi.HomePagePrivateMessageDefaultWorkId,
		"fromUserId": curUserId,
		"toUserId":   toUserId,
	}
	n, err := p.impl.DataCache.GetImpl().PersonalTalkMessageTotalMgDbModel.DeleteItems(ctx, eqCondFromUser, nil, nil, nil)
	if err != nil {
		logger.Errorf(ctx, "del history fail, err: %v, fromUserId: %v, toUserId: %v", err, curUserId, toUserId)
		return err
	}
	logger.Infof(ctx, "del fromUserId nums: %v, fromUserId: %v, toUserId: %v", n, curUserId, toUserId)
	return nil
}
func (p *SessionInValidPush) DeleteExpireSession(ctx context.Context, uniqueId int32, curUserId, toUserId int64) error {
	p.deleteExpireOneSession(ctx, uniqueId, curUserId, toUserId)
	p.deleteExpireOneSession(ctx, uniqueId, toUserId, curUserId)
	return nil
}
func (p *SessionInValidPush) SendPrivateMessage(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbapi.HomePagePrivateMessagePushResp, error) {
	logger.Infof(ctx, "new session process, %#v", *(p.req))
	resp := &pbapi.HomePagePrivateMessagePushResp{}

	if len([]rune(p.req.GetContent())) > int(setting.Maozhua.TalkMessageStrangerMaxLength.Get()) {
		return nil, errorcode.TalkMessageLengthError
	}

	if err := p.checkTemporarySessionParameters(ctx); err != nil {
		logger.Errorf(ctx, "invalid session push fail, err: %v", err)
		return resp, err
	}

	if err := p.commonReqRes.checkLogicBefore(ctx, header); err != nil {
		if err == errorcode.HomePagePrivateMsgInBlackActive {
			return resp, nil
		}
		return nil, err
	}
	if p.impl.DataCache.GetUserInfoTalkMode(ctx, p.toUserInfo.UserInfoDbModel.GetUserId()) == const_busi.TalkModeClose {
		return resp, errorcode.TalkModeCloseError
	}
	curUserId := p.curUserInfo.UserInfoDbModel.GetUserId()
	curUserInfo := p.curUserInfo
	toUserInfo := p.toUserInfo
	req := p.req

	session := &SendMsgSession{
		curUserId:   curUserId,
		curUserInfo: curUserInfo,
		toUserId:    toUserInfo.UserInfoDbModel.GetUserId(),
		toUserInfo:  toUserInfo,
		workId:      req.GetWorkId(),
		modeType:    int32(pbconst.PtModelTypeEnum_pt_model_type_normal),
	}

	uniqueId := genUniqueId(curUserId, req.GetToUserId(), session.workId, session.modeType)
	//物理删除当前过去的会话
	p.DeleteExpireSession(ctx, uniqueId, curUserId, req.GetToUserId())

	//处理emoji图片。
	if p.procEmoji(ctx, header) != nil {
		return resp, nil
	}
	basicReq := &pbapi.SendMsgReq{
		ToUserId:    req.ToUserId,
		Content:     req.Content,
		WorkId:      req.WorkId,
		MessageType: req.MessageType,
		Width:       req.Width,
		High:        req.High,
		Duration:    req.Duration,
		ObjectId:    req.ObjectId,
		ClientId:    req.ClientId,
		MemeId:      req.MemeId,
		SessionType: req.SessionType,
		Longitude:   req.Longitude,
		Latitude:    req.Latitude,
	}

	iSessionInValidPushOfficial := NewInValidSessionOfficial(header, basicReq, session, uniqueId, p)
	ret, err := iSessionInValidPushOfficial.NotNeedDoLogic(ctx, curUserId)
	if err != nil || ret == 1 {
		return resp, err
	}
	err = iSessionInValidPushOfficial.NeedDoLogic(ctx)
	if err != nil {
		return resp, err
	}

	resp, err = p.checkLogicAfter(ctx, header, session, uniqueId, basicReq)
	if err != nil {
		return resp, err
	}
	// 记数
	if p.impl.SendSessComp.EnableTalkAD(header.GetVersioncode()) {
		if session.fromWindow == nil || session.fromWindow.GetInteractTimes() < 1 { //对方未首次回复
			_ = p.impl.SendSessComp.DecrNoReplySendRemain(ctx, curUserId, toUserInfo.UserInfoDbModel.GetUserId())
		} else {
			_ = p.impl.SendSessComp.IncrSendSessCount(ctx, curUserId, toUserInfo.UserInfoDbModel.GetUserId())
		}
	}

	return resp, err
}

func (p *ContentMng) PushPrivateMessage(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbapi.HomePagePrivateMessagePushReq) (*pbapi.HomePagePrivateMessagePushResp, error) {
	loginUserInfo, err := p.getUserInfo(ctx, header)
	if err != nil || loginUserInfo == nil || loginUserInfo.UserInfoDbModel.GetUserId() <= 0 {
		logger.Errorf(ctx, "not login in CheckHomePagePrivateMessagePermission")
		return nil, errorcode.MIDAS_LOGIN_ERROR
	}

	checkReq := &pbapi.HomePagePrivateMessageCheck{
		ToUserId: req.ToUserId,
	}
	status, err := p.checkProcess(ctx, loginUserInfo, checkReq)
	if err != nil {
		logger.Errorf(ctx, "before check fail, err: %v", err)
		return nil, err
	}

	procHandler := NewPushMessageInstance(ctx, status, req, loginUserInfo, p)
	if procHandler == nil {
		logger.Errorf(ctx, "not busi type: %v", status)
		return nil, nil
	}
	resp, err := procHandler.SendPrivateMessage(ctx, header)

	return resp, err
}

type IOfficialLogicProc interface {
	NeedDoLogic(ctx context.Context) error
	NotNeedDoLogic(ctx context.Context, curUserId int64) (int32, error)
}

type privateMsgOfficialCommon struct {
	officialNum map[int64]bool
	header      *pbapi.HttpHeaderInfo
	basicReq    *pbapi.SendMsgReq
	session     *SendMsgSession
	uniqueId    int32
}

func (p *privateMsgOfficialCommon) NeedDoLogic(ctx context.Context) error {
	//TODO: add common process
	return nil
}
func (p *privateMsgOfficialCommon) NotNeedDoLogic(ctx context.Context, curUserId int64) (int32, error) {
	//TODO: add common process
	return 0, nil
}

type validSessionOfficial struct {
	privateMsgOfficialCommon
	impl *SessionValidPush
}

func (p *validSessionOfficial) NeedDoLogic(ctx context.Context) error {
	return nil
}
func (p *validSessionOfficial) NotNeedDoLogic(ctx context.Context, curUserId int64) (int32, error) {
	if _, ok := p.officialNum[curUserId]; ok {
		return 0, nil // 0 do next step
	}
	if err := p.impl.processNoOfficial(ctx, p.header, p.basicReq, p.session, p.uniqueId); err != nil {
		if err == errorcode.HomePagePrivateMsgSwallow {
			return 1, nil // 1 break do next step, and return succ.
		}
		return 2, err // 2 break do next step, and return err.
	}
	return 0, nil
}
func NewValidSessionOfficial(header *pbapi.HttpHeaderInfo, basicReq *pbapi.SendMsgReq, session *SendMsgSession, uniqueId int32, impl *SessionValidPush) IOfficialLogicProc {
	return &validSessionOfficial{
		privateMsgOfficialCommon: privateMsgOfficialCommon{
			officialNum: map[int64]bool{
				cm_const.OfficialMZUserId: true,
			},
			header:   header,
			basicReq: basicReq,
			session:  session,
			uniqueId: uniqueId,
		},
		impl: impl,
	}
}

// //
type invalidSessionOfficial struct {
	privateMsgOfficialCommon
	impl *SessionInValidPush
}

func (p *invalidSessionOfficial) NeedDoLogic(ctx context.Context) error {
	return nil
}
func (p *invalidSessionOfficial) NotNeedDoLogic(ctx context.Context, curUserId int64) (int32, error) {
	if _, ok := p.officialNum[curUserId]; ok {
		return 0, nil // 0 do next step
	}
	if err := p.impl.processNoOfficial(ctx, p.header, p.basicReq, p.session, p.uniqueId); err != nil {
		if err == errorcode.HomePagePrivateMsgSwallow {
			return 1, nil // 1 break do next step, and return succ.
		}
		return 2, err // 2 break do next step, and return err.
	}
	return 0, nil
}
func NewInValidSessionOfficial(header *pbapi.HttpHeaderInfo, basicReq *pbapi.SendMsgReq, session *SendMsgSession, uniqueId int32, impl *SessionInValidPush) IOfficialLogicProc {
	return &invalidSessionOfficial{
		privateMsgOfficialCommon: privateMsgOfficialCommon{
			officialNum: map[int64]bool{
				cm_const.OfficialMZUserId: true,
			},
			header:   header,
			basicReq: basicReq,
			session:  session,
			uniqueId: uniqueId,
		},
		impl: impl,
	}
}

// ///
type mutualSessionOfficial struct {
	privateMsgOfficialCommon
	impl *MutualUserPush
}

func (p *mutualSessionOfficial) NeedDoLogic(ctx context.Context) error {
	return nil
}
func (p *mutualSessionOfficial) NotNeedDoLogic(ctx context.Context, curUserId int64) (int32, error) {
	if _, ok := p.officialNum[curUserId]; ok {
		return 0, nil // 0 do next step
	}
	if err := p.impl.processNoOfficial(ctx, p.header, p.basicReq, p.session, p.uniqueId); err != nil {
		if err == errorcode.HomePagePrivateMsgSwallow {
			return 1, nil // 1 break do next step, and return succ.
		}
		return 2, err // 2 break do next step, and return err.
	}
	return 0, nil
}
func NewMutualSessionOfficial(header *pbapi.HttpHeaderInfo, basicReq *pbapi.SendMsgReq, session *SendMsgSession, uniqueId int32, impl *MutualUserPush) IOfficialLogicProc {
	return &mutualSessionOfficial{
		privateMsgOfficialCommon: privateMsgOfficialCommon{
			officialNum: map[int64]bool{
				cm_const.OfficialMZUserId: true,
			},
			header:   header,
			basicReq: basicReq,
			session:  session,
			uniqueId: uniqueId,
		},
		impl: impl,
	}
}
