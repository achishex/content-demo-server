package job

import (
	"content_svr/app/di"
)

var digC = di.NewContainer()
