package advertisement

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/db/mongodb/model"
	"context"
	"github.com/jinzhu/copier"
	"go.mongodb.org/mongo-driver/bson/primitive"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdateLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewUpdateLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateLogic {
	return &UpdateLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *UpdateLogic) Update(req *types.AppAdUpdateRequest) (resp *types.AppAdUpdateResponse, err error) {

	ad := model.AppAdvertisement{}
	_ = copier.Copy(&ad, req)

	id, err := primitive.ObjectIDFromHex(req.ID)
	if err != nil {
		return nil, err
	}
	ad.ID = id
	ad.Editor = req.CtxName

	//nowUnix := time.Now().UnixMilli()
	//ad.LaunchStatus = getLaunchStatus(nowUnix, ad)
	_, err = l.svcCtx.WriteDB.AppAdvertisement.UpdateOne(l.ctx, &ad)
	if err != nil {
		return nil, err
	}

	return
}
