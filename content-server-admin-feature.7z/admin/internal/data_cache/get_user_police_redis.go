package data_cache

import (
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"strconv"
)

// 检查是不是在内容分发池。返回eg:32 按位分配权限。

func (p *DataCacheMng) GetUserPoliceRedis(ctx context.Context, userId int64) bool {
	appName := "soul_soup" //默认就是 soul_soup 业务。
	redisKey := getRdsKeyPolice(appName)
	userIdStr := strconv.FormatInt(userId, 10)
	ret, err := p.RedisCli.HGet(ctx, redisKey, userIdStr).Result()
	if err != redis.Nil && err != nil {
		logger.Error(ctx, fmt.Sprintf("GetUserPoliceRedis query redis failed. redisKey=%v",
			redisKey), err)
	}
	if ret != "" { //获取成功
		return true
	}
	return false
}
func (p *DataCacheMng) DeleteUserPoliceRedis(ctx context.Context, userId int64) {
	appName := "soul_soup" //默认就是 soul_soup 业务。
	redisKey := getRdsKeyPolice(appName)
	userIdStr := strconv.FormatInt(userId, 10)
	ret, _ := p.RedisCli.HDel(ctx, redisKey, userIdStr).Result()
	logger.Infof(ctx, "del police from redis, userId: %v, ret: %v", userId, ret)
}
