package open_im_api

import (
	"content_svr/config"
	"github.com/OpenIMSDK/protocol/auth"
	"github.com/OpenIMSDK/protocol/friend"
	"github.com/OpenIMSDK/protocol/group"
	"github.com/OpenIMSDK/protocol/msg"
	"github.com/OpenIMSDK/protocol/user"
	"github.com/openimsdk/open-im-server/v3/pkg/apistruct"
)

func imApi() string {
	return config.ServerConfig.OpenImConfig.APIUrl
}

// im caller.
var (
	userToken    = NewApiCaller[auth.UserTokenReq, auth.UserTokenResp]("/auth/user_token", imApi)
	forceOffLine = NewApiCaller[auth.ForceLogoutReq, auth.ForceLogoutResp]("/auth/force_logout", imApi)

	updateUserInfo    = NewApiCaller[user.UpdateUserInfoReq, user.UpdateUserInfoResp]("/user/update_user_info", imApi)
	registerUser      = NewApiCaller[user.UserRegisterReq, user.UserRegisterResp]("/user/user_register", imApi)
	registerUserCount = NewApiCaller[user.UserRegisterCountReq, user.UserRegisterCountResp]("/statistics/user/register", imApi)
	accountCheck      = NewApiCaller[user.AccountCheckReq, user.AccountCheckResp]("/user/account_check", imApi)

	friendUserIDs = NewApiCaller[friend.GetFriendIDsReq, friend.GetFriendIDsResp]("/friend/get_friend_id", imApi)
	importFriend  = NewApiCaller[friend.ImportFriendReq, friend.ImportFriendResp]("/friend/import_friend", imApi)

	createGroup              = NewApiCaller[group.CreateGroupReq, group.CreateGroupResp]("/group/create_group", imApi)
	getGroupsInfo            = NewApiCaller[group.GetGroupsInfoReq, group.GetGroupsInfoResp]("/group/get_groups_info", imApi)
	setGroupsInfo            = NewApiCaller[group.SetGroupInfoReq, group.SetGroupInfoResp]("/group/set_group_info", imApi)
	inviteToGroup            = NewApiCaller[group.InviteUserToGroupReq, group.InviteUserToGroupResp]("/group/invite_user_to_group", imApi)
	groupApplicationResponse = NewApiCaller[group.GroupApplicationResponseReq, group.GroupApplicationResponseResp]("/group/group_application_response", imApi)
	joinGroup                = NewApiCaller[group.JoinGroupReq, group.JoinGroupResp]("/group/join_group", imApi)
	kickGroup                = NewApiCaller[group.KickGroupMemberReq, group.KickGroupMemberResp]("/group/kick_group", imApi)
	getGroupsAbstractInfo    = NewApiCaller[group.GetGroupAbstractInfoReq, group.GetGroupAbstractInfoResp]("/group/get_group_abstract_info", imApi)
	dismissGroup             = NewApiCaller[group.DismissGroupReq, group.DismissGroupResp]("/group/dismiss_group", imApi)
	quitGroup                = NewApiCaller[group.QuitGroupReq, group.QuitGroupResp]("/group/quit_group", imApi)
	transferGroup            = NewApiCaller[group.TransferGroupOwnerReq, group.TransferGroupOwnerResp]("group/transfer_group", imApi)
	setGroupMemberInfo       = NewApiCaller[group.SetGroupMemberInfoReq, group.SetGroupMemberInfoResp]("/group/set_group_member_info", imApi)
	getJoinedGroupList       = NewApiCaller[group.GetJoinedGroupListReq, group.GetJoinedGroupListResp]("/group/get_joined_group_list", imApi)
	getGroupMembersInfo      = NewApiCaller[group.GetGroupMembersInfoReq, group.GetGroupMembersInfoResp]("/group/get_group_members_info", imApi)
	sendMsg                  = NewApiCaller[apistruct.SendMsgReq, msg.SendMsgResp]("/msg/send_msg", imApi)
)
