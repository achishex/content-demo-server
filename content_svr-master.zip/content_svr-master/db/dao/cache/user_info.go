package cache

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/dao/operate"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/model"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
	"context"
	"errors"
	"gorm.io/gen"
	"gorm.io/gorm"
)

type UserInfo struct {
	query.UserInfo
	redisManage *query_rds.Manage
}

func NewCacheUserInfo(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *UserInfo {
	return &UserInfo{
		UserInfo:    query.NewUserInfo(mysql.UserInfo),
		redisManage: redisManage,
	}
}

func (p *UserInfo) FindByUserIds(ctx context.Context, userIds []int64) ([]*model.UserInfo, error) {
	where := map[string]interface{}{
		"user_ids": userIds,
	}

	return p.UserInfo.FindMap(ctx, 500, 0, where)
}

func (p *UserInfo) FindByUserId(ctx context.Context, userId int64) (*model.UserInfo, error) {
	return p.UserInfo.FindOne(ctx, map[string]interface{}{
		"user_id": userId,
	})
}

func (p *UserInfo) FindPage(ctx context.Context, turner operate.PageTurner) ([]*model.UserInfo, int64, error) {
	where, offset, limit := turner.ParseMysql()
	_db := p.UserInfo.ParseWhere(ctx, where)
	count, err := _db.Count()
	if err != nil {
		return nil, 0, err
	}

	items, err := _db.Limit(limit).Offset(offset).Find()
	switch {
	case errors.Is(err, gorm.ErrRecordNotFound):
		return nil, 0, xerr.DbNotFound
	case err == nil:
		return items, count, nil
	default:
		return nil, 0, err
	}
}

func (p *UserInfo) UpdateMap(ctx context.Context, filter, update map[string]interface{}) (info gen.ResultInfo, err error) {
	return p.UserInfo.UpdateMap(ctx, filter, update)
}

func (p *UserInfo) UpdateHeaderAndNickName(ctx context.Context, userId int64, head, nickName string) (err error) {
	if userId == 0 || head == "" || nickName == "" {
		return nil
	}

	filter := map[string]interface{}{
		p.UserInfo.UserID.ColumnName().String(): userId,
	}
	data := map[string]interface{}{
		p.UserInfo.Photo.ColumnName().String():    head,
		p.UserInfo.NickName.ColumnName().String(): nickName,
		p.UserInfo.UserType.ColumnName().String(): model.UserTypeRobot, // 机器人类型
	}
	defer p.redisManage.UserInfo.SetUserInfo(ctx, userId, data)
	_, err = p.UserInfo.UpdateMap(ctx, filter, data)
	switch {
	case err == nil:
		return nil
	case errors.Is(err, gorm.ErrRecordNotFound):
		return gorm.ErrRecordNotFound
	default:
		return err
	}

}

// ClearUserInfoRedisCache 清除redis缓存中用户的缓存信息
func (p *UserInfo) ClearUserInfoRedisCache(ctx context.Context, userId int64) error {
	if err := p.redisManage.UserInfo.Del(ctx, userId); err != nil {
		return err
	}
	return nil
}

// ClearUserTokenRedisCache 清除redis缓存中用户的登录token
func (p *UserInfo) ClearUserTokenRedisCache(ctx context.Context, userId int64) error {
	if err := p.redisManage.Token.TokenContentSvr.DelToken(ctx, userId); err != nil {
		return err
	}

	return nil
}
