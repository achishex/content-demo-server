package bttl_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/aq_const"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/internal/model"
	"content_svr/internal/security_mng"
	"content_svr/internal/user_center_mng"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/snowflakev2"
	"content_svr/setting"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	. "github.com/a3d21/gostream/core"
	"github.com/dtm-labs/rockscache"
	"github.com/redis/go-redis/v9"

	"github.com/samber/lo"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
	"time"
)

func NewBttlMng(
	db model.ParseTimeDB,
	rdb redis.UniversalClient,
	dc data_cache.IDataCacheMng,
	ucm user_center_mng.IUserCenterMng,
	cm content_mng.IContentMng,
	ssc *content_mng.SendSessComp,
	rcCli *rockscache.Client,
	secm security_mng.ISecurityMng,
) *BttlMng {
	return &BttlMng{
		db:    db,
		rdb:   rdb,
		dc:    dc,
		ucm:   ucm,
		cm:    cm,
		ssc:   ssc,
		rcCli: rcCli,
		secm:  secm,
	}
}

type BttlMng struct {
	db    *gorm.DB
	rdb   redis.UniversalClient
	dc    data_cache.IDataCacheMng
	ucm   user_center_mng.IUserCenterMng
	cm    content_mng.IContentMng
	ssc   *content_mng.SendSessComp
	rcCli *rockscache.Client
	secm  security_mng.ISecurityMng
}

func (m *BttlMng) UserStatus(ctx context.Context, userID int64) (*BttlStatusResp, error) {
	pchance, err := m.GetUserPickChance(ctx, userID)
	if err != nil {
		return nil, err
	}
	cc, err := m.GetCreateCount(ctx, userID)
	if err != nil {
		return nil, err
	}

	maxPChance := setting.Maozhua.BttlConf.PickChance.Get()
	cDailyLimit := setting.Maozhua.BttlConf.CreateDaily.Get()

	cchance := cDailyLimit - cc
	if cchance < 0 {
		cchance = 0
	}
	return &BttlStatusResp{
		PickChance:       pchance,
		MaxPickChance:    maxPChance,
		CreateChance:     cchance,
		CreateDailyLimit: cDailyLimit,
	}, nil
}
func (m *BttlMng) getLatestBttlCached(ctx context.Context) ([]BttlEntity, error) {
	enableCache := setting.Maozhua.BttlConf.DiscoverCacheInMin.Get() > 0
	key := fmt.Sprintf("platform:%v:bttl-lite:latest-bttls", config.ServerConfig.Env)
	exp := time.Minute * time.Duration(setting.Maozhua.BttlConf.DiscoverCacheInMin.Get())
	if enableCache {

		if s, err := m.rdb.Get(ctx, key).Result(); err == nil && s != "" {
			var bttls []BttlEntity
			if err2 := json.Unmarshal([]byte(s), &bttls); err2 == nil && len(bttls) > 0 {
				return bttls, nil
			}
		}
	}

	fromTime := time.Now().Add(-time.Duration(setting.Maozhua.BttlConf.DiscoverPeriodInHour.Get()) * time.Hour)
	var bttls []BttlEntity
	err := m.db.WithContext(ctx).Order("create_time desc").Limit(2000).Find(&bttls, "create_time > ?", fromTime).Error
	if err != nil {
		return nil, err
	}

	logger.Infof(ctx, "find bttl count: %v", len(bttls))
	if enableCache && len(bttls) > 0 {
		if bs, err2 := json.Marshal(bttls); err2 == nil {
			m.rdb.Set(ctx, key, string(bs), exp)
		}
	}
	return bttls, nil
}

func (m *BttlMng) Discover(ctx context.Context, userID int64) (*DiscoverResp, error) {

	bttlList, err := m.getLatestBttlCached(ctx)
	if err != nil {
		logger.Errorf(ctx, "getLatestBttlCached fail, err: %v", err)
		return nil, errorcode.INTERNAL_DB_EXCEPTION
	}
	if len(bttlList) == 0 {
		return &DiscoverResp{}, nil
	}

	picked, err := m.GetUserPickSet(ctx, userID)
	if err != nil {
		logger.Errorf(ctx, "GetUserPickSet fail, err: %v", err)
		return nil, errorcode.INTERNAL_EXCEPTION
	}

	filtered := lo.Filter(lo.Filter(bttlList, func(item BttlEntity, _ int) bool {
		return picked == nil || !picked[item.BttlID]
	}), func(item BttlEntity, _ int) bool {
		return item.UserID != userID && item.Replier == 0 // 过滤自己和已被回复
	})

	if len(filtered) == 0 {
		return &DiscoverResp{}, nil
	}

	bttlIDs := lo.Map(filtered, func(item BttlEntity, _ int) int64 {
		return item.BttlID
	})
	var locked map[int64]int64
	//locked, err := m.GetLockMap(ctx, bttlIDs)
	//if err != nil {
	//	logger.Warnf(ctx, "GetLockMap fail, skip, err: %v", err)
	//}

	var exposureMap = map[int64]int64{}
	if setting.Maozhua.BttlConf.MaxExposure.Get() > 0 {
		var err2 error
		exposureMap, err2 = m.GetExposureMap(ctx, bttlIDs)
		if err2 != nil {
			logger.Warnf(ctx, "GetExposureMap fail, err: %v", err2)
		}
	}
	discoverMap, err := m.DiscoverMap(ctx, bttlIDs)
	if err != nil {
		logger.Warnf(ctx, "DiscoverMap fail, err: %v", err)
	}

	replySet, err := m.GetReplySet(ctx)
	if err != nil {
		logger.Warnf(ctx, "GetReplySet fail, err: %v", err)
	}

	maxExp := setting.Maozhua.BttlConf.MaxExposure.Get()
	data := From(filtered).Filter(func(it interface{}) bool {
		item := it.(BttlEntity)
		// filter unlocked
		return locked == nil || locked[item.BttlID] == 0 || locked[item.BttlID] == userID
	}).Filter(func(it interface{}) bool {
		// filter not replied
		item := it.(BttlEntity)
		return replySet == nil || !replySet[item.BttlID]
	}).Filter(func(it interface{}) bool {
		item := it.(BttlEntity)
		// filter exposure
		return exposureMap == nil || exposureMap[item.BttlID] < maxExp
	}).Filter(func(it interface{}) bool {
		item := it.(BttlEntity)
		// filter discover
		return discoverMap == nil || !discoverMap[item.BttlID]
	}).Shuffle().Limit(5). // take random 5 element
				Map(func(it interface{}) interface{} {
			return m.Entity2LiteDTO(it.(BttlEntity)) //to dto
		}).Collect(ToSlice([]BttlLiteDTO{})).([]BttlLiteDTO)

	// 记录分发
	if err2 := m.SetDiscover(ctx, lo.Map(data, func(item BttlLiteDTO, _ int) int64 { return item.BttlID })); err2 != nil {
		logger.Errorf(ctx, "SetDiscover fail, err: %v", err)
	}

	exMap, err := m.GetBttlEx(ctx, lo.Map(data, func(item BttlLiteDTO, _ int) int64 {
		return item.UserID
	}))
	if err != nil {
		logger.Errorf(ctx, "GetBttlEx fail, err: %v", err)
		return nil, errorcode.INTERNAL_DB_EXCEPTION
	}
	for i, dto := range data {
		if ex, ok := exMap[dto.UserID]; ok {
			data[i].BttlEx = ex
		} else {
			logger.Warnf(ctx, "user not found, userID: %v", dto.UserID)
		}
	}

	chance, err := m.GetUserPickChance(ctx, userID)
	if err != nil {
		logger.Warnf(ctx, "GetUserPickChance fail, err: %v", err)
	}
	return &DiscoverResp{
		Data:          data,
		Size:          len(data),
		PickChance:    int(chance),
		NextPageToken: "",
	}, nil

}
func (m *BttlMng) CreateBttl(ctx context.Context, header *pbapi.HttpHeaderInfo, userID int64, content string) (*BttlEntity, error) {
	u, err := m.dc.GetUserBasicInfo(ctx, userID, false)
	if err != nil {
		logger.Errorf(ctx, "GetUserBasicInfo fail, err: %v", err)
		return nil, errorcode.INTERNAL_DB_EXCEPTION
	}
	if u == nil {
		logger.Errorf(ctx, "user not found, userID: %v", userID)
		return nil, errorcode.NOT_AUTH
	}

	if n, err2 := m.GetCreateCount(ctx, userID); err2 == nil && n >= setting.Maozhua.BttlConf.CreateDaily.Get() {
		return nil, errorcode.BttlCreateLimit
	}

	// 内容检查
	if content == "" {
		return nil, errorcode.PARAM_ERROR
	}
	if res, err2 := m.secm.CheckTxt(ctx, userID, security_mng.MArticleEventId.Nickname, content, 1); err2 == nil {
		if res == aq_const.AqConst.Reject {
			logger.Infof(ctx, "content reject, userID: %v, content: %v", userID, content)
			return nil, errorcode.TalkModeDescAuditError
		} else if res == aq_const.AqConst.Warning {
			logger.Infof(ctx, "content warn, userID: %v, content: %v", userID, content)
		}
	}

	crd := m.dc.GetUserCoordinateV2(ctx, userID, header)
	now := time.Now()
	bttl := &BttlEntity{
		ID:         0,
		BttlID:     snowflakev2.GenI64(),
		UserID:     userID,
		Gender:     int(u.GetGender()),
		Content:    content,
		City:       crd.City,
		Replier:    0,
		CreateTime: &now,
		ReplyTime:  nil,
	}
	err = m.db.WithContext(ctx).Create(bttl).Error
	if err != nil {
		logger.Errorf(ctx, "DB Create fail, err: %v", err)
		return nil, errorcode.INTERNAL_DB_EXCEPTION
	}
	m.IncrCreateCount(ctx, userID)
	return bttl, nil
}

func (m *BttlMng) PickBttl(ctx context.Context, userID int64, bttlID int64) (*PickResp, error) {
	if chance, err := m.GetUserPickChance(ctx, userID); err == nil && chance < 1 {
		logger.Infof(ctx, "user no chance pick bttl, userID: %v", userID)
		return nil, errorcode.BttlNoPickChance
	}

	key := m.getBttlPickLockKey(bttlID)
	exp := time.Minute * 6
	ok, err := m.rdb.SetNX(ctx, key, fmt.Sprint(userID), exp).Result()
	if err != nil {
		return nil, err
	}
	if !ok {
		if s, err2 := m.rdb.Get(ctx, key).Result(); err2 == nil && s != fmt.Sprint(userID) {
			return nil, errorcode.BttlPicked
		}
	}

	b := &BttlEntity{}
	err = m.db.WithContext(ctx).First(b, "bttl_id = ?", bttlID).Error
	if err != nil {
		return nil, err
	}

	if b.Replier != 0 && b.Replier != userID {
		return nil, errorcode.BttlReplyed
	}

	if b.UserID == userID {
		return nil, errorcode.BttlSelfReply
	}

	pchance, _ := m.DecrPickChance(ctx, userID)
	_ = m.AddUserPickSet(ctx, userID, bttlID)
	_ = m.IncrExposure(ctx, bttlID)

	if pchance < 0 {
		pchance = 0
	}
	return &PickResp{PickChance: pchance}, nil
}

func (m *BttlMng) ThrowbackBttl(ctx context.Context, userID, bttlID int64) (*ThrowbackResp, error) {
	pickLockKey := m.getBttlPickLockKey(bttlID)
	res, err := m.rdb.Get(ctx, pickLockKey).Result()
	if err != nil && !errors.Is(err, redis.Nil) {
		return nil, errorcode.INTERNAL_DB_EXCEPTION
	}

	if res == fmt.Sprint(userID) {
		m.rdb.Del(ctx, pickLockKey)
	}
	return &ThrowbackResp{}, nil
}

func (m *BttlMng) ReplyBttl(ctx context.Context, userID, bttlID int64, msg string) (*ReplyResp, error) {

	if msg == "" {
		return nil, errorcode.PARAM_ERROR
	}
	if res, err2 := m.secm.CheckTxt(ctx, userID, security_mng.MArticleEventId.Nickname, msg, 1); err2 == nil {
		if res != aq_const.AqConst.Pass {
			logger.Errorf(ctx, "content reject, userID: %v, content: %v", userID, msg)
			return nil, errorcode.TalkModeDescAuditError
		}
	}

	b := &BttlEntity{}
	tx := m.db.WithContext(ctx).Begin()
	err := tx.Clauses(clause.Locking{Strength: "UPDATE"}).First(b, "bttl_id = ?", bttlID).Error
	if err != nil {
		tx.Rollback()
		logger.Errorf(ctx, "select fail, bttl_id: %v, err: %v", bttlID, err)
		return nil, errorcode.INTERNAL_DB_EXCEPTION
	}

	if b.Replier != 0 && b.Replier != userID {
		tx.Rollback()
		logger.Errorf(ctx, "bttl replyed, bttlID: %v replier: %v", bttlID, b.Replier)
		return nil, errorcode.BttlReplyed
	}

	if b.Replier == userID {
		tx.Rollback()
		logger.Errorf(ctx, "duplicated reply, bttlID: %v", bttlID)
		return &ReplyResp{Jump: m.genJumpURL(b.UserID)}, nil
	}

	now := time.Now()
	b.Replier = userID
	b.ReplyTime = &now
	err = tx.Save(b).Error
	//err = tx.Model(&BttlEntity{}).Where("bttl_id = ?", bttlID).Updates(map[string]any{"replier": userID, "reply_time": now}).Error
	if err != nil {
		tx.Rollback()
		return nil, err
	}

	err = tx.Commit().Error
	if err != nil {
		return nil, err
	}

	m.AddReplySet(ctx, bttlID)

	if err2 := m.SetMutual(ctx, b.UserID, userID); err2 != nil {
		logger.Errorf(ctx, "SetMutual fail,  %v - %v err: %v", b.UserID, userID, err2)
		return nil, errorcode.INTERNAL_EXCEPTION
	}

	if err2 := m.SendReplyMsg(ctx, b, userID, msg); err2 != nil {
		logger.Errorf(ctx, "SendReplyMsg fail, bttl: %+v, userID: %v, err: %v", b, userID, err)
		return nil, errorcode.INTERNAL_EXCEPTION
	}
	return &ReplyResp{
		Jump: m.genJumpURL(b.UserID),
	}, nil
}

// ListBttl 列出所有漂流瓶子
func (m *BttlMng) ListBttl(ctx context.Context, userID int64) (*ListBttlResp, error) {
	var l1 []BttlEntity
	err := m.db.WithContext(ctx).Find(&l1, "(user_id = ? and replier != 0) or replier = ?", userID, userID).Error
	if err != nil {
		logger.Errorf(ctx, "ListBttl fail, err: %v", err)
		return nil, errorcode.INTERNAL_DB_EXCEPTION
	}

	if len(l1) == 0 {
		return &ListBttlResp{Data: make([]BttlJumpDTO, 0)}, nil
	}

	data := From(l1).SortedDescBy(func(it interface{}) interface{} {
		return it.(BttlEntity).ReplyTime.UnixMilli()
	}).Map(func(it interface{}) interface{} { //map dto
		item := it.(BttlEntity)
		dto := m.Entity2DTO(item)
		jump := ""
		if userID == item.UserID && item.Replier > 0 {
			jump = m.genJumpURL(item.Replier)
		} else if item.Replier == userID && item.UserID > 0 {
			jump = m.genJumpURL(item.UserID)
		}
		return BttlJumpDTO{
			BttlDTO: dto,
			Jump:    jump,
		}
	}).Collect(ToSlice([]BttlJumpDTO{})).([]BttlJumpDTO)

	exMap, err := m.GetBttlEx(ctx, lo.FlatMap(data, func(item BttlJumpDTO, _ int) []int64 {
		return []int64{item.UserID, item.Replier}
	}))
	if err != nil {
		logger.Errorf(ctx, "GetBttlEx fail, err: %v", err)
		return nil, errorcode.INTERNAL_DB_EXCEPTION
	}

	for i, dto := range data {
		if ex, ok := exMap[dto.UserID]; ok {
			data[i].BttlEx = ex
		} else {
			logger.Warnf(ctx, "user not found, userID: %v", dto.UserID)
		}

		// replier info
		if ex, ok := exMap[dto.Replier]; ok {
			data[i].ReplierNickname = ex.Nickname
			data[i].ReplierFaceURL = ex.FaceURL
		}
	}

	return &ListBttlResp{
		Data: data,
	}, nil
}

func (m *BttlMng) JumpTalk(ctx context.Context, userID, bttlID int64) {

}
