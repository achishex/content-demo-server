package const_level

// 通过，未通过，无需验证
const (
	_ int32 = iota
	RealNameAuthPass
	RealNameAuthNoPass
	RealNameAuthClose
)

// 通过，未通过，无需验证
const (
	_ int32 = iota
	SheNiuAuthPass
	SheNiuAuthNoPass
	SheNiuAuthClose
)
