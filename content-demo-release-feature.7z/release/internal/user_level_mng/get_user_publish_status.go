package user_level_mng

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/var_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/busi_comm/version"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"time"
)

func (p *UserLevelMng) GetPublishStatus(ctx context.Context,
	header *pbapi.HttpHeaderInfo) (*pbuserapi.ChitchatStatusResp, error) {

	resp := &pbuserapi.ChitchatStatusResp{
		PushStatus: cm_const.PushStatusPass,
	}
	//push_status := cm_const.PushStatusPass // 发布状态 1可发布 2未到发布时间 3在小黑屋 4上个作品正在审核中 5-用户等级过低
	userId, err := p.getUserId(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "get user id by token failed,err=%v", err.Error())
		return nil, errorcode.LOGIN_INVALID
	}

	ss, err := p.getUserLevSession(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user level session failed,err=%v", err.Error())
		return nil, errorcode.INTERNAL_ERROR
	}

	//等级过低
	if ss.CurLevel == 0 {
		resp.PushStatus = cm_const.PushStatusLevelToLow
		return resp, nil
	}

	// 在小黑屋
	iBlackHouse := p.DataCache.GetImpl().GetUserInBlackFlag(ctx, userId)
	if iBlackHouse {
		resp.PushStatus = cm_const.PushStatusInBlackHouse
		return resp, nil
	}

	//  未到发布时间
	if ss.UserExt.GetNextChitchatTime() > time.Now().UnixNano()/1e6 {
		resp.PushStatus = cm_const.PushStatusWait
		resp.RemainingNextPushTime = proto.Int64(ss.UserExt.GetNextChitchatTime() - time.Now().UnixNano()/1e6)
		return resp, nil
	}
	resp.PushStatus = cm_const.PushStatusPass

	// 是否为首条动态
	if header.Versioncode >= version.SuperiorContentAwardVersion {
		if err := p.DataCache.LoadSuperiorContentAwardSetting(ctx); err != nil {
			logger.Error(ctx, "LoadSuperiorContentAwardSetting", err)
		}

		exist, err := p.DataCache.GetImpl().SuperiorContentAwardDetailMgModel.CheckFirstWork(ctx, userId)
		switch {
		case err != nil:
			logger.Error(ctx, "CheckFirstWork", err)
			return resp, err
		case !exist && err == nil:
			resp.FirstWorkMessage = fmt.Sprintf("现在发布动态，首条奖励现金¥%.2f哦！", var_busi.AwardFirstWork)
		}

	}

	return resp, nil
}
