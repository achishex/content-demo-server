package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const SecretUserMedalInfoCollectionName = "secretUserMedalInfo"

var _ SecretUserMedalInfoModel = (*customSecretUserMedalInfoModel)(nil)

type (
	// SecretUserMedalInfoModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretUserMedalInfoModel.
	SecretUserMedalInfoModel interface {
		secretUserMedalInfoModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretUserMedalInfo, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretUserMedalInfo, error)
	}

	customSecretUserMedalInfoModel struct {
		*defaultSecretUserMedalInfoModel
	}
)

// NewSecretUserMedalInfoModel returns a model for the mongo.
func NewSecretUserMedalInfoModel(cfg MonConfig) SecretUserMedalInfoModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SecretUserMedalInfoCollectionName)
	return &customSecretUserMedalInfoModel{
		defaultSecretUserMedalInfoModel: newDefaultSecretUserMedalInfoModel(conn),
	}
}

func (m *customSecretUserMedalInfoModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customSecretUserMedalInfoModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretUserMedalInfoModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretUserMedalInfo, error) {
	result := make([]SecretUserMedalInfo, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretUserMedalInfoModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretUserMedalInfo, error) {
	var data SecretUserMedalInfo
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
