package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

const collectionNameCsjAdvertisementData = "csjAdvertisementData"

type CsjAdvertisementData struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	AdFillRate       float64 `json:"ad_fill_rate"`
	AdImpressionRate float64 `json:"ad_impression_rate"`
	AdRequest        int     `json:"ad_request"`
	AdSlotId         int     `json:"ad_slot_id"`
	AdSlotType       int     `json:"ad_slot_type"`
	AdSlotTypeV2     int     `json:"ad_slot_type_v2"`
	AppId            int     `json:"app_id"`
	AppName          string  `json:"app_name"`
	BiddingType      int     `json:"bidding_type"`
	Click            int     `json:"click"`
	ClickRate        float64 `json:"click_rate"`
	CodeName         string  `json:"code_name"`
	Currency         string  `json:"currency"`
	Date             string  `json:"date"`
	Ecpm             float64 `json:"ecpm"`
	FillRate         float64 `json:"fill_rate"`
	MediaMSsr        int     `json:"media_m_ssr"`
	MediaName        string  `json:"media_name"`
	Os               string  `json:"os"`
	PackageName      string  `json:"package_name"`
	Region           string  `json:"region"`
	Request          int     `json:"request"`
	Response         int     `json:"response"`
	Return           int     `json:"return"`
	Revenue          float64 `json:"revenue"` // 预估收益（T日）
	Show             int     `json:"show"`    // 预估ecpm
	TimeZone         int     `json:"time_zone"`
	UseMediation     int     `json:"use_mediation"`

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` // 创建时间
}
