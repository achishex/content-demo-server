package query

import (
	"content_svr/db/mysqldb/model"
	"context"
	"gorm.io/gen"
	"gorm.io/gen/field"
)

type OrderInfo struct {
	orderInfo
}

func NewOrderInfo(p orderInfo) OrderInfo {
	return OrderInfo{
		orderInfo: p,
	}
}

func (p *orderInfo) ParseWhere(ctx context.Context, where map[string]interface{}) IOrderInfoDo {
	_do := p.WithContext(ctx)
	if len(where) == 0 {
		return _do
	}

	attrMap := map[string]interface{}{}
	for key, value := range where {
		switch key {
		case "create_time_start":
			_do = _do.Where(p.CreateTime.Gt(value.(string)))
		case "create_time_end":
			_do = _do.Where(p.CreateTime.Lt(value.(string)))
		default:
			if _, exist := p.fieldMap[key]; !exist {
				continue
			}
			attrMap[key] = value
		}
	}

	return _do.Where(field.Attrs(attrMap))
}

func (p *orderInfo) FindMap(ctx context.Context, limit, offset int, where map[string]interface{}) ([]*model.OrderInfo, error) {
	_db := p.ParseWhere(ctx, where)
	_db = _db.WithContext(ctx)
	if limit != 0 {
		_db = _db.Limit(limit)
	}
	if offset != 0 {
		_db = _db.Offset(offset)
	}

	return _db.Find()
}

func (p *orderInfo) FindOne(ctx context.Context, where map[string]interface{}) (*model.OrderInfo, error) {
	_db := p.ParseWhere(ctx, where)

	return _db.Take()
}

func (p *orderInfo) UpdateMap(ctx context.Context, where, update map[string]interface{}) (info gen.ResultInfo, err error) {
	_db := p.ParseWhere(ctx, where)

	return _db.Updates(update)
}
