package job

import (
	"content_svr/db/aggregation"
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/internal/wxreward"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo/options"
	"math"
	"time"
)

func InitAwardCalcSum(write, read *dao.ManagerDB) {
	ctx := requestid.WithRequestID(context.Background())
	target := time.Now().AddDate(0, 0, -1)
	ctrl := newAwardCalcSumControl(write, read)
	if err := ctrl.DoTask(ctx, target); err != nil {
		logger.Error(context.Background(), "InitAwardCalcSum:", err)
	}

	//for i := 90; i > 0; i-- {
	//	ctx := requestid.WithRequestID(context.Background())
	//	target := time.Now().AddDate(0, 0, -i)
	//	ctrl := newAwardCalcSumControl(write, read)
	//	if err := ctrl.DoTask(ctx, target); err != nil {
	//		logger.Error(context.Background(), "InitAwardCalcSum:", err)
	//	}
	//}

}

type awardCalcSumControl struct {
	write, read *dao.ManagerDB

	sumDb *aggregation.SumManage
}

func newAwardCalcSumControl(write, read *dao.ManagerDB) awardCalcSumControl {
	ctrl := awardCalcSumControl{}
	ctrl.write = write
	ctrl.read = read
	ctrl.sumDb = aggregation.NewSumManage(read, write)
	return ctrl
}

func (l awardCalcSumControl) DoTask(ctx context.Context, targetTime time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	awardSettlementSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.AwardSettlement)
	if err != nil {
		return err
	}
	deductionIllegalSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.DeductionIllegal)
	if err != nil {
		return err
	}
	firstWorkSettlementSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.FirstWorkSettlement)
	if err != nil {
		return err
	}
	wechatPayWithdrawSuccessSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.WechatPayWithdrawSuccess)
	if err != nil {
		return err
	}
	wechatPayWithdrawFailSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.WechatPayWithdrawFail)
	if err != nil {
		return err
	}
	hallOfFameAwardSettlementSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.HallOfFameAwardSettlement)
	if err != nil {
		return err
	}

	signLevelUpAward, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.SignLevelUpAward)
	if err != nil {
		return err
	}
	awardViewWorkSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.AwardViewWork)
	if err != nil {
		return err
	}
	awardGameTime, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.AwardGameTime)
	if err != nil {
		return err
	}
	awardSportAd, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.AwardSportAd)
	if err != nil {
		return err
	}
	awardStarSignAd, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.AwardStarSignAd)
	if err != nil {
		return err
	}
	awardSignAd, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.AwardSignAd)
	if err != nil {
		return err
	}
	awardGroupByCreate, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.AwardGroupByCreate)
	if err != nil {
		return err
	}
	awardGroupUserByActive, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.AwardGroupUserByActive)
	if err != nil {
		return err
	}
	awardCommentFirst, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.AwardCommentFirst)
	if err != nil {
		return err
	}

	//PartnerInviteReward = 16 //合伙人邀请奖励
	partnerInviteReward, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.PartnerInviteReward)
	if err != nil {
		return err
	}
	//PartnerCarveUp      = 17 //合伙人瓜分奖励
	partnerCarveUp, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.PartnerCarveUp)
	if err != nil {
		return err
	}

	gameSum, err := l.countSecretGameOrder(ctx, targetTime)
	if err != nil {
		return err
	}

	/// begin ==================== 从 wx_reward_log 中统计的奖励 ====================
	// 绑定微信的奖励
	awardBindWechatSum, err := l.wxRewardLogDetail(ctx, targetTime, wxreward.RewardTypeBindWx)
	if err != nil {
		return err
	}

	// 升级的奖励
	awardRewardTypeLv5Sum, err := l.wxRewardLogDetail(ctx, targetTime, wxreward.RewardTypeLvlUp)
	if err != nil {
		return err
	}
	signLevelUpAward += awardRewardTypeLv5Sum

	// 名人堂立刻到账的奖励
	palaceSum, err := l.wxRewardLogDetail(ctx, targetTime, wxreward.RewardTypePalace)
	if err != nil {
		return err
	}
	hallOfFameAwardSettlementSum += palaceSum
	/// end ==================== 从 wx_reward_log 中统计的奖励 ====================

	data := &model.SuperiorAwardDaily{
		Day:                          utils.ZeroTime(targetTime).UnixMilli(),
		AwardSettlementSum:           awardSettlementSum,
		DeductionIllegalSum:          deductionIllegalSum,
		FirstWorkSettlementSum:       firstWorkSettlementSum,
		WechatPayWithdrawSuccessSum:  wechatPayWithdrawSuccessSum,
		WechatPayWithdrawFailSum:     wechatPayWithdrawFailSum,
		HallOfFameAwardSettlementSum: hallOfFameAwardSettlementSum,
		GameSum:                      gameSum,
		PartnerInviteReward:          partnerInviteReward,
		PartnerCarveUp:               partnerCarveUp,
		SignLevelUpAwardSum:          signLevelUpAward,
		AwardViewWorkSum:             awardViewWorkSum,
		AwardGameTimeSum:             awardGameTime,
		AwardSportAdSum:              awardSportAd,
		AwardStarSignAdSum:           awardStarSignAd,
		AwardSignAdSum:               awardSignAd,
		AwardGroupByCreateSum:        awardGroupByCreate,
		AwardGroupUserByActiveSum:    awardGroupUserByActive,
		AwardCommentFirstSum:         awardCommentFirst,
		AwardBindWechatSum:           awardBindWechatSum,
	}

	updateFilter := bson.D{
		{"day", utils.ZeroTime(targetTime).UnixMilli()},
	}

	update := bson.D{
		{"$set", data},
		{"$setOnInsert", bson.D{
			{"create_time", targetTime.UnixMilli()},
		}},
	}

	//logger.Infof(ctx, "%v", data)
	opt := options.Update().SetUpsert(true)
	if _, err := l.write.SuperiorAwardDaily.Update(ctx, updateFilter, update, opt); err != nil {
		return err
	}

	day, _ := utils.TimeByDay(targetTime)
	logger.Infof(ctx, "==-==每日%d奖励计算完成", day)

	return nil
}

func (l awardCalcSumControl) countSuperiorContentAwardDetail(ctx context.Context, targetTime time.Time, value interface{}) (uint, error) {
	filter := map[string]interface{}{
		"create_time": bson.D{
			{"$gte", utils.ZeroTime(targetTime).UnixMilli()},
			{"$lt", utils.ZeroTime(utils.CalcTime(targetTime, 1)).UnixMilli()},
		},
		"type": value,
	}

	items, err := l.read.SuperiorContentAwardDetail.FindAll(ctx, filter)
	if err != nil {
		return 0, err
	}

	var count float64
	for _, detail := range items {
		count += detail.Award
	}

	return uint(math.Round(count * 100)), nil
}

// 从 wx_reward_log 中统计的奖励
func (l awardCalcSumControl) wxRewardLogDetail(ctx context.Context, targetTime time.Time, value interface{}) (uint, error) {
	filter := map[string]interface{}{
		"create_time_start": utils.ZeroTime(targetTime).UnixMilli(),
		"create_time_end":   utils.ZeroTime(utils.CalcTime(targetTime, 1)).UnixMilli(),
		"type":              value,
	}

	items, err := l.read.WxRewardLog.Find(ctx, 0, 0, filter)
	if err != nil {
		return 0, err
	}

	var amount int64
	for _, item := range items {
		amount += item.Amount
	}

	logger.Infof(ctx, "==-==quding,filter %+v,len %v", filter, len(items))

	return uint(amount), nil
}

func (l awardCalcSumControl) countSecretGameOrder(ctx context.Context, targetTime time.Time) (uint, error) {
	var sumAllGame uint
	filter := map[string]interface{}{
		"create_time": bson.D{
			{"$gte", utils.ZeroTime(targetTime).UnixMilli()},
			{"$lt", utils.ZeroTime(utils.CalcTime(targetTime, 1)).UnixMilli()},
		},
		"notify_status": 3, // 通知状态 1：回调成功 2：重试中 3：放弃通知
	}
	statisticalList, err := l.sumDb.Game.GameOrder(ctx, filter)
	if err != nil {
		return 0, err
	}

	// 补零统计
	nowZero := utils.ZeroTime(targetTime).UnixMilli()
	statisticalMap := map[string]model.GameStatistical{}
	for _, statistical := range statisticalList {
		statisticalMap[statistical.GameId] = statistical
	}
	gameInfos, err := l.write.SecretGame.FindAll(ctx, nil)
	if err != nil {
		return 0, err
	}
	for _, info := range gameInfos {
		_, ok := statisticalMap[info.GameId]
		if !ok {
			statisticalList = append(statisticalList, model.GameStatistical{
				ID:         primitive.ObjectID{},
				GameId:     info.GameId,
				GameName:   info.GameName,
				AmountSum:  0,
				Day:        nowZero,
				UpdateTime: targetTime.UnixMilli(),
			})
		}
	}

	for _, statistical := range statisticalList {
		sumAllGame += statistical.AmountSum

		updateFilter := bson.D{
			{"day", utils.ZeroTime(targetTime).UnixMilli()},
			{"game_id", statistical.GameId},
		}
		insertData := bson.D{
			{"create_time", targetTime.UnixMilli()},
		}
		if _, err = l.write.GameStatistical.Upsert(ctx, updateFilter, statistical, insertData); err != nil {
			return 0, err
		}
	}
	return sumAllGame, err
}
