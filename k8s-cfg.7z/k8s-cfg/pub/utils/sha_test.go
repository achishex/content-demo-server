package utils

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestSha256String(t *testing.T) {
	in := "appkey=5f03a35d00ee52a21327ab048186a2c4&random=7226249334&time=1457336869"
	out := Sha256String(in)
	want := "c13e54f047ed75e821e698730c72d030dc30e5b510b3f8a0fb6fb7605283d7df" // quick-login 签名demo
	assert.Equal(t, want, out)
}
