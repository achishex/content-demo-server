package user

import "testing"

func TestJudgeAge(t *testing.T) {
	dates := []string{
		"2000-01-01",
		"2007-01-01",
		"2000-1-1",
		"2007-1-1",
		"2000-11-1",
		"2007-11-1",
		"2000-11-12",
		"2007-11-12",
		"2000-1-12",
		"2007-1-12",
	}
	for _, date := range dates {
		IsAdult, err := JudgeAdult(date)
		if err != nil {
			t.Fatal(err)
		}

		t.Log(date, IsAdult)
	}

}
