package const_busi

const (
	WxPayStatusSuccess    = "SUCCESS"    //支付成功
	WxPayStatusRefund     = "REFUND"     //转入退款
	WxPayStatusNotPay     = "NOTPAY"     //未支付
	WxPayStatusClosed     = "CLOSED"     //已关闭
	WxPayStatusRevoked    = "REVOKED"    //已撤销（付款码支付）
	WxPayStatusUserPaying = "USERPAYING" //用户支付中（付款码支付）
	WxPayStatusPayError   = "PAYERROR"   //支付失败(其他原因，如银行返回失败)
)

const (
	PayStatusNoPay         = 1  //未支付
	PayStatusPaying        = 2  //支付中
	PayStatusSuccess       = 3  //支付成功
	PayStatusRefund        = 4  //退款
	PayStatusFail          = 9  //支付失败
	PayStatusRefundSuccess = 10 //退款成功
)

var WxGamePayStatusMapping = map[string]int32{
	WxPayStatusSuccess:    PayStatusSuccess,
	WxPayStatusRefund:     PayStatusRefund,
	WxPayStatusNotPay:     PayStatusNoPay,
	WxPayStatusUserPaying: PayStatusPaying,
	WxPayStatusPayError:   PayStatusFail,
	WxPayStatusClosed:     PayStatusFail,
	WxPayStatusRevoked:    PayStatusFail,
}

const (
	// 支付平台
	PayPlatformWechatPay = 1 //微信
	PayPlatformAliPay    = 2 //支付宝
	PayPlatformApplePay  = 3 //苹果
)

const (
	//订单状态
	OrderStatusNormal = 1 //正常
	OrderStatusClosed = 2 //关闭
)
