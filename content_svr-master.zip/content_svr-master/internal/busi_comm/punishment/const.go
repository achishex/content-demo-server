package punishment

const (
	_                   int32 = iota
	UserDynamic               // 作品
	UserPrivateChat           // 单聊
	UserPicture               // 带图作品二审
	UserBackdropPicture       // 背景图二审
	UserComment         = 10
)
