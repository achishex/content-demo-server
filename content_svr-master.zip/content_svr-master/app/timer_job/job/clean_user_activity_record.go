package job

import (
	"content_svr/db/dao"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

func InitCleanUserActivity(write, read *dao.ManagerDB) {
	ctx := requestid.WithRequestID(context.Background())
	target := time.Now().AddDate(0, 0, -1)
	ctrl := newCleanUserActivityControl(write, read)
	if err := ctrl.DoTask(ctx, target); err != nil {
		logger.Error(context.Background(), "InitCleanUserActivity:", err)
	}
}

type cleanUserActivityControl struct {
	write, read *dao.ManagerDB
}

func newCleanUserActivityControl(write, read *dao.ManagerDB) cleanUserActivityControl {
	ctrl := cleanUserActivityControl{}
	ctrl.write = write
	ctrl.read = read
	return ctrl
}

func (l cleanUserActivityControl) once() {
	ctx := requestid.WithRequestID(context.Background())
	if err := l.DoTask(ctx, time.Now()); err != nil {
		logger.Error(ctx, "InitAwardCalcSum:", err)
	}
}

func (l cleanUserActivityControl) DoTask(ctx context.Context, targetTime time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	now := time.Now()
	day, _ := utils.TimeByDay(utils.CalcTime(now, -40))
	filter := map[string]interface{}{
		"day": bson.D{
			{"$lte", day},
		},
	}
	count, err := l.write.SecretUserActivityDaily.DeleteMany(ctx, filter)
	if err != nil {
		return err
	}
	logger.Infof(ctx, "InitCleanUserActivity delete calcMemberSum: %d", count)

	return nil
}
