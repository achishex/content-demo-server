package handler

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/busi_comm/trans"
	"content_svr/internal/busi_comm/version"
	"content_svr/internal/content_mng"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/protobuf/pbmgdb"
	"content_svr/protobuf/pbsecurity"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/requestid"
	"content_svr/pub/user"
	"content_svr/pub/utils"
	"content_svr/setting"
	"context"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/gogo/protobuf/proto"
	"github.com/kevwan/mapreduce/v2"
	"google.golang.org/protobuf/runtime/protoimpl"
	"math/rand"
	"net/http"
	"strconv"
	"strings"
	"time"
)

// 获取别人回复给用户的消息
func (p *AdminHandler) GetReplyMsg(ctx *gin.Context, req *pbapi.GetReplyMsgReq) ([]*pbapi.GetReplyMsgSimple, error) {
	//headerBytes, _ := json.Marshal(ctx.Request.Header)
	//logger.Infof(ctx, "header=%v", string(headerBytes))

	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}
	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	items, err := p.ContentMng.GetReplyMsg(ctx, header, req)
	if err != nil {
		return nil, err
	}
	return items, nil
}

func (p *AdminHandler) WorkidsGetshare(ctx *gin.Context, req *pbapi.PersonalBottleWorksShareReq) ([]*pbapi.PersonalBottleWorksSimple, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	// limit 默认为3
	if req.GetSize() == 0 {
		req.Size = 3
	}
	userId := middleware.GetUserID(ctx)

	items, err := p.ContentMng.GetShare(ctx, header, req)
	if err != nil {
		return nil, err
	}

	// 转换 model；补充字段 RemindNode
	resp := p.transToResp(ctx, items, err)

	// 补充字段: 是否允许评论 EnableComment
	resp = p.AddCommentInfo(ctx, resp)

	// 补充字段:评论数 NewCommentCount, bgImage, talkMode
	resp, err = p.ContentMng.NewGetShare(ctx, userId, resp)
	if err != nil {
		logger.Error(ctx, "NewGetShare: ", err)
	}
	return resp, nil
}

func (p *AdminHandler) transToResp(ctx *gin.Context, items content_mng.UserWorkScoreList, err error) []*pbapi.PersonalBottleWorksSimple {
	resp := make([]*pbapi.PersonalBottleWorksSimple, 0) //&pbapi.PersonalBottleWorksShareResp{}
	for _, item := range items {
		var extInfo = &pbapi.ExtInfo{}
		if item.SignStarInfo != nil {
			extInfo.StarSignData = item.SignStarInfo
		}

		//游戏卡片跳转h5地址
		if item.WorkInfoLocal.WorkInfoDbModel.GetSpecial() == int32(pbconst.WorkSpecialEnum_work_special_type_game_card) {
			page := fmt.Sprintf("%s%d", config.ServerConfig.OfficialCardConfig.GameCardUrl, rand.Intn(config.ServerConfig.OfficialCardConfig.GameCardPageNum)+1)
			extInfo.Url = proto.String(page)
		}

		tranRet := trans.TransWorkInfoLocalScoreInfoToWorksSimple(item.WorkInfoLocal,
			item.AuthorInfoLocal, item.Liked, extInfo)
		//
		if len(item.RemindInfo) > 0 {
			tranRet.RemindNode = item.RemindInfo
		}
		if len(item.RemindGroup) > 0 {
			tranRet.RemindGroup = item.RemindGroup
		}
		if item.Followed == 1 {
			tranRet.Followed = proto.Bool(true)
		} else {
			tranRet.Followed = proto.Bool(false)
		}

		resp = append(resp, tranRet)
	}
	return resp
}

func (p *AdminHandler) TalkStatus(ctx *gin.Context, req *pbapi.TalkStatusReq) (*pbapi.TalkStatus, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	uid := middleware.GetUserID(ctx)

	if req.GetFromUserId() <= 0 || uid <= 0 {
		return nil, errorcode.PARAM_ERROR
	}

	return p.ContentMng.TalkStatus(ctx, header, uid, req)
}
func (p *AdminHandler) SendMsg(ctx *gin.Context, req *pbapi.SendMsgReq) (*pbapi.SendMsgSimple, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	userId := middleware.GetUserID(ctx)
	// 检查位置信息
	if p.ContentMng.AclCheck(ctx, cm_const.AppTypeDict[header.Apptype], userId) {
		// 需要封禁
		return nil, errorcode.ACLFORBID
	}

	if req.GetMessageType() == 0 {
		req.MessageType = int32(pbconst.MessageTypeEnum_msg_type_txt)
	}
	if req.GetLatitude() == 0 { // 小程序目前会传0过来，为了兼容他，做如下逻辑。
		req.Latitude = nil
	}
	if req.GetLongitude() == 0 {
		req.Longitude = nil
	}
	req.SessionType = proto.Int32(0) // 默认为0

	var resp *pbapi.SendMsgSimple
	//兼容老app使用新的临时会话数据发私信。
	if req.GetWorkId() == const_busi.HomePagePrivateMessageDefaultWorkId {
		logger.Infof(ctx, "send message use temp session, req: %v", *req)
		resp, err = compatibilityOldAppUsingNewProtocal(ctx, p, header, req)
	} else {
		//if req.GetWorkId() > const_busi.HomePagePrivateMessageDefaultWorkId { // 不再支持老版本基于动态的临时会话 by quding
		//	return nil, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "请下载最新猫爪App去聊天~")
		//}
		resp, err = p.ContentMng.SendMsg(ctx, header, req)
	}
	if err != nil {
		logger.Errorf(ctx, "SendMsg fail, err: %v", err)
		return resp, err
	}

	if header.GetVersioncode() >= version.TalkADVersion { //新版本返回status
		if status, err2 := p.TalkStatus(ctx, &pbapi.TalkStatusReq{
			FromUserId: req.GetToUserId(),
			WorkId:     req.GetWorkId(),
		}); err2 == nil {
			resp.TalkStatus = status
		} else {
			logger.Warnf(ctx, "get TalkStatus fail, skip, err: %v", err2)
		}
	}

	return resp, err
}
func compatibilityOldAppUsingNewProtocal(ctx context.Context, p *AdminHandler, header *pbapi.HttpHeaderInfo, req *pbapi.SendMsgReq) (*pbapi.SendMsgSimple, error) {
	tmpSessionReq := &pbapi.HomePagePrivateMessagePushReq{
		ToUserId:    req.ToUserId,
		Content:     req.Content,
		WorkId:      req.WorkId,
		MessageType: req.MessageType,
		Width:       req.Width,
		High:        req.High,
		Duration:    req.Duration,
		ObjectId:    req.ObjectId,
		ClientId:    req.ClientId,
		MemeId:      req.MemeId,
		SessionType: req.SessionType,
		Longitude:   req.Longitude,
		Latitude:    req.Latitude,
	}
	tmpSessionResp, err := p.ContentMng.PushPrivateMessage(ctx, header, tmpSessionReq)
	if err != nil || tmpSessionResp == nil {
		return &pbapi.SendMsgSimple{}, err
	}

	return &pbapi.SendMsgSimple{
		SessionId:      tmpSessionResp.SessionId,
		MessageId:      tmpSessionResp.MessageId,
		CreateTime:     tmpSessionResp.CreateTime,
		ClientId:       tmpSessionResp.ClientId,
		Status:         tmpSessionResp.Status,
		FromCoordinate: tmpSessionResp.FromCoordinate,
		ToCoordinate:   tmpSessionResp.ToCoordinate,
	}, nil
}

type TmpWorkObjectAttrRequest struct {
	// @inject_tag: json:"type" form:"type"
	Type interface{} `protobuf:"varint,1,opt,name=type,proto3,oneof" json:"type" form:"type"` // 对象类型 1 图片 2 视频 4 语音
	// @inject_tag: json:"width" form:"width"
	Width interface{} `protobuf:"varint,2,opt,name=width,proto3,oneof" json:"width" form:"width"`
	// @inject_tag: json:"high" form:"high"
	High interface{} `protobuf:"varint,3,opt,name=high,proto3,oneof" json:"high" form:"high"`
	// @inject_tag: json:"objectId" form:"objectId"
	ObjectId *string `protobuf:"bytes,4,opt,name=objectId,proto3,oneof" json:"objectId" form:"objectId"`
	// @inject_tag: json:"thumbnail" form:"thumbnail"
	Thumbnail *string `protobuf:"bytes,5,opt,name=thumbnail,proto3,oneof" json:"thumbnail" form:"thumbnail"` // 视频的截图地址
	// @inject_tag: json:"imgMd5" form:"imgMd5"
	ImgMd5 *string `protobuf:"bytes,6,opt,name=imgMd5,proto3,oneof" json:"imgMd5" form:"imgMd5"` // 图片的MD5值

}

type TmpPushChitchatReq struct {
	state         protoimpl.MessageState
	sizeCache     protoimpl.SizeCache
	unknownFields protoimpl.UnknownFields

	// @inject_tag: json:"type" form:"type"
	Type int32 `protobuf:"varint,1,opt,name=type,proto3" json:"type" form:"type"` // 作品类型不能为空,        作品类型 1 图片 2 视频 3 文字
	// @inject_tag: json:"pushType" form:"pushType"
	PushType *int32 `protobuf:"varint,2,opt,name=pushType,proto3,oneof" json:"pushType" form:"pushType"` // 投递类型，1:匿名投递； 2:非匿名投递，默认为匿名投递
	// @inject_tag: json:"browseType" form:"browseType"
	BrowseType *int32 `protobuf:"varint,3,opt,name=browseType,proto3,oneof" json:"browseType" form:"browseType"` // 曝光类型，1:超级曝光，不限次数； 2:普通曝光，默认为超级曝光 3.神贴
	// @inject_tag: json:"title" form:"title"
	Title *string `protobuf:"bytes,4,opt,name=title,proto3,oneof" json:"title" form:"title"` // 图片或者视频的标题，如果是文字类型则是文字内容，文字类型时不能为空
	// @inject_tag: json:"workObjects" form:"workObjects"
	WorkObjects []*TmpWorkObjectAttrRequest `protobuf:"bytes,5,rep,name=workObjects,proto3" json:"workObjects" form:"workObjects"` // 作品的图片或者视频存储对象
	// @inject_tag: json:"fileSize" form:"fileSize"
	FileSize *int64 `protobuf:"varint,6,opt,name=fileSize,proto3,oneof" json:"fileSize" form:"fileSize"` // 文件大小
	// @inject_tag: json:"longitude" form:"longitude"
	Longitude *float64 `protobuf:"fixed64,7,opt,name=longitude,proto3,oneof" json:"longitude" form:"longitude"` // 经度
	// @inject_tag: json:"latitude" form:"latitude"
	Latitude *float64 `protobuf:"fixed64,8,opt,name=latitude,proto3,oneof" json:"latitude" form:"latitude"` // 纬度
	// @inject_tag: json:"createTime" form:"createTime"
	CreateTime interface{} `protobuf:"varint,12,opt,name=createTime,proto3,oneof" json:"createTime" form:"createTime"` //客户端作品创建时间的时间戳，精确到毫秒
	// @inject_tag: json:"startTime" form:"startTime"
	StartTime *int64 `protobuf:"varint,13,opt,name=startTime,proto3,oneof" json:"startTime" form:"startTime"` // 开始分享时间，时间戳，默认服务器当前时间
	// @inject_tag: json:"duration" form:"duration"
	Duration *int32 `protobuf:"varint,14,opt,name=duration,proto3,oneof" json:"duration" form:"duration"` // "分享持续时间，单位s，默认86400", hidden = true      // todo 没用了
	// @inject_tag: json:"loveFlag" form:"loveFlag"
	LoveFlag *int32 `protobuf:"varint,15,opt,name=loveFlag,proto3,oneof" json:"loveFlag" form:"loveFlag"` // 是否带有520活动标识，0：否；1：是，默认为否
	// List<int32> tagId;        // 发布内容标签id  TODO 没用了
	// @inject_tag: json:"clientId" form:"clientId"
	ClientId *string `protobuf:"bytes,16,opt,name=clientId,proto3,oneof" json:"clientId" form:"clientId"` // 作品的客户端唯一标识
	// @inject_tag: json:"talkType" form:"talkType"
	TalkType *int32 `protobuf:"varint,17,opt,name=talkType,proto3,oneof" json:"talkType" form:"talkType"` // 作品支持的聊天类型，1：单聊，2：普通群聊， 3：语音群聊，4：文字群聊 5: 纯语音群聊（不可修改） 默认为1
	// @inject_tag: json:"templateId" form:"templateId"
	TemplateId *int64 `protobuf:"varint,18,opt,name=templateId,proto3,oneof" json:"templateId" form:"templateId"` // 发布模版ID
	// @inject_tag: json:"qqFriend" form:"qqFriend"
	QqFriend int32 `protobuf:"varint,19,opt,name=qqFriend,proto3" json:"qqFriend" form:"qqFriend"` // 是否开启添加QQ好友，1开启，否则不开启
	// @inject_tag: json:"special" form:"special"
	Special *int32 `protobuf:"varint,20,opt,name=special,proto3" json:"special" form:"special"` // 特殊作品标识 0:普通 1:神奇骰子 2:唠唠 3:扩列
	// @inject_tag: json:"expandIds" form:"expandIds"
	ExpandIds []int64 `protobuf:"varint,21,rep,packed,name=expandIds,proto3" json:"expandIds" form:"expandIds"` // 扩列标签id
	// @inject_tag: json:"systemWorkId" form:"systemWorkId"
	SystemWorkId *int64 `protobuf:"varint,22,opt,name=systemWorkId,proto3,oneof" json:"systemWorkId" form:"systemWorkId"` // 系统卡片的workid
	// @inject_tag: json:"enableComment" form:"enableComment"
	EnableComment *int32 `protobuf:"varint,23,opt,name=enableComment,proto3,oneof" json:"enableComment" form:"enableComment"` // 帖子打开评论开关， 0：关闭， ：1打开
	// @inject_tag: json:"reminds" form:"reminds"
	RemindNode []*pbapi.RemindUserNode `protobuf:"bytes,24,opt,name=remindNode,proto3,oneof" json:"reminds" form:"reminds"` // @用户信息列表
	// @inject_tag: json:"subType" form:"subType"
	SubType *int32 `protobuf:"varint,25,opt,name=subType,proto3,oneof" json:"subType" form:"subType"` // 子类型

	RemindGroup []*pbapi.RemindGroupNode `json:"remind_group" form:"remind_group"` // at群
}

func (p *AdminHandler) pushTrans(ctx context.Context, src *TmpPushChitchatReq) (*pbapi.PushChitchatReq, error) {
	ctimeInt64, err := utils.Interface2Int64(src.CreateTime)
	if err != nil {
		logger.Errorf(ctx, "")
		return nil, err
	}

	destAttrList := make([]*pbapi.WorkObjectAttrRequest, 0)
	for _, attr := range src.WorkObjects {
		destAttr := &pbapi.WorkObjectAttrRequest{
			ObjectId:  attr.ObjectId,
			Thumbnail: attr.Thumbnail,
		}
		// TYPE
		val, err := utils.Interface2Int64(attr.Type)
		if err != nil {
			logger.Error(ctx, "parse Type failed", err)
			return nil, err
		}
		destAttr.Type = proto.Int32(int32(val))

		// Width
		val, err = utils.Interface2Int64(attr.Width)
		if err != nil {
			logger.Error(ctx, "parse Width failed", err)
			return nil, err
		}
		destAttr.Width = proto.Int32(int32(val))
		// High
		val, err = utils.Interface2Int64(attr.High)
		if err != nil {
			logger.Error(ctx, "parse High failed", err)
			return nil, err
		}
		destAttr.High = proto.Int32(int32(val))

		destAttrList = append(destAttrList, destAttr)
	}

	member := &pbapi.PushChitchatReq{
		Type:          src.Type,
		PushType:      src.PushType,
		BrowseType:    src.BrowseType,
		Title:         src.Title,
		SubType:       src.SubType,
		WorkObjects:   destAttrList,
		FileSize:      src.FileSize,
		Longitude:     src.Longitude,
		Latitude:      src.Latitude,
		CreateTime:    &ctimeInt64,
		StartTime:     src.StartTime,
		Duration:      src.Duration,
		LoveFlag:      src.LoveFlag,
		ClientId:      src.ClientId,
		TalkType:      src.TalkType,
		TemplateId:    src.TemplateId,
		QqFriend:      src.QqFriend,
		Special:       src.Special,
		ExpandIds:     src.ExpandIds,
		SystemWorkId:  src.SystemWorkId,
		EnableComment: src.EnableComment,
		RemindNode:    src.RemindNode,
		RemindGroup:   src.RemindGroup,
	}

	return member, nil
}

func (p *AdminHandler) PushChitchat(ctx *gin.Context, srcReq *TmpPushChitchatReq) (int64, error) {
	req, err := p.pushTrans(ctx, srcReq)
	if err != nil {
		logger.Error(ctx, "pushTrans faile,", err)
		return 0, err
	}

	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return 0, err
	}
	logger.Infof(ctx, "PushChitchat.busi.header=%+v, req=%v", header, utils.StructToJsonString(req))
	req.Duration = proto.Int32(86400 * 3)
	if req.Special == nil {
		req.Special = proto.Int32(int32(pbconst.WorkSpecialEnum_work_special_type_laolao))
	}
	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)
	userId := middleware.GetUserID(ctx)
	// 检查位置信息
	if p.ContentMng.AclCheck(ctx, cm_const.AppTypeDict[header.Apptype], userId) {
		// 需要封禁
		return 0, errorcode.ACLFORBID
	}

	req.BrowseType = proto.Int32(1)
	workid, err := p.ContentMng.PushChitchat(ctx, header, req)
	if err != nil {
		return 0, err
	}
	return workid, nil
}

func (p *AdminHandler) cleanUnReadMsg(ctx *gin.Context, req *pbapi.PushChitchatReq) (string, error) {
	return "", nil
}

func (p *AdminHandler) UploadLog(ctx *gin.Context, uploadLog *pbapi.UploadLogReq) (*pbapi.UploadLogResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}
	userId, err := p.ContentMng.GetUserId(ctx, header.GetToken())

	logger.Infof(ctx, "upload_log,userid %v,header=%v", userId, utils.StructToJsonString(header))
	logger.Infof(ctx, "upload_log,userid %v,type=%v, log%v", userId, uploadLog.GetType(), uploadLog.GetLog())

	return &pbapi.UploadLogResp{
		Status: true,
	}, nil
}

func (p *AdminHandler) GetAppConfig(ctx *gin.Context) (*pbapi.AppConfigResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	defer logger.Infof(ctx, "get_app_config,ctx_header=%v", utils.StructToJsonString(ctx.Request.Header))

	talkMode := const_busi.TalkModeUnknown
	publishWordCount := const_busi.PublishWordCount
	enableUploadLog := false

	//userId := header.Debuguserid
	userInfo, err := p.ContentMng.GetUserInfoByHeader(ctx, header)
	if err == nil {
		if userInfo.UserInfoDbModel.GetUserType() == 2 {
			publishWordCount = const_busi.OfficialPublishWordCount
		}

		talkMode = p.ContentMng.GetUserInfoTalkMode(ctx, userInfo.UserInfoDbModel.GetUserId())
		if talkMode == const_busi.TalkModeUnknown {
			adult, err := user.JudgeAdult(userInfo.UserInfoDbModel.GetBirth())
			if err != nil {
				logger.Error(ctx, "GetAppConfig JudgeAdult", err)
			}
			if !adult {
				talkMode = const_busi.TalkModeClose
			} else {
				talkMode = userInfo.PsecretUserExtInfo.GetTalkMode()
			}
		}

		//userIds := [...]int64{4323936494238720, 4340433133352960, 4379943227133952, 4405176656888832, 4311474405225472, 136775764264960}
		//for tmpId := range userIds {
		//	if int64(tmpId) == userInfo.UserInfoDbModel.GetUserId() {
		//		enableUploadLog = true
		//	}
		//}
	}

	isMiniShowPublishBtn := true
	if header.Apptype == cm_const.AppTypeMobileAndroid {
		//
	} else if header.Apptype == cm_const.AppTypeMobileIos {
		//
	} else if header.Apptype == cm_const.AppTypeAppletWx {
		isMiniShowPublishBtn = false
	} else if header.Apptype == cm_const.AppTypeAppletQq {
		// 晚上20:00-次日早上09:00，“发布”按钮显示
		//hour := time.Now().Hour()
		//if hour >= 20 || hour < 9 {
		//	isMiniShowPublishBtn = true
		//} else {
		//	isMiniShowPublishBtn = false
		//}
		isMiniShowPublishBtn = true
	}

	enableGetJingming := true // android 审核使用
	if header.Versioncode > setting.Maozhua.AndroidLimitVersion.Get() {
		if strings.Contains(setting.Maozhua.AndroidLimitChannel.Get(), header.Channel) {
			enableGetJingming = false
		}
	}

	//活跃用户记录，用于昵称查询
	go func() {
		defer func() {
			if err := recover(); err != nil {
				logger.Errorf(ctx, "add active user panic: %v", err)
				return
			}
		}()

		if userInfo != nil {
			if err := p.UserCenterMng.ActiveUser(ctx, userInfo.UserInfoDbModel.GetUserId(), userInfo.UserInfoDbModel.GetNickName()); err != nil {
				return
			}
		}
	}()

	// qudingding_config 各端基础参数配置
	// 文档说明 https://wm3zyl5om7.feishu.cn/wiki/WZNrwNrD3if2V7kJ4rMcb2QqnHg
	return &pbapi.AppConfigResp{
		IsMiniShowPublishBtn:         isMiniShowPublishBtn,
		IsShowStarBtn:                false,
		CommentWordCount:             const_busi.MaxCommentLen,
		PublishWordCount:             int32(publishWordCount),
		ChatWordCount:                const_busi.ChatWordCount,
		LevelModifyHeader:            2,
		LevelSendComment:             1,
		MaxLevel:                     const_level.UserMaxLevel, // 目前最高等级
		LevelChatSendPhoto:           const_level.UserMaxLevel, // 发送图片最低等级限制
		LevelWorkAlbum:               const_level.UserMaxLevel, // 动态上传图片最低等级限制
		LevelCommentEmotion:          const_level.UserMaxLevel, // 评论发送表情最低等级限制
		IOSIsFixSlide:                true,                     // false 则不打开额外的手势传递代码
		VisitorMaxWorkCount:          3,                        // 游客可看的动态条数(取值<=5)
		EnableUploadLog:              enableUploadLog,
		LevelWorkEmotion:             const_level.UserMaxLevel, // 动态上传表情最低等级限制
		TalkMode:                     talkMode,                 // 私信模式
		VipTalkNoReplyMaxCount:       setting.Maozhua.VipTalkNoReplyMaxCount.Get(),
		TalkNoReplyMaxCount:          setting.Maozhua.TalkNoReplyMaxCount.Get(),
		TalkMessageStrangerMaxLength: setting.Maozhua.TalkMessageStrangerMaxLength.Get(),
		EnableSlideiOS:               true, // iOS 是否支持滑动返回
		WorkLineBreakCount:           8,
		EnableVideoToGif:             true,
		GroupsMaxLimit:               uint32(setting.Maozhua.ImGroup.MaxGroupLimit.Get()),
		GroupsMemberMaxLimit:         uint32(setting.Maozhua.ImGroup.MaxGroupMemberLimit.Get()),
		GroupsCreateLevelLimit:       uint32(setting.Maozhua.ImGroup.GroupCreateLevelLimit.Get()),
		EnableTalkAD:                 setting.Maozhua.EnableTalkAD.Get() > 0,
		TalkADNoReplyMaxCount:        setting.Maozhua.TalkADNoReplyMaxCount.Get(),
		TalkADSessSendCount:          setting.Maozhua.TalkADSessSendCount.Get(),
		EnableGetJingming:            enableGetJingming,
		AwardFirstWork:               setting.Maozhua.AwardFirstWork.Get(),
		HomepageBgLevelLimit:         uint32(setting.Maozhua.HomepageBgLevelLimit.Get()),
		EnableUserGuide:              false,
	}, nil
}

func (p *AdminHandler) GetDiscoveryList(ctx *gin.Context, req *pbapi.DiscoveryListReq) (*pbapi.DiscoveryListResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	versionCodeInt, _ := strconv.Atoi(header.GetVersioncode())
	loginUserId := middleware.GetUserID(ctx)

	resp := &pbapi.DiscoveryListResp{}

	if (header.GetApptype() == cm_const.AppTypeMobileAndroid && versionCodeInt >= 2130000) ||
		(header.GetApptype() == cm_const.AppTypeMobileIos && versionCodeInt >= 2120000) {
		gameRet, err := p.GameMng.GameList(ctx, &pbapi.GameListReq{})
		if err == nil {
			for _, item := range gameRet.GetList() {
				if item.GameDebugMode != 1 || strings.Contains(setting.Maozhua.GameWhiteListStr.Get(), fmt.Sprintf("%d", loginUserId)) {
					resp.List = append(resp.List, &pbapi.DiscoveryListItem{
						Type:    4,
						ItemId:  item.GetGameId(),
						Title:   item.GetGameName(),
						IconUrl: item.GetGameIcon(),
						JumpUrl: item.GetGameUrl(),
					})
				}
			}
		}
	}

	if versionCodeInt >= 2100000 {
		resp.List = append(resp.List, &pbapi.DiscoveryListItem{
			Type:    6,
			Title:   "每日签到",
			IconUrl: "https://image.52mengdong.com/workshop/soup/169578220_icon_qiandao.png",
		})
	}

	resp.List = append(resp.List, &pbapi.DiscoveryListItem{
		Type:    1,
		Title:   "猫爪运动",
		IconUrl: "https://image.52mengdong.com/workshop/soup/169415581_dis_icon_yundong@2x.png",
	})

	resp.List = append(resp.List, &pbapi.DiscoveryListItem{
		Type:    2,
		Title:   "星座运势",
		IconUrl: "https://image.52mengdong.com/workshop/soup/169415578_dis_icon_xingzuo@2x.png",
	})

	if (header.GetApptype() == cm_const.AppTypeMobileAndroid && versionCodeInt >= 2080100) || header.GetApptype() == cm_const.AppTypeMobileIos && versionCodeInt >= 2080000 {
		resp.List = append(resp.List, &pbapi.DiscoveryListItem{
			Type:    3,
			Title:   "可乐名人堂",
			IconUrl: "https://image.52mengdong.com/workshop/soup/169441968_20230911-160649.png",
		})
	}

	//if versionCodeInt >= 2090000 {
	//	resp.List = append(resp.List, &pbapi.DiscoveryListItem{
	//		Type:    5,
	//		Title:   "表情广场",
	//		IconUrl: "https://image.52mengdong.com/workshop/soup/169509091_icon_guangchang.png",
	//	})
	//}

	// 游戏
	//gameRet, err := p.GameMng.GameList(ctx, &pbapi.GameListReq{})
	//if err == nil {
	//	for _, item := range gameRet.GetList() {
	//		resp.List = append(resp.List, &pbapi.DiscoveryListItem{
	//			Type:    4,
	//			ItemId:  item.GetGameId(),
	//			Title:   item.GetGameName(),
	//			IconUrl: item.GetGameIcon(),
	//			JumpUrl: item.GetGameUrl(),
	//		})
	//	}
	//}

	return resp, nil
}

// 设置星座生日。
func (p *AdminHandler) SetStarSignBirth(ctx *gin.Context, req *pbapi.Birth) (string, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return "", err
	}
	err = p.ContentMng.SetStarSignBirth(ctx, header, req)
	if err != nil {
		return "", err
	}

	return "", nil
}

// 返回星座生日。
func (p *AdminHandler) GetStarSignBirth(ctx *gin.Context) (*pbapi.Birth, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}
	data, err := p.ContentMng.GetStarSignBirth(ctx, header)
	if err != nil {
		return nil, err
	}
	return data, nil
}

// 返回星座运势。
func (p *AdminHandler) GetStarSignInfo(ctx *gin.Context) (*pbapi.StarSignData, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}
	data, err := p.ContentMng.GetStarSignInfo(ctx, header)
	if err != nil {
		return nil, err
	}
	return data, nil
}

func (p *AdminHandler) GetMemeSquare(ctx *gin.Context, req *pbapi.MemeSquareReq) (*pbapi.MemeSquareResp, error) {
	data, err := p.ContentMng.GetMemeSquare(ctx, req)
	if err != nil {
		return nil, err
	}

	return data, nil
}

func (p *AdminHandler) MemeReport(ctx *gin.Context, req *pbapi.MemeReportReq) (*pbapi.MemeReportResp, error) {
	data, err := p.ContentMng.MemeReport(ctx, req)
	if err != nil {
		return nil, err
	}

	if req.MemeId <= 0 {
		return nil, errorcode.PARAM_ERROR
	}

	return data, nil
}

// 获取用户等级信息。
func (p *AdminHandler) GetUserLevel(ctx *gin.Context) (*pbuserapi.LevelInfo, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	data, err := p.UserLevMng.GetUserLevel(ctx, header)
	if err != nil {
		return nil, err
	}

	return data, nil
}

func (p *AdminHandler) GetUserInfo(ctx *gin.Context, req *pbuserapi.UserInfoReq) (resp *pbuserapi.UserInfoResp, err error) {
	if req.UserId == 0 {
		return nil, errors.New("user id is 0")
	}

	loginUserId := middleware.GetUserID(ctx)

	userInfo, err := p.ContentMng.GetUserInfo(ctx, req.GetUserId())
	if err != nil || userInfo == nil {
		return nil, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "用户不存在")
	}

	var (
		talkMode   int32
		remarkName string
		//tags       []*pbapi.SecretUserTagResponse
		starTarget     int32
		modifyIdentity bool
		modifyGender   bool
	)

	_ = mapreduce.Finish(func() error {
		talkMode = p.ContentMng.GetUserInfoTalkMode(ctx, req.GetUserId())
		return nil
	}, func() error {
		//fmt.Println(userInfo.UserInfoDbModel.GetUserId(), req.GetUserId())
		remarkName, _ = p.ContentMng.GetUserRemarkNameOne(ctx, loginUserId, req.GetUserId())
		return nil
	}, func() error {
		follow, err := p.ContentMng.GetUserFollowInfo(ctx, loginUserId, req.GetUserId())
		if err != nil {
			logger.Error(ctx, "GetFollowInfo", err)
		}
		starTarget = follow.GetStarTarget()
		return nil
	}, func() error {
		_, exist, err := p.ContentMng.CheckIdentificationCard(ctx, loginUserId)
		if err != nil {
			logger.Error(ctx, "GetFollowInfo", err)
		}
		if exist {
			modifyIdentity = false
		} else {
			modifyIdentity = true
		}
		return nil
	})

	if userInfo.UserInfoDbModel.GetUpdateGenderCount() != 0 && modifyIdentity {
		// 性别剩余修改次数
		modifyGender = true
	}

	var phone string
	if len(userInfo.UserInfoDbModel.GetPhone()) != 0 {
		phoneByte, _ := utils.AESDecrypt(userInfo.UserInfoDbModel.GetPhone(), utils.AesUserKey)
		phone = utils.MaskPhone(string(phoneByte))
	}

	userResponse := &pbapi.SimpleUserInfo{
		UserId:      userInfo.UserInfoDbModel.GetUserId(),
		NickName:    userInfo.UserInfoDbModel.GetNickName(), // 这里要用opennickname
		Photo:       userInfo.UserInfoDbModel.GetPhoto(),
		Gender:      userInfo.UserInfoDbModel.GetGender(),
		Birth:       userInfo.UserInfoDbModel.GetBirth(),
		Age:         utils.CalculateAge(userInfo.UserInfoDbModel.GetBirth()),
		SignId:      utils.CalculateConstellation(userInfo.UserInfoDbModel.GetBirth()),
		City:        userInfo.UserInfoDbModel.GetCity(),
		Province:    userInfo.UserInfoDbModel.GetProvince(),
		IsConvoy:    userInfo.IsPolice,
		ShowConvoy:  userInfo.ShowConvoy,
		MemberType:  userInfo.MemberType,
		WorksLock:   userInfo.UserInfoDbModel.GetWorksLock(),
		Enabled:     userInfo.UserInfoDbModel.GetEnabled(),
		CommentLock: userInfo.UserInfoDbModel.GetCommentLock(),
		//Openid:                  "",
		//ChitChatCdKey:           userInfo.PsecretUserExtInfo.GetChitChatCdKey(),
		BackgroundImage:         userInfo.PsecretUserExtInfo.GetBackgroundImage(),
		BackgroundImageShare:    userInfo.PsecretUserExtInfo.GetBackgroundImageShare(),
		BackgroundImageDownload: userInfo.PsecretUserExtInfo.GetBackgroundImageDownload(),
		Medals:                  userInfo.UserMedals,
		UserType:                userInfo.UserInfoDbModel.GetUserType(),
		ULevel:                  userInfo.PsecretUserExtInfo.GetUlevel(),
		//Tags:                    tags,
		//ChitChatCKeyUpCase: userInfo.PsecretUserExtInfo.GetChitChatCdKey(),
		TalkMode:           talkMode,
		RemarkName:         remarkName,
		StarTarget:         starTarget,
		Description:        userInfo.UserInfoDbModel.GetDescription(),
		ModifyIdentity:     modifyIdentity,
		ModifyBirth:        modifyIdentity,
		ModifyGender:       modifyGender,
		Phone:              phone,
		HomepageBackground: userInfo.PsecretUserExtInfo.GetHomepageBackground(),
	}

	resp = &pbuserapi.UserInfoResp{UserInfo: userResponse}
	return
}

func (p *AdminHandler) EditUserInfo(ctx *gin.Context, req *pbuserapi.EditUserInfoReq) (resp *pbuserapi.EditUserInfoResp, err error) {
	if req.HomepageBackground == "" {
		return nil, errorcode.PARAM_ERROR
	}
	return p.UserCenterMng.EditUserInfo(ctx, req)
}

func (p *AdminHandler) GetLevelInfo(ctx *gin.Context) (*pbuserapi.LevelAllInfoResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	versionCodeInt, _ := strconv.Atoi(header.GetVersioncode())
	if versionCodeInt < 2100000 {
		return p.UserLevMng.GetLevelInfo(ctx, header)
	}

	ret, err := p.UserCenterMng.LevelRights(ctx)
	if err != nil {
		logger.Errorf(ctx, "handler:DailySignCodeUse err: %v", err)
	}
	return ret, nil
}

// 用户签到。
func (p *AdminHandler) UserDailySign(ctx *gin.Context) (*pbuserapi.CommLevelUpResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	versionCodeInt, _ := strconv.Atoi(header.GetVersioncode())
	if versionCodeInt < 2100000 {
		return nil, errorcode.DailyVersionLow
	}

	data, err := p.UserLevMng.UserDailySign(ctx, header)
	if err != nil {
		return nil, err
	}
	return data, nil
}

// 核销激活码
func (p *AdminHandler) UserChitChatConfirm(ctx *gin.Context, req *pbuserapi.ConfirmChitchatCodeReq) (*pbuserapi.CommLevelUpResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	versionCodeInt, _ := strconv.Atoi(header.GetVersioncode())
	if versionCodeInt < 2100000 {
		return nil, errorcode.DailyVersionLow
	}

	data, err := p.UserLevMng.UserChitChatConfirm(ctx, header, req)
	if err != nil {
		return nil, err
	}
	return data, nil
}

// 获取激活码信息
func (p *AdminHandler) GetchitchatInfo(ctx *gin.Context) (*pbuserapi.ChitchatInfo, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	data, err := p.UserLevMng.GetChitchatInfo(ctx, header)
	if err != nil {
		return nil, err
	}
	return data, nil
}

// GetPublishStatus 获取发帖权限
func (p *AdminHandler) GetPublishStatus(ctx *gin.Context) (*pbuserapi.ChitchatStatusResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}
	data, err := p.UserLevMng.GetPublishStatus(ctx, header)
	if err != nil {
		return nil, err
	}
	return data, nil
}

func (p *AdminHandler) GetRemindOfficialList(ctx *gin.Context, req *pbuserapi.GetRemindOfficialListReq) (resp *pbuserapi.GetRemindOfficialListResp, err error) {
	loginUserId := middleware.GetUserID(ctx)

	data, err := p.UserLevMng.GetRemindOfficialListLogic(ctx)
	//if err != nil {
	//	return nil, err
	//}

	userList := p.buildRemindList(ctx, loginUserId, data)

	resp = &pbuserapi.GetRemindOfficialListResp{
		List:  userList,
		Total: int64(len(data)),
	}

	return resp, nil
}

// GetRemindMutualList 该接口废弃
func (p *AdminHandler) GetRemindMutualList(ctx *gin.Context, req *pbuserapi.GetRemindFollowerListReq) (resp *pbuserapi.GetRemindFollowerListResp, err error) {
	//return nil, errorcode.UserRemindStarTargetNewVersion
	loginUserId := middleware.GetUserID(ctx)

	data, total, err := p.UserLevMng.GetRemindMutualListLogic(ctx, loginUserId, req)
	if err != nil {
		return nil, err
	}

	userList := p.buildRemindList(ctx, loginUserId, data)

	resp = &pbuserapi.GetRemindFollowerListResp{
		List:  userList,
		Total: total,
	}

	return resp, nil
}

func (p *AdminHandler) SetRemindStarTarget(ctx *gin.Context, req *pbuserapi.UserStarTargetReq) (*pbuserapi.UserStarTargetResp, error) {
	loginUserId := middleware.GetUserID(ctx)

	if loginUserId == req.GetToUserId() {
		return nil, errorcode.RemarkNameSelfError
	}
	starTarget, err := p.ContentMng.SetStarTarget(ctx, loginUserId, req)
	if err != nil {
		return nil, err
	}

	return &pbuserapi.UserStarTargetResp{
		StarTarget: int32(starTarget),
	}, nil
}

func (p *AdminHandler) GetRemindStarTargetList(ctx *gin.Context) (*pbuserapi.UserStarTargetListResp, error) {
	loginUserId := middleware.GetUserID(ctx)
	data, err := p.ContentMng.GetStarTargetList(ctx, loginUserId)
	if err != nil {
		return nil, err
	}

	list := p.buildRemindList(ctx, loginUserId, data)

	resp := &pbuserapi.UserStarTargetListResp{
		Total: 0,
		List:  list,
	}

	return resp, err
}

func (p *AdminHandler) buildRemindList(ctx context.Context, userId int64, data []*pbapi.UserinfoDbModel) []*pbuserapi.UserStartTargetInfo {
	userList := make([]*pbuserapi.UserStartTargetInfo, 0)
	for _, v := range data {
		var nickName, photo string
		switch {
		case v.GetNickName() != "":
			nickName = v.GetNickName()
		case v.GetOpenNickName() != "":
			nickName = v.GetOpenNickName()
		}

		switch {
		case v.GetPhoto() != "":
			photo = v.GetPhoto()
		case v.GetOpenPhoto() != "":
			photo = v.GetOpenPhoto()
		}

		members := make([]*pbmgdb.SecretMemberInfoMgDbModel, 0)
		memberType, memberExpire := p.ContentMng.GetUserMemberType(ctx, v.GetUserId())
		if memberType != 0 {
			members = append(members, &pbmgdb.SecretMemberInfoMgDbModel{
				Expire: proto.Int64(memberExpire),
				Type:   proto.Int32(memberType),
			})
		}
		remarkName, _ := p.ContentMng.GetUserRemarkNameOne(ctx, userId, v.GetUserId())

		userList = append(userList, &pbuserapi.UserStartTargetInfo{
			UserId:     v.GetUserId(),
			UserType:   v.GetUserType(),
			NickName:   nickName,
			Gender:     v.GetGender(),
			Photo:      photo,
			MemberType: memberType,
			Member:     members,
			RemarkName: remarkName,
		})
	}
	return userList
}

func (p *AdminHandler) AuditNotify(ctx *gin.Context, req *pbuserapi.AuditNotifyReq) (string, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return "", err
	}
	err = p.UserLevMng.AuditNotify(ctx, header, req)
	if err != nil {
		return "", err
	}
	return "", nil
}

func (p *AdminHandler) checkPhone(ctx *gin.Context, req *pbapi.CheckPhoneReq) (*pbapi.CheckPhoneResp, error) {
	//checkCode, err := p.SecurityMng.CheckTelPhone(ctx, req.GetPhone())
	//if err != nil {
	//	return nil, err
	//}

	retData := &pbapi.CheckPhoneResp{}
	retData.Result = 0

	return retData, nil
}

func (p *AdminHandler) SetWorkCommentStatus(ctx *gin.Context, req *pbapi.WorkCommentEnableReq) (string, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return "", nil
	}
	//userId := middleware.GetUserID(ctx)
	//middleware.SetUserID(ctx, userId)
	//
	err = p.ContentMng.SetWorkCommentStatus(ctx, header, req)
	return "", err
}

func (p *AdminHandler) PushWorkComments(ctx *gin.Context, req *pbapi.WorkCommentPushReq) (*pbapi.WorkCommentPushResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, nil
	}
	userId := middleware.GetUserID(ctx)
	//middleware.SetUserID(ctx, userId)

	// 检查位置信息
	if p.ContentMng.AclCheck(ctx, cm_const.AppTypeDict[header.Apptype], userId) {
		// 需要封禁
		return nil, errorcode.ACLFORBID
	}

	if req.CommentType == 0 {
		req.CommentType = const_busi.CommentTypeText
	}
	retData := &pbapi.WorkCommentPushResp{}
	commentId, err := p.ContentMng.PushWorkComment(ctx, header, req, retData)
	if err != nil {
		return nil, err
	}
	retData.Id = &commentId
	userInfoData, err := p.ContentMng.GetUserInfo(ctx, userId)
	if err != nil {
		return retData, err
	}

	//logger.Infof(ctx, "get_userinfo_location-1,user %v, %v, %v", userId, userInfoData.UserInfoDbModel.GetProvince(), userInfoData.UserInfoDbModel.GetCity())
	retData.UserInfo = trans.TransUserInfoLocalToUserSimple(userInfoData)
	//logger.Infof(ctx, "get_userinfo_location-2,user %v, %v, %v", userId, retData.UserInfo.GetProvince(), retData.UserInfo.GetCity())
	return retData, err
}

func (p *AdminHandler) DeleteWorkComments(ctx *gin.Context, req *pbapi.WorkCommentDeleteReq) (string, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return "", nil
	}
	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	return "", p.ContentMng.DeleteWorkComment(ctx, header, req)
}

func (p *AdminHandler) PullWorkCommentsV2(ctx *gin.Context, req *pbapi.WorkCommentPullReq) (*pbapi.WorkCommentPullResp, error) {

	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, nil
	}
	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	return p.ContentMng.PullWorkCommentsV2(ctx, header, req)
}

func (p *AdminHandler) PullWorkComments(ctx *gin.Context, req *pbapi.WorkCommentPullReq) ([]pbapi.WorkCommentBrief, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, nil
	}
	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	ret, err := p.ContentMng.PullWorkCommentsDetail(ctx, header, req)
	if err != nil || len(ret.GetContents()) <= 0 {
		return nil, err
	}

	var busiRet []pbapi.WorkCommentBrief
	for k, _ := range ret.GetContents() {
		if ret.GetContents()[k] == nil {
			continue
		}
		if header.GetVersioncode() < version.CommentEmotionVersion && ret.GetContents()[k].GetCommentType() == const_busi.CommentTypeEmote {
			// 老版本
			ret.GetContents()[k].Comment = proto.String("[ 请在最新版猫爪app中查看 ]")
		}

		busiRet = append(busiRet, pbapi.WorkCommentBrief{
			Id:                ret.GetContents()[k].Id,
			Comment:           ret.GetContents()[k].Comment,
			FromUserId:        ret.GetContents()[k].FromUserId,
			Ip:                ret.GetContents()[k].Ip,
			CreateTime:        ret.GetContents()[k].CreateTime,
			UserInfo:          ret.GetContents()[k].UserInfo,
			RemindNode:        ret.GetContents()[k].RemindNode,
			LikeNums:          ret.GetContents()[k].LikeNums,
			HasLiked:          ret.GetContents()[k].HasLiked,
			CommentType:       ret.GetContents()[k].CommentType,
			CommentObject:     ret.GetContents()[k].GetCommentObject(),
			BeCommentUserInfo: ret.GetContents()[k].BeCommentUserInfo,
			RemindGroup:       ret.GetContents()[k].RemindGroup,
		})
	}
	return busiRet, nil
}

func (p *AdminHandler) PullUnreadCommentWorks(ctx *gin.Context, req *pbapi.WorkCommentUnreadCommentWorkReq) ([]*pbapi.GetReplyMsgSimple, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, nil
	}

	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	//
	pullSize := int32(30) // default set 30.
	lastWorkId := int64(0)
	if req.GetRows() > 0 {
		pullSize = req.GetRows()
	}
	if req.GetLastWorkId() > 0 {
		lastWorkId = req.GetLastWorkId()
	}

	resp, err := p.ContentMng.PullUnreadCommentWorkProc(ctx, header, pullSize, lastWorkId)
	if err != nil {
		return nil, err
	}

	return p.ContentMng.NewPullUnreadCommentWorkProc(ctx, resp)
}
func (p *AdminHandler) AddCommentInfo(ctx *gin.Context, worksInfo []*pbapi.PersonalBottleWorksSimple) []*pbapi.PersonalBottleWorksSimple {
	if len(worksInfo) <= 0 {
		return worksInfo
	}
	worksIds := []int64{}
	for i, _ := range worksInfo {
		if worksInfo[i] == nil || worksInfo[i].GetId() <= 0 {
			continue
		}
		worksIds = append(worksIds, worksInfo[i].GetId())

	}

	statusRet, err := p.ContentMng.GetCommentStatusOnWork(ctx, worksIds)
	if err != nil || statusRet == nil || len(*statusRet) <= 0 {
		return worksInfo
	}
	//
	for i, _ := range worksInfo {
		if worksInfo[i] == nil || worksInfo[i].GetId() <= 0 {
			continue
		}
		v, exist := (*statusRet)[worksInfo[i].GetId()]
		if exist == true {
			tmpV := v
			worksInfo[i].EnableComment = &tmpV
		} else {
			worksInfo[i].EnableComment = proto.Int32(0) //默认0
		}
	}
	return worksInfo
}
func (p *AdminHandler) LikeWorkComments(ctx *gin.Context, req *pbapi.WorkCommentLikeReq) (int32, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return 0, errorcode.IAP_INSUFFICIENT
	}
	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)
	//
	if !(req.GetOp() == const_busi.LikedOp || req.GetOp() == const_busi.UnLikedOp) {
		logger.Infof(ctx, "like op not %v|%v", const_busi.LikedOp, const_busi.UnLikedOp)
		return 0, errorcode.MIDAS_PARAMS_ERROR
	}
	return p.ContentMng.LikeWorkComment(ctx, header, req)
}

func (p *AdminHandler) QuerySportStatus(ctx *gin.Context) (*pbapi.SecretSportStatusResponse, error) {
	//1. 从 collection: user_sport_activity_detail 查询用户最近前三天+当天记录的数据
	//2. if 一条数据都没有， 不存在则返回错误码：Sport_three_day_today_no_item
	//3. if 今天没有记录，前三天有记录，返回错误码0，从查询得到最近一次结果来 填充 day3_history_record记录，
	//并从redis 获取用户的总鱼干数。
	//4. if 查询结果中没有今天记录，从查询结果中填充today_record记录。
	//5. 来取排行榜，根据用户步数进行排序，填充排行榜信息。

	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return &pbapi.SecretSportStatusResponse{}, errorcode.IAP_INSUFFICIENT
	}
	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)
	ret, err := p.ContentMng.QuerySportStatus(ctx, header)
	if err != nil || ret == nil {
		logger.Errorf(ctx, "pull sport status fail, err: %v", err)
		return &pbapi.SecretSportStatusResponse{},
			errorcode.GenBusiErr(errorcode.Sport_status_query_fail, err.Error())
	}
	return ret, err
}
func (p *AdminHandler) EvalFishOnStepNums(ctx *gin.Context, req *pbapi.SecretSportEvalFishOnStepNums) (*pbapi.SecretSportEvalFishOnStepResponse, error) {
	//1. 根据提交的步数，使用算法：当前步数/（当前步数+已提交用户的用户步数)*(总鱼干数+100）
	//2. 查表获取本期所有已提交用户的步数
	//3. 总鱼干总数是：1000+ 查表获取本期已提交的人数*100
	//if *req.StepNums <= 0 {
	//	return nil, errorcode.Sport_input_step_nums_invalid
	//}

	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, nil
	}
	//userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	fishNums, err := p.ContentMng.PredictFishNums(ctx, header, *req.StepNums)
	if err != nil {
		return nil, err
	}

	resp := &pbapi.SecretSportEvalFishOnStepResponse{FishNums: &fishNums}

	return resp, nil
}

func (p *AdminHandler) PushSportSteps(ctx *gin.Context, req *pbapi.SecretSportAwardPushStepReq) (*pbapi.SecretSportAwardPushStepResp, error) {
	//1.今天没有记录，则插入表：
	//2. 有记录则更新步数，重新计算本期总的鱼干数。
	//3. 返回总的鱼干数 和 提交的步数。
	//if *req.StepNums <= 0 {
	//	return nil, nil
	//}

	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, nil
	}
	//userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	result, err := p.ContentMng.UpsertSportStep(ctx.Copy(), header, *req.StepNums)
	if err != nil {
		return nil, err
	}
	//
	p.ContentMng.SportMedalLogic(ctx, header)
	return result, nil
}

func (p *AdminHandler) PullSportRanker(ctx *gin.Context) (*pbapi.SecretSportAwardRankerDetail, error) {
	// 1. 查询用户已提交的步数
	// 2. 查表获取已提交步数, 排序。
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, nil
	}

	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)
	ret, err := p.ContentMng.CurrentActivityRanker(ctx, header)
	if err != nil || ret == nil {
		logger.Errorf(ctx, "get current ranker fail, err: %v", err)
		return &pbapi.SecretSportAwardRankerDetail{}, err
	}
	return ret, err
}

func (p *AdminHandler) CheckResStatus(ctx *gin.Context, req *pbapi.CheckResStatusReqMsg) (*pbapi.CheckResStatusRespMsg, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, nil
	}
	loginUserInfo, err := p.ContentMng.GetUserInfoByHeader(ctx, header)
	if err != nil {
		return nil, err
	}

	ret, err := p.ContentMng.CheckResStatusImpl(ctx, header, req, loginUserInfo.UserInfoDbModel.GetUserId())
	if err != nil || ret == nil {
		return ret, err
	}

	var (
		bgImage                     string
		remarkName                  string
		talkMode                    int32
		commentRemarkName           string
		beCommentUserInfoRemarkName string
	)

	if err = mapreduce.Finish(func() error {
		bgImage, err = p.ContentMng.GetBackgroundWithWork(ctx)
		if err != nil {
			logger.Errorf(ctx, "GetBackgroundWithWork: ", err)
		}
		return nil
	}, func() error {
		if ret.WorkInfo == nil {
			return nil
		}
		talkMode = p.ContentMng.GetUserInfoTalkMode(ctx, ret.WorkInfo.UserInfo.GetUserId())
		return nil
	}, func() error {
		if ret.WorkInfo == nil {
			return nil
		}
		remarkName, err = p.ContentMng.GetUserRemarkNameOne(ctx, loginUserInfo.UserInfoDbModel.GetUserId(), ret.WorkInfo.UserInfo.GetUserId())
		return nil
	}, func() error {
		if ret.CommentInfo == nil {
			return nil
		}
		commentRemarkName, err = p.ContentMng.GetUserRemarkNameOne(ctx, loginUserInfo.UserInfoDbModel.GetUserId(), ret.CommentInfo.UserInfo.GetUserId())
		return nil
	}, func() error {
		if ret.CommentInfo == nil {
			return nil
		}
		beCommentUserInfoRemarkName, err = p.ContentMng.GetUserRemarkNameOne(ctx, loginUserInfo.UserInfoDbModel.GetUserId(), ret.CommentInfo.BeCommentUserInfo.GetUserId())
		return nil
	}); err != nil {
		return ret, err
	}

	if ret != nil && ret.WorkInfo != nil {
		ret.WorkInfo.BgImage = &bgImage
		ret.WorkInfo.UserInfo.TalkMode = talkMode
		ret.WorkInfo.UserInfo.RemarkName = remarkName
	}

	if ret != nil && ret.CommentInfo != nil {
		ret.CommentInfo.UserInfo.RemarkName = commentRemarkName
		ret.CommentInfo.BeCommentUserInfo.RemarkName = beCommentUserInfoRemarkName
	}

	return ret, err
}
func (p *AdminHandler) HomePagePrivateMessageCheckProc(ctx *gin.Context, req *pbapi.HomePagePrivateMessageCheck) (*pbapi.HomePagePrivateMessageCheckResponse, error) {
	var ret *pbapi.HomePagePrivateMessageCheckResponse
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return ret, nil
	}

	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	err = p.ContentMng.CheckHomePagePrivateMessagePermission(ctx, header, req)
	return ret, err
}

func (p *AdminHandler) HomePagePrivateMessagePushProc(ctx *gin.Context, req *pbapi.HomePagePrivateMessagePushReq) (*pbapi.HomePagePrivateMessagePushResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, nil
	}

	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)
	userId := middleware.GetUserID(ctx)

	// 检查位置信息
	if p.ContentMng.AclCheck(ctx, cm_const.AppTypeDict[header.Apptype], userId) {
		// 需要封禁
		return nil, errorcode.ACLFORBID
	}

	if req.GetMessageType() == 0 {
		logger.Infof(ctx, "req.message_type is illegal. =%v", req.GetMessageType())
		req.MessageType = int32(pbconst.MessageTypeEnum_msg_type_txt)
	}
	// 小程序目前会传0过来，为了兼容他，做如下逻辑。
	if req.GetLatitude() == 0 {
		req.Latitude = nil
	}
	if req.GetLongitude() == 0 {
		req.Longitude = nil
	}
	req.SessionType = proto.Int32(0) // 默认为0

	ret, err := p.ContentMng.PushPrivateMessage(ctx, header, req)
	return ret, err
}

func (p *AdminHandler) GetUnReadMsgCounts(ctx *gin.Context) (int64, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return 0, nil
	}

	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	if config.ServerConfig.Env != "prod" {
		// 方便调试用
		logger.Infof(ctx, "get_user_level,ctx_header=%v", utils.StructToJsonString(ctx.Request.Header))
	}

	return p.ContentMng.GetUnReadMsgNums(ctx, header)
}
func (p *AdminHandler) CheckUpdateUserInfo(ctx *gin.Context, req *pbsecurity.CheckUpdateUserInfoReq) (*pbsecurity.CheckUpdateUserInfoResp, error) {
	resp := &pbsecurity.CheckUpdateUserInfoResp{}
	// 填充基础信息
	resp.MessageId = utils.GetLocalIp() + "_" + requestid.GetRequestID(ctx)
	resp.Timestamp = time.Now().UnixNano() / 1e6
	auditResult, err := p.SecurityMng.CheckUpdateUserInfo(ctx, req)
	if err != nil {
		resp.Message = err.Error()
		resp.Status = 201
	} else {
		resp.Status = 200
	}
	resp.Data = auditResult
	return resp, nil
}

func (p *AdminHandler) RealNameAuthentication(ctx *gin.Context, req *pbapi.RealNameAuthenticationReq) (*pbapi.RealNameAuthenticationResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	identity, err := p.ContentMng.RealNameAuthentication(ctx, header, req.GetCardId(), req.GetCardName())
	if err != nil {
		return nil, err
	}

	resp := &pbapi.RealNameAuthenticationResp{
		Status:   true,
		Identity: identity,
	}
	return resp, nil
}

func (p *AdminHandler) CheckRealName(ctx *gin.Context) (*pbapi.CheckRealNameResp, error) {
	loginUserId := middleware.GetUserID(ctx)

	identity, status, err := p.ContentMng.CheckIdentificationCard(ctx, loginUserId)
	if err != nil {
		return nil, err
	}

	resp := &pbapi.CheckRealNameResp{
		Status:   status,
		Identity: identity,
	}
	return resp, nil
}

// AdBehaviorUpload 广告-平台归因上报
func (p *AdminHandler) AdBehaviorUpload(ctx *gin.Context, req *pbapi.AdBehaviorUploadReq) (*pbapi.AdBehaviorUploadResp, error) {
	resp, err := p.ContentMng.AdBehaviorUpload(ctx, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) AdBehaviorUploadV2(ctx *gin.Context, req *pbapi.AdBehaviorUploadReqV2) (*pbapi.AdBehaviorUploadResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	resp, err := p.ContentMng.AdBehaviorUploadV2(ctx, header, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func (p *AdminHandler) AdVivoFeedback(ctx *gin.Context) {
	var params []*pbapi.AdVivoFeedbackDbModel
	if err := ctx.Bind(&params); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, pbapi.AdVivoFeedbackResp{
			Code: -1,
			Msg:  "操作失败",
		})

		return
	}

	logger.Infof(ctx, "receive req: %+v", params)

	resp, err := p.ContentMng.AdVivoFeedback(ctx, params)
	if err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, resp)
		return
	}

	ctx.JSON(http.StatusOK, resp)
	//ctx.JSON(http.StatusOK, gin.H{
	//	"code": 0,
	//	"msg":  "操作成功",
	//})

	return
}

func (p *AdminHandler) AdOppoFeedback(ctx *gin.Context) {
	var req pbapi.AdOppoFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, pbapi.AdOppoFeedbackResp{
			Code: -1,
			Msg:  "操作失败",
		})

		return
	}
	resp, err := p.ContentMng.AdOppoFeedback(ctx, &req)
	if err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, resp)
		return
	}

	ctx.JSON(http.StatusOK, resp)
}

func (p *AdminHandler) AdXiaomiFeedback(ctx *gin.Context) {
	var req pbapi.AdXiaomiFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, pbapi.AdXiaomiFeedbackResp{
			Code: -1,
		})
		return
	}
	resp, err := p.ContentMng.AdXiaomiFeedback(ctx, &req)
	if err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusOK, resp)
		return
	}

	ctx.JSON(http.StatusOK, resp)
}

func (p *AdminHandler) AdBaiduFeedback(ctx *gin.Context) {
	var req pbapi.AdBaiduFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	if err := p.ContentMng.AdBaiduFeedback(ctx, &req); err != nil {
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	ctx.JSON(http.StatusOK, "")
	return

}

func (p *AdminHandler) AdGdtFeedback(ctx *gin.Context) {
	var req pbapi.AdGdtFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	if err := p.ContentMng.AdGdtFeedbackReq(ctx, &req); err != nil {
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	ctx.JSON(http.StatusOK, "")
	return

}

func (p *AdminHandler) AdToutiaoFeedback(ctx *gin.Context) {
	var req pbapi.AdToutiaoFeedbackReq
	if err := ctx.Bind(&req); err != nil {
		logger.Errorf(ctx, "bind req fail, err: %v", err)
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	if err := p.ContentMng.AdToutiaoFeedbackReq(ctx, &req); err != nil {
		ctx.JSON(http.StatusBadRequest, "")
		return
	}

	ctx.JSON(http.StatusOK, "")
	return

}

func (p *AdminHandler) GetWorkTalkList(ctx *gin.Context, req *pbapi.TalkMessageListReq) (*pbapi.SimplePageInfo, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return &pbapi.SimplePageInfo{}, nil
	}
	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)
	return p.ContentMng.ListWorkTalks(ctx, header, req)
}

func (p *AdminHandler) GetOfficialNewMsg(ctx *gin.Context) (*pbapi.PersonalNotificationUnreadTotalResponse, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, nil
	}
	//userId, err := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)
	return p.ContentMng.OfficialNewMsgList(ctx, header)
}

func (p *AdminHandler) GetTalkMessageDetail(ctx *gin.Context, req *pbapi.TalkMessageSecurityReq) (*pbapi.TalkMessageSecurityResponse, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	//userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	logger.Infof(ctx, "GetTalkMessageDetail ,ctx_header=%v", utils.StructToJsonString(ctx.Request.Header))

	ret, err := p.ContentMng.GetTalkMessageDetailByUser(ctx, header, req)
	if err != nil {
		logger.Errorf(ctx, "get talk message detail fail, err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) GetTalkConfig(ctx *gin.Context, req *pbapi.TalkMessageSecurityConfigRes) (*pbapi.TalkMessageSecurityConfigResp, error) {
	//header, err := utils.GetCtxHeadersSession(ctx)
	//if err != nil {
	//	return nil, err
	//}
	var bgImage string
	var err error

	switch req.BgType {
	case 1:
		bgImage, err = p.ContentMng.GetBackgroundWithWork(ctx)
	case 2:
		bgImage, err = p.ContentMng.GetBackgroundWithTalk(ctx)
	case 3:
		bgImage, err = p.ContentMng.GetBackgroundWithTalkGroup(ctx)
	default:
		bgImage, err = p.ContentMng.GetBackgroundWithTalk(ctx)
	}

	if err != nil {
		logger.Error(ctx, "GetBackgroundWithWork", err)
	}

	//loginUser, err := p.ContentMng.GetUserInfoByHeader(ctx, header)
	//if err != nil {
	//	return nil, err
	//}

	resp := &pbapi.TalkMessageSecurityConfigResp{
		BgImage: &bgImage,
		//TalkMode: loginUser.PsecretUserExtInfo.GetTalkMode(),
	}
	return resp, nil
}

func (p *AdminHandler) SetTalkConfig(ctx *gin.Context, req *pbapi.TalkMessageSecurityConfigReq) (interface{}, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}
	if req.GetTalkMode() == 0 {
		return nil, errorcode.PARAM_ERROR
	}

	err = p.ContentMng.SetTalkConfig(ctx, header, req)
	if err != nil {
		return nil, err
	}

	return nil, nil
}

func (p *AdminHandler) Follow(ctx *gin.Context, req *pbuserapi.FollowReq) (*pbuserapi.FollowResp, error) {
	//header, _ := utils.GetCtxHeadersSession(ctx)
	//userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	//if userId == 0 {
	//	userId = header.Debuguserid
	//}
	//middleware.SetUserID(ctx, userId)

	if req.TargetUserId == 0 {
		return nil, errorcode.PARAM_ERROR
	}

	ret, err := p.UserCenterMng.Follow(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "follow fail, err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) FollowList(ctx *gin.Context, req *pbuserapi.FollowListReq) (*pbuserapi.FollowListResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	if req.ListType == 0 {
		req.ListType = const_busi.Mutual //猫友
	}

	if req.Size == 0 {
		req.Size = 20
	}

	ret, err := p.UserCenterMng.FollowList(ctx, header, req)
	if err != nil {
		logger.Errorf(ctx, "get follow list fail, err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) FollowStat(ctx *gin.Context, req *pbuserapi.FollowStatusReq) (*pbuserapi.FollowStatusResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	if req.TargetUserId == 0 {
		return nil, errorcode.PARAM_ERROR
	}

	ret, err := p.UserCenterMng.FollowStat(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "get follow status fail, err: %v", err)
	}
	return ret, err
}

// 优质内容体现处理逻辑
func (p *AdminHandler) KoLaPlanEntry(ctx *gin.Context) (*pbapi.KoLaPlanEntryResponse, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)
	return p.ContentMng.GetTotalAWardByUser(ctx, header) //
}

func (p *AdminHandler) KoLaPlanHallOfFame(ctx *gin.Context) (*pbapi.KoLaHallOfFameResponse, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	//userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)
	userId := middleware.GetUserID(ctx)

	ret := &pbapi.KoLaHallOfFameResponse{
		AwardForHallOfFame: config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.Award,
		Title:              fmt.Sprintf("%02d%02d", int(time.Now().Month()), time.Now().Day()),
		SettleEndTime:      config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem.SettlementEndTime,
		Settled:            const_busi.KoLaHallOfFameNoSettlement,
	}

	if content_mng.CheckHallOfFameRankIsEnd() {
		ret.Settled = const_busi.KoLaHallOfFameHasSettlement
	}

	itemList, err := p.ContentMng.GetKoLaHallOfFameList(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "KoLaPlanHallOfFame get fail, err: %v, user: %v", err, userId)
		return ret, errorcode.KoLaHallOfFameFail
	}
	if len(itemList) <= 0 {
		logger.Infof(ctx, "get rank list is empty")
		return ret, nil
	}

	ret.UserItem = itemList
	return ret, nil
}

// 已结算动态的奖励详情
func (p *AdminHandler) KoLaPlanAwardDetail(ctx *gin.Context) (*pbapi.KoLaPlanDetailResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	//userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	logger.Infof(ctx, "KoLaPlanAwardDetail, ctx_header=%v", utils.StructToJsonString(ctx.Request.Header))
	ret, err := p.ContentMng.GetKoLaAwardDetailByUser(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "KoLaPlanAwardDetail fail, err: %v", err)
	}
	return ret, err
}

// 等待结算的优质动态详情
func (p *AdminHandler) KoLaPlanDetail(ctx *gin.Context) (*pbapi.KoLaPlanDetailResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	//userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	//middleware.SetUserID(ctx, userId)

	logger.Infof(ctx, "KoLaPlanDetail, ctx_header=%v", utils.StructToJsonString(ctx.Request.Header))

	ret, err := p.ContentMng.GetKoLaToSettlementDetailByUser(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "KoLaPlanDetail fail, err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) AddBlackList(ctx *gin.Context, req *pbuserapi.AddBlackListReq) (*pbuserapi.AddBlackListResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	if userId == req.GetTargetUserId() {
		return nil, errorcode.HomePagePrivateMsgSelf
	}

	if req.TargetUserId == 0 {
		return nil, errorcode.PARAM_ERROR
	}

	ret, err := p.UserCenterMng.AddBlackList(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "add black list fail, err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) FollowBadge(ctx *gin.Context, req *pbuserapi.FollowBadgeStatReq) (*pbuserapi.FollowBadgeStatResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	ret, err := p.UserCenterMng.FollowBadge(ctx)
	if err != nil {
		logger.Errorf(ctx, "get follow badge fail, err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) WithdrawBind(ctx *gin.Context, req *pbuserapi.BindWechatUserReq) (*pbuserapi.BindWechatUserResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	ret, err := p.UserCenterMng.WithdrawBind(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "bind wechat_proxy user fail, err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) WithdrawBefore(ctx *gin.Context, req *pbuserapi.WithdrawBeforeReq) (*pbuserapi.WithdrawBeforeResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	ret, err := p.UserCenterMng.WithdrawBefore(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "get withdraw before info fail, err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) Withdraw(ctx *gin.Context, req *pbuserapi.WithdrawReq) (*pbuserapi.WithdrawResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	ret, err := p.UserCenterMng.Withdraw(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "withdraw fail, err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) GameAuth(ctx *gin.Context, req *pbapi.GameAuthReq) (*pbapi.GameAuthResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	ret, err := p.GameMng.GameAuth(ctx, userId, req.AppKey)
	if err != nil {
		logger.Errorf(ctx, "handler:GameAuth err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) GamePreOrder(ctx *gin.Context, req *pbapi.GamePreOrderReq) (*pbapi.GamePreOrderResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	ret, err := p.GameMng.GamePreOrder(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "handler:GamePreOrder, err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) GameGetOrderInfo(ctx *gin.Context, req *pbapi.GameGetOrderInfoReq) (*pbapi.GameGetOrderInfoResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	ret, err := p.GameMng.GameGetOrderInfo(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "handler:GameGetOrderInfo, err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) QueryOrderByOutTradeNo(ctx *gin.Context, req *pbapi.QueryOrderByOutTradeNoReq) (*pbapi.QueryOrderByOutTradeNoResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	ret, err := p.PayMng.QueryOrderByOutTradeNo(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "handler:QueryOrderByOutTradeNo err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) WechatPayNotify(ctx *gin.Context) map[string]string {
	return p.PayMng.WechatPayNotify(ctx, ctx.Request)
}

func (p *AdminHandler) GameNotifyTest(ctx *gin.Context) map[string]string {
	fmt.Println("游戏收到通知")
	fmt.Println("game notify request:", ctx.Request)
	return map[string]string{
		"code": "success",
		"msg":  "",
	}
}

func (p *AdminHandler) GameBind(ctx *gin.Context, req *pbapi.BindGameReq) (*pbapi.BindGameResp, error) {
	ret, err := p.GameMng.GameBind(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "handler:GameBind err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) GameList(ctx *gin.Context, req *pbapi.GameListReq) (*pbapi.GameListResp, error) {
	ret, err := p.GameMng.GameList(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "handler:GameList err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) UserSearch(ctx *gin.Context, req *pbuserapi.UserSearchReq) (*pbuserapi.UserSearchResp, error) {
	header, _ := utils.GetCtxHeadersSession(ctx)
	userId, _ := p.ContentMng.GetUserId(ctx, header.Token)
	if userId == 0 {
		userId = header.Debuguserid
	}
	//middleware.SetUserID(ctx, userId)

	if req.Nickname == "" {
		return nil, errorcode.PARAM_ERROR
	}

	ret, err := p.UserCenterMng.SearchByNickname(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "handler:UserSearch err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) RemarkName(ctx *gin.Context, req *pbuserapi.UserRemarkNameReq) (*pbuserapi.UserRemarkNameResp, error) {
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	if err := p.ContentMng.SetUserRemarkName(ctx, header, req); err != nil {
		return nil, err
	}

	return &pbuserapi.UserRemarkNameResp{}, nil
}

func (p *AdminHandler) DailySign(ctx *gin.Context, req *pbuserapi.DailySignReq) (*pbuserapi.LevelUpResp, error) {
	ret, err := p.UserCenterMng.DailySign(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "handler:DailySign err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) LevelInfo(ctx *gin.Context, req *pbuserapi.LevelCardReq) (*pbuserapi.CurrentLevelInfo, error) {
	ret, err := p.UserCenterMng.LevelInfo(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "handler:DailySignCard err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) GetSpeedCode(ctx *gin.Context, req *pbuserapi.GetSpeedCodeReq) (*pbuserapi.GetSpeedCodeResp, error) {
	ret, err := p.UserCenterMng.GetSpeedCode(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "handler:DailySignCodeGen err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) UsageSpeedCode(ctx *gin.Context, req *pbuserapi.UsageSpeedCodeReq) (*pbuserapi.LevelUpResp, error) {
	req.SpeedCode = strings.ToUpper(req.SpeedCode)

	ret, err := p.UserCenterMng.UsageSpeedCode(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "handler:DailySignCodeUse err: %v", err)
	}
	return ret, err
}

func (p *AdminHandler) LevelRights(ctx *gin.Context) (*pbuserapi.LevelAllInfoResp, error) {
	ret, err := p.UserCenterMng.LevelRights(ctx)
	if err != nil {
		logger.Errorf(ctx, "handler:DailySignCodeUse err: %v", err)
	}
	return ret, err
}
