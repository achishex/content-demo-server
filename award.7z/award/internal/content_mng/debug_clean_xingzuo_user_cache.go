package content_mng

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/pub/logger"
	"context"
)

func (p *ContentMng) CleanXingzuoUserCache(ctx context.Context, userId int64) error {

	logger.Infof(ctx, "CleanXingzuoUserCache, curUserId=%v", userId)
	if userId == 0 {
		return nil
	}
	return p.DataCache.GetImpl().DebugCleanXingZuoRedisCache(ctx, userId, cm_const.SystemWorkIdXingzuo)
}

func (p *ContentMng) CleanSignCache(ctx context.Context, userId int64) error {
	logger.Infof(ctx, "CleanSignCache, curUserId=%v", userId)
	if userId == 0 {
		return nil
	}
	return p.DataCache.GetImpl().DelUserDailySignFlag(ctx, userId)
}

func (p *ContentMng) ResetSignCache(ctx context.Context, userId int64) error {
	logger.Infof(ctx, "ResetSignCache, curUserId=%v", userId)
	if userId == 0 {
		return nil
	}
	return p.DataCache.GetImpl().DelUserDailySign(ctx, userId)
}

func (p *ContentMng) SetUserExt(ctx context.Context, userId int64, changes map[string]interface{}) error {
	extInfo, err := p.DataCache.GetImpl().UserInfoExtMgModel.GetByUserId(ctx, userId)
	if err != nil || extInfo == nil {
		return err
	}

	extData := map[string]interface{}{}
	for key, value := range changes {
		switch key {
		case "ulevel":
			extData[key] = value
		default:
			continue
		}
	}

	if err := p.DataCache.GetImpl().UserInfoExtMgModel.UpdateDictById(ctx, userId, changes, nil); err != nil {
		logger.Error(ctx, "audit notify, change user level failed", err)
		return err
	}
	logger.Infof(ctx, "SetUserLevel suc, curUserId=%v, level=%v", userId, changes)
	return nil
}

func (p *ContentMng) UntieCard(ctx context.Context, userId int64) error {
	filter := map[string]interface{}{
		"user_id": userId,
	}
	data := map[string]interface{}{
		"status": 2,
	}
	_, err := p.DataCache.GetImpl().SecretUserIdentificationCardMgModel.UpdateMap(ctx, filter, data)
	if err != nil {
		return err
	}
	return nil
}
