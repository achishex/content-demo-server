package sum_manage

import (
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

type UserActivityDaily struct {
	ManagerDB, ManagerOnlyReadDB *dao.ManagerDB
}

func (s *UserActivityDaily) GetUserActivityFilter(req types.UserActivityFilter) (map[string]interface{}, string) {
	var daily model.SecretUserActivityDaily
	filter := map[string]interface{}{}
	if req.Channel != "" {
		filter = s.buildFilter(filter, "channel", req.Channel)
		daily.Channel = req.Channel
	}
	if req.AppType != "" {
		filter = s.buildFilter(filter, "app_type", req.AppType)
		daily.AppType = req.AppType
	}
	if req.Gender != 0 {
		filter = s.buildFilter(filter, "gender", req.Gender)
		daily.Gender = req.Gender
	}
	switch req.Market {
	case 1:
		if req.Market == 1 {
			filter = s.buildFilter(filter, "market", req.Market)
			daily.Market = req.Market
		}
	case 2:
		if req.Market == 2 {
			filter = s.buildFilter(filter, "market", bson.D{
				{"$ne", 1},
			})
			daily.Market = req.Market
		}
	}

	if req.TimeStart != 0 && req.TimeEnd != 0 {
		filter = s.buildFilter(filter, "day", bson.D{
			{"$gte", req.TimeStart},
			{"$lte", req.TimeEnd},
		})
	}

	key := "%d" // day
	return filter, key + fmt.Sprintf("%s", s.UniqueKey(daily))
}

func (s *UserActivityDaily) buildFilter(filter map[string]interface{}, key string, value interface{}) map[string]interface{} {
	switch v := value.(type) {
	case int:
		if v == 0 {
			return filter
		}
		filter[key] = value
	case string:
		if v == "" {
			return filter
		}
		filter[key] = value
	default:
		filter[key] = value
	}

	return filter
}

// TodayUserActivity 获取今天 SecretUserActivityDaily 聚合数据
func (s *UserActivityDaily) TodayUserActivity(ctx context.Context, filter map[string]interface{}, timeEnd int64) (*model.SecretUserChannelDaily, error) {
	endTime, err := utils.ParseDay(timeEnd)
	if err != nil {
		return nil, xerr.ParamError
	}
	if utils.GtTodayZero(endTime) {
		nowDay, err := utils.TimeByDay(time.Now())
		if err != nil {
			return nil, err
		}
		channelDaily, err := s.UserActivity(ctx, filter, nowDay)
		if err != nil {
			return nil, err
		}
		return channelDaily, err
	}

	return nil, nil
}

// UserActivity 聚合 SecretUserActivityDaily 某天数据
func (s *UserActivityDaily) UserActivity(ctx context.Context, filter map[string]interface{}, day uint) (*model.SecretUserChannelDaily, error) {
	filter["day"] = day

	activityList, err := s.ManagerOnlyReadDB.SecretUserActivityDaily.FindAll(ctx, filter)
	if err != nil {
		return nil, err
	}

	obj := &model.SecretUserChannelDaily{}
	for _, daily := range activityList {
		obj.AppType = daily.AppType
		obj.Channel = daily.Channel
		obj.Day = day
		obj.Gender = daily.Gender
		obj.Market = daily.Market
		obj.ActiveUserCount++
		if daily.IsNew == 1 {
			obj.NewUserCount++
		}
		switch {
		case daily.WorkActive != 0, daily.CommentActive != 0, daily.TalkActive != 0, daily.LikeActive != 0:
			obj.ActiveTargetUserCount++
			if daily.IsNew == 1 {
				obj.NewTargetUserCount++
			}
		}

	}

	return obj, err
}

// UniqueKey 生成 secretUserChannelDaily 表唯一键
func (s *UserActivityDaily) UniqueKey(daily model.SecretUserActivityDaily) string {
	if daily.Day == 0 {
		return fmt.Sprintf("%s-%s-%d-%d", daily.AppType, daily.Channel, daily.Gender, daily.Market)
	} else {
		return fmt.Sprintf("%d-%s-%s-%d-%d", daily.Day, daily.AppType, daily.Channel, daily.Gender, daily.Market)

	}
}
