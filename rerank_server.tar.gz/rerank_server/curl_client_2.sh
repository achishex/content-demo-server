#! /usr/bin/env bash 
echo "query: Is the Aurzen ZIP compatible with gaming consoles or USB drives?"

curl -X POST http://127.0.0.1:7010/smart-customer-service/v1/rerank_after_retrieve \
  -H "Content-Type: application/json" \
  -d @- <<EOF | jq
{
  "reqId":"1000",
  "queryType": 1,
  "query": "Is the Aurzen ZIP compatible with gaming consoles or USB drives?",
  "qaDocs": [
    {
      "question": "What exist the best use scenarios for Aurzen ZIP?",
      "answer": "● Home entertainment: Enjoy movie nights, games, or streaming with family and friends.\n● Work presentations: Share slides, videos, or reports easily during meetings.\n● Outdoor adventures: Bring big-screen fun to camping trips, picnics, or backyard parties.\n● Travel: Compact design makes it ideal for hotel stays or road trips.\n● Creative projects: Use it to trace or project designs for painting, crafts, or DIY.\n● Workshops & classes: Perfect for teaching baking, cooking, or art with visual aids."
    },
    {
      "question": "What be Aurzen ZIP?",
      "answer": "Aurzen ZIP is a truly portable tri-fold projector designed for convenience and versatility. It features Wi-Fi-free screen mirroring, ToF zero-lag autofocus, vertical full-screen mode, and a compact, lightweight design — perfect for entertainment or work on the go."
    },
    {
      "question": "What case of content can I project with Aurzen ZIP?",
      "answer": "Aurzen ZIP supports a wide range of content types, including movies, presentations, games, and photos. It’s compatible with Android, iOS, macOS, and Windows devices — ideal for various use cases."
    },
    {
      "question": "Does Aurzen ZIP have I/O ports?",
      "answer": "Aurzen ZIP features a single Type-C port that supports PD fast charging. It doesn't include a built-in HDMI port but pairs seamlessly with our official wireless HDMI dongle for streaming content from Netflix, Disney+, and gaming consoles like Nintendo Switch. While it lacks a headphone jack, Bluetooth speaker support enhances your audio experience."
    }
  ]
}
EOF

rightAnswer="Aurzen ZIP supports a wide range of content types, including movies, presentations, games, and photos. It’s compatible with Android, iOS, macOS, and Windows devices — ideal for various use cases."
echo -e "------------- right answer: \n${rightAnswer}"
