package vip_mng

import (
	"content_svr/internal/model"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/setting"
	"context"
	"encoding/json"
	"github.com/samber/lo"
	"gorm.io/gorm"
	"time"
)

const (
	REFUND_VIP_ORDER_NO_PREFIX = "rf_"
)

func NewVipMng(
	db model.ParseTimeDB,
) *VipMng {
	return &VipMng{
		db: db,
	}
}

type VipMng struct {
	db *gorm.DB
}

// vipType: 1 svip, 3 vip, 与memberType一致
func (m *VipMng) GetVipRightsConf(ctx context.Context) (*VipRightsConf, error) {
	var vipRights, svipRights, svipRightsHead []VipRight
	_ = json.Unmarshal([]byte(setting.Maozhua.VipRights.Get()), &vipRights)
	_ = json.Unmarshal([]byte(setting.Maozhua.SVipRights.Get()), &svipRights)
	_ = json.Unmarshal([]byte(setting.Maozhua.SVipRightsHead.Get()), &svipRightsHead)

	resp := &VipRightsConf{
		Vip: VipDesc{
			Name:   "VIP",
			Type:   3,
			Rights: vipRights,
		},
		SVip: VipDesc{
			Name:   "SVIP",
			Type:   1,
			Rights: svipRights,
		},
		SVipRightsHead: svipRightsHead,
	}

	return resp, nil
}

// GetRefundRight 用户退款权益
func (m *VipMng) GetRefundRight(ctx context.Context, userID int64) (int64, error) {
	// 总退款权益
	totalRight := int64(1)
	var n int64
	err := m.db.Table("vip_order_info").Where("user_id = ? && vip_order_type = 2", userID).Count(&n).Error
	if err != nil {
		logger.Errorf(ctx, "count vip_order_info fail, err: %v", err)
		return 0, err
	}

	result := totalRight - n
	if result < 0 {
		result = 0
	}
	return result, nil
}

// FindRefundOrder 查看可退款订单
func (m *VipMng) FindRefundOrder(ctx context.Context, userID int64) ([]*pbapi.VipRefundOrder, error) {
	right, err := m.GetRefundRight(ctx, userID)
	if err != nil {
		return nil, err
	}
	if right <= 0 {
		return nil, nil
	}

	var orders []*VipOrderInfo
	refundDate := time.Now().AddDate(0, 0, -3)
	err = m.db.WithContext(ctx).Model(&VipOrderInfo{}).Where("user_id = ? and pay_channel = 4 and refund = 0 and vip_order_type = 1 and create_time > ?", userID, refundDate).Order("create_time desc").Find(&orders).Error
	if err != nil {
		logger.Errorf(ctx, "db find fail, err: %v", err)
		return nil, err
	}

	if len(orders) == 0 {
		return nil, nil
	}

	res := lo.Map(orders, func(item *VipOrderInfo, _ int) *pbapi.VipRefundOrder {
		return &pbapi.VipRefundOrder{
			VipOrderNo: item.VipOrderNo,
			MemberType: int32(item.MemberType),
			BizName:    item.BizName,
			CreateTime: item.CreateTime.UnixMilli(),
			ExpireTime: item.ExpireTime.UnixMilli(),
		}
	})

	return res, nil

}
