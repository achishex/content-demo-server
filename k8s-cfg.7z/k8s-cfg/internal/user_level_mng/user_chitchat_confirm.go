package user_level_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/busi_comm/version"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbdb"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"context"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"time"
)

func (p *UserLevelMng) UserChitChatConfirm(ctx context.Context,
	header *pbapi.HttpHeaderInfo, req *pbuserapi.ConfirmChitchatCodeReq) (*pbuserapi.CommLevelUpResp, error) {

	userId, err := p.getUserId(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "get user id by token failed,err=%v", err.Error())
		return nil, errorcode.LOGIN_INVALID
	}

	ss, err := p.getUserLevSession(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user level session failed,err=%v", err.Error())
		return nil, errorcode.INTERNAL_ERROR
	}

	//当前等级信息
	curLevInfo := ss.getUserLev()
	resp := &pbuserapi.CommLevelUpResp{
		BLevelUp: false,
	}
	// 已经是最高级，直接返回
	if ss.CurLevel == const_level.UserMaxLevel {
		return resp, nil
	}

	err = p.confirmCode(ctx, userId, req.GetChitchatCode())
	if err != nil {
		return resp, err
	}
	return p.checkLevUpAndUpdate(ctx, header, userId, ss, curLevInfo, 0, 1)
}

func (p *UserLevelMng) confirmCode(ctx context.Context, userId int64, chitchatCode string) error {
	if config.ServerConfig.Env == "test" && chitchatCode == "MAOZUA" {
		return nil
	}
	// 核销激活码。
	// 确认激活码有效。
	cdkeyItem, err := p.DataCache.GetImpl().SecretChitChatCDKeyMgDbModel.GetByCdKey(ctx, chitchatCode)
	if err != nil {
		logger.Error(ctx, "confirm chitchat code failed. query SecretChitChatCDKeyMgDbModel failed", err)
		return errorcode.INTERNAL_ERROR
	}
	if cdkeyItem == nil || cdkeyItem.GetStatus() != 0 {
		return errorcode.GenBusiErr(errorcode.DATA_INVALID, "无效激活码")
	}

	// 更新激活码状态。
	update := bson.D{{"$set", bson.D{
		{"toUserId", userId},
		{"usageTime", time.Now().UnixNano() / 1e6},
		{"status", 1}},
	}}
	err = p.DataCache.GetImpl().SecretChitChatCDKeyMgDbModel.UpdateDictByCdKey(ctx, chitchatCode, update)
	if err != nil {
		logger.Error(ctx, "confirm chitchat code failed. UpdateDictByCdKey failed", err)
		return errorcode.INTERNAL_ERROR
	}
	// 清空 userext中激活码
	// 更新等级到userExt表
	changes := map[string]interface{}{"chitChatCdKey": "", "lastCDKeyUsageTime": time.Now().UnixNano() / 1e6}
	err = p.DataCache.GetImpl().UserInfoExtMgModel.UpdateDictById(ctx, cdkeyItem.GetFromUserId(), changes, nil)
	if err != nil {
		logger.Error(ctx, "UpdateDictById info failed", err)
		return err
	}
	logger.Infof(ctx, "UserChitChatConfirm suc, userId=%v, chitchatcode=%v", userId, chitchatCode)

	if cdkeyItem.GetFromUserId() != userId {
		expire := time.Now().Add(time.Hour * 24 * 10).UnixMilli()
		umItem := &pbapi.SecretUserMedalInfoMgDbModel{
			Id:        proto.Int64(snow_flake.GetSnowflakeID()),
			UserId:    proto.Int64(cdkeyItem.GetFromUserId()),
			MedalId:   proto.Int64(const_busi.MedalIdXinYa),
			Expire:    proto.Int64(expire),
			Timestamp: proto.Int64(utils.GetCurTsMs()),
		}
		if err := p.DataCache.GetImpl().UserMedalMgModel.CreateOrUpdateRecord(ctx, umItem); err != nil {
			logger.Error(ctx, "核销验证码新芽勋章失败", err)
		}
	}

	return nil
}

func (p *UserLevelMng) checkLevUpAndUpdate(ctx context.Context,
	header *pbapi.HttpHeaderInfo,
	userId int64,
	ss *LevelSession,
	curLevInfo *pbuserapi.LevelInfo,
	addSignupTimes, addCodeTimes int32) (*pbuserapi.CommLevelUpResp, error) {

	resp := &pbuserapi.CommLevelUpResp{BLevelUp: false}

	// 查看用户签到等资源的收集
	if ss.UserSignUpItem == nil {
		//新增, addSignupTimes,addCodeTimes 只有一个为1，新增记录不会升级。
		levelupItem := &pbdb.UserLevelUpRecordDbModel{
			UserId:            proto.Int64(userId),
			SignTimes:         proto.Int32(addSignupTimes),
			ChitchatCodeTimes: proto.Int32(addCodeTimes),
		}
		levelupItem, err := p.DataCache.GetImpl().UserLevelUpRecordDbModel.CreateItem(ctx, levelupItem)
		if err != nil {
			logger.Error(ctx, "create levelup table failed.", err)
			return resp, err
		}
		return resp, nil
	} else {
		// 判断升级逻辑
		resp.BLevelUp = p.checkLevelUp(ctx, ss, curLevInfo, addSignupTimes, addCodeTimes)

		if ss.CurLevel == const_level.UserLevel4 && header.GetVersioncode() < version.CommentEmotionVersion {
			// 兼容老版本最高级别为4级，后续删除
			return resp, nil
		}

		if resp.BLevelUp && ss.CurLevel == const_level.UserLevel4 {
			// 用于升级弹窗
			resp.NextLevelInfo = curLevInfo
		}

		if resp.BLevelUp == true {
			//升级成功了
			nextLevCfg := const_level.GetLevelCfg(ss.CurLevel + 1)

			// 升级后下一个等级的信息
			ss.CurLevel += 1                                     //等级+1
			ss.UserSignUpItem.ChitchatCodeTimes = proto.Int32(0) //统计清零
			ss.UserSignUpItem.SignTimes = proto.Int32(0)         // 统计清零
			levelInfo := ss.getUserLev()                         // 获取下一个等级的信息
			if resp.NextLevelInfo == nil {
				resp.NextLevelInfo = levelInfo
			}
			resp.NextLevelDesc = nextLevCfg.LevelUpDescArr // 填充等级描述
			// 更新等级到userExt表
			update := map[string]interface{}{"ulevel": ss.CurLevel}
			err := p.DataCache.GetImpl().UserInfoExtMgModel.UpdateDictById(ctx, userId, update, nil)
			if err != nil {
				logger.Error(ctx, "UpdateDictById info failed", err)
				return nil, err
			}
		}

		// 将更新的记录保存到db
		changes := map[string]interface{}{
			"sign_times":          ss.newSignTimes,
			"chitchat_code_times": ss.newCdKeyTimes,
		}
		cond := map[string]interface{}{
			"user_id": userId,
		}
		err := p.DataCache.GetImpl().UserLevelUpRecordDbModel.UpdateByCondition(ctx, cond, changes)
		if err != nil {
			logger.Error(ctx, "update level info failed", err)
			return resp, err
		}
	}

	return resp, nil
}

// 等级
func (p *UserLevelMng) checkLevelUp(ctx context.Context, ss *LevelSession, curLevInfo *pbuserapi.LevelInfo, addSignupTimes, addCodeTimes int32) bool {
	bLevelUp := ss.checkCodeAndSign(curLevInfo, addSignupTimes, addCodeTimes)

	// 除了需要满足的激活码和签到
	switch ss.UserExt.GetUlevel() {
	case const_level.UserLevel4:
		curLevInfo.NextLevelCard.RealNameAuth = proto.Int32(const_level.RealNameAuthNoPass)
		curLevInfo.NextLevelCard.SheNiuAuth = proto.Int32(const_level.SheNiuAuthNoPass)
		// 身份证
		filter := bson.D{
			{"user_id", ss.UserId},
			{"status", const_busi.UserCardStatus},
		}
		_, err := p.DataCache.GetImpl().SecretUserIdentificationCardMgModel.FindOne(ctx, filter)
		switch err {
		case mongo.ErrNoDocuments:
			bLevelUp = false
		case nil:
			curLevInfo.NextLevelCard.RealNameAuth = proto.Int32(const_level.RealNameAuthPass)
		default:
			logger.Error(ctx, "SecretUserIdentificationCardMgModel.FindOne", err)
			bLevelUp = false
		}
		// 5 社牛勋章
		medal, err := p.DataCache.GetImpl().UserMedalMgModel.GetOneByMediaAndUserId(ctx, ss.UserId, 5)
		if err != nil {
			logger.Error(ctx, "checkLevelUp.GetOneByMediaAndUserId", err)
			bLevelUp = false
		}
		if medal == nil {
			bLevelUp = false
		} else {
			curLevInfo.NextLevelCard.SheNiuAuth = proto.Int32(const_level.SheNiuAuthPass)
		}
		curLevInfo.NextLevelDesc = curLevInfo.NextLevelCard.NextLevelDesc
		if bLevelUp {
			curLevInfo.BLevelUp = bLevelUp
			curLevInfo.Ulevel = curLevInfo.NextLevelCard.NextUlevel
			curLevInfo.LevelTitle = curLevInfo.NextLevelCard.NextLevelTitle
			// 关闭下一级的资料条
			curLevInfo.NextLevelCard = nil
			ss.newSignTimes = 0
			ss.newCdKeyTimes = 0
		}

		// 都满足
		return bLevelUp
	default:
		// 其他级别不处理
		return bLevelUp
	}
}
