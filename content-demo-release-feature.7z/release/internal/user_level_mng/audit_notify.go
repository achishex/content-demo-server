package user_level_mng

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/content_mng"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

type notifyMessage struct {
	ulevel int32

	reportUserId int64  // 举报人
	reportTime   string // 举报时间
	userId       int64  // 被举报人
	timeClock    string // 发布时间
	workId       int64  // 举报的动态
	commentId    int64  // 评论

	messageType string // 消息类型，eq：评论，动态，私聊
	content     string // 内容
	isPunish    bool   // 是否被处罚
	isDegrade   bool   // 是否被降级
}

func (n *notifyMessage) setReportUserId(id int64) {
	n.reportUserId = id
}

func (n *notifyMessage) setReportTime(t int64) {
	if t == 0 {
		return
	}
	n.reportTime = time.UnixMilli(t).Format("2006-01-02 15:04:05")
}

const (
	//_ uint8 = iota
	commentType  = "评论"
	dynamicsType = "动态"
	talkType     = "私聊"
)

func (p *UserLevelMng) AuditNotify(ctx context.Context,
	_ *pbapi.HttpHeaderInfo, req *pbuserapi.AuditNotifyReq) error {
	var punishStatus, arrestType int32
	var reportTime int64
	var userId, workId, commentId, reportUserId, reportItemId int64

	if req.GetReportId() != 0 {
		// 获取举报/抓捕信息
		reportItem, err := p.DataCache.GetImpl().SecretReport.GetById(ctx, req.GetReportId())
		if err != nil {
			logger.Error(ctx, "report no fund", err)
			return err
		}
		reportItemId = reportItem.GetId()
		punishStatus = reportItem.GetVerifyStatus()
		arrestType = reportItem.GetType()
		userId = reportItem.GetUserId()
		workId = reportItem.GetWorkId()
		commentId = reportItem.GetCommentId()
		reportUserId = reportItem.GetReportUserId()
		reportTime = reportItem.GetTimestamp()
	} else {
		// 复审列表的处罚，暂时只有动态
		punishStatus = req.GetVerifyStatus()
		arrestType = cm_const.AuditReexamine
		userId = req.GetUserId()
		workId = req.GetWorkId()
		reportUserId = req.GetReportUserId()
	}

	nm, err := p.initNotifyMessage(ctx, arrestType, userId, workId, commentId)
	if err != nil {
		return err
	}
	nm.setReportUserId(reportUserId)
	nm.setReportTime(reportTime)

	switch {
	case utils.HasInt32Element(punishStatus, cm_const.AuditStatusWeiGui):
		// 处罚
		switch nm.messageType {
		case dynamicsType:
			{
				content_mng.NewSuperiorContentInstance(&content_mng.ContentMng{
					DataCache: p.DataCache,
				}, nil, 0).PenalizeWorkAward(ctx, workId)

				content_mng.NewAddKoLaHallOfFameInstance(&content_mng.ContentMng{
					DataCache: p.DataCache,
				}).PenalizeWorkAward(ctx, workId)
			}
			break
		case commentType:
			//var toDelComment *pbmgdb.WorksCommentDetailMgDbModel
			//{
			//	toDelComment, _ = p.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentById(ctx, nm.commentId)
			//}
			//
			if err := p.removeComment(ctx, punishStatus, nm.userId, nm.workId, nm.commentId); err != nil {
				logger.Error(ctx, "removeComment", err)
			}
			//
			//{
			//	content_mng.NewSuperiorContentInstance(&content_mng.ContentMng{
			//		DataCache: p.DataCache,
			//	}, nil, 0).PenalizeWorkAwardWithComment(ctx, workId, nm.commentId, toDelComment.GetUserId())
			//}
			//
		case talkType:
			break
		}

		nm.isPunish = true
		if utils.HasInt32Element(punishStatus, cm_const.LightWeiGui) {
			nm.isDegrade = false
		} else { // 中等、严重 要降级
			nm.isDegrade = true
			// 获取ext
			extInfo, err := p.DataCache.GetImpl().UserInfoExtMgModel.GetByUserId(ctx, userId)
			if err != nil {
				logger.Error(ctx, "cat not get extInfo.level", err)
				return err
			}
			//ulevel := extInfo.GetUlevel()

			ulevel, err := p.lowerUserLevel(ctx, punishStatus, extInfo)
			if err != nil {
				logger.Error(ctx, "降级失败了", err)
			}
			nm.ulevel = ulevel
		}
	case punishStatus == cm_const.AuditStatusJuBaoBuChuLi:
		// 不处罚
		nm.isPunish = false
	default:
		logger.Error(ctx, fmt.Sprintf("处罚类型错误%d", punishStatus), nil)
		return nil
	}

	// 发通知
	switch nm.messageType {
	case dynamicsType, commentType:
		p.punishNotify(ctx, punishStatus, nm)
		if cm_const.AuditReexamine == arrestType {
			// 机器审核的没有奖励
			return nil
		}

		filter := bson.D{
			{"reportId", reportItemId},
		}
		reportUserInfo, err := p.DataCache.GetImpl().SecretReportUserMgModel.FindAll(ctx, filter)
		if len(reportUserInfo) == 0 {
			// 兼容老逻辑
			p.awardNotify(ctx, nm)
		}
		if err != nil {
			return err
		}
		for _, userInfo := range reportUserInfo {
			nm.setReportUserId(userInfo.ReportUserId)
			nm.setReportTime(userInfo.GetTimestamp())
			p.awardNotify(ctx, nm)
		}

	case talkType:
		// 不通知
	}

	return nil
}

func (p *UserLevelMng) getUserExtInfoAndWorkId(ctx context.Context, userId, workId int64) (
	*pbapi.SecretUserExtInfoMgDbModel, *pbapi.PersonalBottleWorksDbModel, error) {
	// 获取ext
	extInfo, err := p.DataCache.GetImpl().UserInfoExtMgModel.GetByUserId(ctx, userId)
	if err != nil {
		logger.Error(ctx, "cat not get extInfo.level", err)
		return nil, nil, err
	}

	// 获取workId
	workInfo, err := p.DataCache.GetImpl().PersonBottleWorksModel.GetByWorkId(ctx, workId)
	if err != nil || workInfo == nil {
		logger.Infof(ctx, "audit report, workid is illegal")
		//return err
	}
	return extInfo, workInfo, nil
}

func (p *UserLevelMng) initNotifyMessage(ctx context.Context, arrestType int32, userId, workId, commentId int64) (*notifyMessage, error) {
	var nm notifyMessage
	// 通知
	switch arrestType {
	case cm_const.AuditWork, cm_const.Audit2WorkImage, cm_const.Audit2BackgroundImage, cm_const.AuditReexamine:
		// 获取workId
		workInfo, err := p.DataCache.GetImpl().PersonBottleWorksModel.GetByWorkId(ctx, workId)
		if err != nil || workInfo == nil {
			logger.Infof(ctx, "audit report, workid is illegal: ", workId)
			//return err
		}
		nm = notifyMessage{
			userId:      userId,
			workId:      workId,
			timeClock:   workInfo.GetCreateTime(),
			messageType: dynamicsType,
			content:     utils.MaskString(workInfo.GetTitle()),
		}
	case cm_const.AuditComment:
		commentDetail, err := p.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentById(ctx, commentId)
		if err != nil {
			return nil, err
		}

		cTime, err := time.Parse("2006-01-02 15:04:05.000", commentDetail.GetCreateTime())
		if err != nil {
			return nil, err
		}
		timeClock := cTime.Format("2006-01-02 15:04:05")
		nm = notifyMessage{
			userId:      userId,
			workId:      workId,
			commentId:   commentId,
			timeClock:   timeClock,
			messageType: commentType,
			content:     utils.MaskString(commentDetail.GetComment()),
		}
	case cm_const.AuditTalk:
		// 不通知
		nm = notifyMessage{
			userId:      userId,
			workId:      workId,
			timeClock:   "",
			messageType: talkType,
			content:     "",
		}
	}

	return &nm, nil
}

func (p *UserLevelMng) sendNotify(ctx context.Context, userId int64, html string) {
	if err := p.DataCache.GetImpl().PersonalUserNotificationMgModel.SendNotify(ctx, &userId, html); err != nil {
		logger.Error(ctx, "PersonalUserNotificationMgModel.SendNotify", err)
	}
}
