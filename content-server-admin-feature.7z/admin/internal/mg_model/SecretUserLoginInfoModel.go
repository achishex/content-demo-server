package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"context"
	"go.mongodb.org/mongo-driver/mongo"
)

type ISecretUserLoginInfoMgModel interface {
	Insert(ctx context.Context, item *pbmgdb.SecretUserLoginInfoMgDbModel) error
}

func NewSecretUserLoginInfoMgModel(mgdb *mongo.Database) ISecretUserLoginInfoMgModel {
	return &SecretUserLoginInfoMgModel{db: mgdb}
}

type SecretUserLoginInfoMgModel struct {
	db *mongo.Database
}

func (m *SecretUserLoginInfoMgModel) Insert(ctx context.Context, item *pbmgdb.SecretUserLoginInfoMgDbModel) error {
	_, err := m.db.Collection("secretUserLoginInfo").InsertOne(ctx, item)
	return err
}
