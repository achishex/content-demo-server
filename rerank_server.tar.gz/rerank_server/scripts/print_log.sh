#! /usr/bin/env bash 

DIR_SCRIPT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log_prod_server() {
    echo "运行 脚本工具  服务"
    cd ${DIR_SCRIPT}/..
    echo "show  ai-rerank-service logs -f ......"
    docker-compose logs -f ai-rerank-service   
    cd -
}

# 根据参数调用函数
case "$1" in
  prod)
    ${DIR_SCRIPT}/init_env.sh "$1"
    log_prod_server
    ;;
  *)
    echo "未知环境: $1. 请使用 prod"
    exit 1
    ;;
esac