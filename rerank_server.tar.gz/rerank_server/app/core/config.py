import os

############### Number of log files ###############
LOGS_NUM = int(os.getenv("logs_num", "3"))