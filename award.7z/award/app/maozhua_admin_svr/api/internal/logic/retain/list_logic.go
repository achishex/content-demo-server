package retain

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/db/mongodb/model"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/zeromicro/go-zero/core/logx"
	"go.mongodb.org/mongo-driver/bson"
	"math"
	"sort"
	"strconv"
)

type ListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ListLogic {
	return &ListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ListLogic) List(req *types.RetainListReq) (resp *types.RetainListResp, err error) {
	retainList := make([]types.RetainTable, 0)
	key := "%d" // day

	filter := map[string]interface{}{}
	if req.Channel != "" {
		filter = l.buildFilter(filter, "channel", req.Channel)
		key = key + "-" + req.Channel
	}
	if req.AppType != "" {
		filter = l.buildFilter(filter, "app_type", req.AppType)
		key = key + "-" + req.AppType
	}
	if req.Gender != 0 {
		filter = l.buildFilter(filter, "gender", req.Gender)
		key = key + "-" + strconv.Itoa(req.Gender)
	}
	switch req.Market {
	case 1:
		if req.Market == 1 {
			filter = l.buildFilter(filter, "market", req.Market)
			key = key + "-" + strconv.Itoa(req.Market)
		}
	case 2:
		if req.Market == 2 {
			filter = l.buildFilter(filter, "market", bson.D{
				{"$ne", 1},
			})
			key = key + "-" + strconv.Itoa(req.Market)
		}
	}

	if req.TimeStart != 0 && req.TimeEnd != 0 {
		filter = l.buildFilter(filter, "day", bson.D{
			{"$gte", req.TimeStart},
			{"$lte", req.TimeEnd},
		})
	}

	//logx.Disable()
	channelList, err := l.svcCtx.ManagerOnlyReadDB.SecretUserChannelDaily.FindAll(l.ctx, filter)
	if err != nil {
		return nil, err
	}
	targetChannelMap := map[string]model.SecretUserChannelDaily{}
	for _, channelDaily := range channelList {
		uniqueKey := fmt.Sprintf(key, channelDaily.Day)
		item, ok := targetChannelMap[uniqueKey]
		if ok {
			item.ActiveUserCount += channelDaily.ActiveUserCount
			item.ActiveTargetUserCount += channelDaily.ActiveTargetUserCount
			item.NewUserCount += channelDaily.NewUserCount
			item.NewTargetUserCount += channelDaily.NewTargetUserCount
		} else {
			item = channelDaily
		}

		targetChannelMap[uniqueKey] = item
	}

	targetChannel := make([]model.SecretUserChannelDaily, 0)
	for _, daily := range targetChannelMap {
		targetChannel = append(targetChannel, daily)
	}

	sort.Slice(targetChannel, func(i, j int) bool {
		return targetChannel[i].Day > targetChannel[j].Day
	})

	for _, channelDaily := range targetChannel {
		retain := types.RetainTable{
			Date: channelDaily.Day,
			//ActiveUserCount: item.ActiveUserCount,
		}

		filter = l.buildFilter(filter, "day", channelDaily.Day)
		filter = l.buildFilter(filter, "retain_type", map[string]interface{}{
			"$in": []int{0, 1, 2, 3, 4, 5, 6, 7, 15, 30},
		})
		//filter = map[string]interface{}{
		//	"day":      item.Day,
		//	"channel":  item.Channel,
		//	"gender":   item.Gender,
		//	"app_type": item.AppType,
		//	"retain_type": map[string]interface{}{
		//		"$in": []int{0, 1, 2, 3, 4, 5, 6, 7, 15, 30},
		//	},
		//}
		statisticsList, err := l.svcCtx.ManagerOnlyReadDB.SecretUserRetainedStatistics.FindAll(l.ctx, filter)
		if err != nil {
			return nil, err
		}

		targetRetainMap := map[string]model.SecretUserRetainedStatistics{}
		for _, retainedStatistics := range statisticsList {
			uniqueKey := fmt.Sprintf(key+"-%d", retainedStatistics.Day, retainedStatistics.RetainType)
			value, ok := targetRetainMap[uniqueKey]
			if ok {
				value.NewRetainCount += retainedStatistics.NewRetainCount
				value.ActiveRetainCount += retainedStatistics.ActiveRetainCount
				value.NewTargetRetainCount += retainedStatistics.NewTargetRetainCount
				value.ActiveTargetRetainCount += retainedStatistics.ActiveTargetRetainCount

			} else {
				value = retainedStatistics
			}

			targetRetainMap[uniqueKey] = value
		}

		targetRetain := make([]model.SecretUserRetainedStatistics, 0)
		for _, daily := range targetRetainMap {
			targetRetain = append(targetRetain, daily)
		}

		for _, statistics := range targetRetain {
			// 分子
			// 分母
			numerator, denominator := l.getNumeratorAndDenominator(req.ListType, statistics, channelDaily)
			retain.ActiveUserCount = denominator
			logger.Errorf(l.ctx, "分子 %v, 分母 %v， 计算结果：%.4f", numerator, denominator, math.Round(float64(numerator)/float64(denominator)*1000)/1000)
			retain = l.buildRetainTable(retain, statistics.RetainType, numerator, denominator)
		}

		retainList = append(retainList, retain)

	}

	resp = &types.RetainListResp{
		List: retainList,
	}

	return
}

func (l *ListLogic) buildFilter(filter map[string]interface{}, key string, value interface{}) map[string]interface{} {
	switch v := value.(type) {
	case int:
		if v == 0 {
			return filter
		}
		filter[key] = value
	case string:
		if v == "" {
			return filter
		}
		filter[key] = value
	default:
		filter[key] = value
	}

	return filter
}

// 获取分子，分母
func (l *ListLogic) getNumeratorAndDenominator(listType int, statistics model.SecretUserRetainedStatistics, item model.SecretUserChannelDaily) (numerator, denominator int) {
	switch listType {
	case 1:
		numerator = statistics.NewRetainCount
		denominator = item.NewUserCount
	case 2:
		numerator = statistics.NewTargetRetainCount
		denominator = item.NewUserCount
	case 3:
		numerator = statistics.ActiveRetainCount
		denominator = item.ActiveUserCount
	case 4:
		numerator = statistics.ActiveTargetRetainCount
		denominator = item.ActiveUserCount
	default:
		return 1, 1
	}

	//if numerator == 0 {
	//	numerator = denominator
	//}
	//
	//if denominator == 0 {
	//	numerator = 0
	//	denominator = 1
	//}

	return
}

func (l *ListLogic) buildRetainTable(retain types.RetainTable, retainType, numerator, denominator int) types.RetainTable {

	//fmt.Printf("日期%d 第%d天后 分子%d 分母%d\n", retain.Date, retainType, numerator, denominator)
	var calc float64
	if denominator == 0 {
		calc = 0
	} else {
		calc = math.Round(float64(numerator)/float64(denominator)*1000) / 1000
	}
	switch retainType {
	case 0:
		retain.DayLater0 = calc
	case 1:
		retain.DayLater1 = calc
	case 2:
		retain.DayLater2 = calc
	case 3:
		retain.DayLater3 = calc
	case 4:
		retain.DayLater4 = calc
	case 5:
		retain.DayLater5 = calc
	case 6:
		retain.DayLater6 = calc
	case 7:
		retain.DayLater7 = calc
	case 15:
		retain.DayLater15 = calc
	case 30:
		retain.DayLater30 = calc
	default:
		return retain
	}

	return retain
}
