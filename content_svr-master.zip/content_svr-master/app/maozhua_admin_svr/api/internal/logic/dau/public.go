package dau

import (
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/db/mongodb/model"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
)

func GetUserActivityFilter(req types.UserActivityFilter) (map[string]interface{}, string) {
	var daily model.SecretUserActivityDaily
	filter := map[string]interface{}{}
	if req.Channel != "" {
		filter = BuildFilter(filter, "channel", req.Channel)
		daily.Channel = req.Channel
	}
	if req.AppType != "" {
		filter = BuildFilter(filter, "app_type", req.AppType)
		daily.AppType = req.AppType
	}
	if req.Gender != 0 {
		filter = BuildFilter(filter, "gender", req.Gender)
		daily.Gender = req.Gender
	}
	switch req.Market {
	case 1:
		if req.Market == 1 {
			filter = BuildFilter(filter, "market", req.Market)
			daily.Market = req.Market
		}
	case 2:
		if req.Market == 2 {
			filter = BuildFilter(filter, "market", bson.D{
				{"$ne", 1},
			})
			daily.Market = req.Market
		}
	}

	if req.TimeStart != 0 && req.TimeEnd != 0 {
		filter = BuildFilter(filter, "day", bson.D{
			{"$gte", req.TimeStart},
			{"$lte", req.TimeEnd},
		})
	}

	key := "%d" // day
	return filter, key + fmt.Sprintf("%s", UniqueKey(daily))
}

func BuildFilter(filter map[string]interface{}, key string, value interface{}) map[string]interface{} {
	switch v := value.(type) {
	case int:
		if v == 0 {
			return filter
		}
		filter[key] = value
	case string:
		if v == "" {
			return filter
		}
		filter[key] = value
	default:
		filter[key] = value
	}

	return filter
}

// UniqueKey 生成 secretUserChannelDaily 表唯一键
func UniqueKey(daily model.SecretUserActivityDaily) string {
	if daily.Day == 0 {
		return fmt.Sprintf("%s-%s-%d-%d", daily.AppType, daily.Channel, daily.Gender, daily.Market)
	} else {
		return fmt.Sprintf("%d-%s-%s-%d-%d", daily.Day, daily.AppType, daily.Channel, daily.Gender, daily.Market)

	}
}
