package im_mng

import (
	"encoding/json"
	"github.com/OpenIMSDK/protocol/sdkws"
)

type SetGroupInfoReq struct {
	GroupInfoForSet *sdkws.GroupInfoForSet `json:"groupInfoForSet"`
	GroupExt        *GroupExt              `json:"groupExt"` //群业务扩展字段，最后会存入*sdkws.GroupInfoForSet的Ex字段
}

// 群业务扩展
type GroupExt struct {
	Background         string `json:"background"`         //群聊背景
	HomepageBackground string `json:"homepageBackground"` //群主页背景
	Remark             string `json:"remark"`             //群备注
}

// 用户信息业务扩展字段
type UserExt struct {
	Gender int32 `json:"gender"` //性别
}

// // MSG
type ICustomMsg interface {
	Build() *CustomMsg
}

// CustomMsg 扩展群消息
type CustomMsg struct {
	MsgType int32 `json:"msg_type"`
	Data    any   `json:"data"`
}

// ToMap 转成openim api消息
func (m *CustomMsg) ToMap() map[string]any {
	bs, _ := json.Marshal(m)
	return map[string]any{
		"data":        string(bs),
		"description": "",
		"extension":   "",
	}
}

type WorkAtMsg struct {
	Title  string `json:"title"`
	Type   int32  `json:"type"`
	UserID int64  `json:"user_id"`
	WorkID int64  `json:"work_id"`
}

func (m *WorkAtMsg) Build() *CustomMsg {
	return &CustomMsg{
		MsgType: 1001,
		Data:    m,
	}
}

type CommentAtMsg struct {
	Title     string `json:"title"`
	WorkID    int64  `json:"work_id"`
	CommentID int64  `json:"comment_id"`
}

func (m *CommentAtMsg) Build() *CustomMsg {
	return &CustomMsg{
		MsgType: 1002,
		Data:    m,
	}
}

type UserLite struct {
	UserID   string
	NickName string
	FaceURL  string
}
