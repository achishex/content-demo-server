package zoo

import (
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"strconv"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type PaySumListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewPaySumListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *PaySumListLogic {
	return &PaySumListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *PaySumListLogic) PaySumList(req *types.PaySumReq) (resp *types.PaySumResp, err error) {

	filter := bson.M{
		"day": bson.D{
			{"$gte", req.TimeStart},
			{"$lte", req.TimeEnd},
		},
		"gameId": req.GameId,
	}

	if req.Channel != "" {
		filter["channel"] = req.Channel
	}

	if req.Platform != "" {
		p, _ := strconv.Atoi(req.Platform)
		filter["platform"] = p
	}

	list, err := l.svcCtx.ReadDB.ZooGamePayDaily.FindAll(l.ctx, filter)
	if err != nil {
		return nil, err
	}

	logger.Infof(l.ctx, "list: %v", list)

	result := make(map[uint]types.PayRespItem)
	for _, item := range list {
		value, ok := result[item.Day]

		if ok {
			value.Cost += item.Cost

			vd := value.Data
			for k, v := range item.Data {
				vd[k] += v
			}
			value.Data = vd

			result[item.Day] = value
		} else {
			result[item.Day] = types.PayRespItem{
				Day:  item.Day,
				Data: item.Data,
				Cost: item.Cost,
			}
		}
	}

	// 计算真实的收入
	for _, item := range result {
		for k, v := range item.Data {
			item.Data[k] = v * zoo_pay_ration
		}
	}

	rl := make([]types.PaySumItem, 0)

	for i := req.TimeStart; i <= req.TimeEnd; i++ {
		cost := result[uint(i)].Cost
		if cost <= 0 {
			cost = 1
		}
		d := result[uint(i)].Data

		item := types.PaySumItem{
			Day:  i,
			Sum1: decimal(d[1] / cost),
			Sum2: decimal(d[2] / cost),
			Sum3: decimal(d[3] / cost),
			Sum4: decimal(d[4] / cost),
			Sum5: decimal(d[5] / cost),
			Sum6: decimal(d[6] / cost),
			Sum7: decimal(d[7] / cost),
		}

		rl = append(rl, item)
	}

	return &types.PaySumResp{
		List: rl,
	}, nil

}

func decimal(value float64) float64 {
	value, _ = strconv.ParseFloat(fmt.Sprintf("%.2f", value), 64)
	return value
}
