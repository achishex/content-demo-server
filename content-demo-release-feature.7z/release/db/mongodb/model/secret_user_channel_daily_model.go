package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

const SecretUserChannelDailyCollectionName = "secretUserChannelDaily"

var _ SecretUserChannelDailyModel = (*customSecretUserChannelDailyModel)(nil)

type (
	// SecretUserChannelDailyModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretUserChannelDailyModel.
	SecretUserChannelDailyModel interface {
		secretUserChannelDailyModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretUserChannelDaily, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretUserChannelDaily, error)
		InsertMany(ctx context.Context, data []*SecretUserChannelDaily, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error)
	}

	customSecretUserChannelDailyModel struct {
		*defaultSecretUserChannelDailyModel
	}
)

// NewSecretUserChannelDailyModel returns a model for the mongo.
func NewSecretUserChannelDailyModel(cfg MonConfig) SecretUserChannelDailyModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SecretUserChannelDailyCollectionName)
	return &customSecretUserChannelDailyModel{
		defaultSecretUserChannelDailyModel: newDefaultSecretUserChannelDailyModel(conn),
	}
}

func (m *customSecretUserChannelDailyModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	} else {
		flagType = "default"
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customSecretUserChannelDailyModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretUserChannelDailyModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretUserChannelDaily, error) {
	result := make([]SecretUserChannelDaily, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretUserChannelDailyModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretUserChannelDaily, error) {
	var data SecretUserChannelDaily
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretUserChannelDailyModel) InsertMany(ctx context.Context, data []*SecretUserChannelDaily, opts ...*options.InsertManyOptions) (*mongo.InsertManyResult, error) {
	insertData := make([]any, 0)
	for _, datum := range data {
		now := time.Now()
		datum.ID = primitive.NewObjectIDFromTimestamp(now)
		datum.CreateTime = now.UnixMilli()
		insertData = append(insertData, datum)
	}

	insert, err := m.conn.InsertMany(ctx, insertData, opts...)
	return insert, err
}
