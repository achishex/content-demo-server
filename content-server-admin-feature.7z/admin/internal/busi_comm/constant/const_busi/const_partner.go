package const_busi

const (
	PopupTypeNoSign    = 1 //未签到
	PopupTypeCarveUp   = 2 //瓜分奖池
	PopupTypeInvite    = 3 //邀请信息
	PopupTypeBePartner = 4 //成为合伙人
)

var (
	InvitePassphrase = "复/&p致[%s] 下载【猫爪】 新用户可免费领取现金红包! 好运连连, 权益5天内有效 快去商店搜索下载「猫爪」吧"
)
