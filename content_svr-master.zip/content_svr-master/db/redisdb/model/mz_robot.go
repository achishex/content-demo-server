package model

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/redisdb/model/internal"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/go-redis/redis/v8"
	"time"
)

type MzRobotRedis struct {
	internal.RdsInfo
}

func NewMzRobotRedis(rds *redis.Client, env string) *MzRobotRedis {
	return &MzRobotRedis{
		RdsInfo: internal.RdsInfo{
			Env:    env,
			Expire: time.Hour * 24,
			Client: rds,
		},
	}
}

func (r *MzRobotRedis) getRdsKey() string {
	return fmt.Sprintf("platform:%v:robot:rules", r.Env)
}

func (r *MzRobotRedis) getRdsKeySubKey() string {
	return fmt.Sprintf("platform:%v:pub_sub:robot", r.Env)
}

func (r *MzRobotRedis) GetRdsRules(ctx context.Context, id string) (*model.MzRobot, error) {
	rdsKey := r.getRdsKey()

	result, err := r.Client.HGet(ctx, rdsKey, id).Bytes()
	if err != nil {
		return nil, err
	}

	robot := model.MzRobot{}
	if err := json.Unmarshal(result, &robot); err != nil {
		return nil, err
	}

	return &robot, err
}

func (r *MzRobotRedis) SetRdsRules(ctx context.Context, robot *model.MzRobot) error {
	rdsKey := r.getRdsKey()

	b, _ := json.Marshal(robot)

	_, err := r.Client.HSet(ctx, rdsKey, robot.ID.Hex(), string(b)).Result()
	if err != nil {
		return err
	}
	//fmt.Println(x)

	return err
}

func (r *MzRobotRedis) DelRdsRules(ctx context.Context, robotId string) error {
	rdsKey := r.getRdsKey()
	result, err := r.Client.HDel(ctx, rdsKey, robotId).Result()
	if err != nil {
		return err
	}

	if result == 0 {
		return errors.New("删除机器人配置失败")
	}

	return err
}

func (r *MzRobotRedis) Subscript() *redis.PubSub {
	subKey := r.getRdsKeySubKey()
	return r.Client.Subscribe(context.Background(), subKey)
}
