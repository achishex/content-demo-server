package main

import (
	"content_svr/app/app_comm"
	dbConfig "content_svr/app/maozhua_admin_svr/common/db"
	"content_svr/app/timer_job/job"
	"content_svr/app/timer_job/once"
	"content_svr/config"
	"content_svr/db/dao"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
	"content_svr/internal/content_mng"
	"content_svr/internal/inner_mng"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/mg_model"
	"content_svr/internal/model"
	"content_svr/internal/thirdparty/baidu_lbs_yun_proxy"
	"content_svr/internal/thirdparty/shumei_proxy"
	"content_svr/internal/thirdparty/wechat_proxy"
	"content_svr/pub/logger"
	"content_svr/pub/snow_flake"
	"context"
	"fmt"
	go_cache "github.com/fanjindong/go-cache"
	rdsV8 "github.com/go-redis/redis/v8"
	"github.com/robfig/cron/v3"
	"gorm.io/gorm"
	"time"
)

func main() {
	snow_flake.SetMachineID(config.NodeIdx)
	//初始化mysql DB
	mysql, err := model.NewDBInstance(config.ServerConfig.MysqlConfig)
	if err != nil {
		logger.Error(context.Background(), "new db instansce failed", err)
		return
	}
	mysqlRead, err := model.NewDBInstance(config.ServerConfig.MysqlConfigRead)
	if err != nil {
		logger.Error(context.Background(), "new db instansce failed", err)
		return
	}
	// 初始化mongoDB
	mgDb, err := mg_model.NewMongoDBInstance(config.ServerConfig.MongodbConfig)
	if err != nil {
		logger.Error(context.Background(), "new mongo db instansce failed", err)
		return
	}
	//mgDbRead, err := mg_model.NewMongoDBInstance(config.ServerConfig.MongodbConfigRead)
	//if err != nil {
	//	logger.Error(context.Background(), "new mongo db instansce failed", err)
	//	return
	//}

	//初始化本地缓存对象
	localCache := go_cache.NewMemCache()

	//初始化 redis_cli
	redisCli := InitRdsClient(config.ServerConfig.RedisConfig.Addr, config.ServerConfig.RedisConfig.Pwd)
	if err != nil {
		logger.Error(context.Background(), "new redis client failed", err)
		return
	}

	// 初始化kafka
	kafkaProxy := kafka_proxy.NewKafkaProxyImpl(config.ServerConfig.KafkaConfig)

	// 初始化thirdparty
	bdLbsProxy := baidu_lbs_yun_proxy.NewBaiduLbsYunProxyImpl()

	shumeiProxy := shumei_proxy.NewShumeiProxyImpl()

	// 初始化innerProxy
	innerProxy := inner_mng.NewInnerProxyImpl(redisCli)

	wxProxy := wechat_proxy.NewWechatMng()

	// 初始化 data_cache层
	dataCache := app_comm.BuildDataCache(mysql, nil, mgDb, redisCli, bdLbsProxy, localCache)

	kwMng := content_mng.NewContentMng(dataCache, bdLbsProxy, shumeiProxy, innerProxy, kafkaProxy, nil)

	managerDB := InitManager(mysql, config.ServerConfig.MongodbConfig, redisCli)
	managerReadDB := InitManager(mysqlRead, config.ServerConfig.MongodbConfigRead, redisCli)

	logger.DebugLogger(config.ServerConfig.Env)
	// 通过参数执行一次
	once.InitCommand(mgDb, mysql, redisCli)
	once.Command.Run()
	// 启动飞书机器人监听消息
	job.InitServeRobot()
	// 运动数据定时器
	job.TimerSportFish(kwMng, config.ServerConfig.SportTime)
	// 可乐计划的结算任务
	job.NewKoLaPlanSettlement(dataCache, config.ServerConfig.SuperiorContentConfig).TimerSettlement()
	// 定时查询微信转账结果任务
	job.NewWithdrawPayQueryTask(dataCache, wxProxy, config.ServerConfig.SuperiorContentConfig).DoTask()
	// 定时器结算kola名人堂
	job.NewKoLaHallOfFameSettlement(dataCache, &config.ServerConfig.SuperiorContentConfig.KoLaHallOfFameConfigItem).DoTask()
	job.NewUserReportChecker(dataCache).DoTask()
	// 留存率计算
	job.InitCalcRetain(managerDB, managerReadDB)
	// 清理超过40天的用户活动记录
	//job.InitCleanUserActivity(managerDB, managerReadDB)
	// 奖励计算
	job.InitAwardCalcSum(managerDB, managerReadDB)
	// 会员计算
	job.InitMemberSum(managerDB, managerReadDB)
	// 结算消息通知
	job.InitMoneyRobot(managerDB, managerReadDB)

	//定时任务
	c := cron.New(cron.WithSeconds())

	//清理一天前的内容分发池, 每天凌晨一天执行
	if eid, err := c.AddFunc("0 0 1 * * ?", func() {
		job.CleanWorkPool(dataCache)
	}); err != nil {
		panic(fmt.Sprintf("EntryId:%v, err: %v", eid, err))
	}

	c.Start()

	select {}
}

func InitRdsClient(addr, pwd string) *rdsV8.Client {
	client := rdsV8.NewClient(&rdsV8.Options{
		Addr:         addr,
		Password:     pwd,
		DB:           0,
		ReadTimeout:  2 * time.Minute,
		WriteTimeout: 1 * time.Minute,
		PoolTimeout:  2 * time.Minute,
		IdleTimeout:  10 * time.Minute,
		PoolSize:     1000,
	})
	_, err := client.Ping(context.Background()).Result()
	if err != nil {
		panic(fmt.Sprintf("redis init failed. err:%v", err.Error()))
	}
	return client
}

func InitManager(db *gorm.DB, mgCfg *config.MongodbConfig, redisCli *rdsV8.Client) *dao.ManagerDB {
	mysql := query.Use(db)
	mongo := query_mng.NewQueryMng(dbConfig.MongoConfig{
		URI:    mgCfg.URI,
		DBName: mgCfg.DBName,
	})
	redisManage := query_rds.NewClient(redisCli, config.ServerConfig.Env)
	managerDB := dao.NewDbManager(mysql, mongo, redisManage)

	return managerDB
}
