package operate

import (
	"go.mongodb.org/mongo-driver/mongo/options"
	"gorm.io/gen/field"
)

type PageTurner interface {
	GetPager() (page, size int)
	GetWhere() map[string]interface{}
	ParseMongo() (map[string]interface{}, *options.FindOptions)
	ParseMysql() (where map[string]interface{}, offset, limit int)
	ParseMysqlOrderBy(tableName string) field.Expr
}
