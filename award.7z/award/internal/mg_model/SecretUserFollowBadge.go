package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretUserFollowBadgeMgDbModel interface {
	GetByCond(ctx context.Context, cond any) (*pbmgdb.SecretUserFollowBadgeMgDbModel, error)
	Add(ctx context.Context, d *pbmgdb.SecretUserFollowBadgeMgDbModel, opts ...*options.InsertOneOptions) error
	UpdateByUserId(ctx context.Context, cond, update map[string]any) error
}

type SecretUserFollowBadgeMgDbImpl struct {
	MgDB *mongo.Database
}

func NewSecretUserFollowBadgeMgModelImpl(db *mongo.Database) ISecretUserFollowBadgeMgDbModel {
	return &SecretUserFollowBadgeMgDbImpl{MgDB: db}
}

func (impl *SecretUserFollowBadgeMgDbImpl) table() string {
	return "secretUserFollowBadge"
}

func (impl *SecretUserFollowBadgeMgDbImpl) coll() *mongo.Collection {
	return impl.MgDB.Collection(impl.table())
}

func (impl *SecretUserFollowBadgeMgDbImpl) GetByCond(ctx context.Context, cond any) (*pbmgdb.SecretUserFollowBadgeMgDbModel, error) {
	v := &pbmgdb.SecretUserFollowBadgeMgDbModel{}
	err := impl.coll().FindOne(ctx, cond).Decode(v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserFollowBadgeMgDbImpl GetByUserId failed. cond=%v", cond), err)
		return nil, err
	}
	return v, err
}

func (impl *SecretUserFollowBadgeMgDbImpl) UpdateByUserId(ctx context.Context, cond, update map[string]any) error {
	if len(update) == 0 || len(cond) == 0 {
		return nil
	}

	mgUpdates := bson.D{}
	if len(update) > 0 {
		mgUpdates = append(mgUpdates, bson.E{"$set", update})
	}
	_, err := impl.coll().UpdateMany(ctx, cond, mgUpdates)
	return err
}

func (impl *SecretUserFollowBadgeMgDbImpl) Add(ctx context.Context, d *pbmgdb.SecretUserFollowBadgeMgDbModel, opts ...*options.InsertOneOptions) error {
	_, err := impl.coll().InsertOne(ctx, d)
	if err != nil {
		logger.Errorf(ctx, "SecretUserFollowBadgeMgDbImpl:Add error : %v", err)
		return err
	}

	return nil
}
