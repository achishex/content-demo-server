package query

import (
	"content_svr/db/mysqldb/model"
	"context"
	"gorm.io/gen"
	"gorm.io/gen/field"
)

type OperatorTab struct {
	operatorTab
}

func NewOperatorTab(p operatorTab) OperatorTab {
	return OperatorTab{
		operatorTab: p,
	}
}

func (p *operatorTab) ParseWhere(ctx context.Context, where map[string]interface{}) IOperatorTabDo {
	_do := p.WithContext(ctx)
	if len(where) == 0 {
		return _do
	}

	attrMap := map[string]interface{}{}
	for key, value := range where {
		switch key {
		default:
			if _, exist := p.fieldMap[key]; !exist {
				continue
			}
			attrMap[key] = value
		}
	}

	return _do.Where(field.Attrs(attrMap))
}

func (p *operatorTab) FindMap(ctx context.Context, limit, offset int, where map[string]interface{}) ([]*model.OperatorTab, error) {
	_db := p.ParseWhere(ctx, where)
	_db = _db.WithContext(ctx)
	if limit != 0 {
		_db = _db.Limit(limit)
	}
	if offset != 0 {
		_db = _db.Offset(offset)
	}

	return _db.Find()
}

func (p *operatorTab) FindOne(ctx context.Context, where map[string]interface{}) (*model.OperatorTab, error) {
	_db := p.ParseWhere(ctx, where)

	return _db.Take()
}

func (p *operatorTab) UpdateMap(ctx context.Context, where, update map[string]interface{}) (info gen.ResultInfo, err error) {
	_db := p.ParseWhere(ctx, where)

	return _db.Updates(update)
}
