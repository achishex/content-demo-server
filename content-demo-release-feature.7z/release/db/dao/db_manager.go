package dao

import (
	"content_svr/db/dao/cache"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type ManagerDB struct {
	// cache mysql
	*cache.PersonalBottleWork
	*cache.UserInfo
	// cache mongo
	*cache.MzRobotMng
	*cache.BackgroundImage
	*cache.SecretUserExtInfo
	*cache.SecretMemberInfo
	*cache.SecretBlackHouse

	// mysql
	*query.Query

	// mongo
	*query_mng.QueryMng
}

func NewDbManager(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *ManagerDB {
	m := &ManagerDB{
		Query:    mysql,
		QueryMng: mongo,

		PersonalBottleWork: cache.NewCachePersonalBottleWork(mysql, redisManage),
		UserInfo:           cache.NewCacheUserInfo(mysql, redisManage),

		MzRobotMng:        cache.NewCacheRobot(mongo, redisManage),
		BackgroundImage:   cache.NewCacheBackgroundImage(mongo, redisManage),
		SecretUserExtInfo: cache.NewCacheSecretUserExtInfo(mongo, redisManage),
		SecretMemberInfo:  cache.NewCacheSecretMemberInfo(mongo, redisManage),
		SecretBlackHouse:  cache.NewCacheSecretBlackHouse(mongo, redisManage),
	}

	return m
}
