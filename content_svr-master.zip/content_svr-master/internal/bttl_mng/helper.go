package bttl_mng

import (
	"content_svr/config"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/pub/errors"
	"content_svr/setting"
	"context"
	"fmt"
	"github.com/redis/go-redis/v9"
	"github.com/samber/lo"
	"strconv"
	"time"
)

func (m *BttlMng) SendReplyMsg(ctx context.Context, bttl *BttlEntity, replier int64, msg string) error {
	bttlMsg := fmt.Sprintf("【漂流瓶】%s", bttl.Content)
	if err := m.cm.SendNotifyMsg(ctx, bttl.UserID, replier, int32(pbconst.MessageTypeEnum_msg_type_txt), "", bttlMsg); err != nil {
		return err
	}

	return m.cm.SendNotifyMsg(ctx, replier, bttl.UserID, int32(pbconst.MessageTypeEnum_msg_type_txt), "", msg)
}
func (m *BttlMng) SetMutual(ctx context.Context, sender, replier int64) error {
	var f1, f2 *pbapi.SecretUserFollowMgDbModel
	var err error
	followDoc := m.dc.GetImpl().SecretUserFollowMgModel
	if f1, err = followDoc.GetByUserId(ctx, replier, sender); err != nil {
		return err
	}

	if f2, err = followDoc.GetByUserId(ctx, sender, replier); err != nil {
		return err
	}

	if f1 == nil {
		if _, err2 := m.ucm.Follow(ctx, replier, sender); err2 != nil {
			return err2
		}

	}
	if f2 == nil {
		if _, err2 := m.ucm.Follow(ctx, sender, replier); err2 != nil {
			return err2
		}
	}

	return nil
}

func (m *BttlMng) IncrExposure(ctx context.Context, bttlID int64) error {
	key := m.getExposureKey(bttlID)
	return m.rdb.Incr(ctx, key).Err()
}

func (m *BttlMng) GetExposureMap(ctx context.Context, bttlIDs []int64) (map[int64]int64, error) {
	if len(bttlIDs) == 0 {
		return map[int64]int64{}, nil
	}

	uniqIDs := lo.Uniq(bttlIDs)
	var cmds []*redis.StringCmd
	_, err := m.rdb.Pipelined(ctx, func(p redis.Pipeliner) error {
		for _, bttlID := range uniqIDs {
			key := m.getExposureKey(bttlID)
			cmds = append(cmds, p.Get(ctx, key))
		}
		return nil
	})
	if err != nil && !errors.Is(err, redis.Nil) {
		return nil, err
	}

	res := map[int64]int64{}
	for i, cmd := range cmds {
		if n, err2 := cmd.Int64(); err2 == nil {
			res[uniqIDs[i]] = n
		}
	}
	return res, nil
}

func (m *BttlMng) getExposureKey(bttlID int64) string {
	return fmt.Sprintf("platform:%v:bttl-lite:exposure:%v", config.ServerConfig.Env, bttlID)
}

func (m *BttlMng) AddUserPickSet(ctx context.Context, userID, bttlID int64) error {
	key := m.userPickSetKey(userID)
	_, err := m.rdb.SAdd(ctx, key, fmt.Sprint(bttlID)).Result()
	if err != nil {
		return err
	}

	// TODO configurable
	m.rdb.Expire(ctx, key, time.Hour*24*2)
	return nil
}

func (m *BttlMng) GetUserPickSet(ctx context.Context, userID int64) (map[int64]bool, error) {
	key := m.userPickSetKey(userID)
	bttlIDs, err := m.rdb.SMembers(ctx, key).Result()
	if err != nil {
		if errors.Is(err, redis.Nil) {
			return nil, nil
		}
		return nil, err
	}

	if len(bttlIDs) == 0 {
		return nil, nil
	}

	res := make(map[int64]bool)
	for _, s := range bttlIDs {
		if id, err2 := strconv.ParseInt(s, 10, 64); err2 == nil && id > 0 {
			res[id] = true
		}
	}
	return res, nil
}

func (m *BttlMng) GetBttlEx(ctx context.Context, userIDs []int64) (map[int64]BttlEx, error) {
	if len(userIDs) == 0 {
		return map[int64]BttlEx{}, nil
	}
	uimap, err := m.dc.MGetUserBasicInfo(ctx, userIDs, false)
	if err != nil {
		return nil, err
	}

	res := map[int64]BttlEx{}
	for _, ui := range uimap {
		res[ui.GetUserId()] = BttlEx{
			Nickname: ui.GetNickName(),
			FaceURL:  ui.GetPhoto(),
			Tags:     m.parseTags(ui),
		}
	}
	return res, nil
}

func (m *BttlMng) parseTags(userinfo *pbapi.UserinfoDbModel) []string {
	tags := []string{}
	if userinfo.GetBirth() != "" {
		if birthYear := lo.Substring(userinfo.GetBirth(), 0, 4); len(birthYear) == 4 {
			if birthYear >= "2000" {
				tags = append(tags, "00后")
			} else if birthYear >= "1990" {
				tags = append(tags, "90后")
			}
		}
	}

	return tags
}

func (m *BttlMng) GetLockMap(ctx context.Context, bttlIDs []int64) (map[int64]int64, error) {
	if len(bttlIDs) == 0 {
		return map[int64]int64{}, nil
	}

	var cmds []*redis.StringCmd
	_, err := m.rdb.Pipelined(ctx, func(p redis.Pipeliner) error {
		for _, bttlID := range bttlIDs {
			key := m.getBttlPickLockKey(bttlID)
			cmds = append(cmds, p.Get(ctx, key))
		}
		return nil
	})
	if err != nil && !errors.Is(err, redis.Nil) {
		return nil, err
	}

	res := map[int64]int64{}
	for i, c := range cmds {
		if uid, err2 := c.Int64(); err2 == nil && uid > 0 {
			res[bttlIDs[i]] = uid
		}
	}
	return res, nil
}

func (m *BttlMng) GetUserPickChance(ctx context.Context, userID int64) (int64, error) {
	u, err := m.dc.GetUserInfoLocal(ctx, userID, false)
	if err != nil {
		return 0, err
	}

	pc := setting.Maozhua.BttlConf.PickChance.Get()

	if m.ssc.IsVIP(u.MemberType) {
		return pc, nil
	}

	n, err := m.GetPickChance(ctx, userID)
	if err != nil {
		return 0, err
	}

	res := n
	if n < 0 {
		res = 0
	}
	return res, nil

}

func (m *BttlMng) SetDiscover(ctx context.Context, bttlIDs []int64) error {
	if len(bttlIDs) == 0 {
		return nil
	}
	uniqIDs := lo.Uniq(bttlIDs)

	exp := time.Minute * 6
	_, err := m.rdb.Pipelined(ctx, func(p redis.Pipeliner) error {
		for _, bttlID := range uniqIDs {
			key := m.discoverKey(bttlID)
			p.Set(ctx, key, "1", exp)
		}
		return nil
	})

	if err != nil && !errors.Is(err, redis.Nil) {
		return err
	}
	return nil
}

func (m *BttlMng) DiscoverMap(ctx context.Context, bttlIDs []int64) (map[int64]bool, error) {
	if len(bttlIDs) == 0 {
		return map[int64]bool{}, nil
	}

	uniqIDs := lo.Uniq(bttlIDs)
	var cmds []*redis.StringCmd
	_, err := m.rdb.Pipelined(ctx, func(p redis.Pipeliner) error {
		for _, bttlID := range uniqIDs {
			cmds = append(cmds, m.rdb.Get(ctx, m.discoverKey(bttlID)))
		}
		return nil
	})
	if err != nil && !errors.Is(err, redis.Nil) {
		return nil, err
	}

	res := map[int64]bool{}
	for i, cmd := range cmds {
		if cmd.Err() == nil {
			res[uniqIDs[i]] = true
		}
	}
	return res, nil
}

// replySetKey
//
//	返回key和是否缓存
func (m *BttlMng) replySetKey() (string, bool) {
	cacheInMin := setting.Maozhua.BttlConf.DiscoverCacheInMin.Get()
	if cacheInMin <= 0 {
		return "", false
	}
	timeWindow := 2 * cacheInMin
	unit := time.Now().Minute() / int(timeWindow)
	key := fmt.Sprintf("platform:%v:bttl-lite:replyed:%v", config.ServerConfig.Env, unit)
	return key, true
}
func (m *BttlMng) AddReplySet(ctx context.Context, bttlID int64) error {
	if key, ok := m.replySetKey(); ok {
		err := m.rdb.SAdd(ctx, key, fmt.Sprint(bttlID)).Err()
		if err != nil {
			return err
		}
		exp := time.Duration(setting.Maozhua.BttlConf.DiscoverCacheInMin.Get()) * time.Minute
		m.rdb.Expire(ctx, key, exp)
	}
	return nil
}

// GetReplySet 已回复
func (m *BttlMng) GetReplySet(ctx context.Context) (map[int64]bool, error) {
	key, ok := m.replySetKey()
	if !ok {
		return map[int64]bool{}, nil
	}

	bttlIDs, err := m.rdb.SMembers(ctx, key).Result()
	if err != nil {
		if errors.Is(err, redis.Nil) {
			return nil, nil
		}
		return nil, err
	}

	if len(bttlIDs) == 0 {
		return nil, nil
	}

	res := make(map[int64]bool)
	for _, s := range bttlIDs {
		if id, err2 := strconv.ParseInt(s, 10, 64); err2 == nil && id > 0 {
			res[id] = true
		}
	}
	return res, nil
}
func (m *BttlMng) ResetPickChance(ctx context.Context, userID int64) error {
	chance := setting.Maozhua.BttlConf.PickChance.Get()
	return m.rdb.Set(ctx, m.pickChanceKey(userID), fmt.Sprint(chance), time.Hour*24*3).Err()
}

func (m *BttlMng) GetPickChance(ctx context.Context, userID int64) (int64, error) {
	n, err := m.rdb.Get(ctx, m.pickChanceKey(userID)).Int64()
	if err != nil && !errors.Is(err, redis.Nil) {
		return 0, err
	}
	return n, nil
}

func (m *BttlMng) DecrPickChance(ctx context.Context, userID int64) (int64, error) {
	return m.rdb.Decr(ctx, m.pickChanceKey(userID)).Result()
}

// userPickSetKey 用户捡瓶记录
func (m *BttlMng) userPickSetKey(userID int64) string {
	return fmt.Sprintf("platform:%v:bttl-lite:user-pick:%v", config.ServerConfig.Env, userID)
}

func (m *BttlMng) pickChanceKey(userID int64) string {
	return fmt.Sprintf("platform:%v:bttl-lite:pick-chance:%v", config.ServerConfig.Env, userID)
}
func (m *BttlMng) discoverKey(bttlID int64) string {
	return fmt.Sprintf("platform:%v:bttl-lite:discover:%v", config.ServerConfig.Env, bttlID)
}
func (m *BttlMng) Entity2LiteDTO(item BttlEntity) BttlLiteDTO {
	return BttlLiteDTO{
		BttlID:     item.BttlID,
		UserID:     item.UserID,
		Gender:     item.Gender,
		Content:    item.Content,
		City:       item.City,
		CreateTime: item.CreateTime.UnixMilli(),
	}
}

func (m *BttlMng) Entity2DTO(item BttlEntity) BttlDTO {
	replyTime := int64(0)
	if item.ReplyTime != nil {
		replyTime = item.ReplyTime.UnixMilli()
	}
	return BttlDTO{
		BttlID:     item.BttlID,
		UserID:     item.UserID,
		Gender:     item.Gender,
		Content:    item.Content,
		City:       item.City,
		Replier:    item.Replier,
		CreateTime: item.CreateTime.UnixMilli(),
		ReplyTime:  replyTime,
	}
}

func (m *BttlMng) IncrCreateCount(ctx context.Context, userID int64) error {
	key := m.createDailyKey(userID)
	err := m.rdb.Incr(ctx, key).Err()
	if err != nil {
		return err
	}
	m.rdb.Expire(ctx, key, time.Hour*24)
	return nil
}

func (m *BttlMng) GetCreateCount(ctx context.Context, userID int64) (int64, error) {
	key := m.createDailyKey(userID)
	n, err := m.rdb.Get(ctx, key).Int64()
	if err != nil && !errors.Is(err, redis.Nil) {
		return 0, err
	}
	return n, nil
}
func (m *BttlMng) createDailyKey(userID int64) string {
	date := time.Now().Local().Format("20060102")
	return fmt.Sprintf("platform:%v:bttl-lite:create-daily%v:%v", config.ServerConfig.Env, date, userID)
}

func (m *BttlMng) genJumpURL(targetUserID int64) string {
	return fmt.Sprintf("maozhua://card?type=107&work_id=-1&fUId=%v", targetUserID)
}

func (m *BttlMng) getBttlPickLockKey(bttlID int64) string {
	return fmt.Sprintf("platform:%v:bttl-lite:pick-lock:%v", config.ServerConfig.Env, bttlID)
}
