package db

type MongoConfig struct {
	URI    string
	DBName string
}

func (c MongoConfig) GetURL() string {
	return c.URI
}

func (c MongoConfig) GetDBName() string {
	return c.DBName
}
