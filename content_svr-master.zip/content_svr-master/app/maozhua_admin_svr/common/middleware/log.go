package middleware

import (
	"bytes"
	"fmt"
	"github.com/zeromicro/go-zero/core/logc"
	"github.com/zeromicro/go-zero/core/timex"
	"github.com/zeromicro/go-zero/core/utils"
	"github.com/zeromicro/go-zero/rest"
	"io"
	"net/http"
	"regexp"
)

type LogAccessMiddleware struct {
	conf rest.RestConf
}

func NewLogAccessMiddleware(c rest.RestConf) *LogAccessMiddleware {
	return &LogAccessMiddleware{conf: c}
}

func (m *LogAccessMiddleware) Handle(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		timer := utils.NewElapsedTimer()
		lw := newWrite(w)
		var request, response string
		if m.conf.Verbose {
			request = dumpRequest(r)
		}

		next(lw, r)
		if r.URL.String() != "/" {
			if m.conf.Verbose {
				response = lw.responseBody.String()
			}
			message := fmt.Sprintf("[HTTP] %s - %d - %s - %s\n",
				r.Method, lw.code, r.URL.String(), timex.ReprOfDuration(timer.Duration()))
			//traceID := trace.TraceIDFromContext(r.Context())
			//logger.Access(r.Context(), fmt.Sprintf("message:%s, request:%s, response:%s trace:%v", message, request, response, traceID))
			logc.Infow(
				r.Context(),
				message,
				logc.LogField{Key: "request", Value: request},
				logc.LogField{Key: "response", Value: response},
			)
		}
	}
}

var regSpace, _ = regexp.Compile(`\s`)

func dumpRequest(r *http.Request) string {
	reqBuf, err := io.ReadAll(r.Body)
	r.Body = io.NopCloser(bytes.NewBuffer(reqBuf))
	//reqContent, err := httputil.DumpRequest(r, true)
	if err != nil {
		return err.Error()
	}

	content := regSpace.ReplaceAll(reqBuf, []byte{})
	return string(content)
}

type writer struct {
	write        http.ResponseWriter
	code         int
	responseBody *bytes.Buffer
}

func newWrite(write http.ResponseWriter) *writer {
	return &writer{
		write:        write,
		responseBody: bytes.NewBuffer(nil),
	}
}

func (w *writer) Header() http.Header {
	return w.write.Header()
}

func (w *writer) Write(bytes []byte) (int, error) {
	w.responseBody.Write(bytes)
	return w.write.Write(bytes)
}

func (w *writer) WriteHeader(statusCode int) {
	w.code = statusCode
	w.write.WriteHeader(statusCode)
}
