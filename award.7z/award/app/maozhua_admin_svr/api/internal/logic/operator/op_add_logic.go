package operator

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	_const "content_svr/db/m_const"
	"content_svr/db/mysqldb/model"
	"context"
	"github.com/jinzhu/copier"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type OpAddLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewOpAddLogic(ctx context.Context, svcCtx *svc.ServiceContext) *OpAddLogic {
	return &OpAddLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *OpAddLogic) OpAdd(req *types.OpAddReq) (resp *types.OpAddResp, err error) {
	_db := l.svcCtx.ManagerDB.OperatorTab
	result, err := _db.WithContext(l.ctx).Where(_db.Email.Eq(req.CtxEmail)).First()
	if err != nil {
		return nil, err
	}

	if result.Status == _const.AccountStatusClose {
		return nil, xerr.OperatorAccountError
	}

	if result.OpType == _const.AccountTypeNormal {
		return nil, xerr.OperatorAccountPermitError
	}

	data := &model.OperatorTab{}
	err = copier.Copy(data, req)
	if err != nil {
		return nil, err
	}

	data.Status = _const.AccountStatusOpen
	now := time.Now()
	data.Ctime = now.UnixMilli()
	data.Mtime = now.UnixMilli()
	if err := _db.WithContext(l.ctx).Create(data); err != nil {
		return nil, err
	}

	return
}
