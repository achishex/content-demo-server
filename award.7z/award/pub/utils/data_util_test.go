package utils

import "testing"

func TestMD5To32(t *testing.T) {
	t.Log(MD5To32(""))
}
