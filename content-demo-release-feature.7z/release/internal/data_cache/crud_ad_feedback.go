package data_cache

import (
	"content_svr/pub/logger"
	"context"
	"time"
)

func (p *DataCacheMng) SetRedisAdFeedback(ctx context.Context, channel, machineId string, value int) error {
	if channel == "" || machineId == "" {
		return nil
	}
	rdsKey := getRdsKeyAdFeedback(channel, machineId)

	if err := p.RedisCli.Set(ctx, rdsKey, value, time.Hour*48).Err(); err != nil {
		return err
	}

	return nil
}

func (p *DataCacheMng) GetRedisAdFeedback(ctx context.Context, channel, machineId string) int {
	rdsKey := getRdsKeyAdFeedback(channel, machineId)

	value, err := p.RedisCli.Get(ctx, rdsKey).Int()
	if err != nil {
		logger.Errorf(ctx, "read redis key error rdsKey: %s", rdsKey)
		return 0
	}

	return value
}
