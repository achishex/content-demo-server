package once

import (
	"content_svr/config"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

/*
修复 secretUserActivityDaily 表中的 is_new 字段
*/
func (c *command) resetUserActivityDaily() {
	defer fmt.Println("resetUserActivityDaily over")

	db := c.mngDB.Database(config.ServerConfig.MongodbConfig.DBName)
	secretUserActivityDailyCollection := db.Collection("secretUserActivityDaily")
	ctx := context.Background()

	filter := bson.D{
		{"day", 20231017},
	}
	cur, err := secretUserActivityDailyCollection.Find(ctx, filter)
	if err != nil {
		panic(err)
	}

	for cur.Next(ctx) {
		var daily *pbmgdb.SecretUserActivityDaily
		err := cur.Decode(&daily)
		if err != nil {
			logger.Error(ctx, "Decode error:", err)
			continue
		}

		user := &pbapi.UserinfoDbModel{}
		_ = c.mysqlDB.Table("user_info").Where("user_id = ?", daily.GetUserId()).Find(user).Error
		isNew := 0
		if user != nil && isNewUser(user.GetCreateTime()) {
			isNew = 1
		}

		filter := bson.D{
			{"day", daily.GetDay()},
			{"user_id", daily.GetUserId()},
			{"app_type", daily.GetAppType()},
			{"channel", daily.GetChannel()},
		}
		update := bson.D{
			{"$set", bson.D{
				{"is_new", isNew},
			}},
		}

		if _, err := secretUserActivityDailyCollection.UpdateOne(ctx, filter, update); err != nil {
			logger.Error(ctx, "update secretUserActivityDailyCollection is_new, error", err)
		}
	}

}

// 是否是今天新创建的用户
func isNewUser(createTimeStr string) bool {
	timeLayout := "2006-01-02 15:04:05"  //模版
	loc, _ := time.LoadLocation("Local") //获取当前时区
	//使用模版将需要判断的时间在对应时区转化成time.time类型
	theTime, _ := time.ParseInLocation(timeLayout, createTimeStr, loc)
	//将需要判断的时间格式话成str类型
	dataTimeStr := theTime.Format("2006-01-02")

	//当前时间（当年当月当天）
	//nowstr := time.Now().Format("2006-01-02")
	//判断所需要的时间是当天
	if dataTimeStr == "2023-10-17" {
		return true
	} else {
		return false
	}
}
