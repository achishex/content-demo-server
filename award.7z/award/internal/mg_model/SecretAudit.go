package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretAuditMgModel interface {
	FindOne(ctx context.Context, filter any) (*pbmgdb.SecretAuditMgDbModel, error)
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretAuditMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.SecretAuditMgDbModel, options ...*options.InsertOneOptions) error
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
}

type SecretAudit struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretAuditMgModelImpl(db *mongo.Database) ISecretAuditMgModel {
	return &SecretAudit{
		MgDB:  db,
		Table: "secretAudit",
	}
}

func (g *SecretAudit) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *SecretAudit) FindOne(ctx context.Context, filter any) (*pbmgdb.SecretAuditMgDbModel, error) {
	var v *pbmgdb.SecretAuditMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretAudit FindOne failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *SecretAudit) Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretAuditMgDbModel, error) {
	find, err := g.coll().Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	retItems := make([]*pbmgdb.SecretAuditMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.SecretAuditMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretAudit failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (g *SecretAudit) Create(ctx context.Context, data *pbmgdb.SecretAuditMgDbModel, options ...*options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data, options...)

	if err != nil {
		logger.Errorf(ctx, "SecretAudit:Create error : %v", err)
		return err
	}

	return nil
}

func (g *SecretAudit) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "SecretAudit:updateOne error: %v", err)
		return err
	}

	return nil
}
