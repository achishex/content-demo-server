package data_cache

import (
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"strconv"
	"time"
)

// GetUserInBlackFlag 用户是否在小黑屋
func (p *DataCacheMng) GetUserInBlackFlag(ctx context.Context, userId int64) bool {
	redisKey := getUserBlackHouseKey()
	outTimeMs, err := p.RedisCli.HGet(ctx, redisKey, strconv.Itoa(int(userId))).Int64() //返回在range的idx位置
	if err == redis.Nil {
		return false
	}
	logger.Infof(ctx, "GetUserInBlackFlag outTimeMs=%v", outTimeMs)
	if time.Now().UnixNano()/1e6 > outTimeMs {
		logger.Infof(ctx, "black time out of date. GetUserInBlackFlag outTimeMs=%v", outTimeMs)
		return false // 已离开小黑屋
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("GetUserCoordinate failed, redisKey=%v", redisKey), err)
		return false
	}
	return true
}

// GetUserBlackHouseOutTime 返回用户在小黑屋到期时间 例如 1690130830987  (对应日期 2023-07-24 00:47:10)
func (p *DataCacheMng) GetUserBlackHouseOutTime(ctx context.Context, userId int64) (int64, error) {
	redisKey := getUserBlackHouseKey()
	outTimeMs, err := p.RedisCli.HGet(ctx, redisKey, strconv.Itoa(int(userId))).Int64()
	if err == redis.Nil {
		return 0, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("GetUserCoordinate failed, redisKey=%v", redisKey), err)
		return 0, err
	}
	return outTimeMs, nil
}
