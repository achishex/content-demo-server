package setting

import (
	"context"
	"fmt"
	"reflect"
	"strconv"
)

type emptyType struct{}

const emptyTypeValue = "_emptyType"

// 根据目标字段类型进行值转换
func convertToFieldType(value string, dstValueType reflect.StructField) (reflect.Value, error) {
	if value == emptyTypeValue {
		return reflect.Zero(reflect.TypeOf(&emptyType{})), nil
	}

	dstValueTypeKind := dstValueType.Type.Kind()
	switch dstValueTypeKind {
	case reflect.Int:
		intValue, err := strconv.Atoi(value)
		if err != nil {
			return reflect.ValueOf(nil), fmt.Errorf("failed to convert value to int")
		}

		return reflect.ValueOf(intValue), nil
	case reflect.Int32:
		intValue, err := strconv.Atoi(value)
		if err != nil {
			return reflect.ValueOf(nil), fmt.Errorf("failed to convert value to int")
		}

		return reflect.ValueOf(int32(intValue)), nil
	case reflect.Int64:
		intValue, err := strconv.Atoi(value)
		if err != nil {
			return reflect.ValueOf(nil), fmt.Errorf("failed to convert value to int")
		}

		return reflect.ValueOf(int64(intValue)), nil
	case reflect.Uint64:
		uintValue, err := strconv.ParseUint(value, 10, 64)
		if err != nil {
			return reflect.Value{}, fmt.Errorf("failed to convert value to uint")
		}

		return reflect.ValueOf(uintValue), nil
	case reflect.Uint32:
		uintValue, err := strconv.ParseUint(value, 10, 64)
		if err != nil {
			return reflect.Value{}, fmt.Errorf("failed to convert value to uint")
		}

		return reflect.ValueOf(uint32(uintValue)), nil
	case reflect.Uint:
		uintValue, err := strconv.ParseUint(value, 10, 64)
		if err != nil {
			return reflect.Value{}, fmt.Errorf("failed to convert value to uint")
		}

		return reflect.ValueOf(uint(uintValue)), nil
	case reflect.Float64:
		float64Value, err := strconv.ParseFloat(value, 64)
		if err != nil {
			return reflect.Value{}, fmt.Errorf("failed to convert value to uint")
		}

		return reflect.ValueOf(float64Value), nil
	case reflect.String:
		return reflect.ValueOf(value), nil
	default:
		// 对于其他数据类型，可以根据需要进行相应的处理和转换
		return reflect.Zero(dstValueType.Type), nil
	}
}

type fieldInterface interface {
	GetField() string
	GetValue() interface{}
}

type MaozhuaSettingRecord struct {
	Field        string      `json:"field,omitempty"`       // redis 中的field
	Value        interface{} `json:"value,omitempty"`       // 实时值
	DefaultValue interface{} `json:"default_value"`         // 默认值
	Description  string      `json:"description,omitempty"` // 描述
	Category     string      `json:"category,omitempty"`
}

func (r *MaozhuaSettingRecord) TableName() string {
	return "maozhua_setting"
}

func (r *MaozhuaSettingRecord) GetField() string {
	return r.Field
}

// GetValue 获取值
func (r *MaozhuaSettingRecord) GetValue() interface{} {
	if r.Value == nil {
		return r.DefaultValue
	}
	return r.Value
}

// SetValue 更新实时值
func (r *MaozhuaSettingRecord) SetValue(ctx context.Context, value interface{}) {
	r.Value = value
}

type fieldInt64 struct {
	MaozhuaSettingRecord
	DefaultValue int64 `json:"default_value"` // 默认值
}

func (v fieldInt64) Get() int64 {
	value, ok := v.Value.(int64)
	if !ok {
		return v.DefaultValue
	}

	return value
}

type fieldInt32 struct {
	MaozhuaSettingRecord
	DefaultValue int32 `json:"default_value"` // 默认值
}

func (v fieldInt32) Get() int32 {
	value, ok := v.Value.(int32)
	if !ok {
		return v.DefaultValue
	}

	return value
}

type fieldInt struct {
	MaozhuaSettingRecord
	DefaultValue int `json:"default_value"` // 默认值
}

func (v fieldInt) Get() int {
	value, ok := v.Value.(int)
	if !ok {
		return v.DefaultValue
	}

	return value
}

type fieldUint struct {
	MaozhuaSettingRecord
	DefaultValue uint `json:"default_value"` // 默认值
}

func (v fieldUint) Get() uint {
	value, ok := v.Value.(uint)
	if !ok {
		return v.DefaultValue
	}

	return value
}

type fieldUint32 struct {
	MaozhuaSettingRecord
	DefaultValue uint32 `json:"default_value"` // 默认值
}

func (v fieldUint32) Get() uint32 {
	value, ok := v.Value.(uint32)
	if !ok {
		return v.DefaultValue
	}

	return value
}

type fieldUint64 struct {
	MaozhuaSettingRecord
	DefaultValue uint64 `json:"default_value"` // 默认值
}

func (v fieldUint64) Get() uint64 {
	value, ok := v.Value.(uint64)
	if !ok {
		return v.DefaultValue
	}

	return value
}

type fieldString struct {
	MaozhuaSettingRecord
	DefaultValue string `json:"default_value"` // 默认值
}

func (v fieldString) Get() string {
	value, ok := v.Value.(string)
	if !ok {
		return v.DefaultValue
	}

	return value
}

type fieldFloat64 struct {
	MaozhuaSettingRecord
	DefaultValue float64 `json:"default_value"` // 默认值
}

func (v fieldFloat64) Get() float64 {
	value, ok := v.Value.(float64)
	if !ok {
		return v.DefaultValue
	}

	return value
}
