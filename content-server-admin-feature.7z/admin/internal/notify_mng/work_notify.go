package notify_mng

import (
	"content_svr/internal/data_cache"
	"content_svr/internal/kafka_proxy"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
)

// WorkNotifyComp
// 关注好友推送
// https://lanhuapp.com/web/#/item/project/product?tid=a67ec24b-515f-4501-82e0-26e8df817c6c&pid=f872a895-aaed-499b-bf1e-cff66f3e621e&image_id=e0b5cb8b-b0af-4d9e-9414-3bd0ba9b88ce&docId=e0b5cb8b-b0af-4d9e-9414-3bd0ba9b88ce&docType=axure&versionId=813ca49b-ba0b-4ae1-a0d8-ae0c2bf12445&pageId=d2778b39acaa4b888b8e7e85d7035279&parentId=7dee9d97-2408-4336-b332-87f6a614ff35
//
// 2023-11-21
// 推送条件：
// 1.普通关注的人分享动态后，该动态评论人数达到5人时
// 2.星标好友当天分享首条动态时，立即推送，在6小时内，若我的星标好友再次分享动态则不再进行推送，若6小时后有新的动态产生，进行推送
// 跳转：跳转至该条动态，若该条动态被删除或仅自己可见，则跳转至首页并toast提示：动态已消失，为您推荐了其他动态
type WorkNotifyComp struct {
	k  kafka_proxy.IKafkaProxy
	dc data_cache.IDataCacheMng
}

func NewWorkNotifyComp(
	k kafka_proxy.IKafkaProxy,
	dc data_cache.IDataCacheMng,
) *WorkNotifyComp {
	return &WorkNotifyComp{
		k:  k,
		dc: dc,
	}
}

func (wnc *WorkNotifyComp) PushWorkMsgByWorkID(ctx context.Context, userID, workID int64) error {
	if userID <= 0 || workID <= 0 {
		return nil
	}

	work, err := wnc.dc.GetWorkInfoLocal(ctx, workID, false)
	if err != nil {
		logger.Errorf(ctx, "GetWorkInfoLocal fail, err: %v", err)
		return err
	}

	return wnc.PushWorkMsg(ctx, userID, work.WorkInfoDbModel)
}

func (wnc *WorkNotifyComp) PushWorkMsg(ctx context.Context, userID int64, work *pbapi.PersonalBottleWorksDbModel) error {
	if userID <= 0 || work == nil || work.GetId() <= 0 || work.GetUserId() <= 0 {
		return nil
	}

	sender, err := wnc.dc.GetUserBasicInfo(ctx, work.GetUserId(), false)
	if err != nil {
		logger.Errorf(ctx, "GetUserBasicInfo fail, userID: %v err: %v", work.GetUserId(), err)
		return err
	}

	jumpUrl := wnc.GetJumpUrl(work)
	title, content := wnc.GetMsgTitleAndContent(work, sender)
	return wnc.k.TsnPushJumpMessage(ctx, userID, &title, nil, &content, nil, jumpUrl)
}

func (wnc *WorkNotifyComp) GetMsgTitleAndContent(w *pbapi.PersonalBottleWorksDbModel, u *pbapi.UserinfoDbModel) (title, content string) {
	title = "你的关注"
	// 1 图片 2 视频 3 文字
	switch w.GetType() {
	case 1:
		content = fmt.Sprintf("@%s: [图片]", u.GetNickName())
	case 2:
		content = fmt.Sprintf("@%s: [视频]", u.GetNickName())
	case 3:
		content = fmt.Sprintf("@%s: %s", u.GetNickName(), w.GetTitle())
	default:
		content = fmt.Sprintf("@%s: 发布了新动态～", u.GetNickName())
	}
	return
}
func (wnc *WorkNotifyComp) GetJumpUrl(w *pbapi.PersonalBottleWorksDbModel) string {
	return fmt.Sprintf("maozhua://card?type=%v&work_id=%v", 2, w.GetId())
}
