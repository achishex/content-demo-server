package panichelper

import (
	"content_svr/pub/logger"
	"context"
	"fmt"
	"runtime"
	"strings"
)

func PanicRecover(ctx context.Context) {
	if e := recover(); e != nil {
		buf := &strings.Builder{}
		pc := make([]uintptr, 10)
		n := runtime.Callers(3, pc)
		frames := runtime.CallersFrames(pc[:n])

		var frame runtime.Frame
		more := n > 0
		for more {
			frame, more = frames.Next()
			buf.Write([]byte(fmt.Sprintf("  => %s:%d %s\n", frame.File, frame.Line, frame.Function)))
		}

		logger.Errorf(ctx, "panic recover, err: %v, stack: %s", e, buf.String())
	}
}
