package taskq

import (
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"content_svr/pub/utils/panichelper"
	"context"
	"encoding/json"
	"fmt"
	"github.com/go-redis/redis/v8"
	"github.com/google/uuid"
	"github.com/samber/lo"
	"strconv"
	"sync"
	"time"
)

func NewTaskQ(
	cli *redis.Client,
) *TaskQ {
	ctx, stop := context.WithCancel(context.Background())
	return &TaskQ{
		cli:           cli,
		ctx:           ctx,
		fetchLimit:    16,
		fetchInterval: 500 * time.Millisecond,
		randDur:       500 * time.Millisecond,
		failWait:      5 * time.Second,
		emptyWait:     3 * time.Second,
		lockExp:       100 * time.Millisecond,
		hm:            map[string]TaskHandler{},
		l:             sync.Mutex{},
		stop:          stop,
		wg:            sync.WaitGroup{},
	}
}

type TaskQ struct {
	cli           *redis.Client
	ctx           context.Context //控制后台进程
	fetchLimit    int64
	fetchInterval time.Duration
	randDur       time.Duration //随机休眠
	failWait      time.Duration //失败休眠时间
	emptyWait     time.Duration //无任务休眠时间
	lockExp       time.Duration
	hm            map[string]TaskHandler //任务处理回调
	l             sync.Mutex

	stop func()
	wg   sync.WaitGroup
}

func (tq *TaskQ) Register(taskType string, handler TaskHandler) {
	logger.Infof(context.Background(), "Register task handler, type: %v", taskType)
	tq.l.Lock()
	defer tq.l.Unlock()
	tq.hm[taskType] = handler
}

type TaskMsg struct {
	UserID   string `json:"userID"`   //必传
	TaskType string `json:"taskType"` //必传
	TaskID   string `json:"taskID"`   //可选
	RunAt    int64  `json:"runAt"`    //不传
	Ex       string `json:"ex"`       //可选
}
type TaskHandler func(ctx context.Context, msg *TaskMsg) error

func (h TaskHandler) ExecSafely(ctx context.Context, msg *TaskMsg) error {
	defer panichelper.PanicRecover(ctx)

	return h(ctx, msg)
}

func (tq *TaskQ) taskKey(taskID string) string {
	return fmt.Sprintf("tq:task:%v", taskID)
}

func (tq *TaskQ) lockKey(taskID string) string {
	return fmt.Sprintf("tq:lock:%v", taskID)
}
func (tq *TaskQ) zlistKey() string {
	return fmt.Sprintf("tq:zlist:0")
}

func (tq *TaskQ) Submit(ctx context.Context, task *TaskMsg, delay time.Duration) (taskID string, err error) {
	if task.UserID == "" || task.TaskType == "" {
		return "", fmt.Errorf("emtpy task.UserID or task.TaskType")
	}

	taskID = task.TaskID
	if taskID == "" {
		taskID = uuid.New().String()
	}
	runTime := time.Now().Add(delay).Unix()
	task.TaskID = taskID
	task.RunAt = runTime

	taskBody := utils.JsonStr(task)
	hkey := tq.taskKey(taskID)
	zkey := tq.zlistKey()

	_, err = tq.cli.Pipelined(ctx, func(p redis.Pipeliner) error {
		p.Set(ctx, hkey, taskBody, delay+30*time.Second)

		p.ZAdd(ctx, zkey, &redis.Z{Member: taskID, Score: float64(runTime)})
		return nil
	})
	if err != nil {
		logger.Errorf(ctx, "Submit task fail, err: %v", err)

		_, _ = tq.cli.Pipelined(ctx, func(p redis.Pipeliner) error {
			p.ZRem(ctx, zkey, taskID)
			p.Del(ctx, hkey)
			return nil
		})
		return "", err
	}

	return taskID, nil
}

func (tq *TaskQ) CancelTask(ctx context.Context, taskID string) error {
	_, err := tq.cli.Pipelined(ctx, func(p redis.Pipeliner) error {
		p.ZRem(ctx, tq.zlistKey(), taskID)
		p.Del(ctx, tq.taskKey(taskID))
		return nil
	})
	return err
}

func (tq *TaskQ) FetchTask(ctx context.Context, end, limit int64) ([]*TaskMsg, error) {
	zs, err := tq.cli.ZRangeByScoreWithScores(ctx, tq.zlistKey(), &redis.ZRangeBy{
		Min:    "-inf",
		Max:    strconv.FormatInt(end, 10),
		Offset: 0,
		Count:  limit,
	}).Result()
	if err != nil {
		return nil, err
	}

	if len(zs) == 0 {
		return nil, nil
	}

	cmds := make([]*redis.StringCmd, 0, len(zs))
	_, err = tq.cli.Pipelined(ctx, func(p redis.Pipeliner) error {
		for _, z := range zs {
			taskID := z.Member.(string)
			cmds = append(cmds, tq.cli.Get(ctx, tq.taskKey(taskID)))
		}
		return nil
	})

	if err != nil && !errors.Is(err, redis.Nil) {
		return nil, err
	}

	return lo.Filter(lo.Map(cmds, func(item *redis.StringCmd, _ int) *TaskMsg {
		return tq.parseTaskMsg(item)
	}), func(item *TaskMsg, _ int) bool {
		return item != nil
	}), nil
}

func (tq *TaskQ) lockTask(ctx context.Context, taskID string) (bool, error) {
	return tq.cli.SetNX(ctx, tq.lockKey(taskID), "1", tq.lockExp).Result()
}

func (tq *TaskQ) execTask(ctx context.Context, msg *TaskMsg) error {
	h, ok := tq.hm[msg.TaskType]
	if !ok {
		logger.Warnf(tq.ctx, "unknown taskType: %v", msg.TaskType)
		return nil
	}

	lock, err := tq.lockTask(ctx, msg.TaskID)
	if err != nil {
		return err
	}
	if !lock {
		return nil
	}

	defer func() {
		tq.CancelTask(ctx, msg.TaskID)
	}()
	return h.ExecSafely(ctx, msg)
}
func (tq *TaskQ) Run() {
	for {
		select {
		case <-time.After(tq.fetchInterval + tq.randD()):
			taskMsgs, err := tq.FetchTask(tq.ctx, time.Now().Unix(), tq.fetchLimit)
			if err != nil {
				logger.Errorf(tq.ctx, "FetchTask fail, err: %v", err)
				time.Sleep(tq.failWait)
				continue
			}
			if len(taskMsgs) == 0 {
				time.Sleep(tq.emptyWait)
				continue
			}

			for _, msg := range taskMsgs {
				msgCopy := *msg
				// TODO
				go func() {
					if err2 := tq.execTask(tq.ctx, &msgCopy); err2 != nil {
						logger.Errorf(tq.ctx, "execTask fail, err: %v", err2)
					}
				}()
			}

		case <-tq.ctx.Done():
			logger.Infof(tq.ctx, "stop taskq")
		}
	}
}

func (tq *TaskQ) randD() time.Duration {
	return time.Duration(utils.DefaultRand.Float64() * float64(tq.randDur))
}

func (tq *TaskQ) Stop() {
	tq.stop()
	tq.wg.Wait()
}

func (tq *TaskQ) parseTaskMsg(c *redis.StringCmd) *TaskMsg {
	s, err := c.Result()
	if err != nil {
		return nil
	}

	m := &TaskMsg{}
	_ = json.Unmarshal([]byte(s), m)
	return m
}
