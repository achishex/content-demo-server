package once

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/snow_flake"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"log"
)

func moveUserInfoExtCard(mngDB *mongo.Client) {
	// 聚合查询出 sportActivityCollection 表中 activity_status 为 2 所有合计信息
	// 更新所有 PersonalUserCollection 表

	db := mngDB.Database(config.ServerConfig.MongodbConfig.DBName)
	secretUserExtInfoCollection := db.Collection("secretUserExtInfo")
	secretUserIdentificationCardCollection := db.Collection("secretUserIdentificationCard")

	ctx := context.Background()
	filter := bson.D{
		bson.E{Key: "cardId", Value: bson.D{{"$exists", true}}},
	}
	cur, err := secretUserExtInfoCollection.Find(ctx, filter)
	if err != nil {
		panic(err)
	}

	for cur.Next(ctx) {
		var secretUserExtInfo map[string]interface{}
		err := cur.Decode(&secretUserExtInfo)
		if err != nil {
			log.Println(err)
			continue
		}

		if secretUserExtInfo["cardId"] == "" {
			continue
		}

		_, err = secretUserIdentificationCardCollection.InsertOne(ctx, &pbmgdb.SecretUserIdentificationCard{
			Id:       snow_flake.GetSnowflakeID(),
			UserId:   secretUserExtInfo["_id"].(int64),
			CardId:   secretUserExtInfo["cardId"].(string),
			CardName: secretUserExtInfo["cardName"].(string),
			Status:   const_busi.UserCardStatus,
		})
		if err != nil {
			log.Println("InsertOne: ", err)
		}

	}
}
