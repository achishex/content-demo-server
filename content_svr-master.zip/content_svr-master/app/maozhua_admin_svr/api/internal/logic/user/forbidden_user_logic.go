package user

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mysqldb/model"
	"context"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type ForbiddenUserLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewForbiddenUserLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ForbiddenUserLogic {
	return &ForbiddenUserLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ForbiddenUserLogic) ForbiddenUser(req *types.ForBiddenReq) (resp *types.ForBiddenResp, err error) {
	userInfo, err := l.svcCtx.WriteDB.UserInfo.FindByUserId(l.ctx, req.UserId)
	if err != nil {
		return nil, err
	}
	var enable int32 = 0
	if userInfo.Enabled == model.UserForbidden && req.Forbidden == model.UserOpen {
		enable = model.UserOpen
	} else if userInfo.Enabled == model.UserOpen && req.Forbidden == model.UserForbidden {
		enable = model.UserForbidden

		err := l.svcCtx.WriteDB.PersonalBottleWorks.UpdateShowScopeSelf(l.ctx, req.UserId)
		if err != nil {
			return nil, err
		}
	}

	if enable == 0 {
		return nil, xerr.UserForbiddenError
	}

	filter := map[string]interface{}{
		"user_id": req.UserId,
	}
	data := map[string]interface{}{
		"enabled": enable,
	}
	_, err = l.svcCtx.WriteDB.UserInfo.UpdateMap(l.ctx, filter, data)
	if err != nil {
		return nil, err
	}

	err = l.svcCtx.WriteDB.UserInfo.ClearUserInfoRedisCache(l.ctx, req.UserId)
	err = l.svcCtx.WriteDB.UserInfo.ClearUserTokenRedisCache(l.ctx, req.UserId)

	return
}
