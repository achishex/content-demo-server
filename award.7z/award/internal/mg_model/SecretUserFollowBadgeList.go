package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretUserFollowBadgeListMgDbModel interface {
	Get(ctx context.Context, cond any) (*pbmgdb.SecretUserFollowBadgeListMgDbModel, error)
	Find(ctx context.Context, cond any) ([]*pbmgdb.SecretUserFollowBadgeListMgDbModel, error)
	AddOne(ctx context.Context, data *pbmgdb.SecretUserFollowBadgeListMgDbModel, opts ...*options.InsertOneOptions) error
	UpdateMany(ctx context.Context, cond, update map[string]any) error
	DeleteOne(ctx context.Context, cond any) error
	DeleteMany(ctx context.Context, cond any) error
	Exists(ctx context.Context, filter any) bool
}

type SecretUserFollowBadgeListMgDbImpl struct {
	MgDB *mongo.Database
}

func NewSecretUserFollowBadgeListMgModelImpl(db *mongo.Database) ISecretUserFollowBadgeListMgDbModel {
	return &SecretUserFollowBadgeListMgDbImpl{MgDB: db}
}

func (impl *SecretUserFollowBadgeListMgDbImpl) table() string {
	return "secretUserFollowBadgeList"
}

func (impl *SecretUserFollowBadgeListMgDbImpl) coll() *mongo.Collection {
	return impl.MgDB.Collection(impl.table())
}

func (impl *SecretUserFollowBadgeListMgDbImpl) Get(ctx context.Context, filter any) (*pbmgdb.SecretUserFollowBadgeListMgDbModel, error) {
	v := &pbmgdb.SecretUserFollowBadgeListMgDbModel{}
	err := impl.coll().FindOne(ctx, filter).Decode(v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserFollowBadgeListMgDbImpl GetByUserId failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (impl *SecretUserFollowBadgeListMgDbImpl) Find(ctx context.Context, filter any) ([]*pbmgdb.SecretUserFollowBadgeListMgDbModel, error) {
	var list []*pbmgdb.SecretUserFollowBadgeListMgDbModel

	cursor, err := impl.coll().Find(ctx, filter)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserFollowBadgeListMgDbImpl GetByUserId failed. filter=%v", filter), err)
		return nil, err
	}

	for cursor.Next(ctx) {
		v := &pbmgdb.SecretUserFollowBadgeListMgDbModel{}
		if err = cursor.Decode(v); err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretUserFollowBadgeListMgDbModel failed.filter=%v", filter), err)
			return nil, err
		}
		list = append(list, v)
	}

	if len(list) == 0 {
		return nil, nil
	}
	if len(list) > 1 {
		logger.Error(ctx, fmt.Sprintf("get SecretUserFollowBadgeListMgDbModel failed.filter=%v", filter), err)
	}
	return list, err
}

func (impl *SecretUserFollowBadgeListMgDbImpl) UpdateMany(ctx context.Context, filter, update map[string]any) error {
	if len(update) == 0 || len(filter) == 0 {
		return nil
	}

	mgUpdates := bson.D{}
	if len(update) > 0 {
		mgUpdates = append(mgUpdates, bson.E{"$set", update})
	}
	_, err := impl.coll().UpdateMany(ctx, filter, mgUpdates)
	return err
}

func (impl *SecretUserFollowBadgeListMgDbImpl) AddOne(ctx context.Context, doc *pbmgdb.SecretUserFollowBadgeListMgDbModel, opts ...*options.InsertOneOptions) error {
	_, err := impl.coll().InsertOne(ctx, doc)
	if err != nil {
		logger.Errorf(ctx, "SecretUserFollowBadgeListMgDbImpl:Add error : %v", err)
		return err
	}

	return nil
}

func (impl *SecretUserFollowBadgeListMgDbImpl) DeleteOne(ctx context.Context, filter any) error {
	_, err := impl.coll().DeleteOne(ctx, filter)
	if err != nil {
		logger.Errorf(ctx, "SecretUserFollowBadgeListMgDbImpl:DelByCond error : %v", err)
		return err
	}
	return nil
}

func (impl *SecretUserFollowBadgeListMgDbImpl) DeleteMany(ctx context.Context, filter any) error {
	_, err := impl.coll().DeleteMany(ctx, filter)
	if err != nil {
		logger.Errorf(ctx, "SecretUserFollowBadgeListMgDbImpl:DeleteMany error : %v", err)
		return err
	}
	return nil
}

func (impl *SecretUserFollowBadgeListMgDbImpl) Exists(ctx context.Context, filter any) bool {
	v := &pbmgdb.SecretUserFollowBadgeListMgDbModel{}
	err := impl.coll().FindOne(ctx, filter).Decode(v)
	if err == mongo.ErrNoDocuments {
		return false
	}
	if err != nil {
		logger.Errorf(ctx, "SecretUserFollowBadgeListMgDbImpl:Exists error : %v", err)
		return false
	}
	return true
}
