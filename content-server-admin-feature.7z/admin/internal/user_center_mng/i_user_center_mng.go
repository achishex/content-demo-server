package user_center_mng

import (
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/internal/inner_mng"
	"content_svr/internal/kafka_proxy"
	"content_svr/internal/security_mng"
	"content_svr/internal/thirdparty/wechat_proxy"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbuserapi"
	"context"
)

type IUserCenterMng interface {
	//关注API
	Follow(ctx context.Context, req *pbuserapi.FollowReq) (*pbuserapi.FollowResp, error)
	FollowList(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbuserapi.FollowListReq) (*pbuserapi.FollowListResp, error)
	FollowStat(ctx context.Context, req *pbuserapi.FollowStatusReq) (*pbuserapi.FollowStatusResp, error)
	AddBlackList(ctx context.Context, req *pbuserapi.AddBlackListReq) (*pbuserapi.AddBlackListResp, error)
	FollowBadge(ctx context.Context) (*pbuserapi.FollowBadgeStatResp, error)

	//关注功能方法

	//勋章相关功能方法
	MediaPermanent(ctx context.Context, userId, medalId int64) error
	MediaCancel(ctx context.Context, userId, medalId int64) error
	MediaAdd(ctx context.Context, userId, medalId int64, expireTime int64) error

	//可乐提现
	WithdrawBind(ctx context.Context, req *pbuserapi.BindWechatUserReq) (*pbuserapi.BindWechatUserResp, error)
	WithdrawUnBind(ctx context.Context) error
	WithdrawBefore(ctx context.Context, userId int64, req *pbuserapi.WithdrawBeforeReq) (*pbuserapi.WithdrawBeforeResp, error)
	Withdraw(ctx context.Context, userID int64, req *pbuserapi.WithdrawReq) (*pbuserapi.WithdrawResp, error)

	ActiveUser(ctx context.Context, userId int64, nickname string) error
	SearchByNickname(ctx context.Context, req *pbuserapi.UserSearchReq) (*pbuserapi.UserSearchResp, error)

	//每日签到
	DailySign(ctx context.Context, req *pbuserapi.DailySignReq) (*pbuserapi.LevelUpResp, error)
	LevelInfo(ctx context.Context, req *pbuserapi.LevelCardReq) (*pbuserapi.CurrentLevelInfo, error)
	GetSpeedCode(ctx context.Context, req *pbuserapi.GetSpeedCodeReq) (*pbuserapi.GetSpeedCodeResp, error)
	UsageSpeedCode(ctx context.Context, req *pbuserapi.UsageSpeedCodeReq) (*pbuserapi.LevelUpResp, error)
	CheckSpeedCode(ctx context.Context, req *pbuserapi.CheckSpeedCodeReq) (*pbuserapi.CheckSpeedCodeResp, error)
	UsedListSpeedCode(ctx context.Context, req *pbuserapi.SpeedCodeUsedListReq) (*pbuserapi.SpeedCodeUsedListResp, error)
	LevelRights(ctx context.Context) (*pbuserapi.LevelAllInfoResp, error)
	ResetPenalties(ctx context.Context)

	//用户信息
	EditUserInfo(ctx context.Context, req *pbuserapi.EditUserInfoReq) (resp *pbuserapi.EditUserInfoResp, err error)
	QuickLogin(ctx context.Context, header *pbapi.HttpHeaderInfo, req *pbuserapi.QuickLoginReq) (resp *pbuserapi.QuickLoginResp, err error)

	WorkSetting(ctx context.Context, req *pbuserapi.WorkSettingReq) (resp *pbuserapi.WorkSettingResp, err error)
}

type UserCenterMng struct {
	DataCache        data_cache.IDataCacheMng
	InnerProxy       inner_mng.IInnerProxy
	KafkaProxy       kafka_proxy.IKafkaProxy
	WxProxy          wechat_proxy.IWechatProxy
	ContentMng       content_mng.IContentMng
	SecurityMng      security_mng.ISecurityMng
	TencentLoginComp *TencentLoginComp
}

func NewUserCenterMng(
	dataCache data_cache.IDataCacheMng,
	innerProxy inner_mng.IInnerProxy,
	kafkaProxy kafka_proxy.IKafkaProxy,
	wxProxy wechat_proxy.IWechatProxy,
	contentMng content_mng.IContentMng,
	SecurityMng security_mng.ISecurityMng,
) IUserCenterMng {

	return &UserCenterMng{
		DataCache:        dataCache,
		InnerProxy:       innerProxy,
		KafkaProxy:       kafkaProxy,
		WxProxy:          wxProxy,
		ContentMng:       contentMng,
		SecurityMng:      SecurityMng,
		TencentLoginComp: NewTencentLoginComp(QuickLoginAppConf),
	}
}
