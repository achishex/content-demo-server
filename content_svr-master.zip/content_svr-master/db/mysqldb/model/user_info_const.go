package model

// 启用状态,1:启用，2:限时封禁，3:永久封禁
const (
	_        = iota
	UserOpen = 1
	//UserForbiddenExpire
	UserForbidden = 3
)

// 性别  1男 2女
const (
	GenderBoy  = 1
	GenderGirl = 2
)

// 用户状态,0:无效；1:有效
const (
	UserUnRegister = 0
	UserRegister   = 1
)

// 用户类型 1普通用户 2官方用户 3 bb机 4 机器人
const (
	UserTypeNormal   = 1
	UserTypeOffice   = 2
	UserTypeOfficeBB = 3
	UserTypeRobot    = 4
)
