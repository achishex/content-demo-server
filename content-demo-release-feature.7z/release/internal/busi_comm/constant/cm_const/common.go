package cm_const

const (
	MaxBodySize = 10240
	CtxReqBody  = "req_body"

	MaxDbSize                       = 2147483647
	DispatchMaxPastTimeS            = 90 * 60  //普通分发时间限制 n 分钟前，不分发。单位s
	DispatchHighContentMaxPastTimeS = 360 * 60 //高分内容分发时长 6小时

	// httpheader.platform
	PlatformIos     = "ios"
	PlatformAndroid = "android"

	// httpheader.apptype
	AppTypeMobileIos     = "mobile-ios"
	AppTypeMobileAndroid = "mobile-android"
	AppTypeAppletWx      = "applet-wx"
	AppTypeAppletQq      = "applet-qq"
	AppTypeWeb           = "web"
	AppTypeAppletBd      = "applet-bd"
	AppTypeQuickApp      = "quick_app"

	AppChannelMaozhua = "maozhua" // Android、iOS 的官方渠道包
	AppChannelHuaWei  = "huawei"
	AppChannelHonor   = "honor"
	AppChannelXiaomi  = "xiaomi"
	AppChannelOppo    = "oppo"
	AppChannelVivo    = "vivo"
	AppChannelYYB     = "yyb" // 应用宝

	//  UserCircleWorksSwitch.Identity1:中学 2:大学 3:工作 0:未设置
	UserIdentityMidSchool = 1
	UserIdentityCollege   = 2
	UserIdentityWorker    = 3

	// 官方号
	OfficialMZUserId = 129533901081600

	// 图片加速域名host https://image.52mengdong.com
	MaoZhuaImageHost = "https://image.52mengdong.com/"

	// 系统卡片，eg: 星座卡片等等
	SystemWorkIdXingzuo int64 = 10000000000001 // workId=1

	// 用户主页的激活码状态
	CdKeyUnionStatusInBlackHouse    = 1
	CdKeyUnionStatusWeiKaiQi        = 2
	CdKeyUnionStatusShengChengZhong = 3
	CdKeyUnionStatusYiShengCheng    = 4
	CdKeyUnionStatusDaiLingQu       = 5

	// push_status.  platform/api/user/publish/status resp.push_status
	// //必填 发布状态 1可发布 2未到发布时间 3在小黑屋 4上个作品正在审核中 5-用户等级过低
	PushStatusPass         = 1
	PushStatusWait         = 2
	PushStatusInBlackHouse = 3
	PushStatusAuditing     = 4
	PushStatusLevelToLow   = 5

	// AuditStatus 审核状态 0待审核 1通过 2关小黑屋 3永久封号 4该举报不处理 5:10年小黑屋 6关闭唠唠
	AuditStatusWait           = 0 //0待审核
	AuditStatusPass           = 1 //1通过
	AuditStatusGuanXiaoHeiWu  = 2 // 2关小黑屋
	AuditStatusYongJiuFengHao = 3 //3永久封号
	AuditStatusJuBaoBuChuLi   = 4 // 4该举报不处理
	AuditStatus10XiaoHeiWu    = 5 // 5:10年小黑屋
	AuditStatusGuanBiLaoLao   = 6 //6关闭唠唠

	AuditStatusXiaoHeiWu1Day = 11 // 关小黑屋1天
	AuditStatusXiaoHeiWu3Day = 12 //关小黑屋3天

	// 举报6次成功，奖励。 举报4次无效，惩罚。
	//SucNReportAndReward    = 6 //举报6次成功，奖励。
	//FailedNReportAndReward = 4 //举报4次无效，惩罚。

)

const (
	//抓捕类型 1.动态 2.单聊 3.带图动态二审 4.背景图二审 10.评论 99. 复审（全由机器审核，仅包含动态）
	_ = iota
	AuditWork
	AuditTalk
	Audit2WorkImage
	Audit2BackgroundImage
	AuditComment = 10

	AuditReexamine = 99
)

var (
	_                      float64 = 0
	AuditAwardLength               = 10.0 // 总数
	AuditPassMaxCount              = 0.6  // 成功举报占比
	AuditMaliciousMaxCount         = 0.4  // 失败举报占比
	AuditMaliciousLockTime         = 3    // 判断恶意封禁天数
)

const (
	AuditUnknown              uint8 = iota
	AuditSuccess                    // 举报成功，但不足奖励加速码
	AuditSuccessAwardCode           // 举报成功，奖励加速码
	AuditSuccessMaliciousLock       // 举报成功，封禁时间
	AuditFail                       // 举报不成功
	AuditFailMalicious              // 举报不成功，封禁状态
	AuditMalicious                  // 恶意举报封禁
)

const (
	SYSTEM        int32 = 1
	AUDIT         int32 = 2
	VIOLATION     int32 = 3
	FEEDBACK      int32 = 4
	FEEDBACKREPLY int32 = 5
	APPEAL        int32 = 6
	APPEALREPLY   int32 = 7
	ASSIGN        int32 = 8
)

var PersonalUserNotificationType = map[int32]string{
	SYSTEM:        "系统消息",
	VIOLATION:     "审核消息",
	FEEDBACK:      "反馈消息",
	FEEDBACKREPLY: "反馈回复消息",
	APPEAL:        "申诉消息",
	APPEALREPLY:   "申诉反馈消息",
	ASSIGN:        "指定消息",
}

// 严重违规
var SeriousWeiGui = []int32{
	AuditStatusYongJiuFengHao,
	AuditStatus10XiaoHeiWu,
	AuditStatusGuanBiLaoLao,
}

// 中等违规
var MediumWeiGui = []int32{
	AuditStatusGuanXiaoHeiWu,
}

// 轻度违规
var LightWeiGui = []int32{
	AuditStatusXiaoHeiWu1Day,
	AuditStatusXiaoHeiWu3Day,
}

var AuditStatusWeiGui = []int32{
	AuditStatusGuanXiaoHeiWu,
	AuditStatusYongJiuFengHao,
	AuditStatus10XiaoHeiWu,
	AuditStatusXiaoHeiWu1Day,
	AuditStatusXiaoHeiWu3Day,
}

var AppTypeDict = map[string]int32{
	AppTypeMobileIos:     1,
	AppTypeMobileAndroid: 2,
	AppTypeAppletWx:      3,
	AppTypeAppletQq:      4,
	AppTypeWeb:           5,
	AppTypeAppletBd:      6,
	AppTypeQuickApp:      7,
}

var AppNameFlagDict = map[string]int32{ //appname ~ appflag
	"joke":         1,
	"funny":        2,
	"wallpaper":    3,
	"con":          4,
	"soul_soup":    5,
	"commend":      6,
	"match":        7,
	"speak":        8,
	"tribe":        9,
	"family":       10,
	"almanac":      11,
	"bd_tarot":     12,
	"bd_sign":      13,
	"sport":        14,
	"sign_mall":    15,
	"con_wx":       42,
	"soul_soup_wx": 43,
}

var AppTypeOpenTypeDict = map[string]int32{ //appType ~ appflag
	AppTypeMobileIos:     1,
	AppTypeMobileAndroid: 2,
	AppTypeAppletWx:      3,
	AppTypeAppletQq:      4,
	AppTypeWeb:           5,
	AppTypeAppletBd:      6,
	AppTypeQuickApp:      7,
}

var PlatformDict = map[string]int32{ //appType ~ appflag
	PlatformIos:     1,
	PlatformAndroid: 2,
}

var SignIdNameDict = map[int32]string{
	1:  "白羊座",
	2:  "金牛座",
	3:  "双子座",
	4:  "巨蟹座",
	5:  "狮子座",
	6:  "处女座",
	7:  "天秤座",
	8:  "天蝎座",
	9:  "射手座",
	10: "摩羯座",
	11: "水瓶座",
	12: "双鱼座",
}

// 系统卡片对应支持的版本
type SysWorkVerCheck struct {
	WorkId     int64 //系统卡片id
	IosVer     int   //ios从此版本开始支持
	AndroidVer int   // 安卓从此版本开始支持
}

var SysWorkVerCheckDict = map[int64]*SysWorkVerCheck{
	SystemWorkIdXingzuo: &SysWorkVerCheck{ // 星座卡
		WorkId:     1,
		IosVer:     1070000,
		AndroidVer: 1070000,
	},
}

// 第三方登录类型
const (
	ThirdSystem    int32 = 0
	ThirdWX        int32 = 1
	ThirdQQ        int32 = 2
	ThirdSinaWeibo int32 = 3
	ThirdApple     int32 = 4
	ThirdByteDance int32 = 5
	ThirdQuickApp  int32 = 6
)

var (
	HookTypeMine   int32 = 1 //本平台拦截
	HookTypeShuMei int32 = 2 //数美拦截
)

var (
	AuditTypeText  int32 = 1 //文本
	AuditTypeImg   int32 = 2 //图片
	AuditTypeEmote int32 = 3 //表情包
)
