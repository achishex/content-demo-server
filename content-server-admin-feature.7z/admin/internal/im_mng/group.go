package im_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/aq_const"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/security_mng"
	"content_svr/protobuf/pbim"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils/panichelper"
	"content_svr/setting"
	"context"
	"encoding/json"
	"fmt"
	"github.com/OpenIMSDK/protocol/group"
	"github.com/OpenIMSDK/protocol/sdkws"
	"github.com/OpenIMSDK/protocol/wrapperspb"
	"github.com/gin-gonic/gin"
	"github.com/gogo/protobuf/proto"
	"github.com/kevwan/mapreduce/v2"
	"go.mongodb.org/mongo-driver/bson"
	"strconv"
	"sync"
	"time"
)

// 创建群组
func (i *IMMng) CreateGroup(ctx context.Context, req *group.CreateGroupReq) (*group.CreateGroupResp, error) {

	var (
		resp      = &group.CreateGroupResp{}
		gctx      = ctx.(*gin.Context)
		userId    = middleware.GetUserID(gctx)
		maxGroups = int64(setting.Maozhua.ImGroup.MaxGroupLimit.Get())
		apiToken  = middleware.GetImToken(ctx)
	)

	//用户信息
	userInfo := i.DataCache.GetImpl().GetUserExtInfoMgDBLd(ctx, userId, false)
	if userInfo == nil {
		return nil, errorcode.DATA_NOT_EXISTS
	}

	//创建群最低群成员限制
	if len(req.MemberUserIDs) < LeastGroupUserLimit {
		return nil, errorcode.GroupCreateLatestUserNumsError
	}

	//创建群等级限制
	lvlLimit := setting.Maozhua.ImGroup.GroupCreateLevelLimit.Get()
	if userInfo.GetUlevel() < lvlLimit {
		return nil, &errors.Error{UserErrCode: errorcode.GroupCreateLevelNotEnough.UserErrCode, UserMsg: fmt.Sprintf(errorcode.GroupCreateLevelNotEnough.UserMsg, lvlLimit)}
	}

	//创建群数量上限
	c, err := i.DataCache.GetImpl().ImGroupsDbModel.CountMyCreateGroups(ctx, strconv.FormatInt(userId, 10))
	if err != nil {
		logger.Errorf(ctx, "IMMng.CreateGroup.CountMyCreateGroups error: %v", err)
		return nil, errorcode.GroupGetMyCreateCountError
	}
	if c >= maxGroups {
		return nil, errorcode.GroupCreateUpperLimitError
	}

	if err := mapreduce.Finish(func() error {
		//检查群昵称
		if res, err := i.SecurityMng.CheckTxt(ctx, userId, security_mng.MArticleEventId.Nickname, req.GroupInfo.GroupName, 1); err != nil || res != aq_const.AqConst.Pass {
			return errorcode.GroupNameError
		}
		return nil
	}, func() error {
		//检查群简介
		if res, err := i.SecurityMng.CheckTxt(ctx, userId, security_mng.MArticleEventId.Profile, req.GroupInfo.Introduction, 1); err != nil || res != aq_const.AqConst.Pass {
			return errorcode.GroupIntroduceError
		}
		return nil
	}, func() error {
		//检查群头像
		if res, err := i.SecurityMng.CheckImage(ctx, userId, security_mng.MImgEventId.HeadImage, config.ServerConfig.ImageHost+req.GroupInfo.FaceURL); err != nil || res != aq_const.AqConst.Pass {
			return errorcode.GroupFaceImgError
		}
		return nil
	}, func() error {
		//检查用户是否注册ImServer
		if err := i.checkOrRegister(ctx, req.MemberUserIDs); err != nil {
			logger.Errorf(ctx, "IMMng.checkGroupUserAndRegister error: %v", err)
			return err
		}
		return nil
	}); err != nil {
		return nil, err
	}

	//创建群组
	ctx = middleware.WithImToken(ctx, apiToken)
	req.GroupInfo.CreatorUserID = req.OwnerUserID
	req.GroupInfo.GroupID = strconv.FormatInt(snow_flake.GetSnowflakeID(), 10)
	resp, err = i.OpenImCaller.CreateGroup(ctx, req)
	if err != nil {
		logger.Errorf(ctx, "IMMng.CreateGroup error: %v", err)
		return nil, errorcode.GroupCreateError
	}

	// 建群奖励
	ctx2 := gctx.Copy()
	go func() {
		defer panichelper.PanicRecover(ctx2)
		err2 := i.rewardComp.CreateGroupReward(ctx, userId)
		if err2 != nil {
			logger.Errorf(ctx2, "CreateGroupReward fail, userID: %v, err: %v", userId, err)
		}
	}()

	return resp, nil
}

// 设置群组信息
func (i *IMMng) SetGroupInfo(ctx context.Context, req *SetGroupInfoReq) (*group.SetGroupInfoResp, error) {
	var (
		userId = middleware.GetUserID(ctx.(*gin.Context))
	)

	//群信息
	groupInfo, err := i.OpenImCaller.FindGroupInfo(ctx, &group.GetGroupsInfoReq{GroupIDs: []string{req.GroupInfoForSet.GroupID}})
	if err != nil || len(groupInfo.GroupInfos) == 0 {
		return nil, errorcode.GroupNotFoundError
	}
	//权限判断
	if groupInfo.GroupInfos[0].OwnerUserID != strconv.FormatInt(userId, 10) {
		return nil, errorcode.GroupPermissionDenied
	}

	g := groupInfo.GroupInfos[0]
	updates := &sdkws.GroupInfoForSet{
		GroupID:      g.GroupID,
		GroupName:    g.GroupName,
		Notification: g.Notification,
		Introduction: g.Introduction,
		FaceURL:      g.FaceURL,
	}
	var updateEx GroupExt
	_ = json.Unmarshal([]byte(g.Ex), &updateEx)

	if err := mapreduce.Finish(func() error {
		//检查群昵称
		if req.GroupInfoForSet.GroupName != "" {
			if res, err := i.SecurityMng.CheckTxt(ctx, userId, security_mng.MArticleEventId.Nickname, req.GroupInfoForSet.GroupName, 1); err != nil || res != aq_const.AqConst.Pass {
				return errorcode.GroupNameError
			}
			updates.GroupName = req.GroupInfoForSet.GroupName
		}
		return nil
	}, func() error {
		//检查群简介
		if req.GroupInfoForSet.Introduction != "" {
			if res, err := i.SecurityMng.CheckTxt(ctx, userId, security_mng.MArticleEventId.Profile, req.GroupInfoForSet.Introduction, 1); err != nil || res != aq_const.AqConst.Pass {
				return errorcode.GroupIntroduceError
			}
			updates.Introduction = req.GroupInfoForSet.Introduction
		}
		return nil
	}, func() error {
		//检查群头像
		if req.GroupInfoForSet.FaceURL != "" {
			if res, err := i.SecurityMng.CheckImage(ctx, userId, security_mng.MImgEventId.HeadImage, config.ServerConfig.ImageHost+req.GroupInfoForSet.FaceURL); err != nil || res != aq_const.AqConst.Pass {
				return errorcode.GroupFaceImgError
			}
			updates.FaceURL = req.GroupInfoForSet.FaceURL
		}
		return nil
	}, func() error {
		//检查群聊背景
		if req.GroupExt != nil && req.GroupExt.Background != "" {
			if res, err := i.SecurityMng.CheckImage(ctx, userId, security_mng.MImgEventId.Album, config.ServerConfig.ImageHost+req.GroupExt.Background); err != nil || res != aq_const.AqConst.Pass {
				return errorcode.GroupBackGroupImgError
			}
			updateEx.Background = req.GroupExt.Background
		}
		return nil
	}, func() error {
		//检查主页背景
		if req.GroupExt != nil && req.GroupExt.HomepageBackground != "" {
			if res, err := i.SecurityMng.CheckImage(ctx, userId, security_mng.MImgEventId.Album, config.ServerConfig.ImageHost+req.GroupExt.HomepageBackground); err != nil || res != aq_const.AqConst.Pass {
				return errorcode.GroupHomepageBackGroupImgError
			}
			updateEx.HomepageBackground = req.GroupExt.HomepageBackground
		}
		return nil
	}); err != nil {
		return nil, err
	}

	ex, err := json.Marshal(updateEx)
	if err != nil {
		logger.Errorf(ctx, "IMMng.SetGroupInfo Marshal req.GroupExt error: %v", err)
		return nil, errorcode.PARAM_ERROR
	}
	updates.Ex = wrapperspb.String(string(ex))

	//设置群信息
	if err := i.OpenImCaller.SetGroupInfo(ctx, &group.SetGroupInfoReq{GroupInfoForSet: updates}); err != nil {
		logger.Errorf(ctx, "IMMng.SetGroupInfo error: %v", err)
		return nil, errorcode.GroupSetError
	}
	return &group.SetGroupInfoResp{}, nil
}

// 邀请进群组
func (i *IMMng) InviteToGroup(ctx context.Context, req *group.InviteUserToGroupReq) (*group.InviteUserToGroupResp, error) {
	var (
		userId    = middleware.GetUserID(ctx.(*gin.Context))
		groupInfo *group.GetGroupsInfoResp
		err       error
	)

	//入群前置检查
	if groupInfo, err = i.preCheckForJoinGroup(ctx, req.GroupID, req.InvitedUserIDs); err != nil {
		return nil, err
	}

	if groupInfo.GroupInfos[0].OwnerUserID == strconv.FormatInt(userId, 10) {
		//群主邀请，直接进群
		if err := i.OpenImCaller.InviteToGroup(ctx, req); err != nil {
			logger.Errorf(ctx, "IMMng.InviteToGroup error: %v", err)
			return nil, errorcode.GroupInviteError
		}
	} else {
		//todo 非群主邀请，需发送私聊消息，被邀请人从消息入口申请入群
		gctx, ok := ctx.(*gin.Context)
		if !ok {
			logger.Errorf(ctx, "ctx should be gin.Context")
			return &group.InviteUserToGroupResp{}, nil
		}

		err = i.Helper.SendGroupShare(gctx, groupInfo.GroupInfos[0], req.InvitedUserIDs)
		if err != nil {
			logger.Errorf(ctx, "SendGroupShare fain, err: %v", err)
			return nil, err
		}
	}

	return &group.InviteUserToGroupResp{}, nil
}

// 申请入群
func (i *IMMng) JoinGroup(ctx context.Context, req *group.JoinGroupReq) (*group.JoinGroupResp, error) {
	var (
		userId = middleware.GetUserID(ctx.(*gin.Context))
	)

	if req.InviterUserID != strconv.FormatInt(userId, 10) {
		return nil, errorcode.PARAM_ERROR
	}

	if err := i.OpenImCaller.JoinGroup(ctx, req); err != nil {
		return nil, errorcode.GroupJoinError
	}
	// TODO(zhangmingdong) 发BB机消息
	if err := i.Helper.SendGroupJoinBBMsg(ctx, fmt.Sprint(userId), req.GroupID); err != nil {
		logger.Errorf(ctx, "SendGroupJoinBBMsg fail, err: %v", err)
	}
	return &group.JoinGroupResp{}, nil
}

// 群主/管理员处理加入申请进群
func (i *IMMng) GroupApplicationResponse(ctx context.Context, req *group.GroupApplicationResponseReq) (*group.GroupApplicationResponseResp, error) {
	if req.HandleResult != ApplicationStatusAccept && req.HandleResult != ApplicationStatusDecline {
		return nil, errorcode.PARAM_ERROR
	}

	//入群前置检查
	if _, err := i.preCheckForJoinGroup(ctx, req.GroupID, []string{req.FromUserID}); err != nil {
		return nil, err
	}

	//申请通过入群
	if err := i.OpenImCaller.GroupApplicationResponse(ctx, req); err != nil {
		logger.Errorf(ctx, "IMMng.GroupApplicationResponse error: %v", err)
		return nil, errorcode.GroupJoinError
	}
	return &group.GroupApplicationResponseResp{}, nil
}

// 踢出群组
func (i *IMMng) KickGroup(ctx context.Context, req *group.KickGroupMemberReq) (*group.KickGroupMemberResp, error) {
	var userId = middleware.GetUserID(ctx.(*gin.Context))
	//群信息
	groupInfo, err := i.OpenImCaller.FindGroupInfo(ctx, &group.GetGroupsInfoReq{GroupIDs: []string{req.GroupID}})
	if err != nil || len(groupInfo.GroupInfos) == 0 {
		return nil, errorcode.GroupNotFoundError
	}
	//权限判断
	if groupInfo.GroupInfos[0].OwnerUserID != strconv.FormatInt(userId, 10) {
		return nil, errorcode.GroupPermissionDenied
	}

	if err := i.OpenImCaller.KickGroup(ctx, req); err != nil {
		logger.Errorf(ctx, "IMMng.KickGroup error: %v", err)
		return nil, errorcode.GroupKickError
	}
	return &group.KickGroupMemberResp{}, nil
}

// 入群前置检查
func (i *IMMng) preCheckForJoinGroup(ctx context.Context, groupId string, userIds []string) (*group.GetGroupsInfoResp, error) {
	var (
		groupInfo    *group.GetGroupsInfoResp
		groupAbsInfo *group.GetGroupAbstractInfoResp
		err          error
	)

	//群信息
	if err := mapreduce.Finish(func() error {
		groupInfo, err = i.OpenImCaller.FindGroupInfo(ctx, &group.GetGroupsInfoReq{GroupIDs: []string{groupId}})
		if err != nil || len(groupInfo.GroupInfos) == 0 {
			logger.Errorf(ctx, "IMMng.preCheckForJoinGroup.FindGroupInfo error: %v", err)
			return errorcode.GroupNotFoundError
		}
		return nil
	}, func() error {
		groupAbsInfo, err = i.OpenImCaller.GetGroupsAbstractInfo(ctx, &group.GetGroupAbstractInfoReq{GroupIDs: []string{groupId}})
		if err != nil || len(groupAbsInfo.GroupAbstractInfos) == 0 {
			logger.Errorf(ctx, "IMMng.preCheckForJoinGroup.GetGroupsAbstractInfo error: %v", err)
			return errorcode.GroupNotFoundError
		}
		return nil
	}, func() error {
		//被邀请用户检查/注册
		if err := i.checkOrRegister(ctx, userIds); err != nil {
			return err
		}
		return nil
	}); err != nil {
		return nil, err
	}

	//群解散
	if groupInfo.GroupInfos[0].Status == GroupStatusDismissed {
		return nil, errorcode.GroupStatusDismissed
	}

	//群满员
	if int32(groupAbsInfo.GroupAbstractInfos[0].GroupMemberNumber) >= setting.Maozhua.ImGroup.MaxGroupMemberLimit.Get() {
		return nil, errorcode.GroupStatusFull
	}

	return groupInfo, nil
}

// 群举报
func (i *IMMng) GroupReport(ctx context.Context, req *pbim.GroupReportReq) (*pbim.GroupReportResp, error) {
	var userId = middleware.GetUserID(ctx.(*gin.Context))

	g, err := i.DataCache.GetImpl().ImGroupMgModel.FindOne(ctx, bson.M{"user_id": userId, "group_id": req.GroupId})
	if err != nil {
		return nil, errorcode.GroupReportError
	}

	if g != nil {
		return nil, errorcode.GroupReportRepeatError
	}

	if err := i.DataCache.GetImpl().ImGroupMgModel.Create(ctx, &pbmgdb.ImGroupReportMgDbModel{
		Id:         snow_flake.GetSnowflakeID(),
		UserId:     userId,
		GroupId:    req.GroupId,
		Reason:     req.Reason,
		CreateTime: time.Now().UnixMilli(),
	}); err != nil {
		logger.Errorf(ctx, "IMMng.GroupReport.Create error: %v", err)
		return nil, errorcode.GroupReportError
	}

	return &pbim.GroupReportResp{}, nil
}

// 解散群
func (i *IMMng) DismissGroup(ctx context.Context, req *group.DismissGroupReq) (*group.DismissGroupResp, error) {
	var userId = middleware.GetUserID(ctx.(*gin.Context))

	if b, err := i.isGroupOwner(ctx, userId, req.GroupID); !b || err != nil {
		return nil, errorcode.GroupDismissError
	}

	if err := i.OpenImCaller.DismissGroup(ctx, req); err != nil {
		logger.Errorf(ctx, "IMMng.DismissGroup error: %v", err)
		return nil, errorcode.GroupDismissError
	}
	return &group.DismissGroupResp{}, nil
}

// 退群
func (i *IMMng) QuitGroup(ctx context.Context, req *group.QuitGroupReq) (*group.QuitGroupResp, error) {
	if err := i.OpenImCaller.QuitGroup(ctx, req); err != nil {
		logger.Errorf(ctx, "IMMng.QuitGroup error: %v", err)
		return nil, errorcode.GroupQuitError
	}
	return &group.QuitGroupResp{}, nil
}

// 转让群
func (i *IMMng) TransferGroup(ctx context.Context, req *group.TransferGroupOwnerReq) (*group.TransferGroupOwnerResp, error) {
	var userId = middleware.GetUserID(ctx.(*gin.Context))

	if b, err := i.isGroupOwner(ctx, userId, req.GroupID); !b || err != nil {
		return nil, errorcode.GroupTransferError
	}

	if err := i.OpenImCaller.TransferGroup(ctx, req); err != nil {
		logger.Errorf(ctx, "IMMng.TransferGroup error: %v", err)
		return nil, errorcode.GroupTransferError
	}
	return &group.TransferGroupOwnerResp{}, nil
}

// 设置群员信息
func (i *IMMng) SetGroupMemberInfo(ctx context.Context, req *group.SetGroupMemberInfoReq) (*group.SetGroupMemberInfoResp, error) {
	if err := i.OpenImCaller.SetGroupMemberInfo(ctx, req); err != nil {
		logger.Errorf(ctx, "IMMng.SetGroupMemberInfo error: %v", err)
		return nil, errorcode.GroupSetMemberInfoError
	}
	return &group.SetGroupMemberInfoResp{}, nil
}

// 群综合状态信息
func (i *IMMng) GroupMixInfo(ctx context.Context, req *pbim.GroupMixInfoReq) (*pbim.GroupMixInfoResp, error) {
	var (
		resp = &pbim.GroupMixInfoResp{
			IsDismiss:     proto.Bool(false),
			IsFull:        proto.Bool(false),
			IsJoined:      proto.Bool(false),
			MemberTotal:   proto.Int32(0),
			OwnerFaceUrl:  proto.String(""),
			OwnerNickname: proto.String(""),
			CreatorUserID: proto.String(""),
			OwnerUserID:   proto.String(""),
			GroupID:       proto.String(req.GroupID),
		}

		groupInfo    *group.GetGroupsInfoResp
		groupAbsInfo *group.GetGroupAbstractInfoResp
		err          error
		userId       = middleware.GetUserID(ctx.(*gin.Context))
	)

	//群信息
	if err := mapreduce.Finish(func() error {
		groupInfo, err = i.OpenImCaller.FindGroupInfo(ctx, &group.GetGroupsInfoReq{GroupIDs: []string{req.GroupID}})
		if err != nil || len(groupInfo.GroupInfos) == 0 {
			logger.Errorf(ctx, "IMMng.GroupMixInfo.FindGroupInfo error: %v", err)
			return errorcode.GroupNotFoundError
		}
		return nil
	}, func() error {
		groupAbsInfo, err = i.OpenImCaller.GetGroupsAbstractInfo(ctx, &group.GetGroupAbstractInfoReq{GroupIDs: []string{req.GroupID}})
		if err != nil || len(groupAbsInfo.GroupAbstractInfos) == 0 {
			logger.Errorf(ctx, "IMMng.GroupMixInfo.GetGroupsAbstractInfo error: %v", err)
			return errorcode.GroupNotFoundError
		}
		resp.MemberTotal = proto.Int32(int32(groupAbsInfo.GroupAbstractInfos[0].GroupMemberNumber))
		return nil
	}, func() error {
		if b, err := i.DataCache.GetImpl().ImGroupMemberDbModel.HasJoined(ctx, []string{req.GroupID}, strconv.FormatInt(userId, 10)); err != nil {
			logger.Errorf(ctx, "IMMng.GroupMixInfo.GroupMixInfo error: %v", err)
		} else {
			resp.IsJoined = proto.Bool(b[req.GetGroupID()])
		}
		return nil
	}); err != nil {
		return nil, err
	}

	resp.OwnerUserID = proto.String(groupInfo.GroupInfos[0].OwnerUserID)
	resp.CreatorUserID = proto.String(groupInfo.GroupInfos[0].CreatorUserID)
	resp.GroupName = proto.String(groupInfo.GroupInfos[0].GroupName)
	resp.GroupFaceUrl = proto.String(groupInfo.GroupInfos[0].FaceURL)

	//群主信息
	if info, err := i.OpenImCaller.GetGroupMembersInfo(ctx, &group.GetGroupMembersInfoReq{
		GroupID: req.GroupID,
		UserIDs: []string{groupInfo.GroupInfos[0].OwnerUserID},
	}); err != nil || len(info.Members) == 0 {
		logger.Errorf(ctx, "IMMng.GroupMixInfo.GetGroupMembersInfo group owner is nil")
	} else {
		resp.OwnerNickname = proto.String(info.Members[0].Nickname)
		resp.OwnerFaceUrl = proto.String(info.Members[0].FaceURL)
	}

	//群解散
	if groupInfo.GroupInfos[0].Status == GroupStatusDismissed {
		resp.IsDismiss = proto.Bool(true)
	}

	//群满员
	if int32(groupAbsInfo.GroupAbstractInfos[0].GroupMemberNumber) >= setting.Maozhua.ImGroup.MaxGroupMemberLimit.Get() {
		resp.IsFull = proto.Bool(true)
	}

	return resp, nil
}

func (i *IMMng) GroupBatchInfo(ctx context.Context, req *pbim.BatchGroupIsJoinedReq) (*pbim.BatchGroupIsJoinedResp, error) {
	userId := middleware.GetUserID(ctx.(*gin.Context))
	resp := &pbim.BatchGroupIsJoinedResp{}
	if joinList, err := i.DataCache.GetImpl().ImGroupMemberDbModel.HasJoined(ctx, req.GroupIDs, strconv.FormatInt(userId, 10)); err != nil {
		logger.Errorf(ctx, "IMMng.GroupMixInfo.GroupBatchInfo error: %v", err)
	} else {
		for groupId, isJoined := range joinList {
			resp.Result = append(resp.Result, &pbim.GroupJoined{
				GroupID:  groupId,
				IsJoined: proto.Bool(isJoined),
			})
		}
		return resp, nil
	}
	return resp, nil
}

func (i *IMMng) GroupMemberExtInfo(ctx context.Context, req *pbim.GroupMemberExtInfoReq) (*pbim.GroupMemberExtInfoResp, error) {
	var resp = &pbim.GroupMemberExtInfoResp{}
	wg := sync.WaitGroup{}
	wg.Add(len(req.UserIDs))

	for _, uid := range req.UserIDs {
		go func(uid string, wg *sync.WaitGroup) {
			defer func() {
				wg.Done()
				if err := recover(); err != nil {
					return
				}
			}()

			userId, err := strconv.ParseInt(uid, 10, 64)
			if err != nil {
				return
			}

			userInfo, err := i.DataCache.GetUserInfoLocal(ctx, nil, userId, true)
			member := &pbim.MemberExtInfo{
				UserID:     &uid,
				MemberType: &userInfo.MemberType,
				TalkMode:   userInfo.PsecretUserExtInfo.TalkMode,
				Gender:     userInfo.UserInfoDbModel.Gender,
				Ulevel:     userInfo.PsecretUserExtInfo.Ulevel,
				Province:   proto.String(userInfo.UserInfoDbModel.GetProvince()),
				City:       proto.String(userInfo.UserInfoDbModel.GetCity()),
			}

			resp.List = append(resp.List, member)
		}(uid, &wg)
	}
	wg.Wait()

	return resp, nil
}

// 是否群主
func (i *IMMng) isGroupOwner(ctx context.Context, userId int64, groupId string) (bool, error) {
	if userId == 0 || groupId == "" {
		return false, nil
	}

	groupInfo, err := i.OpenImCaller.FindGroupInfo(ctx, &group.GetGroupsInfoReq{GroupIDs: []string{groupId}})
	fmt.Println(groupInfo)
	if err != nil || len(groupInfo.GroupInfos) == 0 {
		logger.Errorf(ctx, "IMMng.isGroupOwner.FindGroupInfo error: %v", err)
		return false, errorcode.GroupNotFoundError
	}
	if groupInfo.GroupInfos[0].OwnerUserID != strconv.FormatInt(userId, 10) {
		return false, errorcode.GroupPermissionDenied
	}

	return true, nil
}
