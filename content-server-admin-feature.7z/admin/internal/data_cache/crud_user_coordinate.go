package data_cache

import (
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
	"github.com/gogo/protobuf/proto"
	"strings"
	"time"
)

func (p *DataCacheMng) trimProvince(text string) string {
	return strings.Replace(text, "省", "", -1)
}

func (p *DataCacheMng) trimCity(text string) string {
	return strings.Replace(text, "市", "", -1)
}

func (p *DataCacheMng) ConvertFormate(coor *pbapi.CoordinateRedis) *pbapi.Coordinate {
	return &pbapi.Coordinate{
		Longitude: proto.Float64(coor.GetLongitude()),
		Latitude:  proto.Float64(coor.GetLatitude()),
		Country:   proto.String(coor.GetCountry()),
		Province:  proto.String(coor.GetProvince()),
		City:      proto.String(coor.GetCity()),
		District:  proto.String(coor.GetDistrict()),
		Ip:        proto.String(coor.GetIp()),
	}
}

func (p *DataCacheMng) GetUserCoordinateV2(ctx context.Context, userId int64, header *pbapi.HttpHeaderInfo) *pbapi.CoordinateRedis {
	// 1. 从 header 获取完整数据
	if header.GetLongitude() > 0 &&
		header.GetLatitude() > 0 &&
		(len(header.GetCountry()) > 0 || len(header.GetProvince()) > 0 || len(header.GetCity()) > 0) {
		resp := &pbapi.CoordinateRedis{}
		resp.Longitude = header.GetLongitude()
		resp.Latitude = header.GetLatitude()
		resp.Ip = header.GetIp()
		resp.Country = header.GetCountry()

		resp.Province = p.trimProvince(header.GetProvince())
		if len(resp.Province) == 0 && len(resp.GetCountry()) > 0 { // 兜底逻辑
			resp.Province = resp.GetCountry()
		}

		if len(header.GetCity()) > 0 {
			city := p.trimCity(header.GetCity())
			if cityMap[city] == true { // 国内的城市
				resp.City = city
			}
		}
		resp.Src = header.GetApptype()
		resp.District = header.GetRegion()

		// 最新定位数据 更新 redis
		p.updateUserCoordinateRedis(ctx, userId, resp, 60*60*24)

		//logger.Infof(ctx, "coordinate_location,from header,user_id %v, app_type %v, province %v,city %v, lng %v, lat %v", userId, header.GetApptype(), header.GetProvince(), header.GetCity(), header.GetLongitude(), header.GetLatitude())
		return resp
	}

	// 2. 从 redis 缓存中取
	resp := p.GetUserCoordinateRedis(ctx, userId)
	if len(resp.GetProvince()) > 0 || len(resp.GetCity()) > 0 {
		if resp.GetSrc() == "baidu_ip" && header.GetLongitude() > 0 && header.GetLatitude() > 0 {
			// 缓存是ip定位，如果上传了经纬度则重新去定位
			logger.Infof(ctx, "coordinate_location,不使用缓存,user_id %v, app_type %v, ver %v, province %v,city %v, lng %v, lat %v", userId, header.GetApptype(), resp.GetVer(), resp.GetProvince(), resp.GetCity(), header.GetLongitude(), header.GetLatitude())
		} else {
			//if resp.GetVer() > 1 {
			return resp
			//} else {
			//	p.deleteUserCoordinateRedis(ctx, userId)
			//}
		}
	}

	// 3.1 从第三方获取 优先使用经纬度
	if header.GetLongitude() > 0 && header.GetLatitude() > 0 {
		resp, err := p.BaiduLbsProxy.ReverseGeocodingV2(ctx, header.GetLatitude(), header.GetLongitude(), header.GetIp())

		if err == nil && resp != nil {
			// 最新数据写入 redis 中
			resp.Src = "baidu_location"
			p.updateUserCoordinateRedis(ctx, userId, resp, 60*60*24)
			logger.Infof(ctx, "coordinate_location,from baidu location,user_id %v, app_type %v, province %v,city %v, lng %v, lat %v", userId, header.GetApptype(), resp.GetProvince(), resp.GetCity(), resp.GetLongitude(), resp.GetLatitude())
			return resp
		} else {
			logger.Infof(ctx, fmt.Sprintf("coordinate_location,from baidu location,user_id %v", userId), err)
		}
	}

	// 3.2 从第三方获取 次优使用ip地址
	if len(header.GetIp()) > 0 {
		resp = p.getCoordinateByIp(ctx, header.GetIp())
		if resp != nil {
			resp.Src = "baidu_ip"
			p.updateUserCoordinateRedis(ctx, userId, resp, 60*60*72) // ip 的定位数据缓存3天，减少百度接口的请求
			logger.Infof(ctx, "coordinate_location,from location ip,user_id %v, app_type %v, province %v,city %v, ip %v, src %v", userId, header.GetApptype(), resp.GetProvince(), resp.GetCity(), resp.GetIp(), resp.GetSrc())
			return resp
		} else {
			logger.Infof(ctx, fmt.Sprintf("coordinate_location,from location ip,user_id %v", userId))
		}
	}

	// 4. 兜底 没有定位数据
	resp = &pbapi.CoordinateRedis{}
	resp.Longitude = header.GetLongitude()
	resp.Latitude = header.GetLatitude()
	resp.Ip = header.GetIp()
	resp.Country = ""
	resp.Province = ""
	resp.City = ""
	resp.District = ""
	return resp
}

func (p *DataCacheMng) getCoordinateByIp(ctx context.Context, ip string) *pbapi.CoordinateRedis {
	if len(ip) == 0 {
		return nil
	}

	//从db 取
	ipACoord, err := p.IpAddressMgModel.GetByIp(ctx, ip)
	if err != nil {
		logger.Errorf(ctx, "coordinate_location mgdb GetCoordinateByIp failed.  err=%v", err)
		return nil
	}

	if ipACoord != nil {
		return &pbapi.CoordinateRedis{
			Ip:        ip,
			Longitude: ipACoord.GetLongitude(),
			Latitude:  ipACoord.GetLatitude(),
			Province:  ipACoord.GetProvince(),
			City:      ipACoord.GetCity(),
			Src:       "mng_ip",
		}
	}

	// 没取成功，请求baidu lbs
	respCoo, err := p.BaiduLbsProxy.GetIpAddressV2(ctx, ip)
	if err != nil {
		//logger.Errorf(ctx, "quding GetIpAddress failed. resp=%v, err=%v", respCoo, err)
		return nil
	}

	// save到db
	if respCoo != nil {
		mgItem := &pbmgdb.IpAddressMgDbModel{
			Id:        ip,
			Province:  proto.String(respCoo.GetProvince()),
			City:      proto.String(respCoo.GetCity()),
			Longitude: proto.Float64(respCoo.GetLongitude()),
			Latitude:  proto.Float64(respCoo.GetLatitude()),
		}
		err = p.IpAddressMgModel.Insert(ctx, mgItem)
		logger.Infof(ctx, "coordinate_location save GetIpAddress to db. ip=%v, value=%+v, err=%v", ip, mgItem, err)
	}

	return respCoo
}

func (p *DataCacheMng) GetUserCoordinateRedis(ctx context.Context, userId int64) *pbapi.CoordinateRedis {
	redisKey := getUserCoordinateKey(userId)
	resp := &pbapi.CoordinateRedis{}
	err := p.RedisCli.HGetAll(ctx, redisKey).Scan(resp) //返回在range的idx位置
	if err != nil && err != redis.Nil {
		logger.Error(ctx, fmt.Sprintf("GetUserCoordinate failed, redisKey=%v", redisKey), err)
	}

	//duration, _ := p.RedisCli.TTL(ctx, redisKey).Result()
	//if duration > time.Duration(86400)*time.Second { // 临时逻辑 by quding  如果是老数据，则让尽快过期。确保走正常的定位逻辑。
	//	expire := 60 * 60 * 1
	//	dd := time.Duration(expire) * time.Second
	//	err = p.RedisCli.Expire(ctx, redisKey, dd).Err()
	//	logger.Infof(ctx, "coordinate_location,reset expire，1小时,user_id %v, duration %v, dd %v", userId, duration, dd)
	//}

	return resp
}

func (p *DataCacheMng) updateUserCoordinateRedis(ctx context.Context, userId int64, coordinate *pbapi.CoordinateRedis, expire int) bool {
	redisKey := getUserCoordinateKey(userId)

	coordinate.Ver = 2
	result, err := utils.StructToJsonMap(&coordinate)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("UpdateUserCoordinateRedis StructToJsonMap failed, redisKey=%v", redisKey), err)
		return false
	}

	_, err = p.RedisCli.HSet(ctx, redisKey, result).Result()
	if err != nil && err != redis.Nil {
		logger.Error(ctx, fmt.Sprintf("UpdateUserCoordinateRedis failed, redisKey=%v", redisKey), err)
		return false
	}

	if expire <= 0 { // 兜底
		expire = 60 * 60 * 24 // 定位缓存24小时(设置大一点，先减少百度api的请求量)
	}
	err = p.RedisCli.Expire(ctx, redisKey, time.Duration(expire)*time.Second).Err()
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("UpdateUserCoordinateRedis expire failed, redisKey=%v", redisKey), err)
		return false
	}

	return true
}

func (p *DataCacheMng) deleteUserCoordinateRedis(ctx context.Context, userId int64) {
	redisKey := getUserCoordinateKey(userId)

	err := p.RedisCli.Del(ctx, redisKey).Err()
	if err != nil && err != redis.Nil {
		logger.Errorf(ctx, "delkey failed. redisKey=%v, err=%v", redisKey, err)
	}
}

var cityMap = map[string]bool{
	"北京":          true,
	"重庆":          true,
	"天津":          true,
	"上海":          true,
	"石家庄":         true,
	"唐山":          true,
	"秦皇岛":         true,
	"邯郸":          true,
	"邢台":          true,
	"保定":          true,
	"张家口":         true,
	"承德":          true,
	"沧州":          true,
	"廊坊":          true,
	"衡水":          true,
	"太原":          true,
	"大同":          true,
	"阳泉":          true,
	"长治":          true,
	"晋城":          true,
	"朔州":          true,
	"晋中":          true,
	"运城":          true,
	"忻州":          true,
	"临汾":          true,
	"吕梁":          true,
	"呼和浩特":        true,
	"包头":          true,
	"乌海":          true,
	"赤峰":          true,
	"通辽":          true,
	"鄂尔多斯":        true,
	"呼伦贝尔":        true,
	"巴彦淖尔":        true,
	"乌兰察布":        true,
	"兴安盟":         true,
	"锡林郭勒盟":       true,
	"阿拉善盟":        true,
	"沈阳":          true,
	"大连":          true,
	"鞍山":          true,
	"抚顺":          true,
	"本溪":          true,
	"丹东":          true,
	"锦州":          true,
	"营口":          true,
	"阜新":          true,
	"辽阳":          true,
	"盘锦":          true,
	"铁岭":          true,
	"朝阳":          true,
	"葫芦岛":         true,
	"长春":          true,
	"吉林":          true,
	"四平":          true,
	"辽源":          true,
	"通化":          true,
	"白山":          true,
	"松原":          true,
	"白城":          true,
	"延边朝鲜族自治州":    true,
	"哈尔滨":         true,
	"齐齐哈尔":        true,
	"鸡西":          true,
	"鹤岗":          true,
	"双鸭山":         true,
	"大庆":          true,
	"伊春":          true,
	"佳木斯":         true,
	"七台河":         true,
	"牡丹江":         true,
	"黑河":          true,
	"绥化":          true,
	"大兴安岭地区":      true,
	"南京":          true,
	"无锡":          true,
	"徐州":          true,
	"常州":          true,
	"苏州":          true,
	"南通":          true,
	"连云港":         true,
	"淮安":          true,
	"盐城":          true,
	"扬州":          true,
	"镇江":          true,
	"泰州":          true,
	"宿迁":          true,
	"杭州":          true,
	"宁波":          true,
	"温州":          true,
	"嘉兴":          true,
	"湖州":          true,
	"绍兴":          true,
	"金华":          true,
	"衢州":          true,
	"舟山":          true,
	"台州":          true,
	"丽水":          true,
	"合肥":          true,
	"芜湖":          true,
	"蚌埠":          true,
	"淮南":          true,
	"马鞍山":         true,
	"淮北":          true,
	"铜陵":          true,
	"安庆":          true,
	"黄山":          true,
	"滁州":          true,
	"阜阳":          true,
	"宿州":          true,
	"六安":          true,
	"亳州":          true,
	"池州":          true,
	"宣城":          true,
	"福州":          true,
	"厦门":          true,
	"莆田":          true,
	"三明":          true,
	"泉州":          true,
	"漳州":          true,
	"南平":          true,
	"龙岩":          true,
	"宁德":          true,
	"南昌":          true,
	"景德镇":         true,
	"萍乡":          true,
	"九江":          true,
	"新余":          true,
	"鹰潭":          true,
	"赣州":          true,
	"吉安":          true,
	"宜春":          true,
	"抚州":          true,
	"上饶":          true,
	"济南":          true,
	"青岛":          true,
	"淄博":          true,
	"枣庄":          true,
	"东营":          true,
	"烟台":          true,
	"潍坊":          true,
	"济宁":          true,
	"泰安":          true,
	"威海":          true,
	"日照":          true,
	"临沂":          true,
	"德州":          true,
	"聊城":          true,
	"滨州":          true,
	"菏泽":          true,
	"郑州":          true,
	"开封":          true,
	"洛阳":          true,
	"平顶山":         true,
	"安阳":          true,
	"鹤壁":          true,
	"新乡":          true,
	"焦作":          true,
	"濮阳":          true,
	"许昌":          true,
	"漯河":          true,
	"三门峡":         true,
	"南阳":          true,
	"商丘":          true,
	"信阳":          true,
	"周口":          true,
	"驻马店":         true,
	"武汉":          true,
	"黄石":          true,
	"十堰":          true,
	"宜昌":          true,
	"襄阳":          true,
	"鄂州":          true,
	"荆门":          true,
	"孝感":          true,
	"荆州":          true,
	"黄冈":          true,
	"咸宁":          true,
	"随州":          true,
	"恩施土家族苗族自治州":  true,
	"长沙":          true,
	"株洲":          true,
	"湘潭":          true,
	"衡阳":          true,
	"邵阳":          true,
	"岳阳":          true,
	"常德":          true,
	"张家界":         true,
	"益阳":          true,
	"郴州":          true,
	"永州":          true,
	"怀化":          true,
	"娄底":          true,
	"湘西土家族苗族自治州":  true,
	"广州":          true,
	"韶关":          true,
	"深圳":          true,
	"珠海":          true,
	"汕头":          true,
	"佛山":          true,
	"江门":          true,
	"湛江":          true,
	"茂名":          true,
	"肇庆":          true,
	"惠州":          true,
	"梅州":          true,
	"汕尾":          true,
	"河源":          true,
	"阳江":          true,
	"清远":          true,
	"东莞":          true,
	"中山":          true,
	"潮州":          true,
	"揭阳":          true,
	"云浮":          true,
	"南宁":          true,
	"柳州":          true,
	"桂林":          true,
	"梧州":          true,
	"北海":          true,
	"防城港":         true,
	"钦州":          true,
	"贵港":          true,
	"玉林":          true,
	"百色":          true,
	"贺州":          true,
	"河池":          true,
	"来宾":          true,
	"崇左":          true,
	"海口":          true,
	"三亚":          true,
	"三沙":          true,
	"儋州":          true,
	"成都":          true,
	"自贡":          true,
	"攀枝花":         true,
	"泸州":          true,
	"德阳":          true,
	"绵阳":          true,
	"广元":          true,
	"遂宁":          true,
	"内江":          true,
	"乐山":          true,
	"南充":          true,
	"眉山":          true,
	"宜宾":          true,
	"广安":          true,
	"达州":          true,
	"雅安":          true,
	"巴中":          true,
	"资阳":          true,
	"阿坝藏族羌族自治州":   true,
	"甘孜藏族自治州":     true,
	"凉山彝族自治州":     true,
	"贵阳":          true,
	"六盘水":         true,
	"遵义":          true,
	"安顺":          true,
	"毕节":          true,
	"铜仁":          true,
	"黔西南布依族苗族自治州": true,
	"黔东南苗族侗族自治州":  true,
	"黔南布依族苗族自治州":  true,
	"昆明":          true,
	"曲靖":          true,
	"玉溪":          true,
	"保山":          true,
	"昭通":          true,
	"丽江":          true,
	"普洱":          true,
	"临沧":          true,
	"楚雄彝族自治州":     true,
	"红河哈尼族彝族自治州":  true,
	"文山壮族苗族自治州":   true,
	"西双版纳傣族自治州":   true,
	"大理白族自治州":     true,
	"德宏傣族景颇族自治州":  true,
	"怒江傈僳族自治州":    true,
	"迪庆藏族自治州":     true,
	"拉萨":          true,
	"日喀则":         true,
	"昌都":          true,
	"林芝":          true,
	"山南":          true,
	"那曲":          true,
	"阿里地区":        true,
	"西安":          true,
	"铜川":          true,
	"宝鸡":          true,
	"咸阳":          true,
	"渭南":          true,
	"延安":          true,
	"汉中":          true,
	"榆林":          true,
	"安康":          true,
	"商洛":          true,
	"兰州":          true,
	"嘉峪关":         true,
	"金昌":          true,
	"白银":          true,
	"天水":          true,
	"武威":          true,
	"张掖":          true,
	"平凉":          true,
	"酒泉":          true,
	"庆阳":          true,
	"定西":          true,
	"陇南":          true,
	"临夏回族自治州":     true,
	"甘南藏族自治州":     true,
	"西宁":          true,
	"海东":          true,
	"海北藏族自治州":     true,
	"黄南藏族自治州":     true,
	"海南藏族自治州":     true,
	"果洛藏族自治州":     true,
	"玉树藏族自治州":     true,
	"海西蒙古族藏族自治州":  true,
	"银川":          true,
	"石嘴山":         true,
	"吴忠":          true,
	"固原":          true,
	"中卫":          true,
	"乌鲁木齐":        true,
	"克拉玛依":        true,
	"吐鲁番":         true,
	"哈密":          true,
	"昌吉回族自治州":     true,
	"博尔塔拉蒙古自治州":   true,
	"巴音郭楞蒙古自治州":   true,
	"阿克苏地区":       true,
	"克孜勒苏柯尔克孜自治州": true,
	"喀什地区":        true,
	"和田地区":        true,
	"伊犁哈萨克自治州":    true,
	"塔城地区":        true,
	"阿勒泰地区":       true,
	"迁安":          true,
}
