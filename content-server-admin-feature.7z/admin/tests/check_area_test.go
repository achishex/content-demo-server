package tests

import (
	"content_svr/db/dao"
	"context"
	"fmt"
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestCheckArea(t *testing.T) {
	t.Run("== start time , == end time", func(t *testing.T) {
		e := c.Invoke(func(managerDB *dao.ManagerDB) error {
			a := managerDB.MzRobot
			ctx := context.Background()
			//userID := int64(4725532565906432)
			number, ok, err := a.CheckArea(ctx, 1698811200000, 1703952000000, 2)
			fmt.Println(number, ok, err)
			return err
		})
		assert.Nil(t, e)
	})

	t.Run("> start time , == end time", func(t *testing.T) {
		e := c.Invoke(func(managerDB *dao.ManagerDB) error {
			a := managerDB.MzRobot
			ctx := context.Background()
			//userID := int64(4725532565906432)
			number, ok, err := a.CheckArea(ctx, 1698831200000, 1703952000000, 2)
			fmt.Println(number, ok, err)
			return err
		})
		assert.Nil(t, e)
	})

	t.Run("== start time , < end time", func(t *testing.T) {
		e := c.Invoke(func(managerDB *dao.ManagerDB) error {
			a := managerDB.MzRobot
			ctx := context.Background()
			//userID := int64(4725532565906432)
			number, ok, err := a.CheckArea(ctx, 1698811200000, 1701952000000, 2)
			fmt.Println(number, ok, err)
			return err
		})
		assert.Nil(t, e)
	})

	t.Run("> start time , < end time", func(t *testing.T) {
		e := c.Invoke(func(managerDB *dao.ManagerDB) error {
			a := managerDB.MzRobot
			ctx := context.Background()
			//userID := int64(4725532565906432)
			number, ok, err := a.CheckArea(ctx, 1698831200000, 1701952000000, 2)
			fmt.Println(number, ok, err)
			return err
		})
		assert.Nil(t, e)
	})

	t.Run("< start time , < end time", func(t *testing.T) {
		e := c.Invoke(func(managerDB *dao.ManagerDB) error {
			a := managerDB.MzRobot
			ctx := context.Background()
			//userID := int64(4725532565906432)
			number, ok, err := a.CheckArea(ctx, 1598811200000, 1701952000000, 2)
			fmt.Println(number, ok, err)
			return err
		})
		assert.Nil(t, e)
	})

	t.Run("不在范围内", func(t *testing.T) {
		e := c.Invoke(func(managerDB *dao.ManagerDB) error {
			a := managerDB.MzRobot
			ctx := context.Background()
			//userID := int64(4725532565906432)
			number, ok, err := a.CheckArea(ctx, 1598811200000, 1601952000000, 2)
			fmt.Println(number, ok, err)
			return err
		})
		assert.Nil(t, e)
	})
}
