package job

import (
	"content_svr/config"
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/internal/kafka_proxy"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbconst"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"github.com/gookit/goutil/timex"
	"go.mongodb.org/mongo-driver/bson"
	"strconv"
	"time"
)

// 合伙人计划，每天22点瓜分奖池
func PartnerCarveUp(writer, reader *dao.ManagerDB, dataCache data_cache.IDataCacheMng, kafkaProxy kafka_proxy.IKafkaProxy, contentMng content_mng.IContentMng) {
	var (
		ctx       = context.Background()
		todayPond = float64(0)
	)

	//今日奖池
	yesterday := timex.DateFormat(timex.Now().SubDay(1).T(), "Y-m-d")
	csj, err := reader.CsjAdvertisementData.FindAll(ctx, bson.M{"date": yesterday})
	if err != nil {
		logger.Errorf(ctx, "瓜分奖池:获取昨日奖池失败, day:%v", yesterday)
		return
	}
	for _, v := range csj {
		todayPond += v.Revenue
	}
	if todayPond <= 0 {
		logger.Errorf(ctx, "瓜分奖池:奖池为空, day:%v", yesterday)
		return
	}

	//广告已领取金额
	adReward := sumAdReward(ctx, reader)
	todayPond = todayPond - adReward
	if todayPond <= 0 {
		logger.Errorf(ctx, "瓜分奖池:减去广告领取后奖池为空, day:%v, adReward: %v", yesterday, adReward)
		return
	}

	//合伙人签到人列表
	partnerList, err := reader.PartnerDailySignIn.FindAll(ctx,
		bson.M{"day": timex.DateFormat(time.Now(), "Ymd"), "is_award": false},
	)
	if err != nil {
		logger.Infof(ctx, "瓜分奖池:获取合伙人签到列表失败。day:%v", timex.DateFormat(time.Now(), "Ymd"))
		return
	}
	expectPeopleNum := len(partnerList)
	if expectPeopleNum <= 0 {
		logger.Infof(ctx, "瓜分奖池:合伙人签到人数为0，不瓜分。day:%v", yesterday)
		return
	}

	todayPond = todayPond * config.ServerConfig.PartnerConfig.PondRate
	maxPond := float64(config.ServerConfig.PartnerConfig.PondMaxAmount)
	if todayPond > 0 && todayPond > maxPond {
		todayPond = maxPond
		logger.Errorf(ctx, "瓜分奖池:奖池大于上限，大于200, day:%v，真实奖池：%v", yesterday, todayPond)
	}

	//瓜分金额
	todayExpectIncome, _ := strconv.ParseFloat(fmt.Sprintf("%.2f", todayPond/float64(expectPeopleNum)), 64)
	logger.Infof(ctx, "瓜分奖池:奖池：%v, 合伙人数：%v, 瓜分金额：%v", todayPond, expectPeopleNum, todayExpectIncome)

	for _, p := range partnerList {
		partner, err := reader.Partner.FindOne(ctx, bson.M{"user_id": p.UserId})
		if err != nil || partner == nil {
			logger.Errorf(ctx, "瓜分奖池:获取合伙人信息失败,userId: %v", p.UserId)
			continue
		}

		userInfo, err := dataCache.GetUserInfoLocal(ctx, p.UserId, true)
		if userInfo == nil || err != nil {
			logger.Errorf(ctx, "瓜分奖池:获取用户信息失败,userId: %v，err:%v", p.UserId, err)
			continue
		}
		if userInfo.IsInBlackHouse || userInfo.UserInfoDbModel.GetStatus() == 0 || userInfo.UserInfoDbModel.GetEnabled() != 1 {
			logger.Errorf(ctx, "瓜分奖池:小黑屋/用户注销/用户被封禁：不予发放奖励, userId: %v, IsInBlackHouse:%v, Status:%v, Enabled:%v",
				p.UserId, userInfo.IsInBlackHouse, userInfo.UserInfoDbModel.GetStatus(), userInfo.UserInfoDbModel.GetEnabled())
			continue
		}

		totalIncome := partner.TotalIncome + uint64(todayExpectIncome*100)
		if err != nil {
			logger.Errorf(ctx, "瓜分奖池:数据转换错误，userId: %v, err:%v", p.UserId, err)
			continue
		}
		if _, err := writer.Partner.UpdateMap(ctx,
			bson.M{"_id": partner.ID, "user_id": partner.UserId},
			bson.M{"total_income": totalIncome, "reward_popup": true, "update_time": time.Now().UnixMilli()},
		); err != nil {
			logger.Errorf(ctx, "瓜分奖池:更新合伙人累计获取失败，userId:%v, todayExpectIncome: %v, err:%v", p.UserId, todayExpectIncome*100, err)
			continue
		}

		if _, err := writer.PartnerDailySignIn.UpdateMap(ctx,
			bson.M{"_id": p.ID},
			bson.M{"is_award": true, "update_time": time.Now().UnixMilli()},
		); err != nil {
			logger.Errorf(ctx, "瓜分奖池: 更新奖励状态失败,userId: %v, day: %v", p.UserId, timex.DateFormat(time.Now(), "Ymd"))
			continue
		}

		//奖励
		sc := content_mng.NewSuperiorContentInstance(&content_mng.ContentMng{
			DataCache:  dataCache,
			KafkaProxy: kafkaProxy,
		}, nil, p.UserId)
		if err := sc.WriteNewItem(ctx, 0, p.UserId, "", todayExpectIncome, model.PartnerCarveUp); err != nil {
			logger.Errorf(ctx, "瓜分奖池:WriteNewItem：reward:%v, error: %v", todayExpectIncome, err)
			continue
		}

		//钱包消息
		go func(userId int64, reward float64) {
			defer func() {
				if err := recover(); err != nil {
					logger.Errorf(ctx, "瓜分奖池:SendWalletMsg:recover err: %v", err)
				}
			}()

			canWithdrawAward, _ := contentMng.GetCanWithdrawAwardByUserId(ctx, userId)
			msgData := &pbapi.Wallet{
				Type:       proto.Int32(const_busi.WalletMsgTypeAward),
				Amount:     proto.String(strconv.FormatFloat(reward, 'f', 2, 64)),
				Balance:    proto.String(strconv.FormatFloat(canWithdrawAward, 'f', 2, 64)),
				Desc:       proto.String("合伙人计划-瓜分奖池"),
				CreateTime: proto.Int64(time.Now().UnixMilli()),
			}
			if err := contentMng.SendWalletMsg(ctx, userId, int32(pbconst.MessageTypeEnum_msg_type_wallet_award_notice), "您有一笔奖励金入账，快去看看吧！", msgData); err != nil {
				logger.Errorf(ctx, "瓜分奖池:sendWalletMsg error: %v", err)
				return
			}
		}(p.UserId, todayExpectIncome)
	}

}

// 广告领取总和
func sumAdReward(ctx context.Context, reader *dao.ManagerDB) float64 {
	timeStart := timex.DayStart(timex.Now().SubDay(1).T()).UnixMilli()
	timeEnd := timex.DayStart(time.Now()).UnixMilli()

	var data []struct {
		Total float64 `bson:"total"`
	}

	pipeline := []bson.M{
		{"$match": bson.M{
			"create_time": bson.M{"$gte": timeStart, "$lt": timeEnd},
			"type":        bson.M{"$in": []int{model.AwardSportAd, model.AwardStarSignAd, model.AwardSignAd}},
		}},
		{"$group": bson.M{
			"_id":   nil,
			"total": bson.M{"$sum": "$award"},
		}},
	}

	if err := reader.SuperiorContentAwardDetail.Aggregate(ctx, &data, pipeline); err != nil {
		logger.Errorf(ctx, "get ad reward error: %v", err)
		return 0
	}

	total := float64(0)
	for _, v := range data {
		total += v.Total
	}

	return total
}
