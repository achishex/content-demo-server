package mg_model

import (
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type IKoLaWithdrawDetailMgModel interface {
	InsertOne(ctx context.Context, item *pbmgdb.KoLaWithDrawDetail) error
	DeleteOneById(ctx context.Context, id int64) error
	GetLatestItemByUserId(ctx context.Context, userId int64) (*pbmgdb.KoLaWithDrawDetail, error)
	FindOneItem(ctx context.Context, filter bson.D) (*pbmgdb.KoLaWithDrawDetail, error)
	FindCountsByConds(ctx context.Context, filter bson.D) (int64, error)
}

type KoLaWithdrawDetailMgModelImpl struct {
	MgDB  *mongo.Database
	Table string
}

func NewKoLaWithdrawDetailMgModelImpl(db *mongo.Database) IKoLaWithdrawDetailMgModel {
	return &KoLaWithdrawDetailMgModelImpl{
		MgDB:  db,
		Table: "kola_withdraw_detail",
	}
}

func (impl *KoLaWithdrawDetailMgModelImpl) FindCountsByConds(ctx context.Context, filter bson.D) (int64, error) {
	coll := impl.MgDB.Collection(impl.Table)
	nums, err := coll.CountDocuments(ctx, filter)
	if err != nil {
		logger.Errorf(ctx, "find doc count fail, err: %v", err)
		return 0, err
	}
	return nums, nil
}
func (impl *KoLaWithdrawDetailMgModelImpl) GetLatestItemByUserId(ctx context.Context, userId int64) (*pbmgdb.KoLaWithDrawDetail, error) {
	coll := impl.MgDB.Collection(impl.Table)
	filter := bson.D{}
	filter = append(filter, bson.E{Key: "user_id", Value: userId})
	opts := options.Find()
	var sortExpand bson.D
	sortExpand = append(sortExpand, bson.E{Key: "_id", Value: const_busi.MongodbSortDes})
	opts.SetLimit(1)
	opts.SetSort(sortExpand)

	cursor, err := coll.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "find KoLaWithdrawDetailMgModel fail, err: %v", err)
		return nil, err
	}
	var result []*pbmgdb.KoLaWithDrawDetail
	for cursor.Next(ctx) {
		data := &pbmgdb.KoLaWithDrawDetail{}
		err = cursor.Decode(data)
		if err != nil {
			logger.Errorf(ctx, "get KoLaWithdrawDetailMgModel query result fail, err: %v", err)
			return nil, err
		}
		result = append(result, data)
	}
	if len(result) <= 0 {
		return nil, nil
	}
	return result[0], nil
}
func (impl *KoLaWithdrawDetailMgModelImpl) DeleteOneById(ctx context.Context, id int64) error {
	coll := impl.MgDB.Collection(impl.Table)
	filter := bson.M{"_id": id}
	_, err := coll.DeleteOne(ctx, filter)
	return err
}
func (impl *KoLaWithdrawDetailMgModelImpl) InsertOne(ctx context.Context, item *pbmgdb.KoLaWithDrawDetail) error {
	coll := impl.MgDB.Collection(impl.Table)
	_, err := coll.InsertOne(ctx, item)
	return err
}
func (impl *KoLaWithdrawDetailMgModelImpl) FindOneItem(ctx context.Context, filter bson.D) (*pbmgdb.KoLaWithDrawDetail, error) {
	w := &pbmgdb.KoLaWithDrawDetail{}
	result := impl.MgDB.Collection(impl.Table).FindOne(ctx, filter)
	err := result.Decode(w)
	if err != nil && err != mongo.ErrNoDocuments {
		return nil, err
	}
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}

	return w, nil
}
