package model

const SecretUserMedalInfoCollectionName = "secretUserMedalInfo"

type SecretUserMedalInfo struct {
	ID        int64 `json:"id,omitempty" bson:"_id,omitempty"`
	UserId    int64 `json:"userId,omitempty" bson:"userId,omitempty"`
	MedalId   int64 `json:"medalId,omitempty" bson:"medalId,omitempty"`
	Expire    int64 `json:"expire,omitempty" bson:"expire,omitempty"`
	Timestamp int64 `json:"timestamp,omitempty" bson:"timestamp,omitempty"` // ms级别
}
