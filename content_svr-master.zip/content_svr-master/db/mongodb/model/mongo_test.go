package model

import (
	"context"
	"testing"
)

type testConnect struct {
	User   string
	Passwd string
	Addr   string
	DBName string
}

func (c testConnect) GetURL() string {

	// mongodb://user:passwd@127.0.0.1:27017
	return "mongodb://platform:2wsx1qaz@119.29.185.233:27017/platform_test?authSource=admin&readPreference=secondaryPreferred"

}

func (c testConnect) GetDBName() string {
	return "platform_test"
}

func TestConnect(t *testing.T) {
	c := testConnect{}

	//var option mon.Option
	//
	//option(c.GetOption())

	robot := NewMzRobotModel(c)
	t.Log(robot.FindOne(context.Background(), map[string]interface{}{"user_id": 4510318690966528}))
}
