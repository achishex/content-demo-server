package svc

import (
	"content_svr/app/maozhua_admin_svr/api/internal/config"
	"content_svr/app/maozhua_admin_svr/api/internal/middleware"
	"content_svr/app/maozhua_admin_svr/api/internal/svc/shumei"
	"content_svr/app/maozhua_admin_svr/api/internal/svc/user_manage"
	"content_svr/app/maozhua_admin_svr/common/db"
	"content_svr/db/dao"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
	"content_svr/setting"
	"github.com/zeromicro/go-zero/rest"
)

type ServiceContext struct {
	Config config.Config

	AuthInterceptor rest.Middleware

	ManagerDB         *dao.ManagerDB
	ManagerOnlyReadDB *dao.ManagerDB

	UserManage *user_manage.UserManage

	RedisClient *query_rds.Manage

	Maozhua *setting.ServiceSetting

	ShuMei *shumei.ShuMei

	//ContentSvr *originManage.ContentSvr
}

func NewServiceContext(c config.Config) *ServiceContext {
	// 初始化数据库
	mysqlConn, err := db.ConnectMysql(c.MysqlConfig)
	if err != nil {
		panic(err)
	}
	mysqlOnlyReadConn, err := db.ConnectMysql(c.MysqlOnlyReadConfig)
	if err != nil {
		panic(err)
	}
	rds := db.InitRdsClient(c.RedisConfig.Host, c.RedisConfig.Pass)
	//mongoConn, err := mg_model.NewMongoDBInstance(cfg.ServerConfig.MongodbConfig)
	//if err != nil {
	//	panic(err)
	//}

	// 构建数据链接对象
	mysql := query.Use(mysqlConn)
	mongo := query_mng.NewQueryMng(c.MongoConfig)
	redisManage := query_rds.NewClient(rds, c.ProjectEnv)
	manageDB := dao.NewDbManager(mysql, mongo, redisManage)

	onlyReadMysql := query.Use(mysqlOnlyReadConn)
	onlyReadMongo := query_mng.NewQueryMng(c.MongoOnlyReadConfig)
	manageOnlyReadDB := dao.NewDbManager(onlyReadMysql, onlyReadMongo, redisManage)

	// 统一配置
	if err := setting.Initialize(rds, c.ProjectEnv); err != nil {
		panic(err)
	}

	return &ServiceContext{
		Config:          c,
		AuthInterceptor: middleware.NewAuthInterceptorMiddleware(redisManage.TokenAdmin).Handle(c.Mode),

		RedisClient:       redisManage,
		ManagerDB:         manageDB,
		ManagerOnlyReadDB: manageOnlyReadDB,
		Maozhua:           setting.Maozhua,
		ShuMei:            shumei.NewShuMeiSvc(c),

		//ContentSvr: originManage.NewContentSvr(mysqlConn, mongoConn, rds),
		UserManage: user_manage.NewUserManage(manageDB),
	}
}
