package query_mng

import (
	"content_svr/db/mongodb/model"
)

type QueryMng struct {
	MzRobot                      model.MzRobotModel
	WorksCommentDetail           model.WorksCommentDetailModel
	BackgroundImage              model.BackgroundImageModel
	SecretUserExtInfo            model.SecretUserExtInfoModel
	SecretMemberInfo             model.SecretMemberInfoModel
	SecretMemberDetail           model.SecretMemberDetailModel
	UserMemberStatistical        model.UserMemberStatisticalModel
	SmsRecord                    model.SmsRecordModel
	SecretAudit                  model.SecretAuditModel
	SecretActiveUser             model.SecretActiveUserModel
	SuperiorContentAwardDetail   model.SuperiorContentAwardDetailModel
	SecretReport                 model.SecretReportModel
	SecretReportUser             model.SecretReportUserModel
	SecretBlackHouse             model.SecretBlackHouseModel
	PersonalTalkMessageRecord    model.PersonalTalkMessageRecordModel
	SecretMedalInfo              model.SecretMedalInfoModel
	SecretUserMedalInfo          model.SecretUserMedalInfoModel
	PersonalPoliceInfo           model.PersonalPoliceInfoModel
	SecretUserActivityDaily      model.SecretUserActivityDailyModel
	SecretUserChannelDaily       model.SecretUserChannelDailyModel
	SecretUserRetainedStatistics model.SecretUserRetainedStatisticsModel
	SuperiorAwardDaily           model.SuperiorAwardDailyModel
}

func NewQueryMng(monCfg model.MonConfig) *QueryMng {
	return &QueryMng{
		MzRobot:                      model.NewMzRobotModel(monCfg),
		WorksCommentDetail:           model.NewWorksCommentDetailModel(monCfg),
		BackgroundImage:              model.NewBackgroundImageModel(monCfg),
		SecretUserExtInfo:            model.NewSecretUserExtInfoModel(monCfg),
		SecretMemberInfo:             model.NewSecretMemberInfoModel(monCfg),
		SecretMemberDetail:           model.NewSecretMemberDetailModel(monCfg),
		UserMemberStatistical:        model.NewUserMemberStatisticalModel(monCfg),
		SmsRecord:                    model.NewSmsRecordModel(monCfg),
		SecretAudit:                  model.NewSecretAuditModel(monCfg),
		SecretActiveUser:             model.NewSecretActiveUserModel(monCfg),
		SuperiorContentAwardDetail:   model.NewSuperiorContentAwardDetailModel(monCfg),
		SecretReport:                 model.NewSecretReportModel(monCfg),
		SecretReportUser:             model.NewSecretReportUserModel(monCfg),
		SecretBlackHouse:             model.NewSecretBlackHouseModel(monCfg),
		PersonalTalkMessageRecord:    model.NewPersonalTalkMessageRecordModel(monCfg),
		SecretMedalInfo:              model.NewSecretMedalInfoModel(monCfg),
		SecretUserMedalInfo:          model.NewSecretUserMedalInfoModel(monCfg),
		PersonalPoliceInfo:           model.NewPersonalPoliceInfoModel(monCfg),
		SecretUserActivityDaily:      model.NewSecretUserActivityDailyModel(monCfg),
		SecretUserChannelDaily:       model.NewSecretUserChannelDailyModel(monCfg),
		SecretUserRetainedStatistics: model.NewSecretUserRetainedStatisticsModel(monCfg),
		SuperiorAwardDaily:           model.NewSuperiorAwardDailyModel(monCfg),
	}
}
