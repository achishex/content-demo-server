#! /bin/bash

set -ex

SRV=${CI_BUILD_TAG%-*}
VER=${CI_BUILD_TAG##*-}

function build-admin-svr() {
    SRV=$1
    VER=$2
    IMAGE_NAME="mirrors-internal.52mengdong.com/maozhua_admin_svr:$VER"
    (cd ./build/maozhua_admin_svr && docker build -t $IMAGE_NAME .)
    docker push $IMAGE_NAME
    echo "BUILD_IMAGE_NAME=$IMAGE_NAME" > ci_env.txt
    echo "BUILD_SVR=maozhua_admin_svr" >> ci_env.txt
    echo "BUILD_VER=$VER" >> ci_env.txt
    env >> ci_env.txt
    curl -X POST -H X-Bot-Token:B6s1BrVbYJ2YuWzR https://cicd-dev.52mengdong.com/v1/upload_ci_env --data-binary @ci_env.txt || exit 0
}

function build-content-svr(){
    SRV=$1
    VER=$2
    IMAGE_NAME="mirrors-internal.52mengdong.com/$SRV:$VER"
    (cd ./build/content_svr && docker build -t $IMAGE_NAME .)
    docker push $IMAGE_NAME
    echo "BUILD_IMAGE_NAME=$IMAGE_NAME" > ci_env.txt
    echo "BUILD_SVR=$SRV" >> ci_env.txt
    echo "BUILD_VER=$VER" >> ci_env.txt
    env >> ci_env.txt
    curl -X POST -H X-Bot-Token:B6s1BrVbYJ2YuWzR https://cicd-dev.52mengdong.com/v1/upload_ci_env --data-binary @ci_env.txt || exit 0
}

if [[ $CI_COMMIT_REF_NAME == "develop" ]]; then
  SRV="content_svr"
  VER=`date +"%Y%m%d_%H%M%S"`
  echo "build $SRV, version: $VER"
  build-content-svr $SRV $VER
fi

if [[ $SRV == "content_svr" ]] && [[ -n $VER ]]; then
  echo "build $SRV, version: $VER"
  build-content-svr $SRV $VER
fi


if [[ $SRV == "admin" ]] && [[ -n $VER ]]; then
  echo "build maozhua_admin_svr, version: $VER"
  build-admin-svr "maozhua_admin_svr"  "$VER"
  exit 0
fi

if [[ $CI_COMMIT_REF_NAME == "admin_dev"  ]]; then
  VER=`date +"%Y%m%d_%H%M%S"`
  echo "build maozhua_admin_svr, version: $VER"
  build-admin-svr "maozhua_admin_svr" $VER
  exit 0
fi
