package content_mng

import (
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
)

func (p *ContentMng) RemoveTimeoutWorks(ctx context.Context) error {
	//curTimeMs := utils.GetCurTsMs()

	workIdStrlist := make([]string, 0)
	var page, size int64 = 0, 100
	for {
		// 批量捞
		workIdTsDict, LatestTsMs, err := p.DataCache.RangeTsWorkPoolRedis(ctx, page*size, (page+1)*size)
		if err != nil {
			logger.Errorf(ctx, "RangeTsWorkPoolRedis failed")
			return err
		}

		// 检查是否捞空了
		if len(workIdTsDict) == 0 {
			logger.Infof(ctx, "len(workIdTsDict) = 0")
			break
		}

		page = page + 1
		// 捞出来的内容是否超过了分发时间
		if utils.GetCurTsMs()-LatestTsMs > 24*60*60*1000 { // 24h之前的内容，全部删除。
			for workIdStr, tsMs := range workIdTsDict {
				//待删除
				workIdStrlist = append(workIdStrlist, workIdStr)
				logger.Infof(ctx, "to be removed workids, workIdStr=%v, tsMs=%v", workIdStr, utils.GenTimeFromTsMs(tsMs))
			}
			continue
		}
	}

	// 删除数据
	page, size = 0, 100
	for {
		begin := page * size
		end := (page + 1) * size
		if end > int64(len(workIdStrlist)) {
			end = int64(len(workIdStrlist))
		}
		subWorkStrList := workIdStrlist[begin:end]
		if len(subWorkStrList) == 0 {
			break
		}
		logger.Infof(ctx, "RemoveTimeoutWorks, remove subWorkStrList.len=%v, page=%v,begin=%v,end=%v", len(subWorkStrList), page, begin, end)
		p.DataCache.AsyncRemoveFromTsWorkPoolRedis(ctx, subWorkStrList)
		page++
	}
	logger.Infof(ctx, "RemoveTimeoutWorks, workIdStrlist.len=%v", len(workIdStrlist))
	return nil
}
