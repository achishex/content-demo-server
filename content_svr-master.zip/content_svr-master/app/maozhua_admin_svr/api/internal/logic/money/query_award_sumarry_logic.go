package money

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"context"
	"go.mongodb.org/mongo-driver/mongo/options"

	"github.com/zeromicro/go-zero/core/logx"
)

type QueryAwardSumarryLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewQueryAwardSumarryLogic(ctx context.Context, svcCtx *svc.ServiceContext) *QueryAwardSumarryLogic {
	return &QueryAwardSumarryLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *QueryAwardSumarryLogic) QueryAwardSumarry(req *types.AwardSumarryReq) (resp *types.AwardSumarryResp, err error) {

	firstTotalAward := 0.0
	{
		filter := make(map[string]interface{})
		filter["create_time_begin"] = req.CreateTimeBegin
		filter["create_time_end"] = req.CreateTimeEnd
		filter["type"] = 1

		//var limit int64 = 10000
		opt := &options.FindOptions{}
		//opt.Skip = &offset
		//opt.Limit = &limit
		//opt.Sort = d.orderMongo()

		list, _ := l.svcCtx.WriteDB.SuperiorContentAwardDetail.FindAll(l.ctx, filter, opt)
		for _, item := range list {
			//if item.Award != 0.2 {
			//	firstTotalAward = firstTotalAward + item.Award
			//} else {
			//	firstTotalAward = firstTotalAward + item.Award
			//}
			firstTotalAward = firstTotalAward + item.Award
		}
	}

	superiorTotalAward := 0.0
	{
		filter := make(map[string]interface{})
		filter["create_time_begin"] = req.CreateTimeBegin
		filter["create_time_end"] = req.CreateTimeEnd
		filter["type"] = 3

		opt := &options.FindOptions{}

		list, _ := l.svcCtx.WriteDB.SuperiorContentAwardDetail.FindAll(l.ctx, filter, opt)
		for _, item := range list {
			superiorTotalAward = superiorTotalAward + item.Award
		}
	}

	resp = &types.AwardSumarryResp{
		FirstTotalAward:    firstTotalAward,
		SuperiorTotalAward: superiorTotalAward,
	}

	return resp, nil
}
