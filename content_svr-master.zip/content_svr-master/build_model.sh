#!/bin/bash

GO111MODULE=on go install github.com/zeromicro/go-zero/tools/goctl@v1.6.0

# 构建mysql
go build -ldflags "-s -w" -o ./gen ./deploy/gentools

mysqlModel=(
user_info
personal_bottle_works
operator_tab
work_object_attr
order_info
wx_reward_log
)

mysqlTables=""
for name in "${mysqlModel[@]}"; do
#  if [[ "$mysqlTables" != *"$name"* ]]; then # 检查 mongoTables 字符串是否包含当前元素 name。
    if [[ -z "$mysqlTables" ]]; then        # 检查是否为空字符串，如果是则直接赋值给 mongoTables 变量。
      mysqlTables="$name"
    else                                   # 如果不为空，则在已有的字符串后面添加逗号和当前元素。
      mysqlTables+=",$name"
    fi
#  fi
done


# 构建 mongo
mongoModel=(
MzRobot
WorksCommentDetail
BackgroundImage
SecretUserExtInfo
SecretMemberInfo
SecretMemberDetail
UserMemberStatistical
SmsRecord
SecretAudit
SecretActiveUser
SuperiorAwardDaily
SuperiorContentAwardDetail
UserRewardMoneyActivity
SecretReport
SecretReportUser
SecretBlackHouse
PersonalTalkMessageRecord
SecretMedalInfo
SecretUserMedalInfo
PersonalPoliceInfo
SecretUserActivityDaily
SecretUserChannelDaily
SecretUserRetainedStatistics
PersonalPoliceDailyData
CsjAdvertisementData
SecretGame
SecretGameOrder
GameStatistical
SecretGameStatisticDaily
SecretMeme
AppAdvertisement
secretUserIdentificationCard
personalUserNotificationMgModel
partner
partner_daily_sign_in
partner_invite
intraCity
provinceCity
ZooGameUserInfo
ZooGamePayInfo
ZooGamePayDaily
)

mongoTables=""
for name in "${mongoModel[@]}"; do
#  if [[ "$mongoTables" != *"$name"* ]]; then # 检查 mongoTables 字符串是否包含当前元素 name。
    if [[ -z "$mongoTables" ]]; then        # 检查是否为空字符串，如果是则直接赋值给 mongoTables 变量。
      mongoTables="$name"
    else                                   # 如果不为空，则在已有的字符串后面添加逗号和当前元素。
      mongoTables+=",$name"
    fi
#  fi
done


echo "./gen -t ./deploy/gentools/tpl -mysql $mysqlTables -mongo $mongoTables"
./gen -p content_svr -t ./deploy/template  -mysql $mysqlTables -mongo $mongoTables -dao
