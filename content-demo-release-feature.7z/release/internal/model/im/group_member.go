package im

import (
	"content_svr/protobuf/pbdb"
	"content_svr/pub/errors"
	"context"
	"gorm.io/gorm"
)

type IImGroupMemberDbModelModel interface {
	ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.GroupMemberDbModel, error)
	HasJoined(ctx context.Context, groupId, userId string) (bool, error)
}

type GroupMemberDbModelModelImpl struct {
	DB *gorm.DB
}

func NewImGroupMemberDbModelModel(db *gorm.DB) IImGroupMemberDbModelModel {
	return &GroupMemberDbModelModelImpl{DB: db}
}

func (impl *GroupMemberDbModelModelImpl) ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.GroupMemberDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.GroupMemberDbModel
	result := impl.DB.WithContext(ctx).Table("group_members").
		Limit(int(size)).Offset(int(offset)).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *GroupMemberDbModelModelImpl) HasJoined(ctx context.Context, groupId, userId string) (bool, error) {
	var c int64
	if err := impl.DB.WithContext(ctx).Table("group_members").Where("group_id = ? AND user_id = ?", groupId, userId).Count(&c).Error; err != nil {
		return false, err
	}
	if c > 0 {
		return true, nil
	}
	return false, nil
}
