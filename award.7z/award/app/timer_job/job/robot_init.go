package job

var (
	// RobotServerControl 飞书serve群里的机器人
	RobotServerControl robotServerControl
	// RobotBossControl 飞书正式群里的机器人
	RobotBossControl robotBossControl
)

type robotServerControl struct {
	robotControl
}

func InitServeRobot() {
	RobotServerControl = robotServerControl{}
	RobotServerControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/c02670dc-de16-4af0-a234-d90af25c6f13"
	RobotServerControl.msgChan = make(chan Message, 100)

	go RobotServerControl.monitor()
}

type robotBossControl struct {
	robotControl
}

func InitBossRobot() {
	RobotBossControl = robotBossControl{}
	//RobotBossControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/c02670dc-de16-4af0-a234-d90af25c6f13" // server群，测试用
	RobotBossControl.webUrl = "https://open.feishu.cn/open-apis/bot/v2/hook/afd15198-34ea-4788-a306-2e94630458de" // 正式群，不要乱推数据
	RobotBossControl.msgChan = make(chan Message, 100)

	go RobotBossControl.monitor()
}
