package middleware

import (
	"content_svr/internal/notify_mng"
	"content_svr/pub/logger"
	"content_svr/pub/utils/panichelper"
	"github.com/gin-gonic/gin"
)

func InactiveNotify(c *notify_mng.InactiveUserNotifyComp) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		ctx.Next()

		// 只监听一个接口
		if ctx.Request.URL.Path == "/platform/secret/chitchat/works" {
			go inactiveNotify(ctx.Copy(), c)
		}
	}
}

func inactiveNotify(ctx *gin.Context, c *notify_mng.InactiveUserNotifyComp) {
	defer panichelper.PanicRecover(ctx)

	userID := GetUserID(ctx)
	if userID <= 0 {
		return
	}

	if err := c.SubmitNotifyTask(ctx, userID); err != nil {
		logger.Errorf(ctx, "SubmitNotifyTask fail, userID: %v, err: %v", userID, err)
	}
}
