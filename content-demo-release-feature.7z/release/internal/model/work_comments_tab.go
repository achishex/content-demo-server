package model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbdb"
	"content_svr/pub/errors"
	"context"
	"github.com/gogo/protobuf/proto"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
	"gorm.io/plugin/dbresolver"
)

type IWorkCommentStatusDbModel interface {
	SetStatus(ctx context.Context, req *pbapi.WorkCommentEnableReq) error
	BulkGetStatus(ctx context.Context, works []int64) (*map[int64]int32, error)
}

type WorkCommentStatusDbImpl struct {
	DB *gorm.DB
}

func NewWorkCommentStatusDbModelImpl(db *gorm.DB) IWorkCommentStatusDbModel {
	return &WorkCommentStatusDbImpl{DB: db}
}
func (p *WorkCommentStatusDbImpl) table() string {
	return "works_comment_status"
}

func (p *WorkCommentStatusDbImpl) SetStatus(ctx context.Context, req *pbapi.WorkCommentEnableReq) error {
	model := &pbdb.WorkCommentStatusDbModel{WorkId: proto.Int64(req.GetWorkId()), Enable: proto.Int32(req.GetOp())}
	result := p.DB.Table(p.table()).Clauses(clause.OnConflict{Columns: []clause.Column{{Name: "work_id"}},
		DoUpdates: clause.Assignments(map[string]interface{}{"enable": req.GetOp()}),
	}).Create(&model)

	return errors.Wrap(result.Error)
}

func (p *WorkCommentStatusDbImpl) BulkGetStatus(ctx context.Context, works []int64) (*map[int64]int32, error) {
	if len(works) <= 0 {
		return nil, errors.New("input empty")
	}
	//
	comment_status := []*pbdb.WorkCommentStatusDbModel{}
	result := p.DB.WithContext(ctx).Clauses(dbresolver.Write).Table(p.table()).Where("work_id IN (?)", works).Find(&comment_status)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	ret := make(map[int64]int32)
	for _, v := range comment_status {
		if v == nil {
			continue
		}
		ret[v.GetWorkId()] = v.GetEnable()
	}
	return &ret, nil
}
