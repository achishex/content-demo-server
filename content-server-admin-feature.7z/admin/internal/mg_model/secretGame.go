package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretGameMgModel interface {
	GetByAppKey(ctx context.Context, appKey string) (*pbmgdb.SecretGameMgDbModel, error)
	GetByGameId(ctx context.Context, gameId string) (*pbmgdb.SecretGameMgDbModel, error)
	Bind(ctx context.Context, data *pbmgdb.SecretGameMgDbModel, options *options.InsertOneOptions) error
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.SecretGameMgDbModel, error)
}

type SecretGame struct {
	MgDB  *mongo.Database
	Table string
}

func NewSecretGameMgModelImpl(db *mongo.Database) ISecretGameMgModel {
	return &SecretGame{
		MgDB:  db,
		Table: "secretGame",
	}
}

func (g *SecretGame) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *SecretGame) GetByAppKey(ctx context.Context, appKey string) (*pbmgdb.SecretGameMgDbModel, error) {
	var v *pbmgdb.SecretGameMgDbModel
	err := g.coll().FindOne(ctx, bson.M{"app_key": appKey}).Decode(&v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretGame GetByAppKey failed. appKey=%v", appKey), err)
		return nil, err
	}
	return v, err
}

func (g *SecretGame) GetByGameId(ctx context.Context, gameId string) (*pbmgdb.SecretGameMgDbModel, error) {
	var v *pbmgdb.SecretGameMgDbModel
	err := g.coll().FindOne(ctx, bson.M{"game_id": gameId}).Decode(&v)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretGame GetByAppKey failed. gameId=%v", gameId), err)
		return nil, err
	}
	return v, err
}

func (g *SecretGame) Bind(ctx context.Context, data *pbmgdb.SecretGameMgDbModel, options *options.InsertOneOptions) error {
	_, err := g.coll().InsertOne(ctx, data)

	if err != nil {
		logger.Errorf(ctx, "SecretGame:Bind error : %v", err)
		return err
	}

	return nil
}

func (g *SecretGame) Find(ctx context.Context, filter any, options ...*options.FindOptions) ([]*pbmgdb.SecretGameMgDbModel, error) {
	find, err := g.coll().Find(ctx, filter, options...)
	if err != nil {
		return nil, err
	}

	retItems := make([]*pbmgdb.SecretGameMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.SecretGameMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretGameMgDbModel failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}
