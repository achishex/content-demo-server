package advertisement

import (
	"content_svr/db/mongodb/model"
)

const (
	unknown   = 0
	launching = 1 // 投放中
	started   = 2 // 未开始
	ended     = 3 // 已结束
	paused    = 4 // 已暂停
)

func getLaunchStatus(now int64, ad model.AppAdvertisement) int64 {
	var timeScope bool
	if now >= ad.StartTime && now <= ad.EndTime {
		timeScope = true
	}

	enable := ad.Enable
	switch {
	case enable && timeScope:
		return launching
	case enable && !timeScope:
		return started
	case !enable && !timeScope:
		return ended
	case !enable && timeScope:
		return paused
	default:
		return unknown
	}
}
