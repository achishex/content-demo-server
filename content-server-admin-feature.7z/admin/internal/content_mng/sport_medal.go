package content_mng

import (
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"time"
)

func (p *ContentMng) SportMedalLogic(ctx context.Context, header *pbapi.HttpHeaderInfo) error {
	nowTm := time.Now()
	loginUserInfo, _ := p.getUserInfo(ctx, header)
	activityPhone := getActivityPhone(nowTm)
	activityEnd := getActivityEndTime(nowTm)

	eqConds := map[string]interface{}{
		"user_id": loginUserInfo.UserInfoDbModel.GetUserId(),
	}
	//>=
	largeConds := map[string]interface{}{
		"cur_activity_date": getActivityLastNTime(activityPhone, 2).UnixMilli(),
	}
	// <=
	lessConds := map[string]interface{}{
		"cur_activity_date": activityEnd.UnixMilli(),
	}
	//
	orderCond := map[string]interface{}{
		"cur_activity_date": -1,
	}
	limits := int32(3)
	ret, err := p.DataCache.GetImpl().SportActivityMgModel.QueryItemBasic(ctx, eqConds, largeConds, lessConds, orderCond, limits)
	if err != nil {
		logger.Infof(ctx, "not data for user: %v", loginUserInfo.UserInfoDbModel.GetUserId())
		return errorcode.Sport_three_day_today_no_item
	}
	if ret == nil || len(ret) < int(limits) || ret[limits-1] == nil {
		return nil
	}
	//
	if ret[limits-1].GetCurActivityDate() < getActivityLastNTime(activityPhone, 2).UnixMilli() {
		return nil
	}
	sportMedalType := int64(10)
	sportExpirtTimeSecond := int64(3600 * 24)
	p.setMedal(ctx, loginUserInfo.UserInfoDbModel.GetUserId(), sportMedalType, sportExpirtTimeSecond)
	//....
	return nil
}
