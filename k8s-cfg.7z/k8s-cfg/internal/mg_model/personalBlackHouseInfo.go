package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type IPersonalBlackHouseInfoMgModel interface {
	ListByCondition(ctx context.Context,
		cond interface{}, page, size int64) ([]*pbmgdb.PersonalBlackHouseInfoMgModel, error)
}

type PersonalBlackHouseInfoMgDbImpl struct {
	MgDB *mongo.Database
}

func NewPersonalBlackHouseInfoMgModelImpl(db *mongo.Database) IPersonalBlackHouseInfoMgModel {
	return &PersonalBlackHouseInfoMgDbImpl{MgDB: db}
}

func (impl *PersonalBlackHouseInfoMgDbImpl) table() string {
	return "personalBlackHouseInfo"
}

func (impl *PersonalBlackHouseInfoMgDbImpl) ListByCondition(ctx context.Context,
	cond interface{}, page, size int64) ([]*pbmgdb.PersonalBlackHouseInfoMgModel, error) {
	collection := impl.MgDB.Collection(impl.table())
	findOptions := options.Find()
	findOptions.SetLimit(size)
	findOptions.SetSort(bson.D{
		bson.E{"_id", 1}, //升序
	})
	//查询条件
	find, err := collection.Find(ctx, cond, findOptions)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PersonalBlackHouseInfoMgDbImpl ListByCondition failed. cond=%v",
			cond), err)
		return nil, err
	}
	retItems := make([]*pbmgdb.PersonalBlackHouseInfoMgModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.PersonalBlackHouseInfoMgModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to PersonalBlackHouseInfoMgDbImpl failed.cond=%v",
				cond), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}
