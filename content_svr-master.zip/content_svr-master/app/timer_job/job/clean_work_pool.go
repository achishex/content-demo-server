package job

import (
	"content_svr/internal/data_cache"
	"content_svr/pub/logger"
	"context"
	"strconv"
	"time"
)

// CleanWorkPool 定时清理内容池
func CleanWorkPool(dc data_cache.IDataCacheMng) {
	ctx := context.Background()
	t := time.Now()
	logger.Infof(ctx, "CleanWorkPool Execute start. begin: %v", t)

	//一天前
	dayBefore := time.Now().AddDate(0, 0, -1).UnixMilli()
	min := "-inf"
	max := strconv.FormatInt(dayBefore, 10)

	//清理普通池
	if err := dc.CleanTsWorkPoolRedis(ctx, min, max); err != nil {
		return
	}

	//清理优质池
	if err := dc.CleanHighTsWorkPoolRedis(ctx, min, max); err != nil {
		return
	}

	//清理《高》优质池
	if err := dc.CleanHighPlusTsWorkPoolRedis(ctx, min, max); err != nil {
		return
	}

	logger.Infof(ctx, "CleanWorkPool Execute end. time since:", time.Since(t))
}
