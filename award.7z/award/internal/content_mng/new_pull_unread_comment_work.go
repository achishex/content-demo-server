package content_mng

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
)

func (p *ContentMng) NewPullUnreadCommentWorkProc(ctx context.Context, resp []*pbapi.GetReplyMsgSimple) ([]*pbapi.GetReplyMsgSimple, error) {
	for i := 0; i < len(resp); i++ {
		workInfos, err := p.DataCache.GetWorkInfoToNewCommentCount(ctx, resp[i].GetWorkId())
		if err != nil {
			logger.Error(ctx, "GetWorkInfoToNewCommentCount: ", err)
			continue
		}

		for _, wi := range workInfos {
			resp[i].GetWorks().NewCommentCount = wi.NewCommentCount
		}
	}
	return resp, nil
}
