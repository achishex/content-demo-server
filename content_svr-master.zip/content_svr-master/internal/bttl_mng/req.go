package bttl_mng

type DiscoverReq struct {
	NextPageToken string `json:"nextPageToken" form:"nextPageToken"`
}
type PullMsgReq struct {
	BttlID int64
	Seq    int64
	Limit  int64
	Order  int
}

type CreateReq struct {
	Content string `json:"content"`
}

type ReplyReq struct {
	Msg string `json:"msg"`
}
