package var_busi

// 用户当天总评论
var (
	Level0MaxCommentNums = 0
	Level1MaxCommentNums = 100
	Level2MaxCommentNums = 400
	Level3MaxCommentNums = 1000
	Level4MaxCommentNums = 2000
	Level5MaxCommentNums = 2000
)

// 用户当天单条评论
var (
	Level0SingleMaxCommentNums       = 0
	Level1SingleMaxCommentNums       = 4
	Level2SingleMaxCommentNums       = 8
	Level3SingleMaxCommentNums       = 30
	Level4SingleMaxCommentNums       = 60
	Level5SingleMaxCommentNums       = 60
	OfficialWorkSingleMaxCommentNums = 20 // 官方账号发布的动态 限制20条评论
)

var (
	AwardFirstWork float64 = 0.2 // 首条动态奖励金额
)
