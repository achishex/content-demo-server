package domain

// LogEntity mongo log
type LogEntity struct {
	UserID  int64  `bson:"user_id"`
	AppType string `bson:"app_type"`
	Url     string `bson:"url"`
	Method  string `bson:"method"`
	Header  string `bson:"header"`
	Req     string `bson:"req"`
	Resp    string `bson:"resp"`
	Created string `bson:"created"`
	Dur     string `bson:"dur"`
}

// KafkaLog kafka日志
type KafkaLog struct {
	UserID  string `json:"userID"`
	AppType string `json:"appType"`
	Url     string `json:"url"`
	Method  string `json:"method"`
	Header  string `json:"header"`
	Req     string `json:"req"`
	Resp    string `json:"resp"`
	Created string `json:"created"`
	Dur     string `json:"dur"`
}
