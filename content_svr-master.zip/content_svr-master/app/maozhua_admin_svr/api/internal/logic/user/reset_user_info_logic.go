package user

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"context"
	"math/rand"

	"github.com/zeromicro/go-zero/core/logx"
)

type ResetUserInfoLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewResetUserInfoLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ResetUserInfoLogic {
	return &ResetUserInfoLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

const (
	ResetPhoto    = 1 //重置头像
	ResetNickName = 2 //重置昵称
	ResetDesc     = 3 //重置个人简介
	ResetGender   = 4 //重置性别(切换性别)
	ResetHomepage = 5 //重置主页背景
)

func (l *ResetUserInfoLogic) ResetUserInfo(req *types.ResetUserInfoReq) (resp *types.ResetUserInfoResp, err error) {
	_db := l.svcCtx.WriteDB.UserInfo
	extUserInfo := l.svcCtx.WriteDB.SecretUserExtInfo

	userInfo, err := _db.FindByUserId(l.ctx, req.UserId)
	if err != nil {
		return nil, err
	}

	var (
		data = map[string]any{}
	)

	switch req.Type {
	case ResetPhoto:
		photo := ""
		if userInfo.Gender == 1 { //  男性
			photo = "workshop/secret/def/male.jpg"
		} else {
			photo = "workshop/secret/def/female.jpg"
		}
		data["photo"] = photo
	case ResetNickName:
		data["nick_name"] = createNewNickname()
	case ResetDesc:
		data["description"] = ""
	case ResetGender:
		gender := 1
		if userInfo.Gender == 1 { //  男性
			gender = 2
		}
		data["gender"] = gender
	case ResetHomepage:
		data["homepageBackground"] = ""
		if err := extUserInfo.UpdateByUserIdCache(l.ctx, req.UserId, data); err != nil {
			return nil, err
		}
	}

	if req.Type != ResetHomepage {
		filter := map[string]any{"user_id": req.UserId}
		if _, err := _db.UpdateMap(l.ctx, filter, data); err != nil {
			return nil, err
		}
	}

	err = _db.ClearUserInfoRedisCache(l.ctx, req.UserId)

	return
}

func createNewNickname() string {
	letters := []rune("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")

	buf := make([]rune, 4)
	for i := range buf {
		buf[i] = letters[rand.Intn(len(letters))]
	}
	randStr := string(buf)

	return "违规用户" + randStr
}
