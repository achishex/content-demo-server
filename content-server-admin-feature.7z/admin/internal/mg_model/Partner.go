package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"errors"
	"fmt"
	"github.com/samber/lo"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type IPartnerMgModel interface {
	FindOne(ctx context.Context, filter any) (*pbmgdb.PartnerMgDbModel, error)
	Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.PartnerMgDbModel, error)
	Create(ctx context.Context, data *pbmgdb.PartnerMgDbModel, options ...*options.InsertOneOptions) error
	UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error
}

type PartnerMgModel struct {
	MgDB  *mongo.Database
	Table string
}

func NewPartnerMgModel(db *mongo.Database) IPartnerMgModel {
	return &PartnerMgModel{
		MgDB:  db,
		Table: "partner",
	}
}

func (g *PartnerMgModel) coll() *mongo.Collection {
	return g.MgDB.Collection(g.Table)
}

func (g *PartnerMgModel) FindOne(ctx context.Context, filter any) (*pbmgdb.PartnerMgDbModel, error) {
	var v *pbmgdb.PartnerMgDbModel
	err := g.coll().FindOne(ctx, filter).Decode(&v)
	if errors.Is(err, mongo.ErrNoDocuments) {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("Partner FindOne failed. filter=%v", filter), err)
		return nil, err
	}
	return v, err
}

func (g *PartnerMgModel) Find(ctx context.Context, filter any, opts ...*options.FindOptions) ([]*pbmgdb.PartnerMgDbModel, error) {
	find, err := g.coll().Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	retItems := make([]*pbmgdb.PartnerMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.PartnerMgDbModel{}
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to Partner failed.cond=%v", filter), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (g *PartnerMgModel) Create(ctx context.Context, data *pbmgdb.PartnerMgDbModel, options ...*options.InsertOneOptions) error {
	iTryTimes := 0
	for iTryTimes < 10000 {
		iTryTimes++
		inviteCode := lo.RandomString(9, lo.NumbersCharset)
		data.InviteCode = inviteCode
		_, err := g.coll().InsertOne(ctx, data, options...)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("Partner.Create error. item=%v", data), err)
			continue
		}
		break
	}

	return nil
}

func (g *PartnerMgModel) UpdateOne(ctx context.Context, filter, updates any, options ...*options.UpdateOptions) error {
	_, err := g.coll().UpdateOne(ctx, filter, bson.D{{"$set", updates}}, options...)
	if err != nil {
		logger.Errorf(ctx, "Partner:updateOne error: %v", err)
		return err
	}

	return nil
}
