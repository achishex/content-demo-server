package handler

import (
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"context"
	"github.com/gin-gonic/gin"
	"strconv"
)

func (p *AdminHandler) RmTimeoutWorks(ctx *gin.Context) (*pbapi.BaseResp, error) {

	//header, err := utils.GetCtxHeadersSession(ctx)
	//if err != nil {
	//	return nil, err
	//}

	go p.ContentMng.RemoveTimeoutWorks(ctx)

	return &pbapi.BaseResp{}, nil
}

func (p *AdminHandler) Debug(ctx *gin.Context) (*pbapi.BaseResp, error) {
	p.ContentMng.Debug(ctx)
	return &pbapi.BaseResp{}, nil
}

func (p *AdminHandler) DebugAddToDeliver(ctx context.Context, req *pbapi.DebugUserIdReq) (*pbapi.BaseResp, error) {
	err := p.ContentMng.DebugAddToDeliver(ctx, req)
	return &pbapi.BaseResp{}, err
}

func (p *AdminHandler) CleanXingzuoUserCache(ctx *gin.Context, req *pbapi.DebugUserIdReq) (*pbapi.BaseResp, error) {
	err := p.ContentMng.CleanXingzuoUserCache(ctx, req.GetUserId())
	if err != nil {
		return nil, err
	}
	return &pbapi.BaseResp{}, nil
}

func (p *AdminHandler) CleanSignCache(ctx *gin.Context, req *pbapi.DebugUserIdReq) (*pbapi.BaseResp, error) {
	err := p.ContentMng.ResetSignCache(ctx, req.GetUserId())
	if err != nil {
		return nil, err
	}
	return &pbapi.BaseResp{}, nil
}

func (p *AdminHandler) DebugHandler(ctx *gin.Context, req *pbapi.DebugReq) (*pbapi.DebugResp, error) {
	if req.DebugType == 0 {
		return nil, errorcode.PARAM_ERROR
	}

	middleware.SetUserID(ctx, req.GetUserId())

	switch req.DebugType {
	case pbapi.DebugType_EXT_USER:
		change := map[string]any{}
		change["ulevel"] = req.UserExt.Ulevel
		err := p.ContentMng.SetUserExt(ctx, req.GetUserId(), change)
		if err != nil {
			return nil, err
		}
		err = p.ulv2comp.ResetUserLvlCheckinCnt(ctx, req.UserId, int(req.UserExt.Ulevel))
		if err != nil {
			logger.Errorf(ctx, "ResetUserLvlCheckinCnt fail, err %v", err)
			return nil, err
		}
	case pbapi.DebugType_UNBIND:
		_ = p.UserCenterMng.WithdrawUnBind(ctx)
	case pbapi.DebugType_UNTIE_CARD:
		err := p.ContentMng.UntieCard(ctx, req.GetUserId())
		if err != nil {
			return nil, err
		}
	case pbapi.DebugType_RESET_SIGN:
		p.ulv2comp.ClearUserCheckinLock(ctx, req.GetUserId())
		err := p.ContentMng.ResetSignCache(ctx, req.GetUserId())
		if err != nil {
			return nil, err
		}
	case pbapi.DebugType_First_Award:
		err := p.ContentMng.DebugFirstAward(ctx, req.Work)
		if err != nil {
			return nil, err
		}
	case pbapi.DebugType_Firepower:
		if err := p.ImMng.CalcFirepower(ctx, strconv.FormatInt(req.UserId, 10), req.Firepower.GroupId); err != nil {
			return nil, err
		}
	case pbapi.DebugType_ClearLvl5Reward:
		p.wxrSvc.ClearLvl5Reward(ctx, req.GetUserId())
	case pbapi.DebugType_SendWxRewardMsg:
		if err := p.ContentMng.SendWxRewardMsg(ctx, req.GetUserId(), req.WxRewardMsg); err != nil {
			logger.Errorf(ctx, "SendWxRewardMsg fail, err %v", err)
		}
	}

	return &pbapi.DebugResp{}, nil
}
