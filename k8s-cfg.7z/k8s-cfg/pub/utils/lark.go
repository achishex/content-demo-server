package utils

import (
	"bytes"
	"encoding/json"
	"net/http"
)

// webhook地址
// 测试群
// var LarkWebhookUrlReportDebug = "https://open.feishu.cn/open-apis/bot/v2/hook/411b9640-8e09-407c-98d3-dda7be542618"
// 正式群
var LarkWebhookUrlReportRelease = "https://open.feishu.cn/open-apis/bot/v2/hook/1669d708-9a2c-4e07-bdb1-83993228064c"

/*
	workItem := item{
		Tag:  "text",
		Text: fmt.Sprintf("【动态】举报未处理统计数：%d\n", t.Work),
	}
	commentItem := item{
		Tag:  "text",
		Text: fmt.Sprintf("【评论】举报未处理统计数：%d\n", t.Comment),
	}
	talkBoyItem := item{
		Tag:  "text",
		Text: fmt.Sprintf("【私聊】男性用户举报未处理统计数：%d\n", t.TalkBoy),
	}
	talkGirlItem := item{
		Tag:  "text",
		Text: fmt.Sprintf("【私聊】女性用户举报未处理统计数：%d\n", t.TalkGirl),
	}
	href := item{
		Tag:  "a",
		Text: "跳转连接",
		Href: "https://mzadmin.52mengdong.com/",
	}

	items := []item{workItem, commentItem, talkBoyItem, talkGirlItem, href}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = "抓捕信息统计"
	m.Content.Post.ZhCn.Content = make([][]item, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

*/

type LarkMessageItem struct {
	Tag      string `json:"tag,omitempty"`
	Text     string `json:"text,omitempty"`
	Href     string `json:"href,omitempty"`
	UserId   string `json:"user_id,omitempty"`
	UserName string `json:"user_name,omitempty"`
	ImageKey string `json:"image_key,omitempty"`
}

type LarkMessage struct {
	MsgType string `json:"msg_type"`
	Content struct {
		Post struct {
			ZhCn struct {
				Title   string              `json:"title"`
				Content [][]LarkMessageItem `json:"content"`
			} `json:"zh_cn"`
		} `json:"post"`
	} `json:"content"`
}

func LarkSendMsg(webhookUrl string, msg LarkMessage) {
	// json
	contentType := "application/json"
	// data
	sendData, _ := json.Marshal(msg)
	// request
	result, err := http.Post(webhookUrl, contentType, bytes.NewReader(sendData))
	if err != nil {
		return
	}
	defer result.Body.Close()
}
