package middleware

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/data_cache"
	"content_svr/internal/mg_model"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

// 注意 value 的数字不可以随便改，下面有使用
var retainRecordRoute = map[string]int32{
	"/platform/secret/chitchat/works":      1,
	"/platform/api/user/work/comment_push": 2,
	"/platform/secret/talkMessage/v2/send": 3,
	"/platform/api/user/work/comment_like": 4,
	"/platform/api/comm/get_app_config":    5,
	"/platform/api/ad/behavior_upload/v2":  6,
	"/platform/api/game/auth":              7,
}

func RetainRecord(dataCache data_cache.IDataCacheMng) gin.HandlerFunc {
	return func(ctx *gin.Context) {
		ctx.Next()
		go userActivityRecord(ctx.Copy(), dataCache)
	}
}

func userActivityRecord(ctx *gin.Context, dataCache data_cache.IDataCacheMng) {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v", err)
			return
		}
	}()
	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		logger.Errorf(ctx, "get header error: %v", err)
		return
	}
	if header.Apptype != cm_const.AppTypeMobileIos && header.Apptype != cm_const.AppTypeMobileAndroid {
		return // 只记录Android、iOS客户端用户
	}

	flag, ok := retainRecordRoute[ctx.Request.RequestURI]
	if !ok {
		return
	}

	if status := GetStatus(ctx); status != "success" {
		// 接口失败
		return
	}

	//if header.Channel == "" && header.Apptype == "mobile-ios" {
	//	header.Channel = "maozhua" // default app-store
	//}
	userId := GetUserID(ctx)
	user, err := dataCache.GetUserInfoLocal(ctx, nil, userId, false)
	if err != nil {
		logger.Errorf(ctx, "cannot find userinfo: %v  err: %v", userId, err)
		return
	}
	if user == nil {
		logger.Errorf(ctx, "cannot find userinfo: %v  err: %v", userId, err)
		return
	}

	var gender int32
	if user.UserInfoDbModel.GetGender() == 0 {
		gender = 2
	} else {
		gender = user.UserInfoDbModel.GetGender()
	}

	now := time.Now()
	//dateStr := fmt.Sprintf("%04d%02d%02d", now.Year(), now.Month(), now.Day())
	//day, _ := strconv.Atoi(dateStr)
	day, _ := utils.TimeByDay(now)
	channel := switchChannel(header)

	data := &pbmgdb.SecretUserActivityDaily{
		UserId:     userId,
		AppType:    header.Apptype,
		Channel:    channel,
		Gender:     gender,
		Day:        int64(day),
		UpdateTime: now.UnixMilli(),
	}

	// add 行为记录
	switch flag {
	case 1:
		data.WorkActive = 1
	case 2:
		data.CommentActive = 1
	case 3:
		data.TalkActive = 1
	case 4:
		data.LikeActive = 1
	case 7:
		data.GameActive = 1
	}

	// add 新用户 和 市场推广标记
	if isNewUser(user.UserInfoDbModel.GetCreateTime()) {
		data.Market = isMarket(ctx, userId, dataCache, header)
		data.IsNew = 1
	} else {
		data.IsNew = 0
	}

	// update mongodb
	upsertActivityDailyRecord(ctx, dataCache.GetImpl().SecretUserActivityDailyMgModel, data)
}

func upsertActivityDailyRecord(ctx *gin.Context, SecretUserActivityDailyMgModel mg_model.ISecretUserActivityDailyMgModel, data *pbmgdb.SecretUserActivityDaily) {
	filter := bson.D{
		{"day", data.Day},
		{"user_id", data.UserId},
	}
	update := bson.D{
		{"$set", &pbmgdb.SecretUserActivityDaily{
			IsNew:         data.IsNew,
			WorkActive:    data.WorkActive,
			CommentActive: data.CommentActive,
			TalkActive:    data.TalkActive,
			LikeActive:    data.LikeActive,
			GameActive:    data.GameActive,
			UserId:        data.UserId,
			//AppType:       "",
			//Channel:       "",
			Gender: data.Gender,
			Day:    data.Day,
			//CreateTime:    0,
			UpdateTime: data.UpdateTime,
			Market:     data.Market,
		}},
		{"$setOnInsert", bson.D{ //不满足filter时，插入这些字段；满足filter发生更新，不做处理
			{"create_time", data.UpdateTime},
			{"app_type", data.AppType},
			{"channel", data.Channel},
		},
		},
	}

	//fmt.Println(data)
	opt := options.Update().SetUpsert(true)
	if _, err := SecretUserActivityDailyMgModel.Update(ctx, filter, update, opt); err != nil {
		logger.Error(ctx, "update SecretUserActivityDailyMgModel:", err)
		return
	}
}

// 是否是今天新创建的用户
func isNewUser(createTimeStr string) bool {
	if len(createTimeStr) == 0 {
		return false
	}

	timeLayout := "2006-01-02 15:04:05"  //模版
	loc, _ := time.LoadLocation("Local") //获取当前时区
	//使用模版将需要判断的时间在对应时区转化成time.time类型
	theTime, _ := time.ParseInLocation(timeLayout, createTimeStr, loc)
	//将需要判断的时间格式话成str类型
	dataTimeStr := theTime.Format("2006-01-02")

	//当前时间（当年当月当天）
	nowstr := time.Now().Format("2006-01-02")

	//判断所需要的时间是否是当天
	return dataTimeStr == nowstr
}

func isMarket(ctx context.Context, userId int64, dataCache data_cache.IDataCacheMng, header *pbapi.HttpHeaderInfo) int32 {
	switch header.Channel {
	case cm_const.AppChannelMaozhua,
		cm_const.AppChannelHuaWei,
		cm_const.AppChannelHonor,
		cm_const.AppChannelXiaomi,
		cm_const.AppChannelOppo,
		cm_const.AppChannelVivo,
		cm_const.AppChannelYYB,
		cm_const.AppChannelBaidu,
		cm_const.AppChannelToutiao,
		cm_const.AppChannelGdt:
		imei := utils.MD5To32(header.Imei)
		ImeiStatus := dataCache.GetRedisAdFeedback(ctx, header.Channel, imei)
		OaidStatus := dataCache.GetRedisAdFeedback(ctx, header.Channel, header.Oaid)
		logger.Infof(ctx, "==retain== Imei: %s -> %d Oaid: %s -> %d", imei, ImeiStatus, header.Oaid, OaidStatus)
		switch {
		//case ImeiStatus > const_busi.AdFeedbackFormChannel, OaidStatus > const_busi.AdFeedbackFormChannel:
		//	// 说明是当前函数写入的 userId 值
		//	return 0
		case ImeiStatus == const_busi.AdFeedbackFormChannel, OaidStatus == const_busi.AdFeedbackFormChannel:
			return 1
		//case ImeiStatus == const_busi.AdFeedbackNil, OaidStatus == const_busi.AdFeedbackNil:
		//	if err := dataCache.SetRedisAdFeedback(ctx, header.Channel, imei, int(userId)); err != nil {
		//		logger.Error(ctx, "dataCache.SetRedisAdFeedback: ", err)
		//		break
		//	}
		//	if err := dataCache.SetRedisAdFeedback(ctx, header.Channel, header.Oaid, int(userId)); err != nil {
		//		logger.Error(ctx, "dataCache.SetRedisAdFeedback: ", err)
		//		break
		//	}
		//	return 0
		default:
			return 0
		}
	default:
		return 0
	}

	//return 0
}

func switchChannel(header *pbapi.HttpHeaderInfo) string {
	switch header.Channel {
	case cm_const.AppChannelMaozhua,
		cm_const.AppChannelHuaWei,
		cm_const.AppChannelHonor,
		cm_const.AppChannelXiaomi,
		cm_const.AppChannelOppo,
		cm_const.AppChannelVivo,
		cm_const.AppChannelYYB,
		cm_const.AppChannelBaidu,
		cm_const.AppChannelToutiao,
		cm_const.AppChannelGdt:
		return header.Channel
	default:
		return "maozhua"
	}
}
