package aggregation

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/utils"
	"context"
	"time"
)

type UserActivityDaily struct {
	WriteDB, ReadDB *dao.ManagerDB
}

// TodayUserActivity 获取今天 SecretUserActivityDaily 聚合数据
func (s *UserActivityDaily) TodayUserActivity(ctx context.Context, filter map[string]interface{}, timeEnd int64) (*model.SecretUserChannelDaily, error) {
	endTime, err := utils.ParseDay(timeEnd)
	if err != nil {
		return nil, xerr.ParamError
	}
	if utils.GtTodayZero(endTime) {
		nowDay, err := utils.TimeByDay(time.Now())
		if err != nil {
			return nil, err
		}
		channelDaily, err := s.UserActivity(ctx, filter, nowDay)
		if err != nil {
			return nil, err
		}
		return channelDaily, err
	}

	return nil, nil
}

// UserActivity 聚合 SecretUserActivityDaily 某天数据
func (s *UserActivityDaily) UserActivity(ctx context.Context, filter map[string]interface{}, day uint) (*model.SecretUserChannelDaily, error) {
	filter["day"] = day

	activityList, err := s.ReadDB.SecretUserActivityDaily.FindAll(ctx, filter)
	if err != nil {
		return nil, err
	}

	obj := &model.SecretUserChannelDaily{}
	for _, daily := range activityList {
		obj.AppType = daily.AppType
		obj.Channel = daily.Channel
		obj.Day = day
		obj.Gender = daily.Gender
		obj.Market = daily.Market
		obj.ActiveUserCount++
		if daily.IsNew == 1 {
			obj.NewUserCount++
		}
		switch {
		case daily.WorkActive != 0, daily.CommentActive != 0, daily.TalkActive != 0, daily.LikeActive != 0:
			obj.ActiveTargetUserCount++
			if daily.IsNew == 1 {
				obj.NewTargetUserCount++
			}
		}

	}

	return obj, err
}
