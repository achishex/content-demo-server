package mg_model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

type ISecretWorksLikeRecordMgDbModel interface {
	GetById(ctx context.Context,
		userId int64, workIdList []int64) (map[int64]*pbapi.SecretWorksLikeRecordMgDbModel, error)
}

type SecretWorksLikeRecordMgDbImpl struct {
	MgDB *mongo.Database
}

func NewSecretWorksLikeRecordMgModelImpl(db *mongo.Database) ISecretWorksLikeRecordMgDbModel {
	return &SecretWorksLikeRecordMgDbImpl{MgDB: db}
}

// 返回 workid~items. 已点赞列表
func (impl *SecretWorksLikeRecordMgDbImpl) GetById(ctx context.Context,
	userId int64, workIdList []int64) (map[int64]*pbapi.SecretWorksLikeRecordMgDbModel, error) {
	retDict := make(map[int64]*pbapi.SecretWorksLikeRecordMgDbModel, 0)
	retItems := make([]*pbapi.SecretWorksLikeRecordMgDbModel, 0)
	collection := impl.MgDB.Collection("secretWorksLikeRecord")
	find, err := collection.Find(ctx, bson.M{"userId": userId, "workId": bson.M{"$in": workIdList}})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretWorksLikeRecordMgDbModel Find failed.userid=%v",
			userId), err)
		return retDict, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.SecretWorksLikeRecordMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretWorksLikeRecordMgDbModel failed.userid=%v",
				userId), err)
			return retDict, err
		}
		retItems = append(retItems, demo)
	}

	for _, item := range retItems {
		if item.Canceled == true {
			continue
		}
		retDict[item.GetWorkId()] = item
	}
	return retDict, nil
}
