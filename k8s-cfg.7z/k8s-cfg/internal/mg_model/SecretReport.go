package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

// SecretReport
// SecretReport
type ISecretReportMgModel interface {
	Insert(ctx context.Context, item *pbmgdb.SecretReportMgDbModel) error
	ListByCondition(ctx context.Context,
		cond map[string]interface{}) ([]*pbmgdb.SecretReportMgDbModel, error)
	UpdateDictByCond(ctx context.Context, cond, update map[string]interface{}) error
	GetById(ctx context.Context,
		reportId int64) (*pbmgdb.SecretReportMgDbModel, error)
	UpdatesStatusToIgnore(ctx context.Context, reportIds []int64) error
	Count(ctx context.Context, filter any) (int64, error)
}

type SecretReportMgDbImpl struct {
	MgDB *mongo.Database
}

func NewSecretReportMgModelImpl(db *mongo.Database) ISecretReportMgModel {
	return &SecretReportMgDbImpl{MgDB: db}
}

func (impl *SecretReportMgDbImpl) table() string {
	return "secretReport"
}

func (impl *SecretReportMgDbImpl) Insert(ctx context.Context, item *pbmgdb.SecretReportMgDbModel) error {
	collection := impl.MgDB.Collection(impl.table())
	_, err := collection.InsertOne(ctx, item)
	//print(result, err)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretReportMgDbImpl.Insert  failed. item=%v",
			item), err)
	}
	return err
}

func (impl *SecretReportMgDbImpl) UpdatesStatusToIgnore(ctx context.Context, reportIds []int64) error {
	collection := impl.MgDB.Collection(impl.table())

	cond := bson.D{{Key: "_id", Value: bson.M{"$in": reportIds}}}
	mgUpdates := bson.D{}
	mgUpdates = append(mgUpdates, bson.E{"$set", map[string]interface{}{"verifyStatus": 4}})

	_, err := collection.UpdateMany(ctx, cond, mgUpdates)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("UpdatesStatusToIgnore.Insert  failed. reportIds=%v",
			reportIds), err)
	}
	return err
}

func (impl *SecretReportMgDbImpl) ListByCondition(ctx context.Context,
	cond map[string]interface{}) ([]*pbmgdb.SecretReportMgDbModel, error) {
	collection := impl.MgDB.Collection(impl.table())
	find, err := collection.Find(ctx, cond)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretReportMgDbModel ListByCondition failed. cond=%v",
			cond), err)
		return nil, err
	}
	retItems := make([]*pbmgdb.SecretReportMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbmgdb.SecretReportMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretReportMgDbModel failed.cond=%v",
				cond), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (impl *SecretReportMgDbImpl) UpdateDictByCond(ctx context.Context, cond, update map[string]interface{}) error {
	collection := impl.MgDB.Collection(impl.table())
	if len(update) == 0 || len(cond) == 0 {
		return nil
	}

	mgUpdates := bson.D{}
	if len(update) > 0 {
		mgUpdates = append(mgUpdates, bson.E{"$set", update})
	}
	_, err := collection.UpdateMany(ctx, cond, mgUpdates)
	return err
}

func (impl *SecretReportMgDbImpl) GetById(ctx context.Context,
	reportId int64) (*pbmgdb.SecretReportMgDbModel, error) {

	item := &pbmgdb.SecretReportMgDbModel{}
	collection := impl.MgDB.Collection(impl.table())
	err := collection.FindOne(ctx, bson.M{"_id": reportId}).Decode(item)
	if err == mongo.ErrNoDocuments {
		return nil, nil
	}
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretReportMgDbImpl Find failed.reportid=%v",
			reportId), err)
		return nil, err
	}
	return item, err
}

func (impl *SecretReportMgDbImpl) Count(ctx context.Context, filter any) (int64, error) {
	return impl.MgDB.Collection(impl.table()).CountDocuments(ctx, filter)
}
