package query

import (
	"content_svr/db/mysqldb/model"
	"context"
	"gorm.io/gen"
	"gorm.io/gen/field"
)

type PersonalBottleWork struct {
	personalBottleWork
}

func NewPersonalBottleWork(p personalBottleWork) PersonalBottleWork {
	return PersonalBottleWork{
		personalBottleWork: p,
	}
}

func (p *personalBottleWork) GetColumnName(field field.Expr) string {
	return field.ColumnName().String()
}

func (p *personalBottleWork) ParseWhere(ctx context.Context, where map[string]interface{}) IPersonalBottleWorkDo {
	_do := p.WithContext(ctx)
	if len(where) == 0 {
		return _do
	}

	attrMap := map[string]interface{}{}
	for key, value := range where {
		if value == nil {
			continue
		}

		switch key {
		case "create_time_begin", "create_time_start":
			_do = _do.Where(p.CreateTime.Gt(value.(string)))
		case "create_time_end":
			_do = _do.Where(p.CreateTime.Lt(value.(string)))
		case "work_ids":
			v := value.([]int64)
			if len(v) == 0 {
				continue
			}
			_do = _do.Where(p.ID.In(v...))
		case "user_ids":
			v := value.([]int64)
			if len(v) == 0 {
				continue
			}
			_do = _do.Where(p.UserID.In(v...))
		default:
			if _, exist := p.fieldMap[key]; !exist {
				continue
			}
			attrMap[key] = value
		}
	}

	return _do.Where(field.Attrs(attrMap))
}

func (p *personalBottleWork) FindMap(ctx context.Context, limit, offset int, where map[string]interface{}) ([]*model.PersonalBottleWork, error) {
	_db := p.ParseWhere(ctx, where)
	_db = _db.WithContext(ctx)
	if limit != 0 {
		_db = _db.Limit(limit)
	}
	if offset != 0 {
		_db = _db.Offset(offset)
	}

	return _db.Find()
}

func (p *personalBottleWork) FindOne(ctx context.Context, where map[string]interface{}) (*model.PersonalBottleWork, error) {
	_db := p.ParseWhere(ctx, where)

	return _db.Take()
}

func (p *personalBottleWork) UpdateMap(ctx context.Context, where, update map[string]interface{}) (info gen.ResultInfo, err error) {
	_db := p.ParseWhere(ctx, where)

	return _db.Updates(update)
}

func (p *personalBottleWork) Count(ctx context.Context, conds []gen.Condition) (int64, error) {
	return p.WithContext(ctx).Where(conds...).Count()
}
