package advertisement

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/db/mongodb/model"
	"context"
	"encoding/json"
	"github.com/jinzhu/copier"
	"github.com/zeromicro/go-zero/core/logx"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

type ListLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewListLogic(ctx context.Context, svcCtx *svc.ServiceContext) *ListLogic {
	return &ListLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *ListLogic) List(req *types.AppAdListRequest) (resp *types.AppAdListResponse, err error) {
	var launchStatus int64
	if req.Where != nil {
		value, exist := req.Where["launch_status"]
		if exist {
			delete(req.Where, "launch_status")
			v, ok := value.(json.Number)
			if ok {
				launchStatus, _ = v.Int64()
			}
		}
	}
	filter, opt := req.ParseMongo()
	if req.OrderKey == "weight" {
		opt.Sort = bson.D{
			{"weight", 1},
			{"create_time", -1},
		}
	}
	nowUnix := time.Now().UnixMilli()

	adList := make([]types.AppAdListItem, 0)
	switch launchStatus {
	case 0:
		total, err := l.svcCtx.ReadDB.AppAdvertisement.Count(l.ctx, filter)
		if err != nil {
			return nil, err
		}

		list, err := l.svcCtx.ReadDB.AppAdvertisement.FindAll(l.ctx, filter, opt)
		if err != nil {
			return nil, err
		}

		adList = l.buildList(nowUnix, launchStatus, list)

		resp = &types.AppAdListResponse{
			Total: total,
			List:  adList,
		}

	default:
		var total int64
		opt.Skip = &[]int64{0}[0]
		opt.Limit = &[]int64{10000}[0]

		list, err := l.svcCtx.ReadDB.AppAdvertisement.FindAll(l.ctx, filter, opt)
		if err != nil {
			return nil, err
		}

		adAllList := l.buildList(nowUnix, launchStatus, list)
		total = int64(len(adAllList))

		if total > 0 {
			start := (req.Page - 1) * req.Size
			end := req.Page * req.Size
			if int64(end) > total {
				end = int(total)
			}
			adList = adAllList[start:end]
		}

		resp = &types.AppAdListResponse{
			Total: total,
			List:  adList,
		}
	}

	//adList := make([]types.AppAdListItem, 0)
	//for _, item := range list {
	//	ad := types.AppAdListItem{}
	//	_ = copier.Copy(&ad, &item)
	//	ad.ID = item.ID.Hex()
	//
	//	ad.LaunchStatus = getLaunchStatus(nowUnix, item)
	//	if launchStatus != 0 {
	//		if launchStatus == ad.LaunchStatus {
	//			adList = append(adList, ad)
	//		}
	//	} else {
	//		adList = append(adList, ad)
	//	}
	//}
	//
	//if len(adList) != req.Size {
	//	total = int64(len(adList))
	//
	//	opt.Skip = &[]int64{int64((req.Page + 1) * req.Size)}[0]
	//	opt.Limit = &[]int64{10000}[0]
	//
	//	list, err := l.svcCtx.ReadDB.AppAdvertisement.FindAll(l.ctx, filter, opt)
	//	if err != nil {
	//		return nil, err
	//	}
	//
	//	for _, item := range list {
	//		if len(adList) == req.Size {
	//			total++
	//			continue
	//		}
	//		ad := types.AppAdListItem{}
	//		_ = copier.Copy(&ad, &item)
	//		ad.ID = item.ID.Hex()
	//
	//		ad.LaunchStatus = getLaunchStatus(nowUnix, item)
	//		if launchStatus != 0 {
	//			if launchStatus == ad.LaunchStatus {
	//				adList = append(adList, ad)
	//			}
	//		} else {
	//			adList = append(adList, ad)
	//		}
	//		total++
	//	}
	//
	//}
	//
	//resp = &types.AppAdListResponse{
	//	Total: total,
	//	List:  adList,
	//}

	return
}

func (l *ListLogic) buildList(nowUnix, launchStatus int64, list []model.AppAdvertisement) []types.AppAdListItem {
	adList := make([]types.AppAdListItem, 0)
	for _, item := range list {
		ad := types.AppAdListItem{}
		_ = copier.Copy(&ad, &item)
		ad.ID = item.ID.Hex()
		ad.LaunchStatus = getLaunchStatus(nowUnix, item)
		if launchStatus != 0 {
			if launchStatus == ad.LaunchStatus {
				adList = append(adList, ad)
			}
		} else {
			adList = append(adList, ad)
		}
	}

	return adList
}
