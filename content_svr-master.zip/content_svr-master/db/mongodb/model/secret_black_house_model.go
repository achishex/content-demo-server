package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var _ SecretBlackHouseModel = (*customSecretBlackHouseModel)(nil)

type (
	// SecretBlackHouseModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretBlackHouseModel.
	SecretBlackHouseModel interface {
		secretBlackHouseModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretBlackHouse, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretBlackHouse, error)
		UpsertMapOne(ctx context.Context, filter, update map[string]interface{}) (*mongo.UpdateResult, error)
	}

	customSecretBlackHouseModel struct {
		*defaultSecretBlackHouseModel
	}
)

// NewSecretBlackHouseModel returns a model for the mongo.
func NewSecretBlackHouseModel(cfg MonConfig) SecretBlackHouseModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SecretBlackHouseCollectionName)
	return &customSecretBlackHouseModel{
		defaultSecretBlackHouseModel: newDefaultSecretBlackHouseModel(conn),
	}
}

func (m *customSecretBlackHouseModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			query = append(query, bson.E{Key: k, Value: v})
		}
	}
	return query
}

func (m *customSecretBlackHouseModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretBlackHouseModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretBlackHouse, error) {
	result := make([]SecretBlackHouse, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretBlackHouseModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretBlackHouse, error) {
	var data SecretBlackHouse
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretBlackHouseModel) UpsertMapOne(ctx context.Context, filter, update map[string]interface{}) (*mongo.UpdateResult, error) {
	conds := bson.D{}
	for key, value := range filter {
		conds = append(conds, bson.E{Key: key, Value: value})
	}

	data := bson.D{}
	for key, value := range update {
		data = append(data, bson.E{Key: key, Value: value})
	}
	updater := bson.D{
		{Key: "$set", Value: data},
	}

	opt := options.Update().SetUpsert(true)
	return m.conn.UpdateOne(ctx, filter, updater, opt)
}
