package model

import "go.mongodb.org/mongo-driver/bson/primitive"

const SuperiorAwardDailyCollectionName = "superior_award_daily"

type SuperiorAwardDaily struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	Day                          int64 `json:"day" bson:"day"`                                                             // 时间戳
	AwardSettlementSum           uint  `json:"award_settlement_sum" bson:"award_settlement_sum"`                           // 当天结算奖励总和
	DeductionIllegalSum          uint  `json:"deduction_illegal_sum" bson:"deduction_illegal_sum"`                         // 当天违规扣除总和
	FirstWorkSettlementSum       uint  `json:"first_work_settlement_sum" bson:"first_work_settlement_sum"`                 // 当天首条动态奖励总和
	WechatPayWithdrawSuccessSum  uint  `json:"wechat_pay_withdraw_success_sum" bson:"wechat_pay_withdraw_success_sum"`     // 当天微信提现成功总和
	WechatPayWithdrawFailSum     uint  `json:"wechat_pay_withdraw_fail_sum" bson:"wechat_pay_withdraw_fail_sum"`           // 当天微信提现失败总和
	HallOfFameAwardSettlementSum uint  `json:"hall_of_fame_award_settlement_sum" bson:"hall_of_fame_award_settlement_sum"` // 当天排行榜奖励总和
	GameSum                      uint  `json:"game_sum" bson:"game_sum"`                                                   // 游戏收益统计
	PartnerInviteReward          uint  `json:"partner_invite_award_sum" bson:"partner_invite_award_sum"`                   // 合伙人邀请奖励
	PartnerCarveUp               uint  `json:"partner_carveup_sum" bson:"partner_carveup_sum"`                             // 合伙人瓜分奖励
	SignLevelUpAwardSum          uint  `json:"sign_level_up_award_sum" bson:"sign_level_up_award_sum"`                     // 签到升级红包奖励
	AwardViewWorkSum             uint  `json:"award_view_work_sum" bson:"award_view_work_sum"`                             // 浏览动态奖励
	AwardGameTimeSum             uint  `json:"award_game_time_sum" bson:"award_game_time_sum"`                             // 玩游戏时长奖励
	AwardSportAdSum              uint  `json:"award_sport_ad_sum" bson:"award_sport_ad_sum"`                               // 观看运动广告奖励
	AwardStarSignAdSum           uint  `json:"award_star_sign_ad_sum" bson:"award_star_sign_ad_sum"`                       // 观看星座广告奖励
	AwardSignAdSum               uint  `json:"award_sign_ad_sum" bson:"award_sign_ad_sum"`                                 // 观看签到广告奖励
	AwardGroupByCreateSum        uint  `json:"award_group_by_create_sum" bson:"award_group_by_create_sum"`                 // 创建群聊
	AwardGroupUserByActiveSum    uint  `json:"award_group_user_by_active_sum" bson:"award_group_user_by_active_sum"`       // 群活跃人数
	AwardCommentFirstSum         uint  `json:"award_comment_first_sum" bson:"award_comment_first_sum"`                     // 首条评论
	AwardBindWechatSum           uint  `json:"award_bind_wechat_sum" bson:"award_bind_wechat_sum"`                         // 绑定微信的奖励

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` // 创建时间
}
