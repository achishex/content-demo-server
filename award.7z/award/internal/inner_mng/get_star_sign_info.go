package inner_mng

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	"io"
)

// 通过-true。
func (p *InnerProxyImpl) GetStarSignInfo(ctx context.Context, starSignId int32) (*pbapi.GetStarSignInfoResp, error) {

	url := fmt.Sprintf("https://platform.52mengdong.com/platform/signIn/today/%v", starSignId)
	resp, err := p.getRequest(ctx, url, nil)
	if err != nil {
		logger.Errorf(ctx, "GetStarSignInfo return err. url=%v, err=%v", url, err)
		return nil, err
	}

	if resp.StatusCode != 200 {
		logger.Errorf(ctx, "GetStarSignInfo httpcode!=200. url=%v,resp.StatusCode != 200", url)
		return nil, fmt.Errorf("http retcode != 200, retcode=%v", resp.Status)
	}

	innerResp := &pbapi.GetStarSignInfoResp{}
	sRespBytes, _ := io.ReadAll(resp.Body)
	err = json.Unmarshal(sRespBytes, innerResp)
	if err != nil {
		return nil, err
	}
	if innerResp.GetStatus() != 1000 {
		logger.Errorf(ctx, "get GetStarSignInfo failed. url=%v, err=%v", url, err)
		return nil, fmt.Errorf("GetStarSignInfo failed.")
	}
	//logger.Infof(ctx, "personal_talk_check over, userId=%v, url=%v, innerResp=%+v", userId, url, innerResp)
	return innerResp, nil
}
