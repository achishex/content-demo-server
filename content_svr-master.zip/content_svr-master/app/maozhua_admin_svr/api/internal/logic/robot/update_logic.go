package robot

import (
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/db/mongodb/model"
	"context"
	"fmt"
	"github.com/jinzhu/copier"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type UpdateLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewUpdateLogic(ctx context.Context, svcCtx *svc.ServiceContext) *UpdateLogic {
	return &UpdateLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *UpdateLogic) Update(req *types.RobotUpdateReq) (resp *types.RobotUpdateResp, err error) {
	robot, err := l.svcCtx.WriteDB.MzRobot.FindOne(l.ctx, req.Id)
	if err != nil {
		return nil, err
	}

	if !(robot.TimePartStart == req.TimePartStart && robot.TimePartEnd == req.TimePartEnd && robot.CommentIndex == req.CommentIndex) {
		// 不校验原值
		number, ok, err := l.svcCtx.WriteDB.MzRobot.CheckArea(l.ctx, robot.ID, req.TimePartStart, req.TimePartEnd, req.CommentIndex)
		if err != nil {
			return nil, err
		}
		if ok {
			return nil, xerr.DbTimeOverlapError.SetMsg(fmt.Sprintf("已与序号为%d的机器人生效时间重叠，请修改后保存", number))
		}
	}
	err = copier.Copy(robot, req)
	if err != nil {
		return nil, err
	}
	robot.Editor = req.CtxName

	info, err := l.svcCtx.WriteDB.SecretUserExtInfo.FindOne(l.ctx, map[string]interface{}{"nickName": robot.Name})
	if err != nil && err != xerr.DbNotFound {
		return nil, err
	}
	if info != nil && info.NickName != robot.Name {
		return nil, xerr.UserInfoNickNameError
	}

	oid, err := primitive.ObjectIDFromHex(req.Id)
	if err != nil {
		return nil, model.ErrInvalidObjectId
	}
	now := time.Now().UnixMilli()
	if now >= robot.TimePartEnd {
		robot.Status = false
	}
	robot.ID = oid
	robot.UpdateAt = time.Now().UnixMilli()
	robot.CommentObject = &model.WorkCommentObjectAttr{
		ObjectId: req.ObjectId,
	}
	if err := l.svcCtx.WriteDB.MzRobot.Update(l.ctx, robot); err != nil {
		return nil, err
	}

	if err := l.svcCtx.WriteDB.UpdateAllRobotByUserId(l.ctx, robot); err != nil {
		return nil, err
	}

	err = l.svcCtx.WriteDB.UserInfo.UpdateHeaderAndNickName(l.ctx, robot.UserId, robot.Header, robot.Name)
	if err != nil {
		return nil, err
	}

	robot, err = l.svcCtx.WriteDB.MzRobot.FindOne(l.ctx, req.Id)
	if err != nil {
		return nil, err
	}

	l.svcCtx.RobotMonitor.ResetWorker(robot)
	return nil, nil
}
