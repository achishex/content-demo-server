package model

import (
	"context"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const SecretAuditCollectionName = "secretAudit"

var _ SecretAuditModel = (*customSecretAuditModel)(nil)

type (
	// SecretAuditModel is an interface to be customized, add more methods here,
	// and implement the added methods in customSecretAuditModel.
	SecretAuditModel interface {
		secretAuditModel
		FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretAudit, error)
		Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error)
		FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretAudit, error)
	}

	customSecretAuditModel struct {
		*defaultSecretAuditModel
	}
)

// NewSecretAuditModel returns a model for the mongo.
func NewSecretAuditModel(cfg MonConfig) SecretAuditModel {
	conn := mon.MustNewModel(cfg.GetURL(), cfg.GetDBName(), SecretAuditCollectionName)
	return &customSecretAuditModel{
		defaultSecretAuditModel: newDefaultSecretAuditModel(conn),
	}
}

func (m *customSecretAuditModel) parseFilter(filter map[string]interface{}, flag ...string) bson.D {
	var flagType string
	if len(flag) > 0 {
		flagType = flag[0]
	}

	query := bson.D{}
	switch flagType {
	default:
		for k, v := range filter {
			switch k {
			case "create_time_begin":
				query = append(query, bson.E{Key: "create_time", Value: bson.D{{"$gte", v}}})
			case "create_time_end":
				query = append(query, bson.E{Key: "create_time", Value: bson.D{{"$lte", v}}})
			default:
				query = append(query, bson.E{Key: k, Value: v})
			}
		}
	}
	return query
}

func (m *customSecretAuditModel) Count(ctx context.Context, filter map[string]interface{}, opts ...*options.CountOptions) (int64, error) {
	query := m.parseFilter(filter)
	count, err := m.conn.CountDocuments(ctx, query, opts...)
	if err != nil {
		return 0, err
	}
	return count, nil
}

func (m *customSecretAuditModel) FindAll(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOptions) ([]SecretAudit, error) {
	result := make([]SecretAudit, 0)
	query := m.parseFilter(filter)
	err := m.conn.Find(ctx, &result, query, opts...)

	switch err {
	case nil:
		return result, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}

func (m *customSecretAuditModel) FindOne(ctx context.Context, filter map[string]interface{}, opts ...*options.FindOneOptions) (*SecretAudit, error) {
	var data SecretAudit
	query := m.parseFilter(filter)
	err := m.conn.FindOne(ctx, &data, query, opts...)
	switch err {
	case nil:
		return &data, nil
	case mon.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}
}
