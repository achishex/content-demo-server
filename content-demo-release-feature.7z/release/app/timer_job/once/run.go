package once

import (
	"flag"
	"github.com/go-redis/redis/v8"
	"go.mongodb.org/mongo-driver/mongo"
	"gorm.io/gorm"
	"os"
)

var Command *command

type command struct {
	mngDB   *mongo.Client
	mysqlDB *gorm.DB
	redisDB *redis.Client

	ReCalcSportActivityFish  bool
	MoveUserExtCardInfo      bool
	DeleteBlackListDuplicate bool
	AddUserExtTalkMode       bool
	ResetUserBirth           bool
	FirstOnlineHallOfFame    bool
	Add4centAward            bool
	ResetUserActivityDaily   bool
}

func InitCommand(mngDB *mongo.Client, mysqlDB *gorm.DB, redisCli *redis.Client) {
	Command = &command{
		mysqlDB: mysqlDB,
		mngDB:   mngDB,
		redisDB: redisCli,
	}
}

func (c *command) Run() {
	parse()
	switch {
	case c.ReCalcSportActivityFish:
		calcSportActivityFish(c.mngDB)
		os.Exit(0)
	case c.MoveUserExtCardInfo:
		moveUserInfoExtCard(c.mngDB)
		os.Exit(0)
	case c.DeleteBlackListDuplicate:
		fixBlackList(c.mngDB)
		os.Exit(0)
	case c.AddUserExtTalkMode:
		addUserExtTalkMode(c.mngDB, c.mysqlDB)
		os.Exit(0)
	case c.ResetUserBirth:
		c.resetUserBrith()
		os.Exit(0)
	case c.FirstOnlineHallOfFame:
		c.FirstOnLineHallOfFame()
		os.Exit(0)
	case c.Add4centAward:
		c.Add4centsForAward()
		os.Exit(0)
	case c.ResetUserActivityDaily:
		c.resetUserActivityDaily()
		os.Exit(0)
	}
}

func parse() {
	flag.BoolVar(&Command.ReCalcSportActivityFish, "sport", false, "重新计算一次鱼干数")
	flag.BoolVar(&Command.MoveUserExtCardInfo, "card", false, "迁移")
	flag.BoolVar(&Command.DeleteBlackListDuplicate, "black", false, "清理拉黑自己")
	flag.BoolVar(&Command.AddUserExtTalkMode, "talkMode", false, "给所有未成年设置闭关模式")
	flag.BoolVar(&Command.ResetUserBirth, "birth", false, "修改生日信息")
	flag.BoolVar(&Command.ResetUserActivityDaily, "userAcitvityDaily", false, "修复留存表中的is_new字段")
	flag.BoolVar(&Command.FirstOnlineHallOfFame, "firstHOF", false, "第一次上线名人堂")
	flag.BoolVar(&Command.Add4centAward, "add4cents", false, "add 0.4")
	flag.Parse()
}
