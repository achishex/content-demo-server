package model

import (
	"content_svr/protobuf/pbdb"
	"content_svr/pub/errors"
	"context"
	"encoding/json"
	"gorm.io/gorm"
	"gorm.io/plugin/dbresolver"
)

type IReportRewardDbModel interface {
	ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.ReportRewardDbModel, error)
	GetItemById(ctx context.Context, userId int64) (*pbdb.ReportRewardDbModel, error)
	UpdateItem(ctx context.Context, model *pbdb.ReportRewardDbModel) (*pbdb.ReportRewardDbModel, error)
	CreateItem(ctx context.Context, model *pbdb.ReportRewardDbModel) (*pbdb.ReportRewardDbModel, error)
	CountItemsByCondition(ctx context.Context, condition map[string]interface{}) (total int64, _ error)
	UpdateByCondition(ctx context.Context, condition, changes map[string]interface{}) error
	DictByCondition(ctx context.Context, condition map[string]interface{},
		page uint64, size uint64) (map[int64]*pbdb.ReportRewardDbModel, error)
}

type ReportRewardDbModelImpl struct {
	DB *gorm.DB
}

func NewReportRewardDbModelImpl(db *gorm.DB) IReportRewardDbModel {
	return &ReportRewardDbModelImpl{DB: db}
}

func (impl *ReportRewardDbModelImpl) table() string {
	return "report_reward"
}

func (impl *ReportRewardDbModelImpl) GetItemById(ctx context.Context, userId int64) (*pbdb.ReportRewardDbModel, error) {
	model := pbdb.ReportRewardDbModel{}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Clauses(dbresolver.Write).
		Where("user_id = ?", userId).First(&model)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	return &model, errors.Wrap(result.Error)
}

func (impl *ReportRewardDbModelImpl) UpdateItem(ctx context.Context, model *pbdb.ReportRewardDbModel) (*pbdb.ReportRewardDbModel, error) {
	modelDict := make(map[string]interface{})
	modelByte, err := json.Marshal(model)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(modelByte, &modelDict)
	if err != nil {
		return nil, err
	}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Where("user_id = ?", model.GetUserId()).Updates(modelDict)
	return model, errors.Wrap(result.Error)
}

func (impl *ReportRewardDbModelImpl) CreateItem(ctx context.Context, model *pbdb.ReportRewardDbModel) (*pbdb.ReportRewardDbModel, error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Create(model)
	return model, errors.Wrap(result.Error)
}

// offset 开始查的默认值为0
func (impl *ReportRewardDbModelImpl) ListItemOffset(ctx context.Context, condition map[string]interface{}, page int, size int) ([]*pbdb.ReportRewardDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.ReportRewardDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(size).Offset(offset).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}

	return items, errors.Wrap(result.Error)
}

func (impl *ReportRewardDbModelImpl) ListItemsByCondition(ctx context.Context,
	condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.ReportRewardDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.ReportRewardDbModel
	result := impl.DB.WithContext(ctx).Table(impl.table()).Limit(int(size)).Offset(int(offset)).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *ReportRewardDbModelImpl) CountItemsByCondition(ctx context.Context,
	condition map[string]interface{}) (total int64, _ error) {
	result := impl.DB.WithContext(ctx).Table(impl.table()).Model(&pbdb.ReportRewardDbModel{}).Where(condition).Count(&total)
	return total, errors.Wrap(result.Error)
}

func (impl *ReportRewardDbModelImpl) UpdateByCondition(ctx context.Context,
	condition, changes map[string]interface{}) error {
	if len(condition) == 0 || len(changes) == 0 {
		return nil
	}
	result := impl.DB.WithContext(ctx).Table(impl.table()).Where(condition).Updates(changes)
	return errors.Wrap(result.Error)
}

func (impl *ReportRewardDbModelImpl) DictByCondition(ctx context.Context, condition map[string]interface{},
	page uint64, size uint64) (map[int64]*pbdb.ReportRewardDbModel, error) {
	items, err := impl.ListItemsByCondition(ctx, condition, page, size)
	if err != nil {
		return nil, err
	}
	resp := make(map[int64]*pbdb.ReportRewardDbModel)

	for _, item := range items {
		resp[item.GetUserId()] = item
	}
	return resp, nil
}
