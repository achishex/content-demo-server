package job

import (
	"bytes"
	"content_svr/config"
	"content_svr/db/aggregation"
	"content_svr/db/dao"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"context"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"strconv"
	"time"
)

type GameReq struct {
	OpenId      string `json:"openId"`
	ProductCode string `json:"productCode"`
	Sign        string `json:"sign"`
	//EventID     string `json:"eventId"`
	//Data      *Data  `json:"data"`
}

type GameResp struct {
	Status bool   `json:"status"`
	Items  []Item `json:"data"`
	//AuxInfo AuxInfo `json:"auxInfo"`
	//BusinessLabels  []interface{} `json:"businessLabels"`
}

type Item struct {
	Date            string `json:"date"`
	ProductId       string `json:"productId"`
	ProductName     string `json:"productName"`
	NewUser         string `json:"newUser"`
	NewDevice       string `json:"newDevice"`
	ActiveUser      string `json:"activeUser"`
	UserLogin       string `json:"userLogin"`
	AllPay          string `json:"allPay"`
	AllPayUser      string `json:"allPayUser"`
	ChannelCode     string `json:"channelCode"`
	NewPayUser      string `json:"newPayUser"`
	NewUserPayCount string `json:"newUserPayCount"`
	NewUserPay      string `json:"newUserPay"`
	PayCount        string `json:"payCount"`
	FirstPayUser    string `json:"firstPayUser"`
	TotalPayUser    string `json:"totalPayUser"`
}

type TodayData struct {
	Date        string
	ProductId   string
	ProductName string
	NewUser     int // 当日注册用户数
	NewDevice   int
	//ActiveUser      int
	UserLogin       int     // 当日活跃用户数
	AllPay          float64 // 当日玩家充值总额
	AllPayUser      int
	ChannelCode     string
	NewPayUser      int
	NewUserPayCount int
	NewUserPay      float64 // 当日的新用户充值额
	PayCount        int
	FirstPayUser    int
	TotalPayUser    int
}

type GameAdResp struct {
	Code  int `json:"code"`
	Count int `json:"count"`

	Items []AdItem `json:"results"`
}

type AdItem struct {
	Day              string `json:"day"`
	Application      string `json:"application"`
	Ecpm             string `json:"ecpm"`
	AdFormat         string `json:"ad_format"`
	Impressions      string `json:"impressions"`
	EstimatedRevenue string `json:"estimated_revenue"`
	Network          string `json:"network"`
	Platform         string `json:"platform"`
}

type gameControl struct {
	write, read *dao.ManagerDB
	sumDb       *aggregation.SumManage
}

func newGameControl(write, read *dao.ManagerDB) *gameControl {
	return &gameControl{
		write: write,
		read:  read,
		sumDb: aggregation.NewSumManage(read, write),
	}
}

func InitGameRobotTodayDetail(write, read *dao.ManagerDB) {
	ctx := requestid.WithRequestID(context.Background())
	loc := time.FixedZone("CST", -5*3600) // 秘鲁时间
	target := time.Now().In(loc)
	ctrl := newGameControl(write, read)

	if err := ctrl.DoTaskBy60Min(ctx, target, true); err != nil {
		logger.Error(context.Background(), "InitCSJ:", err)
	}

	if err := ctrl.DoTaskBy60Min(ctx, target, false); err != nil {
		logger.Error(context.Background(), "InitCSJ:", err)
	}
}

func (r gameControl) DoTaskBy60Min(ctx context.Context, targetTime time.Time, isAndroid bool) error {
	productId := "64073932357668645735256636872459" // ios
	appName := "iOS"
	if isAndroid {
		productId = "70345124778348655040523833083380" // android
		appName = "Android"
	}

	data, err := getDayData(ctx, targetTime, productId)
	if err != nil || data == nil {
		return err
	}

	NewUser := plain{
		Tag:  "text",
		Text: fmt.Sprintf("新用户 %v\n", data.NewUser),
	}
	NewUserArpu := plain{
		Tag:  "text",
		Text: fmt.Sprintf("新用户arpu %.2f\n", data.NewUserPay/float64(data.NewUser)),
	}
	NewAllPay := plain{
		Tag:  "text",
		Text: fmt.Sprintf("新用户充值(美元) %.2f\n", data.NewUserPay),
	}

	AllPay := plain{
		Tag:  "text",
		Text: fmt.Sprintf("日活用户充值(美元) %.2f\n", data.AllPay),
	}
	//PayCount := plain{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("日活用户充值笔数 %v\n", data.PayCount),
	//}
	UserLogin := plain{
		Tag:  "text",
		Text: fmt.Sprintf("日活用户 %v\n", data.UserLogin),
	}
	UserArpu := plain{
		Tag:  "text",
		Text: fmt.Sprintf("日活arpu %.2f\n", data.AllPay/float64(data.UserLogin)),
	}

	items := []plain{
		NewUser,
		NewAllPay,
		NewUserArpu,
		UserLogin,
		AllPay,
		UserArpu,
		//PayCount,
	}

	//logger.Infof(ctx, "==gameControl items: %v", items)

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = fmt.Sprintf("%v 实时数据, (%v utc-5)", appName, TimeByHour(targetTime))
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	if config.ServerConfig.Env == "test" {
		RobotServerControl.SendMessage(m)
	} else {
		RobotGameControl.SendMessage(m)
	}
	logger.Infof(ctx, "==gameControl do task finish send msg")

	return nil
}

func TimeByHour(baseTime time.Time) string {
	dateStr := fmt.Sprintf("%02d月%02d号%02d时", baseTime.Month(), baseTime.Day(), baseTime.Hour())
	return dateStr
}

func InitGameRobotLastdayDetail(write, read *dao.ManagerDB) {
	ctx := requestid.WithRequestID(context.Background())
	target := time.Now().AddDate(0, 0, -1)
	ctrl := newGameControl(write, read)
	if err := ctrl.DoTaskLastDay(ctx, target, true); err != nil {
		logger.Error(context.Background(), "InitCSJ:", err)
	}
	if err := ctrl.DoTaskLastDay(ctx, target, false); err != nil {
		logger.Error(context.Background(), "InitCSJ:", err)
	}
}

func (r gameControl) DoTaskLastDay(ctx context.Context, targetTime time.Time, isAndroid bool) error {
	productId := "64073932357668645735256636872459" // ios
	appName := "iOS"
	if isAndroid {
		productId = "70345124778348655040523833083380" // android
		appName = "Android"
	}

	data, err := getDayData(ctx, targetTime, productId)
	if err != nil {
		return err
	}

	adAmount, _ := getAdvertisingData(ctx, targetTime, targetTime)

	items := []plain{
		{
			Tag:  "text",
			Text: fmt.Sprintf("新用户 %v\n", data.NewUser),
		},
		{
			Tag:  "text",
			Text: fmt.Sprintf("新用户充值(美元) %.2f\n", data.NewUserPay),
		},
		{
			Tag:  "text",
			Text: fmt.Sprintf("新用户arpu %.2f\n", data.NewUserPay/float64(data.NewUser)),
		},
		{
			Tag:  "text",
			Text: fmt.Sprintf("日活用户 %v\n", data.UserLogin),
		},
		{
			Tag:  "text",
			Text: fmt.Sprintf("日活用户充值(美元) %.2f\n", data.AllPay),
		},
		{
			Tag:  "text",
			Text: fmt.Sprintf("日活arpu %.2f\n", data.AllPay/float64(data.UserLogin)),
		},
	}

	if isAndroid {
		items = append(items, plain{
			Tag:  "text",
			Text: fmt.Sprintf("双端广告收入(美元) %.2f\n", adAmount),
		})
	}

	day, _ := utils.TimeByDay(targetTime)
	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = fmt.Sprintf("%v %v 游戏数据(utc-5)", day, appName)
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	if config.ServerConfig.Env == "test" {
		RobotServerControl.SendMessage(m)
	} else {
		RobotGameControl.SendMessage(m)
	}
	logger.Infof(ctx, "==gameControl do task finish send msg, lastday")

	return nil
}

func getDayData(ctx context.Context, targetDate time.Time, productId string) (*TodayData, error) {
	resp, err := getDailyData(ctx, targetDate, targetDate, productId)
	if err != nil || resp.Status == false {
		return nil, err
	}

	logger.Infof(ctx, "==gameControl item count %v", len(resp.Items))

	data := &TodayData{}
	for i := 0; i < len(resp.Items); i++ {
		item := resp.Items[i]
		data.Date = item.Date
		data.ProductName = item.ProductName

		logger.Infof(ctx, "==gameControl item %+v", item)

		NewUser, _ := strconv.Atoi(item.NewUser)
		data.NewUser += NewUser

		NewUserPay, _ := strconv.ParseFloat(item.NewUserPay, 64)
		data.NewUserPay += NewUserPay

		NewUserPayCount, _ := strconv.Atoi(item.NewUserPayCount)
		data.NewUserPayCount += NewUserPayCount

		UserLogin, _ := strconv.Atoi(item.UserLogin)
		data.UserLogin += UserLogin

		AllPay, _ := strconv.ParseFloat(item.AllPay, 64)
		data.AllPay += AllPay

		PayCount, _ := strconv.Atoi(item.PayCount)
		data.PayCount += PayCount
	}

	return data, nil
}

func getDailyData(ctx context.Context, sDate time.Time, eDate time.Time, productId string) (*GameResp, error) {
	const (
		http_address = "https://quicksdk.52mengdong.com/open/daysReport"
	)
	bdate := sDate.Format("2006-01-02")
	edate := eDate.Format("2006-01-02")
	sign := fmt.Sprintf("bdate=%v&edate=%v&openId=HLQOZg&productCode=%v&fQydMFFjTNdL3M2OpzSnq9bcISXzGWPW", bdate, edate, productId)

	logger.Infof(ctx, "==gameControl date %v", bdate)

	// 用url.values方式构造form-data参数
	formValues := url.Values{}
	formValues.Set("openId", "HLQOZg")
	formValues.Set("productCode", productId)
	formValues.Set("bdate", bdate)
	formValues.Set("edate", edate)
	formValues.Set("sign", getMD5To32(sign))
	formDataStr := formValues.Encode()
	formDataBytes := []byte(formDataStr)
	formBytesReader := bytes.NewReader(formDataBytes)

	//生成post请求
	client := &http.Client{}
	req, err := http.NewRequest("POST", http_address, formBytesReader)
	if err != nil {
		// handle error
		log.Fatal("生成请求失败！", err)
		return nil, err
	}

	//注意别忘了设置header
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	//Do方法发送请求
	resp, err := client.Do(req)
	if err != nil {
		logger.Infof(ctx, "%v", err)
		return nil, err
	}
	sRespBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	//logger.Infof(ctx, "game=%v", string(sRespBytes))
	// 解析
	Resp := &GameResp{}
	err = json.Unmarshal(sRespBytes, Resp)
	if err != nil {
		return nil, err
	}

	return Resp, nil
}

func getMD5To32(str string) string {
	if str == "" {
		return ""
	}
	data := []byte(str) //切片
	h := md5.New()
	h.Write(data)
	return hex.EncodeToString(h.Sum(nil))
}

func getAdvertisingData(ctx context.Context, sDate time.Time, eDate time.Time) (float64, error) {
	begin := fmt.Sprintf("%04d-%02d-%02d", sDate.Year(), sDate.Month(), sDate.Day())
	end := fmt.Sprintf("%04d-%02d-%02d", eDate.Year(), eDate.Month(), eDate.Day())
	url := fmt.Sprintf("https://r.applovin.com/maxReport?api_key=CC2no4z6n0r4oOdJ5kL335mtVvMvb8dlJ3l83mHyv8voWMlQVrNXmAvnoG2bmPg5bU5XT_PXXO3ABUHIGzHKoz&start=%v&end=%v&format=json&columns=day,application,ecpm,ad_format,impressions,estimated_revenue,network,platform&report_type=advertiser", begin, end)

	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		return 0, err
	}
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return 0, err
	}

	sRespBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		return 0, err
	}

	// 解析
	Resp := &GameAdResp{}
	err = json.Unmarshal(sRespBytes, Resp)
	if err != nil || Resp.Code != 200 {
		return 0, err
	}

	amount := 0.0
	for _, item := range Resp.Items {
		v, _ := strconv.ParseFloat(item.EstimatedRevenue, 64)
		amount += v
	}

	return amount, nil
}
