package model

import "go.mongodb.org/mongo-driver/bson/primitive"

type SuperiorAwardDaily struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	Day                          int64 `json:"day" bson:"day"`                                                             // 时间戳
	AwardSettlementSum           uint  `json:"award_settlement_sum" bson:"award_settlement_sum"`                           // 当天结算奖励总和
	DeductionIllegalSum          uint  `json:"deduction_illegal_sum" bson:"deduction_illegal_sum"`                         // 当天违规扣除总和
	FirstWorkSettlementSum       uint  `json:"first_work_settlement_sum" bson:"first_work_settlement_sum"`                 // 当天首条动态奖励总和
	WechatPayWithdrawSuccessSum  uint  `json:"wechat_pay_withdraw_success_sum" bson:"wechat_pay_withdraw_success_sum"`     // 当天微信提现成功总和
	WechatPayWithdrawFailSum     uint  `json:"wechat_pay_withdraw_fail_sum" bson:"wechat_pay_withdraw_fail_sum"`           // 当天微信提现失败总和
	HallOfFameAwardSettlementSum uint  `json:"hall_of_fame_award_settlement_sum" bson:"hall_of_fame_award_settlement_sum"` // 当天排行榜奖励总和
	GameSum                      uint  `json:"game_sum" bson:"game_sum"`                                                   // 游戏收益统计
	PartnerInviteReward          uint  `json:"partner_invite_award_sum" bson:"partner_invite_award_sum"`                   // 合伙人邀请奖励
	PartnerCarveUp               uint  `json:"partner_carveup_sum" bson:"partner_carveup_sum"`                             // 合伙人瓜分奖励

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` // 创建时间
}
