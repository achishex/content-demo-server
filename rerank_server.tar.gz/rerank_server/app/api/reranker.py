from app.models.reranker_protocal import RerankRequestModel
from app.models.reranker_protocal import RerankResponseModel
from app.models.reranker_protocal import RetrieveSimilarQResponseModel
from app.models.reranker_protocal import RetrieveSimilarQRequestModel
from app.services.retrieve_similar_questions import RetrieveSimilarQuestionService
from app.services.rerank_service import ReRankService
from fastapi import APIRouter
from app.core.logs import logger
from app.utils.time_op import timeCost

router = APIRouter()


@router.post("/smart-customer-service/v1/rerank_after_retrieve", response_model=RerankResponseModel, response_model_exclude_none=True)
async def rerankAfterRetrieve(req: RerankRequestModel)-> any:
    try:
        rk = ReRankService()
        return rk.Rerank(req)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return {"error": str(e)}


@router.post("/smart-customer-service/v1/retrieve_similar_questions", response_model=RetrieveSimilarQResponseModel, response_model_exclude_none=True)
async def rerankRetrieveSimilarQuestion(req: RetrieveSimilarQRequestModel) -> any:

    try:
        retriever = RetrieveSimilarQuestionService()
        return retriever.RetrieveSimilarQuestion(req)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return {"error": str(e)}
    finally:
        pass