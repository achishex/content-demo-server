package cache

import (
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type OperatorTab struct {
	query.OperatorTab
	redisManage *query_rds.Manage
}

func NewCacheOperatorTab(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *OperatorTab {
	return &OperatorTab{
		OperatorTab: query.NewOperatorTab(mysql.OperatorTab),
		redisManage: redisManage,
	}
}
