package m_const

// 启用状态,1:启用，2:限时封禁，3:永久封禁
const (
	_        = iota
	UserOpen = 1
	//UserForbiddenExpire
	UserForbidden = 3
)
