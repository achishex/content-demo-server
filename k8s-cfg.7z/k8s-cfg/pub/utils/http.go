package utils

import (
	"net/http"
	"time"
)

var DefaultHTTPClient = &http.Client{
	Timeout: 15 * time.Second,
}
