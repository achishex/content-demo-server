package once

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/user"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

func (c *command) resetUserBrith() {
	db := c.mngDB.Database(config.ServerConfig.MongodbConfig.DBName)
	secretUserExtInfoCollection := db.Collection("secretUserExtInfo")
	userCardCollection := db.Collection("secretUserIdentificationCard")

	ctx := context.Background()

	filter := bson.D{
		//{"user_id", 4456877474663424},
		{"status", 1},
	}
	cur, err := userCardCollection.Find(ctx, filter)
	if err != nil {
		panic(err)
	}

	for cur.Next(ctx) {
		var card *pbmgdb.SecretUserIdentificationCard
		err := cur.Decode(&card)
		if err != nil {
			logger.Error(ctx, "Decode error:", err)
			continue
		}
		if len(card.CardId) != 18 {
			continue
		}
		dateNumStr := card.CardId[6:14]
		t, err := time.Parse("20060102", dateNumStr)
		if err != nil {
			logger.Error(ctx, "time.Parse:", err)
			continue
		}
		birth := t.Format("2006-01-02")
		adult, err := user.JudgeAdult(birth)
		if err != nil {
			// 格式错误
			panic(err)
		}

		if adult {
			logger.Infof(ctx, "userId: %d card: %s", card.UserId, card.CardId)
		} else {
			logger.Infof(ctx, "Underage userId: %d card: %s", card.UserId, card.CardId)
			filterUser := bson.D{
				{"_id", card.UserId},
			}
			updateTalkMode := bson.D{
				{"$set", bson.D{
					{"talkMode", const_busi.TalkModeClose},
				}},
			}
			// 更新mongo私聊模式
			if _, err := secretUserExtInfoCollection.UpdateOne(ctx, filterUser, updateTalkMode); err != nil {
				logger.Error(ctx, "update secretUserIdentificationCard talkMode error", err)
			}
			// 更新redis配置
			rdsKey := fmt.Sprintf("platform:%v:cache:userInfo:config:%v", config.ServerConfig.Env, card.UserId)
			if err := c.redisDB.HSet(ctx, rdsKey, "talkMode", const_busi.TalkModeClose).Err(); err != nil {
				logger.Error(ctx, "c.redisDB.HSet talkMode error", err)
			}
		}

		// 更新mysql生日信息
		if err := c.mysqlDB.Table("user_info").Where("user_id = ?", card.UserId).Update("birth", birth).Error; err != nil {
			logger.Error(ctx, "update user_info error", err)
		}
	}

}
