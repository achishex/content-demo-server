package shumei_proxy

import (
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	"io"
)

// 接口文档：https://help.ishumei.com/docs/tw/riskTel/newest/developDoc/
func (p *ShumeiProxy) CheckTelPhone(ctx context.Context, phoneNum string) (int32, *PhoneResp, error) {
	url := p.HostPhone

	req := map[string]interface{}{
		"accessKey": p.AccessKey,
		//"appId":     "default",
		"data": map[string]interface{}{
			"phone": phoneNum,
		},
	}
	reqByte, err := json.Marshal(req)
	// req
	sResp, err := p.postRequest(ctx, url, reqByte)
	if err != nil {
		return 0, nil, err
	}
	sRespBytes, err := io.ReadAll(sResp.Body)
	if err != nil {
		return 0, nil, err
	}
	logger.Infof(ctx, "shumei.CheckPhone, phone=%v, resp=%v", phoneNum, string(sRespBytes))

	// 解析
	phoneResp := &PhoneResp{}
	err = json.Unmarshal(sRespBytes, phoneResp)
	if err != nil {
		return 0, nil, err
	}
	if phoneResp.Code != 1100 {
		logger.Errorf(ctx, "shumei.checkPhone.api failed, BResp.Code=%v", phoneResp.Code)
		return 0, nil, fmt.Errorf("手机号校验失败")
	}

	if len(phoneResp.PhoneRiskLabels) > 0 {
		logger.Infof(ctx, "quding_shumei.check_phone_1, phone=%v, list=%v", phoneNum, phoneResp.PhoneRiskLabels)
		for _, riskLabel := range phoneResp.PhoneRiskLabels {
			if _, ok := riskMaps[riskLabel.Label1]; ok {
				logger.Infof(ctx, "quding_shumei.check_phone_2, phone=%v, label=%v", phoneNum, riskLabel.Label1)
				return 1, nil, nil
			}
		}
	}

	return 0, phoneResp, nil
}

var riskMaps = map[string]string{
	"black_record_phone": "black_record_phone",
	"sms_platform_phone": "sms_platform_phone",
	"iot_simcard_phone":  "sms_platform_phone",
	"mvno_simcard_phone": "sms_platform_phone",
	"sms_group_phone":    "sms_group_phone",
	//"relate_riskdevice_phone": "relate_riskdevice_phone",
}
