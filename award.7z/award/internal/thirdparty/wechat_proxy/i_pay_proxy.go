package wechat_proxy

import (
	"content_svr/config"
	"content_svr/pub/errors"
	"content_svr/pub/logger"
	localUtils "content_svr/pub/utils"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"github.com/wechatpay-apiv3/wechatpay-go/core"
	"github.com/wechatpay-apiv3/wechatpay-go/core/option"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments/app"
	"github.com/wechatpay-apiv3/wechatpay-go/services/transferbatch"
	"github.com/wechatpay-apiv3/wechatpay-go/utils"
	"sync"
)

const (
	PayTypeWeChat = iota + 1
)

// Mock defintion
const (
	MockPayTypeWeChat = PayTypeWeChat + 1000
)

type IPayProxy interface {
	Transfer(ctx context.Context, req *WeChatPayReq) (*WeChatPayResponse, error)
	QueryTransferBatchInfo(ctx context.Context, req *BatchQueryByMchIdReq) (*BatchQueryByMchIdResp, error)

	AppPrepay(ctx context.Context, req *app.PrepayRequest) (*app.PrepayResponse, error)
	QueryOrderById(ctx context.Context, req app.QueryOrderByIdRequest) (resp *payments.Transaction, err error)
	QueryOrderByOutTradeNo(ctx context.Context, req app.QueryOrderByOutTradeNoRequest) (resp *payments.Transaction, err error)
}

func NewPayProxy(payType int32) IPayProxy {
	switch payType {
	case PayTypeWeChat:
		return getWechatPayInstance()
	}
	return nil
}

func getWechatPayInstance() IPayProxy {
	return &WechatPay{
		AppId:                      config.ServerConfig.WechatConfig.AppId,
		MchId:                      config.ServerConfig.WechatConfig.MchID,
		MchCertificateSerialNumber: config.ServerConfig.WechatConfig.MchCertificateSerialNumber,
		MchAPIv3Key:                config.ServerConfig.WechatConfig.MchAPIv3Key,
		MchPrivateKeyFile:          config.ServerConfig.WechatConfig.PrivateKeyFile,
		//
		initError: nil,
	}
}

type WechatPay struct {
	AppId                      string                                 //商户应用id
	MchId                      string                                 // 商户号
	MchCertificateSerialNumber string                                 // 商户证书序列号
	MchAPIv3Key                string                                 // 商户APIv3密钥
	MchPrivateKeyFile          string                                 // 商户私钥文件路径
	TransferHandler            *transferbatch.TransferBatchApiService //转账请求客户端
	AppService                 *app.AppApiService                     //app支付请求客户端

	initError error
}

const (
	WechatPayAccept = iota
	WechatPayPROCESSING
	WechatPayFINISHED
	WechatPayCLOSED
)

var WeChatPayStatus map[int32]string = map[int32]string{
	WechatPayAccept:     "ACCEPTED",
	WechatPayPROCESSING: "PROCESSING",
	WechatPayFINISHED:   "FINISHED",
	WechatPayCLOSED:     "CLOSED",
}

func (p *WechatPay) InitPayClient(ctx context.Context) error {
	wpath, err := localUtils.GetWorkPath()
	if err != nil {
		panic(fmt.Sprintf("get workpath failed. err:%v", err.Error()))
	}

	mchPrivateKey, err := utils.LoadPrivateKeyWithPath(wpath + "/cert/" + p.MchPrivateKeyFile)
	if err != nil {
		p.initError = err
		logger.Errorf(ctx, "load private key file fail, err: %v", err)
		return err
	}
	opts := []core.ClientOption{
		option.WithWechatPayAutoAuthCipher(p.MchId, p.MchCertificateSerialNumber, mchPrivateKey, p.MchAPIv3Key),
	}
	weChatPayClient, err := core.NewClient(ctx, opts...)
	if err != nil {
		p.initError = err
		logger.Errorf(ctx, "new wechat pay client fail, err: %v", err)
		return err
	}
	if weChatPayClient == nil {
		logger.Errorf(ctx, "wechat pay client is nil")
		p.initError = errors.New("client is nil")
		return p.initError
	}
	p.TransferHandler = &transferbatch.TransferBatchApiService{Client: weChatPayClient}
	p.AppService = &app.AppApiService{Client: weChatPayClient}

	logger.Infof(ctx, "init wechat pay client ok")
	return nil
}

var onceWeChatPay sync.Once

func checkTransferReqParams(req *WeChatPayReq) error {
	if req == nil {
		return errors.New("req is nil")
	}
	if len(req.AppId) <= 0 {
		return errors.New("appid is nil")
	}
	if len(req.OutBatchNo) <= 0 {
		return errors.New("out batch no is nil")
	}
	if len(req.BatchName) <= 0 {
		return errors.New("batch name is nil")
	}
	if len(req.BatchRemark) <= 0 {
		return errors.New("batch remark is nil")
	}
	if len(req.TransferDetailList) <= 0 {
		return errors.New("transfer detail list is nil")
	}
	if int(req.TotalNum) != len(req.TransferDetailList) {
		return errors.New(fmt.Sprintf("transfer detail list len: %v != total nums: %v",
			len(req.TransferDetailList), req.TotalNum))
	}

	for _, v := range req.TransferDetailList {
		if len(v.OutDetailNo) <= 0 {
			return errors.New("detail out detail no is nil")
		}
		if v.TransferAmount <= 0 {
			return errors.New("detail trans amount is nil")
		}
		if len(v.TransferRemark) <= 0 {
			return errors.New("detail transfer remark is nil")
		}
		if len(v.ReceiverOpenId) <= 0 {
			return errors.New("detail receiver openid is nil")
		}
	}
	return nil
}

func (p *WechatPay) Transfer(ctx context.Context, req *WeChatPayReq) (*WeChatPayResponse, error) {
	onceWeChatPay.Do(func() {
		p.InitPayClient(ctx)
	})
	if p.TransferHandler == nil {
		logger.Errorf(ctx, "wechat pay client not init or init fail, err: %v", p.initError)
		return nil, p.initError
	}
	if err := checkTransferReqParams(req); err != nil {
		logger.Errorf(ctx, "req param is invalid, err: %v", err)
		return nil, err
	}
	remoteReqMsg := transferbatch.InitiateBatchTransferRequest{
		Appid:       proto.String(req.AppId),
		OutBatchNo:  proto.String(req.OutBatchNo),
		BatchName:   proto.String(req.BatchName),
		BatchRemark: proto.String(req.BatchRemark),
		TotalAmount: proto.Int64(req.TotalAmount),
		TotalNum:    proto.Int64(req.TotalNum),
	}

	for _, v := range req.TransferDetailList {
		item := transferbatch.TransferDetailInput{
			OutDetailNo:    proto.String(v.OutDetailNo),
			TransferAmount: proto.Int64(v.TransferAmount),
			TransferRemark: proto.String(v.TransferRemark),
			Openid:         proto.String(v.ReceiverOpenId),
		}
		if len(v.UserName) > 0 {
			item.UserName = proto.String(v.UserName)
		}
		remoteReqMsg.TransferDetailList = append(remoteReqMsg.TransferDetailList, item)
	}

	if len(req.TransferSceneId) > 0 {
		remoteReqMsg.TransferSceneId = proto.String(req.TransferSceneId)
	}
	resp, result, err := p.TransferHandler.InitiateBatchTransfer(ctx, remoteReqMsg)
	if err != nil {
		logger.Errorf(ctx, "req transfer fail, err: %v, status: %d, req: %s", err.Error(), result.Response.StatusCode, remoteReqMsg)
		return nil, err
	}

	logger.Infof(ctx, "req tran response status: %d, resp: %s, req: %s", result.Response.StatusCode, resp, remoteReqMsg)

	ret := &WeChatPayResponse{}
	if resp.OutBatchNo != nil {
		ret.OutBatchNo = *(resp.OutBatchNo)
	}
	if resp.BatchId != nil {
		ret.BatchId = *(resp.BatchId)
	}
	if resp.CreateTime != nil {
		ret.CreateTime = resp.CreateTime
	}
	if resp.BatchStatus != nil {
		ret.BatchStatus = *(resp.BatchStatus)
	}

	//core.IsAPIError(err, "INVALID_REQUEST")
	return ret, nil
}

func checkQueryBatchInfoReqParams(req *BatchQueryByMchIdReq) error {
	if req == nil {
		return errors.New("req is nil")
	}
	if len(req.OutBatchNo) <= 0 {
		return errors.New("out batch no is nil")
	}
	return nil
}

func (p *WechatPay) ProtocolSwitch(ctx context.Context, resp *transferbatch.TransferBatchEntity) (*BatchQueryByMchIdResp, error) {
	retItem := &BatchQueryByMchIdResp{}
	if resp.TransferBatch == nil {
		logger.Errorf(ctx, "query response TransferBatch is nil")
		return nil, errors.New("query response TransferBatch is nil")
	}
	//
	if resp.TransferBatch.Mchid != nil {
		retItem.MchId = *(resp.TransferBatch.Mchid)
	}
	if resp.TransferBatch.OutBatchNo != nil {
		retItem.OutBatchNo = *(resp.TransferBatch.OutBatchNo)
	}
	if resp.TransferBatch.BatchId != nil {
		retItem.BatchId = *(resp.TransferBatch.BatchId)
	}
	if resp.TransferBatch.Appid != nil {
		retItem.AppId = *(resp.TransferBatch.Appid)
	}
	if resp.TransferBatch.BatchStatus != nil {
		retItem.BatchStatus = *(resp.TransferBatch.BatchStatus)
	}
	if resp.TransferBatch.BatchType != nil {
		retItem.BatchType = *(resp.TransferBatch.BatchType)
	}
	if resp.TransferBatch.BatchName != nil {
		retItem.BatchName = *(resp.TransferBatch.BatchName)
	}
	if resp.TransferBatch.BatchRemark != nil {
		retItem.BatchRemark = *(resp.TransferBatch.BatchRemark)
	}
	if resp.TransferBatch.CloseReason != nil {
		retItem.CloseReason = string(*(resp.TransferBatch.CloseReason))
	}
	if resp.TransferBatch.TotalAmount != nil {
		retItem.TotalAmount = *(resp.TransferBatch.TotalAmount)
	}
	if resp.TransferBatch.TotalNum != nil {
		retItem.TotalNum = *(resp.TransferBatch.TotalNum)
	}
	if resp.TransferBatch.CreateTime != nil {
		retItem.CreateTime = resp.TransferBatch.CreateTime
	}
	if resp.TransferBatch.UpdateTime != nil {
		retItem.UpdateTime = resp.TransferBatch.UpdateTime
	}
	if resp.TransferBatch.SuccessAmount != nil {
		retItem.SuccessAmount = *(resp.TransferBatch.SuccessAmount)
	}
	if resp.TransferBatch.SuccessNum != nil {
		retItem.SuccessNum = *(resp.TransferBatch.SuccessNum)
	}
	if resp.TransferBatch.FailAmount != nil {
		retItem.FailAmount = *(resp.TransferBatch.FailAmount)
	}
	if resp.TransferBatch.FailNum != nil {
		retItem.FailNum = *(resp.TransferBatch.FailNum)
	}
	if resp.TransferBatch.TransferSceneId != nil {
		retItem.TransferSceneId = *(resp.TransferBatch.TransferSceneId)
	}

	for _, v := range resp.TransferDetailList {
		dItem := TransferDetailItem{}

		if v.DetailStatus != nil {
			dItem.DetailStatus = *(v.DetailStatus)
		}
		if v.DetailId != nil {
			dItem.DetailId = *(v.DetailId)
		}
		if v.OutDetailNo != nil {
			dItem.OutDetailNo = *(v.OutDetailNo)
		}
		retItem.TransferDetails = append(retItem.TransferDetails, dItem)
	}
	return retItem, nil
}

func (p *WechatPay) QueryTransferBatchInfo(ctx context.Context, req *BatchQueryByMchIdReq) (*BatchQueryByMchIdResp, error) {
	onceWeChatPay.Do(func() {
		p.InitPayClient(ctx)
	})

	if p.TransferHandler == nil {
		logger.Errorf(ctx, "wechat pay client not init or init fail, err: %v", p.initError)
		return nil, p.initError
	}
	if err := checkQueryBatchInfoReqParams(req); err != nil {
		logger.Errorf(ctx, "check query batch info req param fail, err: %v", err)
		return nil, err
	}

	//required fields
	reqBatchInfo := transferbatch.GetTransferBatchByOutNoRequest{
		OutBatchNo:      proto.String(req.OutBatchNo),
		NeedQueryDetail: proto.Bool(req.NeedQueryDetail),
	}
	//optional fields
	if req.Offset > 0 {
		reqBatchInfo.Offset = proto.Int64(req.Offset)
	}
	if req.Limit > 0 {
		reqBatchInfo.Limit = proto.Int64(req.Limit)
	}
	if len(req.DetailStatus) > 0 {
		reqBatchInfo.DetailStatus = proto.String(req.DetailStatus)
	}

	resp, result, err := p.TransferHandler.GetTransferBatchByOutNo(ctx, reqBatchInfo)
	if err != nil {
		logger.Errorf(ctx, "QueryTransferBatchInfo fail, err: %v, req: %s", err, reqBatchInfo)
		return nil, err
	}
	logger.Infof(ctx, "QueryTransferBatchInfo succ, req: %s, response: %s, req: %s, status: %d", reqBatchInfo, resp, result.Response.StatusCode)

	return p.ProtocolSwitch(ctx, resp)
}

// 预下单
func (p *WechatPay) AppPrepay(ctx context.Context, req *app.PrepayRequest) (*app.PrepayResponse, error) {
	onceWeChatPay.Do(func() {
		if err := p.InitPayClient(ctx); err != nil {
			logger.Errorf(ctx, "init wechat client error: %v", err)
			return
		}
	})

	logger.Infof(ctx, "req: %v", req)

	req.Mchid = core.String(p.MchId)
	req.Appid = core.String(p.AppId)
	if p.TransferHandler == nil {
		logger.Errorf(ctx, "wechat pay client not init or init fail, err: %v", p.initError)
		return nil, p.initError
	}

	resp, result, err := p.AppService.Prepay(ctx, *req)

	if err != nil {
		// 处理错误
		logger.Errorf(ctx, "call Prepay err:%s", err)
		return nil, err
	}

	logger.Infof(ctx, "status=%d resp=%s", result.Response.StatusCode, resp)

	return resp, nil
}

func (p *WechatPay) QueryOrderById(ctx context.Context, req app.QueryOrderByIdRequest) (resp *payments.Transaction, err error) {
	onceWeChatPay.Do(func() {
		if err := p.InitPayClient(ctx); err != nil {
			logger.Errorf(ctx, "init wechat client error: %v", err)
			return
		}
	})

	logger.Infof(ctx, "req: %v", req)

	resp, result, err := p.AppService.QueryOrderById(ctx, req)

	if err != nil {
		// 处理错误
		logger.Errorf(ctx, "call Prepay err:%s", err)
		return nil, err
	}

	logger.Infof(ctx, "status=%d resp=%s", result.Response.StatusCode, resp)

	return resp, nil
}

func (p *WechatPay) QueryOrderByOutTradeNo(ctx context.Context, req app.QueryOrderByOutTradeNoRequest) (resp *payments.Transaction, err error) {
	onceWeChatPay.Do(func() {
		if err := p.InitPayClient(ctx); err != nil {
			logger.Errorf(ctx, "init wechat client error: %v", err)
			return
		}
	})

	logger.Infof(ctx, "req: %v", req)

	resp, result, err := p.AppService.QueryOrderByOutTradeNo(ctx, req)

	if err != nil {
		// 处理错误
		logger.Errorf(ctx, "call Prepay err:%s", err)
		return nil, err
	}

	logger.Infof(ctx, "status=%d resp=%s", result.Response.StatusCode, resp)

	return resp, nil
}
