package user

import (
	"content_svr/pub/utils"
	"strconv"
	"time"
)

func JudgeAdult(birth string) (bool, error) {
	match := utils.RegDateLayout.FindStringSubmatch(birth)
	if len(match) != 4 {
		return true, nil
	}
	yearStr := match[1]
	monthStr := match[2]
	dayStr := match[3]
	year, err := strconv.Atoi(yearStr)
	if err != nil {
		return true, err
	}
	month, err := strconv.Atoi(monthStr)
	if err != nil {
		return true, err
	}
	day, err := strconv.Atoi(dayStr)
	if err != nil {
		return true, err
	}

	now := time.Now()
	birthTime := time.Date(year, time.Month(month), day, 0, 0, 0, 0, now.Location())
	if err != nil {
		return true, err
	}
	ago18 := time.Date(now.Year()-18, now.Month(), now.Day(), 0, 0, 0, 0, now.Location())

	return birthTime.Before(ago18), nil
}
