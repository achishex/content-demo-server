package report

import (
	"content_svr/app/maozhua_admin_svr/common/xconst"
	"content_svr/db/mongodb/model"
	"context"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type SetBlackHouseLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewSetBlackHouseLogic(ctx context.Context, svcCtx *svc.ServiceContext) *SetBlackHouseLogic {
	return &SetBlackHouseLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *SetBlackHouseLogic) SetBlackHouse(req *types.SetBlackHouseReq) (resp *types.SetBlackHouseResp, err error) {
	now := time.Now()
	var endTime int64

	switch req.Type {
	case 0: // 从小黑屋释放
		_ = l.svcCtx.RedisClient.UserInfo.RemoveUserFromBlackHouse(l.ctx, req.UserId)
		return
	case 1:
		endTime = now.Add(xconst.Day * 1).UnixMilli()
	case 3:
		endTime = now.Add(xconst.Day * 3).UnixMilli()
	case 10:
		endTime = now.Add(xconst.Day * 10).UnixMilli()
	case 100:
		endTime = now.Add(xconst.Day * 100).UnixMilli()
	}

	if endTime > 0 {
		data := &model.SecretBlackHouse{
			UserId: req.UserId,
			Start:  now.UnixMilli(),
			End:    endTime,
			Status: 1,
		}
		_, err = l.svcCtx.WriteDB.SecretBlackHouse.Insert(l.ctx, data)
		if err != nil {
			return nil, err
		}
	}

	return
}
