package security_mng

import (
	"content_svr/internal/busi_comm/constant/aq_const"
	"content_svr/protobuf/pbsecurity"
	"content_svr/pub/logger"
	"context"
	"strings"
)

func (p *SecurityMng) CheckUpdateUserInfo(ctx context.Context,
	req *pbsecurity.CheckUpdateUserInfoReq) (*pbsecurity.CheckUpdateUserInfoSimple, error) {

	resp := &pbsecurity.CheckUpdateUserInfoSimple{
		BForbidUser:             false,
		NickNameVerifyStatus:    aq_const.AqConst.Pass,
		DescriptionVerifyStatus: aq_const.AqConst.Pass,
		PhotoVerifyStatus:       aq_const.AqConst.Pass,
	}

	// 检查昵称
	if req.GetNickName() != "" {
		auditResult, err := p.CheckTxt(ctx, req.GetUserId(), MArticleEventId.Nickname, req.GetNickName(), 1)
		if err != nil {
			logger.Errorf(ctx, "CheckUpdateUserInfo nickname error ,user_id %v, %v", req.GetUserId(), req.GetNickName())
			return nil, err
		}

		passed := p.checkSensitiveWords(ctx, req.GetNickName())

		//没通过，直接返回
		if auditResult != aq_const.AqConst.Pass || !passed {
			logger.Infof(ctx, "CheckUpdateUserInfo nickname reject ,user_id %v, %v, auditResult %v, passed %v", req.GetUserId(), req.GetNickName(), auditResult, passed)
			resp.NickNameVerifyStatus = aq_const.AqConst.Reject
			return resp, nil
		}
	}

	// 检查签名
	if req.GetDescription() != "" {
		auditResult, err := p.CheckTxt(ctx, req.GetUserId(), MArticleEventId.Profile, req.GetDescription(), 0)
		if err != nil {
			logger.Errorf(ctx, "CheckUpdateUserInfo description error ,user_id %v, %v", req.GetUserId(), req.GetNickName())

			return nil, err
		}

		passed := p.checkSensitiveWords(ctx, req.GetDescription())

		//没通过，直接返回
		if auditResult != aq_const.AqConst.Pass || !passed {
			logger.Infof(ctx, "CheckUpdateUserInfo description reject ,user_id %v, %v, auditResult %v, passed %v", req.GetUserId(), req.GetNickName(), auditResult, passed)
			resp.DescriptionVerifyStatus = aq_const.AqConst.Reject
			return resp, nil
		}
	}

	// 检查头像
	if req.GetPhoto() != "" {
		auditResult, err := p.CheckImage(ctx, req.GetUserId(), MImgEventId.HeadImage, req.GetPhoto())
		if err != nil {
			return nil, err
		}

		//没通过，直接返回
		if auditResult != aq_const.AqConst.Pass {
			logger.Infof(ctx, "CheckUpdateUserInfo header_photo reject ,user_id %v, %v", req.GetUserId(), req.GetPhoto())
			resp.PhotoVerifyStatus = aq_const.AqConst.Reject
			return resp, nil
		}
	}
	return resp, nil
}

// 昵称、简介单独的审核逻辑
func (p *SecurityMng) checkSensitiveWords(ctx context.Context, content string) bool {
	logger.Infof(ctx, "CheckUpdateUserInfo content check, %v", content)

	if strings.Contains(content, "猫爪") {
		return false
	}

	if strings.Contains(content, "猫抓") {
		return false
	}

	return true
}
