package job

import (
	"content_svr/config"
	"content_svr/db/dao"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"content_svr/pub/utils"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"time"
)

type robotRetainControl struct {
	write, read *dao.ManagerDB
}

func InitRetainRobot(write, read *dao.ManagerDB) {
	ctrl := robotRetainControl{}
	ctrl.write = write
	ctrl.read = read

	{ // DAU 统计
		ctx := requestid.WithRequestID(context.Background())
		target := time.Now().AddDate(0, 0, -1)
		if err := ctrl.DoRetainTask(ctx, target); err != nil {
			logger.Error(context.Background(), "InitRetainRobot,dau,err:", err)
		}
	}

	{ // 次留统计
		ctx := requestid.WithRequestID(context.Background())
		target := time.Now().AddDate(0, 0, -2)
		if err := ctrl.DoSecondRemainTask(ctx, target); err != nil {
			logger.Error(context.Background(), "InitRetainRobot,remain,err:", err)
		}
	}
}

func (r robotRetainControl) DoRetainTask(ctx context.Context, targetTime time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	day, _ := utils.TimeByDay(targetTime)
	filter := map[string]interface{}{
		"day": day,
	}

	// SecretUserChannelDaily
	channelList, err := r.read.SecretUserChannelDaily.FindAll(ctx, filter)
	if err != nil {
		return err
	}

	activeUserCount := 0
	activeTargetUserCount := 0
	newUserCount := 0
	newTargetUserCount := 0
	for _, item := range channelList {
		activeUserCount += item.ActiveUserCount
		activeTargetUserCount += item.ActiveTargetUserCount
		newUserCount += item.NewUserCount
		newTargetUserCount += item.NewTargetUserCount

	}

	//member, err := r.read.UserMemberStatistical.FindOne(ctx, filter)
	//if err != nil {
	//	return err
	//}

	newUserCountMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("新增活跃用户留存: %d\n", newUserCount),
	}
	newTargetUserCountMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("新增目标用户留存: %d\n", newTargetUserCount),
	}
	activeUserCountMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("老活跃用户留存: %d\n", activeUserCount),
	}
	activeTargetUserCountMessage := plain{
		Tag:  "text",
		Text: fmt.Sprintf("老目标用户留存: %.d\n", activeTargetUserCount),
	}
	//WechatPayWithdrawFailSumMessage := item{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天微信提现失败总和: %.2f\n", float64(data.WechatPayWithdrawFailSum)/100),
	//}
	//HallOfFameAwardSettlementSumMessage := item{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天排行榜奖励总和: %.2f\n", float64(data.HallOfFameAwardSettlementSum)/100),
	//}
	//MemberSumMessage := item{
	//	Tag:  "text",
	//	Text: fmt.Sprintf("当天充值总和: %.2f\n", float64(member.PriceSum)/100),
	//}
	items := []plain{
		newUserCountMessage,
		newTargetUserCountMessage,
		activeUserCountMessage,
		activeTargetUserCountMessage,
	}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = fmt.Sprintf("%d DAU统计", day)
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	if config.ServerConfig.Env == "test" {
		RobotServerControl.SendMessage(m)
	} else {
		RobotBossControl.SendMessage(m)
	}

	return nil
}

// DoSecondRemainTask 次留推送
func (r robotRetainControl) DoSecondRemainTask(ctx context.Context, targetTime time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	day, _ := utils.TimeByDay(targetTime)

	// SecretUserChannelDaily
	channelList, err := r.read.SecretUserChannelDaily.FindAll(ctx, bson.M{
		"day": day,
	})
	if err != nil {
		logger.Errorf(ctx, "DoSecondRemainTask,find all,err: %v", err)
		return err
	}

	newUserCount := 0
	channelMap := make(map[string]int)
	for _, item := range channelList {
		newUserCount += item.NewUserCount

		if _, ok := channelMap[item.Channel]; ok {
			channelMap[item.Channel] = channelMap[item.Channel] + item.NewUserCount
		} else {
			channelMap[item.Channel] = item.NewUserCount
		}
	}

	// 次留的数据
	dayOneList, err := r.read.SecretUserRetainedStatisticsModel.FindAll(ctx, bson.M{
		"day":         day,
		"retain_type": 1,
	})
	if err != nil {
		logger.Errorf(ctx, "DoSecondRemainTask,dayOneList,err: %v", err)
		return err
	}

	dayOneCount := 0
	dayOneMap := make(map[string]int)
	for _, item := range dayOneList {
		dayOneCount += item.NewRetainCount

		if _, ok := dayOneMap[item.Channel]; ok {
			dayOneMap[item.Channel] = dayOneMap[item.Channel] + item.NewRetainCount
		} else {
			dayOneMap[item.Channel] = item.NewRetainCount
		}
	}

	items := make([]plain, 0)
	items = append(items, plain{
		Tag:  "text",
		Text: fmt.Sprintf("新用户 %v, 次留 %.1f%%\n", newUserCount, 100*float64(dayOneCount)/float64(newUserCount)),
	})

	for k, v := range dayOneMap {
		remain := 0.0
		if channelMap[k] > 0 {
			remain = 100 * float64(v) / float64(channelMap[k])
		}

		items = append(items, plain{
			Tag:  "text",
			Text: fmt.Sprintf("%v: %v, %.1f%%\n", k, channelMap[k], remain),
		})
	}

	m := Message{}
	m.MsgType = "post"
	m.Content.Post.ZhCn.Title = fmt.Sprintf("%d 次留统计", day)
	m.Content.Post.ZhCn.Content = make([][]plain, 0)
	m.Content.Post.ZhCn.Content = append(m.Content.Post.ZhCn.Content, items)

	if config.ServerConfig.Env == "test" {
		RobotServerControl.SendMessage(m)
	} else {
		RobotBossControl.SendMessage(m)
	}

	return nil
}
