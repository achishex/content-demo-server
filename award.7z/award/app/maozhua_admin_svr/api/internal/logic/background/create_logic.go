package background

import (
	"content_svr/db/mongodb/model"
	"context"
	"github.com/jinzhu/copier"
	"sync"
	"time"

	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"

	"github.com/zeromicro/go-zero/core/logx"
)

type CreateLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewCreateLogic(ctx context.Context, svcCtx *svc.ServiceContext) *CreateLogic {
	return &CreateLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

var createLock sync.RWMutex

func (l *CreateLogic) Create(req *types.BackgroundCreateReq) (resp *types.BackgroundCreateResp, err error) {
	createLock.Lock()
	defer createLock.Unlock()
	bImage := &model.BackgroundImage{}
	if err := copier.Copy(bImage, req); err != nil {
		return nil, err
	}

	now := time.Now().UnixMilli()
	if now >= bImage.TimePartEnd {
		bImage.Status = false
	}

	if err := l.svcCtx.ManagerDB.BackgroundImage.Create(l.ctx, bImage); err != nil {
		return nil, err
	}

	return
}
