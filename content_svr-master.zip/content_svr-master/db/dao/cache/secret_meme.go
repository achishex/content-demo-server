package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type SecretMeme struct {
	model.SecretMemeModel
	redisManage *query_rds.Manage
}

func NewCacheSecretMeme(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *SecretMeme {
	return &SecretMeme{
		SecretMemeModel: mongo.SecretMeme,
		redisManage:     redisManage,
	}
}
