package mg_model

import (
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/snow_flake"
	"context"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type ISecretUserIdentificationCardMgModel interface {
	Create(ctx context.Context, data *pbmgdb.SecretUserIdentificationCard, opts ...*options.InsertOneOptions) error
	FindOne(ctx context.Context, filter bson.D, opts ...*options.FindOneOptions) (*pbmgdb.SecretUserIdentificationCard, error)
	FindAll(ctx context.Context, filter bson.D, opts ...*options.FindOptions) ([]*pbmgdb.SecretUserIdentificationCard, error)
	Count(ctx context.Context, filter bson.D, opts ...*options.CountOptions) (int64, error)
	UpdateMap(ctx context.Context, filter, update map[string]interface{}) (*mongo.UpdateResult, error)
	UpdateByUserId(ctx context.Context, data *pbmgdb.SecretUserIdentificationCard, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error)
}

type SecretUserIdentificationCardMgModelImpl struct {
	MgDB       *mongo.Database
	Collection *mongo.Collection
}

func NewSecretUserIdentificationCardMgModelImpl(db *mongo.Database) ISecretUserIdentificationCardMgModel {
	record := &SecretUserIdentificationCardMgModelImpl{MgDB: db}
	record.Collection = record.MgDB.Collection(record.tableName())
	return record
}

func (impl *SecretUserIdentificationCardMgModelImpl) tableName() string {
	return "secretUserIdentificationCard"
}

func (impl *SecretUserIdentificationCardMgModelImpl) Create(ctx context.Context, data *pbmgdb.SecretUserIdentificationCard, opts ...*options.InsertOneOptions) error {
	data.Id = snow_flake.GetSnowflakeID()
	result, err := impl.Collection.InsertOne(ctx, data, opts...)
	if err != nil {
		return err
	}

	id, ok := result.InsertedID.(int64)
	if !ok {
		return nil
	}
	data.Id = id
	return nil
}

func (impl *SecretUserIdentificationCardMgModelImpl) UpdateByUserId(
	ctx context.Context, data *pbmgdb.SecretUserIdentificationCard, opts ...*options.UpdateOptions) (*mongo.UpdateResult, error) {
	filter := bson.D{
		{Key: "user_id", Value: data.UserId},
	}

	updater := bson.D{
		{Key: "$set", Value: data},
	}
	return impl.Collection.UpdateOne(ctx, filter, updater)
}

func (impl *SecretUserIdentificationCardMgModelImpl) Delete() {}

func (impl *SecretUserIdentificationCardMgModelImpl) Count(ctx context.Context, filter bson.D, opts ...*options.CountOptions) (int64, error) {
	return impl.Collection.CountDocuments(ctx, filter, opts...)
}
func (impl *SecretUserIdentificationCardMgModelImpl) FindOne(ctx context.Context, filter bson.D, opts ...*options.FindOneOptions) (*pbmgdb.SecretUserIdentificationCard, error) {
	result := &pbmgdb.SecretUserIdentificationCard{}
	err := impl.Collection.FindOne(ctx, filter, opts...).Decode(result)
	if err != nil {
		return nil, err
	}
	return result, nil
}

func (impl *SecretUserIdentificationCardMgModelImpl) FindAll(ctx context.Context, filter bson.D, opts ...*options.FindOptions) ([]*pbmgdb.SecretUserIdentificationCard, error) {
	cur, err := impl.Collection.Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	result := make([]*pbmgdb.SecretUserIdentificationCard, 0)
	for cur.Next(ctx) {
		item := &pbmgdb.SecretUserIdentificationCard{}
		if err := cur.Decode(item); err != nil {
			return nil, err
		}
		result = append(result, item)
	}

	return result, err
}

func (impl *SecretUserIdentificationCardMgModelImpl) UpdateMap(ctx context.Context, filter, update map[string]interface{}) (*mongo.UpdateResult, error) {
	conds := bson.D{}
	for key, value := range filter {
		conds = append(conds, bson.E{Key: key, Value: value})
	}

	data := bson.D{}
	for key, value := range update {
		data = append(data, bson.E{Key: key, Value: value})
	}
	updater := bson.D{
		{Key: "$set", Value: data},
	}

	return impl.Collection.UpdateMany(ctx, conds, updater)
}
