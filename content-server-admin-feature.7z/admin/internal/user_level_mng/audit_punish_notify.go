package user_level_mng

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"content_svr/pub/utils"
	"context"
	"errors"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
)

const (
	punishSerious = `
你于%s分享的%s“%s”内容严重违规，现已对你的账号进行等级重置处罚（现已降为Lv%d.%s）。
猫爪官方提醒您，请务必严格遵守《猫爪公约》，勿存侥幸心理！
`
	punishMedium = `
你于%s分享的%s“%s”内容违规，现已对你的账号进行警告降级处罚（现已降为Lv%d.%s）。
猫爪官方提醒您，请务必严格遵守《猫爪公约》，勿存侥幸心理！
`
	punishLight = `
你于%s分享的%s“%s”内容违规，现已对你的账号进行警告处罚。
猫爪官方提醒您，请务必严格遵守《猫爪公约》，勿存侥幸心理！
`
)

// 降级，返回降级后的等级
func (p *UserLevelMng) lowerUserLevel(ctx context.Context,
	verifyStatus int32, extInfo *pbapi.SecretUserExtInfoMgDbModel) (int32, error) {

	ulevel := extInfo.GetUlevel()
	switch {
	case utils.HasInt32Element(verifyStatus, cm_const.SeriousWeiGui):
		//严重违规，降低为0级
		changes := map[string]interface{}{
			"ulevel": 0, // cd时间60s
		}

		err := p.DataCache.GetImpl().UserInfoExtMgModel.UpdateDictById(ctx, extInfo.GetId(), changes, nil)
		if err != nil {
			logger.Error(ctx, "audit notify, serious weigui. change user level failed", err)
			return ulevel, err
		}
		ulevel = 0
	case utils.HasInt32Element(verifyStatus, cm_const.MediumWeiGui): // 中等违规，降1级
		//一般违规，ulevel降低一级
		if extInfo.GetUlevel() == 0 {
			// 零级没法降级
			_ = p.removeLevelRecord(ctx, extInfo.Id)
			return ulevel, nil
		}

		changes := map[string]interface{}{
			"ulevel": ulevel - 1, // 等级-1
		}
		err := p.DataCache.GetImpl().UserInfoExtMgModel.UpdateDictById(ctx, extInfo.GetId(), changes, nil)
		if err != nil {
			logger.Error(ctx, "audit notify, normal weigui. change user level failed", err)
			return ulevel, err
		}
		ulevel = ulevel - 1

	default:
		// 不处罚
		return ulevel, nil
	}

	// 降级把 user_level_up_record 的记录清空。
	err := p.removeLevelRecord(ctx, extInfo.Id)
	if err != nil {
		logger.Error(ctx, "激活码记录清空失败", err)
	}
	return ulevel, nil
}

func (p *UserLevelMng) punishNotify(ctx context.Context, status int32, message *notifyMessage) {
	//  处罚通知
	var lowerLevCfg *const_level.ULevelInfo
	var html string
	switch {
	case utils.HasInt32Element(status, cm_const.SeriousWeiGui):
		lowerLevCfg = const_level.GetLevelCfg(0)
		html = fmt.Sprintf(punishSerious, message.timeClock, message.messageType, message.content, lowerLevCfg.Level, lowerLevCfg.Title)
	case utils.HasInt32Element(status, cm_const.MediumWeiGui):
		lowerLevCfg = const_level.GetLevelCfg(message.ulevel)
		html = fmt.Sprintf(punishMedium, message.timeClock, message.messageType, message.content, lowerLevCfg.Level, lowerLevCfg.Title)
	case utils.HasInt32Element(status, cm_const.LightWeiGui):
		html = fmt.Sprintf(punishLight, message.timeClock, message.messageType, message.content)
	default:
		return
	}

	p.sendNotify(ctx, message.userId, html)
}

func (p *UserLevelMng) removeComment(ctx context.Context, status int32, userId, workId, commentId int64) error {
	if commentId == 0 {
		return errors.New("commentId is 0")
	}
	// 根据处罚类型，删除评论
	conds := make(map[string]interface{})
	conds["user_id"] = userId
	newValues := make(map[string]interface{})
	newValues["status"] = 2 // 0: 无效， 1: 有效  2:删除
	switch status {
	case cm_const.AuditStatusWait, cm_const.AuditStatusPass, cm_const.AuditStatusJuBaoBuChuLi:
		// 什么也不做
		return errors.New(fmt.Sprintf("verifyStatus type is %d", status))
	case cm_const.AuditStatusGuanXiaoHeiWu, cm_const.AuditStatusXiaoHeiWu1Day, cm_const.AuditStatusXiaoHeiWu3Day:
		// 删除该动态下该用户所有评论
		conds["work_id"] = workId
		break
	case cm_const.AuditStatusYongJiuFengHao, cm_const.AuditStatusGuanBiLaoLao:
		// 删除该用户的所有评论
		break
	default:
		return errors.New("verifyStatus type is error")
	}

	commentDetail, err := p.DataCache.GetImpl().WorkCommentDetailMgModel.GetCommentById(ctx, commentId)
	if err != nil {
		return err
	}
	if commentDetail != nil && commentDetail.GetStatus() == const_busi.CommentStatusClose {
		// 评论已被删除
		return nil
	}

	deleteCount, err := p.DataCache.GetImpl().WorkCommentDetailMgModel.DeleteItemsByCond(ctx, conds, newValues)
	if err != nil {
		return err
	}
	//logger.Infof(ctx, "修改: new_comment_count-deleteCount, count: %v, query: %v, 操作的动态id：%d, commentId: %d", deleteCount, conds, workId, commentId)
	err = p.DataCache.IncWorkInfoToNewCommentCount(ctx, workId, -deleteCount)

	return nil
}

// 清空签到记录
func (p *UserLevelMng) removeLevelRecord(ctx context.Context, userId int64) error {
	// 将更新的记录保存到db
	changes := map[string]interface{}{
		"sign_in_times": 0,
	}

	err := p.DataCache.GetImpl().SecretDailySignInMgModel.UpdateOne(ctx, bson.M{"user_id": userId}, changes)

	return err
}
