package model

import "go.mongodb.org/mongo-driver/bson/primitive"

const collectionNamePartnerDailySignIn = "partner_daily_sign_in"

type PartnerDailySignIn struct {
	ID         primitive.ObjectID `json:"id,omitempty" bson:"_id,omitempty"`
	UserId     int64              `json:"user_id,omitempty" bson:"user_id,omitempty json:"`         //合伙人用户id
	Day        string             `json:"day,omitempty" bson:"day,omitempty json:"`                 //日期
	IsAward    bool               `json:"is_award,omitempty" bson:"is_award,omitempty json:"`       //是否已奖励
	CreateTime int64              `json:"create_time,omitempty" bson:"create_time,omitempty json:"` //创建时间
	UpdateTime int64              `json:"update_time,omitempty" bson:"update_time,omitempty json:"` // 更新时间
}
