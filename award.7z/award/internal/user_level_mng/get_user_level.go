package user_level_mng

import (
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/internal/busi_comm/version"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/logger"
	"context"
	"github.com/jinzhu/copier"
	"sort"
)

func (p *UserLevelMng) GetUserLevel(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbuserapi.LevelInfo, error) {
	userId, err := p.getUserId(ctx, header)
	if err != nil {
		logger.Errorf(ctx, "get user id by token failed,err=%v", err.Error())
		return nil, errorcode.LOGIN_INVALID
	}
	ss, err := p.getUserLevSession(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user level session failed,err=%v", err.Error())
		return nil, errorcode.INTERNAL_ERROR
	}
	levelInfo := ss.getUserLev()

	// 已经是最高级，直接返回
	if ss.CurLevel == const_level.UserMaxLevel {
		return levelInfo, nil
	}

	result, err := p.checkLevUpAndUpdate(ctx, header, userId, ss, levelInfo, 0, 0)
	if err != nil {
		logger.Error(ctx, "GetUserLevel.checkLevUpAndUpdate", err)
		return nil, errorcode.INTERNAL_ERROR
	}

	if ss.CurLevel == const_level.UserLevel4 && header.GetVersioncode() < version.CommentEmotionVersion {
		levelInfo.NextLevelCard = nil
	}

	if result == nil || result.NextLevelInfo == nil {
		return levelInfo, nil
	}

	return result.NextLevelInfo, nil
}

func (p *UserLevelMng) GetLevelInfo(ctx context.Context, header *pbapi.HttpHeaderInfo) (*pbuserapi.LevelAllInfoResp, error) {
	userId, err := p.getUserId(ctx, header)
	if err != nil {
		return nil, err
	}
	ss, err := p.getUserLevSession(ctx, userId)
	if err != nil {
		return nil, err
	}

	resp := &pbuserapi.LevelAllInfoResp{
		LevelCards: make([]*pbuserapi.LevelBaseCard, 0),
	}
	penalties := ss.WeiGuiTimes != 0
	uis := const_level.GetUserLevelUp(penalties)

	keys := make([]int32, 0)
	for i, _ := range uis {
		keys = append(keys, i)
	}

	sort.Slice(keys, func(i, j int) bool {
		return keys[i] < keys[j]
	})

	for _, key := range keys {
		item := pbuserapi.LevelBaseCard{}
		err := copier.Copy(&item, uis[key])
		if err != nil {
			continue
		}

		resp.LevelCards = append(resp.LevelCards, &item)
	}

	return resp, err
}
