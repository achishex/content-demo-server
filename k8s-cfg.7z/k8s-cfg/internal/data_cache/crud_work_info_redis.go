package data_cache

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/go-redis/redis/v8"
)

func (p *DataCacheMng) SetUserVisitorCountRD(ctx context.Context, workIds []int64) error {
	if len(workIds) == 0 {
		return nil
	}
	// 操作redis
	for _, workId := range workIds {
		redisKey := getRdsKeyWorkInfo(workId)
		_, err := p.RedisCli.HIncrBy(ctx, redisKey, "visitorCount", 1).Result() //返回设置之后的值
		if err != nil {
			logger.Error(ctx,
				fmt.Sprintf("SetUserVisitorCountRD set redis failed. workid=%v", workId), err)
		}
	}
	//  设置db
	return p.PersonBottleWorksModel.UpdateVisitorCountCondBatch(ctx, workIds)
}

func (p *DataCacheMng) SetUserCommentCountRD(ctx context.Context, workIds []int64) error {
	if len(workIds) == 0 {
		return nil
	}
	// 操作redis
	for _, workId := range workIds {
		redisKey := getRdsKeyWorkInfo(workId)
		_, err := p.RedisCli.HIncrBy(ctx, redisKey, "talkUserCount", 1).Result() //返回设置之后的值
		if err != nil {
			logger.Error(ctx,
				fmt.Sprintf("SetUserVisitorCountRD set redis failed. workid=%v", workId), err)
		}
	}
	//  设置db
	err := p.PersonBottleWorksModel.UpdateCommentCountCondBatch(ctx, workIds)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SetUserCommentCountRD failed. workIds=%v", workIds), err)
	}
	return err
}

func (p *DataCacheMng) SetAuthorReplyCountD(ctx context.Context, workIds []int64) error {
	if len(workIds) == 0 {
		return nil
	}

	//  设置db
	err := p.PersonBottleWorksModel.UpdateAuthorReplyCountCondBatch(ctx, workIds)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SetUserCommentCountRD failed. workIds=%v", workIds), err)
	}
	return err
}

func (p *DataCacheMng) SetWorkStatus(ctx context.Context, workIds []int64, status int32) error {
	if len(workIds) == 0 {
		return nil
	}

	for _, workId := range workIds {
		redisKey := getRdsKeyWorkInfo(workId)
		_, err := p.RedisCli.HSet(ctx, redisKey, "status", status).Result()
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("SetUserVisitorCountRD set redis status failed. workid=%v", workId), err)
			return err
		}
	}

	return nil
}

func (p *DataCacheMng) SetWorkShowScope(ctx context.Context, workIds []int64, showScope int32) error {
	if len(workIds) == 0 {
		return nil
	}

	for _, workId := range workIds {
		redisKey := getRdsKeyWorkInfo(workId)
		_, err := p.RedisCli.HSet(ctx, redisKey, "showScope", showScope).Result()
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("SetUserVisitorCountRD set redis showScope failed. workid=%v", workId), err)
			return err
		}
	}

	return nil
}

// 获取记录到redis的 曝光量和点赞量。
func (p *DataCacheMng) GetWorkInfoRedis(ctx context.Context, workId int64) *pbapi.PersonalBottleWorksCache {
	redisKey := getRdsKeyWorkInfo(workId)
	resp := &pbapi.PersonalBottleWorksCache{}
	err := p.RedisCli.HGetAll(ctx, redisKey).Scan(resp)
	if err == redis.Nil {
		return nil
	}
	if err != nil && err != redis.Nil {
		logger.Error(ctx, fmt.Sprintf("GetUserCoordinate failed, redisKey=%v", redisKey), err)
		return nil
	}
	return resp
}
