package content_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/utils"
	"content_svr/setting"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"math/rand"
	"reflect"
	"time"
)

func (p *ContentMng) GetMemeSquare(ctx context.Context, req *pbapi.MemeSquareReq) (*pbapi.MemeSquareResp, error) {
	var (
		resp = &pbapi.MemeSquareResp{}

		memeAuditColl = p.DataCache.GetImpl().SecretEmoteAuditRecordMgModel
		memeColl      = p.DataCache.GetImpl().MemeMgDbModel
		m             = map[int64]*pbmgdb.SecretMemeMgDbModel{}

		totalQty = int(setting.Maozhua.OfficialMeme.TotalDisplayQty.Get())
		memeIds  = p.getSettingMemeList()
		size     = totalQty - len(memeIds)
	)

	timeRange := time.Now().UnixMilli()
	if req.LastUseTime > 0 {
		timeRange = req.LastUseTime
	}

	for {
		cond := bson.D{
			{"last_use_time", bson.M{"$lt": timeRange}},
			{"meme_id", bson.M{"$exists": true}},
			{"$or", []bson.M{
				{
					"report_count": bson.M{
						"$exists": true,
						"$lt":     2,
					},
				},
				{
					"report_count": bson.M{
						"$exists": false,
					},
				},
			}},
		}

		list, err := memeAuditColl.Find(ctx, cond, &options.FindOptions{
			Limit: proto.Int64(int64(size)),
			Sort:  bson.D{{"last_use_time", -1}},
		})

		if err != nil {
			return resp, nil
		}

		if len(list) == 0 || len(list) < size {
			timeRange = time.Now().UnixMilli()
		}

		for _, item := range list {
			if utils.Int64Exist(memeIds, item.MemeId) {
				continue
			}
			memeIds = append(memeIds, item.MemeId)
			timeRange = item.LastUseTime

			if resp.LastUseTime == 0 || item.LastUseTime < resp.LastUseTime {
				resp.LastUseTime = item.LastUseTime
			}
		}

		memeList, _ := memeColl.Find(ctx, bson.M{"_id": bson.M{"$in": memeIds}})
		for _, meme := range memeList {
			m[meme.Id] = meme
		}

		if size = totalQty - len(m); size > 0 {
			continue
		}

		break
	}

	for _, meme := range m {
		userInfo, _ := p.DataCache.GetUserBasicInfo(ctx, meme.OwnerId, false)
		nickName := ""
		if userInfo != nil && *userInfo.NickName != "" {
			nickName = *userInfo.NickName
		}

		resp.List = append(resp.List, &pbapi.MemeSquareItem{
			MemeId:   meme.GetId(),
			MemeUrl:  config.ServerConfig.ImageHost + meme.GetObjectId(),
			OwnerId:  meme.OwnerId,
			Nickname: nickName,
			Width:    meme.Width,
			High:     meme.High,
		})
	}

	return resp, nil
}

func (p *ContentMng) MemeReport(ctx context.Context, req *pbapi.MemeReportReq) (*pbapi.MemeReportResp, error) {
	var (
		resp          = &pbapi.MemeReportResp{}
		memeAuditColl = p.DataCache.GetImpl().SecretEmoteAuditRecordMgModel
		officialMeme  = p.getSettingMemeList()
	)

	meme, _ := memeAuditColl.FindOne(ctx, bson.M{"meme_id": req.MemeId})
	if meme == nil {
		//官方表情过滤
		for _, memeId := range officialMeme {
			if memeId == req.MemeId {
				return resp, nil
			}
		}
		return nil, errorcode.MemeNotFound
	}

	if err := memeAuditColl.UpdateOne(ctx, bson.M{"_id": meme.Id}, bson.M{"report_count": meme.ReportCount + 1, "update_time": time.Now().UnixMilli()}); err != nil {
		return nil, errorcode.MemeReportError
	}

	return resp, nil
}

func (p *ContentMng) getSettingMemeList() []int64 {
	var (
		m           []int64
		totalQty    = int(setting.Maozhua.OfficialMeme.TotalDisplayQty.Get())
		officialQty = int(setting.Maozhua.OfficialMeme.OfficialQty.Get())
	)

	if officialQty > totalQty {
		officialQty = totalQty
	}

	v := reflect.ValueOf(setting.Maozhua.OfficialMeme)
	for i := 1; i <= totalQty; i++ {
		field := v.FieldByName(fmt.Sprintf("Meme%d", i))
		//设置值
		if k := field.Field(0).Field(1).Kind(); k == reflect.Interface {
			if n, ok := field.Field(0).Field(1).Interface().(int64); ok && n > 0 {
				m = append(m, n)
			} else {
				//默认值
				if k := field.Field(1).Kind(); k == reflect.Int64 {
					if n, ok := field.Field(1).Interface().(int64); ok && n > 0 {
						m = append(m, n)
					}
				}
			}
		}
	}

	rand.Shuffle(len(m), func(i, j int) {
		m[i], m[j] = m[j], m[i]
	})
	return m[:officialQty]
}
