package model

import (
	"content_svr/pub/snow_flake"
	"context"
	"errors"
	"github.com/zeromicro/go-zero/core/stores/mon"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type area struct {
	ID     primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`
	Number int64              `bson:"number,omitempty" json:"number,omitempty"` // 序号
}

// 时间范围是否重叠
func checkArea(ctx context.Context, conn *mon.Model, baseQuery bson.D, startTime, endTime int64) (int64, bool, error) {
	var startQueryOne, endQueryOne area
	startAreaQuery := append(baseQuery, bson.E{Key: "time_part_start", Value: bson.D{{"$lte", startTime}}})
	startAreaQuery = append(startAreaQuery, bson.E{Key: "time_part_end", Value: bson.D{{"$gte", startTime}}})
	err := conn.FindOne(ctx, &startQueryOne, startAreaQuery)
	switch {
	case errors.Is(err, mon.ErrNotFound):
		break
	case err == nil:
		return startQueryOne.Number, true, err
	default:
		return 0, true, err
	}

	endAreaQuery := append(baseQuery, bson.E{Key: "time_part_start", Value: bson.D{{"$lte", endTime}}})
	endAreaQuery = append(endAreaQuery, bson.E{Key: "time_part_end", Value: bson.D{{"$gte", endTime}}})
	err = conn.FindOne(ctx, &endQueryOne, endAreaQuery)
	switch {
	case errors.Is(err, mon.ErrNotFound):
		break
	case err == nil:
		return endQueryOne.Number, true, err
	default:
		return 0, true, err
	}

	if startQueryOne.ID == primitive.NilObjectID && endQueryOne.ID == primitive.NilObjectID {
		// 没有时间重叠
		return 0, false, nil
	}

	return 0, true, nil

}

type idType interface {
	int64 | primitive.ObjectID | string
}

func checkID[D idType](id D) D {
	var value any = &id
	switch v := value.(type) {
	case *int64:
		if 0 == *v {
			*v = snow_flake.GetSnowflakeID()
		}

		return id
	case *primitive.ObjectID:
		if primitive.NilObjectID == *v {
			*v = primitive.NewObjectID()
		}
		return id
	default:
		return id
	}
}
