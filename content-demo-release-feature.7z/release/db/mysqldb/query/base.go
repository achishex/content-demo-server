package query

import "database/sql/driver"

type fieldValue struct {
	value any
}

func (f *fieldValue) Value() (driver.Value, error) {
	return f.value, nil
}
