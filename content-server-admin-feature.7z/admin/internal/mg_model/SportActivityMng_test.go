package mg_model

import (
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"log"
	"os"
	"testing"
)

var db *mongo.Database

func TestMain(m *testing.M) {
	client, err := mongo.Connect(context.Background(),
		options.Client().
			// 连接地址
			ApplyURI("mongodb://127.0.0.1:27017").

			// 设置连接数
			SetMaxPoolSize(20))
	if err != nil {
		log.Fatal(err)
	}
	db = client.Database("platform_test")
	os.Exit(m.Run())
}

func TestSportActivityMgModelImpl_GetAggregateUserActivitySport(t *testing.T) {
	s := SportActivityMgModelImpl{
		MgDB: db,
	}
	pipeline := bson.M{
		"$group": bson.M{
			"_id":        nil,
			"step_total": bson.M{"$sum": "$sport_step_nums"},
			"user_total": bson.M{"$sum": 1},
		},
	}
	p := make([]bson.M, 0)
	p = append(p, pipeline)
	result, err := s.GetAggregateUserActivitySport(context.Background(), p)
	if err != nil {
		return
	}

	fmt.Println(result)

}
