package model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/errors"
	"context"
	"encoding/json"
	"gorm.io/gorm"
	"time"
)

type IPersonalCardMessageQueueDbModel interface {
	ListAsc(ctx context.Context, cond map[string]interface{}, cursorId int64, size int32) ([]*pbapi.PersonalCardMessageQueueDbModel, error)
	UpdateItem(ctx context.Context, model *pbapi.PersonalCardMessageQueueDbModel) (*pbapi.PersonalCardMessageQueueDbModel, error)
	CreateItem(ctx context.Context, model *pbapi.PersonalCardMessageQueueDbModel) (*pbapi.PersonalCardMessageQueueDbModel, error)
	GetItemNums(ctx context.Context, eqCond, largeCond map[string]interface{}) (int64, error)
	GetValidMsgItems(ctx context.Context, eqCond, largeCond map[string]interface{}, specialFields []string) ([]map[string]interface{}, error)
	DeleteItemByGroupId(ctx context.Context, groupId int32, toUserId int64) error
}

type PersonalCardMessageQueueDbModelImpl struct {
	DB    *gorm.DB
	Table string
}

func NewPersonalCardMessageQueueDbModelImpl(db *gorm.DB) IPersonalCardMessageQueueDbModel {
	return &PersonalCardMessageQueueDbModelImpl{
		DB:    db,
		Table: "personal_card_message_queue",
	}
}
func (impl *PersonalCardMessageQueueDbModelImpl) DeleteItemByGroupId(ctx context.Context, groupId int32, toUserId int64) error {
	result := impl.DB.WithContext(ctx).Table(impl.Table).Where("group_id = ? and user_id = ?", groupId, toUserId).Delete(&pbapi.PersonalCardMessageQueueDbModel{})
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return nil
	}
	return errors.Wrap(result.Error)
}

func (impl *PersonalCardMessageQueueDbModelImpl) GetValidMsgItems(ctx context.Context, eqCond, largeCond map[string]interface{}, specialFields []string) ([]map[string]interface{}, error) {
	condStr := ""
	val := []interface{}{}
	for k, v := range eqCond {
		if len(condStr) > 0 {
			condStr += " and "
		}
		condStr += k
		condStr += " = ? "
		val = append(val, v)
	}

	calcUnixToStr := func(unixTime int64) string {
		t := time.Unix(unixTime, 0)
		layout := "2006-01-02 15:04:05"
		str := t.Format(layout)
		return str
	}

	for k, v := range largeCond {
		if len(condStr) > 0 {
			condStr += " and "
		}
		condStr += k
		if k == "create_time" {
			condStr += " between ? and ? "
			val = append(val, calcUnixToStr(v.(int64)), calcUnixToStr(time.Now().Unix()))
		} else {
			condStr += " > ? "
			val = append(val, v)
		}
	}
	opHandle := impl.DB.WithContext(ctx).Table(impl.Table)
	if len(specialFields) > 0 {
		opHandle.Select(specialFields)
	}
	var items []map[string]interface{}
	result := opHandle.Where(condStr, val...).Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) || len(items) <= 0 {
		return nil, nil
	}
	return items, errors.Wrap(result.Error)
}
func (impl *PersonalCardMessageQueueDbModelImpl) GetItemNums(ctx context.Context, eqCond, largeCond map[string]interface{}) (int64, error) {
	condStr := ""
	val := []interface{}{}
	for k, v := range eqCond {
		if len(condStr) > 0 {
			condStr += " and "
		}
		condStr += k
		condStr += " = ? "
		val = append(val, v)
	}

	calcUnixToStr := func(unixTime int64) string {
		t := time.Unix(unixTime, 0)
		layout := "2006-01-02 15:04:05"
		str := t.Format(layout)
		return str
	}

	for k, v := range largeCond {
		if len(condStr) > 0 {
			condStr += " and "
		}
		condStr += k
		if k == "create_time" {
			condStr += " between ? and ? "
			val = append(val, calcUnixToStr(v.(int64)), calcUnixToStr(time.Now().Unix()))
		} else {
			condStr += " > ? "
			val = append(val, v)
		}
	}
	retCount := int64(0)
	result := impl.DB.WithContext(ctx).Table(impl.Table).Where(condStr, val...).Count(&retCount)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return 0, nil
	}
	return retCount, errors.Wrap(result.Error)
}
func (impl *PersonalCardMessageQueueDbModelImpl) ListAsc(ctx context.Context, condition map[string]interface{},
	cursorId int64, size int32) ([]*pbapi.PersonalCardMessageQueueDbModel, error) {
	var items []*pbapi.PersonalCardMessageQueueDbModel
	result := impl.DB.WithContext(ctx).Table(impl.Table).Limit(int(size)).
		Where(condition).Where("id > ?", cursorId).Order("id asc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *PersonalCardMessageQueueDbModelImpl) UpdateItem(ctx context.Context, model *pbapi.PersonalCardMessageQueueDbModel) (*pbapi.PersonalCardMessageQueueDbModel, error) {
	modelDict := make(map[string]interface{})
	modelByte, err := json.Marshal(model)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(modelByte, &modelDict)
	if err != nil {
		return nil, err
	}
	result := impl.DB.WithContext(ctx).Table(impl.Table).Model(&pbapi.PersonalCardMessageQueueDbModel{Id: model.Id}).Updates(modelDict)
	return model, errors.Wrap(result.Error)
}

func (impl *PersonalCardMessageQueueDbModelImpl) CreateItem(ctx context.Context, model *pbapi.PersonalCardMessageQueueDbModel) (*pbapi.PersonalCardMessageQueueDbModel, error) {
	result := impl.DB.WithContext(ctx).Table(impl.Table).Create(model)
	return model, errors.Wrap(result.Error)
}
