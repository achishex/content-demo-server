package tests

import (
	"content_svr/internal/notify_mng"
	"content_svr/pub/taskq"
	"context"
	"fmt"
	"github.com/stretchr/testify/assert"
	"strconv"
	"testing"
	"time"
)

func TestPushUserNotice(t *testing.T) {
	//uid := int64(4804877856243712)
	//uid := int64(4504527306563584)

	uids := []int64{
		4560539365443584, //and
		4504527306563584, //ios
		4838267042234368, //old and
		4838279832698880, //old ios
	}

	ctx := context.Background()
	e := c.Invoke(func(nc *notify_mng.InactiveUserNotifyComp, tq *taskq.TaskQ) error {
		for _, uid := range uids {
			task := &taskq.TaskMsg{
				UserID:   strconv.FormatInt(uid, 10),
				TaskType: notify_mng.InactiveUserNotifyTaskType,
				TaskID:   fmt.Sprintf("inactive_user_notify_%v", uid),
			}
			if _, err := tq.Submit(ctx, task, 3*time.Second); err != nil {
				return err
			}
		}
		return nil
	})
	assert.Nil(t, e)
}
