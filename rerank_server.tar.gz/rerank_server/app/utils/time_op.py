import os
import time
import uvicorn
import torch
import asyncio
from typing import List
from datetime import datetime
from functools import wraps
from app.core.logs import logger


def printTime():
    now = datetime.now()
    formatted = now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}"
    print(formatted)

def timeCost(func):
    @wraps(func)
    async def async_wrapper(*args, **kwargs):
        start = time.time()
        try:
            return await func(*args, **kwargs)
        finally:
            end = time.time()
            logger.info(f"{func.__name__} 耗时: {(end - start) * 1000:.2f} milliseconds")

    @wraps(func)
    def sync_wrapper(*args, **kwargs):
        start = time.time()
        try:
            return func(*args, **kwargs)
        finally:
            end = time.time()
            logger.info(f"{func.__name__} 耗时: {(end - start) * 1000:.2f} milliseconds")
    # 判断是异步函数还是同步函数
    if asyncio.iscoroutinefunction(func):
        return async_wrapper
    else:
        return sync_wrapper
