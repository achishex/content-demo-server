package app_comm

import (
	"content_svr/config"
	"content_svr/internal/data_cache"
	"content_svr/internal/mg_model"
	"content_svr/internal/model"
	"content_svr/internal/model/im"
	"content_svr/internal/thirdparty/baidu_lbs_yun_proxy"
	go_cache "github.com/fanjindong/go-cache"
	rdsV8 "github.com/go-redis/redis/v8"
	"go.mongodb.org/mongo-driver/mongo"
	"gorm.io/gorm"
)

// BuildDataCache
// Deprecated, use di instead
func BuildDataCache(
	db *gorm.DB,
	dbIm im.IMDB,
	mgDb_cli *mongo.Client,
	redis_cli *rdsV8.Client,
	bdLbsProxy baidu_lbs_yun_proxy.IBaiduLbsYunProxy,
	localCache go_cache.ICache) data_cache.IDataCacheMng {

	//todo
	mgDb := mgDb_cli.Database(config.ServerConfig.MongodbConfig.DBName)
	// 初始化 mgdb层
	UserAwardSummaryMgModel := mg_model.NewUserAwardSummaryMgModelImpl(mgDb)
	KoLaWithdrawDetailMgModel := mg_model.NewKoLaWithdrawDetailMgModelImpl(mgDb)
	SuperiorContentAwardDetailMgModel := mg_model.NewSuperiorContentAwardDetailMgModelImpl(mgDb)
	NotificationReadCursorMgModel := mg_model.NewSNotificationReadCursorMgModelImpl(mgDb)
	CommentLikeDetailMgModel := mg_model.NewCommentLikeDetailMgModelImpl(mgDb)
	SportActivityMgModel := mg_model.NewSportActivityMgModelImpl(mgDb)
	PersonalUserAccountMgModel := mg_model.NewPersonalUserAccountMgModelImpl(mgDb)
	WorkCommentDetailMgModel := mg_model.NewWorkCommentDetailMgModelImpl(mgDb)
	UserCommentUnreadWorkMgModel := mg_model.NewUserCommentUnreadWorkMgModelImpl(mgDb)
	UserInfoExtMgModel := mg_model.NewSecretShareUserInfoExtMgModelImpl(mgDb)
	PersonalPoliceInfoMgModel := mg_model.NewPersonalPoliceInfoMgModelImpl(mgDb)
	WorkExpandRelMgModel := mg_model.NewWorksExpandRelMgModelImpl(mgDb)
	UserMedalMgModel := mg_model.NewSecretUserMedalInfoMgModelImpl(mgDb)
	MedalMgModel := mg_model.NewSecretMedalInfoMgModelImpl(mgDb)
	UserBlackListMgModel := mg_model.NewUserBlackListMgModelImpl(mgDb)
	PersonalTalkMessageTotalMgModel := mg_model.NewPersonalTalkMessageTotalMgModelImpl(mgDb)
	SecretUserFollowMgModel := mg_model.NewSecretUserFollowMgModelImpl(mgDb)
	SecretUserFollowBadgeMgModel := mg_model.NewSecretUserFollowBadgeMgModelImpl(mgDb)
	SecretUserFollowBadgeListMgModel := mg_model.NewSecretUserFollowBadgeListMgModelImpl(mgDb)
	SecretWorksLikeRecordMgModel := mg_model.NewSecretWorksLikeRecordMgModelImpl(mgDb)
	SecretUserWechatBindListMgModel := mg_model.NewSecretUserWechatBindListMgModelImpl(mgDb)
	PersonalTalkMessageRecordMgModel := mg_model.NewPersonalTalkMessageRecordMgModelImpl(mgDb)
	MemeMgModel := mg_model.NewSecretMemeMgModelImpl(mgDb)
	IpAddressMgModel := mg_model.NewIpAddressMgModelImpl(mgDb)
	SecretChitchatWorkMgModel := mg_model.NewSecretChitchatWorkMgModelImpl(mgDb)
	SignDailyFortuneMgModel := mg_model.NewSignDailyFortuneMgModelImpl(mgDb)
	secretChitChatCDKeyMgModel := mg_model.NewSecretChitChatCDKeyMgModelImpl(mgDb)
	PersonalUserNotificationMgModel := mg_model.NewPersonalUserNotificationMgModelImpl(mgDb)
	SecretReportMgModel := mg_model.NewSecretReportMgModelImpl(mgDb)
	SecretReportUserMgModel := mg_model.NewSecretReportUserMgModelImpl(mgDb)
	SecretMemberInfoMgModel := mg_model.NewSecretMemberInfoMgModelImpl(mgDb)
	UserRemindDetailMgModel := mg_model.NewUserRemindDetailMgModelImpl(mgDb)
	AuditAwardRecordMgModel := mg_model.NewAuditAwardRecordMgModelImpl(mgDb)
	SecretUserIdentificationCardMgModel := mg_model.NewSecretUserIdentificationCardMgModelImpl(mgDb)
	AuditMaliciousRecordMgModel := mg_model.NewAuditMaliciousRecordMgModelImpl(mgDb)
	PersonBottleWorksExtMgModel := mg_model.NewPersonBottleWorksExtMgModelImpl(mgDb)
	SecretGameMgModel := mg_model.NewSecretGameMgModelImpl(mgDb)
	SecretGameOrderMgModel := mg_model.NewSecretGameOrderMgModelImpl(mgDb)
	SecretPayOrderInfoMgModel := mg_model.NewSecretPayOrderInfoMgModelImpl(mgDb)
	SecretPayNotifyMgModel := mg_model.NewSecretPayNotifyMgModelImpl(mgDb)
	SecretActiveUserMgModel := mg_model.NewSecretActiveUserMgModelImpl(mgDb)
	SecretEmoteAuditRecordMgModel := mg_model.NewSecretEmoteAuditRecordMgModelImpl(mgDb)
	SecretAuditMgModel := mg_model.NewSecretAuditMgModelImpl(mgDb)
	SecretDailySignInMgModel := mg_model.NewSecretDailySignInMgModelImpl(mgDb)
	SecretSpeedCodeMgModel := mg_model.NewSecretSpeedCodeMgModelImpl(mgDb)
	SecretUserActivityDailyMgModel := mg_model.NewSecretUserActivityDailyMgModelImpl(mgDb)
	SecretGameStatisticMgModel := mg_model.NewSecretGameStatisticDailyMgModelImpl(mgDb)
	ImGroupMgModel := mg_model.NewImGroup(mgDb)
	AtDetailMgModel := mg_model.NewAtDetailMgModel(mgDb)
	secretUserLoginInfoMgModel := mg_model.NewSecretUserLoginInfoMgModel(mgDb)
	partnerMgModel := mg_model.NewPartnerMgModel(mgDb)
	partnerInviteMgModel := mg_model.NewPartnerInviteMgModel(mgDb)
	superiorAwardMgModel := mg_model.NewSuperiorAwardDailyMgModel(mgDb)
	csjAdvertisementDataMgModel := mg_model.NewCsjAdvertisementDataMgModel(mgDb)
	partnerDailySignInMgModel := mg_model.NewPartnerDailySignInMgModel(mgDb)

	// 初始化model层
	UserDbImpl := model.NewUserinfoDbModelImpl(db)
	PsWorkDbImpl := model.NewPersonalBottleWorksDbModelImpl(db)
	WorkObjectAttrImpl := model.NewWorkObjectAttrDbModelImpl(db)
	OpenUserDbImpl := model.NewOpenUserDbModelImpl(db)
	UserCircleWorksSwitchDbModelImpl := model.NewUserCircleWorksSwitchDbModelImpl(db)
	SecretExpandTypeModel := model.NewSecretExpandTypeDbModelImpl(db)
	PersonalCardMessageQueueDbModel := model.NewPersonalCardMessageQueueDbModelImpl(db)
	MaozhuaXingZuoModel := model.NewMaoZhuaXingZuoBirthDbModelImpl(db)
	UserLevelUpRecordDbModel := model.NewUserLevelUpRecordDbModelImpl(db)
	ReportRewardDbModel := model.NewReportRewardDbModelImpl(db)
	WorkCommentStatusDbModel := model.NewWorkCommentStatusDbModelImpl(db)
	OperatorModel := model.NewOperatorTabDbModelImpl(db)
	AdVivoFeedbackDbModel := model.NewAdVivoFeedbackDbModelDbModelImpl(db)

	//im model
	ImGroupsModel := im.NewImGroupsDbModelModel(dbIm)
	ImGroupMemberModel := im.NewImGroupMemberDbModelModel(dbIm)

	dataCache := data_cache.NewDataCacheMng(
		UserAwardSummaryMgModel,
		KoLaWithdrawDetailMgModel,
		SuperiorContentAwardDetailMgModel,
		NotificationReadCursorMgModel,
		CommentLikeDetailMgModel,
		UserRemindDetailMgModel,
		SecretMemberInfoMgModel,
		SecretReportMgModel,
		SecretReportUserMgModel,
		SportActivityMgModel,
		PersonalUserAccountMgModel,
		WorkCommentDetailMgModel,
		UserCommentUnreadWorkMgModel,
		PersonalUserNotificationMgModel,
		//personalBlackHouseInfoMgModelImpl,
		secretChitChatCDKeyMgModel,
		SignDailyFortuneMgModel,
		SecretChitchatWorkMgModel,
		IpAddressMgModel,
		MemeMgModel,
		PersonalTalkMessageRecordMgModel,
		SecretWorksLikeRecordMgModel,
		SecretUserFollowMgModel,
		SecretUserFollowBadgeMgModel,
		SecretUserFollowBadgeListMgModel,
		SecretUserWechatBindListMgModel,
		PersonalTalkMessageTotalMgModel,
		UserBlackListMgModel,
		UserMedalMgModel,
		MedalMgModel,
		WorkExpandRelMgModel,
		PersonalPoliceInfoMgModel,
		UserInfoExtMgModel,
		AuditAwardRecordMgModel,
		AuditMaliciousRecordMgModel,
		SecretUserIdentificationCardMgModel,
		PersonBottleWorksExtMgModel,
		SecretGameMgModel,
		SecretGameOrderMgModel,
		SecretPayOrderInfoMgModel,
		SecretPayNotifyMgModel,
		SecretActiveUserMgModel,
		SecretEmoteAuditRecordMgModel,
		SecretAuditMgModel,
		SecretDailySignInMgModel,
		SecretSpeedCodeMgModel,
		SecretUserActivityDailyMgModel,
		SecretGameStatisticMgModel,
		ImGroupMgModel,

		SecretExpandTypeModel, // DB
		WorkCommentStatusDbModel,
		ReportRewardDbModel,
		OperatorModel,
		UserLevelUpRecordDbModel,
		MaozhuaXingZuoModel,
		PersonalCardMessageQueueDbModel,
		UserCircleWorksSwitchDbModelImpl,
		AdVivoFeedbackDbModel,

		OpenUserDbImpl,
		WorkObjectAttrImpl,
		UserDbImpl,
		PsWorkDbImpl,
		ImGroupsModel,
		AtDetailMgModel,
		ImGroupMemberModel,
		secretUserLoginInfoMgModel,
		partnerMgModel,
		partnerInviteMgModel,
		superiorAwardMgModel,
		csjAdvertisementDataMgModel,
		partnerDailySignInMgModel,

		bdLbsProxy,
		redis_cli,
		localCache)
	return dataCache
}
