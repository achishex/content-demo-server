package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

const collectionNameUserRewardMoneyActivity = "userRewardMoneyActivity"

type UserRewardMoneyActivity struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	UserId int64 `json:"user_id,omitempty" bson:"user_id,omitempty"`
	Day    int64 `json:"day,omitempty" bson:"day,omitempty"` // 天数

	Type        int32  `json:"type,omitempty" bson:"type,omitempty"`         // 完成类型
	Complete    bool   `json:"complete,omitempty" bson:"complete,omitempty"` // 是否完成
	Scope       uint64 `json:"scope,omitempty" bson:"scope,omitempty"`       // 数值
	RewardCount uint64 `json:"reward_count" bson:"reward_count"`             // 奖励次数

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` //创建时间
	UpdateTime int64 `json:"update_time,omitempty" bson:"update_time,omitempty"` //更新时间
}
