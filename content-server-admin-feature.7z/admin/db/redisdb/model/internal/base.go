package internal

import (
	redisV8 "github.com/go-redis/redis/v8"
	"time"
)

type RdsInfo struct {
	Env    string        // 环境
	Expire time.Duration // 超时时间
	RdsKey string        // redis key

	Client *redisV8.Client // 链接
}
