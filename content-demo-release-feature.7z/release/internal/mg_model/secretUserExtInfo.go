package mg_model

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"content_svr/internal/busi_comm/constant/const_level"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"math/rand"
)

var InviteCodeLetterRunes = []rune("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz")

type ISecretShareUserInfoExtMgModel interface {
	// Query base
	Query(ctx context.Context, filter interface{}, opts ...*options.FindOptions) ([]*pbapi.SecretUserExtInfoMgDbModel, error)

	GetByUserId(ctx context.Context, userId int64) (*pbapi.SecretUserExtInfoMgDbModel, error)
	GetByUserIds(ctx context.Context, userIds []int64) ([]*pbapi.SecretUserExtInfoMgDbModel, error)
	GetAndCreate(ctx context.Context, userId int64) (*pbapi.SecretUserExtInfoMgDbModel, error)
	UpdateDictById(ctx context.Context, id int64, update map[string]interface{}, incDict map[string]int) error
	Insert(ctx context.Context, item *pbapi.SecretUserExtInfoMgDbModel) error
	ListByCondition(ctx context.Context, cond interface{}, page, size int64) ([]map[string]interface{}, error)
	ListByConditionModel(ctx context.Context,
		cond interface{}, page, size int64) ([]*pbapi.SecretUserExtInfoMgDbModel, error)
	DictByUserIds(ctx context.Context, userIds []int64) (map[int64]*pbapi.SecretUserExtInfoMgDbModel, error)
	UpdateByCond(ctx context.Context, filter, update interface{}, opts ...*options.UpdateOptions) error

	GenInviteCode() string
}

type SecretShareUserInfoExtMgDbImpl struct {
	MgDB *mongo.Database
}

func NewSecretShareUserInfoExtMgModelImpl(db *mongo.Database) ISecretShareUserInfoExtMgModel {
	return &SecretShareUserInfoExtMgDbImpl{MgDB: db}
}

func (impl *SecretShareUserInfoExtMgDbImpl) table() string {
	return "secretUserExtInfo"
}

func (impl *SecretShareUserInfoExtMgDbImpl) GenInviteCode() string {
	buf := make([]rune, 6)
	for i := range buf {
		buf[i] = InviteCodeLetterRunes[rand.Intn(len(InviteCodeLetterRunes))]
	}
	return string(buf)
}

func (impl *SecretShareUserInfoExtMgDbImpl) Query(ctx context.Context, filter interface{}, opts ...*options.FindOptions) ([]*pbapi.SecretUserExtInfoMgDbModel, error) {
	retItems := make([]*pbapi.SecretUserExtInfoMgDbModel, 0)
	find, err := impl.MgDB.Collection(impl.table()).Find(ctx, filter, opts...)
	if err != nil {
		return nil, err
	}

	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.SecretUserExtInfoMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	return retItems, err
}

func (impl *SecretShareUserInfoExtMgDbImpl) GetByUserIds(ctx context.Context, userIds []int64) ([]*pbapi.SecretUserExtInfoMgDbModel, error) {
	retItems, err := impl.Query(ctx, bson.M{"_id": bson.D{{"$in", userIds}}})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("GetByUserIds Find failed.userid=%v",
			userIds), err)
		return nil, err
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	if len(retItems) > 1 {
		logger.Error(ctx, fmt.Sprintf("get SecretUserExtInfoMgDbModel failed.userid=%v",
			userIds), err)
	}
	return retItems, err
}

// 查不到返回nil
func (impl *SecretShareUserInfoExtMgDbImpl) GetByUserId(ctx context.Context,
	userId int64) (*pbapi.SecretUserExtInfoMgDbModel, error) {
	retItems, err := impl.Query(ctx, bson.M{"_id": userId})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserExtInfoMgDbModel Find failed.userid=%v",
			userId), err)
		return nil, err
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	if len(retItems) > 1 {
		logger.Error(ctx, fmt.Sprintf("get SecretUserExtInfoMgDbModel failed.userid=%v",
			userId), err)
	}
	return retItems[0], err
}

func (impl *SecretShareUserInfoExtMgDbImpl) GetAndCreate(ctx context.Context,
	userId int64) (*pbapi.SecretUserExtInfoMgDbModel, error) {
	//获取记录
	userExt, err := impl.GetByUserId(ctx, userId)
	if err != nil {
		logger.Errorf(ctx, "get user extension failed,err=%v", err.Error())
		return nil, errorcode.GenBusiErr(errorcode.DATA_NOT_EXISTS, "用户不存在")
	}
	if userExt == nil {
		userExt = &pbapi.SecretUserExtInfoMgDbModel{
			Id:         userId,
			InviteCode: nil,
			Ulevel:     proto.Int32(const_level.UserLevel1),
		}
		err = impl.Insert(ctx, userExt)
		if err != nil {
			logger.Errorf(ctx, "insert extension failed,err=%v", err.Error())
			return nil, errorcode.INTERNAL_ERROR
		}
	}
	if userExt.GetUlevel() > const_level.UserMaxLevel || userExt.GetUlevel() < const_level.UserLevel0 {
		logger.Errorf(ctx, "user level err, ulevel=%v", userExt.GetUlevel())
		userExt.Ulevel = proto.Int32(const_level.UserLevel0) //默认给0级
	}
	return userExt, err
}

func (impl *SecretShareUserInfoExtMgDbImpl) UpdateDictById(ctx context.Context, id int64,
	updateDict map[string]interface{}, incDict map[string]int) error {
	if len(updateDict)+len(incDict) == 0 {
		return nil
	}
	collection := impl.MgDB.Collection(impl.table())
	updates := bson.D{}
	if len(updateDict) > 0 {
		updates = append(updates, bson.E{"$set", updateDict})
	}
	if len(incDict) > 0 {
		updates = append(updates, bson.E{"$inc", incDict})
	}
	_, err := collection.UpdateByID(ctx, id, updates)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretShareUserInfoExtMgDbImpl.UpdateDictById  failed. id=%v, updateDict=%v, incDict=%v",
			id, updateDict, incDict), err)
	}
	return err
}

// 新建的记录，ulevel必定为1
func (impl *SecretShareUserInfoExtMgDbImpl) Insert(ctx context.Context,
	item *pbapi.SecretUserExtInfoMgDbModel) error {
	collection := impl.MgDB.Collection(impl.table())
	iTryTimes := 0
	for iTryTimes < 1000 {
		iTryTimes++
		if item.GetInviteCode() == "" {
			item.InviteCode = proto.String(impl.GenInviteCode())
			item.Ulevel = proto.Int32(1)
		}
		_, err := collection.InsertOne(ctx, item)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("SecretUserExtInfoMgDbModel.Insert  failed. item=%v",
				item), err)
			continue
		}
		break
	}
	return nil
}

func (impl *SecretShareUserInfoExtMgDbImpl) ListByCondition(ctx context.Context,
	cond interface{}, page, size int64) ([]map[string]interface{}, error) {
	collection := impl.MgDB.Collection(impl.table())
	findOptions := options.Find()
	findOptions.SetLimit(size)
	findOptions.SetSort(bson.D{
		bson.E{"_id", 1}, //升序
	})
	//查询条件
	find, err := collection.Find(ctx, cond, findOptions)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserExtInfoMgDbModel ListByCondition failed. cond=%v",
			cond), err)
		return nil, err
	}
	retItems := make([]map[string]interface{}, 0)
	for find.Next(ctx) {
		demo := make(map[string]interface{})
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretUserExtInfoMgDbModel failed.cond=%v",
				cond), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (impl *SecretShareUserInfoExtMgDbImpl) ListByConditionModel(ctx context.Context,
	cond interface{}, page, size int64) ([]*pbapi.SecretUserExtInfoMgDbModel, error) {
	collection := impl.MgDB.Collection(impl.table())
	findOptions := options.Find()
	findOptions.SetLimit(size)
	findOptions.SetSort(bson.D{
		bson.E{"_id", 1}, //升序
	})
	//查询条件
	find, err := collection.Find(ctx, cond, findOptions)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretUserExtInfoMgDbModel ListByCondition failed. cond=%v",
			cond), err)
		return nil, err
	}
	retItems := make([]*pbapi.SecretUserExtInfoMgDbModel, 0)
	for find.Next(ctx) {
		demo := &pbapi.SecretUserExtInfoMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to SecretUserExtInfoMgDbModel failed.cond=%v", cond), err)
			//return nil, err
			continue
		}
		retItems = append(retItems, demo)
	}
	return retItems, nil
}

func (impl *SecretShareUserInfoExtMgDbImpl) UpdateByCond(ctx context.Context,
	filter, update interface{}, opts ...*options.UpdateOptions) error {
	collection := impl.MgDB.Collection(impl.table())
	_, err := collection.UpdateMany(ctx, filter, update, opts...)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("SecretShareUserInfoExtMgDbImpl.UpdateDictById  failed,filter=%v, update=%v", filter, update), err)
	}
	return err
}

func (impl *SecretShareUserInfoExtMgDbImpl) DictByUserIds(ctx context.Context, userIds []int64) (map[int64]*pbapi.SecretUserExtInfoMgDbModel, error) {
	condMg := bson.D{}
	if len(userIds) > 0 {
		condMg = append(condMg, bson.E{"_id", bson.M{"$in": userIds}})
	}

	items, err := impl.ListByConditionModel(ctx, condMg, 1, cm_const.MaxDbSize)
	if err != nil {
		return nil, err
	}
	resp := make(map[int64]*pbapi.SecretUserExtInfoMgDbModel)
	for _, item := range items {
		resp[item.GetId()] = item
	}
	return resp, nil
}
