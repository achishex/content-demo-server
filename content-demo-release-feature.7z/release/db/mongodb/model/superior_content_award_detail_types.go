package model

type SuperiorContentAwardDetail struct {
	ID               int64   `bson:"_id" json:"_id"`
	WorkId           int64   `bson:"work_id" json:"work_id"`
	UserId           int64   `bson:"user_id" json:"user_id"`                                           // 用户id
	Type             int32   `bson:"type" json:"type"`                                                 // 结算操作类型，1：结算奖励， 2： 违规扣除 3: 首条动态, 4: 微信提现中， 5：微信提现成功， 6：微信提现失败退回 7:可乐名人堂榜单奖励
	Award            float64 `bson:"award,omitempty" json:"award,omitempty"`                           // 单次金额
	CreateTime       int64   `bson:"create_time" json:"create_time"`                                   // 创建时间
	TotalAward       float64 `bson:"total_award,omitempty" json:"total_award,omitempty"`               // 用户累计奖励
	CanWithdrawAward float64 `bson:"can_withdraw_award,omitempty" json:"can_withdraw_award,omitempty"` // 可提现金额
}
