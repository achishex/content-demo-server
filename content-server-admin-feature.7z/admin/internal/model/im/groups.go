package im

import (
	"content_svr/protobuf/pbdb"
	"content_svr/pub/errors"
	"context"
	"gorm.io/gorm"
)

type IMDB *gorm.DB
type IImGroupsDbModelModel interface {
	ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.GroupsDbModel, error)
	CountMyCreateGroups(ctx context.Context, userId string) (int64, error)
}

type GroupsDbModelModelImpl struct {
	DB *gorm.DB
}

func NewImGroupsDbModelModel(db IMDB) IImGroupsDbModelModel {
	return &GroupsDbModelModelImpl{DB: db}
}

func (impl *GroupsDbModelModelImpl) ListItemsByCondition(ctx context.Context, condition map[string]interface{}, page uint64, size uint64) ([]*pbdb.GroupsDbModel, error) {
	offset := (page - 1) * size
	var items []*pbdb.GroupsDbModel
	result := impl.DB.WithContext(ctx).Table("groups").
		Limit(int(size)).Offset(int(offset)).
		Where(condition).Order("id desc").Find(&items)
	if errors.Is(result.Error, gorm.ErrRecordNotFound) {
		return items, nil
	}
	return items, errors.Wrap(result.Error)
}

func (impl *GroupsDbModelModelImpl) CountMyCreateGroups(ctx context.Context, userId string) (int64, error) {
	var c int64
	if err := impl.DB.WithContext(ctx).Table("groups").Where("creator_user_id = ? AND status = 0", userId).Count(&c).Error; err != nil {
		return 0, err
	}
	return c, nil
}
