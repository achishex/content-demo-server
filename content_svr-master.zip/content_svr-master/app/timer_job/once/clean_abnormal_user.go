package once

import (
	"content_svr/db/mysqldb/model"
	"context"
	"github.com/zeromicro/go-zero/core/logx"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"log"
)

func (c *command) cleanAbnormalUser() {
	var data []struct {
		UserId                            int64   `json:"user_id" bson:"_id"`
		Total                             float64 `json:"total" bson:"total"`
		IsForbidden                       bool
		IsCleanSuperiorContentAwardDetail bool
	}
	pipelineFilter := mongo.Pipeline{}
	pipelineFilter = append(pipelineFilter, bson.D{
		{"$match", bson.M{
			"type": bson.M{
				"$in": []int64{13, 14, 15},
			},
		}},
	})
	pipelineFilter = append(pipelineFilter, bson.D{
		{"$group", bson.M{
			"_id": "$user_id",
			"total": bson.M{
				"$sum": "$award",
			},
		}},
	})
	pipelineFilter = append(pipelineFilter, bson.D{
		{"$match", bson.M{
			"total": bson.M{
				"$gte": 1,
			},
		}},
	})
	//pipelineFilter = append(pipelineFilter, bson.D{})

	ctx := context.Background()
	if err := c.read.SuperiorContentAwardDetail.Aggregate(ctx, &data, pipelineFilter); err != nil {
		log.Fatal(err)
	}

	for _, datum := range data {
		// 封禁用户
		if err := forbiddenUser(ctx, c, datum.UserId); err != nil {
			logx.Error("error", datum, err)
			continue
		}
		datum.IsForbidden = true

		// 清理所有奖励表内容
		if err := cleanSuperiorContentAwardDetail(ctx, c, datum.UserId); err != nil {
			logx.Error(datum, err)
			continue
		}
		datum.IsCleanSuperiorContentAwardDetail = true

		logx.Info("done", datum)

		// 清理身份验证
		//if err := cleanIdCard(ctx, c, datum.UserId); err != nil {
		//	logx.Error(datum, err)
		//	continue
		//}

		//break
	}

}

func forbiddenUser(ctx context.Context, c *command, userId int64) error {
	// 封禁用户
	filter := map[string]interface{}{
		"user_id": userId,
	}
	data := map[string]interface{}{
		"enabled": model.UserForbidden,
	}
	_, err := c.write.UserInfo.UpdateMap(ctx, filter, data)
	if err != nil {
		return err
	}

	if err := c.write.UserInfo.ClearUserInfoRedisCache(ctx, userId); err != nil {
		return err
	}
	if err := c.write.UserInfo.ClearUserTokenRedisCache(ctx, userId); err != nil {
		return err
	}

	return nil
}

func cleanSuperiorContentAwardDetail(ctx context.Context, c *command, userId int64) error {
	filter := map[string]interface{}{
		"user_id": userId,
	}
	detail, err := c.write.SuperiorContentAwardDetail.FindAll(ctx, filter)
	if err != nil {
		return err
	}

	for _, awardDetail := range detail {
		result, err := c.write.SuperiorContentAwardDetail.Delete(ctx, awardDetail.ID)
		if err != nil {
			return err
		}

		if result != 0 {
			logx.Infow("delete SuperiorContentAwardDetail", logx.Field("delete_data", awardDetail))
		}
	}

	return nil
}

func cleanIdCard(ctx context.Context, c *command, userId int64) error {
	filter := map[string]interface{}{
		"user_id": userId,
	}
	detail, err := c.write.SecretUserIdentificationCard.FindOne(ctx, filter)
	if err != nil {
		return err
	}

	result, err := c.write.SecretUserIdentificationCard.Delete(ctx, detail.ID)
	if err != nil {
		return err
	}
	if result != 0 {
		logx.Infow("delete SecretUserIdentificationCard", logx.Field("delete_data", detail))
	}

	return nil
}
