package im_mng

import (
	"content_svr/internal/im_mng/open_im_api"
	"content_svr/protobuf/pbim"
	"content_svr/pub/logger"
	"context"
	"github.com/OpenIMSDK/protocol/sdkws"
	"strconv"
	"time"
)

func (i *IMMng) SyncUserInfo(ctx context.Context, req *pbim.SyncUserInfoReq) (*pbim.SyncUserInfoResp, error) {
	ctx = context.WithValue(ctx, open_im_api.CtxApiToken, open_im_api.GetAdminToken())

	uid, err := strconv.ParseInt(req.UserID, 10, 64)
	if err != nil {
		return nil, err
	}
	u, err := i.DataCache.GetUserBasicInfo(ctx, uid, true)
	if err != nil {
		logger.Infof(ctx, "GetUserBasicInfo fail, err :%v", err)
		return nil, err
	}

	i.DataCache.DeleteUserInfoFromCache(ctx, []int64{uid})

	ok, _, err := i.OpenImCaller.AccountCheck(ctx, []string{req.UserID})
	if err != nil {
		return nil, err
	}

	if ok {
		if err2 := i.OpenImCaller.UpdateUserInfo(ctx, req.UserID, u.GetNickName(), u.GetPhoto()); err2 != nil {
			return nil, err2
		}
	} else {
		if err2 := i.OpenImCaller.RegisterUser(ctx, []*sdkws.UserInfo{
			&sdkws.UserInfo{
				UserID:     req.UserID,
				Nickname:   u.GetNickName(),
				FaceURL:    u.GetPhoto(),
				CreateTime: time.Now().UnixMilli(),
			}}); err2 != nil {
			logger.Errorf(ctx, "RegisterUser fail, uid: %v err: %v", req.GetUserID(), err2)
			return nil, err2
		}

		logger.Infof(ctx, "quding GetUserBasicInfo fail, nickname %v, photo %v", u.GetNickName(), u.GetPhoto())
	}

	return &pbim.SyncUserInfoResp{}, nil
}
