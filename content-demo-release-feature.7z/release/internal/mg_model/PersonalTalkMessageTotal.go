package mg_model

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/logger"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

type IPersonalTalkMessageTotalMgDbModel interface {
	GetById(ctx context.Context,
		uniqueId int32, toUserId int64) (*pbapi.PersonalTalkMessageTotalMgDbModel, error)
	GetByFromAndToId(ctx context.Context,
		fromUserId, toUserId, workId int64) (*pbapi.PersonalTalkMessageTotalMgDbModel, error)
	Insert(ctx context.Context, item *pbapi.PersonalTalkMessageTotalMgDbModel) error
	UpdateDictById(ctx context.Context, id int64, update map[string]interface{}, incDict map[string]int) error
	//
	GetItemsByConds(ctx context.Context, eqCond, largeCond, lessCond map[string]interface{}, sortField map[string]int32, limits int32) ([]*pbapi.PersonalTalkMessageTotalMgDbModel, error)
	//
	GetFromUserNumsByConds(ctx context.Context, eqCond, largeCond, lessCond map[string]interface{}) (int, error)
	CheckIdExists(ctx context.Context, eqCond, largeCond, lessCond map[string]interface{}) (bool, error)
	GetToUserNumsByConds(ctx context.Context, eqCond, largeCond, lessCond, neCond map[string]interface{}) ([]int64, error)
	DeleteItems(ctx context.Context, eqCond, largeCond, lessCond, neCond map[string]interface{}) (int32, error)
	FindItemsWithComplexConds(ctx context.Context, filter bson.M, sortField map[string]int32, skips, limits int32) ([]*pbapi.PersonalTalkMessageTotalMgDbModel, error)
}

type PersonalTalkMessageTotalMgDbImpl struct {
	MgDB  *mongo.Database
	Table string
}

func NewPersonalTalkMessageTotalMgModelImpl(db *mongo.Database) IPersonalTalkMessageTotalMgDbModel {
	return &PersonalTalkMessageTotalMgDbImpl{
		MgDB:  db,
		Table: "personalTalkMessageTotal",
	}
}
func (impl *PersonalTalkMessageTotalMgDbImpl) FindItemsWithComplexConds(ctx context.Context, filter bson.M, sortField map[string]int32, skips, limits int32) ([]*pbapi.PersonalTalkMessageTotalMgDbModel, error) {
	coll := impl.MgDB.Collection(impl.Table)
	if len(filter) <= 0 {
		return nil, nil
	}
	var sortExpand bson.D
	for k, v := range sortField {
		sortExpand = append(sortExpand, bson.E{Key: k, Value: v})
	}
	//
	opts := options.Find()
	if len(sortExpand) > 0 {
		opts.SetSort(sortExpand)
	}
	if skips > 0 {
		opts.SetSkip(int64(skips))
	}
	if limits > 0 {
		opts.SetLimit(int64(limits))
	}
	cursor, err := coll.Find(ctx, filter, opts)
	if err != nil {
		logger.Errorf(ctx, "find fail, cond: %#v, err: %v", filter, err)
		return nil, err
	}
	var result []*pbapi.PersonalTalkMessageTotalMgDbModel
	for cursor.Next(ctx) {
		data := &pbapi.PersonalTalkMessageTotalMgDbModel{}
		err = cursor.Decode(data)
		if err != nil {
			logger.Errorf(ctx, "get comment detail query result fail, err: %v", err)
			return nil, err
		}
		result = append(result, data)
	}
	if len(result) <= 0 {
		return nil, nil
	}
	return result, nil
}
func (impl *PersonalTalkMessageTotalMgDbImpl) DeleteItems(ctx context.Context, eqCond, largeCond, lessCond, neCond map[string]interface{}) (int32, error) {
	coll := impl.MgDB.Collection(impl.Table)
	filter := bson.D{}
	for k, v := range eqCond {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	for k, v := range largeCond {
		filter = append(filter, bson.E{k, bson.D{{"$gte", v}}})
	}
	for k, v := range lessCond {
		filter = append(filter, bson.E{k, bson.D{{"$lt", v}}})
	}
	for k, v := range neCond {
		filter = append(filter, bson.E{k, bson.D{{"$ne", v}}})
	}
	//
	delRet, err := coll.DeleteMany(ctx, filter)
	if err != nil {
		logger.Errorf(ctx, "del node by cond: %v fail, err: %v", filter, err)
		return 0, err
	}
	if delRet == nil {
		return 0, nil
	}
	return int32(delRet.DeletedCount), nil

}
func (impl *PersonalTalkMessageTotalMgDbImpl) GetToUserNumsByConds(ctx context.Context, eqCond, largeCond, lessCond, neCond map[string]interface{}) ([]int64, error) {
	coll := impl.MgDB.Collection(impl.Table)
	filter := bson.D{}
	for k, v := range eqCond {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	for k, v := range largeCond {
		filter = append(filter, bson.E{k, bson.D{{"$gte", v}}})
	}
	for k, v := range lessCond {
		filter = append(filter, bson.E{k, bson.D{{"$lt", v}}})
	}
	for k, v := range neCond {
		filter = append(filter, bson.E{k, bson.D{{"$ne", v}}})
	}
	result, err := coll.Distinct(ctx, "toUserId", filter)
	if err != nil {
		logger.Errorf(ctx, "query toUserId fail, err: %v", err)
		return nil, err
	}
	logger.Infof(ctx, "get to user id nums: %v", len(result))
	ret := []int64{}
	for _, v := range result {
		ret = append(ret, v.(int64))
	}
	return ret, nil
}
func (impl *PersonalTalkMessageTotalMgDbImpl) CheckIdExists(ctx context.Context, eqCond, largeCond, lessCond map[string]interface{}) (bool, error) {
	coll := impl.MgDB.Collection(impl.Table)
	filter := bson.D{}
	for k, v := range eqCond {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	for k, v := range largeCond {
		filter = append(filter, bson.E{k, bson.D{{"$gte", v}}})
	}
	for k, v := range lessCond {
		filter = append(filter, bson.E{k, bson.D{{"$lt", v}}})
	}
	filter = append(filter, bson.E{"_id", bson.D{{"$exists", true}}})

	cursor, err := coll.Find(ctx, filter)
	var result []*pbapi.PersonalTalkMessageTotalMgDbModel
	for cursor.Next(ctx) {
		data := &pbapi.PersonalTalkMessageTotalMgDbModel{}
		err = cursor.Decode(data)
		if err != nil {
			logger.Errorf(ctx, "get comment detail query result fail, err: %v", err)
			return false, err
		}
		result = append(result, data)
	}
	if len(result) <= 0 {
		return false, nil
	}
	return true, nil
}
func (impl *PersonalTalkMessageTotalMgDbImpl) GetFromUserNumsByConds(ctx context.Context, eqCond, largeCond, lessCond map[string]interface{}) (int, error) {
	coll := impl.MgDB.Collection(impl.Table)
	filter := bson.D{}
	for k, v := range eqCond {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	for k, v := range largeCond {
		filter = append(filter, bson.E{k, bson.D{{"$gte", v}}})
	}
	for k, v := range lessCond {
		filter = append(filter, bson.E{k, bson.D{{"$lt", v}}})
	}
	result, err := coll.Distinct(ctx, "fromUserId", filter)
	if err != nil {
		logger.Errorf(ctx, "query fromUserId fail, err: %v", err)
		return 0, err
	}
	logger.Infof(ctx, "get from user id nums: %v", len(result))
	return len(result), nil
}

// 查不到返回nil
func (impl *PersonalTalkMessageTotalMgDbImpl) GetById(ctx context.Context,
	uniqueId int32, toUserId int64) (*pbapi.PersonalTalkMessageTotalMgDbModel, error) {
	retItems := make([]*pbapi.PersonalTalkMessageTotalMgDbModel, 0)
	collection := impl.MgDB.Collection(impl.Table)
	find, err := collection.Find(ctx, bson.M{"uniqueId": uniqueId, "toUserId": toUserId})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PersonalTalkMessageTotalMgDbModel Find failed.uniqueId=%v",
			uniqueId), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.PersonalTalkMessageTotalMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to PersonalTalkMessageTotalMgDbModel failed.uniqueId=%v",
				uniqueId), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	if len(retItems) > 1 {
		logger.Error(ctx, fmt.Sprintf("get PersonalTalkMessageTotalMgDbModel failed.uniqueId=%v",
			uniqueId), err)
	}
	return retItems[0], err
}

func (impl *PersonalTalkMessageTotalMgDbImpl) GetByFromAndToId(ctx context.Context,
	fromUserId, toUserId, workId int64) (*pbapi.PersonalTalkMessageTotalMgDbModel, error) {
	retItems := make([]*pbapi.PersonalTalkMessageTotalMgDbModel, 0)
	collection := impl.MgDB.Collection(impl.Table)
	find, err := collection.Find(ctx, bson.M{"fromUserId": fromUserId, "toUserId": toUserId, "workId": workId})
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PersonalTalkMessageTotalMgDbModel.GetByFromAndToId Find failed.fromUserId=%v",
			fromUserId), err)
		return nil, err
	}
	// 遍历查询结果
	for find.Next(ctx) {
		demo := &pbapi.PersonalTalkMessageTotalMgDbModel{}
		// 解码绑定数据
		err = find.Decode(demo)
		if err != nil {
			logger.Error(ctx, fmt.Sprintf("decode to PersonalTalkMessageTotalMgDbModel.GetByFromAndToId failed.fromUserId=%v",
				fromUserId), err)
			return nil, err
		}
		retItems = append(retItems, demo)
	}

	if len(retItems) == 0 {
		return nil, nil
	}
	if len(retItems) > 1 {
		logger.Error(ctx, fmt.Sprintf("get PersonalTalkMessageTotalMgDbModel.GetByFromAndToId ret.len > 1.fromUserId=%v, toUserId=%v",
			fromUserId, toUserId), err)
	}
	return retItems[0], err
}

func (impl *PersonalTalkMessageTotalMgDbImpl) Insert(ctx context.Context, item *pbapi.PersonalTalkMessageTotalMgDbModel) error {
	collection := impl.MgDB.Collection(impl.Table)
	_, err := collection.InsertOne(ctx, item)
	//print(result, err)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PersonalTalkMessageTotalMgDbModel.Insert  failed. item=%v",
			item), err)
	}
	return err
}

func (impl *PersonalTalkMessageTotalMgDbImpl) UpdateDictById(ctx context.Context, id int64,
	updateDict map[string]interface{}, incDict map[string]int) error {
	if len(updateDict)+len(incDict) == 0 {
		return nil
	}
	collection := impl.MgDB.Collection(impl.Table)
	updates := bson.D{}
	if len(updateDict) > 0 {
		updates = append(updates, bson.E{"$set", updateDict})
	}
	if len(incDict) > 0 {
		updates = append(updates, bson.E{"$inc", incDict})
	}

	_, err := collection.UpdateByID(ctx, id, updates)
	if err != nil {
		logger.Error(ctx, fmt.Sprintf("PersonalTalkMessageTotalMgDbModel.UpdateDictById  failed. id=%v, updateDict=%v, incDict=%v",
			id, updateDict, incDict), err)
	}
	return err
}

func (impl *PersonalTalkMessageTotalMgDbImpl) GetItemsByConds(ctx context.Context, eqCond, largeCond, lessCond map[string]interface{}, sortField map[string]int32, limits int32) ([]*pbapi.PersonalTalkMessageTotalMgDbModel, error) {
	coll := impl.MgDB.Collection(impl.Table)
	filter := bson.D{}
	for k, v := range eqCond {
		filter = append(filter, bson.E{Key: k, Value: v})
	}
	for k, v := range largeCond {
		filter = append(filter, bson.E{k, bson.D{{"$gt", v}}})
	}
	for k, v := range lessCond {
		filter = append(filter, bson.E{k, bson.D{{"$lt", v}}})
	}
	var sortExpand bson.D
	for k, v := range sortField {
		sortExpand = append(sortExpand, bson.E{Key: k, Value: v})
	}
	//
	opts := options.Find()
	if len(sortExpand) > 0 {
		opts.SetSort(sortExpand)
	}
	if limits > 0 {
		opts.SetLimit(int64(limits))
	}

	cursor, err := coll.Find(ctx, filter, opts)
	var result []*pbapi.PersonalTalkMessageTotalMgDbModel
	for cursor.Next(ctx) {
		data := &pbapi.PersonalTalkMessageTotalMgDbModel{}
		err = cursor.Decode(data)
		if err != nil {
			logger.Errorf(ctx, "get comment detail query result fail, err: %v", err)
			return nil, err
		}
		result = append(result, data)
	}
	if len(result) <= 0 {
		return nil, nil
	}
	return result, nil
}
