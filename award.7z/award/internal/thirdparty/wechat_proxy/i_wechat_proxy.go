package wechat_proxy

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/pub/logger"
	"context"
	"encoding/json"
	"fmt"
	"github.com/go-resty/resty/v2"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments/app"
)

type IWechatProxy interface {
	GetAccessTokenByCode(ctx context.Context, code string) (*WeChatAccessTokenResponse, error)
	GetWechatUserInfo(ctx context.Context, at *WeChatAccessTokenResponse) (*WeChatUserInfoResponse, error)

	//转账逻辑
	TransferMoney(ctx context.Context, req *WeChatPayReq) (*WeChatPayResponse, error)
	QueryBatchInfo(ctx context.Context, req *BatchQueryByMchIdReq) (*BatchQueryByMchIdResp, error)

	//支付预下单
	AppPrepay(ctx context.Context, req *app.PrepayRequest) (resp *app.PrepayResponse, err error)
	QueryOrderById(ctx context.Context, req app.QueryOrderByIdRequest) (resp *payments.Transaction, err error)
	QueryOrderByOutTradeNo(ctx context.Context, req app.QueryOrderByOutTradeNoRequest) (resp *payments.Transaction, err error)
}

type WechatMng struct {
	AppId     string
	AppSecret string
	Client    *resty.Client

	// 支付接口
	Pay IPayProxy
}

func NewWechatMng() IWechatProxy {
	return WechatMng{
		AppId:     config.ServerConfig.WechatConfig.AppId,
		AppSecret: config.ServerConfig.WechatConfig.AppSecret,
		Client:    resty.New(),

		Pay: NewPayProxy(PayTypeWeChat),
		//Pay: NewPayProxyMock(MockPayTypeWeChat),
	}
}

func (w WechatMng) GetAccessTokenByCode(ctx context.Context, code string) (*WeChatAccessTokenResponse, error) {
	url := fmt.Sprintf(UrlGetAccessToken, w.AppId, w.AppSecret, code)
	r, err := w.Client.NewRequest().Get(url)
	if err != nil {
		logger.Errorf(ctx, "http error:", err)
		return nil, errorcode.THIRD_API_ERROR
	}

	var resp WeChatAccessTokenResponse
	if err := json.Unmarshal(r.Body(), &resp); err != nil {
		logger.Errorf(ctx, "GetAccessTokenByCode: json Unmarshal error: %v", err)
		return nil, errorcode.THIRD_API_ERROR
	}

	return &resp, nil
}

func (w WechatMng) TransferMoney(ctx context.Context, req *WeChatPayReq) (*WeChatPayResponse, error) {
	return w.Pay.Transfer(ctx, req)
}

func (w WechatMng) QueryBatchInfo(ctx context.Context, req *BatchQueryByMchIdReq) (*BatchQueryByMchIdResp, error) {
	return w.Pay.QueryTransferBatchInfo(ctx, req)
}

func (w WechatMng) AppPrepay(ctx context.Context, req *app.PrepayRequest) (resp *app.PrepayResponse, err error) {
	return w.Pay.AppPrepay(ctx, req)
}

func (w WechatMng) QueryOrderById(ctx context.Context, req app.QueryOrderByIdRequest) (resp *payments.Transaction, err error) {
	return w.Pay.QueryOrderById(ctx, req)
}

func (w WechatMng) QueryOrderByOutTradeNo(ctx context.Context, req app.QueryOrderByOutTradeNoRequest) (resp *payments.Transaction, err error) {
	return w.Pay.QueryOrderByOutTradeNo(ctx, req)
}
