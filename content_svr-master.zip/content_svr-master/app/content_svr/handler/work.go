package handler

import (
	"content_svr/protobuf/pbapi"
	"content_svr/pub/utils"
	"github.com/gin-gonic/gin"
)

func (p *AdminHandler) ResetExposure(ctx *gin.Context, req *pbapi.ResetWorkShareReq) (*pbapi.ResetWorkShareResp, error) {

	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	resp, err := p.ContentMng.ResetExposure(ctx, header, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}
