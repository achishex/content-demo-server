package main

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"os"
	"text/template"
)

type TemplateObject struct {
	ModelPackPath string
	Type          string
	LowerType     string

	QueryStructName string
	ModelStructName string

	Member string
	Object string
}

func parseFile(templatePath, writePath string, data any) error {
	rf, err := os.Open(templatePath)
	if err != nil {
		return err
	}
	b, err := io.ReadAll(rf)
	if err != nil {
		return err
	}
	rf.Close()

	tmpl, err := template.New("gen").Parse(string(b))
	if err != nil {
		panic(err)
	}

	wf, err := os.Create(writePath)
	if err != nil {
		return err
	}
	defer wf.Close()
	err = tmpl.Execute(wf, data)
	if err != nil {
		return err
	}

	return nil
}

func parseData(templateData string, data any) (string, error) {
	tmpl, err := template.New("gen").Parse(templateData)
	if err != nil {
		panic(err)
	}

	b := bytes.NewBuffer(nil)
	if err := tmpl.Execute(b, data); err != nil {
		return "", err
	}

	return b.String(), nil
}

type templateGroup struct {
	targets []target

	body *bytes.Buffer

	writePath string
}

type target struct {
	srcTemplatePath string
	data            any
}

func (c *templateGroup) parse() error {
	for _, t := range c.targets {
		rf, err := os.Open(t.srcTemplatePath)
		if err != nil {
			return err
		}
		b, err := io.ReadAll(rf)
		if err != nil {
			return err
		}
		rf.Close()

		tmpl, err := template.New("gen").Parse(string(b))
		if err != nil {
			panic(err)
		}
		err = tmpl.Execute(c.body, t.data)
		if err != nil {
			return err
		}
	}

	fmt.Println(c.writePath)
	wf, err := os.Create(c.writePath)
	if err != nil {
		return err
	}
	defer wf.Close()
	if _, err := wf.Write(c.body.Bytes()); err != nil {
		log.Fatal(err)
	}

	return nil
}
