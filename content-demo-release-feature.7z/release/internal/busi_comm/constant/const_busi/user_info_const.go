package const_busi

const (
	UserInvalidStatus int32 = 0
	UserValidStatus   int32 = 1
)

const (
	_                     int32 = iota
	UserCardStatus              // 登记
	UserCardSignOutStatus       // 注销
)

const (
	UserLockTemporary int32 = 2 //临时封禁
	UserLockPermanent int32 = 3 //永久封禁
)
const (
	MutualUsers int32 = 1
)

const (
	Mutual = 1 //猫友
	Follow = 2 //关注
	Fans   = 3 //粉丝
)

const (
	MedalPermanentNeedMutualCnt = 12  //社牛永久勋章所需要互关数量
	MedalKingOfCatNeedFollowCnt = 500 //猫王勋章所需被关注数量

	MedalIdXinYa           = 1 // 新芽勋章id
	MedalIdSocialButterfly = 5 //社牛勋章id
	MedalIdKingOfCat       = 6 //猫王
)

const (
	IdentityUnknown  = iota
	IdentityUnderage // 未成年
	IdentityAdult    // 成年
)

const (
	TalkModeUnknown int32 = iota
	TalkModeOpen          // 扩列模式，允许接收陌生人的主动私信
	TalkModeClose         // 闭关模式，拒绝接收陌生人的主动私信
)

const (
	StartTargetOpen  = 1 // 设置星标
	StartTargetClose = 2 // 取消星标
)

// 0非会员 1-svip 2赠送会员 3-普通会员
const (
	NormalUser = iota
	SVipUser
	GiftVipUser
	VipUser
)
