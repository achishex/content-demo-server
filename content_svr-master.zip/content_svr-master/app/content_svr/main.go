package main

import (
	"content_svr/app/content_svr/handler"
	"content_svr/app/di"
	"content_svr/config"
	"content_svr/internal/ad_mng"
	"content_svr/internal/content_mng"
	"content_svr/internal/data_cache"
	"content_svr/internal/im_mng"
	"content_svr/internal/notify_mng"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/middleware/retain"
	"content_svr/pub/router"
	"content_svr/pub/snow_flake"
	"content_svr/pub/taskq"
	"content_svr/setting"
	"context"
	"github.com/go-redis/redis/v8"
)

func main() {
	snow_flake.InitMachineID()

	ctx := context.Background()
	c := di.NewContainer()

	// init setting
	err := c.Invoke(func(rdb *redis.Client) {
		if err := setting.Initialize(rdb, config.ServerConfig.Env); err != nil {
			panic(err)
		}
		go setting.Monitor()
	})
	if err != nil {
		logger.Errorf(nil, "Initialize setting fail, err: %v", err)
		panic(err)
	}

	// init im
	err = c.Invoke(func(h *handler.AdminHandler,
		dataCache data_cache.IDataCacheMng,
		mng content_mng.IContentMng,
		imHelper *im_mng.IMHelper) {
		imHelper.SendMsgFn = h.SendMsg // TODO 分包解决依赖
		imHelper.SendBBMsgFn = mng.SendBBMsg
		imHelper.DataCache = dataCache
	})
	if err != nil {
		logger.Errorf(ctx, "Initialize imhelper fail, err: %v", err)
		panic(err)
	}

	err = c.Invoke(func(r *router.Router,
		rdb *redis.Client,
		h *handler.AdminHandler,
		ih *handler.InternalHandler,
		notifyComp *notify_mng.InactiveUserNotifyComp,
		tq *taskq.TaskQ,
		behavior *ad_mng.BehaviorUpCtrl,
	) {
		r.Engine.Use(middleware.AppTokenMiddleware(rdb))
		r.Engine.Use(middleware.ApiWhiteList(config.ServerConfig))
		r.Engine.Use(middleware.InactiveNotify(notifyComp))
		r.Engine.Use(middleware.CtxInfo())
		r.Engine.Use(retain.RetainRecord(behavior))

		handler.SetUrls(r.Engine, h)
		logger.GoZeroLoadLogger(config.ServerConfig.Env)
		logger.DebugLogger(config.ServerConfig.Env)

		// 跑任务队列
		go tq.Run()
		logger.Infof(context.Background(), "server starting, port=%v, node_idx=%v....",
			config.ServerConfig.Port, snow_flake.GetMachinID())

		go func() {
			internalAddr := ":7000"
			logger.Infof(context.Background(), "serve internal http %v", internalAddr)
			if err2 := ih.Serve(internalAddr); err2 != nil {
				logger.Errorf(context.Background(), "serve internal http fail, err: %v", err2)
			}
		}()

		r.Run(config.ServerConfig.Port)
	})

	if err != nil {
		logger.Errorf(ctx, "Run fail, err: ", err)
		panic(err)
	}
	logger.Infof(ctx, "quit app")
}
