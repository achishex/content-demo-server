package job

import (
	"content_svr/db/dao"
	"content_svr/db/mongodb/model"
	"content_svr/pub/logger"
	"content_svr/pub/requestid"
	"context"
	"github.com/zeromicro/go-zero/core/threading"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"math"
	"time"
)

func InitAwardCalcSum(write, read *dao.ManagerDB) {
	threading.GoSafe(func() {
		ctrl := newAwardCalcSumControl(write, read)
		//ctrl.once()
		//return

		ctrl.Do(func() {
			ctx := requestid.WithRequestID(context.Background())
			if err := ctrl.DoTask(ctx, time.Now().AddDate(0, 0, -1)); err != nil {
				logger.Errorf(ctx, "newAwardCalcSumControl.DoTask: %v", err)

				// 五分钟后重试
				ctrl.ticker.Reset(time.Minute * 5)
				return
			}

			ctrl.ticker.Reset(ctrl.calcIntervalTime())
		})

	})
}

type awardCalcSumControl struct {
	TickerExecute
	write, read *dao.ManagerDB
}

func newAwardCalcSumControl(write, read *dao.ManagerDB) awardCalcSumControl {
	// 凌晨四点执行
	ctrl := awardCalcSumControl{}
	ctrl.hour = 4
	//ctrl.hour = 9
	//ctrl.minter = 53

	ctrl.write = write
	ctrl.read = read
	return ctrl
}

func (l awardCalcSumControl) once() {

	//ctx := requestid.WithRequestID(context.Background())
	//now := time.Now()
	//target := now.AddDate(0, 0, -1)
	////target := time.Date(now.Year(), now.Month(), 13, now.Hour(), now.Minute(), now.Second(), now.Nanosecond(), now.Location())
	//if err := l.DoTask(ctx, target); err != nil {
	//	logger.Error(context.Background(), "InitAwardCalcSum:", err)
	//}

	for i := 10; i > 0; i-- {
		ctx := requestid.WithRequestID(context.Background())
		now := time.Now()
		target := now.AddDate(0, 0, -i)
		//target := time.Date(now.Year(), now.Month(), 13, now.Hour(), now.Minute(), now.Second(), now.Nanosecond(), now.Location())
		if err := l.DoTask(ctx, target); err != nil {
			logger.Error(context.Background(), "InitAwardCalcSum:", err)
		}
		//break
	}
}

func (l awardCalcSumControl) DoTask(ctx context.Context, targetTime time.Time) error {
	defer func() {
		if err := recover(); err != nil {
			logger.Errorf(ctx, "recover: %v\n", err)
		}
	}()

	awardSettlementSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.AwardSettlement)
	if err != nil {
		return err
	}
	deductionIllegalSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.DeductionIllegal)
	if err != nil {
		return err
	}
	firstWorkSettlementSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.FirstWorkSettlement)
	if err != nil {
		return err
	}
	wechatPayWithdrawSuccessSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.WechatPayWithdrawSuccess)
	if err != nil {
		return err
	}
	wechatPayWithdrawFailSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.WechatPayWithdrawFail)
	if err != nil {
		return err
	}
	hallOfFameAwardSettlementSum, err := l.countSuperiorContentAwardDetail(ctx, targetTime, model.HallOfFameAwardSettlement)
	if err != nil {
		return err
	}
	gameSum, err := l.countSecretGameOrder(ctx, targetTime)
	if err != nil {
		return err
	}

	data := &model.SuperiorAwardDaily{
		Day:                          l.baseZeroTime(targetTime).UnixMilli(),
		AwardSettlementSum:           awardSettlementSum,
		DeductionIllegalSum:          deductionIllegalSum,
		FirstWorkSettlementSum:       firstWorkSettlementSum,
		WechatPayWithdrawSuccessSum:  wechatPayWithdrawSuccessSum,
		WechatPayWithdrawFailSum:     wechatPayWithdrawFailSum,
		HallOfFameAwardSettlementSum: hallOfFameAwardSettlementSum,
		GameSum:                      gameSum,
	}

	updateFilter := bson.D{
		{"day", l.baseZeroTime(targetTime).UnixMilli()},
	}

	update := bson.D{
		{"$set", data},
		{"$setOnInsert", bson.D{
			{"create_time", targetTime.UnixMilli()},
		}},
	}

	//logger.Infof(ctx, "%v", data)
	opt := options.Update().SetUpsert(true)
	if _, err := l.write.SuperiorAwardDaily.Update(ctx, updateFilter, update, opt); err != nil {
		return err
	}

	logger.Infof(ctx, "==-==每日%d奖励计算完成", l.baseTimeByDay(targetTime))

	return nil
}

func (l awardCalcSumControl) countSuperiorContentAwardDetail(ctx context.Context, targetTime time.Time, value interface{}) (uint, error) {
	filter := map[string]interface{}{
		"create_time": bson.D{
			{"$gte", l.baseZeroTime(targetTime).UnixMilli()},
			{"$lt", l.calcZeroTimeByDay(targetTime, 1).UnixMilli()},
		},
		"type": value,
	}

	items, err := l.read.SuperiorContentAwardDetail.FindAll(ctx, filter)
	if err != nil {
		return 0, err
	}

	var count float64
	for _, detail := range items {
		count += detail.Award
	}

	return uint(math.Round(count * 100)), nil

}

func (l awardCalcSumControl) countSecretGameOrder(ctx context.Context, targetTime time.Time) (uint, error) {
	filter := map[string]interface{}{
		"create_time": bson.D{
			{"$gte", l.baseZeroTime(targetTime).UnixMilli()},
			{"$lt", l.calcZeroTimeByDay(targetTime, 1).UnixMilli()},
		},
		"notify_status": 3, // 通知状态 1：回调成功 2：重试中 3：放弃通知
	}
	items, err := l.read.SecretGameOrder.FindAll(ctx, filter)
	if err != nil {
		return 0, err
	}
	if len(items) == 0 {
		return 0, nil
	}
	var gameTable = map[string]*model.GameStatistical{}
	var sumAllGame uint
	for _, item := range items {
		price := uint(item.Amount)
		if game, ok := gameTable[item.GameId]; ok {
			game.AmountSum += price
			gameTable[item.GameId] = game
		} else {
			var gameName string
			gameInfo, err := l.read.SecretGame.FindOne(ctx, map[string]interface{}{
				"game_id": item.GameId,
			})
			if err == nil {
				gameName = gameInfo.GameName
			}
			if err != nil {
				logger.Errorf(ctx, "%v", err)
			}
			gameTable[item.GameId] = &model.GameStatistical{
				GameId:     item.GameId,
				GameName:   gameName,
				AmountSum:  price,
				Day:        l.baseZeroTime(targetTime).UnixMilli(),
				UpdateTime: targetTime.UnixMilli(),
			}
		}

		sumAllGame += uint(item.Amount)
	}

	for _, game := range gameTable {
		updateFilter := bson.D{
			{"day", l.baseZeroTime(targetTime).UnixMilli()},
			{"game_id", game.GameId},
		}
		insertData := bson.D{
			{"create_time", targetTime.UnixMilli()},
		}
		if _, err = l.write.GameStatistical.Upsert(ctx, updateFilter, game, insertData); err != nil {
			return 0, err
		}
	}

	return sumAllGame, err
}
