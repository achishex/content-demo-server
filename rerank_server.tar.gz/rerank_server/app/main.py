
from fastapi import FastAPI
from app.services import load_model 
from app.services.retrieve_similar_questions import LoadAllLanguageQuestionAnswers 
from app.api.app_router import router

app = FastAPI()
app.include_router(router)
load_model.loadModel()
LoadAllLanguageQuestionAnswers()