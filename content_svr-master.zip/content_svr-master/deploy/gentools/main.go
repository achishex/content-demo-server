package main

import (
	"flag"
)

var (
	mysqlLink   = "root:rnDlrvDxYq09PznZ@tcp(106.52.80.166:3306)/platform"
	packName    = "gen"
	mysqlDbDir  = "./db/mysqldb"
	mongoDbDir  = "./db/mongodb"
	redisDbDir  = "./db/redisdb"
	templateDir = "./deploy/template"

	mysqlTableNames = ""
	mongoTableNames = ""

	dao = false
)

func main() {
	flag.StringVar(&packName, "p", packName, "pack name, default: gen")
	flag.StringVar(&templateDir, "t", templateDir, "模板文件所在地")
	flag.StringVar(&mysqlTableNames, "mysql", mysqlTableNames, "mysql table names, 逗号分割")
	flag.StringVar(&mongoTableNames, "mongo", mongoTableNames, "mongo table names, 逗号分割")
	flag.BoolVar(&dao, "dao", false, "cache is false")
	flag.Parse()

	// -t ./template -mysql report_reward
	// -t ./template -mongo UserActivity
	run()
}

func run() {
	mysql := MysqlInfo{
		TableField:         map[string][]mysqlField{},
		QueryStructNameMap: map[string]string{},
		ModelStructNameMap: map[string]string{},
	}
	mysql.GenerateModel()

	mongo := MongoInfo{}
	mongo.GenerateModel()

	dao := DaoInfo{}
	dao.createDaoManageFile()
}
