package utils

import (
	"sort"
)

func StrStrMapKeys(m map[string]string) []string {
	keys := make([]string, 0, len(m))
	for _k := range m {
		keys = append(keys, _k)
	}
	sort.Strings(keys)
	return keys
}

func StrIMapKeys(m map[string]interface{}) []string {
	keys := make([]string, 0, len(m))
	for _k := range m {
		keys = append(keys, _k)
	}
	sort.Strings(keys)
	return keys
}

type SortMap struct {
	keys []interface{}
	body map[interface{}]interface{}
}

func NewSortMap() *SortMap {
	return &SortMap{
		keys: make([]interface{}, 0),
		body: map[interface{}]interface{}{},
	}
}

func (s *SortMap) Set(k, v interface{}) {
	_, exist := s.body[k]
	if !exist {
		s.keys = append(s.keys, k)
	}

	s.body[k] = v
}

func (s *SortMap) Get(k interface{}) interface{} {
	return s.body[k]
}

func (s *SortMap) GetInt64(k interface{}) int64 {
	return s.body[k].(int64)
}

func (s *SortMap) RangeKeys() []interface{} {
	return s.keys
}

func (s *SortMap) ExistKey(k interface{}) bool {
	_, exist := s.body[k]
	return exist
}

func (s *SortMap) GetInt64RangeKeys() (keys []int64) {
	keys = make([]int64, 0)
	for _, key := range s.keys {
		v, ok := key.(int64)
		if !ok {
			continue
		}
		keys = append(keys, v)
	}
	return keys
}
