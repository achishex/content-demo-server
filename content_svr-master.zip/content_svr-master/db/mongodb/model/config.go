package model

type MonConfig interface {
	GetURL() string
	GetDBName() string
}
