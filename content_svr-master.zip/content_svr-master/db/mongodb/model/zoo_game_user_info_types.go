package model

import (
	"go.mongodb.org/mongo-driver/bson/primitive"
)

const collectionNameZooGameUserInfo = "ZooGameUserInfo"

type ZooGameUserInfo struct {
	ID primitive.ObjectID `bson:"_id,omitempty" json:"id,omitempty"`

	CreateTime int64 `json:"create_time,omitempty" bson:"create_time,omitempty"` //创建时间
	UpdateTime int64 `json:"update_time,omitempty" bson:"update_time,omitempty"` //更新时间

	UserID   string `json:"uid,omitempty" bson:"uid,omitempty"`           // userId
	RegTime  int64  `json:"regTime,omitempty" bson:"regTime,omitempty"`   // unix 时间戳
	Platform int32  `json:"platform,omitempty" bson:"platform,omitempty"` // 平台 1安卓 2ios
	Channel  string `json:"channel,omitempty" bson:"channel,omitempty"`   //  注册渠道 自然量，facebook，Google 等
	GameId   string `json:"gameId,omitempty" bson:"gameId,omitempty"`
}
