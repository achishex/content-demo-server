package game_mng

import (
	"content_svr/config"
	"content_svr/internal/busi_comm/constant/const_busi"
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbapi"
	"content_svr/protobuf/pbmgdb"
	"content_svr/pub/logger"
	"content_svr/pub/middleware"
	"content_svr/pub/snow_flake"
	"content_svr/pub/utils"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/wechatpay-apiv3/wechatpay-go/core"
	"github.com/wechatpay-apiv3/wechatpay-go/services/payments/app"
	"go.mongodb.org/mongo-driver/bson"
	"strconv"
	"time"
)

// 登录授权
func (u *GameMng) GameAuth(ctx context.Context, userId int64, appKey string) (*pbapi.GameAuthResp, error) {
	userInfo, err := u.DataCache.GetUserBasicInfo(ctx, userId, false)
	if err != nil {
		return nil, errorcode.LOGIN_INVALID
	}

	if appKey == "" {
		return nil, errorcode.PARAM_ERROR
	}

	g, err := u.DataCache.GetImpl().SecretGameMgModel.GetByAppKey(ctx, appKey)
	if err != nil || g == nil {
		return nil, errorcode.SecretKeyError
	}

	ts := time.Now().UnixMilli()
	uid := utils.MD5(strconv.FormatInt(userInfo.GetUserId(), 10))

	return &pbapi.GameAuthResp{
		Uid:      uid,
		Ts:       ts,
		Sign:     genAuthSign(uid, ts, appKey, g.AppSecret),
		Nickname: userInfo.GetNickName(),
		Avatar:   userInfo.GetPhoto(),
	}, nil
}

// 授权签名
func genAuthSign(uid string, ts int64, appKey, appSecret string) string {
	encodeStr := fmt.Sprintf("appkey=%s&appsecret=%s&ts=%d&uid=%s", appKey, appSecret, ts, uid)
	hmacHash := hmac.New(sha256.New, []byte(appSecret))
	hmacHash.Write([]byte(encodeStr))
	return hex.EncodeToString(hmacHash.Sum(nil))
}

// 预下单
func (u *GameMng) GamePreOrder(ctx context.Context, req *pbapi.GamePreOrderReq) (*pbapi.GamePreOrderResp, error) {
	if req.AppKey == "" || req.GameId == "" || req.Sign == "" {
		return nil, errorcode.PARAM_ERROR
	}

	g, err := u.DataCache.GetImpl().SecretGameMgModel.GetByAppKey(ctx, req.AppKey)
	if err != nil || g == nil {
		return nil, errorcode.SecretKeyError
	}

	var params map[string]any
	v, _ := json.Marshal(req)
	_ = json.Unmarshal(v, &params)
	//数值直接使用，避免科学计算导致的签名字符串不一致
	params["timestamp"] = req.Timestamp
	params["amount"] = req.Amount

	//接口签名验证
	sign, encodeStr := utils.GenApiSign(params, g.AppSecret)
	logger.Infof(ctx, "encodeStr:%v", encodeStr)
	if req.Sign != sign {
		logger.Errorf(ctx, "game pay api sign error: %v, reqSign: %s, sign: %s", err, req.Sign, sign)
		return nil, errorcode.APISignError
	}

	//预下单
	orderId := snow_flake.GetSnowflakeID()
	now := time.Now()
	if err := u.DataCache.GetImpl().SecretGameOrderMgModel.Create(ctx, &pbmgdb.SecretGameOrderMgDbModel{
		Id:          strconv.FormatInt(orderId, 10),
		UserId:      middleware.GetUserID(ctx.(*gin.Context)),
		GameId:      req.GameId,
		Amount:      req.Amount,
		OutTradeNum: req.OutTradeNum,
		ProductName: req.ProductName,
		Extra:       req.Extra,
		PayType:     req.PayType,
		PayPlatform: req.PayPlatform,
		CreateTime:  now.UnixMilli(),
	}); err != nil {
		return nil, errorcode.PreCreateOrderError
	}

	prepayId := ""
	switch req.PayPlatform {
	//微信APP预下单
	case const_busi.PayPlatformWechatPay:
		prepay, err := u.WxProxy.AppPrepay(ctx, &app.PrepayRequest{
			Description: core.String(req.ProductName),
			OutTradeNo:  core.String(strconv.FormatInt(orderId, 10)),
			NotifyUrl:   core.String(config.ServerConfig.WechatConfig.AppPayNotifyUrl),
			Amount: &app.Amount{
				Total:    core.Int64(req.Amount),
				Currency: core.String("CNY"),
			},
		})
		if err != nil {
			logger.Errorf(ctx, "call wechatPay prepay fail : %v", err)
			return nil, errorcode.PreCreateOrderError
		}
		prepayId = *prepay.PrepayId

		if err := u.DataCache.GetImpl().SecretPayOrderInfoMgModel.Create(ctx, &pbmgdb.SecretPayOrderInfoMgDbModel{
			Id:          snow_flake.GetSnowflakeID(),
			OrderNo:     strconv.FormatInt(orderId, 10),
			Amount:      req.Amount,
			PayPlatform: req.PayPlatform,
			PayOrderNo:  prepayId,
			Status:      const_busi.OrderStatusNormal,
			PayStatus:   const_busi.PayStatusNoPay,
			CreateTime:  time.Now().UnixMilli(),
			AppType:     "wechat",
			AppId:       req.AppKey,
		}); err != nil {
			logger.Errorf(ctx, "create SecretPayOrderInfoMgModel fail : %v", err)
			return nil, errorcode.PreCreateOrderError
		}
	default:
		return nil, errorcode.PaymentNotSupport
	}

	//生成app支付调起签名
	appSign := u.PayMng.GenAppSign(ctx, prepayId)

	return &pbapi.GamePreOrderResp{
		MchId:     appSign.MchId,
		PrepayId:  appSign.PrepayId,
		NonceStr:  appSign.NonceStr,
		Timestamp: appSign.Timestamp,
		Sign:      appSign.Sign,
	}, nil
}

// 获取订单信息
func (u *GameMng) GameGetOrderInfo(ctx context.Context, req *pbapi.GameGetOrderInfoReq) (*pbapi.GameGetOrderInfoResp, error) {
	var (
		payOrderColl  = u.DataCache.GetImpl().SecretPayOrderInfoMgModel
		gameOrderColl = u.DataCache.GetImpl().SecretGameOrderMgModel
	)

	payOrder, err := payOrderColl.Get(ctx, bson.M{"pay_order_no": req.PrepayId})
	if err != nil {
		return nil, err
	}

	gameOrder, err := gameOrderColl.Get(ctx, bson.M{"_id": payOrder.OrderNo})
	if err != nil {
		return nil, err
	}

	return &pbapi.GameGetOrderInfoResp{
		TradeId:     payOrder.PayOrderNo,
		OutTradeId:  gameOrder.OutTradeNum,
		Uid:         gameOrder.UserId,
		GameId:      gameOrder.GameId,
		Amount:      gameOrder.Amount,
		ProductName: gameOrder.ProductName,
		Ext:         gameOrder.Extra,
		PayStatus:   payOrder.PayStatus,
		StatusMsg:   payOrder.TradeStateDesc,
		PayTime:     payOrder.PayTime,
	}, nil
}

// 绑定游戏
func (u *GameMng) GameBind(ctx context.Context, req *pbapi.BindGameReq) (*pbapi.BindGameResp, error) {
	appKey, err := uuid.NewUUID()
	if err != nil {
		return nil, err
	}

	appSecret, err := uuid.NewUUID()
	if err != nil {
		return nil, err
	}

	gameColl := u.DataCache.GetImpl().SecretGameMgModel

	if g, _ := gameColl.GetByGameId(ctx, req.GameId); g != nil {
		return nil, errorcode.GameExists
	}

	if err := gameColl.Bind(ctx, &pbmgdb.SecretGameMgDbModel{
		Id:         snow_flake.GetSnowflakeID(),
		AppKey:     appKey.String(),
		AppSecret:  appSecret.String(),
		GameId:     req.GameId,
		GameName:   req.GameName,
		GameIcon:   req.GameIcon,
		NotifyUrl:  req.NotifyUrl,
		GameUrl:    req.GameUrl,
		Desc:       req.Desc,
		CreateTime: time.Now().UnixMilli(),
	}, nil); err != nil {
		logger.Errorf(ctx, "bind game error: %v", err)
		return nil, errorcode.GameBindError
	}

	return &pbapi.BindGameResp{
		AppKey:    appKey.String(),
		AppSecret: appSecret.String(),
		GameId:    req.GameId,
	}, nil
}

// 游戏列表
func (u *GameMng) GameList(ctx context.Context, req *pbapi.GameListReq) (*pbapi.GameListResp, error) {
	list, err := u.DataCache.GetImpl().SecretGameMgModel.Find(ctx, bson.M{})
	if err != nil {
		return nil, err
	}

	var items []*pbapi.GameListItem
	for _, item := range list {
		items = append(items, &pbapi.GameListItem{
			GameId:        item.GameId,
			GameName:      item.GameName,
			GameIcon:      item.GameIcon,
			GameUrl:       item.GameUrl,
			GameDebugMode: item.DebugMode,
		})
	}

	return &pbapi.GameListResp{List: items}, nil
}
