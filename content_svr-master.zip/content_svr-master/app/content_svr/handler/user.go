package handler

import (
	"content_svr/internal/busi_comm/errorcode"
	"content_svr/protobuf/pbuserapi"
	"content_svr/pub/utils"
	"github.com/gin-gonic/gin"
)

func (p *AdminHandler) QuickLogin(ctx *gin.Context, req *pbuserapi.QuickLoginReq) (*pbuserapi.QuickLoginResp, error) {
	if req.LoginToken == "" || req.Sdkappid == "" || req.Carrier == "" {
		return nil, errorcode.PARAM_ERROR
	}

	header, err := utils.GetCtxHeadersSession(ctx)
	if err != nil {
		return nil, err
	}

	resp, err := p.UserCenterMng.QuickLogin(ctx, header, req)
	if err != nil {
		return nil, err
	}

	return resp, nil
}
