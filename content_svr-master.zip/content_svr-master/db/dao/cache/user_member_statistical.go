package cache

import (
	"content_svr/db/mongodb/model"
	"content_svr/db/mongodb/query_mng"
	"content_svr/db/mysqldb/query"
	"content_svr/db/redisdb/query_rds"
)

type UserMemberStatistical struct {
	model.UserMemberStatisticalModel
	redisManage *query_rds.Manage
}

func NewCacheUserMemberStatistical(mysql *query.Query, mongo *query_mng.QueryMng, redisManage *query_rds.Manage) *UserMemberStatistical {
	return &UserMemberStatistical{
		UserMemberStatisticalModel: mongo.UserMemberStatistical,
		redisManage:                redisManage,
	}
}
