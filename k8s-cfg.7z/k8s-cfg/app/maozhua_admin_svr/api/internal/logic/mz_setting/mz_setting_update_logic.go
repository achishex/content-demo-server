package mz_setting

import (
	"content_svr/app/maozhua_admin_svr/api/internal/svc"
	"content_svr/app/maozhua_admin_svr/api/internal/types"
	"content_svr/app/maozhua_admin_svr/common/xerr"
	"content_svr/setting"
	"context"
	"github.com/jinzhu/copier"
	"math"

	"github.com/zeromicro/go-zero/core/logx"
)

type MzSettingUpdateLogic struct {
	logx.Logger
	ctx    context.Context
	svcCtx *svc.ServiceContext
}

func NewMzSettingUpdateLogic(ctx context.Context, svcCtx *svc.ServiceContext) *MzSettingUpdateLogic {
	return &MzSettingUpdateLogic{
		Logger: logx.WithContext(ctx),
		ctx:    ctx,
		svcCtx: svcCtx,
	}
}

func (l *MzSettingUpdateLogic) MzSettingUpdate(req *types.MzSettingUpdateReq) (resp *types.MzSettingUpdateResp, err error) {
	record := setting.MaozhuaSettingRecord{}
	if err := copier.Copy(&record, req); err != nil {
		return nil, err
	}

	switch req.Value.(type) {
	case float64:
		value := record.Value.(float64)
		intPart, decimalPart := math.Modf(value)
		if decimalPart != 0.0 {
			break
		}
		record.Value = int64(intPart)
	case string:
		if req.Value == "_emptyType" {
			return nil, xerr.SettingUpdateValueError
		}
		break
	default:
		return nil, xerr.SettingUpdateError
	}

	if err := l.svcCtx.Maozhua.UpdateRecord(l.ctx, &record); err != nil {
		return nil, err
	}

	return
}
