package data_cache

import (
	"content_svr/internal/busi_comm/constant/cm_const"
	"context"
	"strconv"
)

func (p *DataCacheMng) GetAuditAwardSetting(ctx context.Context) error {
	redisKey := getRdsKeyTimesConfig("audit_award")

	result, err := p.RedisCli.HGetAll(ctx, redisKey).Result()
	if err != nil {
		return err
	}

	for k, v := range result {
		switch k {
		case "audit_award_length":
			value, err := strconv.ParseFloat(v, 10)
			if err != nil {
				continue
			}
			cm_const.AuditAwardLength = value
		case "audit_pass_max_count":
			value, err := strconv.ParseFloat(v, 10)
			if err != nil {
				continue
			}
			cm_const.AuditPassMaxCount = value
			cm_const.AuditMaliciousMaxCount = 1 - value
		case "audit_malicious_lock_time":
			value, err := strconv.Atoi(v)
			if err != nil {
				continue
			}
			cm_const.AuditMaliciousLockTime = value
		}

	}

	return nil
}
