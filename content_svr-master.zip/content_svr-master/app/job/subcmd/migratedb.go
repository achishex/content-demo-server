package subcmd

import (
	"content_svr/internal/model"
	"content_svr/internal/wxreward"
	"content_svr/pub/logger"
	"context"
	"github.com/samber/lo"
	"github.com/spf13/cobra"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
)

func NewMigrateDBCmd(pdb model.ParseTimeDB) *cobra.Command {
	// 注册entity模型
	models := []any{
		wxreward.WxRewardLog{},
		wxreward.WxRedPaperEntity{},
		wxreward.WxUserReward{},
	}
	// migrate表，空时全更新
	var tables []string

	dsn := ""

	cmd := &cobra.Command{
		Use:     "migrateDB",
		Short:   "db初始化",
		Long:    "", //长说明
		Example: "./job migrateDB --dsn=\"root:123456@tcp(127.0.0.1:3306)/payment?charset=utf8mb4&parseTime=True&loc=UTC\" \n    -t table1,table2",
		RunE: func(c *cobra.Command, args []string) error {
			ctx := context.Background()

			logger.Infof(ctx, "tables %v", tables)
			var db *gorm.DB = pdb
			if dsn != "" {
				var err error
				if db, err = gorm.Open(mysql.Open(dsn), &gorm.Config{
					SkipDefaultTransaction: true,
					NamingStrategy: schema.NamingStrategy{
						SingularTable: true,
					},
					PrepareStmt: false,
				}); err != nil {
					return err
				}
			}

			var getTableName = func(m any) string {
				stmt := &gorm.Statement{DB: db}
				stmt.Parse(m)
				return stmt.Schema.Table
			}

			migrateModels := models
			if len(tables) > 0 {
				migrateModels = lo.Filter(models, func(it any, _ int) bool {
					return lo.Contains(tables, getTableName(it))
				})
			}
			if len(migrateModels) == 0 {
				logger.Warnf(ctx, "emyty migrateModels")
				return nil
			}

			logger.Infof(ctx, "migrate tables: %v", lo.Map(migrateModels, func(it any, _ int) string {
				return getTableName(it)
			}))

			if err := db.Migrator().AutoMigrate(
				migrateModels...,
			); err != nil {
				logger.Errorf(ctx, "AutoMigrate fail, err: %v", err)
				return err
			}

			logger.Infof(ctx, "migrateDB succ.")
			return nil
		},
	}

	cmd.Flags().StringVar(&dsn, "dsn", "", "mysql dsn")
	cmd.Flags().StringSliceVarP(&tables, "tables", "t", nil, "migrate tables")

	return cmd
}
